# -*- coding: utf-8 -*-
"""Packaging + CLI: ponto de entrada instalado como `studydeck`."""

import sys

from .cli import main

if __name__ == '__main__':
    sys.exit(main() or 0)