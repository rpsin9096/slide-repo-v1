# Raw Ideation Fragments: {topic_name}

## Ingested Observations & Unstructured Thoughts
- [timestamp]: {raw_unstructured_thought_1}
- [timestamp]: {raw_unstructured_thought_2}

## Extracted Load-Bearing Terms
- `{term_1}`: {initial_conceptual_definition}
- `{term_2}`: {initial_conceptual_definition}
