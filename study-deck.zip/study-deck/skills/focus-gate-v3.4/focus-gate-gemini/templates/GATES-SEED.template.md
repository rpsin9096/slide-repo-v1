# FocusGate Seed Ledger: {task_name}
State: [Pipeline: Atomic Sprint (1/2)] [Stage: Seed Activation] [Queue: 1 active, 0 buffered] [Est: 2 min]

## 1. Activation Micro-Pledge (≤ 2 Minutes)
- [ ] seed-01: {micro_action_description}
  CHECK: {micro_check_cmd}
  EXPECT: {micro_expect_output}

<!-- Note: Once seed-01 passes, expand unblocked frontier gates into full GATES.md -->
