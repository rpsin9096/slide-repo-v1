# Context Re-Orientation (< 3s Working Memory Restore)

- **What Was Just Completed**: {last_settled_gate_or_task}
- **Where We Are**: [Pipeline: {pipeline_name}] [Active Gate: {current_gate_id}] [Queue: 1 active, {buffered_count} buffered]
- **Immediate Next Action (< 2 min)**: `▶ NEXT ACTION: {next_concrete_command_or_file}`
