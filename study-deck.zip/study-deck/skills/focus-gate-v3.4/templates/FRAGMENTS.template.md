# {working_title}

{initial_fragment}

---

{second_fragment}

---

<!-- Append raw observations, code snippets, quotes, or leading words separated by horizontal rules (---) -->
