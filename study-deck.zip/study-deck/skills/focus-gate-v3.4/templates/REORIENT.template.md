================================================================================
⚡ FOCUSGATE REORIENTATION SNAPSHOT (3-SECOND RESUME)
================================================================================
1. WHAT YOU WERE DOING:
   Task: {task_name}
   Pipeline: {pipeline_name} (Stage: {active_stage})
   Progress: [{progress_bar}] {pct_complete}% | ⚡ Streak: {streak_count} gates

2. WHERE YOU STOPPED:
   Last verified gate: {last_verified_gate} [{last_verified_time}]
   Current active gate: {active_gate_id}: {active_gate_title}
   Working directory / file: {working_target}

3. YOUR IMMEDIATE PHYSICAL NEXT ACTION (≤ 2 MIN):
   ▶ Run: {next_physical_command}
================================================================================
