# Incident Post-Mortem: {incident_name}

**Date:** {incident_date}  
**Severity:** {severity}  
**Settled Acceptance Gate:** `{settled_gate}`  

## Beat 1: Symptom & Detection
{beat_1_symptom}

## Beat 2: Immediate Containment & Hypotheses
{beat_2_containment}

## Beat 3: Root-Cause Isolation & Public Seam Failure
{beat_3_root_cause}

## Beat 4: Permanent Prevention Tracer Gate
- Verified with command: `{prevention_check_cmd}`
- Observable outcome: `{prevention_expect_pattern}`
