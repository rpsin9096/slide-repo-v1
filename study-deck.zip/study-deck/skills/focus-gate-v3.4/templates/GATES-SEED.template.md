# FocusGate Seed Ledger: {task_name}
State: [Pipeline: Atomic Sprint (1/2)] [Stage: Seed Activation] [Queue: 1 active, 0 buffered] [Est: 2 min] [Depth: L1]

## 1. Activation Micro-Pledge (≤ 2 Minutes)
- [ ] seed-01: {micro_action_description}
  CHECK: {micro_check_cmd}
  EXPECT: {micro_expect_output}

<!-- Note: Once seed-01 passes, run `focus-gate.py --compile-spec` or `--next` to expand full DAG gates -->
