# FocusGate Ledger: Meta-Production of FocusGate v3.4 Gemini Markdown Skill
State: [Step 1 of 5] [0/5 gates met] [Est: 30 min]

## 1. Domain Anchors (Micro-Glossary)
- **DeepFacetPlaybook**: Two-tier facet structure pairing invariant directive rules with an executable operational playbook.
  _Avoid_: Facets that are slogans only, rules without failure detectors.
- **CatastrophicCommandGuard**: Invariant security barrier refusing root/home wipes and raw disk writes even with override flags.
  _Avoid_: Running destructive shell commands or relying on porous regexes.
- **SwallowedExceptionDetector**: Cognitive/static check flagging broad exception blocks whose body is pass or ellipsis.
  _Avoid_: Shotgun try/except blocks that hide root cause failures.
- **DualModeExecutionHarness**: Operational protocol enabling full gate verification in tool-enabled and pure-chat environments.
  _Avoid_: Tool lock-in or unverified completion claims in conversational mode.
- **ActionEnvelopeV34**: Scannable 3-part execution header bounding turn cognitive load to a single active gate.
  _Avoid_: Multi-gate thrashing, unanchored progress summaries.

## 2. Acceptance Gates

### Production Gates
- [x] gate-01-v34-spec: Formal architecture contract in focus-gate-gemini/SPEC.md for v3.4 Gemini edition
  CHECK: python3 -c "content = open('focus-gate-gemini/SPEC.md').read(); assert all(k in content for k in ['v3.4-GEMINI', 'Deep Facets', 'Dual-Mode', 'Catastrophic Command', 'Swallowed Exception', 'Playbook']); print('SPEC_V34_OK')"
  EXPECT: ^SPEC_V34_OK$

- [x] gate-02-v34-core-skill: Master markdown skill in focus-gate-gemini/SKILL.md adapting all v3.4 mechanics
  CHECK: python3 -c "content = open('focus-gate-gemini/SKILL.md').read(); assert all(k in content for k in ['FocusGate v3.4-PROD: Evidence Gate + Deep Facets', '▶ NEXT ACTION:', 'Zero Placeholder Policy', 'Action Envelope', 'Cognitive Integrity Linter', 'Red Before Green', 'SWALLOWED_EXCEPTION', 'DESTRUCTIVE_COMMAND']) and len(content.splitlines()) >= 350; print('SKILL_V34_OK')"
  EXPECT: ^SKILL_V34_OK$

- [x] gate-03-v34-deep-facets-and-oracles: Complete 19 deep facets with playbooks and all 7 oracles in references
  CHECK: python3 -c "import json; f_ref = open('focus-gate-gemini/references/facets.md').read(); o_ref = open('focus-gate-gemini/references/oracles.md').read(); facets = json.load(open('facets/facet_index.json'))['facets']; assert all(f in f_ref for f in facets); assert all(k in f_ref for k in ['Playbook', 'Lazy Tells', 'Phases']); assert all(o in o_ref for o in ['Prose Cliché', 'Code Cliché', 'Design Cliché', 'Contrast', 'Safe-Zone', 'Context Sufficiency', 'Infinite Loop']); print('DEEP_FACETS_ORACLES_OK')"
  EXPECT: ^DEEP_FACETS_ORACLES_OK$

- [x] gate-04-v34-gates-and-templates: References gates.md and all 6 templates in focus-gate-gemini/templates/
  CHECK: python3 -c "import glob; g_ref = open('focus-gate-gemini/references/gates.md').read(); bad = ['TO'+'DO', 'FIX'+'ME']; tmpls = glob.glob('focus-gate-gemini/templates/*.md'); assert len(tmpls) >= 6; assert not any(any(b in open(t).read() for b in bad) for t in tmpls); assert 'Catastrophic' in g_ref; print('TEMPLATES_V34_OK')"
  EXPECT: ^TEMPLATES_V34_OK$

- [x] gate-05-v34-verification-clean: Complete audit of all files in focus-gate-gemini/ ensuring zero stubs and valid markdown
  CHECK: python3 -c "import glob; bad = ['TO'+'DO', 'FIX'+'ME']; files = glob.glob('focus-gate-gemini/**/*.md', recursive=True); assert len(files) >= 11; assert not any(any(b in open(f).read() for b in bad) for f in files); print('V34_PACKAGE_VERIFIED')"
  EXPECT: ^V34_PACKAGE_VERIFIED$

## 3. Micro-ADR Ledger
- **[ADR-001] Standalone Skill Directory Structure**: Package FocusGate v3.4 into a self-contained `focus-gate-gemini/` directory tree with modular `references/` and `templates/` for zero-dependency execution on Gemini Spark and Gemini Chat.
- **[ADR-002] Deep Facets Two-Tier Representation**: Port v3.4's two-tier facet paradigm (Rule Invariants + Operational Playbook with Phases, Lazy Tells, Gate Templates, and Handoffs) directly into markdown instructions.
