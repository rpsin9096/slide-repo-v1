# FocusGate v3.4 build ledger (dogfood: v3.3 baselines RED, v3.4 settles)

## 2. Acceptance Gates

### Production Gates
- [x] c1-thin-entry: the script is an entry point and main() only dispatches
  CHECK: python3 -m unittest tests.test_v34_architecture.TestThinEntry
  EXPECT: \nOK(?: \(skipped=\d+\))?$
- [x] c2-one-dispatcher: every command, early or not, resolves through the registry
  CHECK: python3 -m unittest tests.test_v34_architecture.TestOneDispatcher
  EXPECT: \nOK(?: \(skipped=\d+\))?$
- [x] c3-handlers-return-codes: handlers return exit codes and never call sys.exit
  CHECK: python3 -m unittest tests.test_v34_architecture.TestHandlersReturnCodes
  EXPECT: \nOK(?: \(skipped=\d+\))?$
- [x] c4-no-dead-flags: every documented flag is a command or a read modifier
  CHECK: python3 -m unittest tests.test_v34_architecture.TestNoDeadFlags
  EXPECT: \nOK(?: \(skipped=\d+\))?$
- [x] c5-latent-bugs: validate-contracts reads a real event log
  CHECK: python3 -m unittest tests.test_v34_architecture.TestLatentBugs
  EXPECT: \nOK(?: \(skipped=\d+\))?$
- [x] c6-rigor-swallow: the rigor guard flags broad handlers that do nothing (O10)
  CHECK: python3 -m unittest tests.test_v34_architecture.TestRigorSeesSwallowedExceptions
  EXPECT: \nOK(?: \(skipped=\d+\))?$
- [x] c7-destructive-never-runs: destructive CHECKs are refused and never executed (O2)
  CHECK: python3 -m unittest tests.test_v34_architecture.TestDestructiveChecksAreNeverExecuted
  EXPECT: \nOK(?: \(skipped=\d+\))?$
- [x] c8-docs-true: version, changelog, audit and architecture doc agree
  CHECK: python3 -m unittest tests.test_v34_architecture.TestV34Docs
  EXPECT: \nOK(?: \(skipped=\d+\))?$
- [x] z-no-regression: the whole suite passes
  CHECK: python3 -m unittest discover -s tests -p 'test_*.py'
  EXPECT: \nOK(?: \(skipped=\d+\))?$
  TIMEOUT: 240
