"""FocusGate v2.8.5 — CLI Module Package."""
from .dispatch import CLIDispatcher

__all__ = ["CLIDispatcher"]
