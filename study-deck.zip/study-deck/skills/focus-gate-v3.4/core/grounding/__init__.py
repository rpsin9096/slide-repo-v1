"""FocusGate v2.9 — Ubiquitous Concept Grounding & Spec Compilation."""

from core.grounding.grounding_linter import ConceptGroundingLinter, SpecToLedgerCompiler

__all__ = ["ConceptGroundingLinter", "SpecToLedgerCompiler"]
