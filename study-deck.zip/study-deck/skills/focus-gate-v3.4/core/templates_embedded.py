"""Embedded scaffolding templates (moved out of scripts/focus-gate.py in v3.3)."""
import os
import re
import sys
import json
from typing import Any, Dict, List, Optional, Tuple

class EmbeddedTemplates:
    """Zero-dependency embedded templates for immediate workspace scaffolding."""

    GATES_TASK_MD = """# FocusGate Ledger: {task_name}
State: [Step 1 of 4] [0/2 gates met] [Est: 20 min]

## 1. Domain Anchors (Micro-Glossary)
- **{canonical_term}**: {term_definition}
  _Avoid_: {term_avoid}

## 2. Acceptance Gates

### Spikes (Throwaway Explorations)
- [ ] spike-logic-{spike_name}: Test core state machine hypothesis
  BRANCH: logic
  QUESTION: Does the proposed state machine deadlock under concurrent updates?
  ARTIFACT: .focusgate/prototypes/{spike_name}.html
  CHECK: python3 {cli_path} --verify-spike .focusgate/prototypes/{spike_name}.html
  EXPECT: VALID_LOGIC_PROTOTYPE

### Production Gates
- [ ] gate-1: <the observable behavior this gate proves>
  CHECK: <command that FAILS now and passes only when the behavior exists>
  EXPECT: <regex present only in the passing output>

## 3. Micro-ADR Ledger
- **None yet.**
"""

    UI_PROTOTYPE_MD = """# FocusGate UI Prototype Guide: {prototype_name}

**Question**: {question}

## Invariant Rules
1. Single Route, Multi-Variant: Deploy variants A, B, and C on one test route.
2. Floating Switcher: Provide immediate variant switching via bottom floating toolbar.
3. No Persistence: State lives purely in-memory.

## Floating Switcher Component
```html
<div style="position: fixed; bottom: 1rem; left: 50%; transform: translateX(-50%); background: #0f172a; color: white; padding: 0.5rem 1rem; border-radius: 9999px; box-shadow: 0 10px 25px rgba(0,0,0,0.5); display: flex; gap: 0.5rem; z-index: 9999; font-family: sans-serif; font-size: 0.85rem;">
  <span style="opacity: 0.6; margin-right: 0.25rem;">Variant:</span>
  <button onclick="setVariant('a')" class="var-btn">A: Standard</button>
  <button onclick="setVariant('b')" class="var-btn">B: Simplified</button>
  <button onclick="setVariant('c')" class="var-btn">C: Wizard</button>
</div>
```
"""

    ADR_MICRO_MD = """### [{adr_id}] {title}
- **Context & Trade-off**: {context_tradeoff}
- **Decision**: {decision}
"""

    LOGIC_PROTOTYPE_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>FocusGate Logic Prototype: {prototype_title}</title>
  <style>
    :root {{
      --bg: #0f172a;
      --card-bg: #1e293b;
      --border: #334155;
      --text: #f8fafc;
      --text-muted: #94a3b8;
      --primary: #38bdf8;
      --accent: #f59e0b;
      --success: #10b981;
      --danger: #ef4444;
    }}
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      background: var(--bg);
      color: var(--text);
      line-height: 1.5;
      padding: 2rem;
      max-width: 900px;
      margin: 0 auto;
    }}
    header {{ margin-bottom: 2rem; border-bottom: 1px solid var(--border); padding-bottom: 1.5rem; }}
    .badge {{
      display: inline-block;
      padding: 0.25rem 0.75rem;
      background: rgba(56, 189, 248, 0.15);
      color: var(--primary);
      border-radius: 9999px;
      font-size: 0.8rem;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      margin-bottom: 0.5rem;
    }}
    h1 {{ font-size: 1.75rem; margin-bottom: 0.5rem; }}
    .question-banner {{
      background: rgba(245, 158, 11, 0.1);
      border-left: 4px solid var(--accent);
      padding: 1rem;
      border-radius: 4px;
      margin-top: 1rem;
      color: #fde68a;
      font-weight: 500;
    }}
    .panel {{
      background: var(--card-bg);
      border: 1px solid var(--border);
      border-radius: 8px;
      padding: 1.5rem;
      margin-bottom: 1.5rem;
    }}
    .panel h2 {{ font-size: 1.1rem; color: var(--primary); margin-bottom: 1rem; }}
    .state-grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 1rem;
      margin-bottom: 1rem;
    }}
    .state-cell {{
      background: rgba(15, 23, 42, 0.6);
      padding: 0.75rem;
      border-radius: 6px;
      border: 1px solid var(--border);
    }}
    .state-label {{ font-size: 0.75rem; color: var(--text-muted); text-transform: uppercase; }}
    .state-value {{ font-size: 1.25rem; font-weight: 600; margin-top: 0.25rem; }}
    .btn-group {{ display: flex; gap: 0.75rem; flex-wrap: wrap; margin-bottom: 1rem; }}
    button {{
      background: var(--primary);
      color: #0f172a;
      border: none;
      padding: 0.6rem 1.2rem;
      border-radius: 6px;
      font-weight: 600;
      font-size: 0.9rem;
      cursor: pointer;
      transition: opacity 0.2s;
    }}
    button:hover {{ opacity: 0.9; }}
    button.secondary {{ background: var(--border); color: var(--text); }}
    .tabs {{ display: flex; gap: 0.5rem; border-bottom: 1px solid var(--border); margin-bottom: 1rem; }}
    .tab {{
      background: transparent;
      color: var(--text-muted);
      border: none;
      padding: 0.5rem 1rem;
      cursor: pointer;
      border-bottom: 2px solid transparent;
      border-radius: 0;
    }}
    .tab.active {{ color: var(--primary); border-bottom: 2px solid var(--primary); font-weight: 600; }}
    .scenario-box {{ display: none; }}
    .scenario-box.active {{ display: block; }}
    .step-list {{ list-style: none; margin: 1rem 0; counter-reset: step-counter; }}
    .step-list li {{
      padding: 0.5rem;
      background: rgba(15, 23, 42, 0.5);
      border: 1px solid var(--border);
      border-radius: 4px;
      margin-bottom: 0.5rem;
      font-family: monospace;
      font-size: 0.85rem;
    }}
    .step-list li.current {{ border-color: var(--primary); color: var(--primary); font-weight: 600; }}
    pre {{
      background: #060911;
      padding: 1rem;
      border-radius: 6px;
      border: 1px solid var(--border);
      font-family: monospace;
      font-size: 0.85rem;
      overflow-x: auto;
    }}
  </style>
</head>
<body>

  <header>
    <div class="badge">FocusGate Logic Prototype</div>
    <h1>{prototype_title}</h1>
    <div class="question-banner">
      <strong>Core Question:</strong> {prototype_question}
    </div>
  </header>

  <!-- 1. Live State Inspection Panel -->
  <section class="panel">
    <h2>Current State</h2>
    <div class="state-grid" id="state-grid"></div>
  </section>

  <!-- 2. Free-Play Action Buttons -->
  <section class="panel">
    <h2>Interactive Actions</h2>
    <div class="btn-group">
      <button onclick="dispatchAction('INIT')">Initialize</button>
      <button onclick="dispatchAction('TRANSITION_NEXT')">Transition Next</button>
      <button class="secondary" onclick="dispatchAction('RESET')">Reset</button>
    </div>
    <div style="font-size: 0.85rem; color: var(--text-muted);">
      Last Action: <span id="last-action" style="color: var(--text); font-weight: 600;">None</span>
    </div>
  </section>

  <!-- 3. Guided Walkthrough Scenarios -->
  <section class="panel">
    <h2>Guided Walkthroughs</h2>
    <div class="tabs">
      <button class="tab active" onclick="switchTab(0)">Happy Path</button>
      <button class="tab" onclick="switchTab(1)">Boundary Check</button>
    </div>

    <div id="scenario-content">
      <div class="scenario-box active" id="scenario-0">
        <p><strong>Goal:</strong> Normal transition flow without deadlock.</p>
        <ol class="step-list" id="steps-0"></ol>
        <button onclick="runNextStep(0)">Next Step</button>
        <button class="secondary" onclick="resetScenario(0)">Reset Scenario</button>
      </div>

      <div class="scenario-box" id="scenario-1">
        <p><strong>Goal:</strong> Validate boundary handling and error containment.</p>
        <ol class="step-list" id="steps-1"></ol>
        <button onclick="runNextStep(1)">Next Step</button>
        <button class="secondary" onclick="resetScenario(1)">Reset Scenario</button>
      </div>
    </div>
  </section>

  <!-- 4. Raw State Dump & Log -->
  <section class="panel">
    <h2>State Inspector & Log</h2>
    <pre id="raw-state">{{}}</pre>
  </section>

  <!-- ISOLATED PURE DOMAIN MODULE -->
  <script id="core-logic">
    // Pure domain module - Zero DOM dependencies
    const DomainModule = (() => {{
      const initialState = {{
        status: 'IDLE',
        step: 0,
        data: {{}},
        error: null
      }};

      function reduce(state = initialState, action) {{
        switch (action.type) {{
          case 'INIT':
            return {{ ...state, status: 'INITIALIZED', step: 1, error: null }};
          case 'TRANSITION_NEXT':
            return {{ ...state, status: 'RUNNING', step: state.step + 1 }};
          case 'RESET':
            return {{ ...initialState }};
          default:
            return state;
        }}
      }}

      return {{
        initialState,
        reduce
      }};
    }})();
  </script>

  <!-- Prototype Harness Glue -->
  <script>
    let currentState = DomainModule.initialState;
    const scenarios = [
      {{ steps: ['INIT', 'TRANSITION_NEXT'], current: 0 }},
      {{ steps: ['TRANSITION_NEXT', 'RESET'], current: 0 }}
    ];

    function renderState() {{
      const grid = document.getElementById('state-grid');
      grid.innerHTML = `
        <div class="state-cell">
          <div class="state-label">Status</div>
          <div class="state-value">${{currentState.status}}</div>
        </div>
        <div class="state-cell">
          <div class="state-label">Step</div>
          <div class="state-value">${{currentState.step}}</div>
        </div>
      `;
      document.getElementById('raw-state').textContent = JSON.stringify(currentState, null, 2);
    }}

    function dispatchAction(type, payload = {{}}) {{
      currentState = DomainModule.reduce(currentState, {{ type, ...payload }});
      document.getElementById('last-action').textContent = type;
      renderState();
    }}

    function switchTab(idx) {{
      document.querySelectorAll('.tab').forEach((t, i) => t.classList.toggle('active', i === idx));
      document.querySelectorAll('.scenario-box').forEach((b, i) => b.classList.toggle('active', i === idx));
    }}

    function runNextStep(scenarioIdx) {{
      const sc = scenarios[scenarioIdx];
      if (sc.current < sc.steps.length) {{
        dispatchAction(sc.steps[sc.current]);
        sc.current++;
        renderScenarioSteps(scenarioIdx);
      }}
    }}

    function resetScenario(scenarioIdx) {{
      scenarios[scenarioIdx].current = 0;
      dispatchAction('RESET');
      renderScenarioSteps(scenarioIdx);
    }}

    function renderScenarioSteps(scenarioIdx) {{
      const list = document.getElementById(`steps-${{scenarioIdx}}`);
      const sc = scenarios[scenarioIdx];
      list.innerHTML = sc.steps.map((st, i) =>
        `<li class="${{i === sc.current ? 'current' : ''}}">${{st}} ${{i < sc.current ? '&#10003;' : ''}}</li>`
      ).join('');
    }}

    // Initial boot
    renderState();
    renderScenarioSteps(0);
    renderScenarioSteps(1);
  </script>
</body>
</html>
"""
