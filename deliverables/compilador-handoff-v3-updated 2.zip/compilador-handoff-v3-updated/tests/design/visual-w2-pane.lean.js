import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

/* Wave 2 — Settings-Pane rhythm + controls (VISUAL-PROD-SPEC G5/G2/G3).
 * CSS-invariant gates over the pane surface only (no modals, no W3).
 * Run: node --test tests/lean/visual-w2-pane.lean.js */

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..');
const ds = readFileSync(join(root, 'static', 'design-system.css'), 'utf8');

const blockOf = (css, selector) => {
  const i = css.indexOf(selector + ' {');
  assert.notEqual(i, -1, `missing rule: ${selector}`);
  const open = css.indexOf('{', i);
  const close = css.indexOf('}', open);
  return css.slice(open + 1, close);
};

describe('visual W2 RED — pane rhythm + controls', () => {
  it('G5: field-row sits on the 4pt grid (32px row, 4/8px rhythm)', () => {
    const b = blockOf(ds, 'button.field-row');
    assert.ok(b.includes('min-height: var(--space-4xl)'), `expected min-height var(--space-4xl) (32px), got: ${b.trim()}`);
    assert.ok(!b.includes('var(--space-xs)'), `no 6px var(--space-xs) padding on field-row, got: ${b.trim()}`);
  });

  it('G5: acc-head carries a 4pt min-height', () => {
    const b = blockOf(ds, '.acc-head');
    assert.ok(b.includes('min-height:'), `.acc-head must declare min-height on 4pt multiples, got: ${b.trim()}`);
  });

  it('W2.2: toc page numbers use tabular-nums', () => {
    const anchor = ds.indexOf('\n.toc-preview-page {');
    assert.notEqual(anchor, -1, 'missing rule: .toc-preview-page');
    const open = ds.indexOf('{', anchor);
    const b = ds.slice(open + 1, ds.indexOf('}', open));
    assert.ok(b.includes('tabular-nums'), `.toc-preview-page must use font-variant-numeric: tabular-nums, got: ${b.trim()}`);
  });

  it('G2-single-ring: segment focus uses one ring (no 2px outline stack)', () => {
    const b = blockOf(ds, '.segment input:focus-visible + span');
    assert.ok(b.includes('var(--focus-glow)'), `expected var(--focus-glow), got: ${b.trim()}`);
    assert.ok(!b.includes('outline: 2px'), `must not stack a 2px outline over the glow, got: ${b.trim()}`);
  });
});
