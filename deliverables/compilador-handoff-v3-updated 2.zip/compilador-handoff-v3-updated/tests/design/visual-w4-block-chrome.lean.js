import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

/* Milestone 1 — Card chrome (D1 toolbar visible + D4 footer hierarchy).
 * CSS-invariant gates over the active workspace surface only.
 * Run: node --test tests/lean/visual-w4-block-chrome.lean.js */

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..');
const ds = () => readFileSync(join(root, 'static', 'design-system.css'), 'utf8');

const blockOf = (css, selector) => {
  const i = css.indexOf(selector + ' {');
  assert.notEqual(i, -1, `missing rule: ${selector}`);
  const open = css.indexOf('{', i);
  const close = css.indexOf('}', open);
  return css.slice(open + 1, close);
};

describe('visual M1 — card chrome production gates', () => {
  it('D1: block toolbar is fully visible at rest (no 0.35 mute)', () => {
    const b = blockOf(ds(), '.box-card > .toolbar-groups');
    assert.ok(b.includes('opacity: 1'), `expected opacity: 1 at rest, got: ${b.trim()}`);
    assert.ok(!b.includes('0.35'), 'rest opacity must not mute to 0.35');
  });

  it('D4: footer is a 12px muted bar with top hairline', () => {
    const b = blockOf(ds(), '.box-footer');
    assert.ok(b.includes('var(--line)'), `expected hairline var(--line), got: ${b.trim()}`);
    assert.ok(
      b.includes('var(--font-size-xs)') || b.includes('12px'),
      `expected 12px footer type, got: ${b.trim()}`
    );
    assert.ok(
      b.includes('var(--color-muted)') || b.includes('var(--color-text-secondary)'),
      `expected muted footer color, got: ${b.trim()}`
    );
  });

  it('D4: mode switch reads as a pill group', () => {
    const b = blockOf(ds(), '.mode-switcher');
    assert.ok(
      b.includes('var(--radius-pill)') || b.includes('9999px'),
      `expected pill radius, got: ${b.trim()}`
    );
  });

  it('D4: char-count stays right-aligned tabular-nums', () => {
    const b = blockOf(ds(), '.char-count');
    assert.ok(b.includes('tabular-nums'), `expected tabular-nums, got: ${b.trim()}`);
    assert.ok(b.includes('text-align: right'), `expected right-aligned, got: ${b.trim()}`);
  });
});
