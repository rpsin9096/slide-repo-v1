import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

/* Mobile landscape gap: the portal quick-menu (14 items, ~350px tall at
 * 360px widths) has no height cap — on short viewports it clips past the
 * fold with no way to reach lower items. Cap to the viewport with inner
 * scroll; portrait viewports are unaffected (cap sits above content height).
 * Run: node --test tests/lean/visual-w10-menu-viewport.lean.js */

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..');
const ds = () => readFileSync(join(root, 'static', 'design-system.css'), 'utf8');

const blockOf = (css, selector) => {
  const esc = selector.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const m = new RegExp('(^|\\n)[ \\t]*' + esc + ' \\{', 'm').exec(css);
  assert.ok(m, `missing rule: ${selector}`);
  const open = css.indexOf('{', m.index);
  const close = css.indexOf('}', open);
  return css.slice(open + 1, close);
};

describe('visual W10 — portal menu survives short viewports', () => {
  it('floating menu caps to viewport height with inner scroll', () => {
    const b = blockOf(ds(), '#ui-portal .bedit-quick-menu.portal-open');
    assert.ok(/max-height:\s*calc\(100vh/.test(b), `expected viewport cap, got: ${b.trim()}`);
    assert.ok(b.includes('overflow-y: auto'), `expected inner scroll, got: ${b.trim()}`);
  });

  it('guards: width clamps + two-column fallback intact', () => {
    const b = blockOf(ds(), '#ui-portal .bedit-quick-menu.portal-open');
    assert.ok(b.includes('min(380px'), 'min clamp kept');
    assert.ok(b.includes('min(420px'), 'max clamp kept');
    assert.ok(ds().includes('repeat(2, minmax(96px, 1fr))'), '360px fallback kept');
  });
});
