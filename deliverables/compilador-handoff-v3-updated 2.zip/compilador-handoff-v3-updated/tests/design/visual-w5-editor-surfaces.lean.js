import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

/* Milestone 2 — Editor surfaces (D2 parity + D3 shell comfort + D6 type).
 * CSS-invariant gates over the active workspace surface only.
 * Run: node --test tests/lean/visual-w5-editor-surfaces.lean.js */

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..');
const ds = () => readFileSync(join(root, 'static', 'design-system.css'), 'utf8');
const app = () => readFileSync(join(root, 'static', 'v2-app.js'), 'utf8');

const blockOf = (css, selector) => {
  // Anchor to line start so multi-selector tails (e.g. reduced-motion lists
  // ending in `> .rich-container {`) never shadow the canonical rule.
  const esc = selector.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const m = new RegExp('(^|\\n)[ \\t]*' + esc + ' \\{', 'm').exec(css);
  assert.ok(m, `missing rule: ${selector}`);
  const open = css.indexOf('{', m.index);
  const close = css.indexOf('}', open);
  return css.slice(open + 1, close);
};

describe('visual M2 — editor surfaces production gates', () => {
  it('D2: markdown + rich share 12px padding (no density jump)', () => {
    for (const sel of ['.box-md', '.rich-container']) {
      const b = blockOf(ds(), sel);
      assert.ok(b.includes('padding: 12px'), `expected padding: 12px in ${sel}, got: ${b.trim()}`);
    }
  });

  it('D2 guards: shared radius + surface background', () => {
    for (const sel of ['.box-md', '.rich-container']) {
      const b = blockOf(ds(), sel);
      assert.ok(b.includes('border-radius: 8px'), `expected 8px radius in ${sel}, got: ${b.trim()}`);
      assert.ok(b.includes('var(--surface)'), `expected surface background in ${sel}, got: ${b.trim()}`);
    }
  });

  it('D3: shell breathes at 132px empty, caps at 42vh', () => {
    const b = blockOf(ds(), '.box-editor-shell');
    assert.ok(b.includes('132px'), `expected 132px min-height, got: ${b.trim()}`);
    assert.ok(b.includes('42vh'), `expected 42vh cap, got: ${b.trim()}`);
  });

  it('D3: both editor children share the 132px floor', () => {
    for (const sel of ['.box-md', '.rich-container']) {
      const b = blockOf(ds(), sel);
      assert.ok(b.includes('132px'), `expected 132px min-height in ${sel}, got: ${b.trim()}`);
    }
  });

  it('D3: scrollable editors carry an inset top scroll cue', () => {
    for (const sel of ['.box-md', '.rich-container']) {
      const b = blockOf(ds(), sel);
      assert.ok(b.includes('inset'), `expected inset scroll cue in ${sel}, got: ${b.trim()}`);
    }
  });

  it('D6: editing size steps up to 14px', () => {
    const css = ds();
    assert.ok(
      css.includes('--editor-size: var(--font-size-base)') || css.includes('--editor-size: 14px'),
      'expected --editor-size at 14px (font-size-base)'
    );
  });

  it('D6: editing line-height is 1.6 across markdown + rich surfaces', () => {
    for (const sel of ['.box-md', '.bedit-raw', '.bedit-preview', '.bedit-ce']) {
      const b = blockOf(ds(), sel);
      assert.ok(b.includes('line-height: 1.6'), `expected 1.6 in ${sel}, got: ${b.trim()}`);
    }
  });

  it('D6 guards: H1 preview stays color-text, autosize cap untouched', () => {
    const h1 = blockOf(ds(), '.bedit-preview-h1');
    assert.ok(h1.includes('var(--color-text)'), `expected color-text H1, got: ${h1.trim()}`);
    assert.ok(app().includes('0.42'), 'autosize 42vh cap must stay in v2-app.js');
  });
});
