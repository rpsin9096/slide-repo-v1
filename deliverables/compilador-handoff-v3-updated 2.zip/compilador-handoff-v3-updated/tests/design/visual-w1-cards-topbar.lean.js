import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

/* Wave 1 — Block Cards + Topbar (VISUAL-PROD-SPEC G1/G2/G3/G5).
 * CSS-invariant gates over the active workspace surface only.
 * No full suites; run: node --test tests/lean/visual-w1-cards-topbar.lean.js */

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..');
const ds = readFileSync(join(root, 'static', 'design-system.css'), 'utf8');

const blockOf = (css, selector) => {
  const i = css.indexOf(selector + ' {');
  assert.notEqual(i, -1, `missing rule: ${selector}`);
  const open = css.indexOf('{', i);
  const close = css.indexOf('}', open);
  return css.slice(open + 1, close);
};

describe('visual W1 RED — cards + topbar production gates', () => {
  it('G2: card focus-within uses the single token ring', () => {
    const b = blockOf(ds, '.box-card:focus-within');
    assert.ok(b.includes('var(--focus-glow)'), `expected var(--focus-glow) in .box-card:focus-within, got: ${b.trim()}`);
    assert.ok(!b.includes('color-mix'), 'focus ring must not hardcode color-mix');
  });

  it('W1.2: card hover is hairline-only (no shadow lift)', () => {
    const b = blockOf(ds, '.box-card:hover');
    assert.ok(b.includes('var(--line-strong)'), `expected hairline var(--line-strong), got: ${b.trim()}`);
    assert.ok(!b.includes('box-shadow'), 'hover must not add box-shadow');
    assert.ok(!b.includes('rgba'), 'hover must not hardcode rgba');
  });

  it('G3: brand-mark resolves color through tokens (no #fff)', () => {
    const b = blockOf(ds, '.brand-mark');
    assert.ok(!b.match(/#[0-9a-fA-F]{3,6}/), `no hardcoded hex in .brand-mark, got: ${b.trim()}`);
    assert.ok(b.includes('var(--'), '.brand-mark must use var(--*) tokens');
  });

  it('W1.1/W1.3: desktop header + topbar rows stay single-row', () => {
    for (const sel of ['.topbar-center', '.box-header-actions']) {
      const b = blockOf(ds, sel);
      assert.ok(b.includes('flex-wrap: nowrap'), `${sel} must be single-row (flex-wrap: nowrap), got: ${b.trim()}`);
    }
  });

  it('G3: primary action resolves text through tokens (no #fff)', () => {
    for (const sel of ['.btn-primary', '.btn-primary:hover']) {
      const b = blockOf(ds, sel);
      assert.ok(!b.match(/#[0-9a-fA-F]{3,6}/), `no hardcoded hex in ${sel}, got: ${b.trim()}`);
      assert.ok(b.includes('var(--'), `${sel} must use var(--*) tokens`);
    }
  });
});
