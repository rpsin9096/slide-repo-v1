import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../..');

describe('visual W13 — Template-Aware Editorial Document Geometry & Fragmentation CSS & Config Locks', () => {
  it('W13.1: design-guardrails.config.json defines defaults (geometry + fragmentation) and all template profiles while preserving archetype/tokens', () => {
    const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'design-guardrails.config.json'), 'utf8'));
    assert.equal(cfg.archetype?.spacing_base, 4, 'preserves 4px spacing_base');
    assert.ok(cfg.defaults?.geometry, 'defaults.geometry present');
    assert.ok(cfg.defaults?.fragmentation, 'defaults.fragmentation present');
    assert.equal(cfg.defaults.geometry.format, 'A4');
    assert.equal(cfg.defaults.geometry.orientation, 'portrait');
    assert.equal(cfg.defaults.geometry.width, '210mm');
    assert.equal(cfg.defaults.geometry.height, '297mm');
    assert.equal(cfg.defaults.geometry.pushDownThresholdPx, 130);
    assert.equal(cfg.defaults.geometry.subPixelTolerancePx, 1.5);
    assert.equal(cfg.defaults.fragmentation.continuationLabel, '(Continuação...)');
    assert.equal(cfg.defaults.fragmentation.minOrphanLines, 3);
    assert.equal(cfg.defaults.fragmentation.minWidowLines, 3);
    assert.equal(cfg.defaults.fragmentation.minTableRowsBeforeSplit, 2);
    assert.equal(cfg.defaults.fragmentation.minTableRowsAfterSplit, 2);
    assert.equal(cfg.defaults.fragmentation.minListItemsBeforeSplit, 2);
    assert.equal(cfg.defaults.fragmentation.minListItemsAfterSplit, 2);
    assert.equal(cfg.defaults.fragmentation.headingGlueLines, 2);

    for (const tpl of [
      'default',
      'executive-report',
      'legal-contract',
      'compact-technical',
      'landscape-dossier',
      'us-letter-brief',
      'base',
      'bauhaus',
      'bauhaus_minimalist',
    ]) {
      assert.ok(cfg.templates && tpl in cfg.templates, `missing template profile: ${tpl}`);
    }
    assert.equal(cfg.templates['executive-report'].geometry.firstPageMarginTop, '35mm');
    assert.equal(cfg.templates['executive-report'].geometry.firstPageHeaderSafeZone, '0mm');
    assert.equal(cfg.templates['legal-contract'].fragmentation.minOrphanLines, 4);
    assert.equal(cfg.templates['landscape-dossier'].geometry.orientation, 'landscape');
    assert.equal(cfg.templates['us-letter-brief'].geometry.format, 'Letter');
  });

  it('W13.2: static/design-system.css defines template geometry custom properties, @page rules, and .virtual-page-preview', () => {
    const ds = fs.readFileSync(path.join(ROOT, 'static/design-system.css'), 'utf8');
    for (const prop of [
      '--page-width: 210mm',
      '--page-height: 297mm',
      '--page-margin-top: 24mm',
      '--page-margin-bottom: 28mm',
      '--page-margin-inside: 20mm',
      '--page-margin-outside: 24mm',
      '--running-header-safe-zone: 12mm',
      '--running-footer-safe-zone: 12mm',
      '--first-page-margin-top: 24mm',
      '--first-page-margin-bottom: 28mm',
      '--first-page-header-safe-zone: 12mm',
      '--first-page-footer-safe-zone: 12mm',
    ]) {
      assert.ok(ds.includes(prop), `missing custom property in design-system.css: ${prop}`);
    }
    assert.match(ds, /@page\s*\{/);
    assert.match(ds, /@page\s*:first\s*\{/);
    assert.match(ds, /@page\s*:left\s*\{/);
    assert.match(ds, /@page\s*:right\s*\{/);
    assert.match(ds, /\.virtual-page-preview\s*\{/);
  });

  it('W13.3: static/design-system.css defines orphan/widow guards, heading/list-intro glue, atomic containers, continuation markers, and .is-page-bottom rules', () => {
    const ds = fs.readFileSync(path.join(ROOT, 'static/design-system.css'), 'utf8');
    const shell = fs.readFileSync(path.join(ROOT, 'static/shell.css'), 'utf8');
    assert.match(ds, /orphans:\s*3/);
    assert.match(ds, /widows:\s*3/);
    assert.match(ds, /break-after:\s*avoid-page\s*!important/);
    assert.match(ds, /li:nth-child\(-n\+2\)/);
    assert.match(ds, /\.callout-box/);
    assert.match(ds, /\.allow-emergency-split\s*\{[\s\S]*?break-inside:\s*auto\s*!important/);
    assert.match(ds, /\.continuation-marker/);
    assert.match(ds, /\.js-forced-page-break\s*\{[\s\S]*?break-before:\s*page\s*!important/);
    assert.match(ds, /\.is-page-bottom\s*\{[\s\S]*?margin-bottom:\s*0\s*!important/);
    assert.match(ds, /\.is-page-bottom:not\(\.is-framed-box\)\s*\{[\s\S]*?padding-bottom:\s*0\s*!important/);
    assert.match(ds, /@media\s+print\s*\{/);
    assert.equal(/@page\s*\{/.test(shell), false, 'shell.css must not override @page');
    assert.equal(/\.is-page-bottom/.test(shell), false, 'shell.css must not override .is-page-bottom');
  });
});
