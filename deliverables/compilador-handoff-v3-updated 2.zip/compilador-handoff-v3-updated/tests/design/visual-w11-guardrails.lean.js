import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../..');
const dsCss = fs.readFileSync(path.join(ROOT, 'static/design-system.css'), 'utf8');
const shellCss = fs.readFileSync(path.join(ROOT, 'static/shell.css'), 'utf8');
const designMd = fs.readFileSync(path.join(ROOT, 'DESIGN.md'), 'utf8');
const guardrailsCfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'design-guardrails.config.json'), 'utf8'));

function extractBlock(css, headerSubstring) {
  const idx = css.indexOf(headerSubstring);
  assert.ok(idx !== -1, `CSS header not found: ${headerSubstring}`);
  const openIdx = css.indexOf('{', idx);
  let depth = 0;
  for (let i = openIdx; i < css.length; i++) {
    if (css[i] === '{') depth++;
    else if (css[i] === '}') {
      depth--;
      if (depth === 0) return css.slice(openIdx + 1, i);
    }
  }
  throw new Error(`Unclosed CSS block for ${headerSubstring}`);
}

function stripComments(css) {
  return css.replace(/\/\*[\s\S]*?\*\//g, '');
}

function relativeLuminance(hex) {
  const clean = hex.replace('#', '');
  const r = parseInt(clean.slice(0, 2), 16) / 255;
  const g = parseInt(clean.slice(2, 4), 16) / 255;
  const b = parseInt(clean.slice(4, 6), 16) / 255;
  const toLinear = (c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4);
  return 0.2126 * toLinear(r) + 0.7152 * toLinear(g) + 0.0722 * toLinear(b);
}

function contrastRatio(hexA, hexB) {
  const l1 = relativeLuminance(hexA);
  const l2 = relativeLuminance(hexB);
  const hi = Math.max(l1, l2);
  const lo = Math.min(l1, l2);
  return (hi + 0.05) / (lo + 0.05);
}

describe('visual W11 — Design Guardrails v3.0 & multi-viewport visual inspection gates', () => {
  test('W11.1: 3-layer token discipline — semantic theme blocks reference var(--primitive-*) with 0 raw hex/rgba', () => {
    const lightBlock = stripComments(extractBlock(dsCss, ':root, html[data-theme="light"]'));
    const darkBlock = stripComments(extractBlock(dsCss, 'html[data-theme="dark"]'));
    assert.equal(/#[0-9a-fA-F]{3,8}\b/.test(lightBlock), false, 'light semantic block must not contain raw hex');
    assert.equal(/#[0-9a-fA-F]{3,8}\b/.test(darkBlock), false, 'dark semantic block must not contain raw hex');
    assert.equal(/rgba?\s*\(/i.test(lightBlock), false, 'light semantic block must not contain raw rgb/rgba');
    assert.equal(/rgba?\s*\(/i.test(darkBlock), false, 'dark semantic block must not contain raw rgb/rgba');
    assert.match(darkBlock, /--page:\s*var\(--primitive-dark-page\)/);
    assert.match(darkBlock, /--ink-mute:\s*var\(--primitive-dark-ink-mute\)/);
  });

  test('W11.2: WCAG 2.1 AA contrast — light --ink-mute (#626770) >= 4.5:1 on --page and --surface-1', () => {
    const rootBlock = stripComments(extractBlock(dsCss, ':root {'));
    const muteMatch = rootBlock.match(/--primitive-light-ink-mute:\s*(#[0-9a-fA-F]{6})/);
    const pageMatch = rootBlock.match(/--primitive-light-page:\s*(#[0-9a-fA-F]{6})/);
    const surf1Match = rootBlock.match(/--primitive-light-surface-1:\s*(#[0-9a-fA-F]{6})/);
    assert.ok(muteMatch && pageMatch && surf1Match, 'primitive light tokens must be defined in :root');
    assert.equal(muteMatch[1].toLowerCase(), '#626770');
    const crPage = contrastRatio(muteMatch[1], pageMatch[1]);
    const crSurf1 = contrastRatio(muteMatch[1], surf1Match[1]);
    assert.ok(crPage >= 4.5, `Expected --ink-mute on --page >= 4.5:1, got ${crPage.toFixed(2)}:1`);
    assert.ok(crSurf1 >= 4.5, `Expected --ink-mute on --surface-1 >= 4.5:1, got ${crSurf1.toFixed(2)}:1`);
  });

  test('W11.3: Global 4px structural grid, closed radius scale, and >= 48px mobile action targets', () => {
    assert.equal(guardrailsCfg.archetype.spacing_base, 4);
    assert.equal(guardrailsCfg.archetype.mode, 'both');
    assert.match(dsCss, /--space-xs:\s*4px;/);
    assert.match(dsCss, /--space-md:\s*8px;/);
    assert.match(dsCss, /--radius-sm:\s*4px;/);
    assert.match(dsCss, /--radius-md:\s*8px;/);
    assert.match(dsCss, /--radius-card:\s*12px;/);
    assert.match(dsCss, /--radius-xl:\s*16px;/);
    assert.match(shellCss, /\.mobile-action-bar\s+\.btn[\s\S]*?min-height:\s*48px/);
  });

  test('W11.4: Typography wrapping, @media (hover: hover), :disabled/:active states, and 100dvh viewport caps', () => {
    assert.match(dsCss, /text-wrap:\s*balance/);
    assert.match(dsCss, /text-wrap:\s*pretty/);
    assert.match(shellCss, /@media\s*\(hover:\s*hover\)/);
    assert.match(shellCss, /\.ticon:active\s*\{/);
    assert.match(shellCss, /\.ticon:disabled\s*\{[\s\S]*?background:\s*var\(--surface-1\)/);
    assert.match(shellCss, /100dvh/);
    assert.match(shellCss, /82dvh/);
  });

  test('W11.5: Multi-viewport visual inspection fixes — in-flow .rich-composer pill & unified #sheet-body labels', () => {
    const composerBlock = extractBlock(dsCss, '.rich-composer');
    assert.match(composerBlock, /position:\s*relative/);
    assert.match(composerBlock, /display:\s*inline-flex/);
    assert.match(composerBlock, /align-self:\s*center/);
    assert.match(composerBlock, /width:\s*fit-content/);
    assert.equal(/position:\s*absolute/.test(composerBlock), false, '.rich-composer must not overlap rich-editor text via position:absolute');

    assert.match(dsCss, /#sheet-body\s+#add-box-btn\s+\.btn-long\s*\{\s*display:\s*inline/);
    assert.match(designMd, /Rich-Composer In-Flow Pill/);
  });
});
