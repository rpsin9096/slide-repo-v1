import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

/* Config accordion close fix: `.hidden` (display:none) applied same-frame as
 * the 0fr target kills the collapse transition — close snaps. Two-phase:
 * `.is-closing` carries the collapsed grid state WITHOUT display:none so the
 * 1fr->0fr transition runs; JS adds `.hidden` after the drawer duration.
 * Run: node --test tests/lean/visual-w6-config-collapse.lean.js */

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..');
const ds = () => readFileSync(join(root, 'static', 'design-system.css'), 'utf8');
const app = () => readFileSync(join(root, 'static', 'v2-app.js'), 'utf8');

const blockOf = (css, selector) => {
  const esc = selector.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const m = new RegExp('(^|\\n)[ \\t]*' + esc + ' \\{', 'm').exec(css);
  assert.ok(m, `missing rule: ${selector}`);
  const open = css.indexOf('{', m.index);
  const close = css.indexOf('}', open);
  return css.slice(open + 1, close);
};

describe('visual W6 — config accordion collapse actually animates', () => {
  it('closing state collapses grid + fades without display:none', () => {
    const b = blockOf(ds(), '.config-body.is-closing');
    assert.ok(b.includes('grid-template-rows: 0fr'), `expected 0fr, got: ${b.trim()}`);
    assert.ok(b.includes('opacity: 0'), `expected fade, got: ${b.trim()}`);
    assert.ok(!b.includes('display'), `must not hide (transition would die), got: ${b.trim()}`);
  });

  it('JS drives the two-phase close (is-closing then hidden)', () => {
    const js = app();
    assert.ok(js.includes('is-closing'), 'v2-app.js must drive .is-closing');
    assert.ok(js.includes('_configCloseT'), 'pending close must be cancellable on re-open');
  });

  it('guards: open state + hidden end-state unchanged', () => {
    const open = blockOf(ds(), '.config-body');
    assert.ok(open.includes('grid-template-rows: 1fr'), `expected 1fr open, got: ${open.trim()}`);
    const end = blockOf(ds(), '.config-body.hidden');
    assert.ok(end.includes('grid-template-rows: 0fr'), `expected 0fr end, got: ${end.trim()}`);
  });
});
