import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

/* D5 insert unification: one "+" idiom + one shared portal menu
 * (BlockEditor.openPortalMenu + INSERT_ITEMS) across Markdown and Rich.
 * The markdown pill strip (edge arrow / side collapse / data-mi pills) is
 * retired; picking inserts the snippet at the caret.
 * Supersedes W7/W8 (they gated the removed strip mechanism).
 * Run: node --test tests/lean/visual-w9-insert-unified.lean.js */

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..');
const src = () => readFileSync(join(root, 'static', 'v2-app.js'), 'utf8');
const ds = () => readFileSync(join(root, 'static', 'design-system.css'), 'utf8');

describe('visual W9 — single insert idiom across modes', () => {
  it('pill strip retired from the markdown bind', () => {
    const js = src();
    assert.ok(!js.includes('md-insert-edge'), 'edge arrow gone');
    assert.ok(!js.includes('md-insert-side'), 'side collapse gone');
    assert.ok(!js.includes('data-mi='), 'per-pill buttons gone');
  });

  it('markdown insert opens the shared portal menu from the catalog', () => {
    const js = src();
    assert.ok(js.includes('openPortalMenu'), 'shared menu drives markdown insert');
    assert.ok(js.includes('bedit-plus-btn'), 'markdown entry is the shared + button');
    assert.ok(js.includes('insertSnippetFor'), 'picks resolve through the snippet seam');
  });

  it('G5 guards: portal menu stays viewport-clamped, no trailing gutter', () => {
    const css = ds();
    assert.ok(css.includes('min(320px'), 'menu min clamps to viewport');
    assert.ok(css.includes('repeat(2, minmax(96px, 1fr))'), '360px two-column fallback kept');
    assert.ok(css.includes('.bedit-gutter.is-trailing'), 'no-trailing-gutter invariant kept');
    assert.ok(src().includes('INSERT_ITEMS'), 'unified catalog still drives menus');
  });
});
