import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

/* Wave 3 — Mobile 375px + token lock (VISUAL-PROD-SPEC G3/G4).
 * CSS-invariant gates over sheets, bubble, scrim, bottom-bar only.
 * Editor-internals bubble twins (.bedit-/.md-float-) are out of scope (spec §8).
 * Run: node --test tests/lean/visual-w3-mobile-tokens.lean.js */

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..');
const ds = readFileSync(join(root, 'static', 'design-system.css'), 'utf8');
const shell = readFileSync(join(root, 'static', 'shell.css'), 'utf8');

/* Collect EVERY exact-selector block (".sel {" at line start, not descendants). */
const blocksOf = (css, selector) => {
  const out = [];
  let from = 0;
  while (true) {
    const i = css.indexOf('\n' + selector + ' {', from);
    if (i === -1) break;
    const open = css.indexOf('{', i);
    out.push(css.slice(open + 1, css.indexOf('}', open)));
    from = open + 1;
  }
  assert.ok(out.length > 0, `missing rule: ${selector}`);
  return out;
};

describe('visual W3 RED — mobile sheets + token lock', () => {
  it('G3: sheet scrims resolve through var(--color-backdrop)', () => {
    for (const b of blocksOf(ds, '.sheet-backdrop')) {
      assert.ok(b.includes('var(--color-backdrop)'), `expected var(--color-backdrop), got: ${b.trim()}`);
      assert.ok(!b.includes('rgba('), `no hardcoded rgba in .sheet-backdrop, got: ${b.trim()}`);
    }
  });

  it('G3: selection bubble is token-only (no hex, no rgba)', () => {
    for (const [css, name] of [[ds, 'design-system.css'], [shell, 'shell.css']]) {
      const b = blocksOf(css, '.m-bubble')[0];
      assert.ok(!b.match(/#[0-9a-fA-F]{3,6}/), `no hex in ${name} .m-bubble, got: ${b.trim()}`);
      assert.ok(!b.includes('rgba('), `no rgba in ${name} .m-bubble, got: ${b.trim()}`);
      assert.ok(b.includes('var(--'), `${name} .m-bubble must use var(--*) tokens`);
    }
  });

  it('G3: drawer scrim resolves through var(--color-backdrop)', () => {
    const b = blocksOf(shell, '.drawer-scrim')[0];
    assert.ok(b.includes('var(--color-backdrop)'), `expected var(--color-backdrop), got: ${b.trim()}`);
    assert.ok(!b.includes('rgba('), `no hardcoded rgba in .drawer-scrim, got: ${b.trim()}`);
  });

  it('G4: bottom-bar buttons stay single-line', () => {
    const dsBtn = blocksOf(ds, '.m-bottom-bar .btn')[0];
    const shBtn = blocksOf(shell, '.mobile-action-bar .btn')[0];
    assert.ok(dsBtn.includes('white-space: nowrap'), `.m-bottom-bar .btn must be single-line, got: ${dsBtn.trim()}`);
    assert.ok(shBtn.includes('white-space: nowrap'), `.mobile-action-bar .btn must be single-line, got: ${shBtn.trim()}`);
  });
});
