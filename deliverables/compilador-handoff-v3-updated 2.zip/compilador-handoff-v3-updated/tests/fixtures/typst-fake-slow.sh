#!/bin/sh
# Test fake for TYPST_BIN: hangs so the compile timeout can fire.
sleep 30
