#!/bin/sh
# Test fake for TYPST_BIN: pretends `typst compile <src> <pdf>` succeeded by
# copying source bytes to the output path (content is irrelevant to the seam).
cp "$2" "$3"
