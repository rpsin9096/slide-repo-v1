# Sistema nervoso central:

## Doença cerebrovascular encefálica:

### Diagnóstico por imagem e semiologia tomográfica:
- **Tomografia computadorizada de crânio**: Apresenta três planos de visualização espacial ortogonal.
  - **Planos de corte**:
    - **Corte axial**: Define o corte de escolha prioritário para avaliação de acidente vascular cerebral.
    - **Corte coronal**: Complementa a avaliação estrutural craniocaudal.
    - **Corte sagital**: Permite a visualização anatômica anteroposterior e de linha média.
  - **Diferenciação de densidades tomográficas**:
    - **Hiperdensidade**: Apresenta tonalidade branca brilhante ao corte tomográfico.
    - **Hipodensidade**: Apresenta tonalidade escura ou negra ao corte tomográfico.
    - **Isodensidade**: Corresponde à atenuação radiológica basal do parênquima encefálico sadio.

### Acidente vascular cerebral isquêmico:
- **Isquemia cerebral aguda**:
  - **Classificação**: É um evento cerebrovascular focal decorrente de oclusão arterial encefálica súbita.
  - **Topografia vascular prevalente**:
    - **Artéria cerebral média**: Constitui o vaso arterial encefálico mais frequentemente acometido.
  - **Fisiopatologia**: Oclusão arterial aguda → redução do fluxo sanguíneo regional → formação de área central necrótica e penumbra isquêmica.
    - **Zona de penumbra**: Tecido hipoperfundido circundante potencialmente resgatável por reperfusão precoce.
    - **Efeito de massa**: Edema citotóxico volumoso comprime estruturas adjacentes → eleva a pressão intracraniana → causa desvio de linha média.
  - **Manifestação clínica**: Instala sinais neurológicos focais deficitários súbitos contralateralmente ao hemisfério lesionado.
    - **Cefaleia**: Manifesta-se com baixa intensidade ou ausência de dor em comparação a quadros hemorrágicos.
  - **Tratamento**:
    - **Alteplase**: Atua como agente trombolítico de escolha primária na fase hiperaguda.
      - *Umbral*: Se respeitada a janela terapêutica temporal estrita, administre Alteplase endovenosa.
      - *Parâmetro*: Proíbe o uso de abreviações na prescrição médica formal.

### Acidente vascular cerebral hemorrágico intraparenquimatoso:
- **Hemorragia intraparenquimatosa**:
  - **Classificação**: É um extravasamento hemático espontâneo e localizado diretamente no parênquima encefálico.
  - **Achado tomográfico**: Revela lesão expansiva hiperdensa aguda intra-axial com eventual efeito de massa compressivo.
  - **Manifestação clínica**: Apresenta início súbito de déficits focais associado a cefaleia e rebaixamento progressivo do nível de consciência.
    - **Lateralização**: Déficits motores e sensitivos expressam-se no hemicorpo oposto ao hemisfério acometido.
  - **Tratamento**:
    - **Ácido tranexâmico**: Promove hemostasia antifibrinolítica sem dependência estrita de janela terapêutica descrita.
    - **Posicionamento cefálico**: Mantenha a cabeceira elevada a 30 graus para otimizar a drenagem venosa craniana.
  - **Contraindicação**:
    - **Umbral**: Se pressão arterial sistólica ≥ 220 mmHg ou diastólica ≥ 110 mmHg, constitui contraindicação absoluta a trombolíticos.

### Hemorragia subaracnóidea:
- **Sangramento subaracnóideo**:
  - **Classificação**: É o extravasamento hemático agudo no espaço preenchido por líquido cefalorraquidiano.
  - **Sinal patognomônico tomográfico**:
    - **Analogia da fonte**: "Estrela da morte" desenhada pela hiperdensidade hemática nas cisternas da base.
  - **Quadro clínico característico**: Desencadeia cefaleia hiperaguda de intensidade máxima, referida pelo paciente como a pior da vida.
  - **Sinais de irritação meníngea**:
    - **Rigidez de nuca**: A resistência passiva à flexão cervical indica presença de sangue no espaço meníngeo.
    - **Sinal de Kernig**: A extensão passiva do joelho com o quadril flexionado reproduz dor e resistência lombar.
    - **Sinal de Brudzinski**: A flexão cervical involuntariamente induz flexão reflexa dos quadris e joelhos.
  - **Controle hemodinâmico**: Se pressão arterial apresentar níveis críticos, reduza os valores pressóricos com extrema lentidão e vigilância.
  - **Procedimento invasivo**:
    - **Ausente**: Punção lombar inadvertida na vigência de hipertensão intracraniana ou suspeita de herniação.

| Condição cerebrovascular | Densidade tomográfica típica | Apresentação da cefaleia | Sinais meníngeos | Conduta inicial prioritária |
| :--- | :--- | :--- | :--- | :--- |
| AVC isquêmico | Hipodensa com penumbra | Discreta ou ausente | Ausentes | Reperfusão com Alteplase em janela |
| AVC hemorrágico intraparenquimatoso | Hiperdensa intraparenquimatosa | Moderada a intensa súbita | Raros na fase inicial | Cabeceira elevada e Ácido tranexâmico |
| Hemorragia subaracnóidea | Hiperdensa em cisternas basais | Excruciante e hiperaguda | Presentes (Kernig e Brudzinski) | Redução cautelosa da PA e monitorização |

# Sistema respiratório:

## Afecções parenquimatosas e pleurais:

### Princípios de imagem e anatomia funcional:
- **Anatomia segmentar pulmonar**:
  - **Eixo broncovascular**: Cada bronquíolo ramifica-se acompanhado estritamente por um ramo arterial satélite.
  - **Tomografia de tórax**: O corte axial fornece a resolução espacial padrão para mapeamento de infiltrados e consolidações alveolares.

### Pneumonia bacteriana típica:
- **Consolidação bacteriana clássica**:
  - **Fisiopatologia**: Inalação de patógeno bacteriano → reação inflamatória alveolar → acúmulo de exsudato purulento nos ácinos.
  - **Semiologia respiratória**:
    - **Inspeção e palpação**: Reduz a mobilidade torácica regional e eleva expressivamente o frêmito toracovocal.
    - **Tosse e secreção**: Provoca tosse produtiva acompanhada de expectoração mucopurulenta profusa.
  - **Critério diagnóstico radiológico**: Revela consolidação alveolar com preservação de broncogramas aéreos patentes no interior da opacidade.
  - **Tratamento empírico**:
    - **Paciente hígido**: Se ausência de comorbidades prévias, prescreva monoterapia com betalactâmico (Amoxicilina oral).
    - **Paciente com comorbidades**: Se paciente não hígido, administre Amoxicilina com Clavulanato ou Ampicilina com Sulbactam.

### Pneumonia atípica:
- **Infecção por patógenos atípicos**:
  - **Classificação**: É um processo infeccioso parenquimatoso causado por germes intracelulares ou desprovidos de parede celular típica.
  - **Etiologia prevalente**: *Mycoplasma pneumoniae* e *Chlamydia pneumoniae*.
  - **População vulnerável**: Acomete predominantemente crianças, adolescentes e indivíduos jovens sadios.
  - **Tratamento**:
    - **Azitromicina**: Erradica patógenos atípicos por inibição da síntese proteica ribossomal bacteriana.

### Abscesso pulmonar:
- **Infecção necrosante pulmonar**:
  - **Mecanismo**: Necrose de liquefação do parênquima pulmonar → evacuação parcial do conteúdo liquefeito → formação de nível hidroaéreo intracavitário.
  - **Critério diagnóstico**: Identifica lesão cavitária arredondada contendo linha reta horizontal divisória entre ar e fluido purulento.

### Edema agudo de pulmão:
- **Congestão hidrostática alveolar**:
  - **Mecanismo**: Aumento da pressão capilar pulmonar → transudação de fluido transalveolar bilateral → ocupação perivascular e alveolar difusa.
  - **Sinal radiológico**:
    - **Analogia da fonte**: Infiltrado alveolar bilateral difuso em "asas de borboleta" (ou asas de mariposa).
  - **Pertinente negativo**:
    - **Ausente**: Broncograma aéreo típico de consolidação lobar lobulada focal.

### Derrame pleural:
- **Acúmulo de líquido no espaço pleural**:
  - **Classificação**: É a retenção patológica de transudato ou exsudato livre na cavidade entre as pleuras parietal e visceral.
  - **Etiologia primária**: Ocorre mais comumente como complicação direta de infecção parenquimatosa subjacente (derrame parapneumônico).
  - **Sinais semiológicos clássicos**:
    - **Ausculta respiratória**: Abolição completa dos murmúrios vesiculares nas regiões declives do hemitórax afetado.
    - **Palpação torácica**: Determina desaparecimento ou abolição do frêmito toracovocal sobre a projeção do derrame fluido.
  - **Critérios diagnósticos radiológicos**:
    - **Velamento**: Provoca apagamento e obliteração angular do seio costofrênico.
    - **Sinal do menisco**: Demonstra linha demarcatória côncava clássica caracterizada como curva parabólica de Damoiseau.
    - **Mobilidade**: Mostra redistribuição do líquido livre pleural em decúbitos radiológicos alternados.
    - **Distribuição anatômica**: Manifesta-se em padrões unilaterais ou bilaterais difusos.
  - **Pertinente negativo**:
    - **Ausente**: Broncogramas aéreos no interior da zona homogênea correspondente ao fluido livre.

| Entidade pulmonar | Padrão radiológico pulmonar | Frêmito toracovocal | Murmúrio vesicular | Presença de broncograma aéreo |
| :--- | :--- | :--- | :--- | :--- |
| Pneumonia típica | Consolidação alveolar localizada | Aumentado | Ruídos adventícios e estertores | Presente |
| Edema agudo de pulmão | Infiltrado bilateral em asas de borboleta | Preservado ou variável | Estertores crepitantes basais | Ausente |
| Derrame pleural | Obliteramento de seio e curva de Damoiseau | Abolido | Abolido na base afetada | Ausente |