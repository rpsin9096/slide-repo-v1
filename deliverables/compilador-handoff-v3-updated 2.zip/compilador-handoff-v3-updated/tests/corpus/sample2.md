# Patologia geral e fisiopatologia sistêmica:

## Princípios fundamentais da doença:

### Conceitos básicos e epidemiologia:
- **Fisiopatologia**: Integra fisiologia alterada e patologia para explicar a homeostase comprometida.
  - **Alcance científico**:
    - **Análise estrutural e funcional**: Avalia alterações em células, tecidos e órgãos causadores de doença.
    - **Mecanismos subjacentes**: Fornece dados biológicos para planejar medidas preventivas e terapêuticas.
- **Epidemiologia**: Estuda a ocorrência e distribuição de doenças em populações humanas.
  - **Evolução histórica**: Transita do controle de infecções epidêmicas para fatores de risco multifatoriais.
  - **Áreas de aplicação**:
    - **Neoplasia**: Investiga gênese e distribuição de neoplasias malignas.
    - **Cardiopatia**: Analisa determinantes populacionais da doença cardiovascular.
- **Processo patológico**:
  - **Etiologia**: Descreve o fator causador deflagrador da enfermidade.
  - **Patogênese**: Explica a evolução temporal da lesão tecidual.
  - **Fisiopatologia**: Contato etiológico → Alterações celulares → Alterações teciduais → Expressão clínica.

### Manifestações e curso clínico:
- **Manifestações clínicas**: Expressam o fenótipo funcional do processo mórbido.
  - **Formas de apresentação**:
    - **Manifestação direta**: Apresenta sinais mensuráveis imediatos como febre.
    - **Doença silenciosa**: Detecta lesões em fases avançadas ou exames rotineiros.
  - **Taxonomia semiológica**:
    - **Sintoma**: Desconforto subjetivo percebido exclusivamente pelo paciente.
    - **Sinal**: Manifestação objetiva verificada clinicamente pelo examinador.
    - **Síndrome**: Conjunto de sinais e sintomas característicos de determinado estado.
    - **Complicação**: Desfecho adverso originado de doença ou intervenção médica.
    - **Sequela**: Lesão residual provocada diretamente por enfermidade prévia resolvida.
- **Curso clínico**: Registra a evolução temporal da enfermidade orgânica.
  - **Padrão temporal**:
    - **Curso agudo**: Processo grave com caráter patológico autolimitado.
    - **Curso subagudo**: Intensidade e duração intermediárias entre agudo e crônico.
    - **Curso crônico**: Processo contínuo ou periódico de longa duração.
  - **Estádio evolutivo**:
    - **Estádio pré-clínico**: Lesão instalada sem sintomas, com evolução mandatória para doença clínica.
    - **Estádio subclínico**: Alteração biológica presente sem manifestação clínica ou progressão obrigatória.
    - **Estádio clínico**: Presença manifesta de sinais objetivos e sintomas subjetivos.
  - **Estado de portador**: Hospedeiro alberga agente patogênico ativamente sem exteriorizar sinais.

## Adaptação celular e lesão tecidual:

### Modalidades de adaptação celular:
- **Adaptação celular**: Preserva a viabilidade celular contra variações do estresse biológico.
  - **Mecanismo**: Altera tamanho, número ou fenótipo metabólico celular.
  - **Sinalização molecular**: Mensageiros autócrinos e parácrinos → Modificação da expressão gênica adaptativa.
    - **Genes constitutivos**: Mantêm funções vitais basais durante a sobrecarga tecidual.
    - **Genes de diferenciação**: Modificam características fenotípicas especializadas celulares.
  - **Cessação do estímulo**: Retirada da noxa → Normalização de genes de diferenciação → Reversão ao fenótipo basal.
- **Atrofia**: Reduz o tamanho celular com menor nível funcional compatível com sobrevida.
  - **Fisiopatologia**:
    - **Vetor metabólico**: Redução do trabalho funcional → Queda do consumo de oxigênio → Redução da síntese proteica.
    - **Vetor estrutural**: Queda mitocondrial → Perda de miofilamentos → Redução do retículo endoplasmático.
  - **Etiologia**:
    - **Desuso tecidual**: Redução prolongada das demandas de trabalho funcional.
    - **Desnervação motora**: Perda de estimulação nervosa eferente muscular.
    - **Privação endócrina**: Supressão de estímulo trófico dependente de hormônios.
    - **Desnutrição calórico-proteica**: Aporte metabólico e nutricional insuficiente.
    - **Isquemia tecidual**: Redução crônica do fluxo sanguíneo vascular.
- **Hipertrofia**: Aumenta o volume celular com expansão da massa funcional tecidual.
  - **Mecanismo**: Sobrecarga crônica de trabalho e tensão mecânica tecidual.
  - **Tecidos-alvo**: Miocárdio e músculo esquelético por incapacidade proliferativa mitótica.
  - **Classificação**:
    - **Hipertrofia fisiológica**: Sobrecarga funcional esquelética decorrente de treinamento físico.
    - **Hipertrofia patológica adaptativa**: Espessamento parietal vesical por obstrução ou miocárdico por hipertensão sistêmica.
    - **Hipertrofia patológica compensatória**: Expansão celular do parênquima renal remanescente pós-nefrectomia unilateral.
- **Hiperplasia**: Eleva o número absoluto de células em órgão ou parênquima.
  - **Requisito biológico**: Tecidos com capacidade proliferativa conservada como epiderme, epitélio intestinal e estroma glandular.
  - **Classificação**:
    - **Hiperplasia fisiológica hormonal**: Expansão do epitélio mamário e miométrio uterino na gestação mediada por estrogênio.
    - **Hiperplasia fisiológica compensatória**: Regeneração parenquimatosa do lobo hepático remanescente pós-hepatectomia parcial.
    - **Hiperplasia patológica**: Estímulo hormonal descontrolado ou hipersecreção autônoma de fatores tróficos teciduais.
  - **Coexistência celular**: Útero gravídico desenvolve hipertrofia e hiperplasia sincrônicas sob influxo estrogênico.
- **Metaplasia**: Substitui de forma reversível linhagem celular adulta diferenciada por outro tipo fenotípico.
  - **Mecanismo**: Reprogramação adaptativa de células-tronco contra agentes irritativos persistentes.
  - **Fenótipo respiratório**: Substituição de epitélio respiratório cilíndrico por epitélio estratificado pavimentoso no tabagismo.
  - **Esôfago de Barrett**: Substitui epitélio escamoso esofágico estratificado por epitélio colunar intestinal mucossecretor.
    - **Quadro clínico**: Apresenta latência clínica inicial assintomática.
    - **Sintomas de refluxo**: Induz pirose retroesternal, regurgitação ácida gástrica e disgeusia amarga.
    - **Sinais de alarme**: Disfagia mecânica progressiva, odinofagia e hematêmese exigem endoscopia diagnóstica urgente.
    - **Complicação**:
      - **Adenocarcinoma esofágico**: Progride a partir do acúmulo de displasias atípicas no epitélio metaplásico.
      - **Acalasia secundária**: Instala-se após desorganização estrutural progressiva da musculatura cárdica.
    - **Classificação de Praga**:
      - *Critério C*: Mede extensão circunferencial contínua da metaplasia a partir do topo das pregas gástricas.
      - *Critério M*: Mensura extensão longitudinal máxima da lingueta metaplásica esofágica.
- **Displasia**: Proliferação desordenada com perda da arquitetura tecidual, atipias nucleares e polimorfismo.
  - **Mecanismo**: Irritação química continuada ou inflamação tecidual crônica sustentada.
  - **Pronóstico**: Reverte completamente com cessação do agente irritativo ou progride para carcinoma in situ e invasor.
- **Acúmulos intracelulares**: Retêm metabólitos normais ou pigmentos anômalos no citoplasma por depuração insuficiente.

### Calcificações patológicas:
- **Calcificação patológica**: Deposita sais minerais compostos de cálcio, ferro e magnésio em tecidos moles.
- **Calcificação distrófica**:
  - **Substrato tecidual**: Depósito mineral focal restrito a tecidos necróticos ou em degeneração.
  - **Fisiopatologia**: Ruptura celular → Liberação de fosfolipídios de membrana → Ligação a íons cálcio → Formação de fosfato de cálcio.
  - **Morfologia**: Apresenta desde grânulos arenosos finos até blocos pétreos rígidos intratissulares.
  - **Origem dos componentes**: Fosfolipídios de membranas degradadas, cálcio circulante e fluido intersticial.
  - *Calcemia sérica*: Normal.
- **Calcificação metastática**:
  - **Substrato tecidual**: Depósito mineral difuso secundário em tecidos viáveis previamente sadios.
  - **Sítios preferenciais**: Instala-se em septos alveolares pulmonares, túbulos renais e túnica média vascular sistêmica.
  - **Etiologia**: Hiperparatireoidismo primário, intoxicação exógena por vitamina D, retenção renal de fosfato e osteólise neoplásica maciça.
  - *Calcemia sérica*: Hipercalcemia sustentada.

### Mecanismos de lesão celular:
- **Determinantes de lesão**: Gravidade do insulto, tempo de exposição, aporte vascular, reserva metabólica e capacidade proliferativa.
- **Vias etiopatogênicas universais**:
  - **Radicais livres**: Gera espécies químicas instáveis dotadas de elétron desemparelhado na órbita externa.
    - **Patogênese molecular**: Peroxida lipídios de membrana celular e fragmenta fitas de DNA genômico.
    - **Vetor de propagação**: Lesão oxidativa primária → Geração de novos radicais livres → Reação autocatalítica em cadeia de milhares de passos.
  - **Estresse hipóxico**: Interrompe o aporte tecidual de oxigênio celular.
    - **Fisiopatologia**: Hipóxia tecidual → Cessação da fosforilação oxidativa mitocondrial → Depleção crítica de trifosfato de adenosina.
    - **Fatores de irreversibilidade**: Depende do tempo de anóxia, consumo basal de glicose e atividade metabólica intrínseca.
  - **Homeostase do cálcio**: Aumento anômalo do cálcio citosólico livre ativa fosfolipases, proteases, ATPases e endonucleases líticas.
- **Padrões de necrose tecidual**:
  - **Necrose por liquefação**: Conserva enzimas hidrolíticas ativas que digerem e convertem o tecido morto em massa líquida viscosa.
  - **Necrose coagulativa**: Desnaturação por acidose bloqueia proteólise enzimática, preservando o arcabouço estrutural tecidual básico por dias.
  - **Necrose caseosa**: Converte o parênquima necrótico em massa esbranquiçada friável semelhante a queijo sem lise enzimática imediata.

### Agentes físicos e químicos de lesão:
- **Temperaturas extremas**: Destroem organelas celulares e sistemas enzimáticos por congelamento tecidual ou hipertermia destrutiva.
  - **Calor de baixa intensidade**:
    - *Faixa térmica*: 43 °C a 46 °C.
    - **Manifestação**: Queimaduras dérmicas de espessura parcial e síndrome de insolação sistêmica.
    - **Mecanismo**: Provoca lesão microvascular focal, acelera reações metabólicas, inativa enzimas termossensíveis e desestabiliza membranas celulares.
- **Lesão por eletricidade**: Converte energia elétrica em térmica destrutiva e desorganiza potenciais miocárdicos e neurológicos.
  - **Determinantes**: Depende de voltagem aplicada, amperagem, corrente contínua versus alternada, resistência ôhmica, trajeto anatômico e tempo.
- **Radiação ionizante**: Arranca elétrons orbitais atômicos, rompe ligações do ácido desoxirribonucleico e gera radicais hidroxila livres.
  - **Efeitos agudos**: Bloqueia mitoses nucleares, causa lise celular imediata e fixa mutações cromossômicas permanentes.
  - **Suscetibilidade biológica**:
    - **Tecidos vulneráveis**: Células hematopoéticas medulares e criptas epiteliais gastrointestinais por alta taxa proliferativa.
    - **Tecidos resistentes**: Tecido ósseo mineralizado e músculo estriado esquelético por baixa reposição mitótica.
  - **Efeitos crônicos**: Provoca fibrose intersticial pulmonar e miocárdica, radiodermite atrófica esclerótica e defeitos de cicatrização.
  - **Neoplasias secundárias induzidas**: Origina carcinomas cutâneos, leucemias agudas, osteossarcomas e neoplasias malignas brônquicas.
- **Saturnismo**: Intoxicação ocupacional ou acidental sistêmica grave por exposição inalatória ou digestiva a chumbo.
  - **Alvos orgânicos**: Provoca encefalopatia crônica, neuropatia motora periférica desmielinizante e anemia por inibição enzimática heme.
  - **Sinal clínico patognomônico**: Forma pigmentação acinzentada linear do ribete gengival de Burton na borda alveolar dentária.

## Inflamação e reparo tecidual:

### Sinais cardinais e cinética inflamatória:
- **Inflamação**: Reação protetora de tecidos conjuntivos vascularizados contra patógenos invasores e restos de necrose tecidual.
  - **Nomenclatura**: Agrega o sufixo -ite à estrutura anatômica acometida pelo processo reativo.
    - **Pericardite**: Inflamação exsudativa do saco pericárdico.
    - **Neurite**: Inflamação estrutural de troncos nervosos periféricos.
    - **Apendicite**: Processo inflamatório agudo obstrutivo do apêndice cecal.
  - **Tétrade de Celso**:
    - **Calor**: Vasodilatação arteriolar com aumento do aporte do fluxo sanguíneo quente local.
    - **Rubor**: Eritema inflamatório originado por hiperemia vascular ativa contínua.
    - **Tumor**: Aumento volumétrico tecidual derivado de exsudato rico em proteínas e infiltrado celular.
    - **Dor**: Estimulação direta de nociceptores por bradicinina, prostaglandinas e estiramento tecidual.
  - **Pêntada de Galeno**: Adiciona perda funcional tecidual transitória ou definitiva aos quatro sinais cardinais de Celso.
- **Inflamação aguda**: Resposta biológica primária imediata com trânsito de leucócitos e macromoléculas aos focos de agressão.
  - **Componentes teciduais**: Envolve células endoteliais, leucócitos circulantes, fibroblastos estromais, mastócitos e matriz extracelular.
  - **Fase vascular**:
    - **Leito vascular**: Restringe-se a arteríolas terminais, redes capilares e vênulas pós-capilares.
    - **Fisiopatologia**: Agressão tecidual → Vasoconstrição arteriolar neurogênica transitória → Vasodilatação arteriolar duradoura → Abertura microvascular capilar → Aumento da pressão hidrostática intravascular → Hiperpermeabilidade endotelial venular → Extravasamento de exsudato plasmático proteináceo para o interstício.
    - **Endotélio microvascular**: Monocamada com permeabilidade estritamente regulada entre o sangue e tecidos vizinhos.
      - **Reparação tecidual**: Sintetiza fatores de crescimento reguladores da angiogênese e síntese de matriz colágena.
      - **Marcador fisiopatológico**: Exibe lesão endotelial imune e disfunção celular ativa no lúpus eritematoso sistêmico.
  - **Fase celular**:
    - **Cinética transendotelial**: Marginação leucocitária parietal → Rolamento e adesão endotelial firme → Diapedese interendotelial → Quimiotaxia dirigida por gradiente químico → Ativação microbicida e fagocitose.
    - **Fagocitose ativa**:
      - **Populações efetoras**: Neutrófilos polimorfonucleares, monócitos circulantes e macrófagos teciduais maduros.
      - **Mecanismo**: Reconhecimento e ligação de receptores a opsoninas → Engolfamento citoplasmático com formação do fagossomo → Fusão com lisossomos citoplasmáticos → Degradação enzimática intracelular.

### Mediadores químicos da inflamação:
- **Mediadores derivados do plasma**: Fígado sintetiza precursores inativos ativados em cascata enzimática no compartimento intravascular.
  - **Proteínas de fase aguda**: Elevam o ponto térmico hipotalâmico e orquestram a resposta sistêmica inflamatória.
  - **Fator XII de Hageman**: Ativa conjuntamente a cascata de coagulação, o sistema fibrinolítico e a via das cininas formadora de bradicinina.
  - **Sistema complemento**: Cliva componentes plasmáticos para executar opsonização bacteriana, quimiotaxia neutrofílica e lise por complexo de ataque à membrana.
- **Mediadores celulares**:
  - **Mediadores pré-formados**:
    - **Histamina**: Mastócitos perivasculares e basófilos desgranulam conteúdo sob trauma físico ou fixação de IgE.
      - **Ação vascular**: Estimula receptores H1 para induzir vasodilatação arteriolar rápida e abertura transitória de junções venulares.
    - **Serotonina**: Grânulos densos plaquetários secretam mediador vasoativo durante o processo de agregação hemostática.
    - **Enzimas lisossômicas**: Neutrófilos e macrófagos secretam proteases neutras teciduais e hidrolases ácidas nos focos exsudativos.
  - **Mediadores sintetizados de novo**:
    - **Metabólitos do ácido araquidônico**: Fosfolipase A2 cliva lipídios estruturais da membrana celular disponibilizando substrato.
      - **Via cicloxigenase**: Sintetiza prostaglandinas pró-inflamatórias térmicas, prostaciclina antiagregante vasodilatadora e tromboxano A2 pró-agregante.
      - **Via lipoxigenase**: Metaboliza lipídios em leucotrienos mediadores de broncoespasmo, quimiotaxia e hiperpermeabilidade microvascular.
      - **Inibição farmacológica**: Anti-inflamatórios não esteroides e ácido acetilsalicílico bloqueiam a catálise enzimática da cicloxigenase.
    - **Fator ativador de plaquetas**: Leucócitos e mastócitos produzem mediador fosfolipídico bioativo indutor de inflamação e adesão celular.
    - **Espécies reativas e óxido nítrico**: Macrófagos ativados geram espécies bactericidas de oxigênio e óxido nítrico relaxante vascular.
    - **Citocinas pró-inflamatórias**: Macrófagos, linfócitos e células endoteliais ativadas secretam fator de necrose tumoral alfa regulador da pirose e caquexia.

### Manifestações locais e exsudatos:
- **Tipos de exsudato inflamatório**:
  - **Exsudato hemorrágico**: Apresenta extravasamento maciço de eritrócitos íntegros por fratura da integridade vascular microcirculatória.
  - **Exsudato purulento**: Contém restos celulares necróticos liquefeitos, neutrófilos senescentes e proteínas coaguladas sob infecção piogênica estafilocócica.
  - **Abscesso**: Coleção líquida purulenta circunscrita circundada por infiltrado de neutrófilos preservados e cápsula colágena periférica.
  - **Úlcera**: Erosão tecidual escavada em superfícies cutaneomucosas decorrente do desprendimento em bloco de parênquima necrótico.
  - **Edema inflamatório**: Acúmulo de fluido rico em albumina no interstício cutâneo, alvéolos pulmonares ou matriz extracelular cerebral.

### Diagnóstico diferencial dos padrões inflamatórios e fluidos:

| Atributo | Inflamação aguda | Inflamação crônica | Limiar discriminador |
|---|---|---|---|
| Tempo de início | Resposta precoce imediata frente à agressão | Resposta tardia insidiosa | Imediatismo de segundos a minutos |
| Duração do processo | Minutos a vários dias, limites de 6 a 24 horas | Semanas, meses ou anos | Limite temporal estrito de 15 dias |
| Infiltrado celular predominante | Predomínio de neutrófilos extravasados | Infiltração de linfócitos e macrófagos | Linhagem polimorfonuclear versus mononuclear |
| Padrão vascular e tecidual | Vasodilatação arteriolar e exsudato rico em fibrina | Proliferação vascular, necrose e fibrose | Ausência de proliferação fibrovascular na fase aguda |

| Atributo | Exsudato | Transudato | Limiar discriminador |
|---|---|---|---|
| Etiopatogenia fundamental | Aumento da permeabilidade microvascular por mediadores | Aumento da pressão hidrostática ou redução coloidosmótica | Ausência de alteração da permeabilidade vascular intrínseca no transudato |
| Conteúdo proteico relativo | Alto teor de proteínas plasmáticas | Baixo teor de proteínas dissolvidas | Concentração de proteínas macromoleculares no fluido |
| Aspecto físico macroscópico | Aspecto turvo por detritos celulares | Aspecto límpido e claro | Turbidez do fluido à inspeção direta |

### Cicatrização tecidual e infecções bacterianas cutâneas:
- **Cinética da cicatrização tecidual**:
  - **Fase inflamatória**: Instala-se imediatamente na injúria mecânica através da polimerização de trombina e formação da malha de fibrina.
    - **Fisiopatologia**: Infiltração tecidual primária por neutrófilos → Atração de monócitos e diferenciação em macrófagos às 24 horas → Secreção de citocinas quimiotáticas e tróficas.
  - **Fase proliferativa**: Deposita estroma de granulação vascularizado para preencher as margens separadas da fenda lesional.
    - **Célula efetora**: Fibroblasto tecidual migratório ativado.
    - **Produtos de síntese**: Sintetiza colágeno fibrilar imaturo, proteoglicanos basais e glicoproteínas estruturais.
  - **Fase de maturação e remodelação**: Inicia na terceira semana do trauma físico e prolonga-se por período igual ou superior a 6 meses.
    - **Mecanismo**: Regride densidade vascular capilar local e reorganiza colágeno em feixes paralelos regulares.
    - **Desfecho funcional**: Aumenta progressivamente a resistência tênsil mecânica cicatricial e encurta o diâmetro da ferida.
- **Queloide**: Proliferação fibroelástica exuberantetransbordante excedendo as dimensões topográficas do corte cirúrgico original.
  - **Mecanismo**: Deposição descontrolada, excessiva e contínua de colágeno fibrilar e proteoglicanos na matriz dérmica.
  - **Suscetibilidade genética**: Acomete indivíduos com ascendência biológica negra africana por suscetibilidade gênica familiar.
- **Piodermites bacterianas**:
  - **Impetigo não bolhoso**: Infecção contagiosa bacteriana restrita à camada subcórnea da epiderme superficial.
    - **Lesão elementar**: Forma pápulas eritematosas que evoluem para vesículas frágeis e pústulas com halo inflamatório de 1 a 4 mm.
    - **Fisiopatologia**: Ruptura do teto de vesículas frágeis → Liberação de líquido seropurulento estafilocócico → Dessecação do exsudato infectado → Deposição de crosta melicérica amarelada.
    - **Topografia típica**: Fixa-se preferencialmente em regiões periorificiais da face, fossas nasais e transição do vermelhão labial.
  - **Furúnculo**: Infecção bacteriana necrotizante profunda supurativa do complexo pilossebáceo dérmico.
    - **Etiologia**: *Staphylococcus aureus*.
    - **Sítio anatômico**: Acomete profundamente bulbo folicular, glândulas sebáceas contíguas e estroma perifolicular circundante.
    - **Fatores predisponentes**: Seborreia cutânea, atrito traumático de tecidos, vestimentas sintéticas oclusivas, hiperidrose, pediculose ativa e depilação.
    - **População vulnerável**: Concentra incidência preferencialmente em adolescentes e adultos jovens.

| Atributo | Erisipela | Celulite | Limiar discriminador |
|---|---|---|---|
| Início e progressão | Início hiperagudo menor de 24 horas | Início insidioso e lentamente progressivo | Latência clínica menor de 24 horas |
| Profundidade tecidual | Derme superficial e vasos linfáticos dérmicos | Derme profunda e gordura subcutânea | Acometimento dérmico superficial versus invasão hipodérmica |
| Delimitação das margens | Placa eritematosa com bordas elevadas nítidas | Placa eritematosa com bordas mal definidas e planas | Presença de rebordo periférico delimitado e sobreelevado |
| Manifestações sistêmicas | Calafrios e febre maior de 38 °C desde o início | Sintomas gerais infrequentes de surgimento tardio | Registro térmico superior a 38 °C desde o início |
| Distribuição e lateralidade | Unilateral em 98% dos casos com foco crural em 85% | Acometimento sem distribuição percentual estrita | Comprometimento acropédico unilateral em 85% a 98% dos casos |
| Resposta sorológica | Títulos de antiestreptolisina O menores de 40% no início | Sorologia variável com menor vínculo à cinética da ASO | Taxa de soroconversão estreptocócica quantificável |

## Hematologia e hemostasia:

### Elementos figurados e regulação hematopoética:
- **Eritrócito**: Disco bicôncavo anucleado altamente deformável para transporte gasoso microvascular capilar.
  - *Sobrevida média*: 120 dias na circulação intravascular sistêmica.
  - **Componente funcional**: Hemoglobina molecular tetramérica carreadora de oxigênio e dióxido de carbono.
- **Leucócitos**: Células esferoides nucleadas coordenadoras das defesas biológicas inata e adquirida.
  - *Volume relativo*: Constituem 1% do volume hemático corporal total.
  - **Linhagens constitutivas**: Engloba granulócitos polimorfonucleares, monócitos circulantes e linfócitos teciduais.
- **Linfócitos**:
  - *Proporção escalar*: Representam 20% a 30% da contagem total de leucócitos do sangue periférico.
  - **Recirculação contínua**: Migram ciclicamente entre o leito vascular e órgãos linfoides secundários durante horas até anos.
  - **Subpopulações funcionais**:
    - **Linfócito B**: Diferencia-se terminalmente em plasmócito secretor de imunoglobulinas humorais antígeno-específicas.
    - **Linfócito T**: Reconhece peptídeos imunogênicos processados para executar citotoxicidade e regulação imunológica celular.
    - **Célula natural killer**: Exerce citotoxicidade inata direta contra células neoplásicas e infectadas sem sensibilização clonal prévia.
- **Ontogenia hematopoética**:
  - **Fisiopatologia**: Endotélio intravascular do saco vitelino na semana 5 → Colonização do fígado fetal → Migração para o baço fetal → Instalação definitiva na medula óssea pós-natal.
  - **Hematopoiese extramedular**: Fígado e baço reativam transcrição hematopoética sob anemia crônica ou fibrose da cavidade medular.
- **Citocinas hematopoéticas reguladoras**:
  - **Eritropoietina**: Hormônio glicoproteico que induz sobrevida e diferenciação terminal de precursores unipotentes eritroides.
  - **Fator estimulador de colônias de granulócitos e macrófagos**: Estimula progenitores bivalentes mieloides geradores de granulócitos, monócitos, hemácias e megacariócitos.
  - **Fator estimulador de colônias de granulócitos**: Direciona precursores mieloblásticos para a produção e liberação seletiva de neutrófilos funcionais.
  - **Fator estimulador de colônias de macrófagos**: Promove a diferenciação unidirecional de células monocíticas em macrófagos teciduais maduros.
  - **Trombopoietina**: Estimula a endomitose de megacariócitos medulares e o desprendimento de plaquetas no lúmen vascular.

### Hemostasia, cascata de coagulação e estados de hipercoagulação:
- **Hemostasia**: Sistema enzimático e vascular que impede extravasamento hemático mantendo o sangue em estado líquido intravascular.
  - **Trombose**: Formação patológica intravascular inapropriada de trombos plaquetários e fibrinosos oclusivos.
  - **Hemorragia**: Rompimento da contenção hemostática com perda aguda de sangue para fora do leito vascular.
  - **Etapas primárias**: Vasoconstrição miogênica reflexa imediata → Adesão e desgranulação plaquetária → Polimerização da rede insolúvel de fibrina.
- **Plaquetas**: Fragmentos anucleados discoides derivados de megacariócitos poliploides da medula óssea.
  - **Grânulos alfa**: Contêm fibrinogênio, fator de von Willebrand, fibronectina, fator V, fator VIII, fator plaquetário 4, PDGF e TGF-alfa.
  - **Grânulos densos**: Armazenam trifosfato de adenosina, difosfato de adenosina, cálcio ionizado, histamina, serotonina e adrenalina.
  - **Fisiopatologia**: Lesão endotelial vascular → Exposição de colágeno subendotelial → Secreção endotelial do fator de von Willebrand → Adesão do receptor plaquetário ao colágeno via fvW → Mudança conformacional para esfera espiculada → Ativação do receptor GP IIb/IIIa → Secreção ativa de ADP e tromboxano A2 → Agregação de novas plaquetas circulantes → Clivagem de monômeros de fibrina pela trombina → Consolidação do tampão estável.
  - **Fator de von Willebrand**: Circula ligado ao fator VIII protegendo a molécula contra clivagem proteolítica precoce no plasma.
- **Coagulação plasmática**: Cascata amplificadora sequencial de pró-enzimas sintetizadas no retículo endoplasmático hepático.
  - **Via intrínseca**: Inicia pelo contato do fator XII sérico com superfícies de colágeno carregadas negativamente expostas na lesão.
  - **Via extrínseca**: Inicia pela exposição microvascular luminal de tromboplastina tecidual após injúria celular estrutural.
  - **Via comum**: Fator Xa + Fator Va + Cálcio ionizado + Fosfolipídios ativam o complexo protrombinase → Conversão de protrombina em trombina → Clivagem enzimática de fibrinogênio em polímeros insolúveis de fibrina.
  - **Cofatores metabólicos**:
    - **Vitamina K**: Promove gama-carboxilação dos resíduos glutâmicos dos fatores dependentes II, VII, IX e X e da proteína C.
    - **Cálcio ionizado**: Atua como cofator estrutural obrigatório para montagem de todos os complexos enzimáticos exceto as duas ativações iniciais.
- **Fibrinólise**: Ativação do plasminogênio tecidual em plasmina ativa para hidrolisar fibrina e restaurar o lúmen vascular pérvio.
- **Tríade de Virchow**:
  - **Lesão endotelial**: Agressão física contusa, inflamação celular ou toxicidade metabólica sobre a camada íntima endotelial.
  - **Estase venosa**: Perda da velocidade laminar do fluxo sanguíneo com aprisionamento marginal de leucócitos e plaquetas.
  - **Hipercoagulabilidade**: Alterações procoagulantes humorais no balanço dinâmico de coagulantes e anticoagulantes endógenos.
- **Hiperatividade plaquetária**:
  - **Etiologia**: Provocada por aterosclerose obstrutiva, tabagismo, diabetes mellitus descompensado, dislipidemia e hiperplaquetoses.
  - **Fisiopatologia**: Placa aterosclerótica induz fluxo sanguíneo turbilhonar → Deposição de plaquetas ativadas no subendotélio → Liberação contínua de PDGF plaquetário → Hiperplasia de células musculares lisas da túnica média → Aterogênese obstrutiva acelerada.
- **Ativação patológica da coagulação**:
  - **Transtornos hereditários primários**:
    - **Mutação do fator V de Leiden**: Herança autossômica dominante que confere resistência molecular à degradação pela proteína C ativada.
    - **Mutação do gene da protrombina G20210A**: Aumenta os níveis basais de protrombina circulante acelerando a trombogênese.
    - **Deficiência de anticoagulantes**: Reduções congênitas de antitrombina III plasmática, proteína C sérica ou proteína S livre.
  - **Transtornos adquiridos secundários**:
    - **Estase prolongada**: Imobilização no leito, repouso pós-operatório estrito e congestão na insuficiência cardíaca crônica.
    - **Neoplasia maligna ativa**: Representa malignidade oculta subjacente em 20% a 25% dos episódios de trombose venosa idiopática.
    - **Estados hiperestrogênicos**: Gravidez, puerpério, reposição hormonal exógena e administração de contraceptivos orais combinados.
    - **Fator multiplicador do risco vascular**: Tabagistas femininas com idade > 35 anos sob contracepção hormonal oral sofrem elevação sinérgica de infarto miocárdico e AVC isquêmico.
    - **Síndrome antifosfolipídica**: Trombofilia autoimune adquirida mediada por autoanticorpos indutores de tromboses arteriais e venosas recorrentes.
    - **Fatores de risco sistêmicos associados**: Obesidade mórbida, hipertensão arterial, DPOC, nefropatia crônica, transfusões heterólogas e voos aéreos de longa distância.

### Alterações do número de plaquetas e tromboembolia pulmonar:
- **Trombocitose**: Elevação da contagem plaquetária sérica acima dos limites basais.
  - *Limiar diagnóstico*: Contagem de plaquetas > 1.000.000 /µL.
  - **Alça homeostática da trombopoietina**: Queda plaquetária periférica → Elevação de TPO sérica livre → Estimulação proliferativa de megacariócitos medulares → Expansão da massa plaquetária circulante → Depuração de TPO por receptores em plaquetas maduras → Queda de TPO livre circulante → Bloqueio da trombopoiese medular.
  - **Classificação**:
    - **Trombocitose primária**: Neoplasia mieloproliferativa clonal crônica com autonomia biológica independente de trombopoietina livre.
    - **Trombocitose secundária**: Resposta medular reativa deflagrada por grandes cirurgias, neoplasias sólidas, artrite reumatoide, doença de Crohn e leucemias.
  - **Manifestações clínicas**:
    - **Fenômenos trombóticos**: Trombose venosa profunda crural, tromboembolia pulmonar aguda e trombose das veias porta e hepáticas.
    - **Eritromelalgia**: Oclusão microvascular isquêmica paroxística das extremidades distais com queimação cutânea intensa, rubor e calor local.
    - **Hemorragia paroxística paradoxal**: Episódios de sangramento mucoso alternados com períodos assintomáticos por defeito funcional plaquetário associado.
  - **Tratamento**: Prescreva hidroxiureia oral para reduzir a proliferação megacariocítica em trombocitoses graves sintomáticas.
- **Trombocitopenia**: Redução patológica da concentração de plaquetas circulantes.
  - *Limiar diagnóstico*: Contagem de plaquetas < 150.000 /µL.
  - **Mecanismos etiopatogênicos**:
    - **Insuficiência de síntese medular**: Aplasia medular primária, infiltração neoplásica ou toxicidade supressora sobre megacariócitos.
    - **Sequestro patológico esplênico**: Aprisionamento exacerbado de massa plaquetária funcional nos cordões da polpa vermelha esplênica.
    - **Destruição acelerada periférica**: Remoção precoce mediada por anticorpos opsonizantes antiplaquetários ou fratura mecânica microangiopática.
- **Tromboembolia pulmonar**: Impactação mecânica aguda da circulação vascular arterial pulmonar por êmbolos originados no sistema venoso periférico.
  - **Origem primária dos trombos**: Desprendimento de coágulos formados nas veias profundas proximais dos membros inferiores e bacia.
  - **Embolia paradoxal**: Transposição de êmbolo venoso para a grande circulação sistêmica através de defeitos no septo interatrial ou forame oval patente.
  - **Apresentação semiológica**: Instalação hiperaguda de dispneia súbita e dor torácica de difícil elucidação etiológica.
  - **Critério de suspeição diagnóstica**: Refratariedade e ausência de resposta ao tratamento padrão de descompensações agudas de insuficiência cardíaca ou quadros de pneumonia.
  - **Estratificação hemodinâmica de risco**:
    - **Tromboembolia pulmonar maciça**:
      - *Limiar anatômico*: Oclusão arterial pulmonar bilateral de pelo menos 50% do leito vascular pulmonar total.
      - *Prevalência*: Constitui 5% a 10% de todos os diagnósticos confirmados.
      - **Manifestações clínicas**: Dispneia crítica asfixiante, síncope súbita, hipotensão sistêmica persistente, cianose central, choque obstrutivo cardiogênico e parada circulatória.
    - **Tromboembolia pulmonar submaciça**:
      - **Definição**: Disfunção ecocardiográfica de ventrículo direito associada a biomarcadores cardíacos positivos sem hipotensão sistêmica.
      - *Prevalência*: Abrange 20% a 25% da amostragem clínica hospitalar.
      - **Manifestações clínicas**: Taquipneia sustentada com pressão arterial sistêmica preservada.
    - **Tromboembolia pulmonar de baixo risco**:
      - **Definição**: Preservação estrita da dinâmica contrátil de câmaras direitas e biomarcadores miocárdicos séricos normais.
      - *Prevalência*: Compreende 65% a 75% da totalidade dos casos admitidos.
      - **Manifestações clínicas**: Estabilidade hemodinâmica sem evidências clínicas ou laboratoriais de falência ventricular.

## Insuficiência circulatória aguda - Choque:

### Mecanismos e bioenergética celular:
- **Choque circulatório**: Síndrome patológica caracterizada por hipoperfusão sistêmica difusa com desequilíbrio crítico entre oferta e consumo tecidual de oxigênio.
  - **Quadro fisiopatológico básico**: Débito cardíaco insuficiente e má oxigenação celular periférica, tolerando pressão arterial normal nas fases compensadas iniciais.
  - **Classificação etiológica**:
    - **Choque cardiogênico**: Falência contrátil mecânica miocárdica primária que colapsa agudamente o volume sistólico e o débito eferente.
    - **Choque hipovolêmico**: Depleção crítica do volume intravascular intra-arterial efetivo com redução extrema do retorno venoso sistêmico.
    - **Choque distributivo**: Perda desregulada do tônus vasomotor vascular com sequestro periférico e má distribuição distributiva tecidual.
    - **Choque obstrutivo**: Bloqueio mecânico extracardíaco impedindo o enchimento diastólico ventricular ou a ejeção sistólica nos grandes vasos torácicos.
- **Bioenergética tecidual celular**:
  - **Fase aeróbica em normóxia**: Glicólise anaeróbica citoplasmática cliva glicose em 2 moléculas de piruvato com produção de 2 moles de ATP → Captação do piruvato pela membrana mitocondrial → Oxidação no ciclo dos ácidos tricarboxílicos → Cadeia de transporte de elétrons e fosforilação oxidativa sintetizam o rendimento líquido celular de ATP.
  - **Desvio anaeróbico sob hipoperfusão tecidual e choque**:
    - **Bloqueio oxidativo**: Anóxia mitocondrial bloqueia o transporte e o processamento de piruvato pela piruvato desidrogenase.
    - **Desvio citosólico compensatório**: Enzima lactato desidrogenase citoplasmática converte o piruvato acumulado em ácido lático gerando aporte energético mínimo.
    - **Fisiopatologia**: Falência do aporte de oxigênio tecidual → Dependência exclusiva da via glicolítica citosólica ineficiente → Acúmulo intracelular de ácido lático → Efluxo de lactato para o espaço intersticial e plasma → Acidose metabólica sistêmica progressiva com hiato aniônico elevado.

### Choque hipovolêmico e obstrutivo:
- **Choque hipovolêmico**:
  - **Fase pré-hipotensiva**: Ocorre vasoconstrição e hipoperfusão celular precoce periférica antes do declínio numérico da pressão arterial sistólica.
  - **Queda volumétrica crítica**: Perda hemorrágica ou fluídica aguda de 30% a 40% da volemia total colapsa o débito cardíaco e reduz a pressão arterial para zero.
  - **Mecanismos neuroendócrinos compensatórios**:
    - **Eixo simpático-adrenérgico**: Desativação de barorreceptores carotídeos e aórticos → Descarga simpática eferente em segundos → Cronotropismo e inotropismo aumentados no miocárdio + Vasoconstrição alfa-adrenérgica periférica seletiva.
    - **Eixo neuro-hipofisário**: Estímulo sobre barorreceptores excita núcleos hipotalâmicos → Ativação do centro da sede + Liberação de vasopressina pelo lobo hipofisário posterior.
      - **Ações da vasopressina**: Provoca vasoconstrição de arteríolas musculares e do leito esplâncnico + Induz inserção de canais de aquaporina nos túbulos coletores renais reabsorvendo água livre.
  - **Fase descompensada e refratária**:
    - **Fisiopatologia**: Hipovolemia sustentada sem reposição de fluidos → Vasoconstrição isquêmica mantida em leitos esplâncnico, cutâneo e renal → Hipóxia celular irreversível → Exaustão terminal das reservas de ATP → Falência das bombas iônicas de membrana transmembranares → Ruptura da membrana celular e liberação de enzimas lisossômicas → Necrose tecidual generalizada e falência de múltiplos órgãos.
- **Choque obstrutivo**: Interrupção puramente mecânica ao fluxo de sangue intracardíaco ou nos troncos arteriais intratorácicos principais.
  - **Causa primária principal**: Tromboembolia pulmonar maciça aguda oclusiva que sobrecarrega agudamente as pressões de ventrículo direito.
  - **Etiologias mecânicas associadas**:
    - **Aneurisma dissecante da aorta**: Falso lúmen gerado na túnica média comprime e oblitera a luz vascular aórtica verdadeira.
    - **Tamponamento cardíaco**: Acúmulo agudo de sangue ou exsudato inflamatório no folheto pericárdico bloqueando o enchimento diastólico ventricular.
    - **Pneumotórax hipertensivo**: Válvula unidirecional acumula ar sob tensão na pleura, desviando o mediastino com colapso do retorno pela veia cava.
    - **Hérnia diafragmática traumática**: Ruptura parietal do hemidiafragma com translocação de vísceras abdominais e compressão cardíaca e mediastinal intratorácica.