# Sistema hematológico e vascular:
## Transtornos da hemostasia:
### Estados de hipercoagulabilidade:
- **Estados de hipercoagulabilidade**: Predispõem à trombose vascular por aumento funcional plaquetário ou aceleração da cascata de coagulação.
  - **Aumento da função de plaquetas**:
    - **Mecanismos indutores de trombose**: Perturbação do fluxo sanguíneo + lesão endotelial + aumento de sensibilidade plaquetária à adesão e agregação.
    - **Consequências teciduais**: Aderência de plaquetas → formação de tampões plaquetários → interrupção do fluxo de sangue.
    - **Condições associadas**:
      - **Aterosclerose**: Placas ateroscleróticas alteram o fluxo, causam lesão do endotélio e estimulam a fixação plaquetária.
      - **Liberação de mediadores**: Plaquetas aderidas secretam fatores de crescimento que induzem proliferação do músculo liso vascular.
      - **Fatores metabólicos e comportamentais**: Diabetes mellitus + tabagismo + hiperlipidemia + hipercolesterolemia + elevação numérica plaquetária.
      - **Ponte didática / Analogia prática**: O vaso com aterosclerose funciona como pista asfaltada cheia de buracos e remendos; o tráfego perde fluidez, os carros batem nas bordas e formam retenção imediata de veículos.
    - **Trombocitose**:
      - **Parâmetro diagnóstico de trombocitose**: Contagem de plaquetas > 1.000.000/µL.
      - **Subtipos**:
        - **Trombocitose essencial (primária)**: Processo autônomo da medula óssea.
        - **Trombocitose reativa (secundária)**:
          - **Mecanismo indutor**: Doenças de base estimulam liberação excessiva de trombopoietina.
          - **Etiologias documentadas**: Intervenção cirúrgica + câncer + doenças inflamatórias crônicas (artrite reumatoide, doença de Crohn) + policitemia + leucemia.
      - **Regulação por trombopoietina**:
        - **Vetor mecanicista**: Trombopoietina liga-se a receptores de plaquetas circulantes e megacariócitos para regular maturação celular.
        - **Queda de contagem plaquetária**: Menor fixação em plaquetas → elevação de trombopoietina livre → estimulação de megacariócitos medulares.
        - **Elevação de contagem plaquetária**: Maior fixação em plaquetas → redução de fração livre de trombopoietina → inibição da megacariocitopoiese.
      - **Manifestações clínicas**: Trombose (TVP, TEP, trombose de veia porta e supra-hepática) + hemorragias espontâneas ou fatais.
      - **Eritromelalgia**: Oclusão arteriolar microvascular por agregados plaquetários → dor em queimação + palpitações digitais em dedos.
      - **Intervenção farmacológica**: Hidroxiureia reduz a concentração plasmática plaquetária.
  - **Aceleração da atividade do sistema de coagulação**:
    - **Transtornos congênitos (hereditários)**:
      - **Mutação do Fator V de Leiden**: Causa resistência molecular à proteína C ativada, impedindo a degradação proteolítica fisiológica dos fatores V e VIII.
      - **Mutação no gene da protrombina**: Eleva a concentração plasmática de protrombina, aumentando o risco de tromboembolia venosa.
    - **Transtornos adquiridos**:
      - **Estase de fluxo venoso**:
        - **Vetor mecanicista**: Fluxo lento impede contato de enzimas pró-coagulantes ativadas com inibidores naturais plasmáticos.
        - **Fatores etiológicos**: Repouso prolongado em leito + imobilização mecânica + infarto agudo do miocárdio + insuficiência cardíaca congestiva + pós-operatório.
      - **Hiperestrogenismo**: Consumo crônico de anticoncepcionais orais + gravidez + puerpério.
      - **Associação clínica**: Mulheres > 35 anos usuárias de anticoncepcionais combinados associados a tabagismo apresentam maior incidência de AVC e IAM.
      - **Neoplasias malignas**: Câncer ativo cursa com risco aumentado de tromboembolia venosa; 20% a 25% dos quadros primários de TEV decorrem de câncer oculto.
      - **Ponte didática / Analogia prática**: O sangue sob estase comporta-se como água de rio represada em curva fechada; sem movimento, resíduos e lodo acumulam-se no fundo até bloquear a passagem.

### Tromboembolia venosa e complicações cardiovasculares:
- **Tromboembolia venosa (TEV)**: Compreende a trombose venosa profunda (TVP) e o tromboembolismo pulmonar (TEP).
  - **Fator epidemiológico**: Causa mais comum de morte evitável em pacientes hospitalizados.
  - **Tríade de Virchow**:
    - **Lesão endotelial**: Ruptura ou ativação disfuncional da camada íntima vascular.
    - **Estase venosa**: Redução da velocidade linear e acúmulo focal de fatores de coagulação.
    - **Hipercoagulabilidade**: Desbalanço humoral pró-trombótico congênito ou adquirido.
  - **Trombose venosa profunda (TVP)**:
    - **Acometimento de extremidade inferior**: Origina-se na panturrilha e propaga-se proximalmente para veias poplítea, femoral e ilíaca; apresenta frequência 10 vezes maior que extremidade superior.
    - **Acometimento de extremidade superior**: Desencadeado por cateter venoso central de longa permanência, marcapasso, desfibrilador interno, esforço físico vigoroso, estresse emocional severo e neoplasias.
    - **Quadro clínico periférico**:
      - **Sintoma típico**: Cãibra persistente na panturrilha ("charley horse") que piora progressivamente com a marcha.
      - **Sinais locais**: Edema maleolar, calor local, rubor ou cianose, dilatação de veias superficiais e cordão venoso palpável e hipersensível.
  - **Embolização e tromboembolismo pulmonar (TEP)**:
    - **Mecanismo de desprendimento**: Trombos periféricos fragmentam-se, migram pela veia cava até o ventrículo direito e ocluem o leito arterial pulmonar.
    - **Embolismo paradoxal**: Desvio do êmbolo para circulação arterial sistêmica através de forame oval patente ou comunicação interatrial.
    - **Embolias de etiologia não trombótica**: Êmbolo gorduroso + êmbolo neoplásico (tumoral) + medula óssea + ar (gasosa) + líquido amniótico por rotura de membranas fetais.
    - **Quadro clínico central**: Denominado "a grande simuladora" por apresentar sinais inespecíficos; a manifestação mais comum envolve dispneia não explicada.
  - **Sequelas crônicas pós-trombóticas**:
    - **Hipertensão pulmonar tromboembólica crônica (HPTEC)**: Oclusões vasculares persistentes causam dispneia progressiva aos esforços e disfunção ventricular.
    - **Síndrome pós-trombótica**: Destruição das válvulas venosas de membros inferiores → estase venosa crônica → edema maleolar + dor surda + hiperpigmentação + úlcera cutânea.

#### Matriz comparativa - Estratificação de risco do tromboembolismo pulmonar:
| Parâmetro avaliado | TEP de baixo risco | TEP submassivo | TEP massivo | Critério discriminador / Ponto de corte |
| :--- | :--- | :--- | :--- | :--- |
| Prevalência relativa | 65% a 75% dos casos | 20% a 25% dos casos | 5% a 10% dos casos | Proporção epidemiológica do quadro |
| Pressão arterial sistêmica | Normotenso | Normotenso | Hipotensão arterial / Choque | PAS < 90 mmHg ou instabilidade clínica |
| Função do ventrículo direito | Preservada | Disfunção de ventrículo direito | Falência ventricular aguda | Sinais ecocardiográficos ou de imagem |
| Biomarcadores cardíacos | Sem elevação | Elevação documentada | Elevação documentada | Liberação de troponina ou peptídeos natriuréticos |
| Extensão vascular pulmonar | Oclusão focal | Oclusão intermediária | Oclusão ≥ 50% dos vasos pulmonares | Comprometimento anatômico arterial pulmonar |
| Desfecho prognóstico | Prognóstico excelente | Risco de deterioração clínica | Choque cardiogênico e falência múltipla | Taxa elevada de mortalidade precoce |

### Diagnóstico, monitorização e estadiamento clínico:
- **Abordagem diagnóstica laboratorial e por imagem**:
  - **Ensaio imunoenzimático de Dímero D**:
    - **Sensibilidade clínica**: Sensibilidade > 80% para TVP e > 95% para TEP em pacientes de probabilidade clínica baixa a intermediária.
    - **Falsos-positivos documentados**: Infarto agudo do miocárdio + pneumonia bacteriana + septicemia sistêmica + câncer ativo + pós-operatório recente + gestação no 2º e 3º trimestres.
  - **Ultrassonografia vascular (Eco-Doppler de membros inferiores)**: Método de eleição para confirmação de TVP por visibilização direta da massa trombótica intraluminal.
  - **Angiotomografia computadorizada de tórax (Angio-TC)**: Exame padrão-ouro confirmatório para localização de falhas de enchimento luminais no TEP.
  - **Radiografia simples de tórax**: Apresenta-se frequentemente normal ou com achados inespecíficos.
- **Protocolos terapêuticos de recanalização e anticoagulação**:
  - **Trombólise dirigida por cateter**: Farmacomecânica invasiva com infusão local de trombolítico diretamente sobre a massa trombótica.
  - **Anticoagulação oral com varfarina**: Dose inicial de 5 mg via oral para bloqueio dependente de vitamina K.
  - **Faixa de monitorização de INR**:
    - *Alvo terapêutico*: Valor de INR = 2,5.
    - *Limites terapêuticos aceitáveis*: Intervalo de INR [2,0, 3,0].
- **Insuficiência venosa crônica (Classificação CEAP)**:
  - **Estádio 0**: Ausência de sinais visíveis ou palpáveis de doença venosa.
  - **Estádio 1**: Telangiectasias ou veias reticulares periféricas.
  - **Estádio 2**: Veias varicosas tronculares visíveis.
  - **Estádio 3**: Edema de membro inferior sem alterações tróficas da pele.
  - **Estádio 4**: Alterações cutâneas tróficas (hiperpigmentação, eczema estático, atrofia branca ou lipodermatoesclerose).
  - **Estádio 5**: Alterações tróficas cutâneas associadas a úlcera venosa cicatrizada.
  - **Estádio 6**: Alterações tróficas cutâneas associadas a úlcera venosa ativa em fase aberta.

### Distúrbios hemorrágicos:
- **Transtornos hemorragíparos vasculares e hematológicos**:
  - **Mecanismos primários de falha**: Defeitos plaquetários + deficiência de fatores de coagulação + perda da integridade vascular.
  - **Sangramentos de origem plaquetária**:
    - **Localização preferencial**: Microvasculatura de membranas mucosas (nariz, cavidade oral, trato digestivo, cavidade uterina) e tecido cutâneo.
    - **Manifestações dérmicas**: Petéquias milimétricas e manchas purpúricas em áreas de declive com alta pressão capilar hidrostática.
    - **Ausência de petéquias na disfunção qualitativa**: Petéquias ocorrem quase que exclusivamente na insuficiência quantitativa (trombocitopenia), ausentes no defeito funcional isolado.
    - **Ponte didática / Analogia prática**: As plaquetas funcionam como rolhas de borracha em tubulações perfuradas; se faltam rolhas em quantidade, pequenos furos de alfinete vazam líquido continuamente nas paredes.
  - **Trombocitopenia quantitativa**:
    - *Ponto de corte hematológico*: Contagem plaquetária circulante < 150.000/µL.
    - **Mecanismos fisiopatológicos**:
      - **Depressão medular direta**: Anemia aplásica + radiação ionizante + quimioterápicos antineoplásicos.
      - **Infiltração de medula óssea**: Substituição do parênquima hematopoético por células neoplásicas de leucemia.
      - **Supressão viral de megacariócitos**: Infecção ativa por Vírus da Imunodeficiência Humana (HIV) ou Citomegalovírus (CMV).
      - **Sequestro esplênico**: Aprisionamento físico acelerado de plaquetas no baço em quadros de esplenomegalia.
      - **Destruição periférica**: Mecanismos imunes (anticorpos antiplaquetários) ou não imunes.
  - **Defeitos funcionais (qualitativos)**:
    - **Formas congênitas**: Doenças hereditárias da agregação e adesão de plaquetas.
    - **Formas adquiridas**: Toxicidade medicamentosa + uremia sistêmica + estresse mecânico de circulação extracorpórea.
  - **Defeitos vasculares e da parede do vaso**:
    - **Etiologias mecânicas e imunes**: Fragilidade mecânica parietal estrutural + dano microvascular induzido por inflamação parietal ou imunocomplexos circulantes.