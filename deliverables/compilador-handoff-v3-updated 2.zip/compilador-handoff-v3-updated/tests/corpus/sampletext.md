# Fisiopatología hematológica y vascular:
## Trastornos plaquetarios y de la hemostasia primaria:
### Fisiopatología de la trombocitopenia y hemorragia microvascular:
- **Hemorragia por alteración plaquetaria**: El sangrado surge ante el fallo funcional o numérico del tapón hemostático primario, comprometiendo de forma predominante la microvasculatura mucocutánea.
  - **Mecanismos etiopatogénicos generales**: Cuando valoramos una diátesis hemorrágica plaquetaria en la clínica, debemos identificar si nos encontramos ante un descenso numérico o ante una falla cualitativa.
    - **Trombocitopenia por hipoproducción medular**: La médula ósea pierde su capacidad proliferativa megacariocítica por daño aplásico intrínseco, toxicidad por fármacos, radioterapia, supresión directa de megacariocitos mediada por VIH o infiltración maligna por leucemias.
    - **Destrucción plaquetaria acelerada**: La vida media periférica de las plaquetas se acorta drásticamente mediante lisis inmune por anticuerpos o destrucción mecánica no inmune.
    - **Disfunción plaquetaria intrínseca**: El recuento plaquetario puede ser adecuado, pero las plaquetas son incapaces de adherirse o agregarse de forma efectiva.
  - **Secuestro esplénico de plaquetas**: En condiciones fisiológicas basales, el bazo retiene entre el 30% y el 40% de la masa plaquetaria circulante; sin embargo, en cuadros de esplenomegalia patológica, este secuestro puede incrementarse hasta el 90%, provocando una trombocitopenia periférica severa a pesar de una producción medular conservada.
  - **Mecanismo de destrucción periférica**:
    - **Destrucción inmunitaria**: Los autoanticuerpos o aloanticuerpos se dirigen contra glucoproteínas esenciales de la membrana plaquetaria, en particular GPIIb/IIIa y GPIb/IX, induciendo la opsonización celular y facilitando su fagocitosis macrofágica o lisis por complemento.
    - **Destrucción no inmunitaria**: El daño de la pared microvascular en la hipertensión maligna o las fuerzas de cizallamiento generadas por prótesis valvulares cardíacas fragmentan mecánicamente las plaquetas, mientras que en la CID y la púrpura trombocitopénica trombótica se produce un consumo microvascular masivo.
  - **Expresión semiológica del sangrado plaquetario**:
    - **Hemorragia cutánea**:
      - **Petequias**: Pequeñas lesiones puntiformes de extravasación capilar que se observan casi con exclusividad en la insuficiencia plaquetaria cuantitativa y no en los trastornos funcionales cualitativos.
      - **Púrpura**: Áreas confluentes de equimosis y magulladuras violáceas localizadas predominantemente en zonas declives corporales donde la presión hidrostática capilar es superior.
    - **Hemorragia mucosa**: Epistaxis espontánea, gingivorragia activa, hemorragia digestiva alta o baja y metrorragias o pérdidas uterinas anormales.
    - **Riesgo vital del sangrado central**:
      - *Umbral crítico*: Recuentos plaquetarios en agotamiento extremo con cifras inferiores a 20.000/µL.
      - *Consecuencia clínica*: Hemorragia vascular intracraneal masiva que compromete la vida del paciente de manera aguda.
- **Criterio diagnóstico de trombocitopenia**:
  - *Umbral*: Recuento de plaquetas en sangre periférica menor a 150.000/µL.
  - *Consecuencia clínica*: Aparición progresiva de sangrados menores espontáneos y alargamiento sustancial del tiempo de sangría con pruebas de coagulación plasmática conservadas.

### Trombocitopenia inducida por fármacos y por heparina:
- **Trombocitopenia inmune inducida por fármacos**: Cuadro mediado por la interacción de sustancias exógenas con componentes de la membrana plaquetaria.
  - **Agentes etiológicos prototípicos**: Quinina, quinidina y antibióticos que contienen sulfonamidas.
  - **Mecanismo o cascada**: La presencia de la molécula del fármaco desencadena la formación de anticuerpos específicos que se ligan a la superficie plaquetaria; esta interacción induce la formación de complejos inmunes solubles que activan el sistema del complemento, provocando la lisis celular intravascular de las plaquetas.
  - **Cinética de instalación y resolución**:
    - **Primera exposición**: El descenso plaquetario ocurre a partir del séptimo día de haber iniciado el tratamiento farmacológico, periodo requerido para montar la respuesta humoral adaptativa primaria.
    - **Reexposición**: Tras un contacto previo sensibilizante, la reintroducción de la droga induce una caída brusca y fulminante del recuento en un lapso de 2 a 3 días.
    - **Resolución al retiro**: Al descontinuar de inmediato la administración del fármaco culpable, la destrucción se interrumpe y los niveles de plaquetas se elevan de manera rápida y sostenida en sangre.
- **Trombocitopenia inducida por heparina**:
  - *Umbral de frecuencia*: Se manifiesta de forma transitoria y leve en aproximadamente el 10% de los pacientes expuestos a heparina.
  - *Intervalo temporal*: Su presentación característica se observa entre los 2 y 5 días posteriores al inicio de la heparinizoterapia.
  - **Mecanismo fisiopatológico**: Se desencadena por una respuesta inmunológica dirigida contra los neoantígenos conformados por el complejo heparina-factor plaquetario 4 (PF4), provocando agregación y consumo plaquetario periférico.

### Púrpura trombocitopénica inmunitaria (PTI):
- **Definición de PTI**: Patología autoinmune adquirida mediada por autoanticuerpos que conducen a la destrucción prematura de las plaquetas y a una trombopoyesis compensadora inadecuada.
  - **Clasificación clínica**:
    - **PTI primaria o idiopática**: Surge en ausencia de una enfermedad infecciosa activa subyacente, colagenopatía o factor de riesgo identificable.
    - **PTI secundaria**: Ocurre en el contexto de patologías sistémicas asociadas, incluyendo lupus eritematoso sistémico, síndrome antifosfolípido, infección por VIH, hepatitis C, leucemia linfocítica crónica, linfomas o por fármacos como heparina y quinidina.
  - **Mecanismo o cascada fisiopatológica**:
    - **Desregulación inmunitaria central**: Falla funcional de las células T colaboradoras CD4+ y de las células T reguladoras, lo cual desinhibe a los linfocitos B autorreactivos y estimula la síntesis descontrolada de inmunoglobulinas antiplaquetarias.
    - **Fagocitosis esplénica**: Los anticuerpos atacan las glucoproteínas de la membrana plaquetaria; las plaquetas opsonizadas quedan marcadas y son reconocidas de inmediato por los receptores Fc de los macrófagos del sistema fagocítico mononuclear en los cordones esplénicos, donde son destruidas.
    - **Paradoja de la trombopoyetina**: A pesar de la profunda trombocitopenia periférica observada, los niveles plasmáticos de trombopoyetina (TPO) no se encuentran proporcionalmente elevados en los pacientes con PTI, impidiendo una adecuada estimulación regenerativa en la médula ósea.
  - **Disfunción cualitativa plaquetaria adquirida**:
    - **Trombocitopatía urémica**: Falla metabólica que altera los receptores de membrana e impide la correcta degranulación y adhesión vascular, presente de forma regular en pacientes con uremia avanzada.
    - **Circulación extracorpórea**: Daño físico y activación prematura de la superficie plaquetaria inducida por el contacto mecánico con los circuitos de bypass cardiopulmonar en cirugías de gran envergadura.

### Disfunción plaquetaria intrínseca y adquirida (Trombocitopatía):
- **Trastornos de la función plaquetaria**: Enfermedades en las cuales el defecto hemostático no depende del número celular, sino de la incapacidad bioquímica de la plaqueta para activarse o agregarse.
  - **Defectos congénitos de la función plaquetaria**:
    - **Enfermedad de von Willebrand**: Coagulopatía hereditaria más común, caracterizada por la alteración en la adhesión plaquetaria al endotelio subyacente y por el transporte defectuoso del factor VIII.
  - **Inhibición farmacológica de la ciclooxigenasa (COX)**:
    - **Ácido acetilsalicílico (AAS)**:
      - **Mecanismo**: Produce una acetilación irreversible del centro activo de la ciclooxigenasa plaquetaria, suprimiendo de manera definitiva la síntesis de tromboxano A2 (TXA2) durante toda la vida biológica remanente de la plaqueta tratada.
      - *Consecuencia clínica*: Bloqueo prolongado de la agregación plaquetaria que persiste de 7 a 10 días tras suspender la medicación.
    - **Antiinflamatorios no esteroideos (AINE) reversibles**:
      - **Mecanismo**: Generan una inhibición competitiva y reversible de la ciclooxigenasa.
      - *Consecuencia clínica*: La supresión de la síntesis de tromboxano A2 y la disfunción agregante persisten únicamente mientras el fármaco se encuentre presente en el torrente sanguíneo en concentraciones activas.

## Trastornos de los factores de la coagulación y de la pared vascular:
### Defectos de la hemostasia secundaria:
- **Coagulopatías plasmáticas**: Alteraciones derivadas de la síntesis deficiente, consumo patológico o disfunción molecular de una o más proteínas de la cascada de coagulación, donde el sangrado característico se desencadena predominantemente tras un evento traumático o quirúrgico.
  - **Coagulopatías hereditarias**:
    - **Hemofilia A**: Deficiencia cuantitativa o funcional del factor VIII de la coagulación, transmitida de forma recesiva ligada al cromosoma X.
    - **Hemofilia B**: Deficiencia cuantitativa o funcional del factor IX de la coagulación (enfermedad de Christmas).
    - **Enfermedad de von Willebrand hereditaria**: Deficiencia del factor von Willebrand que deteriora la hemostasia primaria al bloquear la adhesión plaquetaria y la hemostasia secundaria al desestabilizar al factor VIII plasmático.
  - **Coagulopatías adquiridas**:
    - **Enfermedad hepática**: El daño estructural de los hepatocitos disminuye la síntesis de la mayor parte de los factores procoagulantes dependientes y no dependientes de carboxilación.
    - **Déficit de vitamina K**: Provoca la falta de gamma-carboxilación postraduccional de los residuos glutámicos en los factores procoagulantes II, VII, IX y X, generando proteínas inactivas incapaces de fijar calcio a las superficies fosfolipídicas.

### Trastornos de la integridad vascular:
- **Púrpura y fragilidad no trombocitopénica**: Trastornos en los cuales la hemorragia de vasos de pequeño calibre deriva de la incompetencia de la pared conectiva o del daño inflamatorio de la barrera endotelial.
  - **Telangiectasia hemorrágica hereditaria**: Padecimiento autosómico caracterizado por malformaciones vasculares congénitas con capilares y arteriolas dilatadas provistas de paredes delgadas y carentes de soporte muscular elástico.
  - **Escorbuto (Déficit de vitamina C)**: La falta de ácido ascórbico bloquea la hidroxilación de prolina y lisina en la síntesis de colágeno, produciendo una sustancia intercelular incompetente donde las células endoteliales fracasan en cimentarse de forma adecuada, volviendo a la pared capilar sumamente frágil.
  - **Enfermedad de Cushing**: El exceso sostenido de cortisol circulante promueve la atrofia proteica cutánea y el catabolismo del tejido conjuntivo perivascular, privando a los capilares de su sostén tisular.
  - **Púrpura senil**: Presencia de grandes manchas equimóticas en el dorso de manos y antebrazos de adultos mayores debido al deterioro biológico progresivo de la síntesis y recambio de colágeno por el propio envejecimiento.

### Coagulación intravascular diseminada (CID):
- **Fisiopatología sistémica de la CID**: Síndrome trombohemorrágico agudo secundario que se origina por la activación generalizada y no regulada de la hemostasia dentro de todo el árbol vascular.
  - **Mecanismo o cascada**:
    - **Generación explosiva de trombina**: Los estímulos patológicos promueven una liberación masiva de factor tisular o una lesión endotelial difusa con activación del factor XII; esto sobrepasa los mecanismos de control endógenos y genera trombina de forma incontrolada, conduciendo a una polimerización sistémica de fibrina.
    - **Agotamiento de anticoagulantes naturales**: Se produce una rápida reducción en los niveles plasmáticos de antitrombina, proteína C y proteína S, perdiéndose los frenos fisiológicos de la coagulación.
    - **Trombosis microvascular e isquemia de órganos**: La deposición continua de redes de microtrombos de fibrina ocluye la microcirculación tisular, provocando necrosis isquémica celular y falla orgánica múltiple.
    - **Anemia hemolítica microangiopática**: Al intentar circular a alta presión por vasos parcialmente ocluidos por filamentos rígidos de fibrina, los glóbulos rojos sufren cizallamiento y fragmentación mecánica.
    - **Consumo y hemorragia incoagulable**: La formación difusa de trombos consume la totalidad de las plaquetas, el fibrinógeno y los factores lábiles de la coagulación (factores V y VIII); en paralelo, la plasmina activada degrada la fibrina y genera productos de división de la fibrina (PDF) que inhiben de manera directa la trombina, la polimerización de fibrina y la agregación plaquetaria, desatando una hemorragia masiva catastrófica.
  - **Etiologías desencadenantes de CID**:
    - **Complicaciones obstétricas**: Desprendimiento prematuro de placenta normoinserta, síndrome de feto muerto retenido, preeclampsia, eclampsia y embolia de líquido amniótico por vuelco de tromboplastina tisular al torrente materno.
    - **Neoplasias malignas**: Cáncer metastásico y leucemias agudas.
    - **Infecciones graves**: Septicemia por bacterias gramnegativas que exponen endotoxinas, infecciones virales sistémicas, rickettsiosis (fiebre manchada de las Montañas Rocosas) e infestaciones parasitarias como el paludismo.
    - **Estados de shock**: Shock séptico y shock hipovolémico severo con hipoperfusión tisular, acidosis celular y anoxia endotelial.
    - **Traumatismo e intervenciones**: Politraumatismos masivos, quemaduras extensas, cirugía mayor con circulación extracorpórea, mordedura de serpiente con veneno procoagulante y golpe de calor.
    - **Reacciones inmunológicas**: Reacciones hemolíticas transfusionales por incompatibilidad de grupo sanguíneo.

| Trastorno hemostático | Evento patogénico inicial | Alteración de laboratorio clave | Manifestación clínica predominante |
| :--- | :--- | :--- | :--- |
| Trombocitopenia (ej. PTI) | Lisis inmune periférica o falla de producción megacariocítica | Recuento de plaquetas < 150.000/µL con tiempos de coagulación normales | Petequias no palpables y sangrado de mucosas en vasos de pequeño calibre |
| Coagulopatía plasmática (ej. Hemofilia) | Ausencia o deficiencia cuantitativa de factor VIII o IX | Prolongación del tiempo de tromboplastina parcial activada (TTPa) | Hematomas profundos, hemartrosis y sangrado tardío tras trauma o cirugía |
| Coagulación intravascular diseminada | Expresión sistémica masiva de factor tisular y generación de trombina | Trombocitopenia con prolongación de TP/TTPa, hipofibrinogenemia y elevación de PDF | Coexistencia paradójica de microtrombosis isquémica multiorgánica y hemorragia masiva difusa |

## Fisiología y trastornos de los glóbulos rojos:
### Biología del eritrocito, eritropoyesis y catabolismo del hemo:
- **Eritrocito maduro y cinética del hierro**:
  - **Estructura funcional**: Disco bicóncavo anucleado configurado de forma flexible para atravesar los lechos capilares mientras optimiza la superficie de difusión de gases, facilitando el transporte de oxígeno a los tejidos y la captación de dióxido de carbono hacia los pulmones mediante la molécula de hemoglobina (adulta y fetal).
  - **Dependencia de hierro**: La velocidad con la que se sintetiza la hemoglobina está regulada directamente por la disponibilidad de hierro para la formación del anillo del hemo; su carencia restringe la masa de hemoglobina intracelular.
  - **Distribución orgánica del hierro**: El 80% del hierro corporal se encuentra localizado en los músculos fijado a la mioglobina y enzimas, mientras que el 20% restante se almacena en la médula ósea, el hígado y el bazo.
- **Mecanismo de la eritropoyesis medular**:
  - **Diferenciación celular**: Las células madre pluripotenciales generan de manera continua eritroblastos comprometidos en la médula ósea que proliferan, sintetizan hemoglobina, extruyen su núcleo y son liberados al torrente como reticulocitos, los cuales maduran a eritrocitos en 24 a 48 horas.
  - **Regulación homeostática de oxígeno**:
    - **Sensor tisular**: Las células renales detectan la caída en la presión parcial o contenido tisular de oxígeno.
    - **Síntesis hormonal**: El riñón incrementa de forma directa la producción y secreción de la hormona eritropoyetina.
    - **Acción diana**: La eritropoyetina viaja por vía endocrina hasta fijarse a receptores específicos en las células madre comprometidas de la médula ósea, estimulando su proliferación y acelerando la maduración eritroide.
- **Catabolismo eritrocitario y ciclo de la bilirrubina**:
  - **Vida media fisiológica**: Los eritrocitos tienen una supervivencia media estricta de 120 días, destruyéndose de forma natural una tasa constante del 1% de glóbulos rojos por día.
  - **Lisis en el sistema reticuloendotelial**: La fagocitosis de los eritrocitos senescentes es efectuada por macrófagos tisulares localizados en el bazo, el hígado, la médula ósea y los ganglios linfáticos.
  - **Destino metabólico de las fracciones**:
    - **Globina**: Es degradada a sus aminoácidos estructurales para ser reutilizados en nuevas síntesis proteicas.
    - **Hierro**: El átomo ferroso se recupera para reutilizarse de inmediato en la médula ósea o almacenarse en bazo e hígado.
    - **Fracción hemo**: Se transforma bioquímicamente en bilirrubina no conjugada (libre), la cual se transporta unida a albúmina hacia el hígado, donde se conjuga con ácido glucurónico para ser excretada por la bilis hacia el intestino, eliminándose finalmente en heces y orina.

### Parámetros e índices hematimétricos de laboratorio:
| Parámetro eritrocitario | Valor de referencia estándar | Unidad de medida | Interpretación fisiopatológica |
| :--- | :--- | :--- | :--- |
| Recuento de eritrocitos (Varones) | 4,2 a 5,4 × 10⁶ | /µL | Número total de hematíes circulantes en el compartimiento vascular. |
| Recuento de eritrocitos (Mujeres) | 3,6 a 5,0 × 10⁶ | /µL | Masa absoluta de glóbulos rojos disponible para transporte de gases. |
| Porcentaje de reticulocitos | 1,0% a 1,5% | % de GR totales | Tasa activa de producción y recambio de hematíes en la médula ósea. |
| Hemoglobina (Varones) | 14,0 a 16,5 | g/dL | Contenido proteico absoluto transportador de oxígeno en sangre total. |
| Hemoglobina (Mujeres) | 12,0 a 15,0 | g/dL | Concentración total de hemoglobina disponible para perfusión tisular. |
| Hematocrito (Varones) | 40% a 50% | % | Fracción de volumen ocupada por la masa globular en 100 mL de plasma. |
| Hematocrito (Mujeres) | 37% a 47% | % | Relación volumétrica porcentual entre eritrocitos y plasma circulante. |
| Volumen corpuscular medio (VCM) | 85 a 100 (rango extendido 83 a 97) | fL | Volumen físico promedio individual de cada glóbulo rojo. |
| Concentración de Hb corpuscular media (CHCM) | 31 a 35 | g/dL | Concentración interna de hemoglobina por unidad de volumen eritrocitario. |
| Hemoglobina celular media (HCM) | 27 a 34 | pg/célula | Masa o peso absoluto promedio de hemoglobina contenida en cada eritrocito. |

### Síndrome anémico y mecanismos compensadores:
- **Definición fisiopatológica de anemia**: Estado hemodinámico caracterizado por la disminución en el número de glóbulos rojos circulantes o una concentración anormalmente baja de hemoglobina, reduciendo la capacidad de transporte de oxígeno hacia los tejidos.
  - **Mecanismos primarios desencadenantes**:
    - **Pérdida sanguínea acelerada**: Extravasación aguda o crónica del compartimiento intravascular.
    - **Hemólisis eritrocitaria**: Destrucción prematura intracorpuscular o extracorpuscular con acortamiento patológico de la vida media.
    - **Producción medular deficiente**: Fracaso cuantitativo de la proliferación por hipoplasia de médula ósea o por carencia de elementos nutricionales esenciales como hierro y vitaminas.
  - **Manifestaciones clínicas derivadas de la hipoxia tisular**:
    - **Hipoxia muscular y periférica**: Fatiga crónica, debilidad muscular generalizada, disnea de esfuerzo y claudicación de la reserva coronaria en forma de angina de pecho.
    - **Hipoxia del sistema nervioso central**: Cefalea pulsátil, mareos ortostáticos o inestabilidad postural y visión borrosa por hipoperfusión retiniana.
  - **Mecanismos fisiopatológicos compensadores**:
    - **Afinidad de la hemoglobina por el oxígeno**: Se incrementa la síntesis intraeritrocitaria de 2,3-difosfoglicerato, lo que desplaza la curva de disociación hacia la derecha e incrementa la capacidad de la hemoglobina para ceder oxígeno a los tejidos periféricos que sufren anoxia.
    - **Redistribución del flujo sanguíneo**: Se produce una vasoconstricción periférica selectiva en órganos con menor demanda crítica como la piel y los lechos renales, redirigiendo el gasto hacia la circulación coronaria y cerebral; este fenómeno determina la palidez mucocutánea visible en piel, conjuntivas y lechos ungueales.
    - **Aumento del gasto cardíaco y respuesta hiperdinámica**:
      - *Umbral hemodinámico*: Se activa de forma pronunciada cuando la hemoglobina desciende por debajo de 100 g/L (10,0 g/dL o 6,21 mmol/L).
      - **Mecanismo**: La caída de la masa eritrocitaria reduce la viscosidad sanguínea y las resistencias vasculares periféricas con un incremento mediado por la actividad del óxido nítrico; esta reducción de la poscarga se asocia a un aumento de la precarga y a un estímulo inotrópico y cronotrópico simpático directo, generando taquicardia refleja y palpitaciones.
    - **Respuesta eritropoyética renal**: La anoxia renal y extrarrenal estimula de forma prioritaria la transcripción del gen de la eritropoyetina para forzar la hiperplasia eritroide en la médula ósea si esta mantiene su viabilidad.

### Clasificación etiopatogénica y morfológica de las anemias:
- **Clasificación según la cinética eritropoyética medular**:
  - **Anemias regenerativas o periféricas**: La médula ósea se encuentra sana y responde de forma vigorosa elevando la producción de hematíes con reticulocitosis marcada superior a los valores basales, característica observada tras hemorragias agudas o en procesos de destrucción hemolítica acelerada (por defectos enzimáticos, hemoglobinopatías, tóxicos, infecciones o procesos inmunes).
  - **Anemias arregenerativas o centrales**: La médula ósea es incapaz de generar una respuesta adecuada y mantiene un recuento de reticulocitos bajo o normal a pesar de la anemia severa; obedece a lesiones de las células madre pluripotenciales (aplasia medular), invasión medular por células neoplásicas (leucemias, linfomas) o a carencias metabólicas de sustratos eritropoyéticos esenciales.
- **Clasificación según índices eritrocitarios morfológicos**:
  - **Anemias microcíticas e hipocrómicas**:
    - *Umbral*: VCM inferior a 83 fL y/o HCM menor a 27 pg.
    - **Etiologías principales**: Anemia ferropénica por depleción de depósitos de hierro, talasemias por defecto en las cadenas de globina, casos seleccionados de anemia sideroblástica, intoxicación por plomo o aluminio y fases avanzadas de anemia de enfermedades crónicas.
  - **Anemias normocíticas**:
    - *Umbral*: VCM dentro de límites estándar entre 83 y 97 fL.
    - **Etiologías principales**: Anemia de las enfermedades crónicas en la gran mayoría de casos, anemias hemolíticas (cuando no existe un componente desmedido de reticulocitosis), aplasia medular primaria, pérdidas sanguíneas en etapas agudas iniciales e infiltración medular neoplásica.
  - **Anemias macrocíticas**:
    - *Umbral*: VCM marcadamente superior a 97 fL.
    - **Etiologías principales**: Anemias megaloblásticas por deficiencia de vitamina B12 o folatos, alcoholismo crónico, hepatopatías avanzadas, síndromes mielodisplásicos, estados de reticulocitosis masiva (los reticulocitos poseen un tamaño superior al eritrocito senescente), hipotiroidismo y algunos subtipos de aplasia medular.

## Correlación clínico-patológica y análisis de casos:
### Caso clínico 1 - Púrpura trombocitopénica inmunitaria aguda en pediatría:
- **Perfil de la paciente**: Niña de 6 años de edad que presenta un cuadro súbito de 48 horas de evolución consistente en petequias diseminadas en torso y miembros inferiores y equimosis espontáneas de 2 a 3 cm en brazos y muslos, manteniéndose afebril y activa.
  - **Antecedentes relevantes**: Episodio de infección respiratoria de vías aéreas superiores (resfriado común) hace 3 semanas con resolución espontánea completa.
  - **Hallazgos físicos**:
    - **Piel**: Múltiples petequias que no desaparecen a la vitropresión y tres equimosis en miembros, sin evidencia de otros traumatismos.
    - **Ausente**: Sangrado activo en fosas nasales (epistaxis), encías (gingivorragia) o paladar; no presenta visceromegalias a la palpación ni adenomegalias palpables.
  - **Laboratorio hematológico**:
    - Hemoglobina: 12,8 g/dL (normal).
    - Leucocitos: 6.500/mm³ con fórmula leucocitaria diferencial conservada.
    - Plaquetas: 9.000/mm³ (trombocitopenia grave con valor basal esperado de 150.000 a 450.000/mm³).
    - Frotis sanguíneo: Confirma marcada escasez de plaquetas con presencia aislada de macroplaquetas.
  - **Diagnóstico diferencial**:
    - **Criterio discriminador**: Afectación clonal multilínea frente a citopenia unilínea pura autolimitada.
      - **Leucemia aguda o anemia aplásica**: Se acompañan de anemia, leucopenia o blastos anormales periféricos, asociados a dolor óseo, fiebre o hepatoesplenomegalia.
      - **Púrpura trombocitopénica inmunitaria aguda**: Cursa estrictamente con trombocitopenia aislada severa en una paciente con serie roja y serie blanca rigurosamente normales tras un cuadro viral previo.
  - **Conducta y manejo terapéutico**:
    - **Régimen de ingreso**: Hospitalización preventiva para observación continua y reposo físico relativo estricto para evitar traumatismos craneoencefálicos accidentales que puedan desencadenar sangrado cerebral ante un recuento menor a 20.000/µL.
    - **Tratamiento farmacológico**:
      - *Esquema*: Prednisona a dosis de 2 mg/kg/día por vía oral.
      - *Justificación*: Inducir la inhibición de la destrucción esplénica de plaquetas opsonizadas y modular la respuesta autoinmune mediada por células T.
    - **Contraindicaciones absolutas**: Prohibición estricta de ácido acetilsalicílico (AAS) y otros AINE para no anular la actividad plaquetaria residual; contraindicación formal de inyecciones intramusculares por riesgo de hematomas musculares masivos.
    - **Evolución a las 72 horas y sospecha de complicación**: La paciente desarrolla dolor abdominal agudo con defensa involuntaria, requiriendo ecografía abdominal (criterio de hepatomegalia: lóbulo hepático derecho longitudinal > 15,5 a 16 cm) o tomografía computarizada para descartar hematomas retroperitoneales o hemoperitoneo espontáneo.

### Caso clínico 2 - Anemia carencial mixta (Ferropenia y déficit de vitamina B12):
- **Perfil de la paciente**: Mujer de 48 años con dieta vegana estricta de 5 años de evolución sin suplementación farmacológica de cobalamina, que asocia pérdidas ginecológicas menstruales excesivas (menorragia) en los últimos 8 meses.
  - **Manifestaciones clínicas**: Fatiga invalidante, mareos ortostáticos marcados, caída del cabello, disnea de esfuerzo y palidez cutaneomucosa evidente al examen físico.
  - **Compromiso neurológico**: Disminución en la sensibilidad vibratoria (palestesia) en extremidades inferiores compatible con desmielinización de los cordones posteriores de la médula espinal por falta prolongada de vitamina B12.
  - **Laboratorio hematimétrico y de reservas**:
    - Hemoglobina: 8,2 g/dL (anemia moderada a severa).
    - VCM: 104 fL (macrocitosis con referencia de 80 a 100 fL).
    - Hierro sérico: 30 µg/dL (marcadamente bajo).
    - Ferritina sérica: 6 ng/mL (depleción crítica de depósitos corporales frente al intervalo normal de 70 a 120 ng/mL).
    - Vitamina B12: 110 pg/mL (deficiencia franca con normal esperado > 200 pg/mL).
    - Ácido fólico: En niveles normales.
  - **Fisiopatología del cuadro mixto**: La carencia de cobalamina detiene la síntesis adecuada de timidilato en el ADN eritroblástico, provocando asincronía núcleo-citoplasmática y generando hematíes macrocíticos con VCM elevado; al mismo tiempo, el sangrado menorrágico continuo agota las reservas de hierro, pero el índice volumétrico permanece enmascarado hacia la macrocitosis por el predominio metabólico del déficit vitamínico.
  - **Tratamiento**:
    - **Reposición de vitamina B12**: Hidroxocobalamina intramuscular en dosis de carga inicial continuada de forma mensual para revertir el daño medular y detener la degeneración de los cordones neuronales posteriores.
    - **Suplementación férrica**: Sulfato ferroso por vía oral una vez estabilizada la síntesis celular dependiente de B12 para repletar la ferritina tisular.
    - **Control etiológico**: Evaluación ginecológica especializada para cohibir el sangrado endometrial disfuncional.

### Caso hematológico integrado - Infiltración leucémica con pancitopenia periférica:
- **Perfil de laboratorio (Max Lab)**: Paciente masculino de 24 años evaluado mediante hemograma completo automatizado con confirmación microscópica de lámina periférica.
  - **Serie roja (Anemia macrocítica hipoproliferativa)**:
    - Recuento eritrocitario: 1,42 × 10⁶/mm³ (depleción profunda frente a 4,1 a 5,9 × 10⁶).
    - Hemoglobina: 5,6 g/dL (anemia severa con indicación transfusional inminente frente al normal de 12,5 a 17,0 g/dL).
    - Hematocrito: 15,6% (marcadamente reducido).
    - VCM: 109,9 fL (macrocitosis franca).
    - HCM: 39,4 pg y CHCM: 35,9 g/dL.
    - Frotis morfológico: Presencia notable de Rouleaux eritrocitario y anisocitosis con RDW del 16,4%.
  - **Serie blanca (Transformación clonal blástica)**:
    - Recuento de leucocitos totales: 8.300/mm³ (dentro del rango global de 3.600 a 10.000/mm³).
    - Blastos periféricos: 28% con valor absoluto de 2.324/mm³ (presencia patológica extrema de células inmaduras donde lo normal es 0%).
    - Células precursoras mieloides: Promielocitos 2% (166/mm³), mielocitos 3% (249/mm³), metamielocitos 6% (498/mm³) y bastones 13% (1.079/mm³).
    - Células maduras: Segmentados neutrófilos 23% (1.909/mm³), linfocitos típicos 22% (1.826/mm³), linfocitos reactivos 1% (83/mm³) y monocitos 2% (166/mm³).
    - Ausente: Eosinófilos (0%) y basófilos (0%).
  - **Serie plaquetaria**: Recuento de 60.000/mm³ (trombocitopenia moderada a grave frente al rango de 150.000 a 450.000/mm³) con volumen plaquetario medio (VPM) en 9,3 fL.
  - **Fisiopatología de la correlación cruzada**:
    - **Infiltración medular**: La presencia de un 28% de blastos periféricos (umbral diagnóstico superior al 20% para neoplasia mieloide aguda) demuestra una proliferación clonal descontrolada que reemplaza físicamente la celularidad hematopoyética en la médula ósea.
    - **Fallo simultáneo de la hemostasia y de la masa globular**: La ocupación del nicho medular frena la megacariopoyesis, provocando la trombocitopenia observada (60.000/mm³), y suprime la línea eritroide, originando la anemia severa arregenerativa con hemoglobina crítica de 5,6 g/dL; esto unifica directamente los mecanismos de fallo de producción de la hemostasia primaria con las anemias centrales hipoproliferativas por invasión tisular.