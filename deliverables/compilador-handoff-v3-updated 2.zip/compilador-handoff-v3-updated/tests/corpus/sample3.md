# Atención Primaria de la Salud y Medicina Familiar:

## Conceptos fundamentales en salud y enfermedad:

### Salud:
- **Definición**: Estado de completo bienestar físico, mental y social.
- **Ausente**: Ausencia exclusiva de afecciones o enfermedades como criterio suficiente de salud.
- **Dimensión física**: Expresa buen estado fisiológico y funcional orgánico.
- **Dimensión mental**: Abarca aspectos psicológicos y emocionales del individuo.
- **Dimensión social**: Modula el bienestar mediante la influencia del entorno comunitario.
- **Determinantes de la salud**:
  - **Factores biológicos**: Integran carga genética y edad intrínseca de la persona.
  - **Factores ambientales**: Agrupan agentes infecciosos, polución, variaciones climáticas y entorno físico.
  - **Estilo de vida**: Comprende regímenes alimentarios, ejercicio físico, consumo de sustancias tóxicas, ocupación laboral y conductas de riesgo.
  - **Salud pública**: Engloba recursos del sistema sanitario, cobertura institucional, talento humano e inventario farmacológico.

### Enfermedad:
- **Definición**: Desviación del estado fisiológico en regiones corporales específicas, secundaria a etiologías generalmente identificables.
- **Manifestación clínica**: Cursa con semiología característica compuesta por signos y síntomas verificables.
- **Pronóstico**: Presenta evolución temporal previsible.
- **Afectación sistémica**: Altera el funcionamiento corporal tanto en el plano biológico como en el plano psíquico.

### Salud holística:
- **Definición**: Modelo multidimensional que concibe a la persona como una unidad integral indivisible.
- **Ejes integradores**: Evalúa componentes físicos, intelectuales, sociales, emocionales y espirituales.
- **Mecanismo operativo**: Integra equilibrio homeostático corporal, balance de energía vital y determinantes ambientales.
- **Campo de intervención**: Trata dolencias corporales musculoesqueléticas y cuadros psíquicos como angustia o depresión.
- **Intervenciones terapéuticas**: Articula herramientas médicas contemporáneas con fitoterapia, acupuntura y yoga.

| Atributo | Modelo Biomédico | Modelo Bio-psico-social | Umbral discriminador |
|---|---|---|---|
| Concepción de la enfermedad | Entidad aislada del individuo y su entorno social | Entidad inseparable del individuo y su medio ambiente | Grado de disociación contextual |
| Modelo de causalidad | Monocausal y dependiente de un patógeno específico | Multicausal y contextualizada en el individuo | Pluralidad de factores etiológicos |
| Objetivo clínico | Identificar patógeno y prescribir fármaco específico | Comprender la dolencia y el significado del síntoma | Dimensión hermenéutica aplicada |
| Rol del enfermo | Receptor pasivo y objeto de observación médica | Agente corresponsable activo de su propia salud | Grado de agencia terapéutica |
| Integración somatopsíquica | Trastornos psiquiátricos disociados de la patología somática | Patologías integradas con sustrato físico y mental simultáneo | Dualismo mente-cuerpo estricto |

## Atención Primaria de la Salud - APS:

### Principios y atributos funcionales:
- **Definición**: Asistencia sanitaria esencial fundada en métodos científicos prácticos, socialmente aceptables, universalmente accesibles y sostenibles económicamente.
- **Ausente**: Prestación sanitaria degradada, precarizada o reducida exclusivamente a sectores marginales.
- **Objetivo central**: Incrementar el nivel de salud poblacional articulando acciones multisectoriales.
- **Pilares de ejecución**:
  - **Participación social**: Moviliza activamente a la comunidad en la toma de decisiones sanitarias.
  - **Cobertura universal**: Aplica intervenciones preventivas y de promoción de la salud a la población total.
  - **Visita domiciliaria**: Ejecuta intervenciones extramurales periódicas lideradas por el agente comunitario de salud.
  - **Consulta programada**: Mantiene seguimiento ambulatorio clínico y odontológico estructurado.
  - **Intersectorialidad**: Coordina determinantes sanitarios con educación, vivienda, seguridad social y desarrollo comunitario.
- **Principios rectores de la APS**:
  - **Distribución equitativa**: Garantiza igualdad de acceso financiero y geográfico a las prestaciones.
  - **Participación comunitaria**: Transfiere capacidad resolutiva a la comunidad para gestionar su estado biológico y social.
  - **Tecnología apropiada**: Emplea procedimientos costo-efectivos, éticamente viables y culturalmente compatibles con la realidad local.
  - **Cooperación intersectorial**: Vincula metas sanitarias con planes productivos agrícolas, habitacionales y educativos.
  - **Accesibilidad integral**: Asegura ingreso funcional a servicios diagnósticos y terapéuticos sin barreras organizativas.
- **Atributos funcionales de la APS**:
  - **Primer contacto y accesibilidad**: Actúa como puerta de entrada mandatoria frente a condicionantes económicos o culturales.
  - **Coordinación asistencial**: Consolida la continuidad terapéutica articulando el sistema de referencia y contrarreferencia.
  - **Integralidad resolutiva**: Aborda intervenciones desde la prevención primaria hasta cuidados paliativos.
    - **Umbral de resolución ambulatoria**: Resuelve aproximadamente el 90% de las patologías en el nivel primario.
  - **Longitudinalidad**: Provee seguimiento clínico temporal prolongado centrado en la persona por el mismo equipo asistencial.
- **Componentes mínimos de Alma-Ata (1978)**:
  - **Educación sanitaria**: Difunde pautas pedagógicas comunitarias y medidas de promoción de la salud.
  - **Seguridad alimentaria**: Asegura abastecimiento nutricional suficiente y balance cualitativo de alimentos.
  - **Saneamiento básico**: Garantiza provisión de agua potable y control técnico de excretas o residuos.
  - **Atención materno-infantil**: Aplica programas de control obstétrico, del desarrollo pediátrico y salud reproductiva.
  - **Inmunizaciones**: Administra esquemas profilácticos contra enfermedades transmisibles prevalentes.
  - **Control de endemias**: Implementa protocolos de erradicación y contención de enfermedades infecciosas locales.
  - **Manejo de lesiones y enfermedades prevalentes**: Prescribe tratamientos clínicos directos ante cuadros prevalentes.
  - **Farmacopea esencial**: Distribuye fármacos prioritarios indispensables para la cobertura territorial.

### Estrategia de APS en Paraguay:
- **Estructura territorial y demográfica**:
  - **Unidad de Salud de la Familia (USF)**: Representa el dispositivo sanitario de contacto territorial del MSPBS.
  - **Cobertura familiar estándar**: Asigna 600 familias por cada dispositivo territorial instalado.
  - **Cobertura poblacional estándar**: Cubre un promedio de 3.500 individuos asignados a un territorio social definido.
- **Flujograma resolutivo y función de filtro en la red sanitaria**:
  - **Primer nivel asistencial**: Paciente consulta en USF (programada o demanda espontánea) → Médico de APS estratifica gravedad, urgencia y capacidad resolutiva → Trata la patología localmente si corresponde al primer nivel asistencial.
  - **Segundo nivel asistencial**: Médico de APS detecta complejidad clínica excedente de USF → Activa protocolo de referencia coordinada → Transfiere al paciente hacia el segundo nivel asistencial.
- **Equipo de Salud de la Familia (ESF)**:
  - **Composición del talento humano**:
    - **Médico/a de familia**: Lidera el proceso asistencial y la toma de decisiones diagnósticas.
    - **Odontólogo/a**: Gestiona la salud estomatológica preventiva y asistencial.
    - **Profesional de enfermería u obstetricia**: Ejecuta procedimientos clínicos y seguimiento obstétrico.
    - **Auxiliar técnico**: Desarrolla soporte operativo auxiliar en enfermería y odontología.
    - **Agente comunitario de salud**: Realiza el mapeo extramural y las visitas domiciliarias regulares.
    - **Licenciado/a en Psicología**: Brinda abordaje específico de la salud mental comunitaria e individual.
    - **Personal de soporte**: Gestiona procesos administrativos, de archivo y saneamiento de áreas comunes.
  - **Infraestructura física de la USF**:
    - **Área asistencial ambulatoria**: Dispone de consultorios diferenciados de medicina general, odontología y enfermería.
    - **Área crítica y de recuperación**: Alberga sala de urgencias y unidad de observación de corta estancia.
    - **Área de gestión y profilaxis**: Contiene admisión y archivo, vacunatorio y depósito farmacéutico oficial de la DGAPS.
    - **Área de servicios generales**: Integra sanitarios públicos, cocina y sector de lavandería de material.
- **Modelo de Atención Integral en Salud**:
  - **Definición**: Marco rector del MSPBS para vigilar, promocionar, prevenir, tratar y rehabilitar estados patológicos.
  - **Eje de pertinencia**: Incorpora adecuación cultural y perspectiva de género en todos los escalones de atención.
  - **Ausente**: Dinámica asistencialista fragmentada y verticalista del modelo predecesor.

## Medicina Familiar:

### Especialidad médica:
- **Definición**: Disciplina médica académica que brinda atención asistencial continua, preventiva e integral al individuo y a la familia.
- **Integración de saberes**: Fusiona ciencias biológicas, métodos clínicos, ciencias sociales y conductuales.
- **Alcance taxonómico**: Atiende sin restricción de género, estrato etario ni localización de órganos diana.
- **Ausente**: Fragmentación organicista del proceso mórbido.
- **Competencias funcionales del médico de familia**:
  - **Resolución clínica**:
    - **Umbral de resolución clínica**: Resuelve > 80% de los motivos de consulta ambulatoria basándose en evidencia científica.
    - **Población diana**: Provee cobertura longitudinal pediátrica, de adolescentes, adultos, gerontes y personas gestantes.
  - **Intervención familiar**: Diagnostica y asesora unidades familiares expuestas a vulnerabilidad biopsicosocial.
  - **Emergencias**: Realiza soporte vital y maniobras de estabilización inicial en el primer nivel asistencial.
  - **Gestión sanitaria**: Ejecuta tareas operativas en programas sanitarios y políticas de salud pública.
  - **Educación comunitaria**: Transmite información sobre prevención sanitaria a usuarios, núcleos familiares y entornos comunitarios.
- **Atributos de la práctica clínica del médico familiar**:
  - **Centrada en la persona**: Subordina el plan terapéutico a los valores, necesidades y cosmovisiones del usuario.
  - **Atención personalizada**: Adapta las directrices clínicas a la realidad biológica e individual evitando la protocolización rígida.
  - **Flexibilidad organizativa**: Modifica la frecuencia y modalidad de asistencia según la evolución del caso clínico.
  - **Despliegue domiciliario**: Traslada la intervención clínica al domicilio para evaluar el contexto de habitabilidad y funcionalidad.
  - **Enfoque bio-psico-social**: Integra la estructura relacional familiar en el curso de la patología y la adhesión terapéutica.
  - **Navegación asistencial**: Coordina y conduce el tránsito del usuario por los distintos niveles de complejidad del sistema sanitario.

### Relación médico-paciente:
- **Entrevista clínica**:
  - **Métricas de práctica profesional y epidemiología comunicacional**:
    - **Carga asistencial del médico de familia**: Realiza entre 200 000 y 400 000 consultas durante una vida profesional de 40 años.
    - **Frecuencia de intervención**: Constituye la intervención médica ejecutada con más frecuencia en la práctica clínica.
  - **Brechas en el proceso de la entrevista médica clásica**:
    - **Interrupción inicial del paciente**: Ocurre en promedio a los 18 segundos del relato del problema actual.
    - **Omisión de esfera psicosocial y psiquiátrica**: Médicos omiten el 50% de los problemas psicosociales y psiquiátricos.
    - **Falta de registro de motivos de consulta**: Médico no toma en cuenta el 54% de los problemas de consulta.
    - **Falta de registro de preocupaciones**: Médico no toma en cuenta el 45% de las preocupaciones del paciente, o este no las expresa.
    - **Discordancia de motivo principal**: Pacientes y médicos no coinciden en el problema principal de la consulta en el 50% de los casos.
    - **Sesgo de estimación de tiempo explicativo**: Médicos sobrestiman hasta en un 90% el tiempo dedicado a la explicación y pronóstico.
    - **Tasa de incumplimiento terapéutico**: Cerca del 50% de los pacientes no toma los medicamentos prescritos o los administra incorrectamente.
    - **Consecuencia médico-legal**: La ruptura comunicacional entre paciente y profesional constituye un factor crítico causante de demandas por mala praxis.

| Atributo | Paradigma clásico | Modelo biopsicosocial | Umbral discriminador |
|---|---|---|---|
| Enfoque directivo | Centrado en el profesional y la enfermedad | Centrado en el paciente, familia y entorno | Involucramiento activo del paciente en decisiones terapéuticas |
| Objetivo central | Diagnosticar la patología e indicar tratamiento farmacológico | Comprender e intervenir sobre factores biológicos y psicosociales integrados | Reconocimiento explícito de vivencias y dinámicas vinculares |
| Recolección diagnóstica | Preguntas cerradas; inhibición de ideas y expectativas del consultante | Preguntas abiertas; exploración activa de creencias y preocupaciones | Exploración de conocimientos, dudas y temores del enfermo |
| Intervención en seguimiento | Pérdida de relevancia del soporte conductual posdiagnóstico | Diseño colaborativo de planes para sostener cambios a lo largo del tiempo | Acuerdos negociados y chequeo de entendimiento en la prescripción |

- **Paradigma clásico**:
  - **Definición**: Postula la observación médica objetiva externa sobre el paciente para diagnosticar y pautar el tratamiento biológico.
  - **Mecanismo de falla terapéutica**: Enfoque centrado en el médico → elusión e inhibición de las ideas del paciente → discordancia clínica no identificada → deserción y falla en adherencia conductual prolongada.
  - **Disparidad de prioridades informativas**:
    - **Prioridad del paciente**: Demanda información diagnóstica, etiológica y pronóstica.
    - **Prioridad atribuida por el médico**: Asume erróneamente mayor demanda sobre farmacoterapia e intervenciones.
- **Modelo biopsicosocial**:
  - **Definición**: Paradigma propuesto por George Engel que equipara e integra la relevancia de los factores biológicos y psicosociales en el proceso de salud-enfermedad.
  - **Estratificación multinivel del caso clínico ejemplar**:
    - **Nivel de órganos y sistemas**: Diagnóstico de asma bronquial con exacerbaciones graves repetidas.
      - *Parámetro*: 4 internaciones previas por crisis asmática refractaria a los 13 años.
    - **Nivel personal**: Falta de autonomía individual en la autoadministración inhalatoria.
      - **Ausente**: Autogestión del aerosol por parte del paciente a la edad esperada.
    - **Nivel familiar**: Incapacidad de resolución de conflictos en el subsistema parental encubierta por la crisis física.
  - **Disfunciones de aplicación clínica**:
    - **Disociación teoría-práctica**: Atención médica fragmentada enfocada en problemas aislados sin integración psicosocial.
    - **Fijación reduccionista**: Abordaje médico limitado a fijación somática exclusiva o psicológica exclusiva sin visión integral.
- **Habilidades de comunicación clínica y desenlaces asistenciales**:
  - **Demora de la interrupción inicial**: Esperar mayor tiempo para interrumpir al paciente al inicio → identificación completa del motivo de consulta → prevención de tópicos emergentes al cierre.
  - **Interrogatorio con preguntas abiertas y escucha activa**: Estimula la exteriorización de preocupaciones complejas y maximiza la obtención de datos clínicos.
  - **Comunicación no verbal empática**: Contacto visual directo, postura orientada, inclinación cefálica, distancia interpersonal adecuada y modulación prosódico-facial aumentan la satisfacción del paciente.
  - **Técnica de reformulación por el paciente**: Solicitar al paciente que repita las indicaciones médicas con sus propias palabras aumenta la retención y comprensión de las instrucciones.
  - **Trato empático y negociación**: Trato cordial con aclaración del fundamento terapéutico → elevación del cumplimiento del tratamiento.
- **Diagnóstico diferencial**:
  - **Criterio de discriminación**: Impacto de la esfera emocional en la resolución de la cefalea crónica
    - **Manejo enfocado en desahogo inicial**: La resolución sintomática correlaciona con la expresión de sentimientos sobre la patología durante la primera consulta.
    - **Manejo técnico aislado**: La resolución sintomática no guarda correlación preponderante con el diagnóstico aislado, estudios paraclínicos, prescripción o derivación especializada.
    - *Umbral*: Expresión activa de vivencias emocionales en la consulta de apertura.

### Familia como unidad de atención:
- **Definición**: Es la unidad básica de la sociedad conformada por individuos vinculados por parentesco consanguíneo, legal o afectivo que cohabitan por tiempo indefinido.
- **Tipología de vínculos familiares**:
  - **Vínculo consanguíneo**: Une a padres, hermanos, hijos y nietos.
  - **Vínculo por afinidad**: Une al cónyuge y a sus consanguíneos.
  - **Vínculo por vía legal**: Establece relaciones filiales mediante adopción o matrimonio.
  - **Vínculo afectivo**: Determina lazos de convivencia y reciprocidad relacional.
- **Dimensiones operativas familiares**:
  - **Convivencia y roles**: Asigna posiciones fijas intrahogar delimitadas como padre, madre o hermanos.
  - **Modo de vida**: Articula la organización social y el régimen económico compartido.
  - **Salud**: Constituye el entorno natural y la unidad de análisis de la salud familiar.
- **Taxonomía de la estructura familiar**:
  - **Familia nuclear**: Padres e hijos integran el núcleo conviviente tradicional.
  - **Familia extendida**: Parientes consanguíneos o afines cohabitan con padres, hijos, abuelos, tíos y primos.
  - **Familia monoparental**: Un solo progenitor convive con sus hijos.
  - **Familia homoparental**: Parejas del mismo sexo conviven con hijos biológicos o adoptivos.
  - **Familia ensamblada**: Dos o más familias se agregan incorporando hijos de uniones previas.
  - **Familia adoptiva**: Progenitores crían hijos sin nexo biológico consanguíneo.
  - **Familia de acogida**: Adultos asumen la tutela legal transitoria de menores.
  - **Familia con padres separados**: Progenitores disuelven la convivencia y distribuyen la custodia en modalidad única o alternada.
  - **Familia sin hijos**: Parejas prescinden de descendencia por infertilidad o por elección voluntaria.

### Familiograma estructural y dinámico:
- **Definición**: Es la representación gráfica estructurada de la composición familiar y de los patrones interaccionales intergeneracionales.
- **Evaluación de riesgos biopsicosociales**:
  - **Riesgo biológico**: Patologías y factores hereditarios transmisibles.
  - **Riesgo psicológico**: Disfuncionalidad en la dinámica intrafamiliar.
  - **Riesgo social**: Condiciones de pobreza y hacinamiento por familia numerosa.
- **Dominio de datos compilados**:
  - **Composición familiar**: Identifica la totalidad de los miembros del sistema.
  - **Relaciones biológicas y legales**: Registra uniones conyugales, matrimonios, separaciones y divorcios.
  - **Relaciones interpersonales**: Grafica la dinámica afectiva y el tono vincular directo.
  - **Eventos biopatográficos**: Detalla patologías médicas, causas de defunción, violencia y suicidio.
- **Campos de utilidad clínica**:
  - **Función diagnóstica**: Revela patologías y problemas biopsicosociales ocultos.
  - **Función preventiva**: Detecta vulnerabilidades y riesgos familiares de forma temprana.
  - **Función terapéutica**: Proyecta a la familia su configuración sistémica global.
  - **Función de registro**: Documenta etapas del ciclo vital y recursos protectores disponibles.
- **Parámetros operativos de confección**:
  - **Tiempo de ejecución**: 15 a 20 minutos requeridos para el trazo basal.
  - **Estrategia longitudinal**: Construcción progresiva a lo largo de consultas sucesivas en atención primaria.
- **Simbología estandarizada del genograma**:
  - **Identificación individual y demográfica**:
    - **Representación por sexo y género**:
      - Masculino: Se representa con un cuadrado.
      - Femenino: Se representa con un círculo.
      - Hombre o mujer homosexual: Se representa inscribiendo un triángulo dentro de la figura geométrica de base.
      - Hombre o mujer bisexual: Se representa inscribiendo dos triángulos superpuestos dentro de la figura de base.
      - Transgénero de hombre a mujer: Se representa con un cuadrado circunscrito por un círculo externo.
      - Transgénero de mujer a hombre: Se representa con un círculo circunscrito por un cuadrado externo.
    - **Sujeto de consulta**:
      - **Criterio de señalamiento**: Doble línea perimetral delimita el símbolo de la persona índice.
      - **Término de la fuente**: Sujeto principal.
    - **Registro cronológico y mortalidad**:
      - **Mortalidad**: Una cruz en aspa (X) en el interior del símbolo indica defunción.
      - **Edad de fallecimiento**: Se inscribe al interior del símbolo marcado con X.
      - **Posición temporal de nacimiento**: Se ubica a la izquierda exterior del símbolo.
      - **Posición temporal de defunción**: Se ubica a la derecha exterior del símbolo.
      - **Genograma extendido**: Símbolos de generaciones remotas prescinden de cruz en aspa salvo defunciones de relevancia clínica.
      - **Umbral intergeneracional**: Se aplica a tres o más generaciones documentadas.
  - **Marcadores patológicos individuales**:
    - **Consumo de sustancias y trastornos graves**:
      - Abuso confirmado de alcohol o sustancias: Cuadrante inferior izquierdo sombreado de negro.
      - Sospecha de abuso de alcohol o sustancias: Mitad inferior sombreada con línea punteada.
      - Problema mental o físico grave: Mitad superior completamente sombreada.
      - Patología combinada: Relleno total del símbolo por adicción y trastorno grave simultáneos.
      - Recuperación de adicciones: Mitad inferior sombreada bisecada por una línea vertical central.
  - **Uniones conyugales y filiación**:
    - **Eje de pareja**:
      - Matrimonio: Línea continua horizontal descendente que sitúa al varón a la izquierda y a la mujer a la derecha.
      - Notación de matrimonio: Letra «M» o «m.» antecede a los últimos dos dígitos del año de enlace.
      - Convivencia o unión libre: Línea discontinua horizontal conecta a la pareja no casada.
      - Notación de cohabitación: Letra «C» o «c.» antecede a la fecha de inicio de cohabitación.
      - Separación conyugal: Una línea oblicua cruza transversalmente la línea de unión.
      - Notación de separación: Letra «s.» antecede al año de la disrupción.
      - Divorcio: Dos líneas oblicuas paralelas cruzan transversalmente la línea de unión.
      - Notación de divorcio: Letra «d.» antecede al año de resolución legal.
    - **Uniones múltiples sucesivas**:
      - Regla de ordenamiento: Se disponen cronológicamente de izquierda a derecha situando la relación más reciente en el extremo final.
      - Poliandria serial o uniones sucesivas de la mujer: La figura femenina central proyecta líneas hacia cónyuges previos a la izquierda y posteriores a la derecha.
      - Poligamia serial o uniones sucesivas del hombre: La figura masculina proyecta enlaces sucesivos de izquierda a derecha hacia sus parejas secuenciales.
      - Múltiples parejas de ambas partes: Las uniones previas de cada miembro se ubican lateralmente hacia los extremos, dejando la unión vigente al centro.
    - **Líneas de filiación y descendencia**:
      - Orden de nacimiento: Los hijos cuelgan verticalmente de la línea de unión y se ordenan de izquierda a derecha desde el primogénito hasta el menor.
      - Embarazo: Se grafica con un triángulo equilátero.
      - Mortinato:
        - **Definición**: Muerte fetal en el parto.
        - **Término de la fuente**: Muerte al nacer.
        - **Criterio gráfico**: Símbolo geométrico habitual de tamaño reducido con una X en su interior.
      - Aborto espontáneo: Círculo sólido relleno de color negro.
      - Aborto inducido: Cruz en aspa pequeña sin marco geométrico.
      - Hijo adoptivo: Línea de conexión discontinua cuelga desde la barra conyugal.
      - Mellizos: Dos ramas divergentes nacen de un único punto de la línea de unión parental.
      - Gemelos monocigóticos: Dos ramas nacen de un punto común de la unión y se conectan entre sí por un segmento horizontal intermedio.
      - Método alternativo para familias numerosas: Una sola rama vertical desciende de la unión conyugal y se bifurca en una barra horizontal colectiva desde la cual cuelgan todos los descendientes.
  - **Dinámica relacional y límites del hogar**:
    - **Padrón de relaciones interpersonales**:
      - Muy estrecha: Tres líneas continuas paralelas interconectan ambos símbolos.
      - Cercana: Dos líneas continuas paralelas interconectan ambos símbolos.
      - Distante: Línea horizontal discontinua simple conecta a ambos miembros.
      - Conflictiva: Línea continua en zigzag interconecta a ambos miembros.
      - Muy estrecha pero conflictiva: Línea continua en zigzag superpuesta con dos líneas continuas paralelas.
      - Quiebre relacional: Línea horizontal continua interrumpida en su centro por dos barras verticales espaciadas.
    - **Delimitación de la cohabitación**:
      - Línea de convivencia: Cerco perimetral de línea discontinua rodea exclusivamente a los convivientes bajo el mismo techo.
      - Propiedad de sistema abierto: El trazo punteado ilustra el intercambio constante entre el sistema familiar y el medio externo.
    - **Grado epistemológico de los vínculos**:
      - Nivel inferencial: Las líneas relacionales expresan hipótesis derivadas de las narrativas familiares y la observación clínica directa.
