# Sistema hematológico:

## Trastornos hemostáticos y diátesis hemorrágicas:

### Fisiopatología plaquetaria y trombocitopenia:
- **Concepto clave**: Los defectos plaquetarios derivan de fallas cuantitativas o cualitativas en el tapón hemostático primario[cite: 1].
  - **Clasificación**: Tres mecanismos primarios provocan deficiencia plaquetaria periférica[cite: 1].
    - **Disminución de la producción**: La médula ósea pierde capacidad proliferativa o sufre supresión directa de megacariocitos[cite: 1].
    - **Destrucción acelerada**: La pérdida periférica de plaquetas supera la tasa máxima de liberación medular[cite: 1].
    - **Disfunción plaquetaria**: El recuento de plaquetas permanece normal, pero la adhesión y la agregación fallan[cite: 1].
  - **Presentación cardinal**: Las manifestaciones clínicas predominan como sangrados característicos en microvasos de piel y mucosas[cite: 1].
    - **Hemorragia mucosa espontánea**: El sangrado afecta las mucosas nasales, cavidad oral, tubo digestivo y aparato genital femenino[cite: 1].
    - **Manifestaciones cutáneas**: Las lesiones purpúricas asientan en zonas con mayor presión hidrostática intravascular[cite: 1].
      - **Petequias**: Pequeñas hemorragias puntiformes cutáneas surgen casi de forma exclusiva por déficit numérico plaquetario[cite: 1].
        - *Trampa de examen*: La disfunción plaquetaria funcional no suele manifestarse con petequias típicas[cite: 1].
      - **Púrpura y equimosis**: Confluencias de sufusiones hemorrágicas superficiales predominan en miembros inferiores por efecto gravitacional[cite: 1].
  - **Complicación temida**: La hemorragia intracraniana actúa como evento fatal en cuadros con depleción plaquetaria extrema[cite: 1].
  - **Criterio diagnóstico**: El diagnóstico de trombocitopenia exige un recuento plaquetario inferior a 150.000/μL[cite: 1].
    - **Fisiopatología esencial**: Tres vías fisiopatológicas principales rompen el equilibrio homeostático plaquetario[cite: 1].
      - **Supresión medular**: La aplasia medular, infiltración leucémica, radioterapia, quimioterapia o infección por VIH destruyen el nicho megacariocítico[cite: 1].
      - **Secuestro esplénico**: El bazo retiene una fracción anormalmente alta de plaquetas circulantes[cite: 1].
        - *Reserva fisiológica esplénica*: El bazo retiene habitualmente entre 30% y 40% de las plaquetas corporales totales[cite: 1].
        - *Retención en esplenomegalia*: El bazo hipertrófico secuestra hasta 90% de la masa plaquetaria circulante[cite: 1].
      - **Reducción de sobrevida periférica**: Prótesis valvulares mecánicas, hipertensión arterial acelerada-maligna o coagulopatías consumen plaquetas prematuramente[cite: 1].

### Trombocitopenias inmunitarias e inducidas por fármacos:
- **Trombocitopenia inducida por fármacos**: Anticuerpos dependientes de fármacos median la lisis plaquetaria accidental[cite: 1].
  - **Fármacos desencadenantes**: La quinina, quinidina y antibióticos derivados de sulfonamidas activan la respuesta inmune[cite: 1].
  - **Fisiopatología esencial**: El fármaco se une a la membrana plaquetaria y crea un neoantígeno híbrido[cite: 1].
    - **Progresión de la lisis**: El neoantígeno híbrido induce la síntesis de anticuerpos específicos[cite: 1].
      - **Fijación de complemento**: Los anticuerpos específicos fijan el sistema de complemento sobre la superficie celular[cite: 1].
        - *Desenlace lítico*: El sistema de complemento ensamblado produce lisis plaquetaria intravascular inmediata[cite: 1].
  - **Cinética temporal**: La temporalidad depende del contacto inmunológico previo con la molécula agresora[cite: 1].
    - **Primera exposición**: El sistema inmune requiere una latencia de 7 o más días para montar la respuesta humoral[cite: 1].
    - **Reexposición**: El reingreso del fármaco desencadena una caída celular abrupta en 2 a 3 días[cite: 1].
  - **Conducta inmediata**: La suspensión inmediata del fármaco agresor restituye con rapidez el recuento plaquetario normal[cite: 1].
- **Trombocitopenia inducida por heparina**: El tratamiento anticoagulante con heparina genera una complicación protrombótica paradójica[cite: 1].
  - **Punto de corte crítico**: El cuadro afecta aproximadamente al 10% de los pacientes y debuta entre 2 y 5 días de infusión[cite: 1].
  - **Fisiopatología esencial**: El fármaco se une al factor plaquetario 4 y genera el complejo heparina-PF4[cite: 1].
    - **Reconocimiento inmune**: El complejo heparina-PF4 estimula la síntesis de anticuerpos dirigidos[cite: 1].
      - **Activación plaquetaria**: Los anticuerpos dirigidos activan los receptores Fc de las plaquetas circulantes[cite: 1].
        - *Consecuencia clínica*: La activación continua de receptores Fc provoca trombosis paradójica con plaquetopenia leve a moderada[cite: 1, 2].
- **Púrpura trombocitopénica inmunitaria**: Una alteración autoinmune adquirida causa destrucción acelerada y producción medular insuficiente[cite: 1].
  - **Clasificación**: Dos subtipos etiológicos orientan el abordaje clínico del paciente[cite: 1].
    - **Forma primaria**: La trombocitopenia aislada aparece de forma idiopática sin ningún factor de riesgo subyacente[cite: 1].
    - **Forma secundaria**: El cuadro coexiste con VIH, hepatitis C, lupus eritematoso sistémico, síndrome antifosfolípido, leucemia linfocítica crónica, linfomas o sensibilización farmacológica[cite: 1].
  - **Fisiopatología esencial**: La pérdida de tolerancia inmune activa linfocitos T CD4 efectores y deteriora los linfocitos T reguladores[cite: 1].
    - **Síntesis de autoanticuerpos**: Los linfocitos activados liberan autoanticuerpos contra las glucoproteínas de membrana GPIIb/IIIa y GPIb/IX[cite: 1].
      - **Opsonización celular**: Las glucoproteínas unidas a autoanticuerpos marcan a las plaquetas como blancos fagocíticos[cite: 1].
        - *Fagocitosis esplénica*: Los macrófagos del estroma esplénico fagocitan prematuramente a las plaquetas opsonizadas[cite: 1].
  - **Disfunción de trombopoyetina**: Las concentraciones séricas de trombopoyetina permanecen normales o bajas, lo que impide la compensación medular[cite: 1].
  - **Presentación cardinal**: El paciente muestra petequias mucocutáneas y equimosis sin visceromegalia asociada[cite: 2].
    - **Criterio diagnóstico**: El frotis revela plaquetas aisladas inferiores a 20.000/μL sin otras series alteradas[cite: 2].

### Trombocitopatías y defectos de la coagulación:
- **Trombocitopatías**: La alteración cualitativa afecta la adhesión, activación o agregación plaquetaria con recuentos celulares normales o casi normales[cite: 1].
  - **Defectos hereditarios**: La enfermedad de von Willebrand representa la anomalía genética cardinal en la adhesión celular[cite: 1].
  - **Defectos adquiridos**: La uremia grave, la circulación extracorpórea o fármacos antiplaquetarios inducen disfunción plaquetaria secundaria[cite: 1].
    - **Ácido acetilsalicílico**: El fármaco acetila de forma irreversible la ciclooxigenasa-1 plaquetaria[cite: 1].
      - **Bloqueo sintético**: La acetilación irreversible de COX-1 anula la síntesis de tromboxano A2 durante toda la vida útil celular[cite: 1, 2].
    - **Antiinflamatorios no esteroideos**: Los agentes se unen de modo no covalente y reversible a la ciclooxigenasa[cite: 2].
      - **Restitución funcional**: La eliminación sistémica del fármaco recupera de inmediato la producción de tromboxano[cite: 2].
- **Coagulopatías plasmáticas**: La falla en la red de fibrina hemostática secundaria causa hematomas profundos, hemartrosis y hemorragias tras traumas[cite: 2].
  - **Formas hereditarias**: Tres entidades genéticas clásicas alteran la cascada hemostática[cite: 2].
    - **Enfermedad de von Willebrand**: Constituye la coagulopatía hereditaria más prevalente por déficit cuantitativo o cualitativo del factor de von Willebrand[cite: 2].
    - **Hemofilia A**: Una mutación congénita provoca la deficiencia funcional del factor VIII de la coagulación[cite: 2].
    - **Hemofilia B**: Una alteración monogénica condiciona la deficiencia funcional del factor IX de la coagulación[cite: 2].
  - **Formas adquiridas**: El fracaso orgánico múltiple desregula la síntesis de factores de la coagulación[cite: 2].
    - **Insuficiencia hepática**: El hepatocito disfuncional reduce la síntesis proteica de factores de la vía intrínseca y extrínseca[cite: 2].
    - **Deficiencia de vitamina K**: La falta del cofactor bloquea la carboxilación posraduccional de residuos de ácido glutámico en los factores II, VII, IX y X[cite: 2].
- **Trastornos vasculares**: La fragilidad estructural microvascular o el deterioro de la matriz de colágeno causan diátesis hemorrágica localizada[cite: 2].
  - **Telangiectasia hemorrágica hereditaria**: El defecto autosómico dilata arteriolas y capilares con paredes finas y tortuosas[cite: 2].
  - **Deficiencia de vitamina C**: El escorbuto altera la síntesis de fibrillas colágenas y debilita el cemento intercelular del endotelio[cite: 2].
  - **Síndrome de Cushing**: El exceso sostenido de glucocorticoides atrofia el colágeno tisular y retira el sostén mecánico perivascular[cite: 2].
  - **Púrpura senil**: El envejecimiento tisular colapsa la síntesis de matriz dérmica de colágeno y desencadena equimosis recurrentes[cite: 2].

### Coagulación intravascular diseminada:
- **Concepto clave**: Una activación descontrolada y difusa de la coagulación desencadena un síndrome trombohemorrágico sistémico[cite: 2].
  - **Etiologías desencadenantes**: Múltiples noxas críticas activan simultáneamente el árbol vascular[cite: 2].
    - **Complicaciones obstétricas**: Desprendimiento prematuro de placenta, retención de feto muerto, preeclampsia, eclampsia y embolia de líquido amniótico[cite: 2].
    - **Neoplasias malignas**: Metástasis de tumores sólidos y leucemias agudas expresan mediadores procoagulantes[cite: 2].
    - **Infecciones graves**: Sepsis bacteriana por gramnegativos, meningococcemia, virosis fulminantes, rickettsias y malaria por Plasmodium[cite: 2].
    - **Estados de choque**: El choque séptico y el choque hipovolémico grave comprometen la perfusión endotelial sistémica[cite: 2].
    - **Traumatismos extensos**: Quemaduras severas, politraumatismo, cirugía con circulación extracorpórea, mordedura ofídica y golpe de calor[cite: 2].
    - **Incompatibilidad transfusional**: Reacciones hemolíticas agudas por incompatibilidad de grupo ABO liberan tromboplastina tisular masiva[cite: 2].
  - **Fisiopatología esencial**: La expresión endotelial de factor tisular y la activación del factor XII liberan trombina activa de forma desenfrenada[cite: 2].
    - **Polimerización de fibrina**: La trombina abundante polimeriza redes masivas de fibrina intravascular[cite: 2].
      - **Oclusión microvascular**: Las redes de microtrombos ocluyen lechos capilares en órganos vitales[cite: 2].
        - *Daño isquémico y mecánico*: El bloqueo capilar causa isquemia tisular y destruye eritrocitos por cizallamiento microangiopático[cite: 2].
    - **Coagulopatía de consumo**: La formación descontrolada de coágulos agota las reservas de fibrinógeno, factor V, factor VIII y plaquetas[cite: 2].
      - **Activación fibrinolítica**: El endotelio lesionado libera plasmina para degradar los depósitos microvasculares de fibrina[cite: 2].
        - *Sangrado paradójico*: Los productos de degradación de fibrina inhiben la trombina y la función plaquetaria, lo que desata hemorragias graves[cite: 2].

#### Diagnóstico diferencial de diátesis hemorrágicas:

| Entidad o patología | Factor desencadenante | Marcador laboratorial cardinal | Manifestación clínica predominante | Conducta de primera línea |
| :--- | :--- | :--- | :--- | :--- |
| Púrpura trombocitopénica inmunitaria | Autoanticuerpos anti-GPIIb/IIIa y anti-GPIb/IX | Plaquetas < 20.000/μL con frotis aislado | Petequias mucocutáneas y equimosis sin visceromegalia | Corticosteroides o inmunomodulación |
| Trombocitopenia inducida por heparina | Complejo heparina-factor plaquetario 4 | Caída plaquetaria entre 2 y 5 días de tratamiento | Trombosis paradójica con plaquetopenia leve a moderada | Descontinuación inmediata de heparina |
| Hemofilia A o B | Déficit congénito de factor VIII o factor IX | Alargamiento de tiempo de tromboplastina parcial activada | Hemartrosis y hematomas musculares postraumáticos | Reemplazo específico del factor deficitario |
| Coagulación intravascular diseminada | Sepsis grave o traumatismo tisular masivo | Plaquetopenia, consumo de fibrinógeno y PDF elevados | Isquemia microvascular asociada a sangrado difuso | Tratamiento etiológico y soporte hemodinámico |

---

## Fisiopatología de los eritrocitos y anemias:

### Biología, metabolismo y cinética celular:
- **Concepto clave**: El glóbulo rojo adopta forma de disco bicóncavo anucleado para maximizar el transporte celular de gases[cite: 2].
  - **Hemoglobina funcional**: Un tetrámero proteico conjugado al grupo hemo asegura la oxigenación de los tejidos periféricos[cite: 2].
    - **Hemoglobina A**: Constituye la isoforma fisiológica predominante en el adulto tras los primeros meses extrauterinos[cite: 2].
    - **Hemoglobina F**: Muestra una afinidad elevada por el oxígeno durante la etapa intrauterina placentaria[cite: 2].
  - **Homeostase del hierro**: El mineral actúa como factor limitante directo para la síntesis intracelular del grupo hemo[cite: 2].
    - **Hierro funcional**: El 80% del hierro corporal permanece unido al complejo hemo y a la mioglobina muscular[cite: 2].
    - **Hierro de reserva**: El 20% restante se almacena como ferritina y hemosiderina en hígado, bazo y médula ósea[cite: 2].
  - **Eritropoyesis medular**: Células peritubulares renales detectan descensos en la presión tisular de oxígeno y liberan eritropoyetina[cite: 3].
    - **Acción hormonal**: La eritropoyetina estimula los progenitores eritroides medulares para sintetizar hemoglobina y expulsar el núcleo picnótico[cite: 3].
      - **Retículo periférico**: La médula expulsa reticulocitos inmaduros que completan su remodelación de membrana en 24 a 48 horas[cite: 3].
  - **Senescencia celular**: El hematíe cumple una vida media fisiológica de 120 días con una tasa de recambio diario del 1%[cite: 3].
    - **Fagocitosis fisiológica**: Macrófagos tisulares de bazo, hígado, médula ósea y ganglios linfáticos degradan las células seniles[cite: 3].
      - **Metabolismo de globina**: Proteasas degradan las cadenas de globina hacia aminoácidos libres reutilizables[cite: 3].
      - **Metabolismo del hemo**: Enzimas degradan la porción hemo y liberan hierro hacia la transferrina sérica[cite: 3].
      - **Metabolismo de bilirrubina**: La porfirina residual se convierte en bilirrubina no conjugada, viaja con albúmina y se conjuga en el hepatocito[cite: 3].

#### Parámetros laboratoriales y cinética eritrocitaria:

| Parámetro laboratorial | Valor en varones | Valor en mujeres | Significado fisiológico | Criterio de alteración |
| :--- | :--- | :--- | :--- | :--- |
| Recuento de eritrocitos | 4,2 a 5,4 × 10⁶/μL | 3,6 a 5,0 × 10⁶/μL | Masa celular absoluta de transporte gaseoso | Refleja pérdidas, fallas de producción o sobreproducción |
| Reticulocitos | 1% a 1,5% del total | 1% a 1,5% del total | Velocidad de producción y respuesta medular | Distingue anemias regenerativas de arregenerativas |
| Hemoglobina sérica | 14,0 a 16,5 g/dL | 12,0 a 15,0 g/dL | Concentración de proteína transportadora de oxígeno | Define presencia y severidad de la anemia |
| Hematocrito | 40% a 50% | 37% a 47% | Fracción de volumen ocupada por eritrocitos | Varía por deshidratación o hipercelularidad |
| Volumen corpuscular medio | 83 a 97 fL | 83 a 97 fL | Tamaño o volumen promedio del eritrocito | Clasifica morfológicamente en micro, normo o macrocítica |
| Hemoglobina corpuscular media | 27 a 34 pg | 27 a 34 pg | Contenido promedio de hemoglobina por eritrocito | Define normocromía o hipocromía celular |
| Concentración de hemoglobina corpuscular media | 31 a 35 g/dL | 31 a 35 g/dL | Proporción de hemoglobina según masa celular total | Refleja saturación interna de hemoglobina |

### Síndrome anémico y mecanismos de compensación:
- **Concepto clave**: La anemia reduce la masa total de glóbulos rojos o la hemoglobina, lo que lesiona el aporte tisular de oxígeno[cite: 3].
  - **Mecanismos etiopatogénicos**: Tres vías fundamentales disminuyen el transporte sistémico de oxígeno[cite: 3].
    - **Pérdida hemática**: La hemorragia aguda o crónica drena hematíes íntegros y vacía las reservas minerales[cite: 3, 4].
    - **Destrucción acelerada**: Defectos intrínsecos o noxas del plasma acortan la supervivencia del glóbulo rojo[cite: 4].
    - **Producción insuficiente**: El fallo primario medular o la falta de nutrientes bloquea la maduración celular[cite: 4].
  - **Síntomas de hipoxia celular**: La falta de oxígeno desencadena manifestaciones clínicas funcionales[cite: 3].
    - **Hipoxia tisular periférica**: El déficit de oxígeno causa fatiga precoz, astenia muscular marcada, disnea de esfuerzo y angina funcional[cite: 3].
    - **Hipoxia vascular cerebral**: La hipoperfusión cerebral origina cefalea pulsátil, mareo ortostático y oscurecimiento visual transitorio[cite: 3].
  - **Mecanismos compensatorios**: Tres respuestas adaptativas compensan el déficit de transporte gaseoso periférico[cite: 3].
    - **Redistribución del flujo**: El tono adrenérgico induce vasoconstricción cutánea y renal para preservar el cerebro y miocardio, lo que genera palidez[cite: 3].
    - **Modulación de afinidad**: La curva de disociación de oxihemoglobina vira hacia la derecha, facilitando la entrega periférica de oxígeno[cite: 3].
    - **Respuesta hiperdinámica**: El gasto cardíaco aumenta marcadamente cuando la hemoglobina desciende por debajo de 10 g/dL (100 g/L o 6,21 mmol/L)[cite: 3].
      - **Ajuste de poscarga**: La menor viscosidad hemática y el óxido nítrico endotelial reducen las resistencias vasculares periféricas[cite: 3].
      - **Ajuste de precarga**: El retorno venoso se incrementa y eleva la contractilidad y frecuencia cardíaca, provocando taquicardia y palpitaciones[cite: 3].
    - **Estímulo de eritropoyetina**: El sensor renal detecta hipoxia y acelera la liberación masiva de eritropoyetina hacia la médula ósea[cite: 3].

### Clasificación diagnóstica de las anemias:
- **Clasificación etiopatogénica**: La respuesta de la médula ósea, cuantificada por reticulocitos, divide las anemias en dos grupos[cite: 3, 4].
  - **Anemias regenerativas**: La médula responde activamente a la noxa con reticulocitosis en sangre periférica[cite: 3, 4].
    - **Pérdida sanguínea aguda**: El choque o sangrado activo estimula una liberación inmediata de células jóvenes[cite: 4].
    - **Hemólisis intracorpuscular**: Enzimopatías o hemoglobinopatías estructurales provocan destrucción prematura del hematíe[cite: 4].
    - **Hemólisis extracorpuscular**: Autoanticuerpos, toxinas bacterianas, infecciones parasitarias o cizallamiento mecánico destruyen el eritrocito normal[cite: 4].
  - **Anemias arregenerativas**: La médula ósea muestra recuentos reticulocitarios disminuidos o inadecuadamente normales[cite: 4].
    - **Falla medular primaria**: La aplasia pura de progenitores o la mielofibrosis anula la proliferación hematopoyética[cite: 4].
    - **Invasión estromal**: La infiltración neoplásica por leucemias, linfomas o metástasis de tumores sólidos reemplaza la médula sana[cite: 4].
    - **Déficit de factores de maduración**: La falta de hierro, cobalamina, ácido fólico o eritropoyetina interrumpe la maduración celular[cite: 4].
- **Clasificación morfológica**: Los índices eritrocitarios dividen las anemias según tamaño celular y carga de hemoglobina[cite: 4].
  - **Patrón microcítico e hipocrómico**: El frotis revela VCM inferior a 83 fL y HCM inferior a 27 pg[cite: 4].
    - **Fisiopatología esencial**: La falla en sintetizar el grupo hemo o cadenas de globina fuerza divisiones mitóticas adicionales que reducen el tamaño celular[cite: 4].
    - **Etiologías cardinales**: Anemia ferropénica, talasemias, anemia sideroblástica, saturnismo, intoxicación por aluminio y subgrupos de enfermedad crónica[cite: 4].
  - **Patrón normocítico y normocrómico**: El frotis muestra VCM entre 83 y 97 fL con HCM conservada[cite: 4].
    - **Fisiopatología esencial**: La masa eritrocitaria total se reduce sin alterar los procesos de división nuclear o condensación citoplasmática[cite: 4].
    - **Etiologías cardinales**: Anemia de enfermedad crónica, pérdida hemática aguda temprana, aplasia medular, invasión tumoral o hemólisis incipiente[cite: 4].
  - **Patrón macrocítico**: El frotis expone un VCM superior a 97 fL (y superior a 100 fL en patrones megaloblásticos floridos)[cite: 4, 8].
    - **Fisiopatología esencial**: El retraso en la duplicación del ADN genera asincronía núcleo-citoplasma y eritroblastos gigantes[cite: 4, 8].
    - **Etiologías cardinales**: Déficit de vitamina B12 o folato, alcoholismo crónico, hepatopatías, mielodisplasias, hipotiroidismo y reticulocitosis marcada[cite: 4].

---

## Fisiopatología de las anemias hemolíticas:

### Vías anatómicas de lisis y aclaramiento de hemoglobina:
- **Concepto clave**: La destrucción acelerada de hematíes supera la reposición medular y reduce la masa celular[cite: 5].
  - **Respuesta compensatoria**: La médula ósea entra en estado hiperreactivo y expulsa reticulocitos con sobrevida menor a 60 días[cite: 5].
  - **Hemólisis intravascular**: La lisis ocurre directamente en la luz del árbol vascular por fuerzas mecánicas, toxinas o complemento[cite: 5].
    - **Lisis mecánica y por complemento**: La membrana eritrocitaria estalla y vierte hemoglobina libre al plasma[cite: 5].
      - **Hemoglobinemia**: La hemoglobina libre satura y agota las reservas de haptoglobina plasmática[cite: 5].
        - *Hemoglobinuria*: La hemoglobina libre no fijada atraviesa la barrera glomerular y tiñe la orina de color caoba[cite: 5].
        - *Lesión tubular renal*: Células tubulares proximales reabsorben hemoglobina, acumulan hemosiderina, se descaman y causan necrosis tubular aguda[cite: 5].
    - **Presentación cardinal**: La tétrada clásica reúne hemoglobinemia, hemoglobinuria, ictericia y hemosiderinuria persistente en sedimento urinario[cite: 5].
  - **Hemólisis extravascular**: Los hematíes pierden elasticidad y encallan en los sinusoides esplénicos y hepáticos[cite: 5].
    - **Atrapamiento sinusoidal**: Células rígidas quedan atrapadas en la microcirculación esplenohepática[cite: 5].
      - **Fagocitosis macrofágica**: Macrófagos locales reconocen y destruyen de forma ordenada a los hematíes encallados[cite: 5].
        - *Hiperbilirrubinemia*: El catabolismo macrofágico genera ictericia mucocutánea sin hemoglobinemia ni hemosiderinuria urinaria[cite: 5].
  - **Ausente**: La hemólisis extravascular pura no presenta hemoglobinuria ni hemosiderinuria, porque no libera hemoglobina intacta a la luz vascular[cite: 5].

#### Diagnóstico diferencial de pigmenturia y lisis eritrocitaria:

| Parámetro o biomarcador | Localización o muestra | Momento de aparición | Criterio discriminador | Trampa de examen |
| :--- | :--- | :--- | :--- | :--- |
| Hemoglobinemia | Plasma sanguíneo | Inmediato tras la rotura celular | Plasma rojizo por lisis intravascular aguda | Se disipa rápidamente al ser captada por haptoglobina |
| Hemoglobinuria | Orina espontánea | Intermedio tras agotar haptoglobina | Orina caoba sin hematíes en microscopía | Se confunde con hematuria sin sedimento centrifugado |
| Hemosiderinuria | Sedimento urinario | Tardío en lisis sostenida | Gránulos de hierro dentro de células tubulares descamadas | Resulta negativa en episodios agudos tempranos |
| Hematuria | Sedimento urinario | Inmediato en sangrado urológico | Sedimento con hematíes íntegros abundantes | La tira reactiva resulta falsamente idéntica a hemoglobina |

### Anemias hemolíticas hereditarias:
- **Esferocitosis hereditaria**: Un trastorno autosómico dominante altera la estabilidad del citoesqueleto del glóbulo rojo[cite: 6].
  - **Fisiopatología esencial**: Mutaciones genéticas lesionan la espectrina, anquirina, banda 3 o proteína 4.2[cite: 6].
    - **Inestabilidad de membrana**: El citoesqueleto debilitado desestabiliza la bicapa lipídica suprayacente[cite: 6].
      - **Vesiculación lipídica**: La membrana desprende microvesículas lipídicas y reduce su superficie celular[cite: 6].
        - *Rigidez esferocítica*: La pérdida de superficie transforma al hematíe en una esfera rígida no deformable[cite: 6].
        - *Atrapamiento esplénico*: Los sinusoides del bazo retienen los esferocitos rígidos y los macrófagos los fagocitan[cite: 6].
  - **Presentación cardinal**: La tétrada clínica incluye anemia hemolítica continua, ictericia fluctuante, esplenomegalia y colelitiasis pigmentaria[cite: 6].
  - **Complicación temida**: La infección por Parvovirus B19 interrumpe la eritropoyesis medular y desencadena una crisis aplásica aguda con colapso del hematocrito[cite: 6].
  - **Conducta inmediata**: La esplenectomía extirpa el sitio principal de destrucción macrofágica y extiende la vida del eritrocito esférico[cite: 6].
- **Drepanocitosis (anemia falciforme)**: Una hemoglobinopatía autosómica recesiva provoca eventos vasooclusivos recurrentes y hemólisis crónica[cite: 6].
  - **Fisiopatología molecular**: Una mutación puntual en la cadena de globina beta sustituye ácido glutámico por valina, originando hemoglobina S (HbS)[cite: 6].
    - **Polimerización citoplasmática**: La desoxigenación induce agregación de moléculas de HbS en polímeros insolubles[cite: 6].
      - **Falciformación celular**: El citosol gelificado curva la membrana celular hasta adoptar morfología rígida de hoz[cite: 6].
        - *Daño de membrana*: Ciclos continuos de falciformación lesionan la membrana y vuelven irreversible la rigidez celular[cite: 6].
  - **Presentación cardinal**: Las crisis vasooclusivas provocan isquemia distal con dolor agudo severo óseo, articular, torácico y abdominal[cite: 6, 7].
    - **Dactilitis dolorosa**: La oclusión microvascular se manifiesta en pacientes pediátricos como inflamación dolorosa de manos y pies[cite: 7].
  - **Complicación temida**: El síndrome torácico agudo por microinfartos pulmonares causa dolor torácico, disnea e infiltrados alveolares con riesgo letal[cite: 7].
  - **Disfunción multiorgánica**: Infartos repetidos dañan bazo, hígado, riñón, retina y encéfalo, predisponiendo a accidentes cerebrovasculares y osteomielitis[cite: 7].

---

## Anemias por falla en la producción e insuficiencia medular:

### Anemia ferropénica:
- **Concepto clave**: El agotamiento de las reservas de hierro impide la síntesis del grupo hemo y reduce la producción de hemoglobina[cite: 7].
  - **Homeostasis digestiva**: El enterocito duodenal absorbe de 1 a 2 mg diarios de hierro para reponer pérdidas fisiológicas[cite: 7].
  - **Factores etiológicos según contexto**: Las causas primarias difieren de acuerdo al grupo etario y estado metabólico[cite: 7].
    - **Varones y posmenopáusicas**: Pérdidas hemáticas crónicas por úlceras pépticas, neoplasias colorrectales, pólipos o angiodisplasias causan el cuadro[cite: 7].
    - **Mujeres gestantes**: El aumento metabólico fetoplacentario incrementa el riesgo de parto pretérmino y neonatos de bajo peso[cite: 7].
    - **Lactantes y primera infancia**: Reservas bajas por ferropenia materna o consumo de leche de vaca antes de los 12 meses provocan microhemorragias intestinales[cite: 7].
      - *Trampa de examen*: La leche bovina entera ofrece biodisponibilidad deficiente de hierro y lesiona activamente la mucosa intestinal infantil[cite: 7].
      - *Factor protector*: La lactancia materna exclusiva aporta hierro de alta biodisponibilidad y previene estados carenciales tempranos[cite: 7].
  - **Presentación cardinal**: La hipoxia funcional causa astenia marcada, intolerancia al esfuerzo, disnea, taquicardia y angina de pecho[cite: 7, 8].
    - **Alteraciones tróficas epiteliales**: La carencia celular crónica de hierro desestructura epitelios y faneras[cite: 8].
      - **Coiloniquia**: Las uñas se adelgazan y adoptan curvatura cóncava anormal en forma de cuchara[cite: 8].
      - **Glositis y queilitis**: La atrofia papilar produce una lengua roja y lisa junto con grietas dolorosas en comisuras labiales[cite: 8].
      - **Síndrome de pica**: Compulsión anormal por sustancias no nutritivas como hielo (pagofagia) o tierra (geofagia)[cite: 8].

### Anemias megaloblásticas:
- **Concepto clave**: La falla en la síntesis del ADN provoca asincronía núcleo-citoplasmática, macrocitosis y VCM marcadamente elevado (> 100 fL)[cite: 8].
  - **Deficiencia de vitamina B12 (cobalamina)**: La falta del cofactor interrumpe la duplicación celular y el metabolismo lipídico de la mielina[cite: 8].
    - **Cinética de absorción**: La cobalamina alimentaria se une al factor intrínseco secretado por células parietales gástricas[cite: 8].
      - **Absorción ileal**: El complejo factor intrínseco-B12 se acopla a receptores en el íleon terminal y se absorbe hacia la sangre[cite: 8].
        - *Transporte tisular*: La transcobalamina II transporta la cobalamina absorbida hacia su depósito en el parénquima hepático[cite: 8].
    - **Causas etiológicas**: Gastritis atrófica autoinmune (anemia perniciosa), gastrectomías, resección ileal, celiaquía o fármacos (metformina, inhibidores de bomba de protones)[cite: 8].
    - **Presentación cardinal**: Anemia macrocítica con CHCM normal e ictericia leve combinada con degeneración de cordones medulares espinales[cite: 8].
      - **Manifestaciones neurológicas**: La desmielinización lesiona cordones posteriores y laterales, generando ataxia sensitiva, paraparesia espástica y demencia[cite: 8].
  - **Deficiencia de ácido fólico**: La carencia celular impide donar grupos metilo para sintetizar timidilato en el genoma celular[cite: 8].
    - **Causas etiológicas**: Alcoholismo crónico, desnutrición, consumo tumoral, embarazo sin suplementación o fármacos (fenitoína, fenobarbital, metotrexato)[cite: 8].
      - *Daño teratogénico*: El déficit durante la organogénesis embrionaria induce malformaciones severas por cierre defectuoso del tubo neural[cite: 8].
  - **Diagnóstico diferencial**: La presencia o ausencia de afectación neurológica orienta la distinción clínica inmediata[cite: 8].
    - **Déficit de folato**: Presenta anemia macrocítica sin daño en la vaina de mielina ni sintomatología neurológica[cite: 8].
    - **Déficit de B12**: Combina anemia macrocítica con ataxia sensitiva, paraparesia espástica y alteraciones neuropsiquiátricas progresivas[cite: 8].

### Falla medular y trastornos proliferativos eritroides:
- **Anemia aplásica**: El daño letal de las células madre pluripotenciales provoca pancitopenia en sangre periférica y médula ósea grasa acelular[cite: 8].
  - **Factores desencadenantes**: Radiaciones ionizantes, benceno, fármacos citotóxicos o toxicidad idiosincrática grave por cloranfenicol[cite: 8].
  - **Detonantes infecciosos**: Hepatitis viral aguda seronegativa, mononucleosis infecciosa y síndrome de inmunodeficiencia adquirida[cite: 8].
- **Policitemia (eritrocitosis)**: El incremento de la masa celular eritrocitaria eleva el hematocrito por encima de los límites fisiológicos[cite: 8].
  - **Criterio diagnóstico**: El hematocrito supera 54% en el varón y 47% en la mujer[cite: 8].
    - **Hemodinámica capilar**: Superar 50% de hematocrito incrementa la viscosidad y superar 60% colapsa la microcirculación, causando hipoxia paradójica[cite: 8].
  - **Clasificación clínica**: Tres entidades explican la elevación sérica del hematocrito[cite: 8].
    - **Policitemia relativa (síndrome de Gaisböck)**: La deshidratación aguda contrae el volumen plasmático sin elevar la masa celular absoluta[cite: 8].
      - **Conducta inmediata**: La infusión de volumen hidroelectrolítico normaliza el hematocrito[cite: 8].
    - **Policitemia primaria (policitemia vera)**: Una neoplasia mieloproliferativa clonal ligada a la mutación somática JAK2 genera panmielosis autónoma[cite: 8].
      - **Presentación cardinal**: Hipertensión por hiperviscosidad, rubicundez cianótica, cefalea, prurito tras baño tibio y eritromelalgia urente distal[cite: 8].
      - **Parámetro laboratorial**: Las concentraciones séricas de eritropoyetina permanecen suprimidas o bajas frente a la masa roja expandida[cite: 8].
    - **Policitemia secundaria reactiva**: La médula responde a niveles elevados de eritropoyetina inducidos por hipoxia o producción ectópica[cite: 8].
      - **Causas hipóxicas**: Grandes altitudes (14.000 a 17.000 pies), EPOC grave, cortocircuitos cardíacos cianóticos o tabaquismo severo[cite: 8].
      - **Causas no hipóxicas**: Tumores secretores ectópicos o compresión renal mecánica por quistes gigantes o hidronefrosis[cite: 8].

#### Matriz diagnóstica de las policitemias:

| Tipo de policitemia | Volumen plasmático | Masa eritrocitaria absoluta | Concentración de eritropoyetina | Conducta de primera línea |
| :--- | :--- | :--- | :--- | :--- |
| Policitemia relativa (Gaisböck) | Disminuido | Normal | Normal | Restitución del volumen hidroelectrolítico intravascular |
| Policitemia absoluta primaria (Vera) | Normal o expandido | Elevada (panmielosis clonal) | Suprimida o marcadamente baja | Flebotomías terapéuticas, control mieloproliferativo y antiagregación |
| Policitemia secundaria reactiva | Normal | Elevada por estímulo humoral | Aumentada en plasma | Corrección de hipoxia (oxigenoterapia) o resección de masa ectópica |