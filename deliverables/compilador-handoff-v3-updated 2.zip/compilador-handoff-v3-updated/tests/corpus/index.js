/**
 * Corpus loader for the lean/regression suites.
 *
 * The original tree kept these documents at the repository root and under
 * `taskfiles/`. The handoff snapshot stores them in one place so the project
 * root stays product-only. Logical names are preserved so test expectations
 * and fixture JSON remain readable.
 */
import { readFileSync } from 'node:fs';
import { basename, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));

const ALIASES = Object.freeze({
  'taskfiles/sampletext2.md': 'sampletext2.md',
  'taskfiles/sampletext.md': 'sampletext.md',
  'taskfiles/2/sampletext.md': '2-sampletext.md',
});

/** The six documents every corpus-wide gate is expected to see. */
export const CORPUS_DOCS = Object.freeze([
  'sample1.md',
  'sample2.md',
  'sample3.md',
  'sample4.md',
  'text-test.md',
  'taskfiles/sampletext2.md',
]);

/** Resolve a logical corpus name to its file in this directory. */
export function corpusPath(name) {
  return join(here, ALIASES[name] || basename(name));
}

/** Read a corpus document as UTF-8. Throws if it is missing. */
export function readCorpus(name) {
  return readFileSync(corpusPath(name), 'utf8');
}
