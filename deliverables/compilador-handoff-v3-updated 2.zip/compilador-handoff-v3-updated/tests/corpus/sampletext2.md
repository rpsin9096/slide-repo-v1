# Patología general y fundamentos disciplinares:
## Dimensiones de la enfermedad y ramas patológicas:
### Ramas del estudio patológico:
- **Etiología**: Es el estudio de las causas biológicas, físicas o químicas que originan la enfermedad[cite: 1].
  - **Etiología genética**: Mutaciones heredadas, variantes génicas o polimorfismos cromosómicos alteran la homeostasis transcripcional basal[cite: 1].
  - **Etiología adquirida**: Infecciones microbianas, desequilibrios nutricionales, tóxicos químicos, noxas físicas o intervenciones iatrogénicas provocan lesión tisular directa[cite: 1].
  - **Etiología multifactorial**: Agentes ambientales o noxas externas actúan directamente sobre individuos con perfiles génicos susceptibles[cite: 1].
  - **Etiología idiopática**: Es la persistencia de una afección lesional con origen primario desconocido[cite: 1].
- **Patogenia**: Es la secuencia ordenada de episodios celulares, bioquímicos y moleculares tras la exposición a agentes lesionales[cite: 1].
  - **Mecanismo**: Noxa lesional → alteración bioquímica celular → compromiso molecular → daño histológico estructural[cite: 1].
- **Fisiopatología**: Es el estudio sistemático de las alteraciones funcionales dinámicas en órganos comprometidos[cite: 1].
- **Anatomía patológica morfológica**: Es la identificación de alteraciones estructurales e histopatológicas microscópicas y macroscópicas[cite: 1].
- **Semiología**: Es el registro de las manifestaciones clínicas objetivas y subjetivas generadas por el proceso morboso[cite: 1].
- **Clínica**: Es la gestión, abordaje terapéutico y tratamiento integral del paciente enfermo[cite: 1].
### Campos de aplicación:
- **Anatomía patológica general**: Es el estudio teórico de los mecanismos lesionales básicos compartidos por cualquier tejido[cite: 1].
  - **Factor**: Inflamación aguda[cite: 1].
  - **Factor**: Inflamación crónica[cite: 1].
  - **Factor**: Neoplasias[cite: 1].
- **Anatomía patológica específica**: Es la aplicación clínica integrada a aparatos y sistemas orgánicos concretos[cite: 1].
  - **Factor**: Patología cardiovascular[cite: 1].
  - **Factor**: Patología del sistema respiratorio[cite: 1].

## Procedimientos diagnósticos y procesamiento tisular:
### Modalidades de biopsia y obtención tisular:
- **Biopsia**: Es la extracción de tejido celular delimitado proveniente de un sujeto vivo para estudio patológico[cite: 1].
- **Biopsia intraoperatoria**: Muestreo intraquirúrgico → congelación rápida tisular → corte criostático → emisión de informe intraoperatorio orientador[cite: 1].
  - **Término de la fuente**: Biopsia extratemporánea[cite: 1].

| Atributo | Biopsia incisional | Biopsia excisional | Biopsia por congelación | Punción por aspiración |
| --- | --- | --- | --- | --- |
| Extensión resecada | Fragmento lesional representativo | Lesión íntegra con margen sano | Segmento lesional intraoperatorio | Cilindro o cúmulo celular |
| Instrumentación | Bisturí o sacabocados | Disección quirúrgica amplia | Sección en criostato | Aguja fina o aguja gruesa |
| Indicación clínica | Tumores volumétricos extensos | Neoplasias pequeñas delimitadas | Decisión intraoperatoria crítica | Nódulos tiroideos o fluidos |
| Tiempo de fijación | Estándar en formalina | Estándar en formalina | Inmediato por congelamiento | Secado al aire o etanol |

### Procesamiento de piezas operatorias:
- **Protocolo de macroscopía**: Mida la dimensión total de la pieza quirúrgica[cite: 1].
- **Protocolo de masa**: Pese la masa tisular resecada en balanza de precisión[cite: 1].
- **Protocolo de disección**: Diseque minuciosamente las áreas patológicas y márgenes[cite: 1].
- **Protocolo de orientación**: Tiña bordes quirúrgicos para orientar la microscopía[cite: 1].
### Métodos diagnósticos en citopatología:
- **Citología**: Es el examen morfológico de células aisladas[cite: 1].
  - **Punción aspirativa con aguja fina**: Presión negativa aspira cúmulos celulares lesionales intratiroideos[cite: 1].
  - **Improntas tisulares**: Aposición directa de la superficie lesional sobre portaobjetos transfiere células viables[cite: 1].
  - **Raspado celular**: Fricción mecánica exfolia células epiteliales para tamizaje citológico[cite: 1].
  - **Cepillado de mucosas**: Cepillo endocavitario desprende agregados epiteliales mucosos[cite: 1].
  - **Citología de líquidos biológicos**: Centrifugación de esputo, exudado o trasudado concentra el sedimento celular diagnóstico[cite: 1].
### Modalidades del examen necrópsico:
- **Autopsia**: Es la disección y estudio anatómico integral del cadáver y sus órganos[cite: 1].
  - **Autopsia clínica**: Examen histopatológico de órganos confirma correlación con hallazgos clínicos previos[cite: 1].
    - **Criterio diagnóstico**: Requiere autorización escrita expresa de familiares directos[cite: 1].
  - **Autopsia médico-legal**: Peritaje forense obligatorio investiga la causa directa de muerte no clarificada[cite: 1].
    - **Ausente**: Requerimiento de consentimiento familiar directo ante mandato judicial[cite: 1].
### Fundamentos y afinidades tintoriales:
- **Técnica de tinción más utilizada**: Hematoxilina-Eosina (H&E)[cite: 1].
  - **Hematoxilina**: Colorante catiónico básico tiñe cromatina nuclear rica en ácidos nucleicos[cite: 1].
  - **Eosina**: Colorante aniónico ácido contratiñe proteínas del estroma citoplasmático celular[cite: 1].

| Atributo | Hematoxilina-Eosina | Tricrómico de Mallory | Tricrómico de Masson | Ácido peryódico de Schiff | Azul de metileno |
| --- | --- | --- | --- | --- |
| Tinción nuclear | Azul o violáceo basófilo | Rojo intenso | Negro profundo | Basófilo estándar | Azul uniforme |
| Diana histológica | Ácidos nucleicos y citoplasma | Fibras de colágeno | Colágeno y matriz conectiva | Glucógeno e hidratos de carbono | Mucosa intestinal y colonocitos |
| Coloración extracelular | Rosa o rojo eosinófilo | Azul brillante | Verde o azul conectivo | Magenta o fucsia | Azul |
| Aplicación clínica | Diagnóstico histopatológico general | Cuantificación en cirrosis hepática | Identificación de fibrosis tisular | Glucogenosis o mucopolisacáridos | Identificación de metaplasia intestinal |

# Adaptación celular:
## Mecanismos adaptativos basales:
### Respuestas adaptativas basales:
- **Definición**: Respuesta reversible con cambios estructurales, funcionales y bioquímicos para mantener la viabilidad ante estrés sostenido[cite: 1].
- **Límite adaptativo**: Si la agresión supera el umbral o persiste sin cesar, sobreviene la lesión celular[cite: 1].

| Atributo | Hipertrofia | Hiperplasia | Atrofia | Metaplasia |
| --- | --- | --- | --- | --- |
| Criterio discriminador | Aumento del tamaño celular | Aumento del número celular | Reducción de tamaño y actividad | Reemplazo por otro linaje celular |
| Mecanismo efector basal | Síntesis de proteínas y miofilamentos | Proliferación celular dependiente de ciclinas | Vía ubiquitina-proteosoma y autofagia | Reprogramación de células precursoras |
| Capacidad de división celular requerida | Permanente o nula (células permanentes) | Conservada (células lábiles y estables) | Independiente de la tasa mitótica basal | Tejidos epiteliales o mesenquimatosos |

### Hipertrofia:
- **Definición**: Aumento de las dimensiones celulares y de su capacidad funcional[cite: 1].
- **Población diana**: Células permanentes sin mitosis (miocitos cardíacos y músculo esquelético)[cite: 1].
- **Mecanismo molecular**: Factores de crecimiento activan transducción de señales → activación de factores de transcripción → incremento de síntesis de proteínas estructurales, actina y miosina[cite: 1].
- **Fisiopatología miocárdica**:
  - **Sobrecarga de volumen**: El exceso volumétrico diastólico estira el sarcómero y desencadena hipertrofia excéntrica con adelgazamiento parietal y dilatación luminal[cite: 1].
    - **Factor**: Insuficiencia aórtica[cite: 1].
  - **Sobrecarga de presión**: La elevada poscarga desencadena hipertrofia concéntrica para disipar el estrés de la pared celular[cite: 1].
    - **Factor**: Hipertensión arterial descontrolada crónica y estenosis valvular aórtica[cite: 1].
### Hiperplasia:
- **Definición**: Proliferación mitótica regulada que amplía el número total de células maduras[cite: 1].
- **Tipos fisiológicos**:
  - **Hiperplasia hormonal**: Epitelio glandular mamario (pubertad/gestación) y miometrio gestacional[cite: 1].
  - **Hiperplasia compensadora**: Regeneración parenquimatosa tras hepatectomía parcial y expansión de centros germinales linfoides[cite: 1].
- **Tipos patológicos**:
  - **Hiperplasia prostática benigna**: Estímulo androgénico desmedido → proliferación fibromuscular/glandular → uropatía obstructiva baja[cite: 1].
  - **Hiperplasia endometrial**: Estimulación estrogénica sostenida no contrarrestada → hemorragia uterina anormal[cite: 1].
### Atrofia:
- **Definición**: Disminución del tamaño, volumen del parénquima y tasa metabólica funcional de la célula[cite: 1].
- **Mecanismo de degradación**:
  - **Vía ubiquitina-proteosoma**: La ubiquitina marca proteínas estructurales desnaturalizadas que luego el proteasoma escinde[cite: 1].
  - **Autofagia**: Formación de vacuolas autofágicas que degradan organelos citoplasmáticos basales[cite: 1].
  - **Pigmento de lipofuscina**: Producto lipídico no degradado resultante de autofagia incompleta origina atrofia parda[cite: 1].
- **Causas fisiológicas**: Involución tímica en el envejecimiento, atrofia del endometrio menopáusico y regresión uterina posparto[cite: 1].
- **Causas patológicas**: Desuso e inmovilización, denervación, isquemia crónica, caquexia por desnutrición proteica y compresión externa[cite: 1].
### Metaplasia:
- **Definición**: Reprogramación reversible por la cual un tejido adulto es reemplazado por otro linaje más resistente al microambiente hostil[cite: 1].
- **Patrones histológicos de sustitución**:
  - **Cilíndrico a escamoso respiratorio**: Exposición crónica al humo de tabaco o carencia de vitamina A (ácido retinoico)[cite: 1].
  - **Escamoso a cilíndrico intestinal**: Reflujo gastroesofágico crónico de ácido clorhídrico en esófago de Barrett[cite: 1].
  - **Conductos glandulares**: Litiasis en vías biliares, conductos salivales o pancreáticos induce transformación a epitelio escamoso estratificado[cite: 1].
  - **Metaplasia mesenquimatosa**: Formación de tejido óseo ectópico en partes blandas o cartílagos sometidos a estrés[cite: 1].

# Lesión y muerte celular:
## Principios de la lesión celular:
### Dinámica lesiva:
- **Lesión celular reversible**: Estímulo leve o transitorio → alteración bioquímica y funcional → preservación de membrana → retorno a la homeostasis basal[cite: 1].
- **Lesión celular irreversible**: Estímulo grave, persistente o lesivo directo → rotura de membranas u organelos → falla metabólica permanente → necrosis o apoptosis[cite: 1].
- **Secuencia cronológica**: Alteración bioquímica → modificación ultraestructural → modificación al microscopio óptico → lesión macroscópica visible[cite: 1].
### Causas primarias de lesión celular:
- **Restricción de oxígeno**: Isquemia tisular, hipoxia por falla cardiorrespiratoria, anemia, intoxicación por CO o hemorragia sistémica intensa[cite: 1].
- **Agentes físicos**: Traumatismo mecánico, temperaturas extremas, cambios barométricos, radiación ionizante y descargas eléctricas[cite: 1].
- **Sustancias químicas y fármacos**: Tóxicos o metabolitos reactivos (e.g., sobredosis de paracetamol genera NAPQI con radicales libres) dañan membranas y ADN[cite: 1].
- **Agentes biológicos e infecciosos**: Replicación intracelular vírica lítica, exotoxinas bacterianas o lesión inflamatoria indirecta por citocinas y enzimas[cite: 1].
- **Trastornos inmunitarios**: Autoanticuerpos, activación del complemento y lisis mediada por linfocitos T[cite: 1].
- **Desequilibrios nutricionales**: Carencia proteicocalórica produce atrofia; excesos lipídicos inducen esteatosis hepática y placas de ateroma[cite: 1].
- **Alteraciones genéticas**: Aberraciones cromosómicas numéricas, mutaciones moleculares puntuales o polimorfismos enzimáticos[cite: 1].

## Mecanismos moleculares y morfología reversible:
### Consecuencias del agotamiento de ATP:
- **Falla de bombas iónicas**: Disminución de ATP → detención de bomba Na+/K+ ATPasa → acumulación de Na+ intracelular → entrada osmótica de agua → tumefacción celular[cite: 1].
- **Acidosis metabólica**: Disminución de ATP → activación de fosfofructocinasa → aceleración de glucólisis anaerobia → consumo de glucógeno y producción de ácido láctico → caída del pH citosólico[cite: 1].
- **Desprendimiento ribosomal**: Depleción prolongada de ATP → disociación de ribosomas del retículo endoplásmico rugoso → colapso de síntesis proteica[cite: 1].
### Daño mitocondrial y sobrecarga de calcio citosólico:
- **Transición mitocondrial**: Apertura del poro de permeabilidad mitocondrial → pérdida del gradiente electroquímico → fuga de citocromo c hacia el citosol[cite: 1].
- **Activación enzimática catabólica**: Entrada masiva de Ca2+ extracelular y liberación desde el retículo endoplásmico[cite: 1].
  - **Fosfolipasas**: Hidrolizan y degradan fosfolípidos de la membrana plasmática[cite: 1].
  - **Proteasas**: Fragmentan proteínas citoesqueléticas y de membrana[cite: 1].
  - **Endonucleasas**: Provocan degradación enzimática de la cromatina y del ADN genómico[cite: 1].
  - **ATPasas**: Aceleran la degradación del pool residual de ATP intracelular[cite: 1].
### Patrones morfológicos de lesión celular reversible:
- **Tumefacción celular (degeneración hidrópica)**:
  - **Mecanismo**: Fallo bioenergético de la bomba Na+/K+ ATPasa con acumulación pasiva de agua[cite: 1].
  - **Criterio macroscópico**: Aumento de tamaño, masa y turgencia; superficie capsular lisa y aspecto pálido por compresión capilar[cite: 1].
  - **Criterio microscópico**: Dilatación celular con palidez, vacuolización clara por cisternas del retículo endoplásmico y posición nuclear conservada[cite: 1].
- **Esteatosis celular (cambio graso)**:
  - **Fisiopatología**: Acumulación intracitoplasmática anormal de triglicéridos en células parenquimatosas[cite: 1].
  - **Criterio macroscópico**: Hepatomegalia voluminosa, consistencia blanda, bordes romos y superficie de corte untuosa de tonalidad amarilla brillante[cite: 1].
  - **Criterio microscópico**: Vacuolas lipídicas redondeadas ópticamente vacías y desplazamiento excéntrico compresivo del núcleo hacia la periferia[cite: 1].

## Modalidades de muerte celular:
### Diagnóstico diferencial: Muerte celular:
- **Diagnóstico diferencial**:
  - **Criterio de discriminación**: Integridad de membrana celular, respuesta inflamatoria reactiva y lisis enzimática desregulada[cite: 1].
  - **Entidad A**: Necrosis tisular[cite: 1].
  - **Entidad B**: Apoptosis celular[cite: 1].
  - *Umbral*: Rotura de membrana plasmática con fuga de contenido celular hacia el intersticio[cite: 1].

| Atributo | Necrosis tisular | Apoptosis celular |
| --- | --- | --- |
| Integridad de membrana plasmática | Rota y discontinua con fuga enzimática | Intacta con formación de cuerpos apoptósicos |
| Respuesta inflamatoria reactiva | Presente e intensa de forma obligada | Ausente |
| Mecanismo efector | Digestión enzimática lítica y desnaturalización | Activación coordinada de caspasas con gasto de ATP |
| Volumen celular | Tumefacción y lisis osmótica | Retracción y condensación celular |

### Apoptosis:
- **Definición**: Muerte programada mediada por proteasas intrínsecas (caspasas), dependiente de ATP, conservando la integridad de membranas[cite: 1].
  - **Ausente**: Respuesta inflamatoria tisular reactiva[cite: 1].
- **Vías de activación y caspasas iniciadoras**:
  - **Vía intrínseca (mitocondrial)**: Estrés o daño genómico → activación de Bax/Bak y neutralización de Bcl-2 → salida de citocromo c → activación de procaspasa 9 iniciadora[cite: 1].
  - **Vía extrínseca (receptores de muerte)**: Ligandos extracelulares (FasL o TNF) activan receptores con dominio de muerte → reclutamiento de procaspasa 8 iniciadora[cite: 1].
- **Vía común de ejecución**: Caspasas iniciadoras (8 y 9) escinden y activan a las caspasas ejecutoras 3, 6 y 7 → degradación selectiva del citoesqueleto y del ADN[cite: 1].
- **Secuencia morfológica de la apoptosis**:
  - **Paso 1**: Retracción y condensación citoplasmática celular[cite: 1].
  - **Paso 2**: Condensación periférica de cromatina bajo la envoltura nuclear (picnosis apoptósica)[cite: 1].
  - **Paso 3**: Formación de protusiones de superficie (blebbing) y fragmentación celular formando cuerpos apoptósicos intactos[cite: 1].
  - **Paso 4**: Fagocitosis ultrarrápida (eferocitosis) por macrófagos tisulares sin fuga de detritos[cite: 1].
### Necrosis: Cambios celulares y degradación nuclear:
- **Morfología citoplasmática de la necrosis**:
  - **Eosinofilia citoplasmática**: Pérdida de ARN ribosómico citosólico e incremento de proteínas desnaturalizadas fijadoras de eosina[cite: 1].
  - **Figuras de mielina**: Restos fosfolipídicos arremolinados en espiral derivados de membranas celulares dañadas[cite: 1].
  - **Rotura parietal**: Pérdida de la ultraestructura y disrupción de la membrana plasmática[cite: 1].
- **Tríada de degradación nuclear**:
  - **Picnosis**: Retracción y condensación extrema de la cromatina en una masa esférica intensamente basófila[cite: 1].
  - **Cariorrexis**: Fragmentación asimétrica y dispersión del núcleo picnótico por el citoplasma[cite: 1].
  - **Cariólisis**: Disolución hidrolítica total de la cromatina por endonucleasas con desaparición de la basofilia nuclear[cite: 1].

## Patrones histopatológicos de la necrosis tisular:
### Necrosis coagulativa:
- **Fisiopatología**: Desnaturalización de proteínas estructurales y enzimas que bloquea la proteólisis inmediata[cite: 1].
- **Criterio macroscópico**: Zona pálida, delimitada, firme y con morfología triangular en cuña[cite: 1].
- **Criterio microscópico**: Sombras fantasma celulares con eosinofilia intensa, anucleación y preservación temporal de la citoarquitectura básica[cite: 1].
- **Etiología representativa**: Infartos isquémicos en órganos parenquimatosos sólidos (miocardio, riñón, bazo), excepto encéfalo[cite: 1].
### Necrosis licuefactiva:
- **Fisiopatología**: Digestión enzimática hidrolítica acelerada mediada por enzimas leucocitarias o toxinas microbianas[cite: 1].
- **Criterio macroscópico**: Reblandecimiento tisular focal con transformación fluida viscosa o cavidad quística residual[cite: 1].
- **Criterio microscópico**: Pérdida completa de la arquitectura celular sustituida por detritos necróticos amorfos, pus y macrófagos espumosos rodeados por gliosis en SNC[cite: 1].
- **Etiología representativa**: Infartos isquémicos en el SNC (cerebro) e infecciones bacterianas/fúngicas formadoras de abscesos[cite: 1].
### Necrosis caseosa:
- **Fisiopatología**: Destrucción celular y lisis granulomatosa mediada por hipersensibilidad retardada celular tipo IV[cite: 1].
- **Criterio macroscópico**: Masa friable, blanco-amarillenta, blanda y pastosa semejante al queso requesón[cite: 1].
- **Criterio microscópico**: Núcleo eosinófilo granular amorfo y acelular sin sombras celulares, circundado por macrófagos epitelioides, células gigantes de Langhans y linfocitos[cite: 1].
- **Etiología representativa**: Infección por *Mycobacterium tuberculosis* o micosis sistémicas profundas[cite: 1].