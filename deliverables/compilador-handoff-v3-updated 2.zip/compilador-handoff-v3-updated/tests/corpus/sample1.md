# Patología general y fisiopatología sistémica:

## Principios fundamentales de la enfermedad:

### Conceptos básicos y epidemiología:
- **Fisiopatología**: Integra fisiología alterada y patología para explicar la salud comprometida.
- **Alcance científico**:
  - **Análisis estructural y funcional**: Evalúa alteraciones en células, tejidos y órganos causantes de enfermedad.
  - **Mecanismos subyacentes**: Aporta información para planificar medidas preventivas y terapéuticas prácticas.
- **Epidemiología**: Estudia la aparición de enfermedad en poblaciones humanas.
  - **Evolución histórica**: Transita desde la diseminación infecciosa epidémica hasta factores de riesgo multifactoriales.
  - **Áreas de aplicación**:
    - **Enfermedad neoplásica**: Cáncer.
    - **Enfermedad cardiovascular**: Cardiopatías.
- **Etiología frente a patogenia**:
  - **Etiología**: Describe el factor causante que inicia el proceso patológico.
  - **Patogenia**: Explica la evolución temporal de la enfermedad.
  - **Vector patogénico**: Contacto con factor etiológico → Alteraciones celulares → Alteraciones tisulares → Expresión clínica de la enfermedad.

### Manifestaciones y curso clínico:
- **Manifestaciones clínicas**: Expresan fenotípicamente el proceso mórbido.
  - **Formas de presentación**:
    - **Manifestación directa**: Fiebre.
    - **Enfermedad silente**: Detecta patología en estudios rutinarios o en fases avanzadas.
- **Taxonomía semiológica**:
  - **Síntoma**: Molestia subjetiva percibida por la persona enferma.
  - **Signo**: Manifestación objetiva identificada por un observador clínico.
  - **Síndrome**: Conjunto de signos y síntomas característicos de un estado patológico específico.
  - **Complicación**: Extensión adversa derivada de una enfermedad o de un tratamiento.
  - **Secuela**: Lesión consecutiva provocada directamente por una enfermedad previa.
- **Curso clínico**: Describe la evolución temporal del proceso patológico.
  - **Patrón temporal**:
    - **Curso agudo**: Proceso relativamente grave de carácter autolimitado.
    - **Curso subagudo**: Intensidad y duración intermedias entre agudo y crónico.
    - **Curso crónico**: Proceso continuo o periódico de larga duración.
  - **Estado evolutivo**:
    - **Estado preclínico**: Ausencia de manifestaciones actuales con destino obligatorio hacia datos clínicos.
    - **Estado subclínico**: Ausencia de clínica sin progresión ulterior a datos manifiestos.
    - **Estado clínico**: Presencia manifiesta de signos y síntomas.
    - **Estado portador**: Hospedero asintomático con albergue activo de un microorganismo.

## Adaptación celular y lesión tisular:

### Modalidades de adaptación celular:
- **Adaptación celular**: Preserva la viabilidad de la célula ante variaciones del medio interno.
  - **Mecanismo efector**: Altera el tamaño, el número o el fenotipo celular.
  - **Mecanismos moleculares**: Factores celulares autocrinos o paracrinos regulados por señales químicas.
  - **Vías de señalización molecular**: Mensajeros químicos → Modificación de expresión génica.
    - **Genes constitutivos**: Mantienen funciones vitales basales indemnes durante la adaptación.
    - **Genes de diferenciación**: Alteran características fenotípicas especializadas celulares.
    - **Retiro del estímulo**: Cese del estímulo → Normalización de genes de diferenciación → Restauración del fenotipo previo.
- **Atrofia**: Reduce el tamaño celular con nivel funcional disminuido compatible con supervivencia.
  - **Fisiopatología**:
    - **Vector metabólico**: Reducción de carga laboral → Reducción del consumo de oxígeno → Descenso de síntesis proteica.
    - **Vector estructural**: Descenso de mitocondrias → Pérdida de miofilamentos → Reducción del retículo endoplásmico.
  - **Etiología**:
    - **Desuso**: Reducción prolongada de demandas de trabajo.
    - **Denervación**: Pérdida de la inervación motora.
    - **Pérdida endocrina**: Supresión del estímulo hormonal trófico.
    - **Desnutrición**: Aporte nutricional deficiente.
    - **Isquemia**: Disminución del flujo sanguíneo tisular.
- **Hipertrofia**: Aumenta el tamaño celular con incremento de masa tisular funcionante.
  - **Mecanismo inductor**: Aumento sostenido de la carga de trabajo funcional tisular.
  - **Tejidos diana característicos**: Miocardio y músculo esquelético por incapacidad de división mitótica.
  - **Clasificación**:
    - **Hipertrofia fisiológica**: Aumento de masa muscular esquelética por ejercicio físico.
    - **Hipertrofia patológica adaptativa**: Engrosamiento de pared vesical por uropatía obstructiva o miocardiopatía por hipertensión y valvulopatías.
    - **Hipertrofia patológica compensadora**: Crecimiento compensatorio del parénquima renal remanente tras nefrectomía.
- **Hiperplasia**: Incrementa el número absoluto de células de un órgano o tejido.
  - **Requisito biológico**: Parénquimas con capacidad mitótica como epidermis, epitelio intestinal y estroma glandular.
  - **Clasificación**:
    - **Hiperplasia fisiológica hormonal**: Crecimiento mamario y uterino durante la gestación mediado por estrógenos.
    - **Hiperplasia fisiológica compensadora**: Regeneración de masa hepática tras hepatectomía parcial.
    - **Hiperplasia patológica**: Estimulación hormonal excesiva o hipersecreción de factores de crecimiento.
  - **Coexistencia celular**: Útero gestante presenta hipertrofia e hiperplasia simultáneas por estímulo estrogénico.
- **Metaplasia**: Sustituye reversiblemente un tipo de célula diferenciada adulta por otro fenotipo.
  - **Inductor etiopatogénico**: Respuesta defensiva celular ante inflamación o irritación tisular crónica.
  - **Fenotipo respiratorio**: Sustituye epitelio respiratorio cilíndrico por epitelio plano estratificado en tabaquismo.
  - **Fenotipo digestivo - Esófago de Barrett**:
    - **Manifestaciones clínicas**: Presenta estado asintomático inicial frecuente.
    - **Signos de reflujo**: Pirosis retroesternal, pirosis gástrica, regurgitación alimentaria y sabor ácido.
    - **Signos de alarma**: Disfagia, odinofagia y hematemesis que exigen evaluación médica urgente.
    - **Complicación**:
      - **Adenocarcinoma de esófago**: Deriva de displasia.
      - **Acalasia secundaria**: Desarrolla tras alteración estructural.
    - **Clasificación de Praga**:
      - *Criterio C*: Extensión circunferencial de la metaplasia medida desde el pliegue gástrico superior.
      - *Criterio M*: Extensión máxima longitudinal del epitelio metaplásico.
- **Displasia**: Proliferación desorganizada tisular con variabilidad en tamaño, forma y organización celular.
  - **Asociación biológica**: Estímulos lesivos crónicos o procesos inflamatorios persistentes.
  - **Reversibilidad y riesgo**: Presenta potencial reversión tras retirar el estímulo irritante con riesgo de transformación neoplásica maligna.
- **Acumulaciones intracelulares**: Depositan sustancias y productos metabólicos en concentraciones anómalas dentro de la célula.

### Calcificaciones patológicas:
- **Calcificación patológica**: Deposita sales de calcio, hierro, magnesio y otros minerales de forma anormal.
  - **Calcificación distrófica**:
    - **Sustrato tisular**: Depósito en tejidos necróticos o inviables con calcemia sérica normal.
    - **Apariencia macroscópica**: Partículas arenosas finas hasta conglomerados firmes con consistencia pétrea.
    - **Patogenia**: Forma sales cristalinas intra y extracelulares de fosfato de calcio.
    - **Origen de componentes**: Cuerpos celulares líticos, torrente sanguíneo y líquido intersticial circundante.
  - **Calcificación metastásica**:
    - **Sustrato tisular**: Depósito mineral en parénquimas normales derivado de hipercalcemia sérica.
    - **Localizaciones predilectas**: Parénquima pulmonar, túbulos renales y paredes de vasos sanguíneos.
    - **Etiología**: Hiperparatiroidismo, retención de fosfato, insuficiencia renal, resorción ósea e intoxicación por vitamina D.

## Lesión celular y muerte tisular:

### Mecanismos de lesión celular:
- **Determinantes de lesión**: Intensidad del agente, tiempo lesivo, perfusión tisular, estado nutricional y capacidad de regeneración.
- **Vías etiopatogénicas universales**:
  - **Producción de radicales libres**: Forma especies químicas reactivas de manera descontrolada.
  - **Estrés hipóxico**: Deteriora el transporte o el empleo tisular de oxígeno.
  - **Homeostasis del calcio**: Libera calcio intracelular descontrolado que activa enzimas destructivas.
- **Radicales libres**: Especies químicas reactivas inestables con un electrón desapareado en órbita externa.
  - **Patogenia molecular**: Reacciona con fosfolípidos de membranas celulares e induce mutagénesis sobre ácidos nucleicos.
  - **Vector de propagación**: Reacción inicial → Formación de nuevos radicales → Reacción en cadena de miles de pasos.
- **Hipoxia tisular**: Priva de oxígeno al tejido, interrumpe el metabolismo oxidativo y agota el ATP.
  - **Factores de irreversibilidad**: Magnitud de la carencia de oxígeno o glucosa y requerimientos metabólicos celulares.
- **Patrones de necrosis tisular**:
  - **Necrosis por licuefacción**: Conserva enzimas catalíticas activas que disuelven el tejido muerto.
  - **Necrosis coagulativa**: Genera acidosis intracelular intensa que desnaturaliza proteínas estructurales y enzimáticas.
  - **Necrosis caseosa**: Produce residuos celulares amorfos blandos blanquecinos que persisten sin disolución.

### Agentes físicos y tóxicos de lesión:
- **Temperaturas extremas**: Destruyen organelos y complejos enzimáticos por transferencia de calor o congelación.
  - **Calor de baja intensidad**: Rango de 43 °C a 46 °C presente en quemaduras dérmicas parciales y golpe de calor.
  - **Mecanismos efectores**: Induce lesiones vasculares, acelera el metabolismo, inactiva enzimas termosensibles y rompe membranas.
- **Lesiones por electricidad**: Provocan daño tisular extenso con interferencia de la conducción miocárdica y nerviosa.
  - **Variables determinantes**: Voltaje, amperaje, tipo de corriente continua o alterna, resistencia tisular, trayectoria y duración.
- **Radiaciones ionizantes**: Ionizan moléculas, rompen directamente el ADN y forman radicales libres lesivos.
  - **Efectos agudos**: Provocan muerte celular inmediata, detienen la multiplicación celular e inducen mutaciones génicas.
  - **Vulnerabilidad tisular**:
    - **Tejidos con alta susceptibilidad**: Presentan división rápida como médula ósea y epitelio intestinal.
    - **Tejidos con resistencia relativa**: Muestran menor tasa lesiva el tejido óseo y el músculo esquelético.
  - **Efectos crónicos**: Provocan fibrosis miocárdica o pulmonar por radiación torácica, radiodermitis crónica, necrosis y cicatrización anómala.
  - **Inducción neoplásica**: Originan cáncer cutáneo, leucemias, sarcomas osteogénicos y neoplasias pulmonares.
- **Plumbosis - Saturnismo**: Acumula plomo celular vía inhalatoria o digestiva produciendo intoxicación sistémica grave.
  - **Diana patológica**: Degeneración del sistema nervioso central, neuropatía periférica y disfunción del tejido hematológico.
  - **Signo físico bucal**: Exhibe ribete gingival de Burton visible en el margen dental.

## Respuestas inflamatorias tisulares:

### Signos cardinales y nomenclatura:
- **Inflamación**: Reacción defensiva coordinada de tejidos conjuntivos vascularizados ante lesión o infección.
  - **Nomenclatura nosológica**: Añade el sufijo -itis al órgano lesionado.
    - **Pericarditis**: Inflamación del pericardio.
    - **Neuritis**: Inflamación de troncos nerviosos.
    - **Apendicitis**: Inflamación del apéndice vermiforme.
- **Manifestaciones cardinales**:
  - **Tétrada de Celso**:
    - **Calor**: Vasodilatación arteriolar.
    - **Rubor**: Eritema vascular por hiperemia activa.
    - **Tumor**: Hinchazón tisular por exudación líquida e infiltración leucocítica.
    - **Dolor**: Estimulación de nociceptores por mediadores químicos.
  - **Péntada de Galeno**: Integra pérdida funcional del órgano afectado a la tétrada.

### Fases de la inflamación aguda:
- **Inflamación aguda**: Despliega respuesta inmunitaria temprana inmediata frente al agente agresor.
  - **Estímulos desencadenantes**: Infecciones, reacciones inmunitarias, traumatismos contusos y penetrantes, quemaduras, congelación y químicos.
  - **Componentes estructurales**: Células endoteliales, leucocitos circulantes, fibroblastos, mastocitos y matriz extracelular.
- **Fase vascular**:
  - **Microcirculación afectada**: Arteriolas, redes capilares y vénulas poscapilares.
  - **Vector hemodinámico**: Lesión tisular → Vasoconstricción arteriolar transitoria breve → Vasodilatación arteriolar persistente → Apertura de lechos capilares → Aumento de presión hidrostática → Incremento de permeabilidad vascular → Exudación de líquido plasmático al intersticio.
  - **Células endoteliales**:
    - **Función de barrera**: Monocapa epitelial selectiva entre compartimento vascular y tejido perivascular frente a agresiones.
    - **Función de reparación**: Sintetiza factores de crecimiento inductores de angiogénesis y depósito de matriz extracelular.
    - **Marcador patológico**: Marca disfunción vascular endotelial en pacientes con lupus eritematoso sistémico.
- **Fase celular**:
  - **Vector de reclutamiento leucocítico**: Marginación parietal → Adhesión firme al endotelio vascular → Migración transendotelial → Quimiotaxis guiada → Activación funcional y fagocitosis.
  - **Fagocitosis leucocítica**:
    - **Células efectoras**: Neutrófilos, monocitos circulantes y macrófagos tisulares.
    - **Vector de degradación**: Reconocimiento y adhesión al ligando → Endocitosis de la partícula → Eliminación y lisis intracelular.

### Mediadores químicos de la inflamación:
- **Fuentes de mediadores inflamatorios**: Inducen signos y síntomas inflamatorios a nivel local y sistémico.
  - **Mediadores derivados del plasma**:
    - **Síntesis y activación**: El hígado sintetiza precursores inactivos que activan cascadas proteolíticas séricas.
    - **Cascadas plasmáticas**:
      - **Proteínas de fase aguda**: Inducen fiebre y marcan respuesta sistémica.
      - **Factor XII - Factor Hageman**: Activa coagulación, fibrinólisis y sistema de cininas para sintetizar bradicinina.
      - **Sistema del complemento**: Activa factores en secuencia para opsonización y lisis celular.
  - **Mediadores derivados de células**:
    - **Fuentes celulares**: Células cebadas, plaquetas, neutrófilos, monocitos, macrófagos, células endoteliales, músculo liso y fibroblastos.
    - **Mediadores preformados en gránulos**:
      - **Histamina**: Células cebadas y basófilos liberan histamina por traumatismo o unión de IgE.
        - *Efecto vascular*: Vasodilatación arteriolar e incremento de la permeabilidad venular dependiente de receptores H1.
      - **Serotonina**: Células plaquetarias liberan serotonina almacenada en gránulos densos.
      - **Enzimas lisosómicas**: Neutrófilos y macrófagos liberan proteasas preformadas.
    - **Mediadores de síntesis de novo**:
      - **Eicosanoides**: Fosfolipasas escinden ácido araquidónico para activar dos vías metabólicas principales:
        - **Vía ciclooxigenasa**: Sintetiza prostaglandinas inflamatorias, prostaciclina vasodilatadora y tromboxano A2 proagregante.
        - **Inhibición farmacológica**: Aspirina y antiinflamatorios no esteroideos inactivan la ciclooxigenasa.
        - **Vía lipooxigenasa**: Sintetiza mediadores leucotrienos.
      - **Factor activador de plaquetas**: Leucocitos sintetizan activamente este mediador.
      - **Especies reactivas de oxígeno y óxido nítrico**: Macrófagos y leucocitos liberan radicales de oxígeno y óxido nítrico.
      - **Citocinas proinflamatorias**: Linfocitos, macrófagos y células endoteliales sintetizan factor de necrosis tumoral alfa.

### Manifestaciones locales y exudados:
- **Lesiones inflamatorias locales**:
  - **Exudados**:
    - **Exudado hemorrágico**: Fuga masiva de eritrocitos por lesión vascular estructural grave o daño endotelial extremo.
    - **Exudado purulento supurativo**: Compuesto por detritos celulares, proteínas y leucocitos degradados inducidos por Staphylococcus.
  - **Absceso**: Acumula exudado purulento circunscrito delimitado por infiltrado de neutrófilos.
  - **Úlcera**: Excava un defecto necrótico en superficies epiteliales cutáneas o mucocutáneas gastrointestinales.
  - **Edema inflamatorio**: Acumula líquido extravascular en tejido celular subcutáneo, intersticio pulmonar o masa encefálica.
- **Diagnóstico diferencial**:

  | Atributo | Inflamación aguda | Inflamación crónica | Umbral discriminador |
  |---|---|---|---|
  | Tiempo de inicio y latencia | Respuesta temprana inmediata frente a la agresión biológica | Respuesta tardía insidiosa con posibilidad de instauración posterior a fase aguda | Inmediatez sintomática de segundos a minutos tras la noxa |
  | Duración del proceso | Minutos a varios días con límites habituales de 6 a 24 horas | Semanas, meses o años de persistencia activa | Límite temporal estricto en 15 días |
  | Infiltrado celular predominante | Predominio cuantitativo de leucocitos neutrófilos extravasados | Infiltración predominante de linfocitos y macrófagos tisulares | Linaje polimorfonuclear neutrófilo frente a linaje mononuclear |
  | Patrón vascular y tisular | Vasodilatación arteriolar y exudado plasmático rico en fibrina | Proliferación de vasos neoformados, necrosis celular y fibrosis cicatricial | Ausencia de proliferación fibrovascular en patrón agudo |

- **Diagnóstico diferencial de fluidos**:

  | Atributo | Exudado | Trasudado | Umbral discriminador |
  |---|---|---|---|
  | Etiopatogenia fundamental | Aumento de permeabilidad microvascular inducido por mediadores inflamatorios | Aumento mecánico de presión hidrostática o reducción de presión coloidosmótica capilar | Ausencia de alteración en permeabilidad vascular intrínseca en trasudado |
  | Contenido proteico relativo | Alto contenido de proteínas plasmáticas | Bajo contenido de proteínas disueltas | Concentración escalar de proteínas macromoleculares en fluido |
  | Aspecto físico macroscópico | Aspecto turbio con turbidez variable por detritos celulares | Aspecto límpido y claro | Turbidez del fluido a la inspección directa |

## Cicatrización y reparación tisular:

### Fases de la cicatrización de heridas:
- **Cicatrización cutánea**: Restaura la integridad anatómica y funcional del tejido lesionado.
  - **Fase inflamatoria**:
    - **Momento de instauración**: Inicia inmediatamente tras el daño con el tapón hemostático y el coágulo.
    - **Secuencia de migración celular**: Neutrófilos infiltran inicialmente para fagocitosis → Macrófagos infiltran a las 24 horas y secretan factores tróficos.
  - **Fase proliferativa**:
    - **Objetivo biológico**: Sintetiza y deposita tejido de granulación para ocupar la brecha lesional.
    - **Célula efectora principal**: Fibroblasto del estroma conjuntivo.
    - **Productos de síntesis**: Colágeno fibrilar, proteoglucanos fundamentales y glucoproteínas de adhesión.
  - **Fase de contracción y remodelación**:
    - **Cronología**: Comienza hacia la tercera semana poslesión y persiste durante 6 meses o más.
    - **Mecanismos efectores**: Reduce la densidad vascular y remodela activamente el colágeno sintetizado.
    - **Resultado biomecánico**: Incrementa la fuerza tensil tisular y retrae dimensionalmente la cicatriz fibrosa.
- **Cicatrización anómala**:
  - **Queloides**: Producen crecimiento tumoral exuberante de tejido cicatricial patológico.
    - **Mecanismo patológico**: Deposita colágeno y componentes de matriz extracelular en exceso anormal.
    - **Epidemiología y genética**: Afecta con elevada frecuencia a individuos de ascendencia africana por susceptibilidad genética hereditaria.

## Infecciones cutáneas bacterianas:

### Entidades piodérmicas:
- **Impétigo no ampolloso**: Infección bacteriana superficial contagiosa de la epidermis.
  - **Morfología lesional**: Pápulas, vesículas y pústulas con halo eritematoso circundante de 1 a 4 mm de diámetro.
  - **Vector evolutivo**: Rotura vesicular → Salida de líquido seropurulento → Desecación exudativa → Costra melisérica amarillenta.
  - **Localización preferente**: Regiones periorificiales de la cara, específicamente fosas nasales y borde labial.
- **Forúnculo**: Infección necrotizante profunda del aparato folicular cutáneo.
  - **Etiología bacteriana**: *Staphylococcus aureus*.
  - **Estructura comprometida**: Bulbo piloso, unidad pilosebácea e invasión progresiva a múltiples folículos vecinos.
  - **Factores de riesgo predisponentes**: Piel grasa, fricción crónica, ropa oclusiva, hiperhidrosis, humedad, pediculosis, rasurado y depilación.
  - **Población diana**: Adolescentes y adultos jóvenes.
- **Diagnóstico diferencial de infecciones bacterianas dérmicas**:

  | Atributo | Erisipela | Celulitis | Umbral discriminador |
  |---|---|---|---|
  | Forma de inicio y progresión | Comienzo hiperagudo súbito menor de 24 horas | Comienzo insidioso de curso lentamente progresivo | Latencia temporal clínica menor de 24 horas |
  | Profundidad de afectación tisular | Inflamación confinada a dermis superficial y vasos linfáticos dérmicos | Inflamación profunda que compromete dermis profunda y grasa subcutánea | Compromiso dérmico superficial exclusivo frente a invasión hipodérmica |
  | Delimitación de márgenes clínicos | Placa eritematosa con bordes elevados netos y sobreelevación marcada | Placa eritematosa de bordes mal definidos, imprecisos y no sobreelevada | Presencia de reborde periférico delimitado y sobreelevado |
  | Manifestaciones sistémicas | Escalofrios y fiebre marcada mayor de 38 °C desde el inicio | Síntomas generales infrecuentes de aparición ocasional y tardía | Registro térmico sistemático superior a 38 °C desde el inicio |
  | Distribución y lateralidad | Presentación unilateral en 98% de casos con predominio en pierna o pie en 85% | Afectación sin distribución porcentual estricta ni definición uniforme | Compromiso acro-pedio unilateral en 85% a 98% de casos |
  | Respuesta inmunológica serológica | Títulos de antiestreptolisina O menores de 40% al inicio o seguimiento | Serología variable con menor vinculación a cinética de antiestreptolisina O | Tasa de seroconversión estreptocócica cuantificable |

## Hematopoyesis y elementos formes sanguíneos:

### Células sanguíneas y linfocitos:
- **Eritrocitos**: Células anucleadas discoides bicóncavas de gran superficie con elevada deformabilidad mecánica capilar.
  - **Vida media y contenido**: Supervivencia de 120 días con hemoglobina transportadora de oxígeno.
- **Leucocitos**: Células inmunitarias que constituyen el 1% del volumen sanguíneo corporal total.
  - **Linajes constitutivos**: Granulocitos, monocitos circulantes y linfocitos.
- **Linfocitos**: Células mononucleares que constituyen entre el 20% y el 30% del recuento leucocitario total.
  - **Tráfico celular**: Migración continua entre el lecho vascular y órganos linfoides durante horas o años.
  - **Subtipos funcionales**:
    - **Linfocitos B**: Progenitores de células plasmáticas que secretan inmunoglobulinas efectoras de la inmunidad humoral.
    - **Linfocitos T**: Mediadores centrales de la inmunidad celular contra antígenos intracelulares.
    - **Células asesinas naturales**: Efectores de la inmunidad innata sin restricción clonal para citotoxicidad directa.

### Ontogenia y regulación citocínica:
- **Ontogenia hematopoyética**:
  - **Vector cronológico**: Células endoteliales vasculares embrionarias en semana 5 → Hígado fetal → Bazo fetal → Médula ósea posnatal.
  - **Hematopoyesis extramedular**: Hígado y bazo retienen capacidad hematopoyética residual compensadora en vida adulta.
- **Regulación citocínica**: Factores de crecimiento de vida media corta reguladores de la masa celular circulante.
  - **Efectores de linaje específico**:
    - **Eritropoyetina**: Estimula la proliferación y diferenciación del linaje eritroide.
    - **Factor estimulante de colonias de granulocitos y monocitos**: Promueve progenitores de granulocitos, monocitos, eritrocitos y megacariocitos.
    - **Factor estimulante de colonias de granulocitos**: Induce proliferación específica del linaje de neutrófilos.
    - **Factor estimulante de colonias de macrófagos**: Estimula el desarrollo selectivo de colonias macrofágicas.
    - **Trombopoyetina**: Promueve la proliferación de megacariocitos y producción de trombocitos.

## Hemostasia y trombosis:

### Fases de la hemostasia y tapón plaquetario:
- **Hemostasia**: Detiene la hemorragia vascular preservando la fluidez intracirculatoria mediante mecanismos regulados.
  - **Desequilibrios fisiopatológicos**:
    - **Trombosis**: Formación inapropiada y descontrolada de coágulos intravasculares oclusivos.
    - **Hemorragia**: Falla hemostática funcional con incapacidad para contener la pérdida de sangre.
  - **Etapas secuenciales de la hemostasia**: Constricción vascular arteriolar → Adhesión y agregación plaquetaria → Coagulación por fibrina.
- **Plaquetas**: Fragmentos citoplasmáticos con receptores glicoproteicos de superficie como el complejo GP IIb/IIIa.
  - **Gránulos plaquetarios**:
    - **Gránulos alfa**: Almacenan fibrinógeno, factor de von Willebrand, fibronectina, factor V, factor VIII, factor 4 plaquetario, PDGF y TGF-alfa.
    - **Gránulos delta densos**: Almacenan trifosfato de adenosina, difosfato de adenosina, calcio ionizado, histamina, serotonina y adrenalina.
  - **Vector de activación plaquetaria**: Lesión endotelial → Exposición de colágeno subendotelial → Secreción endotelial de factor de von Willebrand → Unión de FvW al receptor plaquetario → Cambio morfológico a esfera espinosa → Exposición de receptores GP IIb/IIIa → Liberación activa de tromboxano A2 y ADP → Agregación plaquetaria secundaria → Generación parietal de trombina y fibrina → Estabilización insoluble del trombo primario.
  - **Función portadora del factor de von Willebrand**: Transporta y protege al factor VIII circulante en plasma.

### Cascada de la coagulación y fibrinólisis:
- **Coagulación de la sangre**: Cascada enzimática escalonada de activación de zimógenos hepáticos en plasma.
  - **Vías de iniciación**:
    - **Vía intrínseca**: Contacto de la sangre intravascular con fibras de colágeno expuestas del endotelio dañado.
    - **Vía extrínseca**: Exposición plasmática a factor tisular liberado por traumatismo del vaso y tejidos vecinos.
  - **Vía común**: Factor Xa + Factor Va + Calcio ionizado + Fosfolípidos de membrana → Activador de protrombina → Conversión de protrombina a trombina → Escisión de fibrinógeno a polímeros insolubles de fibrina.
  - **Cofactores esenciales**:
    - **Vitamina K**: Requerimiento hepático para síntesis de factores II, VII, IX, X y anticoagulante proteína C.
    - **Calcio - Factor IV**: Ion indispensable en todos los pasos enzimáticos excepto las dos primeras reacciones.
- **Fibrinólisis**: Vía lítica secuencial que disuelve el coágulo para restituir el flujo vascular y permitir reparación.

### Estados de hipercoagulabilidad:
- **Hipercoagulabilidad**: Alteración de la función de las plaquetas o de factores plasmáticos que amplifica la hemostasia y predispone a trombosis.
  - **Tríada de Virchow**:
    - **Lesión endotelial**: Pérdida de integridad de la túnica íntima vascular.
    - **Estasis venosa**: Enlentecimiento del flujo sanguíneo laminar.
    - **Hipercoagulabilidad**: Desbalance procoagulante en sangre circulante.
- **Incremento de función plaquetaria**:
  - **Factores etiológicos**: Aterosclerosis, tabaquismo, diabetes mellitus, hipercolesterolemia, hiperlipidemia y trombocitosis.
  - **Fisiopatología aterosclerótica**: Placas endoteliales perturban flujo sanguíneo → Depósito plaquetario parietal → Liberación de PDGF → Hiperplasia de músculo liso vascular → Aterogénesis progresiva.
- **Activación patológica de la coagulación**:
  - **Trastornos genéticos congénitos**:
    - **Mutación del factor V Leiden**: Transmisión autosómica dominante con resistencia a la proteína C activada.
    - **Mutación del gen de la protrombina**: Incremento de niveles plasmáticos de protrombina circulante.
    - **Déficit de anticoagulantes naturales**: Deficiencias congénitas de antitrombina, proteína C o proteína S vinculadas a tromboembolia venosa.
  - **Trastornos adquiridos**:
    - **Estasis venosa**: Reposo prolongado en cama, inmovilidad posquirúrgica e insuficiencia cardiaca congestiva.
    - **Malignidad neoplásica**: Cáncer activo presente de forma oculta en 20% a 25% de personas con tromboembolia venosa primaria.
    - **Estados hiperestrogénicos**: Embarazo, puerperio, reemplazo hormonal menopáusico y consumo de anticonceptivos orales combinados.
    - **Riesgo vascular aditivo**: Mujeres tabaquistas mayores de 35 años que emplean anticonceptivos muestran mayor tasa de infarto y accidente cerebrovascular.
    - **Síndrome antifosfolípido**: Trombofilia autoinmune adquirida asociada a trombosis recurrente venosa y arterial.
    - **Otros factores**: Obesidad, hipertensión, enfermedad pulmonar obstructiva crónica, nefropatía crónica, transfusiones y vuelos aéreos prolongados.

### Trombocitosis y trombocitopenia:
- **Trombocitosis**: Elevación de plaquetas en sangre periférica por encima de 1.000.000/μL.
  - **Vector de retroalimentación de la trombopoyetina**: Trombocitopenia → Aumento de TPO plasmática no unida → Estimulación de megacariocitos → Incremento de plaquetas → Ligadura de TPO a receptores plaquetarios → Reducción de TPO libre → Cese del estímulo trófico.
  - **Trombocitosis primaria**: Mieloproliferación clonal autónoma independiente del control por trombopoyetina.
  - **Trombocitosis secundaria reactiva**: Intervención quirúrgica, neoplasias malignas, artritis reumatoide, enfermedad de Crohn, policitemia vera y leucemias.
  - **Manifestaciones clínicas**:
    - **Eventos trombóticos**: Trombosis venosa profunda, tromboembolia pulmonar y trombosis de vena porta o venas suprahepáticas.
    - **Eritromelalgia**: Isquemia periférica paroxística por microtrombos arteriolares con palpitaciones, dolor y ardor de dedos.
    - **Eventos hemorrágicos**: Paroxismos hemorrágicos graves que alternan con periodos asintomáticos.
  - **Tratamiento**: Administre hidroxiurea para reducir concentraciones plaquetarias patológicas.
- **Trombocitopenia**: Reducción del recuento plaquetario por debajo de 150.000/μL.
  - **Mecanismos patológicos**:
    - **Producción deficiente**: Falla medular primaria en la síntesis de megacariocitos.
    - **Secuestro esplénico**: Captación y retención esplénica acentuada de plaquetas.
    - **Destrucción acelerada**: Lisis plaquetaria patológica por mecanismos inmunitarios o no inmunitarios.

## Tromboembolia pulmonar:

### Embolización y estratificación hemodinámica:
- **Embolización y embolia pulmonar**: Ocluye el árbol arterial pulmonar tras la migración de trombos venosos periféricos desprendidos.
  - **Embolia paradójica**: Migración de trombos venosos hacia la circulación arterial sistémica a través de foramen oval persistente o CIA.
  - **Diagnóstico clínico**: Simula diversas patologías cursando con disnea no explicada como manifestación predominante.
  - **Sospecha diagnóstica**: Fracaso en respuesta habitual en pacientes con insuficiencia cardíaca congestiva o neumonía concomitante.
- **Estratificación hemodinámica**:
  - **Tromboembolia pulmonar masiva**: Trombosis bilateral extensa que compromete al menos el 50% de la vascularización pulmonar.
    - *Incidencia relativa*: Representa entre 5% y 10% de los casos.
    - *Manifestaciones de gravedad*: Disnea grave, síncope, hipotensión sistémica, cianosis, choque cardiogénico y falla multiorgánica mortal.
  - **Tromboembolia pulmonar submasiva**: Disfunción hemodinámica del ventrículo derecho con presión arterial sistémica normal y liberación de biomarcadores miocárdicos.
    - *Incidencia relativa*: Representa entre 20% y 25% de las presentaciones clínicas.
  - **Tromboembolia pulmonar de bajo riesgo**: Ausencia de falla ventricular derecha con pronóstico clínico excelente.
    - *Incidencia relativa*: Comprende entre 65% y 75% del total de pacientes diagnosticados.

## Insuficiencia circulatoria - Choque:

### Clasificación etiopatogénica del choque:
- **Choque circulatorio**: Síndrome de hipoperfusión sistémica e hipoxia celular derivado de gasto cardíaco insuficiente.
  - **Manifestaciones cardinales**: Hipotensión arterial e hipoperfusión celular con posibilidad de signos vitales transitoriamente normales.
  - **Clasificación fisiopatológica**:
    - **Choque cardiogénico**: Falla de bomba intrínseca con deterioro agudo de la función contráctil miocárdica.
    - **Choque hipovolémico**: Pérdida crítica del volumen intravascular efectivo circulante.
    - **Choque distributivo**: Vasodilatación arteriolar masiva con distribución anómala del flujo sanguíneo sistémico.
    - **Choque obstructivo**: Impedimento mecánico al flujo sanguíneo en cavidades cardíacas centrales o grandes vasos.

### Fisiopatología metabólica del choque:
- **Bioenergética celular en normoxia**:
  - **Vía citoplasmática glucolítica anaeróbica**: Degrada glucosa para producir piruvato y dos moles de ATP.
  - **Vía mitocondrial aeróbica del ácido cítrico**: Introduce piruvato citosólico en ciclo de Krebs mitocondrial para sintetizar la mayor masa de ATP.
- **Bioenergética celular en choque e hipoxia**:
  - **Bloqueo oxidativo**: Carencia de oxígeno impide el transporte y la conversión mitocondrial del piruvato.
  - **Desviación anaeróbica citosólica**: Desvía piruvato acumulado hacia fermentación láctica con síntesis reducida de ATP.
  - **Vector de acidosis láctica**: Hipoxia tisular → Activación anaerobia pura → Acumulación de ácido láctico intracelular → Salida intersticial de lactato → Acidosis metabólica sistémica.

### Fisiopatología hemodinámica del choque hipovolémico:
- **Disfunción hemodinámica y compensación**:
  - **Fase prehipotensiva**: Descenso temprano del gasto cardíaco y perfusión tisular antes de caídas perceptibles en tensión arterial.
  - **Pérdida sanguínea extrema**: Pérdida de 30% a 40% de volemia abate el gasto cardíaco y la presión arterial a cero.
  - **Respuesta refleja compensadora**:
    - **Vector simpático adrenérgico**: Caída de volemia → Estimulación simpática en segundos → Taquicardia + Aumento de contractilidad + Vasoconstricción periférica.
    - **Activación neuroendocrina hipotalámica**: Centros hipotalámicos activan el reflejo de sed e incrementan secreción de ADH vasopresina.
    - **Efectos de vasopresina**: Constriñe arterias y vénulas periféricas y promueve reabsorción tubular renal neta de agua.
  - **Fase descompensada irreversible**:
    - **Vector de isquemia periférica**: Progresión del choque → Vasoconstricción intensa de lechos cutáneos, esplácnicos y renales → Hipoperfusión tisular crítica → Transición masiva al metabolismo anaeróbico → Lesión celular irreversible y muerte.

### Fisiopatología del choque obstructivo:
- **Choque obstructivo**: Bloqueo mecánico intraluminal o extrínseco del flujo en grandes vasos, cámaras cardíacas o circulación pulmonar.
  - **Etiología obstructiva principal**: Tromboembolia pulmonar oclusiva masiva.
  - **Otras causas desencadenantes**: Aneurisma aórtico disecante, taponamiento cardiaco pericárdico, neumotórax a tensión y rotura hemidiafragmática con evisceración visceral hacia hemitórax.