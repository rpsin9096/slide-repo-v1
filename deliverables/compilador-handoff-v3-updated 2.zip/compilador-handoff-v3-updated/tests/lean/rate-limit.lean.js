import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createRateLimiter, envInt } from '../../src/v2/server/rate-limit.js';

/* CC4 step 2 lock: fixed-window limiting with fake req/res (no server). */

const fakeReq = (ip = '1.2.3.4') => ({ ip });
const fakeRes = () => {
  const res = { statusCode: 200, headers: {}, body: null, ended: false };
  res.set = (k, v) => { res.headers[k] = v; };
  res.status = (c) => { res.statusCode = c; return res; };
  res.json = (b) => { res.body = b; res.ended = true; return res; };
  return res;
};
const run = (mw, req) => {
  const res = fakeRes();
  let nexted = false;
  mw(req, res, () => { nexted = true; });
  return { res, nexted };
};

describe('CC4 rate limiter', () => {
  it('allows up to max, then 429s with Retry-After', () => {
    let t = 1000;
    const mw = createRateLimiter({ windowMs: 60000, max: 2, now: () => t });
    assert.equal(run(mw, fakeReq()).nexted, true);
    assert.equal(run(mw, fakeReq()).nexted, true);
    const third = run(mw, fakeReq());
    assert.equal(third.nexted, false);
    assert.equal(third.res.statusCode, 429);
    assert.equal(third.res.headers['Retry-After'], '60');
    assert.ok(typeof third.res.body.detail === 'string');
  });

  it('resets after the window and keys clients independently', () => {
    let t = 0;
    const mw = createRateLimiter({ windowMs: 1000, max: 1, now: () => t });
    assert.equal(run(mw, fakeReq('a')).nexted, true);
    assert.equal(run(mw, fakeReq('a')).nexted, false);
    assert.equal(run(mw, fakeReq('b')).nexted, true);
    t = 1001;
    assert.equal(run(mw, fakeReq('a')).nexted, true);
  });

  it('falls back to socket address and exposes reset/stats', () => {
    const mw = createRateLimiter({ max: 1 });
    assert.equal(run(mw, { socket: { remoteAddress: '9.9.9.9' } }).nexted, true);
    assert.equal(run(mw, { socket: { remoteAddress: '9.9.9.9' } }).nexted, false);
    assert.equal(mw.stats().keys, 1);
    mw.reset();
    assert.equal(mw.stats().keys, 0);
    assert.equal(run(mw, {}).nexted, true); // unknown key still works
  });

  it('envInt parses positive ints, falls back otherwise', () => {
    const old = process.env.RATE_LIMIT_TEST_X;
    try {
      delete process.env.RATE_LIMIT_TEST_X;
      assert.equal(envInt('RATE_LIMIT_TEST_X', 7), 7);
      process.env.RATE_LIMIT_TEST_X = '30';
      assert.equal(envInt('RATE_LIMIT_TEST_X', 7), 30);
      process.env.RATE_LIMIT_TEST_X = 'junk';
      assert.equal(envInt('RATE_LIMIT_TEST_X', 7), 7);
      process.env.RATE_LIMIT_TEST_X = '-5';
      assert.equal(envInt('RATE_LIMIT_TEST_X', 7), 7);
    } finally {
      if (old === undefined) delete process.env.RATE_LIMIT_TEST_X;
      else process.env.RATE_LIMIT_TEST_X = old;
    }
  });
});
