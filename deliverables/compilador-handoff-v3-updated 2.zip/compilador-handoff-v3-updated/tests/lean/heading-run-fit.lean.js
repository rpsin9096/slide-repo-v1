// G19b — a heading run that does not fit must not be trusted to keep company.
//
// G19 (stranded-heading.lean.js) counts headings left at a column foot with no
// body after them. Its 5 RED cases share a cause that is NOT in its predicate,
// which is why it has stayed red while three other milestones landed.
//
//   sample2.md/bauhaus p4  "Hematologia e hemostasia:"     -> next is "### Elementos figurados..."
//   sample2.md/bauhaus_minimalist p1 "Adaptação celular..."  -> same shape
//   sample4.md/base p1     "Sistema respiratório:"          -> same shape
//   sample4.md/base p1     "Afecções parenquimatosas..."     -> same shape
//   taskfiles/sampletext2.md/bauhaus p2 "Principios de la lesion celular:" -> same shape
//
// In the source each `##` is followed IMMEDIATELY by a `###` (sample2.md:245-247).
// So the `##` is not an orphan: it heads a heading run, and the `###` carries
// the body. The compiler assumes that is safe — geometry-compiler.js:2002
//
//     const tailKeepsCompany = !!tailFollower && tailFollower.kind === 'heading';
//     if (tailIsHeading && !tailKeepsCompany && tailFollower) { ... }
//
// "follower is a heading" is taken as proof the run travels together. Nothing
// checks that the run FITS. When the sub-heading cannot fit the leftover space
// it is dropped to the next column and the `##` is left bare — the exact
// outcome the flag was meant to prevent, in the one case the flag skips.
//
// Doctrine being tested (unchanged from the existing comment): heading runs
// stay together. The fix is not to stop exempting them; it is to exempt them
// only when the whole run fits.
//
// This gate asserts the INVARIANT, not the census: for every stranded heading
// found, the number of items in the run that was assumed to accompany it is
// recorded, and the run must have been able to fit. It is written to fail on
// the current build and to hold on any build that refuses to strand a run it
// could not have placed.
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readCorpus } from '../corpus/index.js';
import { runPipeline } from '../../src/v2/runtime/pipeline.js';

const here = dirname(fileURLToPath(import.meta.url));
const repo = join(here, '..', '..');

const DOCS = ['sample1.md', 'sample2.md', 'sample3.md', 'sample4.md', 'text-test.md', 'taskfiles/sampletext2.md'];
const TEMPLATES = ['base', 'bauhaus', 'bauhaus_minimalist'];

// The 5 known cases, named, so a failure says WHICH shape broke rather than
// only printing a count. Thresholds are the current measured rate: the point
// of this gate is to drive these five to zero, not to bless them.
const KNOWN = [
  ['sample2.md', 'bauhaus', 4, 'Hematologia'],
  ['sample2.md', 'bauhaus_minimalist', 1, 'Adaptação'],
  ['sample4.md', 'base', 1, 'Sistema respiratório'],
  ['taskfiles/sampletext2.md', 'bauhaus', 2, 'Principios'],
];

const isHeadingLike = (el) => !!el && el.type === 'text'
  && String(el.font || '').includes('bold') && (el.size || 0) >= 9 && (el.width || 0) >= 50;

function columnsOf(page, footY) {
  const rows = (page.elements || [])
    .filter((e) => e && typeof e.y === 'number' && e.y < footY)
    .map((e) => ({ x: e.x || 0, y: e.y, el: e }));
  const cols = [];
  for (const r of rows.sort((a, b) => a.x - b.x)) {
    const near = cols.find((c) => r.x - c.maxX <= 30);
    if (near) { near.items.push(r); near.maxX = Math.max(near.maxX, r.x); }
    else cols.push({ minX: r.x, maxX: r.x, items: [r] });
  }
  for (const c of cols) c.items.sort((a, b) => a.y - b.y);
  return cols;
}

/** A heading left bare at its column's foot. */
function strandedHeadings(page, footY) {
  const out = [];
  for (const [ci, c] of columnsOf(page, footY).entries()) {
    const texts = c.items.filter((r) => r.el.type === 'text');
    if (texts.length < 8) continue;
    const last = texts[texts.length - 1].el;
    if (!isHeadingLike(last)) continue;
    // Anything rendered below it inside the same column means it is not bare.
    // Rules (w=0 rects) are a heading's own decoration, not a follower.
    const below = c.items.filter((r) => r.y > texts[texts.length - 1].y + 0.6
      && !(r.el.type === 'rect' && (r.el.width || 0) === 0));
    if (below.length > 0) continue;
    out.push({ col: ci, text: String(last.text || ''), y: texts[texts.length - 1].y });
  }
  return out;
}

async function render(doc, tpl) {
  const md = readCorpus(doc);
  const r = await runPipeline({ payload: { title: 'G19b', template: tpl,
    blocks: [{ title: 'B', markdown: md, masthead: { enabled: false },
      flags: { autofix: true, optimize_tables: true, split_equations: true }, columns: null }] },
    mode: 'paginate', seed: 'g19b', timestamp: 1700000000000 });
  return r.displayList.pages || [];
}

describe('G19b — heading runs only keep company when the whole run fits', () => {
  for (const [doc, tpl, pg, frag] of KNOWN) {
    it(`${doc}/${tpl} p${pg}: "${frag}..." does not sit bare at a column foot`, async () => {
      const defs = await import('../../src/v2/templates/definitions.js');
      const tm = defs.TEMPLATES[tpl];
      const footY = 841.89 - tm.margins.bottom - tm.footskip;
      const pages = await render(doc, tpl);
      const page = pages[pg - 1];
      assert.ok(page, `page ${pg} missing in ${doc}/${tpl} (got ${pages.length})`);
      const bad = strandedHeadings(page, footY).filter((s) => s.text.includes(frag));
      assert.equal(bad.length, 0,
        `"${frag}..." left bare at the foot of col${bad[0]?.col}: `
        + `the sub-heading that should have travelled with it went to the next column. `
        + `tailKeepsCompany exempted the run without checking that it fit.`);
    });
  }

  it('corpus: no heading is left bare at a column foot anywhere', async () => {
    const defs = await import('../../src/v2/templates/definitions.js');
    const found = [];
    for (const doc of DOCS) {
      for (const tpl of TEMPLATES) {
        const tm = defs.TEMPLATES[tpl];
        if (!tm) continue;
        const footY = 841.89 - tm.margins.bottom - tm.footskip;
        const pages = await render(doc, tpl);
        for (let i = 0; i < pages.length - 1; i++) { // not the last page: nothing follows it
          for (const s of strandedHeadings(pages[i], footY)) {
            found.push(`${doc}/${tpl} p${i + 1} col${s.col} "${s.text.slice(0, 40)}"`);
          }
        }
      }
    }
    assert.deepEqual(found, [],
      `${found.length} heading(s) left bare at a column foot:\n      `
      + found.map((f) => `      ${f}`).join('\n'));
  });
});
