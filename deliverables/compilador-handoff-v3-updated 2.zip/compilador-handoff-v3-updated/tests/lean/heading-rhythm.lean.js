import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { TEMPLATES, headingSpaceBefore } from '../../src/v2/templates/definitions.js';
import { runPipeline } from '../../src/v2/runtime/pipeline.js';

/* Token-aware heading rhythm + run-bisection gates.
 * Rhythm assertions target tokens through headingSpaceBefore (never
 * hardcoded points); layout assertions target pagination behavior. */

const docOf = (markdown, extra = {}) => ({
  title: 'Rhythm', template: 'base',
  blocks: [{ title: 'A', markdown, masthead: { enabled: false }, flags: { autofix: true, optimize_tables: true, split_equations: true }, columns: null }],
  ...extra,
});
const FIX = { timestamp: 1700000000000, seed: 'rhythm' };

describe('heading rhythm tokens', () => {
  it('every template carries finite spaceBefore for levels 1-4', () => {
    for (const [id, tmpl] of Object.entries(TEMPLATES)) {
      for (let lv = 1; lv <= 4; lv++) {
        const v = tmpl.headingDecorators?.[lv]?.spaceBefore;
        assert.ok(Number.isFinite(Number(v)), `${id} H${lv} spaceBefore=${v}`);
      }
    }
  });

  it('spaceBefore is monotonic non-increasing down the hierarchy', () => {
    for (const [id, tmpl] of Object.entries(TEMPLATES)) {
      const vals = [1, 2, 3, 4].map((lv) => headingSpaceBefore(tmpl.headingDecorators, lv));
      for (let i = 1; i < vals.length; i++) {
        assert.ok(vals[i] <= vals[i - 1], `${id}: H${i}(${vals[i - 1]}) >= H${i + 1}(${vals[i]})`);
      }
    }
  });

  it('resolver honors tokens, falls back to legacy 6/4/2.5', () => {
    assert.equal(headingSpaceBefore({ 2: { spaceBefore: 9 } }, 2), 9);
    assert.equal(headingSpaceBefore({}, 1), 6);
    assert.equal(headingSpaceBefore({}, 2), 4);
    assert.equal(headingSpaceBefore({}, 3), 2.5);
    assert.equal(headingSpaceBefore({}, 6), 2.5);
    assert.equal(headingSpaceBefore(null, 1), 6);
  });
});

describe('heading-run pagination', () => {
  it('a 4-heading run plus fitting panoramic table shares one body page', async () => {
    const md = `# Sistema respiratório:\n## Diagnóstico por imagem:\n### Tomografia de tórax:\n#### Parâmetros:\n\n| A | B |\n|---|---|\n| 1 | 2 |\n| 3 | 4 |`;
    const dl = (await runPipeline({
      payload: docOf(md, { table_layout_mode: 'panoramic' }), mode: 'paginate', ...FIX,
    })).displayList;
    assert.equal(dl.totalPages, 1, `expected single page, got ${dl.totalPages}`);
  });

  it('heading runs never strand alone across pages on roomy pages', async () => {
    const md = `# A\n## B\n### C\n\nCorpo final com algum texto para fechar a seção.`;
    const dl = (await runPipeline({ payload: docOf(md), mode: 'paginate', ...FIX })).displayList;
    assert.equal(dl.totalPages, 1, `expected single page, got ${dl.totalPages}`);
  });
});
