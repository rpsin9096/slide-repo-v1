/**
 * Layout-cache isolation guard.
 *
 * PDFKit's EmbeddedFont.layoutRun normalizes the positions it gets from
 * fontkit IN PLACE:
 *   position[key] *= this.scale;
 *   position.advanceWidth = run.glyphs[i].advanceWidth * this.scale;
 *
 * A fontkit font reused across documents (the Worker's FK_PARSED_CACHE path)
 * would therefore rescale the same cached run on every render: the second
 * document sees xAdvance scaled twice while advanceWidth is recomputed once,
 * so PDFKit emits a large negative TJ adjustment between every glyph. The
 * visible result is compressed/tracking-broken text in the live Worker only
 * (Node opens a fresh font per document).
 *
 * attachFkFontLayoutCache must return per-call copies so this cannot happen.
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createRequire } from 'node:module';
import { attachFkFontLayoutCache } from '../../src/v2/fonts/shaping.js';

// fontkit ships CJS; a static default import fails on Node 26 ESM interop.
const fontkit = createRequire(import.meta.url)('fontkit');

test('W14.1: a reused fontkit layout run is isolated from caller mutation', () => {
  const font = fontkit.create(fs.readFileSync('assets/fonts/Arimo-Regular.ttf'));
  attachFkFontLayoutCache(font);

  const first = font.layout('Hemorragia');
  const pristine = first.positions.map((p) => ({ ...p }));

  // Simulate one PDFKit document normalizing the run it received.
  const scale = 1000 / font.unitsPerEm;
  for (let i = 0; i < first.positions.length; i++) {
    const position = first.positions[i];
    for (const key of Object.keys(position)) position[key] *= scale;
    position.advanceWidth = first.glyphs[i].advanceWidth * scale;
  }

  const second = font.layout('Hemorragia');
  assert.notStrictEqual(second, first, 'cached run must not be the same object');
  assert.notStrictEqual(second.positions, first.positions, 'positions array must be per-call');
  assert.ok(Number.isFinite(second.advanceWidth) && second.advanceWidth > 0, 'prototype getters (advanceWidth) must survive cloning');
  assert.deepEqual(
    second.positions.map((p) => ({ ...p })),
    pristine,
    'second render must see fontkit-unit advances, not once-normalized ones',
  );
});

test('W14.2: repeat calls return equal, independent runs', () => {
  const font = fontkit.create(fs.readFileSync('assets/fonts/Arimo-Regular.ttf'));
  attachFkFontLayoutCache(font);

  const a = font.layout('conteúdo');
  const b = font.layout('conteúdo');
  assert.notStrictEqual(a.positions, b.positions);
  a.positions[0].xAdvance += 123;
  assert.notEqual(a.positions[0].xAdvance, b.positions[0].xAdvance);
});
