import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readCorpus } from '../corpus/index.js';
import { checkColumnOrder, checkDisparity, checkDiagnostics } from '../../src/v2/qa/span-gates.js';
import { V2MulticolGalleyBalancer } from '../../src/v2/layout/multicol.js';
import { makeBox } from '../../src/v2/layout/box.js';
import { runPipeline } from '../../src/v2/runtime/pipeline.js';

const b = (h, extra = {}) => makeBox('para', { heightPt: h, lines: 1, text: 'x', ...extra });
const bal = (items) => new V2MulticolGalleyBalancer({}).balance(items);

describe('span gates', () => {
  it('col2 never taller than col1 on region-sized galleys', () => {
    const cases = [
      Array.from({ length: 10 }, () => b(12)),
      Array.from({ length: 7 }, () => b(12)),
      [b(14), b(12), b(24), b(12), b(36), b(12)],
      [b(12)],
    ];
    for (const items of cases) {
      assert.equal(checkColumnOrder(bal(items)).pass, true);
    }
    // When col2 <= col1 is only enforceable by emptying col2 — a whole
    // column of void, the broken-page look — both columns stay alive and
    // col2 may run taller: reading order is intact and the feet stay as
    // close as the items allow ([12 | 36] is the item-granular optimum).
    const both = bal([b(12), b(36)]);
    assert.equal(both.col2.length > 0, true, 'col2 never empties on a multi-item galley');
    assert.equal(both.height2 - both.height1, 24);
  });
  it('canonical galleys balance within one line', () => {
    const cases = [
      Array.from({ length: 10 }, () => b(12)),
      Array.from({ length: 7 }, () => b(12)),
      [b(14), b(12), b(24), b(12), b(36), b(12)],
    ];
    for (const items of cases) {
      assert.equal(checkDisparity(bal(items), 12).pass, true);
    }
  });
  it('diagnostics checker pins frozen core', () => {
    const dl = { totalPages: 5, diagnostics: { tableSlices: 0, panoramicTransitions: 2, overfullColumns: 0 } };
    const frozen = { totalPages: 5, diagnostics: { tableSlices: 0, panoramicTransitions: 2, overfullColumns: 0 } };
    assert.equal(checkDiagnostics(dl, frozen).pass, true);
    assert.equal(checkDiagnostics({ ...dl, totalPages: 6 }, frozen).pass, false);
  });
  it('fixtures hold gates: zero overfull and frozen panoramic rhythm', async () => {
    const here = dirname(fileURLToPath(import.meta.url));
    const repo = join(here, '..', '..');
    const saved = JSON.parse(readFileSync(join(repo, 'tests', 'fixtures', 'span-baseline.json'), 'utf-8'));
    const docOf = (markdown) => ({
      title: 'Baseline', template: 'base',
      blocks: [{ title: 'A', markdown, masthead: { enabled: false }, flags: { autofix: true, optimize_tables: true, split_equations: true }, columns: null }],
    });
    for (const name of ['sample1.md', 'sample2.md', 'sample3.md', 'text-test.md']) {
      const markdown = readCorpus(name);
      const { displayList } = await runPipeline({ payload: docOf(markdown), mode: 'paginate', seed: saved.seed, timestamp: saved.timestamp });
      assert.equal(displayList.diagnostics.overfullColumns, 0, `${name} zero overfull`);
      assert.equal(checkDiagnostics(displayList, saved.fixtures[name]).pass, true, `${name} frozen rhythm`);
    }
  });
});
