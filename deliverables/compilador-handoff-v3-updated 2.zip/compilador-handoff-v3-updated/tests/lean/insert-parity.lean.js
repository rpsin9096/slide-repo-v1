import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { INSERT_ITEMS, insertSnippetFor, applyRichCommand } from '../../static/editor-core.js';

const KEYS = ['h1', 'h2', 'h3', 'h4', 'p', 'ul', 'ol', 'quote', 'tbl', 'code', 'math', 'callout', 'rule'];

describe('P1 unified Inserir catalog', () => {
  it('covers h1-h4 + paragraph + lists + islands', () => {
    const keys = INSERT_ITEMS.map((x) => x.key);
    for (const k of KEYS) assert.ok(keys.includes(k), `catalog must include ${k}`);
  });

  it('snippets are byte-identical for atCursor vs handleInsertAt', () => {
    assert.equal(`${insertSnippetFor('h4')}\n`, '#### Novo Título 4\n');
    assert.equal(`${insertSnippetFor('h1')}\n`, '# Novo Título\n');
    assert.ok(insertSnippetFor('tbl').includes('| Coluna 1 | Coluna 2 |'));
    assert.ok(insertSnippetFor('math').includes('$$'));
    assert.ok(insertSnippetFor('callout').startsWith('::: info'));
    assert.equal(insertSnippetFor('nope'), '');
  });

  it('h4 snippet is a real h4 the seam toggles', () => {
    const r1 = applyRichCommand('Texto', 0, 5, 'h4');
    assert.equal(r1.text, '#### Texto');
    const r2 = applyRichCommand(r1.text, 0, r1.text.length, 'h4');
    assert.equal(r2.text, 'Texto');
  });

  it('markdown insert bar renders from the same catalog (h1-h4 present)', async () => {
    const src = await import('node:fs').then((fs) => fs.readFileSync(new URL('../../static/v2-app.js', import.meta.url), 'utf8'));
    assert.ok(src.includes('INSERT_ITEMS'), 'md insert bar must render from INSERT_ITEMS');
    assert.ok(!src.includes("data-mi=\"h1\">H1</button>\n"), 'no hardcoded subset without h3/h4');
  });
});
