import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

/* M7 mobile theme — REGRESSION LOCK, not TDD: triage reproduction proved the
 * Tema button already rides the Mais sheet move list, flips data-theme both
 * ways on 360px, and restores on sheet close with zero JS errors. No
 * production change was made (generalizing the binding would be gratuitous).
 * This gate locks the path against future breakage.
 * Evidence: probe 360px dark→light→dark + restored=true.
 * Run: node --test tests/lean/mobile-theme-m7.lean.js */

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..');
const src = (p) => readFileSync(join(root, p), 'utf8');

describe('M7 — mobile theme toggle survives the sheet round-trip', () => {
  it('toggle rides the Mais sheet move list', () => {
    const js = src('static/v2-app.js');
    assert.ok(
      js.includes("['clean-tags-btn', 'theme-toggle'"),
      'theme-toggle must stay in the sheet move list'
    );
  });

  it('initTheme binds flip + persistence on the same node', () => {
    const js = src('static/v2-app.js');
    assert.ok(js.includes("$('#theme-toggle')?.addEventListener('click'"), 'click bound');
    assert.ok(js.includes('doe-v2-new-theme'), 'choice persisted');
    assert.ok(js.includes('aria-pressed'), 'pressed state synced');
    const html = src('static/index.html');
    assert.ok(html.includes('id="theme-toggle"'), 'button exists in topbar');
  });
});
