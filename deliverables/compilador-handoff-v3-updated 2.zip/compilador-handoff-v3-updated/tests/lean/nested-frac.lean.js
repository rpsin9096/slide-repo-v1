/**
 * Nested-brace \frac (user doc: `$IT = \frac{\text{…}}{\text{…}}$`).
 *
 *  G-frac1 — nested braces expand recursively: `\frac{\text{A}}{\text{B}}`
 *  becomes `(A)/(B)`, never `fracAB` with brace-strip garbage.
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { InlineMath } from '../../src/v2/modules/math-module.js';

const textOf = (runs) => runs.map((r) => r.text).join('');

describe('nested-brace frac', () => {
  it('G-frac1: \\frac with \\text args expands', () => {
    assert.equal(
      textOf(InlineMath.expand(String.raw`IT = \frac{\text{Dose}}{\text{Terapêutica}}`)),
      'IT = (Dose)/(Terapêutica)',
    );
  });

  it('G-frac1b: doubly nested frac expands inside-out', () => {
    assert.equal(
      textOf(InlineMath.expand(String.raw`x = \frac{\frac{a}{b}}{c}`)),
      'x = ((a)/(b))/(c)',
    );
  });
});
