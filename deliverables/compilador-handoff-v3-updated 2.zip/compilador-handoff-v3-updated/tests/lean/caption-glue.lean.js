/**
 * Caption promotion + line-glue gates (user report 2026-10-04, farmacologia).
 *
 *  G-cap1 — a heading run that opens a region directly before a panoramic
 *  span renders full-width (scope `span`), never stranded in one column
 *  above its own table.
 *
 *  G-glue1 — no display-list line starts with closing punctuation or a
 *  sub/superscript run: `$R^*$` tokenizes apart, and the `*`/`,` must ride
 *  with their base instead of opening a column (`*, …` orphan).
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { GeometryCompiler, wrapRunsToLines } from '../../src/v2/compiler/geometry-compiler.js';
import { createMeasureContext } from '../../src/v2/drivers/pdfkit/blaster.js';

const CAPTION_MD = '## Familias de receptores farmacologicos:\n\n'
  + '| Familia de Receptor | Topografia Celular | Mecanismo de Acao e Transducao | Escala Temporal de Efeito | Prototipo Farmacologico |\n'
  + '| --- | --- | --- | --- | --- |\n'
  + '| Ionotropicos acoplados a canal ionico com texto longo para forcar largura panoramica | Membrana plasmatica integral com descricao longa | Abertura ou fechamento alosterico de poro transmembrana com influxo ou efluxo ionico mediado | Milissegundos | Receptor colinergico nicotinico muscular e neuronal |\n'
  + '| Segunda familia com texto igualmente longo para segunda linha tabular | Outra topografia celular detalhada | Outro mecanismo de transducao longo | Segundos a minutos | Outro prototipo farmacologico |\n';

const GLUE_MD = '- **Modelo dos dois estados**: Receptores existem em equilibrio basal entre a conformacao inativa ($R$) e ativa ($R^*$), deslocando o equilibrio alosterico para o estado ativado funcional com texto de enchimento para forcar quebras de linha em colunas estreitas de duas colunas.\n';

const LEAD_GLUE_RE = /^[,.;:!?)\]}%‰'…»"“”‘’]/u;

const firstTokenOf = (el) => {
  const runs = (el && el.runs) || [];
  for (const r of runs) {
    if (r && r.text) return { text: r.text, style: r.style };
  }
  return null;
};

describe('caption promotion + line glue', () => {
  it('G-cap1: region-opening caption before a panoramic span is span-scoped', () => {
    const dl = new GeometryCompiler().compile(
      { title: 'T', template: 'base', blocks: [{ title: 'A', markdown: CAPTION_MD }] }, {},
    );
    const caps = dl.pages.flatMap((p) => p.elements || [])
      .filter((e) => e.type === 'text' && /Familias de/.test(e.text || ''));
    assert.ok(caps.length >= 1, 'caption heading rendered');
    for (const c of caps) {
      assert.equal(c.scope, 'span', `caption stranded in ${c.scope}: ${c.text}`);
    }
  });

  it('G-glue1: no line starts with closing punct or a sub/superscript', () => {
    const dl = new GeometryCompiler().compile(
      { title: 'T', template: 'base', blocks: [{ title: 'A', markdown: GLUE_MD }] }, {},
    );
    const texts = dl.pages.flatMap((p) => p.elements || []).filter((e) => e.type === 'text');
    assert.ok(texts.length > 0, 'expected text lines');
    for (const el of texts) {
      const first = firstTokenOf(el);
      if (!first) continue;
      assert.ok(
        !(first.style === 'math-sub' || first.style === 'math-super'),
        `script orphan at line start: ${el.text}`,
      );
      assert.ok(
        !LEAD_GLUE_RE.test(first.text),
        `punct orphan at line start: ${el.text}`,
      );
    }
  });

  it('G-glue2: wrapper sweep never strands glue at any width', () => {
    // Width sweep over a math-tail paragraph (the `$R^*$` shape): the old
    // wrapper stranded `*`/`,` at 3 widths in 60..300pt; the glued wrapper
    // must strand none.
    const ctx = createMeasureContext('bauhaus', null);
    const runs = [
      { text: 'Modelo dos dois estados: equilibrio entre a conformacao inativa (', style: 'normal' },
      { text: 'R', style: 'math' },
      { text: '*', style: 'math-super' },
      { text: ', deslocando o equilibrio com enchimento extra para variar quebras de linha.', style: 'normal' },
    ];
    let lines = 0;
    for (let w = 60; w <= 300; w += 5) {
      for (const ln of wrapRunsToLines(runs, 'helvetica', 8.5, w, ctx.measure)) {
        lines++;
        const first = firstTokenOf(ln);
        if (!first) continue;
        assert.ok(
          !(first.style === 'math-sub' || first.style === 'math-super'),
          `script orphan at width ${w}: ${ln.runs.map((r) => r.text).join('|')}`,
        );
        assert.ok(
          !LEAD_GLUE_RE.test(first.text),
          `punct orphan at width ${w}: ${ln.runs.map((r) => r.text).join('|')}`,
        );
      }
    }
    assert.ok(lines > 40, `expected sweep coverage, got ${lines} lines`);
  });
});
