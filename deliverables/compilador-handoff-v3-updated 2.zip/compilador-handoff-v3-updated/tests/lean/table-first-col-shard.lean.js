import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { GeometryCompiler } from '../../src/v2/compiler/geometry-compiler.js';

const md = '| Categoria | A | B | C |\n|---|---|---|---|\n| **Descompensação** | texto longo aqui | outro texto longo | mais um texto longo |\n| **Hiponatremia** | um | dois | três |\n';
const mdAuto = '| Categoria | A | B | C |\n|---|---|---|---|\n| **Descompensação** | texto longo aqui | outro texto longo | mais um texto longo |\n';
const mdCrowded = '| H1 Supercalifragilistica | H2 Extravagantíssima | H3 Monumentalidade | H4 Transdisciplinar | H5 Eletroencefalograma | H6 Otorrinolaringologista |\n|---|---|---|---|---|---|\n| **Descompensação** | a | b | c | d | e |\n';

const boldBodyLines = (dl) => dl.pages
  .flatMap((p) => p.elements)
  .filter((e) => e.type === 'text' && e.font === 'helvetica' && (e.runs || []).some((r) => r.style === 'bold'))
  .map((e) => e.text);

describe('table first-col shard', () => {
  it('compact keeps bold first-col words whole', () => {
    const gc = new GeometryCompiler();
    const dl = gc.compile({ title: 'T', template: 'base', blocks: [{ title: '', markdown: md, tableLayout: 'compact' }] }, {});
    const lines = boldBodyLines(dl);
    assert.ok(lines.length > 0, 'expected bold body lines, got none');
    for (const t of lines) {
      assert.ok(!t.endsWith('-'), `shard: ${t}`);
    }
  });
  it('auto deciding column keeps bold first-col words whole', () => {
    const gc = new GeometryCompiler();
    const dl = gc.compile({ title: 'T', template: 'base', blocks: [{ title: '', markdown: mdAuto }] }, {});
    const lines = boldBodyLines(dl);
    assert.ok(lines.length > 0, 'expected bold body lines, got none');
    for (const t of lines) {
      assert.ok(!t.endsWith('-'), `shard: ${t}`);
    }
  });
  it('crowded compact prefers no shard over word-boundary orphans', () => {
    const gc = new GeometryCompiler();
    const dl = gc.compile({ title: 'T', template: 'base', blocks: [{ title: '', markdown: mdCrowded, tableLayout: 'compact' }] }, {});
    const lines = boldBodyLines(dl);
    assert.ok(lines.length > 0, 'expected bold body lines, got none');
    for (const t of lines) {
      assert.ok(!t.endsWith('-'), `shard: ${t}`);
    }
  });
});
