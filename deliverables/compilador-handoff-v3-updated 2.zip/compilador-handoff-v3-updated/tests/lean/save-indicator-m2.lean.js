import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

/* M2 save indicator + pagehide flush: persistence stops being silent (topbar
 * "Salvo HH:MM" ticked through the single store.save choke point) and a fast
 * tab close keeps last keystrokes (pagehide flushes adapters + store).
 * Run: node --test tests/lean/save-indicator-m2.lean.js */

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..');
const src = (p) => readFileSync(join(root, p), 'utf8');

describe('M2 — save feedback + loss-window close', () => {
  it('topbar carries a save-status pill', () => {
    assert.ok(src('static/index.html').includes('id="save-status"'), 'pill in topbar');
    assert.ok(src('static/v2-app.js').includes('save-status'), 'app drives the pill');
    assert.ok(src('static/v2-app.js').includes('Salvo'), 'pill copy present');
  });

  it('save flows through one ticking choke point + pagehide flush', () => {
    const js = src('static/v2-app.js');
    assert.ok(js.includes('updateSaveStatus'), 'tick function exists');
    assert.ok(js.includes('pagehide'), 'pagehide listener registered');
    assert.ok(js.includes('flushAdaptersToStore'), 'flush available to the handler');
  });

  it('pill styling is token-only', () => {
    const css = src('static/design-system.css');
    const i = css.indexOf('.save-status {');
    assert.notEqual(i, -1, 'missing rule: .save-status');
    const b = css.slice(css.indexOf('{', i) + 1, css.indexOf('}', css.indexOf('{', i)));
    assert.ok(b.includes('var(--'), 'pill must use var(--*) tokens');
    assert.ok(!b.match(/#[0-9a-fA-F]{3,6}/), `no hardcoded hex, got: ${b.trim()}`);
  });
});
