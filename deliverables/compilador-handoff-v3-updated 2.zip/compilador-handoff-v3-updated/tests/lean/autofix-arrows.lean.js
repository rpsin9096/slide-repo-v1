/**
 * Autofix arrow ordering (assessment bug 7).
 *
 *  G-arrow1 — the `<`-prefixed composites convert whole: `<=>` → `⇔`,
 *  `<->` → `↔`. The `->`/`=>` pre-pass must not eat their tails first.
 *
 *  G-arrow2 — existing arrows keep working: `->`, `=>`, `-->`, `<--`, `<==`.
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { TypographicAutofix } from '../../src/v2/ingest/sanitizer.js';

const apply = (s) => TypographicAutofix.apply(s, true);

describe('autofix arrow ordering', () => {
  it('G-arrow1: <=> and <-> convert whole', () => {
    assert.equal(apply('a <=> b'), 'a ⇔ b');
    assert.equal(apply('a <-> c'), 'a ↔ c');
  });

  it('G-arrow2: existing arrows unchanged', () => {
    assert.equal(apply('a -> b'), 'a → b');
    assert.equal(apply('a => b'), 'a ⇒ b');
    assert.equal(apply('a --> b'), 'a → b');
    assert.equal(apply('a <-- b'), 'a ← b');
    assert.equal(apply('a <== b'), 'a ⇐ b');
  });
});
