/**
 * Executable Acceptance & Synthetic Production Stress Suite for Layout & Geometry V3 (VG-0..VG-17).
 *
 * Tests:
 *   1. Exact frame snap math (VG-0), DisplayList 2.2.0 metadata (VG-1), and baseline roundtrip (VG-2).
 *   2. Max-margin collapse (VG-3), topskip/maxdepth bounds (VG-4), single-authority glue (VG-5),
 *      2-column band balance (VG-6), and deferred span re-solve (VG-7, F-6 fix on sample2.md).
 *   3. Shared running pitch u across paragraphs and multi-level lists (VG-8, ADR-0805).
 *   4. Container splitting without 0-line shells (VG-9), continuation cues (VG-10),
 *      water-filling table column floors (VG-11), and heading proximity >= 1.50 (VG-10/VG-12, F-13 fix).
 *   5. Boxed-element outside gaps (blockquote, code, math no longer have 0pt bottom gap, F-13).
 *   6. Multi-page TOC reservation and page-switch rendering across 32 chapters (VG-16, F-14 fix).
 *   7. Full synthetic stress documents across all 3 templates (base, bauhaus, bauhaus_minimalist)
 *      combining headings H1-H4, nested lists + task checkboxes, compact & panoramic tables,
 *      rotated tables, callouts, fenced code, display/inline math, images/captions, and emojis.
 *   8. Seeded PRNG (mulberry32) property fuzzing across 30 random Markdown documents × 3 templates.
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { TEMPLATES, rhythmForTemplate, headingSpaceBefore } from '../../src/v2/templates/definitions.js';
import { PAGE_SIZES } from '../../src/v2/core/geometry.js';
import { elementExtent } from '../../src/v2/layout/stretch-seam.js';
import {
  getFontMetrics,
  lineTopFromBaselineMpt,
  baselineFromLineTopMpt,
  inkExtentOfText,
} from '../../src/v2/fonts/metrics.js';
import {
  distributeMpt,
  resolveFrameAndTokens,
  collapsedGapMpt,
  enforceHeadingProximity,
  createLineAtom,
  createBlockAtom,
  createSpanAtom,
  enforceTableColumnFloors,
  splitContainerAtom,
  balanceBandColumns,
  resolveBandWithDeferredSpans,
  distributeColumnGlueMpt,
  computeMultiPageTocLayout,
  verifyV3Invariants,
} from '../../src/v2/compiler/v3/index.js';
import { runPipeline } from '../../src/v2/runtime/pipeline.js';
import { convertDocument } from '../../pdf-engine.js';
import { ExportPayloadBuilder } from '../../static/export-payload.js';
import { DocumentStore, normalizeBox } from '../../static/document-store.js';
import { runDualV2V3 } from '../../src/v2/compat/dual-run.js';
import { readCorpus } from '../corpus/index.js';
import { evaluateGates, contrastRatio } from '../../scripts/probe-geometry-baseline.mjs';
import { decodePdfRuns } from '../../scripts/pdf-text-runs.mjs';

function mulberry32(seed) {
  let a = seed >>> 0;
  return function next() {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

describe('Layout & Geometry V3 — VG-0..VG-17 Gate Suite & Synthetic Production Stress', () => {
  it('VG-0: snaps baseline grid unit u in integer millipoints with <= 1.5% drift across all 3 templates', () => {
    const fBase = resolveFrameAndTokens(TEMPLATES.base, PAGE_SIZES.A4);
    const fBau = resolveFrameAndTokens(TEMPLATES.bauhaus, PAGE_SIZES.A4);
    const fMin = resolveFrameAndTokens(TEMPLATES.bauhaus_minimalist, PAGE_SIZES.A4);

    assert.equal(fBase.uMpt, 12451);
    assert.equal(fBase.gridIntervals, 60);
    assert.equal(fBase.gridLines, 61);
    assert.ok(fBase.snapDrift <= 0.015);

    assert.equal(fBau.uMpt, 11821);
    assert.equal(fBau.gridIntervals, 64);
    assert.equal(fBau.gridLines, 65);
    assert.ok(fBau.snapDrift <= 0.015);

    assert.equal(fMin.uMpt, 10701);
    assert.equal(fMin.gridIntervals, 72);
    assert.equal(fMin.gridLines, 73);
    assert.ok(fMin.snapDrift <= 0.015);
  });

  it('VG-1, VG-2 & VG-14: emits DisplayList 2.2.0 metadata and matches decoded PDF baselines within <= 0.10pt', async () => {
    for (const tid of ['base', 'bauhaus', 'bauhaus_minimalist']) {
      const f = resolveFrameAndTokens(TEMPLATES[tid]);
      const font = TEMPLATES[tid].tokens.bodyFontName;
      const size = TEMPLATES[tid].fontSize;
      const topMpt = lineTopFromBaselineMpt(f.firstBaselineMpt, font, size);
      const backMpt = baselineFromLineTopMpt(topMpt, font, size);
      assert.ok(Math.abs(backMpt - f.firstBaselineMpt) <= 1);
    }

    const { displayList, buffer } = await runPipeline({
      payload: {
        title: 'V3 PDF Baseline Check',
        template: 'base',
        geometry: 'v3',
        blocks: [{ title: 'Sec 1', markdown: '# Título\n\nParágrafo um com texto suficiente.\n\n- Item A\n- Item B\n' }],
      },
      mode: 'pdf',
      geometry: 'v3',
      seed: 'v3-pdf',
      timestamp: 1700000000000,
    });

    assert.equal(displayList.irVersion, '2.2.0');
    assert.equal(displayList.schemaVersion, '2.2.0');
    assert.equal(displayList.diagnostics?.geometry?.version, 'v3');
    const decoded = decodePdfRuns(buffer);
    assert.ok(decoded.length >= 1);

    for (const page of displayList.pages) {
      assert.ok(page.frame && typeof page.frame.u === 'number');
      assert.ok(Array.isArray(page.columns) && page.columns.length >= 1);
      for (const el of page.elements) {
        if (el.type === 'text' || el.type === 'list_item') {
          assert.equal(typeof el.baseline, 'number');
          assert.ok(el.atom && typeof el.atom.id === 'string');
        }
      }
    }
  });

  it('VG-2 & F-6 Fix: eliminates the empty right column on sample2.md x bauhaus_minimalist page 1', async () => {
    const md = readCorpus('sample2.md');
    const { displayList } = await runPipeline({
      payload: {
        title: 'F-6 Regression Lock',
        template: 'bauhaus_minimalist',
        geometry: 'v3',
        blocks: [{
          title: 'A',
          markdown: md,
          masthead: { enabled: false },
          flags: { autofix: true, optimize_tables: true, split_equations: true },
        }],
      },
      mode: 'paginate',
      geometry: 'v3',
      seed: 'vertical-justify',
      timestamp: 1700000000000,
    });

    const p1 = displayList.pages[0];
    assert.equal(p1.columns.length, 2);
    assert.ok(p1.columns[0].atomCount >= 30, `col:0 should be populated (${p1.columns[0].atomCount})`);
    assert.ok(p1.columns[1].atomCount >= 30, `col:1 must not be empty (${p1.columns[1].atomCount})`);
    assert.ok(p1.columns[0].voidPt <= 0.25);
    assert.ok(p1.columns[1].voidPt <= 0.25);
  });

  it('VG-3, VG-10 & F-13 Fix: enforces max-margin collapse, heading proximity >= 1.50, and outside gaps below boxed atoms', async () => {
    assert.equal(collapsedGapMpt(6000, 12000, false), 12000);
    assert.equal(collapsedGapMpt(6000, 12000, true), 0);

    for (const tid of ['base', 'bauhaus', 'bauhaus_minimalist']) {
      const t = TEMPLATES[tid];
      const sc = t.vertical?.scalePt || { s1: 2.2, s2: 4.36, s3: 6.2, s4: 8.2 };
      const bond = sc.s1;
      for (const lvl of [1, 2, 3, 4]) {
        const before = lvl === 1 ? sc.s4 : (lvl === 2 ? sc.s3 : sc.s2);
        const ratio = before / bond;
        assert.ok(ratio >= 1.5, `${tid} H${lvl} proximity ratio ${ratio.toFixed(2)} must be >= 1.50`);
      }

      // Verify boxed elements (blockquote, code, math) leave an external gap below their rect
      const boxMd = [
        '> Citação clínica importante.',
        'Parágrafo após citação.',
        '```js\nconst a = 1;\n```',
        'Parágrafo após código.',
        '$$E = mc^2$$',
        'Parágrafo após equação.',
      ].join('\n\n');

      const { displayList } = await runPipeline({
        payload: {
          title: 'Box Outside Gap Check',
          template: tid,
          geometry: 'v3',
          blocks: [{ title: 'B', markdown: boxMd, masthead: { enabled: false } }],
        },
        mode: 'paginate',
        geometry: 'v3',
      });

      const els = displayList.pages[0].elements;
      const rects = els.filter((e) => e.type === 'rect' && (e.w || 0) > 100);
      assert.ok(rects.length >= 3, `Expected >= 3 container rects in ${tid}`);
      let checkedFollowers = 0;
      for (const r of rects) {
        const boxBot = r.y + r.h;
        // Find the first text element in the SAME column that starts below this box
        const nextText = els
          .filter((e) => e.type === 'text' && e.role !== 'chrome' && e.scope === r.scope && e.y > boxBot - 0.5)
          .sort((a, b) => a.y - b.y)[0];
        if (nextText) {
          checkedFollowers++;
          assert.ok(nextText.y - boxBot >= 3.0, `Expected >= 3pt external gap below box in ${tid}, got ${(nextText.y - boxBot).toFixed(2)}pt`);
        }
      }
      assert.ok(checkedFollowers >= 2, `Expected >= 2 boxes with same-column followers in ${tid}`);
    }
  });

  it('VG-4, VG-5 & VG-15: enforces topskip/maxdepth, single-authority glue distribution, and exact integer mpt largest-remainder', () => {
    const shares = distributeMpt(1000, [1, 1, 1]);
    assert.equal(shares.reduce((a, b) => a + b, 0), 1000);
    assert.ok(shares.every((v) => Number.isInteger(v)));
    assert.ok(Math.max(...shares) - Math.min(...shares) <= 1);

    const f = resolveFrameAndTokens(TEMPLATES.base);
    const atoms = Array.from({ length: 58 }, (_, i) =>
      createLineAtom({
        text: `Linha ${i}`,
        fontName: 'arimo',
        fontSizePt: 9.5,
        leadingMpt: f.uMpt,
        groupRole: i % 5 === 0 ? 'para-start' : 'para-mid',
      })
    );
    const pos = atoms.map((_, i) => f.firstBaselineMpt + i * f.uMpt);
    const justified = distributeColumnGlueMpt(atoms, pos, f, 'justified');
    assert.equal(justified.TerminalState, 'justified');
    assert.equal(justified.voidMpt, 0);
  });

  it('VG-16 & F-14 Fix: reserves multiple TOC pages and renders 32 chapters across pages without footer overflow', async () => {
    const blocks = Array.from({ length: 32 }, (_, i) => ({
      title: `Capítulo ${i + 1}: Fisiopatologia Clínica e Mecanismos`,
      markdown: `## Subseção ${i + 1}.1\n\nTexto do capítulo ${i + 1} com conteúdo clínico.\n\n## Subseção ${i + 1}.2\n\nMais texto.\n`,
      masthead: { enabled: i === 0, course: 'Medicina Interna', topic: 'Compêndio V3' },
    }));

    const { displayList, buffer } = await runPipeline({
      payload: {
        title: 'Tratado Multi-TOC',
        template: 'base',
        geometry: 'v3',
        chapters_toc: true,
        toc_include_headings: true,
        blocks,
      },
      mode: 'pdf',
      geometry: 'v3',
      seed: 'multitoc',
      timestamp: 1700000000000,
    });

    assert.ok(Buffer.isBuffer(buffer) && buffer.length > 5000);
    assert.ok(displayList.pagination.sections[0].startPage >= 3, `Expected >= 2 reserved TOC pages before first chapter, got startPage=${displayList.pagination.sections[0].startPage}`);
  });

  it('Synthetic Multi-Element Production Stress across all 3 templates (tables, callouts, math, code, nested lists, images, emojis)', async () => {
    const stressMd = [
      '# 1. Síntese Clínica e Engenharia de Layout 😀 ⭐',
      '',
      'Parágrafo introdutório com **negrito**, *itálico*, `código inline`, fórmulas $E = mc^2$ e símbolos $G_q \\rightarrow \\text{IP}_3 + \\text{DAG}$ para validar o motor tipográfico em milipontos inteiros.',
      '',
      '## 1.1 Hierarquia de Listas e Tarefas',
      '- [x] Nível 1: avaliação hemodinâmica inicial com monitorização contínua',
      '  - Nível 2: controle de pressão arterial média e lactato sérico',
      '    - Nível 3: titulação de vasopressores conforme resposta periférica',
      '      - Nível 4: reavaliação ecocardiográfica à beira do leito',
      '- [ ] Nível 1: segundo item de verificação clínica',
      '1. Passo ordenado um com texto descritivo longo para testar quebra de linha em lista numerada',
      '   1. Subpasso ordenado aninhado com alinhamento óptico de marcador',
      '',
      '### 1.1.1 Bloco de Citação e Código Fonte',
      '> Nota de preceptoria: A separação entre o preenchimento interno da caixa e o espaçamento externo elimina colisões visuais na borda inferior.',
      '',
      '```js',
      'function snapGridUnit(spanMpt, u0Mpt) {',
      '  const intervals = Math.round(spanMpt / u0Mpt);',
      '  return Math.round(spanMpt / intervals);',
      '}',
      '```',
      '',
      '#### 1.1.1.1 Equações de Transporte e Tabela Compacta',
      '$$\\Phi_J = -D \\cdot \\frac{\\partial C}{\\partial x} \\quad \\\\ \\quad \\Delta P = Q \\times R_{vascular}$$',
      '',
      '| Parâmetro | Basal | Estresse | Referência |',
      '|---|---|---|---|',
      '| Débito Cardíaco (L/min) | 5,0 | 14,5 | 4,0–8,0 |',
      '| Resistência Sistêmica | 1100 | 650 | 800–1200 |',
      '| Consumo de O₂ (mL/min) | 250 | 1800 | 200–300 |',
      '',
      '![Diagrama hemodinâmico ausente](nao-existe-diagrama.png "Figura 1: Curva de Frank-Starling e retorno venoso")',
      '',
      '---',
      '',
      '## 1.2 Matriz Diagnóstica Panorâmica (7 Colunas)',
      '',
      '| Síndrome | Etiologia Primária | Pré-Carga | Pós-Carga | Contratilidade | Saturação Venosa | Conduta Imediata |',
      '|---|---|---|---|---|---|---|',
      '| Hipovolêmico | Hemorragia / Desidratação | Reduzida | Elevada | Preservada | Baixa (<65%) | Cristaloide / Hemocomponentes |',
      '| Cardiogênico | Infarto Agudo / Miocardite | Elevada | Elevada | Reduzida | Baixa (<60%) | Inotrópico + Suporte Mecânico |',
      '| Distributivo | Sepse / Anafilaxia | Baixa/Normal | Reduzida | Variável | Normal/Alta | Noradrenalina + Antibiótico |',
      '| Obstrutivo | TEP Maciço / Tamponamento | Elevada | Elevada | Preservada | Baixa (<65%) | Desobstrução / Pericardiocentese |',
      '',
      ...Array.from({ length: 18 }, (_, i) =>
        `Parágrafo de fluxo contínuo número ${i + 1} após a tabela panorâmica para exercitar o preenchimento das duas colunas, a distribuição de cola elástica em milipontos e o balanceamento da banda terminal na última página.`
      ),
    ].join('\n');

    for (const tid of ['base', 'bauhaus', 'bauhaus_minimalist']) {
      for (const balance of [false, true]) {
        const { displayList, buffer } = await runPipeline({
          payload: {
            title: `Stress ${tid}`,
            template: tid,
            geometry: 'v3',
            chapters_toc: true,
            blocks: [
              {
                title: 'Módulo Clínico 1',
                markdown: stressMd,
                masthead: { enabled: true, course: 'Clínica Médica', topic: 'Hemodinâmica', prefix: 'M01' },
                flags: { autofix: true, optimize_tables: true, split_equations: true, balance_columns: balance },
              },
              {
                title: 'Módulo Rotacionado 2',
                markdown: '## Tabela Rotacionada\n\n| A | B | C | D | E |\n|---|---|---|---|---|\n| 1 | 2 | 3 | 4 | 5 |\n| 6 | 7 | 8 | 9 | 10 |\n',
                table_layout_mode: 'rotated_cw',
                masthead: { enabled: false },
              },
            ],
          },
          mode: 'pdf',
          geometry: 'v3',
          seed: `stress-${tid}-${balance}`,
          timestamp: 1700000000000,
        });

        assert.ok(Buffer.isBuffer(buffer) && buffer.length > 4000);
        assert.equal(displayList.irVersion, '2.2.0');
        assert.ok(displayList.pages.length >= 3);
        const cbY = PAGE_SIZES.A4.height - TEMPLATES[tid].margins.bottom - TEMPLATES[tid].footskip;

        for (const page of displayList.pages) {
          assert.ok(page.frame && page.frame.u > 10);
          for (const col of page.columns || []) {
            if (col.voidPt > 0.25) {
              assert.ok(col.reason, `Page ${page.pageNumber} ${col.scope} in ${tid} missing VoidReason for void=${col.voidPt}pt`);
            }
          }
          for (const el of page.elements) {
            if (!el || el.role === 'chrome' || el.type === 'rotated') continue;
            if (el.type === 'rule' && (el.y1 || 0) !== (el.y2 || 0)) continue;
            const ext = elementExtent(el);
            if (ext && ext.top < cbY - 1.0) {
              assert.ok(ext.bottom <= cbY + 0.15, `Element ${el.type} overflowed footer on ${tid} p${page.pageNumber}: bottom=${ext.bottom} > cbY=${cbY}`);
            }
          }
        }
      }
    }
  });

  it('Seeded PRNG Property Fuzzing (30 random multi-element Markdown documents across 3 templates)', async () => {
    const rng = mulberry32(20261025);
    const snippets = [
      '## Seção de Teste\n\nParágrafo inicial vinculado ao título com texto suficiente para duas linhas.',
      '### Subseção Técnica\n\nOutro parágrafo explicativo para manter a coesão temática.',
      'Parágrafo longo com várias palavras para testar a quebra de linhas e o espaçamento vertical entre blocos de texto corrido na coluna.',
      '- Item de lista 1 com texto descritivo\n- Item de lista 2 com continuação\n  - Subitem aninhado 2.1',
      '> Bloco de citação clínica com destaque lateral e margem externa.',
      '```txt\nlinha de codigo 1\nlinha de codigo 2\n```',
      '| Col 1 | Col 2 | Col 3 |\n|---|---|---|\n| Dado A | Dado B | 123 |\n| Dado C | Dado D | 456 |',
      '$$f(x) = \\int_0^x e^{-t^2} dt$$',
      '---',
    ];

    for (let s = 0; s < 30; s++) {
      const tid = ['base', 'bauhaus', 'bauhaus_minimalist'][s % 3];
      const count = 8 + Math.floor(rng() * 14);
      const parts = ['# Documento Sintético ' + (s + 1)];
      for (let k = 0; k < count; k++) {
        parts.push(snippets[Math.floor(rng() * snippets.length)]);
      }
      const md = parts.join('\n\n');
      const { displayList } = await runPipeline({
        payload: {
          title: `Fuzz ${s}`,
          template: tid,
          geometry: 'v3',
          blocks: [{ title: 'F', markdown: md, masthead: { enabled: s % 2 === 0 } }],
        },
        mode: 'paginate',
        geometry: 'v3',
        seed: `fuzz-${s}`,
        timestamp: 1700000000000,
        options: { geometry: 'v3', skip_fit_audit: true },
      });

      const cbY = PAGE_SIZES.A4.height - TEMPLATES[tid].margins.bottom - TEMPLATES[tid].footskip;
      assert.ok(displayList.pages.length >= 1);
      for (const page of displayList.pages) {
        for (const col of page.columns || []) {
          if (col.voidPt > 0.25) assert.ok(Boolean(col.reason));
        }
        for (const el of page.elements) {
          if (!el || el.role === 'chrome') continue;
          if (el.type === 'rule' && (el.y1 || 0) !== (el.y2 || 0)) continue;
          const ext = elementExtent(el);
          if (ext && ext.top < cbY - 1.0) {
            assert.ok(ext.bottom <= cbY + 0.15, `Fuzz seed ${s} (${tid}) overflowed footer: ${ext.bottom} > ${cbY}`);
          }
        }
      }
    }
  });

  it('VG-17 & Full Corpus Evaluation: passes all 18 gates (VG-0..VG-17) and runs runDualV2V3 cleanly', async () => {
    const syn = await verifyV3Invariants();
    for (let i = 0; i <= 16; i++) {
      assert.equal(syn[`VG-${i}`], true, `Expected synthetic VG-${i} to pass`);
    }

    const gates = await evaluateGates('v3');
    for (let i = 0; i <= 17; i++) {
      assert.equal(gates[`VG-${i}`], true, `Expected corpus VG-${i} to pass (${gates._details?.[`VG-${i}`]})`);
    }

    for (const tid of ['base', 'bauhaus', 'bauhaus_minimalist']) {
      assert.ok(contrastRatio(TEMPLATES[tid].colors.textmuted, '#FFFFFF') >= 4.5);
    }

    const dual = await runDualV2V3({
      title: 'Dual Check',
      template: 'base',
      blocks: [{ title: 'A', markdown: '# T\n\nTexto de verificação dual v2 vs v3.\n' }],
    });
    assert.equal(dual.v2.totalPages, dual.v3.totalPages);
    assert.equal(dual.v3.displayList.schemaVersion, '2.2.0');
  });

  it('Frontend-to-Backend E2E Seam: DocumentStore -> ExportPayloadBuilder (geometry: v3) -> paginate & convertDocument TOC parity', async () => {
    const store = new DocumentStore();
    store.setGlobal('template', 'bauhaus');
    store.setGlobal('chaptersToc', true);
    store.setGlobal('tocTitle', 'SUMÁRIO EXECUTIVO');
    store.setGlobal('tocHeadings', true);
    store.setGlobal('docTitle', 'Manual de Engenharia V3');
    store.setGlobal('docSubtitle', 'Arquitetura Vertical em Milipontos');
    store.boxes = [
      normalizeBox({
        title: 'Capítulo 1: Fundamentos',
        markdown: '# 1. Fundamentos de Layout\n\nTexto introdutório do capítulo um.\n\n## 1.1 Subseção A\n\nDetalhes da subseção A.\n',
      }, 0),
      normalizeBox({
        title: 'Capítulo 2: Tabelas e Colunas',
        markdown: '# 2. Tabelas e Colunas\n\n| A | B |\n|---|---|\n| 1 | 2 |\n\n## 2.1 Subseção B\n\nConclusão do capítulo dois.\n',
      }, 1),
    ];

    const payload = ExportPayloadBuilder.build(store, { preview: true, previewFull: true });
    assert.equal(payload.geometry, 'v3', 'ExportPayloadBuilder must default to geometry: v3');
    assert.equal(payload.engine, 'v2-modular');
    assert.equal(payload.chapters_toc, true);
    assert.equal(payload.sections.length, 2);

    // 1. /api/paginate V3 path
    const pagOut = await runPipeline({
      payload,
      mode: 'paginate',
      geometry: payload.geometry,
      options: {
        chapters_toc: payload.chapters_toc,
        toc_title: payload.toc_title,
        toc_include_headings: payload.toc_include_headings,
        doc_title: payload.doc_title,
        doc_subtitle: payload.doc_subtitle,
        geometry: payload.geometry,
        skip_fit_audit: true,
      },
    });
    const pag = pagOut.pagination;
    assert.equal(pag.geometry, 'v3');
    assert.equal(pag.chaptersToc, true);
    assert.equal(pag.tocPages, 1);
    assert.equal(pag.totalPages, 3);
    assert.equal(pag.sections.length, 2);
    assert.equal(pag.sections[0].index, 1);
    assert.equal(pag.sections[0].name, 'Capítulo 1: Fundamentos');
    assert.equal(pag.sections[0].startPage, 2);
    assert.equal(pag.sections[0].bodyPage, 1);
    assert.ok(Array.isArray(pag.sections[0].headings) && pag.sections[0].headings.length >= 2);
    assert.equal(pag.sections[1].index, 2);
    assert.equal(pag.sections[1].startPage, 3);
    assert.equal(pag.sections[1].bodyPage, 2);

    // 2. /api/convert V3 path via convertDocument
    const pdfBuffer = await convertDocument(payload, { driver: 'pdfkit', format: 'pdf' });
    assert.ok(Buffer.isBuffer(pdfBuffer) && pdfBuffer.length > 2000);
    assert.deepEqual(pdfBuffer.pagination, pag, 'convertDocument pagination sidecar must match /api/paginate V3 output');
  });
});
