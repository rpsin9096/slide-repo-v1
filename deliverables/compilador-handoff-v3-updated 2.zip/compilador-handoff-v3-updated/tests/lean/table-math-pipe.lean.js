/**
 * Math-aware table row split (assessment bug 4).
 *
 *  G-rowsplit1 — a `|` inside `$…$` is cell content, not a column break:
 *  `| $a | b$ | x |` parses as 2 cells (`$a | b$`, `x`), never 3 with
 *  dangling dollars.
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { GeometryCompiler } from '../../src/v2/compiler/geometry-compiler.js';

const textsOf = (dl) => dl.pages
  .flatMap((p) => p.elements || [])
  .filter((e) => e.type === 'text');

describe('math-aware row split', () => {
  it('G-rowsplit1: pipe inside $…$ does not split cells', () => {
    const dl = new GeometryCompiler().compile({
      title: 'T', template: 'base',
      blocks: [{
        title: 'A',
        markdown: '| H1 | H2 |\n| --- | --- |\n| $a | b$ | x |',
      }],
    }, {});
    const els = textsOf(dl);
    assert.ok(els.length > 0, 'expected rendered text');
    const cellTexts = els.map((e) => e.text || '');
    // The math cell survives whole in a single element …
    assert.ok(
      cellTexts.some((t) => t === '$a | b$'),
      `math cell broken up; elements: ${JSON.stringify(cellTexts)}`,
    );
    // … instead of sharded into `$a` / `b$` by the inner pipe.
    for (const t of cellTexts) {
      assert.ok(
        t !== '$a' && t !== 'b$',
        `cell split at math-internal pipe: ${JSON.stringify(t)}`,
      );
    }
  });
});
