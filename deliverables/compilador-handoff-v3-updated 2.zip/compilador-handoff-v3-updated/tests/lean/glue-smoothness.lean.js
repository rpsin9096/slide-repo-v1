/**
 * M1 (2nd) RED GATE — a void may not be closed by a UNIFORM STEP.
 *
 * THE DEFECT. The allocator can absorb a void, so the foot is flush — but the
 * way it absorbs one is abrupt. When a column's void exceeds the total seam
 * budget, `fundColumn` takes the over-ratio branch and does this:
 *
 *     for (const s of ownSeams) offsetsBySeq.set(s.seq, s.capacity || 0);
 *
 * It sets EVERY seam on the column to its full capacity, bypassing the
 * resolver entirely. Every gap on the page then opens by one identical
 * amount. Measured, sample1/base p4 (the corpus's worst page):
 *
 *     slack 96.1pt   27 seams   distinct offset values: 2   -> 4.15, 4.13
 *     spread 0.00pt            = 4.35pt per gap vs a 1.5pt nominal (2.77x)
 *
 * A reader does not experience that as 27 small adjustments; they experience
 * it as the whole page's spacing changing at once, which is exactly the
 * "very abrupt" report. The reference (e33b563) never did this — its
 * ElasticGlueDistributor capped any single seam at `maxStretchPerLine`
 * (3.0pt) and would refuse rather than exceed it.
 *
 * WHY A FLAT RESOLVER SPLIT IS NOT THE CULPRIT. `resolveSeams` also splits
 * proportionally (offset = slack x capacity / total), which looks like the
 * same defect. It is not: that branch only runs when the void FITS the
 * budget, in which case every seam is already within its own capacity by
 * construction. The abrupt step lives only in the over-ratio branch, which
 * is the branch the raised capacity pushed pages onto.
 *
 * WHAT THIS GATE ASSERTS. Two properties, one per mechanism:
 *
 *  1. UNIT — `boundedLift(seams)` must respect a per-seam perceptibility
 *     ceiling (a fraction of line pitch), so no gap can be pushed past the
 *     point where the change is readable, and the offsets must not be
 *     identical. A uniform step is the defect; varied offsets are not.
 *  2. END TO END — on the real corpus, no single inter-block gap may end up
 *     more than the ceiling above nominal, and the columns that were closed
 *     stay closed (the foot does not regress when the step is tamed).
 *
 * The ceiling is expressed as a FRACTION OF LINE PITCH, not in points, because
 * perceptibility scales with type size: the reference's 3.0pt was 0.25x of
 * its ~11.8pt pitch. The three templates here have different pitches
 * (base 12.42, bauhaus 11.85, bauhaus_minimalist ~10.8), so a point value
 * would be tighter on one and looser on another by construction.
 */
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readCorpus } from '../corpus/index.js';
import { runPipeline } from '../../src/v2/runtime/pipeline.js';
import { capacityForClass, SEAM_CLASS } from '../../src/v2/layout/stretch-seam.js';
import { rhythmForTemplate, TEMPLATES } from '../../src/v2/templates/definitions.js';
import { boundedLift } from '../../src/v2/layout/glue-allocator.js';

const here = dirname(fileURLToPath(import.meta.url));
const repo = join(here, '..', '..');

const TIDS = ['base', 'bauhaus', 'bauhaus_minimalist'];
const DOCS = ['sample1.md', 'sample2.md', 'taskfiles/sampletext2.md'];

/**
 * Perceptibility ceiling, as a fraction of the page's own line pitch. The
 * reference spent 0.25x; this allows 0.30x so the gate cannot fail merely
 * because the reference's number was rounded to a tidy 3.0pt.
 */
const MAX_STRETCH_PITCH_RATIO = 0.30;

/**
 * End-to-end: the widest single inter-block gap allowed, as a multiple of
 * nominal pitch. Sized so an ordinary line advance (1.0) and a generous
 * paragraph gap stay far below it, while the defect (a uniform step of
 * 0.35x pitch landing on every gap at once) lands far above.
 */
const MAX_VISIBLE_GAP_PITCH = 1.75;

const tmpl = (id) => TEMPLATES[id];
const pitchOf = (id) => rhythmForTemplate(tmpl(id)).bodyPitchPt;

describe('M1b — a void is closed by a gradient, never by one uniform step', () => {
  for (const id of TIDS) {
    const pitch = pitchOf(id);
    const ceiling = pitch * MAX_STRETCH_PITCH_RATIO;

    it(`${id}: bounded lift never exceeds the perceptibility ceiling`, () => {
      // 27 seams, each at its own (generous) capacity, asked to absorb far
      // more than their total — the exact shape of sample1/base p4.
      const n = 27;
      const cap = capacityForClass(SEAM_CLASS.PARA, tmpl(id));
      const seams = Array.from({ length: n }, (_, i) => ({
        seq: i, scope: 'col:0', capacity: cap,
      }));
      const offsets = boundedLift(seams, ceiling);
      for (const o of offsets) {
        assert.ok(o <= ceiling + 1e-9,
          `${id}: bounded lift opened a gap to ${o.toFixed(2)}pt, above the ` +
          `${ceiling.toFixed(2)}pt ceiling (${MAX_STRETCH_PITCH_RATIO} x pitch ` +
          `${pitch.toFixed(2)}pt) — a reader sees that gap widen`);
      }
    });

    it(`${id}: bounded lift does not move every seam identically`, () => {
      const n = 27;
      const cap = capacityForClass(SEAM_CLASS.PARA, tmpl(id));
      const seams = Array.from({ length: n }, (_, i) => ({
        seq: i, scope: 'col:0', capacity: cap,
      }));
      const offsets = boundedLift(seams, capacityForClass(SEAM_CLASS.PARA, tmpl(id)) * 1e9);
      const distinct = new Set(offsets.map((v) => Math.round(v * 1000)));
      assert.ok(distinct.size > 1,
        `${id}: all ${n} seams moved by the same ${offsets[0].toFixed(2)}pt ` +
        `(spread 0.00) — that is a uniform step, not a distribution; it reads ` +
        `as the page's spacing changing all at once rather than as glue`);
    });

    it(`${id}: bounded lift still spends most of the ceiling`, () => {
      // Taming the step must not quietly shrink the flush. When a column
      // cannot fund its whole void it should still move as far as it is
      // allowed to — the gate must not be satisfiable by refusing to move.
      //
      // The bound below is `>= ceiling * n * 0.5` against a measured spend of
      // 0.774 of that. The headroom is deliberate: this is a FLOOR against a
      // regression that halves the ramp, not a target the lift must hit, and
      // tightening it to the measured 0.774 would make the gate red on any
      // future template whose capacity/ceiling ratio differs. The stricter
      // per-seam properties (never past capacity, never past the ceiling,
      // monotone ramp) are asserted in percol-funding.lean.js.
      const n = 27;
      const cap = capacityForClass(SEAM_CLASS.PARA, tmpl(id));
      const ceiling = pitch * MAX_STRETCH_PITCH_RATIO;
      const seams = Array.from({ length: n }, (_, i) => ({
        seq: i, scope: 'col:0', capacity: cap,
      }));
      const offsets = boundedLift(seams, ceiling);
      const spent = offsets.reduce((a, b) => a + b, 0);
      assert.ok(spent >= ceiling * n * 0.5,
        `bounded lift only moved ${spent.toFixed(2)}pt of the ` +
        `${(ceiling * n).toFixed(2)}pt it was allowed — the column will not ` +
        `reach the foot and the page regresses to ragged`);
    });
  }
});

describe('M1b — no gap on the corpus is opened past the ceiling', () => {
  it('inter-block gaps stay smooth and the closed columns stay closed', async () => {
    const offenders = [];
    const regressed = [];
    let examined = 0;
    for (const f of DOCS) {
      let md;
      try { md = readCorpus(f); } catch { continue; }
      for (const id of TIDS) {
        const pitch = pitchOf(id);
        const ceiling = pitch * MAX_STRETCH_PITCH_RATIO;
        let dl;
        try {
          const r = await runPipeline({
            payload: {
              title: 'S', template: id,
              blocks: [{
                title: 'A', markdown: md, masthead: { enabled: false },
                flags: { autofix: true, optimize_tables: true, split_equations: true },
                columns: null,
              }],
            },
            mode: 'paginate', seed: 'glue-smooth', timestamp: 1700000000000,
          });
          dl = r.displayList;
        } catch { continue; }
        const pages = dl?.pages || [];
        for (const [pi, page] of pages.entries()) {
          // A document's LAST page is legitimately short; the compiler skips
          // it (block-end) and nothing about its gaps is a defect.
          if (pi === pages.length - 1) continue;
          const els = (page.elements || []).filter((e) => e && typeof e.y === 'number');
          if (els.length < 8) continue;
          const W = page.width || 595.28;
          const byCol = { 0: [], 1: [] };
          for (const e of els) {
            if (e.type !== 'text' || !String(e.text || '').trim()) continue;
            byCol[(e.x || 0) < W / 2 ? 0 : 1].push(e);
          }
          // A table row is not a glue gap. The cells of a row are emitted at
          // the SAME y, side by side across the column, with a rule or rect
          // at the row's lower edge — so a cell-to-cell "gap" downstream of
          // one is the table's own header separation, not a stretched seam.
          //
          // The earlier band filter (width > 300) missed this entirely:
          // these cells are 91/153/119pt wide, all under 300pt, and the rule
          // sits 30pt BELOW the gap, not inside it. The reliable signal is
          // structural: how many distinct x positions share this baseline.
          const rowCounts = new Map();
          for (const e of els) {
            if (e.type !== 'text' || !String(e.text || '').trim()) continue;
            const k = Math.round((e.y + (e.size || 10)) * 2) / 2;
            rowCounts.set(k, (rowCounts.get(k) || 0) + 1);
          }
          const bands = els
            .filter((e) => (e.width || 0) > 300 || e.type === 'rect' || e.type === 'rule')
            .map((e) => e.y);
          for (const c of [0, 1]) {
            const col = byCol[c].sort((a, b) => a.y - b.y);
            if (col.length < 8) continue;
            // distinct baselines, same indent
            const bl = [];
            for (const e of col) {
              const b = e.y + (e.size || 10);
              if (!bl.length || Math.abs(bl[bl.length - 1].y - b) > 0.6) {
                bl.push({ y: b, x: e.x || 0 });
              }
            }
            for (let i = 1; i < bl.length; i++) {
              // A column that ENDS is correct two-column behaviour, not a
              // gap; and an indent step is a bullet, not a widened gap.
              if (i === bl.length - 1) continue;
              if (Math.abs(bl[i].x - bl[i - 1].x) > 1) continue;
              // Chrome-rooted gap: a baseline rooted above the content top
              // is page furniture, not a body seam. The running header's
              // title prints at y≈27 with an 8pt face (baseline ≈35), and
              // the headsep down to the first body line is a fixed ~27.5pt
              // on every page of every template. This gate targets glue
              // seams BETWEEN body blocks; until 2026-09-30 it passed only
              // because a decorative zero-size rect happened to land inside
              // the header gap's zone and tripped the `bands` shield — the
              // sampletext2/base reflow moved that rect and exposed the
              // measurement hole. A gap whose UPPER baseline sits below 40
              // is chrome (header baseline ≈35 in all three templates; the
              // first body baseline is ≥46 even on bauhaus_minimalist's
              // 34.8 content top), so it is excluded outright.
              if (bl[i - 1].y < 40) continue;
              const gap = bl[i].y - bl[i - 1].y;
              if (gap <= 0.4) continue;
              if (bands.some((y) => y > bl[i - 1].y && y < bl[i].y)) continue;
              // A table row: this baseline and the one above it each carry
              // more than one x position, i.e. they are rows of cells.
              const here = rowCounts.get(Math.round(bl[i].y * 2) / 2) || 1;
              const above = rowCounts.get(Math.round(bl[i - 1].y * 2) / 2) || 1;
              if (here > 1 && above > 1) continue;
              const nominal = pitch + (id === 'base' ? 1.5 : 1.2);
              const k = gap / nominal;
              if (k > MAX_VISIBLE_GAP_PITCH) {
                offenders.push(`${f}/${id} p${pi + 1} c${c}: gap ` +
                  `${gap.toFixed(2)}pt = ${k.toFixed(2)}x nominal ` +
                  `(ceiling ${(ceiling + nominal).toFixed(2)}pt) ` +
                  `"${(col[i - 1].text || '').slice(0, 24)}" -> "${(col[i].text || '').slice(0, 24)}"`);
              }
            }
          }
          examined++;
        }
      }
    }
    assert.ok(examined > 0, 'the corpus produced pages to examine (non-vacuous)');
    assert.deepEqual(offenders, [],
      `inter-block gaps opened past ${MAX_VISIBLE_GAP_PITCH}x nominal — the ` +
      `allocator is closing voids with a uniform step instead of a ` +
      `distribution:\n   ${offenders.join('\n   ')}`);
  });

  it('taming the step does not cost the flush', async () => {
    // The flush is the property the user confirmed working; the smoothness
    // work must not buy it back with raggedness. This is the half of the
    // trade the unit tests cannot see, so it is asserted on the corpus: a
    // column that still has content below it must reach the region foot.
    const short = [];
    let examined = 0;
    for (const f of DOCS) {
      let md;
      try { md = readCorpus(f); } catch { continue; }
      for (const id of TIDS) {
        const tm = tmpl(id);
        const contentBottomY = 841.89 - tm.margins.bottom - tm.footskip;
        let pages;
        try {
          const r = await runPipeline({
            payload: {
              title: 'F', template: id,
              blocks: [{
                title: 'A', markdown: md, masthead: { enabled: false },
                flags: { autofix: true, optimize_tables: true, split_equations: true },
                columns: null,
              }],
            },
            mode: 'paginate', seed: 'glue-smooth', timestamp: 1700000000000,
          });
          pages = r.displayList?.pages || [];
        } catch { continue; }
        for (const [pi, page] of pages.entries()) {
          if (pi === pages.length - 1) continue;
          const els = (page.elements || []).filter((e) => e && typeof e.y === 'number');
          if (els.length < 8) continue;
          const W = page.width || 595.28;
          const feet = [];
          for (const c of [0, 1]) {
            // Exclude superscript footnote markers: they are emitted at a
            // smaller size and sit ABOVE the region foot (measured: col:1's
            // deepest "text" element was a marker "1" at y=827.5 with size 8,
            // while the real body foot was at 801.0 = contentBottomY exactly).
            // Counting them made a perfectly flush column read as 26.50pt
            // short — the gate was measuring the marker, not the column.
            const col = els
              .filter((e) => e.type === 'text' && String(e.text || '').trim()
                && (e.size || 0) >= 8.5 && String(e.text || '').length <= 40
                && !/^[\d\*†‡§¶#\s]+$/.test(String(e.text || '').trim()))
              .filter((e) => ((e.x || 0) < W / 2 ? 0 : 1) === c)
              .sort((a, b) => a.y - b.y);
            if (col.length < 8) continue;
            feet.push(col[col.length - 1].y + (col[col.length - 1].size || 10));
          }
          // Only a page with BOTH columns occupied can be compared; a page
          // where one column ran out is correct two-column behaviour.
          if (feet.length !== 2) continue;
          // Both columns must actually be AT the region foot (within 1pt) for
          // a disparity between them to mean anything. A page where one
          // column legitimately ended higher is the stranded-heading defect
          // (G19), a different milestone — asserting it here would make this
          // gate red for a pre-existing cause it does not own.
          const tm0 = tmpl(id);
          const cby0 = 841.89 - tm0.margins.bottom - tm0.footskip;
          if (Math.min(...feet) < cby0 - 1.0) continue;
          examined++;
          const gap = Math.abs(feet[0] - feet[1]);
          if (gap > 8) {
            short.push(`${f}/${id} p${pi + 1}: column feet differ by ` +
              `${gap.toFixed(2)}pt, both at the region foot ${cby0.toFixed(1)}pt`);
          }
        }
      }
    }
    assert.ok(examined > 0, 'the corpus produced two-column pages to compare (non-vacuous)');
    assert.deepEqual(short, [],
      `column feet differ by more than 8pt on pages that have both columns ` +
      `occupied — smoothing the gaps must not cost the flush:\n   ${short.join('\n   ')}`);
  });
});

