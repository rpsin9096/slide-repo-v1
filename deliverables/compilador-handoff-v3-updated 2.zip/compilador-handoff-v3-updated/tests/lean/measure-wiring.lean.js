import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { measure } from '../../src/v2/layout/coordinator.js';
import { runPipeline } from '../../src/v2/runtime/pipeline.js';

const stub = (w) => (w === ' ' ? 3 : 10);
const LONG = `Para ${'word '.repeat(30).trim()}`;
const blocks = [{ title: '', markdown: LONG }];

describe('measure wiring', () => {
  it('default ignores no opts (characterization)', () => {
    assert.deepEqual(measure(blocks), measure(blocks, {}));
    assert.deepEqual(measure(blocks), measure(blocks, { mode: 'estimado' }));
  });
  it('real mode wraps long lines with the measurer', () => {
    const est = measure(blocks);
    const real = measure(blocks, { mode: 'real', measure: stub, colWidthPt: 40 });
    const para = (list) => list.find((x) => x.kind === 'para');
    assert.equal(para(est).heightPt, 12);
    assert.ok(para(real).heightPt > para(est).heightPt, `real=${para(real).heightPt} est=12`);
  });
  it('typst-source honors measureMode opt-in', async () => {
    const payload = { title: 'W', template: 'base', blocks: [{ title: '', markdown: LONG }] };
    const base = await runPipeline({ payload, mode: 'typst-source', seed: 'w', timestamp: 1700000000000 });
    const wired = await runPipeline({
      payload, mode: 'typst-source', seed: 'w', timestamp: 1700000000000,
      options: { measureMode: 'real', measureColWidthPt: 40, measure: stub },
    });
    assert.notEqual(wired.source, base.source, 'real mode changes measured heights');
  });
});
