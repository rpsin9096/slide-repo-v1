import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { TextareaAdapter, isEditorAdapter } from '../../static/editor-adapters.js';
import { BlockEditor } from '../../static/editor-core.js';

/* M1 undo/redo buttons: the adapter seam exposes canUndo/canRedo (both
 * adapters already hold stacks), the card toolbar carries undo/redo ticons,
 * and clicks route through the active adapter with disabled-sync.
 * Run: node --test tests/lean/undo-redo-buttons.lean.js */

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..');
const src = (p) => readFileSync(join(root, p), 'utf8');

const fakeEl = (value = '') => ({
  value, selectionStart: value.length, selectionEnd: value.length,
  setSelectionRange(s, e) { this.selectionStart = s; this.selectionEnd = e; },
  focus() {}, dispatchEvent() {},
});

describe('M1 — undo/redo seam + toolbar', () => {
  it('TextareaAdapter reports stack state and round-trips', () => {
    const ad = new TextareaAdapter(fakeEl('abc'));
    assert.equal(ad.canUndo(), false);
    assert.equal(ad.canRedo(), false);
    ad.insertText('X');
    assert.equal(ad.getContent(), 'abcX');
    assert.equal(ad.canUndo(), true);
    assert.equal(ad.undo(), true);
    assert.equal(ad.getContent(), 'abc');
    assert.equal(ad.canRedo(), true);
    assert.equal(ad.redo(), true);
    assert.equal(ad.getContent(), 'abcX');
    assert.equal(isEditorAdapter(ad), true);
  });

  it('BlockEditor exposes the same availability seam', () => {
    const ed = new BlockEditor({}, () => {});
    assert.equal(ed.canUndo(), false);
    assert.equal(ed.canRedo(), false);
    assert.equal(isEditorAdapter(ed), true);
  });

  it('card toolbar carries undo/redo actions with icons', () => {
    const js = src('static/v2-app.js');
    assert.ok(js.includes('data-act="undo"'), 'undo button in template');
    assert.ok(js.includes('data-act="redo"'), 'redo button in template');
    assert.ok(js.includes('syncUndoButtons'), 'disabled-sync exists');
    const svg = src('static/icons.svg');
    assert.ok(svg.includes('id="i-undo"'), 'undo glyph in sprite');
    assert.ok(svg.includes('id="i-redo"'), 'redo glyph in sprite');
  });
});
