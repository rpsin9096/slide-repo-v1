/**
 * Block option lifecycle (user report: block Auto ≠ sidebar; dead toggles).
 *
 *  G-split-eq1 — display `\\` breaks split by default (flag on).
 *  G-split-eq2 — split_equations:false keeps one line, `\\` as space (no leak).
 *  G-blockauto1 — block `auto` forces heuristic density even under a
 *  compact document default; inherit follows the sidebar.
 *  G-autofix1 — block autofix toggle is honored (locks the working toggle).
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { GeometryCompiler } from '../../src/v2/compiler/geometry-compiler.js';
import { normalizeToDocIR } from '../../src/v2/core/contracts.js';

const compilePayload = (payload) => new GeometryCompiler().compile(
  normalizeToDocIR(payload), {},
);

const courierTexts = (dl) => dl.pages
  .flatMap((p) => p.elements || [])
  .filter((e) => e.type === 'text' && e.font === 'courier')
  .map((e) => e.text);

const cellScopes = (dl) => dl.pages
  .flatMap((p) => p.elements || [])
  .filter((e) => e.type === 'text' && typeof e.scope === 'string' && /^(A|B|a1|b1|a2|b2)$/.test(e.text || ''))
  .map((e) => e.scope);

describe('block option lifecycle', () => {
  it('G-split-eq1: \\\\ breaks split display math by default', () => {
    const dl = compilePayload({
      title: 'T', template: 'base',
      blocks: [{ title: 'A', markdown: '$$a \\\\ b$$' }],
    });
    const lines = courierTexts(dl);
    assert.ok(lines.includes('a'), `first equation missing: ${JSON.stringify(lines)}`);
    assert.ok(lines.includes('b'), `second equation missing: ${JSON.stringify(lines)}`);
  });

  it('G-split-eq2: split_equations:false keeps one line without leaking', () => {
    const dl = compilePayload({
      title: 'T', template: 'base',
      blocks: [{
        title: 'A', markdown: '$$a \\\\ b$$',
        flags: { split_equations: false },
      }],
    });
    const lines = courierTexts(dl);
    assert.equal(lines.length, 1, `expected one math line, got: ${JSON.stringify(lines)}`);
    assert.ok(!lines[0].includes('\\'), `backslash leaked: ${JSON.stringify(lines)}`);
  });

  it('G-blockauto1: block auto forces heuristics under a panoramic default', () => {
    const SMALL_TABLE = '| A | B |\n| --- | --- |\n| a1 | b1 |\n| a2 | b2 |\n';
    const mk = (tableLayout) => compilePayload({
      title: 'T', template: 'base', tableLayoutMode: 'panoramic',
      blocks: [{ title: 'A', markdown: SMALL_TABLE, ...(tableLayout ? { tableLayout } : {}) }],
    });
    const inheritScopes = cellScopes(mk(undefined));
    const autoScopes = cellScopes(mk('auto'));
    assert.ok(inheritScopes.length > 0 && inheritScopes.every((s) => s === 'span'),
      `inherit should follow forced panoramic, got: ${JSON.stringify(inheritScopes)}`);
    assert.ok(autoScopes.length > 0 && autoScopes.every((s) => s !== 'span'),
      `block auto should stay column-flow, got: ${JSON.stringify(autoScopes)}`);
  });

  it('G-autofix1: block autofix toggle honored', () => {
    const mk = (autofix) => compilePayload({
      title: 'T', template: 'base',
      blocks: [{ title: 'A', markdown: 'a -> b', flags: { autofix } }],
    });
    const on = mk(true).pages.flatMap((p) => p.elements || []).map((e) => e.text || '').join('');
    const off = mk(false).pages.flatMap((p) => p.elements || []).map((e) => e.text || '').join('');
    assert.ok(on.includes('→'), `autofix on should convert: ${JSON.stringify(on)}`);
    assert.ok(off.includes('->'), `autofix off should stay literal: ${JSON.stringify(off)}`);
  });
});
