/**
 * Mid-flow caption promotion (user report: panoramic tables with h1/h2/h3
 * or bold lead-in bullets as headers, presented as one column).
 *
 *  G-capmid1 — an H3 buried mid-bite directly before a panoramic span still
 *  promotes to full width when caption + span fit.
 *
 *  G-capmid2 — a single fully-bold L1 bullet ending in ':' directly before
 *  a span converts to a span-scoped caption (marker dropped, no TOC entry).
 *
 *  G-capmid3 — a plain (non-colon) bullet before a span is NOT promoted:
 *  it keeps its marker and column flow.
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { GeometryCompiler } from '../../src/v2/compiler/geometry-compiler.js';
import { normalizeToDocIR } from '../../src/v2/core/contracts.js';

const SMALL_SPAN_TABLE = '| A | B |\n| --- | --- |\n| a1 | b1 |\n| a2 | b2 |\n';

const compile = (markdown) => new GeometryCompiler().compile(
  normalizeToDocIR({
    title: 'T', template: 'bauhaus', tableLayoutMode: 'panoramic',
    blocks: [{ title: 'A', markdown }],
  }), {},
);

const textsOf = (dl, scope) => dl.pages
  .flatMap((p) => p.elements || [])
  .filter((e) => e.type === 'text' && (!scope || e.scope === scope))
  .map((e) => e.text || '');

describe('mid-flow caption promotion', () => {
  it('G-capmid1: mid-bite H3 caption spans with its table', () => {
    const dl = compile(`Intro paragraph with enough words to take some room here.\n\n### Caption heading here:\n\n${SMALL_SPAN_TABLE}`);
    const caps = textsOf(dl, 'span').filter((t) => /Caption heading/.test(t));
    assert.ok(caps.length >= 1, `caption not promoted to span: ${JSON.stringify(textsOf(dl, 'span'))}`);
  });

  it('G-capmid2: bold colon bullet converts to a spanning caption', () => {
    const dl = compile(`Intro paragraph with enough words to take some room here.\n\n- **Caption lead here:**\n\n${SMALL_SPAN_TABLE}`);
    const caps = textsOf(dl, 'span').filter((t) => /Caption lead/.test(t));
    assert.ok(caps.length >= 1, `bullet caption not promoted: ${JSON.stringify(textsOf(dl, 'span'))}`);
    const bullets = dl.pages
      .flatMap((p) => p.elements || [])
      .filter((e) => e.type === 'bullet');
    assert.equal(bullets.length, 0, `caption kept a marker: ${JSON.stringify(bullets)}`);
  });

  it('G-capmid3: plain bullets before a span keep list flow', () => {
    const dl = compile(`- Plain bullet here\n\n${SMALL_SPAN_TABLE}`);
    const bullets = dl.pages
      .flatMap((p) => p.elements || [])
      .filter((e) => e.type === 'bullet');
    assert.ok(bullets.length >= 1, 'plain bullet lost its marker');
  });

  it('G-capmid4: balanced-prefix room counts, not the height sum', () => {
    // A long prefix (~700pt) balances to ~350pt of column foot, leaving a
    // roomy span track below. The sum-bound would refuse (~55pt left);
    // the planned foot (~405pt left) correctly promotes.
    const filler = Array.from({ length: 20 },
      (_, i) => `- Item de enchimento número ${i} com texto propositalmente longo para ocupar três ou quatro linhas inteiras da coluna estreita e assim encher bem a página antes da legenda.`,
    ).join('\n');
    const dl = compile(`${filler}\n\n### Caption after fill:\n\n${SMALL_SPAN_TABLE}`);
    const caps = dl.pages
      .flatMap((p) => p.elements || [])
      .filter((e) => e.type === 'text' && e.scope === 'span' && /Caption after fill/.test(e.text || ''));
    assert.ok(caps.length >= 1, 'caption not promoted despite room in the span track');
  });

  it('G-gap1: caption/table/next rhythm is symmetric', () => {
    // Caption-adjacent spans shed their topGap (the caption's own trailing
    // space already provides the air): text-to-rule above ≈ rule-to-text
    // below, instead of stacking extraH + topGap on one side only.
    const dl = compile(`Intro paragraph here.\n\n### Caption heading here:\n\n${SMALL_SPAN_TABLE}\nTrailing paragraph here.`);
    const els = dl.pages[0].elements || [];
    const capBottom = Math.max(...els
      .filter((e) => e.type === 'text' && /Caption heading/.test(e.text || ''))
      .map((e) => (e.y || 0) + (e.size || 0)));
    const tableRules = els
      .filter((e) => e.type === 'rule' && e.scope === 'span'
        && Math.abs((e.y1 || 0) - (e.y2 || 0)) < 1e-9 && (e.y1 || 0) > capBottom)
      .map((e) => e.y1 || 0)
      .sort((a, b) => a - b);
    assert.ok(tableRules.length >= 2, 'table rules not found');
    const above = tableRules[0] - capBottom;
    const botRule = tableRules[tableRules.length - 1];
    const nextTop = Math.min(...els
      .filter((e) => e.type === 'text' && /^col:/.test(e.scope || '') && (e.y || 0) > botRule)
      .map((e) => e.y || 0));
    const below = nextTop - botRule;
    assert.ok(
      Math.abs(above - below) <= 2.5,
      `asymmetric span rhythm: above=${above.toFixed(2)} below=${below.toFixed(2)}`,
    );
  });
});
