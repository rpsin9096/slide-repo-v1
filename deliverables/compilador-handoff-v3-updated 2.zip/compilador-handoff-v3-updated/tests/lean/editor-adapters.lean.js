import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { TextareaAdapter, isEditorAdapter } from '../../static/editor-adapters.js';

/* CC1 step 2 seam lock: TextareaAdapter honors the EditorAdapter contract
 * against a DOM-less fake element (no browser needed). */

const fakeEl = (value = '') => ({
  value,
  selectionStart: 0,
  selectionEnd: 0,
  focused: false,
  events: [],
  setSelectionRange(s, e) { this.selectionStart = s; this.selectionEnd = e; },
  focus() { this.focused = true; },
  dispatchEvent(ev) { this.events.push(ev.type); return true; },
});

describe('CC1 EditorAdapter contract', () => {
  it('isEditorAdapter accepts the adapter, rejects partials', () => {
    assert.equal(isEditorAdapter(new TextareaAdapter(fakeEl())), true);
    assert.equal(isEditorAdapter({}), false);
    assert.equal(isEditorAdapter(null), false);
    assert.equal(isEditorAdapter({ getContent() { return ''; } }), false);
  });

  it('getContent/setContent roundtrip resets undo history', async () => {
    const ad = new TextareaAdapter(fakeEl('old'));
    await ad.setContent('new');
    assert.equal(ad.getContent(), 'new');
    assert.equal(ad.undo(), false);
  });

  it('insertText splices at caret and moves caret', () => {
    const el = fakeEl('helloworld');
    el.selectionStart = 5; el.selectionEnd = 5;
    const ad = new TextareaAdapter(el);
    ad.insertText(' ');
    assert.equal(el.value, 'hello world');
    assert.equal(el.selectionStart, 6);
    assert.equal(el.focused, true);
  });

  it('undo/redo walk the checkpoint stack', async () => {
    const el = fakeEl();
    const ad = new TextareaAdapter(el);
    await ad.setContent('a');
    el.selectionStart = 1; el.selectionEnd = 1;
    ad.insertText('b');
    assert.equal(el.value, 'ab');
    assert.equal(ad.undo(), true);
    assert.equal(el.value, 'a');
    assert.equal(ad.undo(), false);
    assert.equal(ad.redo(), true);
    assert.equal(el.value, 'ab');
    assert.deepEqual(el.events, ['input', 'input']);
  });

  it('execCommand bolds the selection, canExec gates formats', () => {
    const el = fakeEl('hello');
    el.selectionStart = 0; el.selectionEnd = 5;
    const ad = new TextareaAdapter(el);
    assert.equal(ad.canExec('bold'), true);
    assert.equal(ad.canExec('nope'), false);
    assert.equal(ad.execCommand('bold'), true);
    assert.equal(el.value, '**hello**');
  });

  it('highlight/destroy are DOM-safe no-throw with a minimal fake', () => {
    const ad = new TextareaAdapter(fakeEl('line1\nline2\n'));
    assert.doesNotThrow(() => ad.highlight(0, 5));
    assert.doesNotThrow(() => ad.destroy());
  });
});

describe('CC1 v2-app adapter seam parity', () => {
  it('v2-app re-exports the identical adapter bindings', async () => {
    const app = await import('../../static/v2-app.js');
    const mod = await import('../../static/editor-adapters.js');
    assert.equal(app.TextareaAdapter, mod.TextareaAdapter);
    assert.equal(app.isEditorAdapter, mod.isEditorAdapter);
  });
});
