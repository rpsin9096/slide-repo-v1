// Stacked-sliver reading order: a lone item stacked at the foot of the
// shorter column must not read before its own parent in the taller column.
//
// Reported 2026-10-06 (bauhaus): page 1's left-column foot shows the end of
// the sentence "Sintese relacional ... fechando" followed by the bullet
// "Valor de referencia: 1,0% a 1,5% ...", while the sentence head "a alca
// de retroalimentacao ..." opens the right column at the TOP of the page
// and the bullet's parent ("Porcentaje de reticulocitos") sits at the
// right-column foot. Column-major reading order (all of col0, then col1)
// meets the child BEFORE its parent, and wedges the orphaned child between
// the two halves of the column-boundary sentence split.
//
// Mechanism: the regions loop stacks a follow-up region below
// max(col0Y, col1Y). When the previous region filled BOTH columns and the
// new bite reduces to a single CHILD bullet, that bullet lands in the
// shorter (left) column foot while its parent sits in the taller (right)
// column — an inversion by construction. The fix defers such a lone child
// sliver to a fresh page, where it opens with its kin. Sibling/new-section
// slivers share the physical shape but are out of scope: deferring them
// cascades pagination corpus-wide for no gated defect (measured 2026-10-06:
// a broad guard tripped the column-flow cue and G12 frozen-geometry gates
// on sample1.md/base/bal=true). They stay a known remainder.
//
// The predicate is general (parent = nearest preceding list item with
// smaller indent; both must render exactly once on the same page), run over
// a minimized real-world trigger (57 lines). Non-vacuity is asserted: the
// scan must locate pairs.
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { runPipeline } from '../../src/v2/runtime/pipeline.js';

const W = 595.28;
const FOOT = 818;
const SEED = 'stacked-sliver';
const TIMESTAMP = 1700000000000;

// Minimized trigger (reported case, ddmin 73 -> 57 lines). Upstream content
// exists only to push the parent/child pair onto the page-break boundary;
// the defect is positional.
const MD = `# Trastornos de los glóbulos rojos:
## Biologia celular e cinética dos glóbulos rojos:
### Eritrocito maduro e dinâmica da hemoglobina:
- **Glóbulos rojos**: Células anucleadas com morfologia de disco bicóncavo especializadas no transporte de gases respiratórios entre os tecidos e os pulmões.
  - **Função de transporte**: Transporta $O_2$ aos tecidos sistêmicos e remove $CO_2$ tecidual em direção aos pulmões para eliminação ventilatória.
  - **Facilitação molecular**: A função carreadora dos glóbulos rojos é mediada pela hemoglobina, que viabiliza a ligação reversível com os gases.
  - **Classificação**: Os tipos principais de hemoglobina distribuem-se conforme o estágio de desenvolvimento ontogenético:
    - Hemoglobina Adulta.
    - Hemoglobina Fetal.
  - **Síntese de hemoglobina**: A velocidade de montagem macromolecular depende criticamente da biodisponibilidade de ferro para a síntese do grupo hemo.
    - **Padrão de falha**: A privação ou esgotamento de ferro limita a formação do hemo e resulta em eritrócitos com concentrações anormalmente reduzidas de hemoglobina.
    - **Distribuição**: O ferro corporal total reparte-se em compartimentos funcionais e de reserva:
      - 80% nos músculos (fração funcional e mioglobina).
      - 20% na médula ósea, no hígado e no bazo (fração de depósito e hematopoiese ativa).
  - **Cinética celular**: A integridade funcional do glóbulo rojo é restrita a uma semivida fisiológica de 120 dias.
    - **Taxa de renovação**: A taxa diária de destruição e reposição fisiológica corresponde a 1% dos glóbulos rojos circulantes.
### Eritropoyesis e mecanismos de regulação renal:
- **Eritropoyesis**: Processo contínuo de diferenciação e proliferação medular que origina novos glóbulos rojos a partir de células precursoras eritroblastos.
  - **Mecanismo**: As células madre pluripotenciais na médula ósea originam continuamente eritroblastos que proliferam e maturam até a liberação vascular.
  - **Sensor de $O_2$ renal**: A eritropoyesis responde prioritariamente às demandas metabólicas de oxigenação tecidual sistêmica.
    - **Mecanismo**: A redução da tensão de oxigênio tecidual ativa quimiorreceptores nos riñones, estimulando a síntese e secreção endócrina de eritropoyetina.
    - **Ação medular**: A eritropoyetina atua na médula ósea mediante a fixação específica a receptores de superfície em células progenitoras comprometidas.
  - **Transição de estado**: A cascata de desenvolvimento eritroide segue uma sequência morfológica unidirecional:
    - **Fase medular basal**: Célula madre pluripotencial prolifera e diferencia-se em precursor de eritroide comprometido sob estímulo de eritropoyetina.
    - **Fase de maturação nuclear**: O precursor eritroide sintetiza hemoglobina, reduz seu volume e expulsa o núcleo celular (núcleo extruído).
    - **Fase de transição vascular**: O reticulocito resultante ingressa na circulação sanguínea, completando a maturação terminal até eritrócito maduro.
  - **Síntese relacional**: A massa final de eritrócitos circulantes normaliza a oferta de $O_2$ aos tecidos, fechando a alça de retroalimentação negativa que atenua a secreção de eritropoyetina renal.
### Sistema fagocítico mononuclear e metabolismo do grupo hemo:
- **Destrucción de glóbulos rojos**: Fagocitose e lise seletiva de eritrócitos senescentes conduzida pelo sistema macrofágico tecidual.
  - **Distribuição anatômica**: As células fagocíticas responsáveis pela hemocaterese localizam-se em quatro sítios orgânicos principais:
    - Bazo.
    - Hígado.
    - Médula ósea.
    - Ganglios linfáticos.
  - **Degradação da hemoglobina**: A lise da hemoglobina no interior do fagócito desmembra a molécula em duas frações funcionais distintas:
    - **Globina**: Proteína clivada em aminoácidos elementares que retornam ao pool metabólico para reutilização celular.
    - **Grupo hem**: Molécula tetrapirrólica clivada enzimaticamente para liberar ferro elementar e produzir o pigmento tetrapirrólico linear bilirrubina.
  - **Cinética do ferro reciclado**: O ferro liberado da clivagem do hemo é exportado ao plasma e carreado para reutilização na médula ósea ou armazenado sob forma de reserva no hígado e no bazo.
  - **Depuração da bilirrubina**: A conversão do hemo gera bilirrubina não conjugada livre, insolúvel em água, que migra pelo plasma até os hepatócitos.
    - **Mecanismo hepático**: O hígado capta a fração livre e executa a conjugação glicurônica, gerando bilirrubina conjugada hidrossolúvel.
    - **Excreção terminal**: A bilirrubina conjugada é secretada ativamente na bilis e direcionada ao trato digestivo para eliminação pelas fezes e urina.
  - **Transição de estado [Hemólise patológica acelerada]**: A destruição desproporcional de hemácias excede a capacidade de conjugação e depuração hepática.
    - **Mecanismo**: A hiperprodução aguda de pigmento eleva a bilirrubina não conjugada livre plasmática sem aumento equiparado da fração conjugada direta.
---
## Avaliação laboratorial e índices eritrocitários:
### Parâmetros quantitativos do hemograma:
- **Recuento de eritrocitos (GR)**: Quantificação numérica absoluta de glóbulos rojos contidos em 1 microlitro ($1\\ mm^3$) de sangue total.
  - **Valor de referência [Varones]**: $4,2\\times 10^6/\\mu L\\text{ a }5,4\\times 10^6/\\mu L$.
  - **Valor de referência [Mujeres]**: $3,6\\times 10^6/\\mu L\\text{ a }5,0\\times 10^6/\\mu L$.
- **Hemoglobina**: Medida fotométrica direta da concentração de hemoglobina expressa em gramas por decilitro de sangue total.
  - **Valor de referência [Varones]**: $14\\ g/dL\\text{ a }16,5\\ g/dL$.
  - **Valor de referência [Mujeres]**: $12\\ g/dL\\text{ a }15\\ g/dL$.
- **Hematocrito**: Fração volumétrica percentual ocupada pela massa de glóbulos rojos em 100 mL de sangue total centrifugado.
  - **Valor de referência [Varones]**: 40% a 50%.
  - **Valor de referência [Mujeres]**: 37% a 47%.
- **Porcentaje de reticulocitos**: Proporção percentual de eritrócitos jovens recém-emitidos em relação à contagem eritrocitária total.
  - **Valor de referência**: 1,0% a 1,5% do recuento total de GR.
`;

const key = (t) => String(t || '').toLowerCase()
  .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
  .replace(/[^a-z0-9]+/g, ' ').trim();

// Source list items with indent; parent = nearest preceding smaller-indent.
function sourcePairs(md) {
  const items = [];
  md.split('\n').forEach((line) => {
    const m = line.match(/^(\s*)[-*]\s+(.+?)\s*$/);
    if (m) items.push({ indent: m[1].length, text: m[2] });
  });
  const counts = new Map();
  for (const s of items) {
    const k = key(s.text).slice(0, 24);
    counts.set(k, (counts.get(k) || 0) + 1);
  }
  const pairs = [];
  for (let k = 0; k < items.length; k++) {
    for (let j = k - 1; j >= 0; j--) {
      if (items[j].indent < items[k].indent) {
        const pk = key(items[j].text).slice(0, 24);
        const ck = key(items[k].text).slice(0, 24);
        // Unique-text pairs only: ambiguous keys cannot be located exactly.
        if (pk.length >= 10 && ck.length >= 10 && counts.get(pk) === 1 && counts.get(ck) === 1) {
          pairs.push([items[j].text, items[k].text]);
        }
        break;
      }
    }
  }
  return pairs;
}

// Reading order: col0 top->bottom, then col1 top->bottom. Index = read rank.
function readingSequence(page) {
  const els = (page.elements || []).filter((e) => e
    && e.type === 'text' && typeof e.y === 'number' && e.y < FOOT
    && String(e.text || '').trim() && (e.size || 0) > 7
    && !/^[\d\s]+$/.test(String(e.text || '').trim()));
  const cols = new Map();
  for (const e of els) {
    const c = (e.x || 0) < W / 2 ? 0 : 1;
    if (!cols.has(c)) cols.set(c, []);
    cols.get(c).push(e);
  }
  return [...cols.keys()].sort((a, b) => a - b)
    .flatMap((c) => cols.get(c).sort((a, b) => a.y - b.y));
}

// Exactly-once location by unique key; -1 when absent/ambiguous (skipped).
function locate(seq, srcText) {
  const k = key(srcText).slice(0, 24);
  const hits = [];
  seq.forEach((e, i) => { if (key(e.text).includes(k)) hits.push(i); });
  return hits.length === 1 ? hits[0] : -1;
}

async function audit(template) {
  const { displayList: dl } = await runPipeline({
    payload: {
      title: 'Sliver', template,
      blocks: [{
        title: 'B', markdown: MD, masthead: { enabled: false },
        flags: { autofix: true, optimize_tables: true, split_equations: true }, columns: null,
      }],
    },
    mode: 'paginate', seed: SEED, timestamp: TIMESTAMP,
  });
  const pairs = sourcePairs(MD);
  const violations = [];
  let located = 0;
  let skipped = 0;
  for (let p = 0; p < dl.pages.length; p++) {
    const seq = readingSequence(dl.pages[p]);
    for (const [parent, child] of pairs) {
      const pi = locate(seq, parent);
      const ci = locate(seq, child);
      if (pi < 0 || ci < 0) { skipped++; continue; }
      located++;
      if (ci < pi) violations.push(`p${p + 1}: child "${child.slice(0, 40)}" reads before parent "${parent.slice(0, 40)}"`);
    }
  }
  return { violations, located, skipped };
}

describe('stacked sliver keeps parent before child in reading order', () => {
  for (const template of ['base', 'bauhaus', 'bauhaus_minimalist']) {
    it(`${template}: no child bullet reads before its parent on the same page`, async () => {
      const { violations, located } = await audit(template);
      assert.ok(located > 10, `scan is vacuous: only ${located} pairs located`);
      assert.equal(violations.length, 0, `child-before-parent inversions:\n  ${violations.join('\n  ')}`);
    });
  }

  it('the scan actually covers the fixture (non-vacuous)', async () => {
    const { located, skipped } = await audit('bauhaus');
    assert.ok(located >= 20, `only ${located} unique pairs located (skipped ${skipped})`);
  });
});
