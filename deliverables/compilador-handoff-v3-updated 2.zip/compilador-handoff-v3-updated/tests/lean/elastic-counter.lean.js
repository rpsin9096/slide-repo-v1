import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { marked } from 'marked';
import { countElasticElements } from '../../pdf-generator.js';

/* CC3 lock: elastic inventory covers tables/images/math with legacy
 * {items,headings,paras} semantics bit-identical. */

describe('CC3 legacy parity', () => {
  it('matches the verify-pdf-geometry.mjs pinned {4,1,33}', () => {
    let elasticDoc = '# Elastic Probe\n\n';
    for (let i = 0; i < 33; i++) elasticDoc += `Parágrafo de teste número ${i} com palavras suficientes para ocupar duas linhas de coluna e gerar medida estável.\n\n`;
    elasticDoc += '- item um da lista final\n- item dois da lista final\n- item três da lista final\n- item quatro da lista final\n';
    const c = countElasticElements(marked.lexer(elasticDoc));
    assert.equal(c.itemCount, 4);
    assert.equal(c.headingCount, 1);
    assert.equal(c.paragraphCount, 33);
    assert.equal(c.tableCount, 0);
    assert.equal(c.imageCount, 0);
    assert.equal(c.mathCount, 0);
  });

  it('counts nested ordered/unordered items and blockquote paragraphs as before', () => {
    const md = '- L1\n  - L2\n    - L3\n1. O1\n   1. O2\n\n> quoted para\n';
    const c = countElasticElements(marked.lexer(md));
    assert.equal(c.itemCount, 5);
    assert.equal(c.paragraphCount, 1);
  });
});

describe('CC3 new coverage', () => {
  it('counts GFM tables with header-inclusive rows', () => {
    const md = '| H1 | H2 |\n|---|---|\n| c1 | c2 |\n\n| P1 | P2 | P3 |\n|---|---|---|\n| a | b | c |\n| d | e | f |\n';
    const c = countElasticElements(marked.lexer(md));
    assert.equal(c.tableCount, 2);
    assert.equal(c.rowCount, (1 + 1) + (1 + 2));
    assert.equal(c.paragraphCount, 0);
  });

  it('counts images at every inline depth (heading/strong/list/quote/cell)', () => {
    const md = '# H ![h](h.png)\n\nPara ![a](x.png "T") and **bold ![b](y.png)**.\n\n- item ![n](n.png)\n\n> quote ![q](q.png)\n\n| H1 | H2 |\n|---|---|\n| ![c](c.png) | plain |\n';
    const c = countElasticElements(marked.lexer(md));
    assert.equal(c.imageCount, 6);
    assert.equal(c.headingCount, 1);
    assert.equal(c.paragraphCount, 2); // top-level + one inside the blockquote
    assert.equal(c.itemCount, 1);
    assert.equal(c.tableCount, 1);
  });

  it('counts display-math pairs in paragraphs/headings, never in code', () => {
    const md = '$$E=mc^2$$\n\n## Head $$x$$\n\n```js\ncode $$notmath$$\n```\n\nUnclosed $$ stays zero.\n';
    const c = countElasticElements(marked.lexer(md));
    assert.equal(c.mathCount, 2);
  });

  it('ignores code/space/hr tokens', () => {
    const md = '```\ncode\n```\n\n---\n\ntext\n';
    const c = countElasticElements(marked.lexer(md));
    assert.deepEqual(
      [c.itemCount, c.headingCount, c.paragraphCount, c.tableCount, c.imageCount, c.mathCount],
      [0, 0, 1, 0, 0, 0],
    );
  });
});
