/**
 * M0 — column-foot disparity gate.
 *
 * The editorial flush-bottom guarantee: on every page the two text columns'
 * last lines sit at the same Y. This measures that on RENDERED PDF glyph
 * positions (decoded from the content stream), not on display-list extents,
 * because the display list carries estimates and the guarantee is about ink.
 *
 * WHY THIS GATE EXISTS: every existing gate was green while the columns ended
 * visibly uneven —
 *   - `verify-suite` 9/9 PASS
 *   - `scripts/smoke-vertical-layout.mjs` (its single failure is G7 stranded
 *     headings, a different defect)
 *   - `tests/fixtures/vertical-justify.json`, the pinned corpus lock
 *   - `scripts/measure-v2-balance.mjs`, the project's own balance gate
 * None of them could see the regression introduced across `f87e545`..`2cbe7cd`.
 * `measure-v2-balance` exempts mid-document pages and only fails a terminal
 * page that happens to be half-empty. This gate asserts the terminal page
 * unconditionally, because the terminal page is the one a reader sees the
 * section end on.
 *
 * Threshold 6pt is OLD pre-VGA parity (`e33b563`), measured with this same
 * probe: 3.21pt interior / 3.32pt last page. Spec:
 * COLUMN-FOOT-EVENNESS-SPEC.md §1, roadmap M0.
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, mkdtempSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readCorpus } from '../corpus/index.js';
import { tmpdir } from 'node:os';
import { runPipeline } from '../../src/v2/runtime/pipeline.js';
import { decodePdfRuns } from '../../scripts/pdf-text-runs.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const repo = join(here, '..', '..');
const SEED = 'column-foot';
const TIMESTAMP = 1700000000000;

/**
 * RECALIBRATED 2026-09-30 after finding the coordinate convention inverted.
 * `decodePdfRuns` returns BOTTOM-UP PDF user space: the visually-lowest
 * line — the FOOT, the whole point of this gate — is the MINIMUM body y.
 * The 2026-09-29 "correction" flipped `Math.min` to `Math.max`, so every
 * number this suite reported until now was the column TOP delta wearing the
 * foot's name; terminal pages passed vacuously (both columns start at the
 * same band top). Measured with the corrected arithmetic (92 corpus pages):
 *   terminal feet (n=18): mean 9.8pt
 *   all feet: mean 4.16pt
 * The top-alignment invariant now has its own gate
 * (`column-band-structure.lean.js`); this one owns the FOOT alone.
 *
 * TERMINAL_OUTLIER_MAX_PT accommodates the granularity-limited tail: when
 * the balanced tail's boundary lands on an atomic heading-run, every legal
 * move either overshoots the balance point (the run alone is taller than
 * d/2) or strands the run at a column foot with nothing under it. The
 * engine deliberately keeps the run with its body and takes the ragged
 * tail — the fine-tune's own contract calls this "the honest granularity
 * limit". Measured worst case: sampletext2/base p4 (2026-09-30), a 42.3pt
 * H2+H3 run over d=59.5, closing at 57.44pt rendered. The MEAN bound below
 * is the systemic guard: one granularity-limited tail is honest, a corpus
 * drifting toward many of them is a regression.
 */
const TERMINAL_OUTLIER_MAX_PT = 66;  // honest granularity limit; measured worst: 57.44pt
const TERMINAL_MEAN_MAX_PT = 14;     // measured 12.64pt (one 57.44 outlier raises the
                                     // pre-fix 9.8pt mean; without it: 9.9pt)

/**
 * Corpus-mean bound: measured 4.16pt over 92 two-column pages (2026-09-30).
 * 6pt leaves room for a corpus that grows while still failing a real
 * regression.
 */
const TARGET_MEAN_PT = 6;

const FIXTURES = ['sample1.md', 'sample2.md', 'sample3.md', 'text-test.md', 'taskfiles/sampletext2.md'];
const TEMPLATE_IDS = ['base', 'bauhaus', 'bauhaus_minimalist'];

/**
 * Only fixtures that exist. A missing corpus file must not read as a layout
 * failure — the gate measures column evenness, and "the file is absent" is a
 * different claim. (Filling this in is what made the gate RED against the
 * pre-VGA tree on its first run: `taskfiles/sampletext2.md` does not exist
 * there, and the ENOENT surfaced as a failed assertion.)
 */
const presentFixtures = () => FIXTURES.filter((f) => {
  try { readCorpus(f); return true; } catch { return false; }
});

const docOf = (markdown, template) => ({
  title: 'ColumnFoot',
  template,
  blocks: [{
    title: 'A',
    markdown,
    masthead: { enabled: false },
    flags: { autofix: true, optimize_tables: true, split_equations: true },
    columns: null,
  }],
});

const r2 = (v) => Math.round(v * 100) / 100;
const mean = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : NaN);

/**
 * Per-page column-foot disparity for one fixture/template, measured from the
 * rendered PDF. A page is counted only when BOTH columns carry body text —
 * a page with one column is a single-column region or a section tail, not
 * evidence about column evenness. The `60 / H-27` band is the same body-text
 * window `scripts/measure-v2-balance.mjs` uses, so the two agree on what
 * counts as body.
 */
const measure = async (md, template) => {
  const { buffer } = await runPipeline({
    payload: docOf(md, template), mode: 'pdf', seed: SEED, timestamp: TIMESTAMP,
  });
  assert.ok(buffer && buffer.length > 1000, `pdf rendered [${template}]`);
  const tmp = join(mkdtempSync(join(tmpdir(), 'colfoot-')), 'out.pdf');
  writeFileSync(tmp, buffer);
  const pages = decodePdfRuns(buffer);
  const rows = [];
  pages.forEach(({ W, H, runs }, i) => {
    // Chrome band only — `y > 20` drops the folio (its topmost ink is
    // ~11.3 + ~6pt; the bauhaus_minimalist foot at 28.84pt stays in),
    // `y < H - 60` drops the running head. Same body-text window
    // `scripts/measure-v2-balance.mjs` uses, expressed in PDF space.
    const body = runs.filter((p) => p.y > 20 && p.y < H - 60);
    if (body.length < 2) return;
    const left = body.filter((p) => p.x < W / 2).map((p) => p.y);
    const right = body.filter((p) => p.x >= W / 2).map((p) => p.y);
    if (!left.length || !right.length) return;
    rows.push({
      page: i + 1,
      ofPages: pages.length,
      isLast: i === pages.length - 1,
      // COORDINATE CONVENTION: `runs[].y` is BOTTOM-UP PDF user space (y
      // grows toward the page top), so the column FOOT — the visually-lowest
      // inked line — is the MINIMUM body y. `Math.max` measured the column
      // TOP; the 2026-09-29 note that called max "the foot" inverted the
      // convention, and every number calibrated from it measured the wrong
      // end of the column.
      deltaPt: r2(Math.abs(Math.min(...left) - Math.min(...right))),
    });
  });
  return rows;
};

describe('M0 column-foot disparity (rendered PDF)', () => {
  it('corpus-wide mean column-foot disparity holds at OLD parity', async () => {
    const fixtures = presentFixtures();
    assert.ok(fixtures.length >= 4, `only ${fixtures.length} corpus fixtures present`);
    const all = [];
    for (const f of fixtures) {
      const md = readCorpus(f);
      for (const template of TEMPLATE_IDS) {
        for (const row of await measure(md, template)) all.push({ ...row, doc: f, template });
      }
    }
    assert.ok(all.length >= 40, `corpus produced ${all.length} two-column pages, expected >= 40`);

    const deltas = all.map((r) => r.deltaPt);
    const m = mean(deltas);
    assert.ok(
      m <= TARGET_MEAN_PT,
      `mean disparity ${r2(m)}pt > ${TARGET_MEAN_PT}pt `
      + `(max ${r2(Math.max(...deltas))}pt, n=${deltas.length}). `
      + `Worst: ${all.filter((r) => r.deltaPt > 12).map((r) => `${r.doc}/${r.template} p${r.page} ${r.deltaPt}pt${r.isLast ? ' LAST' : ''}`).join('; ')}`,
    );
  });

  it('the TERMINAL page of every section balances — the guarantee a reader sees', async () => {
    // The half of the guarantee every pre-existing gate missed. Asserted per
    // document/template, never as a corpus mean: one lopsided section end IS
    // the defect, and averaging it away is how it shipped. Bounds are
    // calibrated on TRUE foot measurements (2026-09-30): terminal feet
    // mean 9.8pt, worst 23.04pt over 18 section ends.
    const hard = [];     // > TERMINAL_OUTLIER_MAX_PT: beyond the measured envelope
    let measured = 0;
    let sum = 0;
    for (const f of presentFixtures()) {
      const md = readCorpus(f);
      for (const template of TEMPLATE_IDS) {
        const rows = await measure(md, template);
        const last = rows.find((r) => r.isLast);
        if (!last) continue;
        measured++;
        sum += last.deltaPt;
        const where = `${f}/${template} p${last.page}/${last.ofPages} = ${last.deltaPt}pt`;
        if (last.deltaPt > TERMINAL_OUTLIER_MAX_PT) hard.push(where);
      }
    }
    assert.ok(measured >= 10, `measured ${measured} terminal pages, expected >= 10`);
    // (1) No section end may exceed the measured envelope. This names every
    //     offender, not a median.
    assert.deepEqual(hard, [], `terminal disparities beyond ${TERMINAL_OUTLIER_MAX_PT}pt: ${hard.join('; ')}`);
    // (2) The average section end stays within the flush doctrine's reach —
    //     a rising mean is the early signal before any single page breaks (1).
    const m = sum / measured;
    assert.ok(
      m <= TERMINAL_MEAN_MAX_PT,
      `terminal mean disparity ${r2(m)}pt > ${TERMINAL_MEAN_MAX_PT}pt`,
    );
  });
});
