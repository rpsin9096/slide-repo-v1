import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

/* IMAGE M1 universal normalize: everything PDFKit cannot eat (gif/webp/bmp
 * at any size) canvas-transcodes to JPEG before upload, with a white fill
 * (transparent PNGs stop going black); HEIC is early-detected with PT
 * guidance instead of a cryptic 422; rich paste/drop surfaces uploader
 * errors instead of swallowing them.
 * Run: node --test tests/lean/image-normalize-m1.lean.js */

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..');
const src = (p) => readFileSync(join(root, p), 'utf8');

describe('IMAGE M1 — normalize before upload', () => {
  it('transcode set covers gif/bmp at any size', () => {
    const js = src('static/v2-app.js');
    assert.ok(js.includes('image\\/gif'), 'gif enters the canvas path');
    assert.ok(js.includes('image\\/bmp'), 'bmp enters the canvas path');
  });

  it('canvas fill kills transparency-black', () => {
    const js = src('static/v2-app.js');
    assert.ok(js.includes('fillRect'), 'background fill before drawImage');
  });

  it('HEIC fails fast with guidance, never hits the wire', () => {
    const js = src('static/v2-app.js');
    assert.ok(js.includes('\\.(heic'), 'extension detected');
    assert.ok(js.includes('HEIC'), 'actionable PT message present');
  });

  it('rich paste/drop uploader surfaces errors', () => {
    const js = src('static/v2-app.js');
    assert.ok(js.includes('Falha ao enviar imagem'), 'rich upload failures reach showError');
  });
});
