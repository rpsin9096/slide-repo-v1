import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readCorpus } from '../corpus/index.js';
import { runPipeline } from '../../src/v2/runtime/pipeline.js';

const here = dirname(fileURLToPath(import.meta.url));
const repo = join(here, '..', '..');
const SEED = 'span-baseline';
const TIMESTAMP = 1700000000000;

const docOf = (markdown) => ({
  title: 'Baseline',
  template: 'base',
  blocks: [{ title: 'A', markdown, masthead: { enabled: false }, flags: { autofix: true, optimize_tables: true, split_equations: true }, columns: null }],
});

const core = (dl) => ({
  totalPages: dl.totalPages,
  tableSlices: dl.diagnostics.tableSlices ?? null,
  panoramicTransitions: dl.diagnostics.panoramicTransitions ?? null,
  overfullColumns: dl.diagnostics.overfullColumns ?? null,
});

describe('span coordinator wiring parity', () => {
  for (const name of ['sample3.md', 'text-test.md']) {
    it(`${name} flag on matches flag off`, async () => {
      const markdown = readCorpus(name);
      const off = (await runPipeline({ payload: docOf(markdown), mode: 'paginate', seed: SEED, timestamp: TIMESTAMP })).displayList;
      const on = (await runPipeline({ payload: docOf(markdown), mode: 'paginate', seed: SEED, timestamp: TIMESTAMP, options: { useSpanCoordinator: true } })).displayList;
      assert.equal(on.diagnostics.spanCoordinated, true, `${name} marker`);
      assert.deepEqual(core(on), core(off), `${name} parity`);
    });
  }
});
