import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { runPipeline } from '../../src/v2/runtime/pipeline.js';
import { TEMPLATES } from '../../src/v2/templates/definitions.js';
import { PAGE_SIZES } from '../../src/v2/core/geometry.js';
import {
  capacityForClass,
  classForItemKind,
  deriveGapYs,
} from '../../src/v2/layout/stretch-seam.js';

const SEED = 'stretch-seam';
const TIMESTAMP = 1700000000000;

const docOf = (markdown, extra = {}) => ({
  title: 'Seam',
  template: 'base',
  blocks: [{
    title: 'A',
    markdown,
    masthead: { enabled: false },
    flags: { autofix: true, optimize_tables: true, split_equations: true },
    columns: null,
  }],
  ...extra,
});

const CONTENT_TYPES = new Set(['text', 'rect', 'image', 'rule', 'bullet', 'checkbox']);
const isContent = (el) => !!el && CONTENT_TYPES.has(el.type);

const contentBandOf = (template) => {
  const t = TEMPLATES[template];
  const { height: A4H } = PAGE_SIZES.A4;
  return {
    top: t.margins.top + t.headheight + t.headsep,
    bottom: A4H - t.margins.bottom - t.footskip,
  };
};

const elTop = (el) => {
  if (!el || typeof el !== 'object') return null;
  if (typeof el.y === 'number') return el.y;
  if (el.type === 'rule') return Math.min(el.y1 ?? Infinity, el.y2 ?? Infinity);
  return null;
};

describe('M1 stretch-seam substrate', () => {
  it('class table resolves from template tokens, bond classes carry zero capacity', async () => {
    const tmpl = TEMPLATES.base;
    assert.equal(capacityForClass('headingBond', tmpl), 0);
    assert.equal(capacityForClass('blockEnd', tmpl), 0);
    assert.ok(capacityForClass('para', tmpl) > 0, 'para stretches');
    assert.ok(capacityForClass('list', tmpl) > 0, 'list stretches');
    assert.ok(capacityForClass('spanEdge', tmpl) > 0, 'spanEdge stretches');
    assert.ok(
      capacityForClass('tableEdge', tmpl) < capacityForClass('para', tmpl),
      'tableEdge is half capacity',
    );
    assert.equal(classForItemKind({ kind: 'heading' }), 'headingBond');
    assert.equal(classForItemKind({ kind: 'list-item' }), 'list');
    assert.equal(classForItemKind({ kind: 'table' }), 'tableEdge');
    assert.equal(classForItemKind({ kind: 'paragraph' }), 'para');
  });

  it('records one seam per inter-item boundary with scope and capacity', async () => {
    // M3 retires the seams from the frozen display list once the allocator
    // has resolved them (the IR ships no layout scratch), so this probe
    // keeps them with the V2_KEEP_SEAMS opt-in used by the corpus harness.
    process.env.V2_KEEP_SEAMS = '1';
    const md = ['# T', '', 'Alpha bravo charlie delta echo foxtrot golf.', '', 'Hotel india juliet kilo lima mike november.', '', 'Oscar papa quebec romeo sierra tango uniform.'].join('\n');
    const { displayList: dl } = await runPipeline({ payload: docOf(md), mode: 'paginate', seed: SEED, timestamp: TIMESTAMP });
    delete process.env.V2_KEEP_SEAMS;
    const seams = dl.pages.flatMap((p) => p._stretchSeams || []);
    assert.ok(seams.length >= 2, `expected inter-item seams, got ${seams.length}`);
    for (const s of seams) {
      assert.equal(typeof s.seq, 'number');
      assert.equal(typeof s.y, 'number');
      assert.ok(s.scope === 'span' || s.scope.startsWith('col:'), `scope shape, got ${s.scope}`);
      assert.equal(typeof s.klass, 'string');
      assert.equal(typeof s.capacity, 'number');
      assert.ok(s.capacity >= 0);
    }
    // No trailing seam after the final item: every seam y sits strictly above
    // the page content bottom it was recorded against.
    const { bottom } = contentBandOf('base');
    for (const p of dl.pages) {
      const pseams = p._stretchSeams || [];
      let foot = -Infinity;
      for (const el of (p.elements || [])) {
        if (!isContent(el)) continue;
        const t = elTop(el);
        if (t === null || t < bottom + 0.5) {
          const b = el.type === 'text' ? (el.y || 0) + (el.size || 10)
            : el.type === 'rule' ? Math.max(el.y1 || 0, el.y2 || 0)
            : el.type === 'bullet' ? (el.y || 0) + (el.r || 1.5)
            : el.type === 'checkbox' ? (el.y || 0) + 7.5
            : (el.y || 0) + (el.h || 0);
          foot = Math.max(foot, b);
        }
      }
      for (const s of pseams) assert.ok(s.y < foot, `seam y=${s.y} must sit above page foot=${foot}`);
    }
  });

  it('every content element carries {seamSeq, scope}; span scope only at span sites', async () => {
    const md = ['# Fisio', '', 'Fluxo regional com queda e calcio na cascata de texto para encher a coluna.', '', '| c1 | c2 | c3 | c4 | c5 |', '|---|---|---|---|---|', '| AVC isquemico com penumbra | Hipodensa | Discreta | Ausentes | Reperfusao com Alteplase em janela estendida |', '| AVC hemorragico hiperdensa | Intraparenquimatosa | Moderada | Raros | Cabeceira elevada a trinta graus |', '', '---', '', 'Texto apos a divisoria panoramica com palavras suficientes para ocupar a largura.'].join('\n');
    const { displayList: dl } = await runPipeline({ payload: docOf(md), mode: 'paginate', seed: SEED, timestamp: TIMESTAMP });
    const { top, bottom } = contentBandOf('base');
    assert.ok((dl.diagnostics.panoramicTransitions || 0) >= 1, 'fixture must carry a panoramic span');
    let contentCount = 0;
    let spanScoped = 0;
    for (const p of dl.pages) {
      for (const el of (p.elements || [])) {
        if (!isContent(el) || el.cue === 'continuation') continue;
        const t = elTop(el);
        if (t === null || t < top - 0.5 || t > bottom + 0.5) continue; // chrome lives outside the band
        contentCount++;
        assert.equal(typeof el.seamSeq, 'number', `content ${el.type} at y=${t} carries seamSeq`);
        assert.ok(typeof el.scope === 'string' && (el.scope === 'span' || el.scope.startsWith('col:')), `content ${el.type} carries scope, got ${el.scope}`);
        if (el.scope === 'span') spanScoped++;
      }
    }
    assert.ok(contentCount > 0, 'fixture must emit content elements');
    assert.ok(spanScoped > 0, 'span sites must emit span-scoped elements');
  });

  it('derived Y-list covers the legacy feather gap positions', async () => {
    const md = ['# T', '', 'Alpha bravo charlie delta echo foxtrot golf hotel india.', '', 'Juliet kilo lima mike november oscar papa quebec romeo.', '', 'Sierra tango uniform victor whiskey xray yankee zulu wun.'].join('\n');
    const { displayList: dl } = await runPipeline({ payload: docOf(md), mode: 'paginate', seed: SEED, timestamp: TIMESTAMP });
    for (const p of dl.pages) {
      const seams = p._stretchSeams || [];
      if (seams.length === 0) continue;
      const derived = deriveGapYs(seams);
      assert.ok(derived.length > 0, 'seams derive at least one gap');
      assert.ok(derived.every((y) => typeof y === 'number'), 'derived gaps are numbers');
      for (let i = 1; i < derived.length; i++) assert.ok(derived[i] - derived[i - 1] > 0.5, 'derived gaps keep the 0.5pt dedupe epsilon');
    }
  });
});
