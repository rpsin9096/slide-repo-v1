// M4 — a zero-placement plan at the end of the stream must not spin.
//
// The region loop builds a bite, asks `GalleyEngine.planColumns` for a
// partition, and retries the bite when a column overflows. Its zero-placement
// guard used `cursor < items.length` to mean "content is still queued". When
// the bite consumes the WHOLE remaining stream, `cursor` already equals
// `items.length`, so that test is false even though the balancer placed
// NOTHING — all items came back in `unplaced`. The continuous branch then
// resets `cursor = biteStart` and the same region re-enters forever.
//
// MEASURED 2026-10-26: three tables followed by a 16-row table produced a
// 298.7pt region whose plan was empty; the compiler emitted 490,870 trace
// lines in 3s at 100% CPU and never finished. The threshold was sharp: 15
// rows terminated in 45ms, 16 did not. The same shape occurs on a fresh page
// with an atomic table taller than the page (all-unplaced, cursor at stream
// end).
//
// THE ORACLE: run the real pipeline in a child with a hard timeout. A hang is
// killed with SIGTERM and fails cleanly instead of wedging the suite.
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { spawnSync } from 'node:child_process';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const repo = join(here, '..', '..');
const PER_PROBE_MS = 15000;

const child = `
  import { runPipeline } from ${JSON.stringify(join(repo, 'src/v2/runtime/pipeline.js'))};
  const rows = (n, cols) => Array.from({ length: n }, (_, r) =>
    '| ' + Array.from({ length: cols }, (_, c) => 'd' + (r + 1) + '.' + (c + 1)).join(' | ') + ' |');

  const probe = process.argv[1];
  const lines = ['# Tabelas', ''];
  if (probe === 'tail-region') {
    lines.push('## Normal', '', '| A | B | C |', '|---|---|---|', ...rows(14, 3), '');
    lines.push('Texto entre tabelas com alguma extensão para forçar fluxo em colunas e criar costuras de justificação.', '');
    lines.push('## Larga', '', '| A | B | C | D | E | F | G | H |', '|---|---|---|---|---|---|---|---|', ...rows(10, 8), '');
    lines.push('## Alta', '', '| A | B |', '|---|---|', ...rows(16, 2), '');
    lines.push('', '- item após tabela alta com texto suficiente para ocupar algumas linhas e testar o pé da coluna.', '- segundo item.', '');
  } else {
    lines.push('## Alta', '', '| A | B |', '|---|---|', ...rows(220, 2), '');
    lines.push('', '- item final.', '');
  }

  const r = await runPipeline({
    payload: {
      title: 'ZeroPlacement', template: 'base',
      blocks: [{
        title: 'A', markdown: lines.join('\\n'), masthead: { enabled: false },
        flags: { autofix: true, optimize_tables: true, split_equations: true }, columns: null,
      }],
    },
    mode: 'paginate', seed: 'zero-placement', timestamp: 1700000000000,
  });
  const text = r.displayList.pages.reduce((n, p) => n + (p.elements || []).filter((e) => e.type === 'text').length, 0);
  process.stdout.write('PAGES ' + r.displayList.pages.length + ' TEXT ' + text);
`;

describe('M4 — a table-only tail region cannot spin the replan loop', () => {
  for (const probe of ['tail-region', 'oversized-table']) {
    it(`the pipeline terminates on ${probe} (${PER_PROBE_MS}ms budget)`, () => {
      const res = spawnSync(process.execPath, ['--input-type=module', '-e', child, probe], {
        encoding: 'utf-8', timeout: PER_PROBE_MS, cwd: repo,
      });
      assert.notEqual(
        res.signal, 'SIGTERM',
        `the pipeline did not terminate within ${PER_PROBE_MS}ms on ${probe} — `
        + 'the region loop accepted an empty plan and reset the cursor. The '
        + 'zero-placement guard must key on the bite/unplaced items, not the '
        + 'post-bite cursor, and a fresh page must force progress.',
      );
      assert.equal(
        res.status, 0,
        `the pipeline exited ${res.status} (${res.signal || 'no signal'}) on ${probe}.\n`
        + `${(res.stderr || '').slice(-1200)}`,
      );
      assert.match(res.stdout || '', /PAGES \d+ TEXT \d+/, 'the pipeline produced a display list');
      const m = (res.stdout || '').match(/PAGES (\d+) TEXT (\d+)/);
      assert.ok(Number(m[1]) >= 2, 'the probe spans more than one page');
      assert.ok(Number(m[2]) > 0, 'content was actually placed');
    });
  }
});
