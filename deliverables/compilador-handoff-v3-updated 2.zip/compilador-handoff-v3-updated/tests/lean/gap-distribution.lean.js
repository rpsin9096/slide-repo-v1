/**
 * M1 RED GATE — the allocator must be able to absorb a void it can absorb
 * INVISIBLY.
 *
 * THE DEFECT. `capacityForClass()` returns the template's *nominal spacing
 * token* (paraGapPt 1.5, listGapPt 1.2) as a seam's stretch capacity, and
 * `resolveSeams()` caps absorbable slack at MAX_RATIO (1.0) times the sum of
 * those capacities. So the budget for absorbing a page void is bounded by the
 * sum of the gaps that already exist on the page:
 *
 *     sampletext2/bauhaus p1:  slack 82.53pt across 46 seams
 *                              budget = 46 x 1.2pt = 55.20pt   -> refused
 *     sample1/base p4:         slack 96.11pt across 33 seams
 *                              budget = 33 x 1.2pt = 39.60pt   -> refused
 *
 * Closing p1 needs 1.79pt per seam — 0.16x line pitch, far below anything a
 * reader can see. The engine has 46 seams and will not spend 0.6pt of each.
 * The void is therefore left for the PARTITIONER to absorb, and the partitioner
 * leaves it as dead space at the foot of a column: the 5.02x and 9.68x line-pitch
 * holes measured in gaps2.mjs, both in the document the user actually tested.
 *
 * WHY THIS IS A GATE ABOUT THE *SHAPE* OF THE BUDGET, NOT A TIGHTER BOUND.
 * A per-gap ceiling is the wrong instrument in both directions: too small and
 * the page cannot be flushed at all, too large and the page reads loose. What
 * matters is that the budget be (a) large enough to close a real void at a
 * per-seam amount that is imperceptible, and (b) expressed so a reader cannot
 * see it. So the gate asserts the RATIO between a seam's stretch capacity and
 * the line pitch it sits in — the fraction of a line the engine is allowed to
 * spend invisibly — plus the end-to-end property that the visible holes close.
 *
 * The threshold is calibrated from the pre-VGA reference build (e33b563), which
 * shipped and was accepted. It is not invented here.
 */
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readCorpus } from '../corpus/index.js';
import { runPipeline } from '../../src/v2/runtime/pipeline.js';
import { capacityForClass, SEAM_CLASS } from '../../src/v2/layout/stretch-seam.js';
import { resolveSeams, MAX_RATIO } from '../../src/v2/layout/glue-allocator.js';
import { rhythmForTemplate, TEMPLATES } from '../../src/v2/templates/definitions.js';

const here = dirname(fileURLToPath(import.meta.url));
const repo = join(here, '..', '..');

const TIDS = ['base', 'bauhaus', 'bauhaus_minimalist'];
const DOCS = ['sample1.md', 'sample2.md', 'taskfiles/sampletext2.md'];

/**
 * The perceptibility budget, as a FRACTION OF LINE PITCH. A seam may stretch
 * by this much without the change being readable. The reference engine spent
 * up to 3.0pt per gap on a ~11.8pt pitch (0.25x); this gate allows up to
 * 0.35x, which is more headroom than the reference used, and asserts the
 * engine actually has access to that much.
 */
const MAX_STRETCH_PITCH_RATIO = 0.35;

/**
 * End-to-end: the widest hole the engine may leave mid-column, as a multiple of
 * line pitch. Reference build e33b563 measured max 3.54x; the current tree
 * reaches 9.68x. Anything under 4x is within the reference's own range.
 */
const MAX_VISIBLE_HOLE_PITCH = 4.0;

const tmpl = (id) => TEMPLATES[id];
const pitchOf = (id) => rhythmForTemplate(tmpl(id)).bodyPitchPt;

describe('M1 — stretch capacity is a stretch budget, not a nominal gap', () => {
  for (const id of TIDS) {
    const pitch = pitchOf(id);
    const budget = pitch * MAX_STRETCH_PITCH_RATIO;

    it(`${id}: para seam capacity is a real invisibility budget`, () => {
      const cap = capacityForClass(SEAM_CLASS.PARA, tmpl(id));
      assert.ok(
        cap >= budget,
        `${id}: para seam capacity ${cap.toFixed(2)}pt is below the ` +
        `${budget.toFixed(2)}pt invisibility budget (${MAX_STRETCH_PITCH_RATIO} x ` +
        `pitch ${pitch.toFixed(2)}pt) — the allocator cannot close a void ` +
        `without opening a gap the reader can see`,
      );
    });

    it(`${id}: list seam capacity is a real invisibility budget`, () => {
      const cap = capacityForClass(SEAM_CLASS.LIST, tmpl(id));
      assert.ok(
        cap >= budget,
        `${id}: list seam capacity ${cap.toFixed(2)}pt is below the ` +
        `${budget.toFixed(2)}pt invisibility budget`,
      );
    });

    it(`${id}: zero-capacity classes stay zero`, () => {
      // F-6 (a heading never drifts off its body) and F-9 (trailing voids are
      // semantic) are unaffected by the budget and must not be relaxed by it.
      assert.equal(capacityForClass(SEAM_CLASS.HEADING_BOND, tmpl(id)), 0);
      assert.equal(capacityForClass(SEAM_CLASS.BLOCK_END, tmpl(id)), 0);
    });
  }

  it('a page with many seams can absorb a real void', () => {
    // The measured refusal, reproduced exactly: sampletext2/bauhaus p1.
    const pitch = pitchOf('bauhaus');
    const budget = pitch * MAX_STRETCH_PITCH_RATIO;
    const n = 46;
    const slack = 82.53;
    const seams = Array.from({ length: n }, (_, i) => ({
      seq: i, scope: 'col:0', capacity: budget,
    }));
    const r = resolveSeams(seams, slack, MAX_RATIO);
    assert.equal(r.verdict, 'applied',
      `a ${slack}pt void across ${n} seams was refused (reason "${r.reason}", ` +
      `ratio ${r.ratio.toFixed(2)}) — the page cannot be flushed and the ` +
      `partitioner leaves a visible hole instead`);
    const per = r.perSeam[0].offset;
    assert.ok(per / pitch <= MAX_STRETCH_PITCH_RATIO,
      `per-seam stretch ${per.toFixed(2)}pt is ${(per / pitch).toFixed(2)}x ` +
      `pitch — above the ${MAX_STRETCH_PITCH_RATIO}x invisibility budget`);
  });

  it('a void far beyond any sane budget still refuses', () => {
    // The gate must not become "always apply". A page needing more than the
    // whole budget at maximum permissible stretch must still go ragged, or the
    // fix is just a looser bound and the page reads loose.
    const pitch = pitchOf('bauhaus');
    const budget = pitch * MAX_STRETCH_PITCH_RATIO;
    const n = 46;
    const absurd = n * budget * 2.5;
    const seams = Array.from({ length: n }, (_, i) => ({
      seq: i, scope: 'col:0', capacity: budget,
    }));
    const r = resolveSeams(seams, absurd, MAX_RATIO);
    assert.notEqual(r.verdict, 'applied',
      `a ${absurd.toFixed(0)}pt void was accepted; the budget is unbounded and ` +
      `the page would print visibly loose`);
  });
});

describe('M1 — no visible mid-column hole survives', () => {
  it('corpus leaves no inter-block gap above the reference bound', async () => {
    const offenders = [];
    let examined = 0;
    for (const f of DOCS) {
      let md;
      try { md = readCorpus(f); } catch { continue; }
      for (const id of TIDS) {
        const pitch = pitchOf(id);
        let dl;
        try {
          const r = await runPipeline({
            payload: {
              title: 'G', template: id,
              blocks: [{
                title: 'A', markdown: md, masthead: { enabled: false },
                flags: { autofix: true, optimize_tables: true, split_equations: true },
                columns: null,
              }],
            },
            mode: 'paginate', seed: 'gap-distribution', timestamp: 1700000000000,
          });
          dl = r.displayList;
        } catch { continue; }
        for (const [pi, page] of (dl?.pages || []).entries()) {
          const els = (page.elements || []).filter((e) => e && typeof e.y === 'number');
          // A mid-column hole is empty space in a column that CONTINUES below
          // it. Two things look like a hole and are not:
          //
          //  - a full-width band (table row, rule, rect) shared by both columns;
          //  - a column that simply ENDS, with the other column still running.
          //    That is correct two-column behaviour, not dead space.
          //
          // So a "hole" only counts when the column has more content below the
          // gap AND the space between the two elements holds nothing at all —
          // no other column's text, no full-width band.
          const fullWidthBands = els
            .filter((e) => (e.width || 0) > 300 || e.type === 'rect' || e.type === 'rule')
            .map((e) => e.y);
          const col = els
            .filter((e) => e.x < 290 && e.type !== 'bullet' && (e.text || '').trim())
            .sort((a, b) => a.y - b.y);
          if (col.length < 8) continue;
          for (let i = 1; i < col.length; i++) {
            const d = col[i].y - col[i - 1].y;
            const k = d / pitch;
            if (k <= 1.15) continue;           // an ordinary line advance
            const top = col[i - 1].y, bot = col[i].y;
            // Occupied by a full-width band?
            if (fullWidthBands.some((y) => y > top && y < bot)) continue;
            // Occupied by the other column's text?
            const otherColText = els.some((e) => e.x >= 290 && e.y > top && e.y < bot
              && (e.text || '').trim() && e.type !== 'bullet');
            if (otherColText) continue;
            // The column must continue below the gap for a gap to be a defect.
            if (bot > col[col.length - 1].y + 0.5) continue;
            if (k > MAX_VISIBLE_HOLE_PITCH) {
              offenders.push(`${f}/${id} p${pi + 1}: ${k.toFixed(2)}x pitch ` +
                `(${d.toFixed(1)}pt) "${(col[i - 1].text || '').slice(0, 26)}" -> ` +
                `"${(col[i].text || '').slice(0, 26)}"`);
            }
          }
          examined++;
        }
      }
    }
    assert.ok(examined > 0, 'the corpus produced pages to examine (non-vacuous)');
    assert.deepEqual(offenders, [],
      `inter-block holes above ${MAX_VISIBLE_HOLE_PITCH}x line pitch — the ` +
      `allocator refused a void it could have closed invisibly, and the ` +
      `partitioner left it as dead space:\n   ${offenders.join('\n   ')}`);
  });
});
