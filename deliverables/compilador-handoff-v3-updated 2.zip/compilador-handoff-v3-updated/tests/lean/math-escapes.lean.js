/**
 * Math escapes + dead-code gates (assessment batch 5).
 *
 *  G-esc1 — `\%` converts to `%` in prose autofix and in math expansion;
 *  no backslash leaks.
 *
 *  G-esc2 — `\_` converts to a literal `_` in prose (no leak, no accidental
 *  subscript of a following digit).
 *
 *  G-esc3 — `\begin{…}` / `\end{…}` wrappers strip in prose autofix,
 *  content kept.
 *
 *  G-gate1 — TokenResolver.parseInlineRuns does not math-style currency:
 *  `price $5 and $10 each` keeps both dollars, no math runs.
 *
 *  G-gate2 — InlineMath.expandInText leaves non-math spans literal.
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { TypographicAutofix, TokenResolver } from '../../src/v2/ingest/sanitizer.js';
import { InlineMath } from '../../src/v2/modules/math-module.js';

describe('math escapes + gates', () => {
  it('G-esc1: \\% becomes %', () => {
    assert.equal(TypographicAutofix.apply('100\\% eficaz', true), '100% eficaz');
    const runs = InlineMath.expand('\\%');
    assert.ok(
      runs.some((r) => (r.text || '').includes('%') && !(r.text || '').includes('\\')),
      `backslash leaked in math: ${JSON.stringify(runs)}`,
    );
  });

  it('G-esc2: \\_ becomes a literal underscore', () => {
    assert.equal(TypographicAutofix.apply('snake\\_case', true), 'snake_case');
    assert.equal(TypographicAutofix.apply('file\\_2', true), 'file_2');
  });

  it('G-esc3: \\begin/\\end wrappers strip, content kept', () => {
    assert.equal(
      TypographicAutofix.apply('\\begin{equation} x \\end{equation}', true).trim(),
      'x',
    );
  });

  it('G-gate1: TokenResolver keeps currency literal', () => {
    const runs = TokenResolver.parseInlineRuns('price $5 and $10 each');
    assert.ok(
      !runs.some((r) => r.style === 'math'),
      `currency math-styled: ${JSON.stringify(runs)}`,
    );
    const joined = runs.map((r) => r.text).join('');
    assert.ok(
      (joined.match(/\$/g) || []).length === 2,
      `dollars lost: ${JSON.stringify(joined)}`,
    );
  });

  it('G-gate2: expandInText leaves non-math spans literal', () => {
    const runs = InlineMath.expandInText('price $5 and $10 each');
    assert.ok(
      !runs.some((r) => String(r.style || 'normal').includes('math')),
      `non-math span styled: ${JSON.stringify(runs)}`,
    );
    assert.equal(runs.map((r) => r.text).join(''), 'price $5 and $10 each');
  });
});
