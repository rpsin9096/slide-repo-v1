// G19 — no stranded heading at a column foot, over the whole corpus.
//
// A heading is stranded when a content column ends with it and no text follows
// in that column. On a non-final page the reader walks on and meets a bare
// heading: the body is on the next page, or — worse — at the far foot of the
// other column, after everything in it.
//
// The predicate is G7's own (scripts/smoke-vertical-layout.mjs), not a
// size-vs-modal heuristic: bold font, size >= 9, width >= 50. That heuristic
// misfires on table-heavy pages, where the modal size is the table's, not the
// body text's. G7 covers one smoke fixture; this covers 6 docs x 3 templates.
//
// Columns are recovered by clustering line x-positions rather than by reading
// `el.scope`, so the same probe works on builds that predate the scope tag.
// Only non-final pages are counted: a last page has nothing after it, so a
// heading at its foot is the end of the document, not an orphan.
//
// THRESHOLD IS NOW ZERO. Reached 2026-09-29 (M6), after M4/M5/M6 took the
// measured rate 5 -> 2 -> 1 -> 0. `MAX_STRANDED` used to be the pre-VGA rate
// (4) with a header explaining that locking the real defects here would make
// the gate unlandable; that reasoning is now spent — the defects are fixed, so
// zero is the honest bound. Do NOT raise this to make a red gate pass: that
// returns the gate to being a rubber stamp.
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readCorpus } from '../corpus/index.js';
import { runPipeline } from '../../src/v2/runtime/pipeline.js';

const here = dirname(fileURLToPath(import.meta.url));
const repo = join(here, '..', '..');

const DOCS = ['sample1.md', 'sample2.md', 'sample3.md', 'sample4.md', 'text-test.md', 'taskfiles/sampletext2.md'];
const TEMPLATES = ['base', 'bauhaus', 'bauhaus_minimalist'];
const MAX_STRANDED = 0;

const isHeadingLike = (el) => !!el && el.type === 'text'
  && String(el.font || '').includes('bold') && (el.size || 0) >= 9 && (el.width || 0) >= 50;

function columnsOf(page, footY) {
  const rows = (page.elements || [])
    .filter((e) => e && typeof e.y === 'number' && e.y < footY - 2)
    .map((e) => ({ y: e.y, x: e.x || 0, el: e }));
  const cols = [];
  for (const r of [...rows].sort((a, b) => a.x - b.x)) {
    const near = cols.find((k) => r.x - k.maxX <= 30);
    if (near) { near.items.push(r); near.maxX = Math.max(near.maxX, r.x); }
    else cols.push({ minX: r.x, maxX: r.x, items: [r] });
  }
  return cols.filter((c) => c.items.length >= 12); // real text columns only
}

// The detector, factored out so the non-vacuity test can drive it directly
// instead of depending on the corpus still containing a defect.
function pendingAtFoot(col) {
  col.items.sort((a, b) => a.y - b.y);
  // A heading is stranded only if the column ends before any text at all
  // follows it. A second heading after the first is a section/subsection
  // pair, not an orphan — keep waiting for the body.
  let pending = null;
  for (const r of col.items) {
    if (r.el.type !== 'text') continue;
    if (isHeadingLike(r.el)) { pending = String(r.el.text).slice(0, 48); continue; }
    pending = null;
  }
  return pending;
}

const stranded = [];
let columnsExamined = 0;
let pagesExamined = 0;
for (const f of DOCS) {
  const markdown = readCorpus(f);
  for (const template of TEMPLATES) {
    const { displayList: dl } = await runPipeline({
      payload: {
        title: 'G19', template,
        blocks: [{
          title: 'B', markdown, masthead: { enabled: false },
          flags: { autofix: true, optimize_tables: true, split_equations: true }, columns: null,
        }],
      },
      mode: 'paginate', timestamp: 1700000000000, seed: 'stranded-census',
    });
    for (const page of dl.pages.slice(0, -1)) {
      pagesExamined += 1;
      for (const c of columnsOf(page, 820)) {
        columnsExamined += 1;
        const pending = pendingAtFoot(c);
        if (pending) stranded.push(`${f}/${template} p${page.pageNumber} ${pending}`);
      }
    }
  }
}

describe('G19 — no stranded heading at a column foot (corpus-wide)', () => {
  it(`stranded headings stay at or below ${MAX_STRANDED}`, () => {
    assert.ok(
      stranded.length <= MAX_STRANDED,
      `stranded=${stranded.length} > ${MAX_STRANDED}\n   ${stranded.join('\n   ')}`,
    );
  });

  it('the scan actually covers the corpus (non-vacuous)', () => {
    // If column recovery ever breaks, `stranded` empties and the gate above
    // passes for the wrong reason. So prove the scan really ran...
    assert.ok(pagesExamined >= 40, `only ${pagesExamined} non-final pages scanned`);
    assert.ok(columnsExamined >= 100, `only ${columnsExamined} columns examined`);

    // ...and, separately, that the DETECTOR fires. Earlier revisions of this
    // canary asserted that a specific corpus page still stranded, and were
    // repointed twice as real fixes repaired the named case (sample4/base p1
    // by M4, sampletext2/bauhaus p4 by M5). That was the wrong shape: a
    // canary pinned to a defect goes red exactly when the layout improves,
    // training the reader to distrust a fix. With the count now at zero no
    // corpus case can satisfy it at all.
    //
    // So the witness is the predicate itself, driven on a synthetic column
    // built to be stranded. If `isHeadingLike` or `pendingAtFoot` regresses,
    // this goes red while the corpus stays clean.
    const synth = (rows) => ({
      items: rows.map((r, i) => ({
        y: 100 + i * 14, x: 50, el: { type: 'text', font: i === rows.length - 1 ? 'bold' : 'roman', size: 10, width: 200, text: 'line ' + i },
      })),
    });
    const strandedCol = synth(Array.from({ length: 12 }, () => 0));   // ends on a heading
    const bodyCol = synth(Array.from({ length: 12 }, () => 1)).items.slice(0, 11);
    bodyCol.push({ y: 254, x: 50, el: { type: 'text', font: 'bold', size: 10, width: 200, text: 'H' } });
    bodyCol.push({ y: 268, x: 50, el: { type: 'text', font: 'roman', size: 10, width: 200, text: 'body' } });
    const followedCol = { items: bodyCol };

    assert.ok(pendingAtFoot(strandedCol), 'detector failed to flag a column ending on a heading');
    assert.equal(pendingAtFoot(followedCol), null, 'detector flagged a heading that has body beneath it');

    // Note what this detector does NOT know: it has no notion of heading
    // depth, so a column ending on `##` immediately followed by `###` with no
    // body IS reported (the last heading seen is pending). That is deliberate —
    // it is the same reading a reader has — and the M5/M6 fixes keep such a
    // pair together at the layout level rather than teaching the gate to
    // ignore it. Asserting the run is exempt here would be asserting a
    // behaviour this predicate does not have.
    const runCol = { items: [
      ...Array.from({ length: 10 }, (_, i) => ({ y: 100 + i * 14, x: 50, el: { type: 'text', font: 'roman', size: 10, width: 200, text: 'b' + i } })),
      { y: 240, x: 50, el: { type: 'text', font: 'bold', size: 11, width: 200, text: 'H2' } },
      { y: 256, x: 50, el: { type: 'text', font: 'bold', size: 9.5, width: 200, text: 'H3' } },
    ] };
    assert.equal(pendingAtFoot(runCol), 'H3', 'a run ending on a heading must be reported as pending');
  });
});
