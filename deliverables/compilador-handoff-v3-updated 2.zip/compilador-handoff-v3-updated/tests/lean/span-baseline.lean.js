import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readCorpus } from '../corpus/index.js';
import { runPipeline } from '../../src/v2/runtime/pipeline.js';

const here = dirname(fileURLToPath(import.meta.url));
const repo = join(here, '..', '..');
const saved = JSON.parse(readFileSync(join(repo, 'tests', 'fixtures', 'span-baseline.json'), 'utf-8'));

const docOf = (markdown) => ({
  title: 'Baseline',
  template: 'base',
  blocks: [{ title: 'A', markdown, masthead: { enabled: false }, flags: { autofix: true, optimize_tables: true, split_equations: true }, columns: null }],
});

describe('span baseline pinned', () => {
  for (const name of ['sample1.md', 'sample2.md', 'sample3.md', 'text-test.md']) {
    it(`${name} matches frozen diagnostics`, async () => {
      const markdown = readCorpus(name);
      const { displayList } = await runPipeline({ payload: docOf(markdown), mode: 'paginate', seed: saved.seed, timestamp: saved.timestamp });
      assert.equal(displayList.totalPages, saved.fixtures[name].totalPages, `${name} totalPages`);
      assert.deepEqual(
        {
          tableSlices: displayList.diagnostics.tableSlices ?? null,
          panoramicTransitions: displayList.diagnostics.panoramicTransitions ?? null,
          overfullColumns: displayList.diagnostics.overfullColumns ?? null,
        },
        {
          tableSlices: saved.fixtures[name].diagnostics.tableSlices,
          panoramicTransitions: saved.fixtures[name].diagnostics.panoramicTransitions,
          overfullColumns: saved.fixtures[name].diagnostics.overfullColumns,
        }
      );
    });
  }
});
