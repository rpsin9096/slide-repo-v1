import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  BlockStore, splitBlocks,
  applyRichCommand, detectRichState, canExecCommand,
  pushUndo, popUndo, ceApplyInline, UNDO_LIMIT,
  applyListCommand, parseListMarker, mapBodyRangeToStore, digitOf,
} from '../../static/editor-core.js';

const reloadCount = (store) => splitBlocks(store.getMarkdown()).length;

describe('RichCommandInterface pure seam', () => {
  it('canExec accepts spec commands, rejects unknown', () => {
    for (const f of ['bold', 'italic', 'code', 'strike', 'link', 'h1', 'h2', 'h3', 'h4', 'quote', 'p', 'ul', 'ol']) {
      assert.equal(canExecCommand(f), true);
    }
    assert.equal(canExecCommand('nope'), false);
  });

  it('inline bold toggles off when exactly wrapped', () => {
    const r1 = applyRichCommand('hello', 0, 5, 'bold');
    assert.equal(r1.text, '**hello**');
    const r2 = applyRichCommand(r1.text, 0, r1.text.length, 'bold');
    assert.equal(r2.text, 'hello');
  });

  it('block h1 toggles to paragraph on repeat', () => {
    const r1 = applyRichCommand('Texto', 0, 5, 'h1');
    assert.equal(r1.text, '# Texto');
    const r2 = applyRichCommand(r1.text, 0, r1.text.length, 'h1');
    assert.equal(r2.text, 'Texto');
  });

  it('block h4 toggles + converts without stacking', () => {
    const r1 = applyRichCommand('Texto', 0, 5, 'h4');
    assert.equal(r1.text, '#### Texto');
    const r2 = applyRichCommand(r1.text, 0, r1.text.length, 'h4');
    assert.equal(r2.text, 'Texto');
    assert.equal(applyRichCommand('### T', 0, 5, 'h4').text, '#### T');
    assert.equal(applyRichCommand('#### T', 0, 7, 'h1').text, '# T');
  });

  it('detectRichState probes inline + block active', () => {
    assert.equal(detectRichState('**hi**', 0, 6, 'bold'), true);
    assert.equal(detectRichState('hi', 0, 2, 'bold'), false);
    assert.equal(detectRichState('# T', 0, 3, 'h1'), true);
    assert.equal(detectRichState('T', 0, 1, 'h1'), false);
    assert.equal(detectRichState('> q', 0, 3, 'quote'), true);
    assert.equal(detectRichState('#### T', 0, 7, 'h4'), true);
    assert.equal(detectRichState('### T', 0, 6, 'h4'), false);
    assert.equal(detectRichState('### T', 0, 6, 'h3'), true);
  });

  it('ceApplyInline link wraps with https placeholder', () => {
    const r = ceApplyInline('texto', 0, 5, 'link');
    assert.equal(r.text, '[texto](https://)');
  });

  it('UndoCheckpoint bounded stack push/pop', () => {    let st = [];
    st = pushUndo(st, 'a');
    st = pushUndo(st, 'b');
    assert.equal(st.length, 2);
    const { snapshot, rest } = popUndo(st);
    assert.equal(snapshot, 'b');
    assert.equal(rest.length, 1);
    let big = [];
    for (let k = 0; k < UNDO_LIMIT + 5; k++) big = pushUndo(big, `s${k}`);
    assert.equal(big.length, UNDO_LIMIT);
  });
});

describe('BlockStore separator positional fix', () => {
  it('insert in middle keeps 3 cards after reserialize', () => {
    const s = new BlockStore('A\n\nB\n');
    s.insertBlockAt(1, '# Novo Título\n');
    assert.equal(s.blocks.length, 3);
    assert.equal(reloadCount(s), 3);
  });

  it('append after edit keeps cards after reserialize', () => {
    const s = new BlockStore('A\n\nB\n');
    s.updateBlockText(1, 'B edited');
    s.appendLines('C\n');
    assert.equal(s.blocks.length, 3);
    assert.equal(reloadCount(s), 3);
  });

  it('move keeps cards after reserialize', () => {
    const s = new BlockStore('A\n\nB\n\nC\n');
    s.moveBlock(0, 2);
    assert.equal(s.blocks.length, 3);
    assert.equal(reloadCount(s), 3);
  });

  it('execCommand-equivalent store edit round-trips', () => {
    const s = new BlockStore('Texto\n');
    const r = applyRichCommand('Texto', 0, 5, 'bold');
    s.updateBlockText(0, r.text);
    assert.equal(s.getMarkdown().trim(), '**Texto**');
    assert.equal(reloadCount(s), 1);
  });
});

describe('List commands (Notion-style multi-line toggle)', () => {
  it('parseListMarker detects unordered, ordered, indent', () => {
    assert.equal(parseListMarker('plain'), null);
    assert.deepEqual(
      { ordered: parseListMarker('- item').ordered, indent: parseListMarker('- item').indent },
      { ordered: false, indent: '' },
    );
    const ind = parseListMarker('  3. deep');
    assert.equal(ind.ordered, true);
    assert.equal(ind.num, 3);
    assert.equal(ind.indent, '  ');
  });

  it('collapsed caret on plain line starts a bullet', () => {
    // End-of-line caret rides with the content …
    const end = applyRichCommand('Texto', 5, 5, 'ul');
    assert.equal(end.text, '- Texto');
    assert.equal(end.caretStart, 7);
    // … while a line-start caret lands after the new marker.
    const start = applyRichCommand('Texto', 0, 0, 'ul');
    assert.equal(start.text, '- Texto');
    assert.equal(start.caretStart, 2);
  });

  it('bullets toggle off across all spanned lines', () => {
    const md = '- A\n- B\n- C';
    const r = applyRichCommand(md, 0, md.length, 'ul');
    assert.equal(r.text, 'A\nB\nC');
  });

  it('plain lines become bullets, blanks skipped', () => {
    const r = applyRichCommand('A\n\nB', 0, 4, 'ul');
    assert.equal(r.text, '- A\n\n- B');
  });

  it('ul converts to ol with fresh sequential numbers', () => {
    const r = applyRichCommand('- A\n- B', 0, 6, 'ol');
    assert.equal(r.text, '1. A\n2. B');
  });

  it('ol continues numbering from the item directly above', () => {
    const r = applyRichCommand('1. A\nB', 5, 6, 'ol');
    assert.equal(r.text, '1. A\n2. B');
  });

  it('indent is preserved when toggling', () => {
    const r = applyRichCommand('  plain', 0, 7, 'ul');
    assert.equal(r.text, '  - plain');
    const back = applyRichCommand(r.text, 0, r.text.length, 'ul');
    assert.equal(back.text, '  plain');
  });

  it('detectRichState probes list kinds', () => {
    assert.equal(detectRichState('- A\n- B', 0, 7, 'ul'), true);
    assert.equal(detectRichState('- A\n- B', 0, 7, 'ol'), false);
    assert.equal(detectRichState('1. A\n2. B', 0, 10, 'ol'), true);
    assert.equal(detectRichState('- A\nB', 0, 5, 'ul'), false);
  });

  it('mapBodyRangeToStore shifts heading hashes, expands quote prefixes', () => {
    const h = mapBodyRangeToStore('# Hi', 'Hi', '# ', false, 0, 2);
    assert.deepEqual(h, { start: 2, end: 4 });
    const q = mapBodyRangeToStore('> AB\n> CD', 'AB\nCD', '', true, 1, 5);
    assert.deepEqual(q, { start: 3, end: 9 });
  });

  it('digitOf prefers physical code under Shift', () => {
    assert.equal(digitOf({ key: '*', code: 'Digit8' }), '8');
    assert.equal(digitOf({ key: '7', code: 'Digit7' }), '7');
    assert.equal(digitOf({ key: '1' }), '1');
  });

  it('applyListCommand direct entry matches seam', () => {
    const a = applyListCommand('x', 1, 1, 'ol');
    const b = applyRichCommand('x', 1, 1, 'ol');
    assert.deepEqual(a, b);
  });

  it('formats convert instead of stacking prefixes', () => {
    // Heading + bullets → bullets (strips `# `).
    assert.equal(applyRichCommand('# Título', 0, 8, 'ul').text, '- Título');
    // Bullets + H1 → heading (strips `- `, never `# - `).
    assert.equal(applyRichCommand('- item', 0, 6, 'h1').text, '# item');
    // Ordered + quote → quote.
    assert.equal(applyRichCommand('1. item', 0, 7, 'quote').text, '> item');
    // Bullets + paragraph → plain.
    assert.equal(applyRichCommand('- item', 0, 6, 'p').text, 'item');
  });
});
