import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { estimateHeight, wrapLineCount, calibrateHeight, resolveCalOpts } from '../../src/v2/layout/measure-calibration.js';
import { measure } from '../../src/v2/layout/coordinator.js';

const stub10 = (w) => (w === ' ' ? 3 : 10);

describe('measure calibration', () => {
  it('estimado reproduces current rates', () => {
    assert.equal(estimateHeight('heading', 1), 14);
    assert.equal(estimateHeight('hr', 1), 10);
    assert.equal(estimateHeight('image', 1), 130);
    assert.equal(estimateHeight('math', 1), 24);
    assert.equal(estimateHeight('table', 3), 3 * 14 + 10);
    assert.equal(estimateHeight('code', 4), 4 * 10);
    assert.equal(estimateHeight('list', 2), 2 * 11);
    assert.equal(estimateHeight('quote', 2), 2 * 11);
    assert.equal(estimateHeight('para', 3), 3 * 12);
  });
  it('estimado matches coordinator boxes', () => {
    const boxes = measure([{ title: 'T', markdown: '# H\n\nOne two three.\n\n- a\n- b\n' }]);
    for (const box of boxes) {
      const n = box.lines ?? 1;
      assert.equal(calibrateHeight(box.kind, Array(n).fill('x')), estimateHeight(box.kind, n));
    }
  });
  it('real mode wraps with the measurer', () => {
    assert.equal(wrapLineCount('a b c d', { measure: stub10, colWidthPt: 25 }), 2);
    assert.equal(wrapLineCount('a', { measure: stub10, colWidthPt: 25 }), 1);
    assert.equal(calibrateHeight('para', ['a b c d'], { mode: 'real', measure: stub10, colWidthPt: 25 }), 2 * 12);
  });
  it('real mode falls back without measurer and keeps fixed kinds', () => {
    assert.equal(calibrateHeight('para', ['a b c d', 'e'], { mode: 'real' }), estimateHeight('para', 2));
    assert.equal(calibrateHeight('heading', ['# Hi'], { mode: 'real', measure: stub10, colWidthPt: 25 }), 14);
    assert.equal(calibrateHeight('table', ['| a |', '| b |'], { mode: 'real', measure: stub10, colWidthPt: 25 }), estimateHeight('table', 2));
  });
  it('resolveCalOpts is idempotent and defaults to estimado', () => {
    assert.deepEqual(resolveCalOpts(), { mode: 'estimado' });
    assert.deepEqual(resolveCalOpts({}), { mode: 'estimado' });
    const once = resolveCalOpts({ measureMode: 'real', measureColWidthPt: 40, measure: stub10 });
    assert.equal(once.mode, 'real');
    assert.equal(once.colWidthPt, 40);
    const twice = resolveCalOpts(once);
    assert.deepEqual(twice, once);
  });
});
