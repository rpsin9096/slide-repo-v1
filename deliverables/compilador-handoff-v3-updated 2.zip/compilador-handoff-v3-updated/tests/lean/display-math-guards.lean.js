/**
 * Display-math guards (assessment batch 1: content-loss bugs).
 *
 *  G-dmath1 — an unclosed `$$` opener must not swallow the rest of the
 *  block into a math box; the lines fall back to paragraphs.
 *
 *  G-dmath2 — trailing prose on a `$$x$$` line stays prose: the math box
 *  carries only `x`, the tail becomes a paragraph.
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { GeometryCompiler } from '../../src/v2/compiler/geometry-compiler.js';

const compile = (markdown) => new GeometryCompiler().compile(
  { title: 'T', template: 'base', blocks: [{ title: 'A', markdown }] }, {},
);

const textsOf = (dl, pageIdx = 0) => (dl.pages[pageIdx].elements || [])
  .filter((e) => e.type === 'text')
  .map((e) => e.text);

const fontOf = (dl, re, pageIdx = 0) => {
  const el = (dl.pages[pageIdx].elements || [])
    .find((e) => e.type === 'text' && re.test(e.text || ''));
  return el ? el.font : null;
};

describe('display-math guards', () => {
  it('G-dmath1: unclosed $$ does not swallow following paragraphs', () => {
    const dl = compile('$$x + y\npara after\nmore para');
    const texts = textsOf(dl);
    assert.ok(
      texts.some((t) => /para after/.test(t)),
      `following prose lost to math box, got: ${JSON.stringify(texts)}`,
    );
    assert.ok(
      texts.some((t) => /more para/.test(t)),
      `trailing prose lost to math box, got: ${JSON.stringify(texts)}`,
    );
    // Presence is not enough: swallowed prose renders as math-box lines
    // (courier). It must stay a paragraph (helvetica).
    assert.equal(
      fontOf(dl, /para after/), 'helvetica',
      `following prose swallowed into math box (font=${fontOf(dl, /para after/)})`,
    );
  });

  it('G-dmath2: trailing prose on a $$x$$ line stays prose', () => {
    const dl = compile('$$x$$ trailing text');
    const texts = textsOf(dl);
    assert.ok(
      texts.some((t) => t === 'x' || /^x$/.test(t.trim())),
      `math content wrong, got: ${JSON.stringify(texts)}`,
    );
    assert.ok(
      texts.some((t) => /trailing text/.test(t) && !/\$\$/.test(t)),
      `trailing prose absorbed into math, got: ${JSON.stringify(texts)}`,
    );
    assert.ok(
      !texts.some((t) => /\$\$/.test(t)),
      `literal $$ leaked, got: ${JSON.stringify(texts)}`,
    );
  });

  it('G-dmath3: trailing prose on the closer line stays prose', () => {
    const dl = compile('$$hello\n$$ world after');
    const texts = textsOf(dl);
    assert.ok(
      texts.some((t) => /world after/.test(t) && !/\$\$/.test(t)),
      `closer-line prose absorbed into math, got: ${JSON.stringify(texts)}`,
    );
    assert.equal(
      fontOf(dl, /world after/), 'helvetica',
      `closer-line prose rendered as math (font=${fontOf(dl, /world after/)})`,
    );
  });
});
