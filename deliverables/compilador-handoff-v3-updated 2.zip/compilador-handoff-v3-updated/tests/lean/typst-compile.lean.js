import { describe, it, before } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  compileTypstSource,
  sandboxTypstAssets,
  resolveTypstBin,
  compileTimeoutMs,
  DEFAULT_TYPST_TIMEOUT_MS,
} from '../../src/v2/drivers/typst/compile.js';

/* CC4 lock: Typst compile seam — timeout, binary resolution, asset sandbox. */

const here = path.dirname(fileURLToPath(import.meta.url));
const COPY_SH = path.join(here, '..', 'fixtures', 'typst-fake-copy.sh');
const SLOW_SH = path.join(here, '..', 'fixtures', 'typst-fake-slow.sh');

before(() => {
  for (const f of [COPY_SH, SLOW_SH]) {
    try { fs.chmodSync(f, 0o755); } catch { /* already executable */ }
    assert.ok(fs.existsSync(f), `fixture present: ${f}`);
  }
});

describe('CC4 typst compile seam', () => {
  it('roundtrips bytes through the binary contract (compile src pdf)', async () => {
    const out = await compileTypstSource('hello-typst', { typstBin: COPY_SH, timeoutMs: 10000 });
    assert.ok(Buffer.isBuffer(out));
    assert.equal(out.toString(), 'hello-typst');
  });

  it('rejects on timeout with a clear message', async () => {
    await assert.rejects(
      () => compileTypstSource('x', { typstBin: SLOW_SH, timeoutMs: 300 }),
      /timed out after 300ms/,
    );
  });

  it('rejects on missing binary', async () => {
    await assert.rejects(
      () => compileTypstSource('x', { typstBin: '/nonexistent/typst-xyz', timeoutMs: 5000 }),
      /failed|ENOENT/i,
    );
  });

  it('resolveTypstBin honors TYPST_BIN, compileTimeoutMs honors TYPST_TIMEOUT_MS', () => {
    const oldBin = process.env.TYPST_BIN;
    const oldTo = process.env.TYPST_TIMEOUT_MS;
    try {
      process.env.TYPST_BIN = '/tmp/fake-typst';
      assert.equal(resolveTypstBin(), '/tmp/fake-typst');
      delete process.env.TYPST_BIN;
      assert.ok(typeof resolveTypstBin() === 'string');

      assert.equal(compileTimeoutMs(), DEFAULT_TYPST_TIMEOUT_MS);
      process.env.TYPST_TIMEOUT_MS = '500';
      assert.equal(compileTimeoutMs(), 500);
      process.env.TYPST_TIMEOUT_MS = 'junk';
      assert.equal(compileTimeoutMs(), DEFAULT_TYPST_TIMEOUT_MS);
    } finally {
      if (oldBin === undefined) delete process.env.TYPST_BIN; else process.env.TYPST_BIN = oldBin;
      if (oldTo === undefined) delete process.env.TYPST_TIMEOUT_MS; else process.env.TYPST_TIMEOUT_MS = oldTo;
    }
  });

  it('sandboxTypstAssets copies local refs, passes remote/missing through', () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sandbox-test-'));
    try {
      const src = 'text image("package.json") and image("https://x/y.png") and image("nope-missing.png") tail';
      const out = sandboxTypstAssets(src, dir);
      assert.ok(out.includes('image("package.json")'));
      assert.ok(out.includes('image("https://x/y.png")'));
      assert.ok(out.includes('image("nope-missing.png")'));
      assert.ok(fs.existsSync(path.join(dir, 'package.json')), 'local hit copied into sandbox');
      assert.equal(fs.existsSync(path.join(dir, 'y.png')), false);
      assert.equal(fs.existsSync(path.join(dir, 'nope-missing.png')), false);
    } finally {
      fs.rmSync(dir, { recursive: true, force: true });
    }
  });
});
