/**
 * Atomic-list balance gate.
 *
 * `split_list_items: false` promises that a list item is never cut across a
 * column or page boundary. The v3 compiler forwarded the flag but ignored it,
 * so a nested list split six items and left a 317pt void in the right column
 * of page 3 (the shape the user reported on doc-87). The fix has two parts:
 * the split guard itself, and a balanced partition for atomic-list regions so
 * whole items move between columns instead of being cut.
 *
 * This fixture is synthetic: a short paragraph preamble fills the first page,
 * then a nested list has enough parent/child chains to cross several column
 * boundaries. It deliberately has no tables or images, so the only reason a
 * column can be short is the list-item partition.
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { normalizeToDocIR } from '../../pdf-engine.js';
import { GeometryCompiler } from '../../src/v2/compiler/geometry-compiler.js';
import { createMeasureContext } from '../../src/v2/drivers/pdfkit/blaster.js';
import { elementExtent } from '../../src/v2/layout/stretch-seam.js';
import { TEMPLATES } from '../../src/v2/templates/definitions.js';
import { PAGE_SIZES } from '../../src/v2/core/geometry.js';

const TEMPLATE = 'bauhaus';
const BODY = 'A ausculta pulmonar sistematica compara os ruidos respiratorios nos campos pulmonares simetricos e registra o achado predominante.';
const paragraph = (n = 3) => Array.from({ length: n }, () => BODY).join(' ');
const long = paragraph(4);

const contentBottomY = () => {
  const tmpl = TEMPLATES[TEMPLATE];
  return PAGE_SIZES.A4.height - tmpl.margins.bottom - tmpl.footskip;
};

const makeMarkdown = () => {
  const lines = [];
  for (let i = 0; i < 30; i++) lines.push(paragraph(2), '');
  lines.push('## Tema sintetico', '');
  for (let i = 0; i < 20; i++) {
    lines.push(`- Item ${i} ${i % 3 === 0 ? long : paragraph(2)}`);
    if (i % 3 === 0) {
      lines.push(`  - Filho ${i}.a ${paragraph(3)}`);
      lines.push(`    - Neto ${i}.a.1 ${paragraph(2)}`);
      lines.push(`      - Bisneto ${i}.a.1.1 ${paragraph(2)}`);
      lines.push(`    - Neto ${i}.a.2 ${paragraph(2)}`);
      lines.push(`  - Filho ${i}.b ${paragraph(2)}`);
    }
  }
  return lines.join('\n');
};

const compile = () => {
  const payload = {
    title: 'Atomic list balance',
    template: TEMPLATE,
    blocks: [{
      title: 'A',
      markdown: makeMarkdown(),
      masthead: { enabled: false },
      columns: null,
    }],
  };
  const docIR = normalizeToDocIR(payload);
  const ctx = createMeasureContext(TEMPLATE);
  const compiler = new GeometryCompiler();
  const origSplit = compiler._splitParagraph.bind(compiler);
  const splitItems = [];
  compiler._splitParagraph = (item, maxH, opts) => {
    const result = origSplit(item, maxH, opts);
    if (item && item.kind === 'list-item' && result[1]) {
      splitItems.push({
        text: (item.text || '').slice(0, 60),
        total: item.lines ? item.lines.length : null,
        kept: result[0].lines ? result[0].lines.length : null,
        maxH: Number(maxH.toFixed(1)),
      });
    }
    return result;
  };
  try {
    const displayList = compiler.compile(docIR, {
      template: TEMPLATE,
      geometry: 'v3',
      split_list_items: false,
      flush_columns: true,
      columns: 2,
      measure: ctx.measure,
      measureImage: ctx.measureImage,
      skip_fit_audit: true,
    });
    return { displayList, splitItems };
  } finally {
    try { ctx.dispose(); } catch { /* no-op */ }
  }
};

/** Deepest inked body bottom for each column scope, chrome excluded. */
const columnFeet = (page) => {
  const feet = new Map();
  for (const element of page.elements || []) {
    if (typeof element.seamSeq !== 'number') continue;
    if (!element.scope || !element.scope.startsWith('col:')) continue;
    const extent = elementExtent(element);
    if (!extent) continue;
    const previous = feet.get(element.scope) || -Infinity;
    feet.set(element.scope, Math.max(previous, extent.bottom));
  }
  return feet;
};

describe('atomic list items — split flag is honored and columns rebalance', () => {
  it('never splits a list item when split_list_items is false', () => {
    const { splitItems } = compile();
    assert.deepEqual(
      splitItems,
      [],
      `split_list_items=false still cut ${splitItems.length} list item(s): ${JSON.stringify(splitItems)}`,
    );
  });

  it('keeps every interior column at the region foot instead of leaving a void', () => {
    const { displayList } = compile();
    const foot = contentBottomY();
    const offenders = [];
    for (let i = 0; i < displayList.pages.length - 1; i++) {
      const page = displayList.pages[i];
      const feet = columnFeet(page);
      for (const [scope, bottom] of feet) {
        const voidPt = foot - bottom;
        if (voidPt > 14) {
          offenders.push(`p${i + 1} ${scope} short ${voidPt.toFixed(1)}pt`);
        }
      }
    }
    assert.deepEqual(
      offenders,
      [],
      `atomic-list pages left a column void: ${offenders.join('; ')}`,
    );
  });
});
