/**
 * Inline-math script grouping (assessment bug 1: meaning corruption).
 *
 *  G-script1 — `_{…}` / `^{…}` groups survive whole: `$E_{\max}$` renders
 *  `E` + fully-subscripted `ₘₐₓ`, never `Eₘax`.
 *
 *  G-script2 — bodies without full unicode coverage fall back to a styled
 *  run carrying the WHOLE body: `$t_{1/2}$` renders `t` + `1/2` as one
 *  `math-sub` run, never `t₁/2`.
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { InlineMath } from '../../src/v2/modules/math-module.js';

const textOf = (runs) => runs.map((r) => `${r.text}:${r.style}`).join('|');

describe('inline-math script grouping', () => {
  it('G-script1: braced subscript groups convert whole', () => {
    // Same-style adjacent runs merge by design (`push`), so the group and
    // its base share one run — what matters is no `ₘax` shard survives.
    assert.equal(textOf(InlineMath.expand('E_{\\max}')), 'Eₘₐₓ:math');
    assert.equal(textOf(InlineMath.expand('x^{ab}')), 'xᵃᵇ:math');
  });

  it('G-script2: unmappable bodies fall back whole, not first-char', () => {
    assert.equal(textOf(InlineMath.expand('t_{1/2}')), 't:math|1/2:math-sub');
  });
});
