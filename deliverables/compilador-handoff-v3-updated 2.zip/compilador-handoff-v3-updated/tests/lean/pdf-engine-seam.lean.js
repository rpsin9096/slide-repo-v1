import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  createEngine,
  calculatePagination,
  collectImageSources,
  resolveCompileOptions,
  IMAGE_PRE_RESOLVE_CONCURRENCY,
} from '../../pdf-engine.js';
import { ModularTableEngine } from '../../src/v2/modules/table-module.js';
import { ModularImageResolver } from '../../src/v2/modules/image-module.js';

/* CC2 seam lock: image pre-resolve, compile-option canonicalization,
 * lazy engines, pagination honesty. */

const tick = (ms = 5) => new Promise((r) => setTimeout(r, ms));

describe('CC2 collectImageSources', () => {
  it('dedupes, strips titles, skips non-markdown blocks', () => {
    const blocks = [
      { markdown: '![a](img_1)\n![b](img_1 "Legenda")' },
      { markdown: 'text ![c](/uploads/x.png)' },
      { markdown: 123 },
      {},
      null,
    ];
    assert.deepEqual(collectImageSources(blocks), ['img_1', '/uploads/x.png']);
  });

  it('finds leading images of later blocks (no /g lastIndex carryover)', () => {
    const blocks = [
      { markdown: 'x ![a](a.png) trailing text here' },
      { markdown: '![b](b.png)' },
    ];
    assert.deepEqual(collectImageSources(blocks), ['a.png', 'b.png']);
  });

  it('returns [] for empty input', () => {
    assert.deepEqual(collectImageSources([]), []);
    assert.deepEqual(collectImageSources(null), []);
  });
});

describe('CC2 resolveCompileOptions', () => {
  it('drops undefined entries', () => {
    assert.deepEqual(resolveCompileOptions({}), {});
    assert.deepEqual(resolveCompileOptions(), {});
  });

  it('mirrors snake/camel pairs', () => {
    const out = resolveCompileOptions({ tableLayoutMode: 'panoramic' });
    assert.equal(out.table_layout_mode, 'panoramic');
    assert.equal(out.tableLayoutMode, 'panoramic');
  });

  it('keeps verbatim first-key-wins precedence per alias list', () => {
    const out = resolveCompileOptions({ table_layout_mode: 'compact', tableLayoutMode: 'panoramic' });
    assert.equal(out.table_layout_mode, 'compact');
    assert.equal(out.tableLayoutMode, 'panoramic');
  });

  it('reads tertiary aliases (tocTitleInput) and unrelated keys stay out', () => {
    const out = resolveCompileOptions({ tocTitleInput: 'X', preview: true });
    assert.equal(out.toc_title, 'X');
    assert.equal('tocTitle' in out, false);
    assert.equal('preview' in out, false);
  });
});

describe('CC2 resolveBlockImages', () => {
  it('dedupes resolve calls and skips pre-seeded map entries', async () => {
    const calls = [];
    const engine = createEngine();
    engine.imageResolver = { resolve: async (src) => { calls.push(src); return Buffer.from([1]); } };
    const map = new Map([['seeded.png', Buffer.from([9])]]);
    const blocks = [
      { markdown: '![a](dup.png) ![b](dup.png)' },
      { markdown: '![c](seeded.png) ![d](new.png)' },
    ];
    await engine.resolveBlockImages(blocks, map);
    assert.deepEqual(calls, ['dup.png', 'new.png']);
    assert.equal(map.get('seeded.png')[0], 9);
    assert.ok(map.get('dup.png') instanceof Buffer);
  });

  it('tolerates resolver failures (placeholder path downstream)', async () => {
    const engine = createEngine();
    engine.imageResolver = {
      resolve: async (src) => { if (src === 'bad.png') throw new Error('nope'); return Buffer.from([1]); },
    };
    const map = new Map();
    await engine.resolveBlockImages([{ markdown: '![a](bad.png) ![b](ok.png)' }], map);
    assert.equal(map.has('bad.png'), false);
    assert.equal(map.has('ok.png'), true);
  });

  it('caps concurrency and commits in first-occurrence order', async () => {
    let inFlight = 0;
    let maxFlight = 0;
    const engine = createEngine();
    engine.imageResolver = {
      resolve: async (src) => {
        inFlight++;
        maxFlight = Math.max(maxFlight, inFlight);
        // Slow-first delays: completion order is the reverse of source order.
        await tick(src === 's0.png' ? 30 : 2);
        inFlight--;
        return Buffer.from([src.length]);
      },
    };
    const sources = Array.from({ length: 10 }, (_, i) => `s${i}.png`);
    const map = new Map();
    await engine.resolveBlockImages([{ markdown: sources.map((s) => `![x](${s})`).join(' ') }], map);
    assert.ok(maxFlight <= IMAGE_PRE_RESOLVE_CONCURRENCY, `maxFlight=${maxFlight}`);
    assert.ok(maxFlight > 1, `expected real parallelism, maxFlight=${maxFlight}`);
    assert.deepEqual([...map.keys()], sources);
  });
});

describe('CC2 lazy engines', () => {
  it('builds singletons on first access, keeps assignment API', () => {
    const engine = createEngine();
    assert.deepEqual(Object.keys(engine._engines), []);
    assert.ok(engine.tableEngine instanceof ModularTableEngine);
    assert.deepEqual(Object.keys(engine._engines), ['table']);
    assert.equal(engine.tableEngine, engine.tableEngine);
    const fake = { resolve: async () => null };
    engine.imageResolver = fake;
    assert.equal(engine.imageResolver, fake);
    assert.ok(engine.galleyEngine && typeof engine.galleyEngine.planColumns === 'function');
  });

  it('default engine exposes a real image resolver', async () => {
    const { default: def } = await import('../../pdf-engine.js');
    assert.ok(def.imageResolver instanceof ModularImageResolver);
  });
});

describe('CC2 pagination honesty + integrated convert', () => {
  it('calculatePagination tags output as estimated', () => {
    const out = calculatePagination({ sections: [{ title: 'T', markdown: 'hello' }] });
    assert.equal(out.estimated, true);
    assert.ok(out.totalPages >= 1);
  });

  it('convertDocument dedupes image resolves end-to-end (pdfkit)', async () => {
    const calls = [];
    const engine = createEngine();
    engine.imageResolver = { resolve: async (src) => { calls.push(src); return null; } };
    const out = await engine.convertDocument(
      { sections: [{ title: 'T', markdown: '![a](dup.png)\n\n![b](dup.png)\n\n![c](other.png)' }] },
      { driver: 'pdfkit', format: 'pdf' },
    );
    assert.ok(Buffer.isBuffer(out), 'pdfkit emits a PDF buffer');
    assert.deepEqual(calls, ['dup.png', 'other.png']);
  });
});
