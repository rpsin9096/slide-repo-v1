import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readCorpus } from '../corpus/index.js';
import { runPipeline } from '../../src/v2/runtime/pipeline.js';
import { TEMPLATES } from '../../src/v2/templates/definitions.js';
import { PAGE_SIZES } from '../../src/v2/core/geometry.js';
import { computeElementShifts } from '../../src/v2/layout/glue-allocator.js';

const here = dirname(fileURLToPath(import.meta.url));
const repo = join(here, '..', '..');
const SEED = 'vertical-justify';
const TIMESTAMP = 1700000000000;

const docOf = (markdown, template = 'base') => ({
  title: 'Justify',
  template,
  blocks: [{
    title: 'A', markdown, masthead: { enabled: false },
    flags: { autofix: true, optimize_tables: true, split_equations: true },
    columns: null,
  }],
});

const contentBottomOf = (template) => {
  const t = TEMPLATES[template];
  return PAGE_SIZES.A4.height - t.margins.bottom - t.footskip;
};

const extentBottom = (el) => {
  if (!el || typeof el !== 'object') return null;
  if (el.type === 'text') return (el.y || 0) + (el.size || 10);
  if (el.type === 'rect' || el.type === 'image') return (el.y || 0) + (el.h || 0);
  if (el.type === 'rule') return Math.max(el.y1 || 0, el.y2 || 0);
  if (el.type === 'bullet') return (el.y || 0) + (el.r || 1.5);
  if (el.type === 'checkbox') return (el.y || 0) + 7.5;
  return null;
};

const pageVoid = (page, cbY) => {
  let b = -Infinity;
  for (const el of (page.elements || [])) {
    const e = extentBottom(el);
    if (e === null) continue;
    const top = el.type === 'rule' ? Math.min(el.y1 || 0, el.y2 || 0) : (el.y ?? 0);
    if (top < cbY + 0.5) b = Math.max(b, e);
  }
  return Number.isFinite(b) ? cbY - b : Infinity;
};

describe('M3 vertical justification (G12/G13/G15)', () => {
  it('G12 flush coverage: every applied page bottom void <= 1pt', async () => {
    const md = readCorpus('sample4.md');
    for (const template of ['base', 'bauhaus', 'bauhaus_minimalist']) {
      const { displayList: dl } = await runPipeline({ payload: docOf(md, template), mode: 'paginate', seed: SEED, timestamp: TIMESTAMP });
      const cbY = contentBottomOf(template);
      const j = dl.diagnostics.justify;
      assert.ok(j, `diagnostics.justify exists [${template}]`);
      const applied = new Set(j.pages || []);
      for (const n of applied) {
        const v = pageVoid(dl.pages[n - 1], cbY);
        assert.ok(v <= 1.0, `G12 [${template}] p${n} void=${v.toFixed(2)}pt > 1pt`);
      }
    }
  });

  it('G13 ratio bound: maxRatio <= 1.0 on every applied page', async () => {
    // sample1/base is the allocator's proving ground: mid-range voids the
    // foot scope can genuinely fund (p2 applied 10.6pt at ratio 0.94).
    // sample4/base is entirely over-cap — it exercises honesty, not ratio.
    const md = readCorpus('sample1.md');
    const { displayList: dl } = await runPipeline({ payload: docOf(md), mode: 'paginate', seed: SEED, timestamp: TIMESTAMP });
    const j = dl.diagnostics.justify;
    assert.ok(j, 'diagnostics.justify exists');
    assert.equal(typeof j.maxRatio, 'number', 'maxRatio is numeric');
    assert.ok((j.applied || 0) >= 1, 'at least one page applied');
    assert.ok(j.maxRatio <= 1.0, `maxRatio=${j.maxRatio} > 1.0`);
    assert.equal(typeof j.maxSeamShiftPt, 'number', 'maxSeamShiftPt is numeric');
    // Honesty shape: every skipped page carries a reason.
    for (const s of (j.skipped || [])) assert.ok(s.reason, `skipped p${s.page} carries a reason`);
  });

  // The smoke gates (S2/S3) never cover taskfiles/sampletext2.md, which is
  // where the M3 pad retirement surfaced: a column separator left 0.09pt
  // past the region foot (bottomMarginViolations 0 -> 1). This gate runs
  // every corpus fixture x every template and requires the compiler's own
  // bottom-margin diagnostic to stay clean, so a flush overshoot in any
  // fixture fails the suite instead of waiting for a visual read.
  it('no fixture leaves content past the region foot (all templates)', async () => {
    const fixtures = ['sample1.md', 'sample2.md', 'sample3.md', 'sample4.md', 'text-test.md', 'taskfiles/sampletext2.md'];
    for (const f of fixtures) {
      const md = readCorpus(f);
      for (const template of ['base', 'bauhaus', 'bauhaus_minimalist']) {
        const { displayList: dl } = await runPipeline({ payload: docOf(md, template), mode: 'paginate', seed: SEED, timestamp: TIMESTAMP });
        const d = dl.diagnostics;
        assert.equal(d.bottomMarginViolations, 0,
          `bottomMarginViolations [${f}/${template}] = ${d.bottomMarginViolations} worst=${JSON.stringify(d.bottomMarginWorst || [])}`);
        assert.equal(d.overfullColumns, 0,
          `overfullColumns [${f}/${template}] = ${d.overfullColumns}`);
      }
    }
  });

  // ---------------------------------------------------------------------
  // M4 — seam classes and honest ragged.
  // ---------------------------------------------------------------------

  // G14 (spec §4.4, F-6): a heading's distance to its own body never
  // increases.
  //
  // Read from the allocator's own arithmetic, NOT from display-list geometry.
  // An earlier version of this gate inferred headings from font size (a
  // heading being larger than the page's modal text size) and produced a
  // FALSE POSITIVE: on a page whose modal size is 6.6pt (table text), an 8.5pt
  // list line outranks 6.6pt and reads as a "heading", so a legitimate 0.273pt
  // list-seam stretch was reported as a broken bond. Font size cannot
  // distinguish a heading from a same-size list line.
  //
  // The seam class is authoritative. A `headingBond` seam has capacity 0, so
  // resolveSeams() must return offset 0 for it, and a heading's distance to
  // its body is that seam's offset. The gate asserts the invariant directly
  // and requires that bonds were actually exercised — a gate that never
  // measures anything must not pass silently.
  it('G14 heading bond: headingBond seams never move (capacity 0)', async () => {
    const files = ['sample1.md', 'sample2.md', 'sample3.md', 'sample4.md', 'text-test.md', 'taskfiles/sampletext2.md'];
    let totalBonds = 0;
    for (const f of files) {
      const md = readCorpus(f);
      for (const template of ['base', 'bauhaus', 'bauhaus_minimalist']) {
        const { displayList: dl } = await runPipeline({ payload: docOf(md, template), mode: 'paginate', seed: SEED, timestamp: TIMESTAMP });
        const j = dl.diagnostics.justify;
        assert.ok(j, `diagnostics.justify exists [${f}/${template}]`);
        const shifts = j.bondShifts || [];
        assert.deepEqual(shifts, [],
          `G14 [${f}/${template}] heading bond moved: ${JSON.stringify(shifts.slice(0, 3))}`);
        totalBonds += j.bondCount || 0;
      }
    }
    assert.ok(totalBonds > 0, `G14 exercised no headingBond seams (bondCount=0) — the gate would pass vacuously`);
  });

  // G16 (spec §4.6): every page is accounted for as applied or
  // skipped-with-reason, and a block-final page stays ragged BY RULE
  // (reason 'block-end', capacity 0) rather than by an incidental cap.
  it('G16 honest ragged: every page is applied or skipped with a valid reason', async () => {
    const VALID = new Set(['ragged', 'block-end', 'toc', 'rotated', 'no-gaps', 'full', 'negligible', 'empty',
      'over-cap', 'no-capacity', 'over-ratio', 'flush-off', 'partial-lift', 'neighbour-ragged', 'column-ragged']);
    const md = readCorpus('sample2.md');
    for (const template of ['base', 'bauhaus', 'bauhaus_minimalist']) {
      const { displayList: dl } = await runPipeline({ payload: docOf(md, template), mode: 'paginate', seed: SEED, timestamp: TIMESTAMP });
      const j = dl.diagnostics.justify;
      const total = dl.totalPages;
      const applied = (j.pages || []).length;
      const skipped = j.skipped || [];
      assert.equal(applied + skipped.length, total,
        `G16 [${template}] applied(${applied}) + skipped(${skipped.length}) != totalPages(${total})`);
      for (const s of skipped) {
        assert.ok(VALID.has(s.reason), `G16 [${template}] p${s.page} unknown reason ${JSON.stringify(s.reason)}`);
        assert.ok(typeof s.page === 'number', `G16 [${template}] skipped entry carries its page`);
      }
      const noted = (j.notes || []).map((n) => n.page);
      for (const p of noted) {
        assert.ok(!skipped.some((s) => s.page === p), `G16 [${template}] p${p} counted twice (notes + skipped)`);
      }
    }
  });

  // F-9 by rule: a block-final page has no flush target at all. The corpus
  // has multi-block fixtures; every page that ends a block must report
  // 'block-end' rather than being flushed to the region foot.
  it('F-9 block-final pages stay ragged by rule (capacity 0)', async () => {
    const md = readCorpus('sample2.md');
    const doc = {
      title: 'Blocks',
      template: 'base',
      blocks: [
        { title: 'A', markdown: md, masthead: { enabled: false }, flags: { autofix: true, optimize_tables: true, split_equations: true }, columns: null },
        { title: 'B', markdown: md, masthead: { enabled: false }, flags: { autofix: true, optimize_tables: true, split_equations: true }, columns: null },
      ],
    };
    const { displayList: dl } = await runPipeline({ payload: doc, mode: 'paginate', seed: SEED, timestamp: TIMESTAMP });
    const j = dl.diagnostics.justify;
    const applied = (j.pages || []).length;
    const skipped = j.skipped || [];
    assert.equal(applied + skipped.length, dl.totalPages, 'F-9 every page accounted');
    const blockEnd = skipped.filter((s) => s.reason === 'block-end');
    assert.ok(blockEnd.length > 0,
      `F-9 expected at least one block-final page reported as 'block-end', got reasons: ${JSON.stringify(skipped.map((s) => s.reason))}`);
  });

  it('G15 column independence: col:0 items never shift from col:1-only offsets', async () => {
    // Display-list-level probe: elements carry {seamSeq, scope}; a resolution
    // that stretches ONLY col:1 seams must leave every col:0 element exactly
    // where placement put it. The old global gapsBelow() fails this by
    // construction (one sorted Y-list moves neighbours across columns).
    const seams = [
      { seq: 0, page: 1, region: null, scope: 'col:0', y: 200, klass: 'para', capacity: 2.5 },
      { seq: 1, page: 1, region: null, scope: 'col:1', y: 205, klass: 'para', capacity: 2.5 },
      { seq: 2, page: 1, region: null, scope: 'col:1', y: 300, klass: 'para', capacity: 2.5 },
    ];
    const elements = [
      { type: 'text', y: 150, size: 9, seamSeq: -1, scope: 'col:0' },
      { type: 'text', y: 210, size: 9, seamSeq: 0, scope: 'col:0' },
      { type: 'text', y: 215, size: 9, seamSeq: 1, scope: 'col:1' },
      { type: 'text', y: 310, size: 9, seamSeq: 2, scope: 'col:1' },
    ];
    const offsetsBySeq = new Map([[0, 0], [1, 1.0], [2, 1.0]]);
    const shifts = computeElementShifts(elements, seams, offsetsBySeq);
    assert.equal(shifts.get(0), 0, 'element above all seams holds still');
    assert.equal(shifts.get(1), 0, 'col:0 element ignores col:1-only stretch');
    assert.ok(shifts.get(2) > 0, 'col:1 element below stretched seams moves');
    assert.ok(shifts.get(3) > shifts.get(2), 'shifts accumulate in reading order');
  });
});
