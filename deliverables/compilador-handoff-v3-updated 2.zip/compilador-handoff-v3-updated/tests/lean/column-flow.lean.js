import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readCorpus } from '../corpus/index.js';
import { runPipeline } from '../../src/v2/runtime/pipeline.js';
import { TEMPLATES } from '../../src/v2/templates/definitions.js';
import { PAGE_SIZES } from '../../src/v2/core/geometry.js';

const here = dirname(fileURLToPath(import.meta.url));
const repo = join(here, '..', '..');
const SEED = 'column-flow';
const TIMESTAMP = 1700000000000;

const docOf = (markdown, flags) => ({
  title: 'Column flow',
  template: 'bauhaus',
  blocks: [{ title: 'A', markdown, masthead: { enabled: false }, ...(flags ? { flags } : {}) }],
});

const cueCount = (dl) => dl.pages.flatMap((p) => p.elements || [])
  .filter((el) => el && el.cue === 'continuation').length;
const diagFlags = (dl) => {
  const j = dl.diagnostics.justify || {};
  const skipped = j.skipped || [];
  return {
    applied: j.applied ?? 0,
    reason: skipped[0] ? skipped[0].reason : null,
    covered: (j.applied ?? 0) + skipped.length === dl.totalPages,
  };
};

describe('column flow default + opt-in balance cue', () => {
  it('sampletext2: default runs straight, opt-in balances with cue', async () => {
    const markdown = readCorpus('taskfiles/sampletext2.md');
    const def = (await runPipeline({ payload: docOf(markdown), mode: 'paginate', seed: SEED, timestamp: TIMESTAMP })).displayList;
    const bal = (await runPipeline({ payload: docOf(markdown, { balance_columns: true }), mode: 'paginate', seed: SEED, timestamp: TIMESTAMP })).displayList;
    assert.equal(cueCount(def), 0, 'default flow carries no continuation cue');
    assert.ok(cueCount(bal) > 0, 'opt-in balance stamps continuation cues');
    assert.ok(bal.totalPages <= def.totalPages, 'balance packs tighter or equal');
  });

  // The marks replaced a single arrow parked at the shorter column's text edge
  // pointing down into the margin, which read as belonging to whichever column
  // happened to run shorter. These invariants are what makes each mark say one
  // thing: the gutter arrow is the col1-to-col2 break, the chevron is the
  // reading terminus running on, and neither is ever printed over content.
  it('balance cues sit on the flow break, never on content or in the margin', async () => {
    // Fixture: this test needs a document where a balanced region still has
    // content running on, because the terminus cue is only drawn when the
    // reading does NOT end on the page. It used sampletext2/bauhaus, which the
    // capacity fix now flushes so completely that nothing runs on — the cue
    // became unreachable and this gate went red for a reason that was not a
    // regression. Corpus scan under the fix: sample1/base is the combo that
    // still overflows under balance (7 pages, 12 crosses, 2 tails), so this
    // uses base geometry with sample1 and the cross-cue path is still checked
    // on every page it renders.
    const tmpl = TEMPLATES.base;
    const { width: A4W, height: A4H } = PAGE_SIZES.A4;
    const colW = (A4W - tmpl.margins.left - tmpl.margins.right - tmpl.columnsep) / 2;
    const col0Right = tmpl.margins.left + colW;
    const col1Left = col0Right + tmpl.columnsep;
    const col1Centre = col1Left + colW / 2;
    const contentBottomY = A4H - tmpl.margins.bottom - tmpl.footskip;
    const markdown = readCorpus('sample1.md');
    const dl = (await runPipeline({
      payload: { ...docOf(markdown, { balance_columns: true }), template: 'base' },
      mode: 'paginate', seed: SEED, timestamp: TIMESTAMP,
    })).displayList;

    // Nearest body line bottom at or above a cue: a cue that floats mid-void
    // says nothing, so each mark must hug the break it names (HUG_PT slack).
    const HUG_PT = 7;
    const nearestBottomAbove = (bottoms, y) => bottoms.filter((b) => b <= y + 0.5)
      .reduce((a, b) => Math.max(a, b), -Infinity);
    let crosses = 0;
    let tails = 0;
    for (const page of dl.pages) {
      const els = page.elements || [];
      const texts = els.filter((el) => el && el.type === 'text' && typeof el.y === 'number'
        && el.y + (el.size || 10) <= contentBottomY);
      const bottomsLeft = texts.filter((t) => t.x < col1Left - 1).map((t) => t.y + (t.size || 10));
      const bottomsRight = texts.filter((t) => t.x >= col1Left - 1).map((t) => t.y + (t.size || 10));
      for (const el of els.filter((e) => e && e.cue === 'continuation')) {
        const box = {
          x0: Math.min(el.x1, el.x2), x1: Math.max(el.x1, el.x2),
          y0: Math.min(el.y1, el.y2), y1: Math.max(el.y1, el.y2),
        };
        assert.ok(box.y1 <= contentBottomY + 0.01, `${el.cueRole}: cue crosses into the footer zone`);
        assert.ok(box.x1 <= col1Left + colW - 2, `${el.cueRole}: cue pushed out into the right margin`);
        const overText = texts.some((t) => (
          Math.min(box.x1, t.x + (t.width || colW)) - Math.max(box.x0, t.x) > 0
          && Math.min(box.y1, t.y + (t.size || 10)) - Math.max(box.y0, t.y) > 0
        ));
        assert.ok(!overText, `${el.cueRole}: cue printed over text`);
        if (el.cueRole === 'column-cross') {
          crosses++;
          assert.ok(box.x0 >= col0Right - 0.01 && box.x1 <= col1Left + 0.01,
            'column-cross: the gutter arrow must live in the gutter channel, not in a column');
          assert.ok(el.y1 === el.y2 ? el.x2 >= el.x1 : el.x2 > el.x1,
            'column-cross: every stroke must run toward the next column, never back or down');
          const near = nearestBottomAbove(bottomsLeft, box.y0);
          if (Number.isFinite(near)) {
            assert.ok(box.y0 - near <= HUG_PT, `column-cross: floats ${((box.y0 - near)).toFixed(1)}pt under the break`);
          }
        } else {
          assert.equal(el.cueRole, 'region-tail', `unknown cueRole ${el.cueRole}`);
          tails++;
          assert.ok(Math.abs(box.x0 - col1Centre) <= 2.81 && Math.abs(box.x1 - col1Centre) <= 2.81,
            'region-tail: must be centred under the column where the reading ends');
          const near = nearestBottomAbove(bottomsRight, box.y0);
          assert.ok(Number.isFinite(near), 'region-tail: needs a reading line above it');
          assert.ok(box.y0 - near <= HUG_PT, `region-tail: floats ${(box.y0 - near).toFixed(1)}pt under the last line`);
          const lowerThan = bottomsRight.filter((b) => b > box.y1 + 0.5);
          assert.equal(lowerThan.length, 0, 'region-tail: content below the page makes "runs on" false');
        }
      }
    }
    assert.ok(crosses > 0, 'balanced regions stamp the gutter cross cue');
    assert.ok(tails > 0, 'a page whose reading runs on stamps the terminus cue');
  });

  // The document-level control is what the workspace toggle writes; the engine
  // decides per block, so the value has to survive payload -> DocumentIR ->
  // block flags. A dropped hop is invisible: the toggle would sit in the panel
  // and the page would never change.
  it('the document-level column-break control reaches the layout engine', async () => {
    const markdown = readCorpus('taskfiles/sampletext2.md');
    const docLevel = (value) => ({
      title: 'Column flow',
      template: 'bauhaus',
      ...(value === null ? {} : { balance_columns: value }),
      blocks: [{ title: 'A', markdown, masthead: { enabled: false } }],
    });
    const plain = (await runPipeline({ payload: docLevel(null), mode: 'paginate', seed: SEED, timestamp: TIMESTAMP })).displayList;
    const off = (await runPipeline({ payload: docLevel(false), mode: 'paginate', seed: SEED, timestamp: TIMESTAMP })).displayList;
    const on = (await runPipeline({ payload: docLevel(true), mode: 'paginate', seed: SEED, timestamp: TIMESTAMP })).displayList;
    assert.equal(cueCount(plain), 0, 'absent control keeps the continuous default');
    assert.equal(cueCount(off), 0, 'document-level off keeps the continuous default');
    assert.ok(cueCount(on) > 0, 'document-level on must balance columns and stamp cues');
  });

  // "Encaixar pé da página": the footer-flush control is the last invisible
  // touch. ON, a gap-a-budget page closes to the rodapé line; OFF, every page
  // stays exactly where the fill put it and the post-pass has to say so for
  // every page it skips (G11 keeps covering the whole document).
  it('flush-bottom toggle gates the 3b post-pass with an honest reason', async () => {
    const markdown = readCorpus('sample4.md');
    const mk = (value) => ({
      title: 'Flush', template: 'bauhaus', headerText: 'Material de Teste do Corpus',
      ...(value === null ? {} : { flush_columns: value }),
      blocks: [{ title: 'A', markdown, masthead: { enabled: true, course: 'IMAGENOLOGIA', topic: 'P1:' }, columns: null }],
    });
    const on = (await runPipeline({ payload: mk(true), mode: 'paginate', seed: SEED, timestamp: TIMESTAMP })).displayList;
    const def = (await runPipeline({ payload: mk(null), mode: 'paginate', seed: SEED, timestamp: TIMESTAMP })).displayList;
    const off = (await runPipeline({ payload: mk(false), mode: 'paginate', seed: SEED, timestamp: TIMESTAMP })).displayList;

    assert.deepEqual(diagFlags(off), { applied: 0, reason: 'flush-off', covered: true },
      'off: nothing moved, every page accounted');
    // Default must be ON — the toggle is opt-out. The witness is the REASON,
    // not the applied count. M4 (2026-09-29) removed 3 of 5 stranded headings
    // by letting a heading carry its body to the next column instead of
    // cramming it at a column foot, and sample4/bauhaus came out of that with
    // no slack left on any page: `justify.applied` correctly went 1 -> 0
    // because there was nothing left to absorb. Asserting `applied >= 1` would
    // therefore have demanded that the layout stay sloppy. What must hold is
    // that the default is NOT 'flush-off' — that string appears only when the
    // toggle is explicitly false, and is the real marker of the default.
    assert.notEqual(diagFlags(def).reason, 'flush-off',
      'default: flush is opt-out, so the default run must not report flush-off');
    assert.deepEqual(diagFlags(on), diagFlags(def),
      'explicit true and the default must behave identically');
    assert.equal(on.diagnostics.overfullColumns, 0);
    assert.equal(off.diagnostics.overfullColumns, 0);
    assert.equal(on.totalPages, off.totalPages, 'flush buys space, never pagination');
  });

  // Continuous mode is a galley: col1 runs to the region foot, col2 picks up at
  // the top and runs to the same foot. The partition that predates this gave col2
  // whatever col1 left with no capacity check of its own, so a page could keep
  // one column entirely empty beside a full one (measured on sample3.md: 642pt
  // placed in col1, 0pt in col2, content carried to an extra page) and the
  // balancing refinement then shortened both columns to look symmetric. These
  // invariants are what makes "coluna corrida" mean the page is full.
  it('continuous mode fills both columns to the region foot', async () => {
    const tmpl = TEMPLATES.bauhaus;
    const { width: A4W, height: A4H } = PAGE_SIZES.A4;
    const colW = (A4W - tmpl.margins.left - tmpl.margins.right - tmpl.columnsep) / 2;
    const col1Left = tmpl.margins.left + colW + tmpl.columnsep;
    const contentBottomY = A4H - tmpl.margins.bottom - tmpl.footskip;
    // A column may stop short only where a heading refused to close a column
    // without its body (anti-orphan clearance) plus the last item's trailing
    // gap: ~24pt + one gap, measured worst case 25.8pt on this fixture.
    const FOOT_TOL = 32;
    const body = 'Linha de corpo com palavras suficientes para embrulhar uma coluna estreita do documento compilado.';
    const markdown = Array.from({ length: 14 }, (_, i) => `# Título ${i}\n\n${Array.from({ length: 5 }, (_, j) => `Parágrafo ${i}.${j} ${body} ${body}`).join('\n\n')}`).join('\n');

    const footOf = (dl) => dl.pages.map((page) => {
      let left = -Infinity;
      let right = -Infinity;
      for (const el of (page.elements || [])) {
        if (!el || el.type !== 'text') continue;
        const bottom = (el.y || 0) + (el.size || 10);
        if (bottom > contentBottomY + 0.01) continue;
        if (el.x < col1Left - 1) left = Math.max(left, bottom);
        else right = Math.max(right, bottom);
      }
      return { left, right };
    });

    const run = (flags) => runPipeline({
      payload: docOf(markdown, flags), mode: 'paginate', seed: SEED, timestamp: TIMESTAMP,
    }).then((r) => r.displayList);
    const dl = await run();
    const bal = await run({ balance_columns: true });

    assert.ok(dl.totalPages >= 3, 'multi-page fixture');
    const feet = footOf(dl);
    for (const [i, f] of feet.slice(0, -1).entries()) {
      const n = i + 1;
      assert.ok(Number.isFinite(f.left), `p${n}: continuous page without text in col1`);
      assert.ok(Number.isFinite(f.right), `p${n}: col2 left empty while the block continues (false column break)`);
      assert.ok(contentBottomY - f.left <= FOOT_TOL,
        `p${n}: col1 ends ${(contentBottomY - f.left).toFixed(1)}pt above the region foot`);
      assert.ok(contentBottomY - f.right <= FOOT_TOL,
        `p${n}: col2 ends ${(contentBottomY - f.right).toFixed(1)}pt above the region foot`);
    }
    assert.ok(dl.totalPages <= bal.totalPages,
      `continuous flow must never cost a page vs column-break mode (${dl.totalPages} > ${bal.totalPages})`);
  });
});
