/**
 * Table header style (user report with reference photos).
 *
 *  The reference renders panoramic headers PLAIN: bold dark text on paper
 *  with a light midrule — no inverted dark band. A band was briefly
 *  shipped on a thumbnail misread and is pinned off here.
 *
 *  G-plainhead1 — panoramic tables carry no full-width dark rect.
 *  G-plainhead2 — header text renders in the dark cell color, not white.
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { GeometryCompiler } from '../../src/v2/compiler/geometry-compiler.js';
import { normalizeToDocIR } from '../../src/v2/core/contracts.js';

const DENSE_TABLE = '| Familia de Receptor | Topografia Celular | Mecanismo de Acao e Transducao | Escala Temporal de Efeito | Prototipo Farmacologico |\n'
  + '| --- | --- | --- | --- | --- |\n'
  + '| Ionotropicos acoplados a canal ionico com texto longo | Membrana plasmatica integral | Abertura alosterica | Milissegundos | Receptor colinergico |\n'
  + '| Segunda familia longa | Outra topografia detalhada | Outro mecanismo longo | Segundos | Outro prototipo |\n';

const compile = (markdown) => new GeometryCompiler().compile(
  normalizeToDocIR({ title: 'T', template: 'bauhaus', blocks: [{ title: 'A', markdown }] }), {},
);

const DARK = new Set(['#111827', '#0F172A', '#18181B']);

describe('plain panoramic header', () => {
  it('G-plainhead1: no dark full-width band on panoramic tables', () => {
    const dl = compile(DENSE_TABLE);
    const els = dl.pages.flatMap((p) => p.elements || []);
    const bands = els.filter((e) => e.type === 'rect' && DARK.has(e.fill) && (e.w || 0) > 400);
    assert.equal(bands.length, 0, `dark band present: ${JSON.stringify(bands.slice(0, 1))}`);
  });

  it('G-plainhead2: header text is dark, not white', () => {
    const dl = compile(DENSE_TABLE);
    const els = dl.pages.flatMap((p) => p.elements || []);
    const heads = els.filter((e) => e.type === 'text'
      && /Familia|Topografia|Mecanismo|Escala|Prototipo/.test(e.text || ''));
    assert.ok(heads.length > 0, 'no header text found');
    for (const h of heads) {
      assert.ok(
        (h.color || '').toUpperCase() !== '#FFFFFF',
        `white header text: ${JSON.stringify(h.text)}`,
      );
    }
  });
});
