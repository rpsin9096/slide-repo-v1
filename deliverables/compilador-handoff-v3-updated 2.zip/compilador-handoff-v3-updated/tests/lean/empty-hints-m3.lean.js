import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

/* M3 empty states: a fresh block hints instead of blanking. Markdown gets a
 * real textarea placeholder; Rich renders an actionable empty hint (reusing
 * the .bedit-empty style) that inserts a paragraph on tap.
 * Run: node --test tests/lean/empty-hints-m3.lean.js */

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..');
const src = (p) => readFileSync(join(root, p), 'utf8');

describe('M3 — empty blocks hint, never blank', () => {
  it('markdown textarea carries a placeholder', () => {
    assert.ok(
      src('static/v2-app.js').includes('placeholder="Escreva em Markdown'),
      'card template textarea needs placeholder'
    );
  });

  it('placeholder styling is token-only', () => {
    const css = src('static/design-system.css');
    const i = css.indexOf('.box-md::placeholder');
    assert.notEqual(i, -1, 'missing rule: .box-md::placeholder');
    const b = css.slice(css.indexOf('{', i) + 1, css.indexOf('}', css.indexOf('{', i)));
    assert.ok(b.includes('var(--color-muted)'), `expected muted token, got: ${b.trim()}`);
  });

  it('rich renders an actionable empty hint for blockless content', () => {
    const js = src('static/editor-core.js');
    assert.ok(js.includes('bedit-empty'), 'empty hint element rendered');
    assert.ok(js.includes('para começar'), 'hint copy present');
    assert.ok(js.includes("handleInsertAt(0, 'p')"), 'hint inserts a paragraph');
  });
});
