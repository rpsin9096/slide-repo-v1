import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { splitBlocks, serializeBlocks, BlockStore } from '../../static/editor-core.js';

const reloadCount = (store) => splitBlocks(store.getMarkdown()).length;

describe('rich text cards survive reload', () => {
  it('insert in middle keeps 3 cards after reserialize', () => {
    const s = new BlockStore('A\n\nB\n');
    s.insertBlockAt(1, '# Novo Título\n');
    assert.equal(s.blocks.length, 3);
    assert.equal(reloadCount(s), 3);
  });

  it('append after edit keeps cards after reserialize', () => {
    const s = new BlockStore('A\n\nB\n');
    s.updateBlockText(1, 'B edited');
    s.appendLines('C\n');
    assert.equal(s.blocks.length, 3);
    assert.equal(reloadCount(s), 3);
  });

  it('move keeps cards after reserialize', () => {
    const s = new BlockStore('A\n\nB\n\nC\n');
    s.moveBlock(0, 2);
    assert.equal(s.blocks.length, 3);
    assert.equal(reloadCount(s), 3);
  });

  it('multi-paragraph doc roundtrips stable', () => {
    const md = 'Para 1\n\nPara 2\n\nPara 3\n';
    assert.equal(splitBlocks(serializeBlocks(splitBlocks(md))).length, 3);
  });

  it('CRLF doc splits into N cards (no reload merge)', () => {
    assert.equal(splitBlocks('A\r\n\r\nB\r\n\r\nC\r\n').length, 3);
  });

  it('CR-only doc splits into N cards (no reload merge)', () => {
    assert.equal(splitBlocks('A\r\rB\r\rC').length, 3);
  });

  it('CRLF roundtrips stable through serialize', () => {
    const s = new BlockStore('A\r\n\r\nB\r\n\r\nC\r\n');
    assert.equal(s.blocks.length, 3);
    assert.equal(splitBlocks(s.getMarkdown()).length, 3);
  });
});
