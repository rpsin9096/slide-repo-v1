// G19c — a heading is never read after the sub-heading it names.
//
// PARITY EXCEEDED 2026-09-29 (M4). The inversion set went 3 documents -> 2:
// `sampletext2/bauhaus_minimalist` no longer reads a heading after its own
// sub-heading, because the ungated column-boundary keep-with-next
// (geometry-compiler.js, `if (endsHeading(c1) && bite.length > 1)`) now
// prevents that plan from being placed. MAX_INVERSIONS is 2 and EXPECTED holds
// the 2 survivors, so this gate is TIGHTER than the reference, not looser —
// the reference (`copy 34`) still has 3. Do not restore 3 "for parity": parity
// was the floor while we were behind, and the lock is a ceiling on regressions.
// Both the count and the identity are asserted, so a new document failing, or
// a known one being silently repaired again, both go red.
//
// CORRECTED 2026-09-29. The previous version of this gate was wrong in two
// independent ways, and both are worth keeping in mind:
//
//   1. It compared `y` ACROSS COLUMNS. `y` is measured from the top of the
//      page independently for each column, so "the child is at col1 y=761"
//      says nothing about "the parent is at col0 y=782". Reading order in a
//      two-column page is col0 top->bottom, THEN col1 top->bottom. The old
//      predicate `c.col > p.col && c.y < p.y` therefore flagged pages that
//      were rendered correctly.
//   2. It named the wrong PAIR. On the page it reported, the pair it
//      complained about was in the CORRECT order:
//
//        READ# 53  col0  y=782.0  size=10.5  "Adaptacion celular:"             H1
//        READ#108  col1  y=761.2  size=9.0   "Mecanismos adaptativos basales:"  H2
//        READ# 54  col0  y=805.0  size=8.0   "RESPUESTAS ADAPTATIVAS BASALES:"  H3
//
//      #53 before #108 is correct. The real violation is the H2 at #108
//      reading AFTER its own H3 child at #54.
//
// So: indices in the reading sequence, never y. Parent/child pairing is by
// SOURCE adjacency (the next deeper heading in the markdown) — pairing by
// "any heading nearby on the page" is what produced the earlier false
// positive on "Diagnostico diferencial" (source line 197, an unrelated
// section) and then on "Fases de la inflamacion" vs "Fases de la
// cicatrizacion", which share a three-word opening.
//
// THRESHOLD = 3, and that is a PARITY number, not a target.
//
// THIS GATE IS NOT DISCRIMINATING AGAINST M3, and it should not be read as
// though it were. Verified 2026-09-29: it is GREEN both with and without the
// M3 heading-run guards in geometry-compiler.js. The set of inversions is
// identical either way; the only thing M3 moves is WHICH PAGE carries the
// sampletext2/base case (p3 -> p4), which is why the key is doc/template and
// not doc/template/page.
//
// So this is a pure REGRESSION LOCK: it pins the count and the identity of
// the known inversions so no future change silently reorders headings. It
// does not certify the M3 work. A gate that could not tell the two trees apart
// is a parity contract, not evidence — the two are easy to confuse and the
// postmortem's "no existence-only oracles" rule is exactly about this.
//
// Measured by reading order over 6 documents x 3 templates, 111 located
// parent/child pairs:
//
//   copy 34 (reference) : 3   sample2/bm p1, sampletext2/base p3, sampletext2/bauhaus p3
//   this tree           : 3   sampletext2/base p4, sampletext2/bauhaus p3,
//                              sampletext2/bauhaus_minimalist p1
//   (page numbers are this gate's own enumeration; the scratch audit that
//    first measured 3 numbered `base` as p3)
//   this tree, no M3    : 3   identical set
//
// All are the same shape: sampletext2.md:68-69, an H2 immediately followed by
// its H3, split across a page or column edge. The reference has the same
// defect, so this gate is a REGRESSION LOCK at parity — it pins the count
// AND the identity of the cases, so any change to heading order in either
// direction trips it. Setting it to 0 would demand beating the reference on
// an axis the reference also fails; that is a different milestone, and the
// one place it is worth attempting.
//
// NOTE ON M3: the layout work this gate originally justified (moving a
// parent heading in front of its child across a column boundary) turned out
// to address an artefact of the broken predicate, not a real inversion. With
// the corrected oracle it fixes none of these three. It is retained for
// separate, measured reasons — stranded headings 5 -> 4 (G19 now green),
// 9 of 10 changed column voids strictly smaller, suite failures 14 -> 5 — and
// the record in COLUMN-FOOT-EVENNESS-ROADMAP.md says so.
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readCorpus } from '../corpus/index.js';
import { runPipeline } from '../../src/v2/runtime/pipeline.js';

const here = dirname(fileURLToPath(import.meta.url));
const repo = join(here, '..', '..');

const DOCS = ['sample1.md', 'sample2.md', 'sample3.md', 'sample4.md', 'text-test.md',
  'taskfiles/sampletext2.md'];
const TEMPLATES = ['base', 'bauhaus', 'bauhaus_minimalist'];
const W = 595.28;
const SEED = 'g19c';

// Parity with the reference, measured. See the header.
const MAX_INVERSIONS = 2;
// KEYED ON doc/template, NOT ON PAGE NUMBER, and that is deliberate.
//
// The page carrying an inversion moves: M3 shifts sampletext2/base's case from
// p3 to p4 without repairing it. A page-keyed expectation would go RED on a
// layout change it does not claim to test, and GREEN on a real ordering change
// that happened to keep the same page. The gate's claim is heading ORDER, so
// the key is order-stable; the page is reported in the failure message for
// whoever has to go look at it.
//
// Verified seed-independent (g19c / audit / layout-v2 / zzz all identical), so
// the page shift came from the compiler, not from run-to-run variation.
const EXPECTED = [
  'taskfiles/sampletext2.md/base',
  'taskfiles/sampletext2.md/bauhaus',
];

const isHeading = (el) => !!el && el.type === 'text'
  && String(el.font || '').includes('bold') && (el.width || 0) >= 40;

const key = (t) => String(t || '').toLowerCase()
  .normalize('NFD').replace(/[̀-ͯ]/g, '')
  .replace(/[^a-z0-9]+/g, ' ').trim();

/** Headings in the markdown, in source order. */
function sourceHeadings(md) {
  const out = [];
  md.split('\n').forEach((line, i) => {
    const m = line.match(/^(#{1,6})\s+(.+?)\s*$/);
    if (m) out.push({ line: i + 1, level: m[1].length, text: m[2] });
  });
  return out;
}

/** A heading's true child: the next heading of a DEEPER level in source order. */
function childOf(src, h) {
  const k = src.indexOf(h);
  for (let j = k + 1; j < src.length; j++) {
    if (src[j].level > h.level) return src[j];
    if (src[j].level <= h.level) return null; // sibling or shallower: no child
  }
  return null;
}

/**
 * Every text element on a page in the order a reader meets it: col0
 * top->bottom, then col1 top->bottom. The index in this array IS reading
 * order; no other coordinate is comparable across columns.
 */
function readingSequence(page) {
  const els = (page.elements || []).filter((e) => e
    && e.type === 'text' && typeof e.y === 'number' && e.y < 818
    && String(e.text || '').trim() && (e.size || 0) > 7
    && !/^[\d\s]+$/.test(String(e.text || '').trim()));
  const cols = new Map();
  for (const e of els) {
    const c = (e.x || 0) < W / 2 ? 0 : 1;
    if (!cols.has(c)) cols.set(c, []);
    cols.get(c).push(e);
  }
  return [...cols.keys()].sort((a, b) => a - b)
    .flatMap((c) => cols.get(c).sort((a, b) => a.y - b.y));
}

/**
 * Locate a rendered heading by full-key match, either direction of prefix.
 * NOT a short prefix: "Fases de la cicatrizacion" and "Fases de la
 * inflamacion" share their first three words, and a 3-word match silently
 * pairs the wrong element.
 */
function locate(heads, text) {
  const k = key(text);
  if (!k) return null;
  return heads.find((h) => {
    const ek = key(h.el.text);
    return ek && (k.startsWith(ek) || ek.startsWith(k));
  });
}

async function render(doc, tpl) {
  const md = readCorpus(doc);
  const r = await runPipeline({ payload: { title: 'G19c', template: tpl,
    blocks: [{ title: 'B', markdown: md, masthead: { enabled: false },
      flags: { autofix: true, optimize_tables: true, split_equations: true }, columns: null }] },
    mode: 'paginate', seed: SEED, timestamp: 1700000000000 });
  return r.displayList.pages || [];
}

/** Every inversion in the corpus, as { id, parent, child, ph, ch }. */
async function auditCorpus() {
  const found = [];
  for (const doc of DOCS) {
    const src = sourceHeadings(readCorpus(doc));
    for (const tpl of TEMPLATES) {
      const defs = await import('../../src/v2/templates/definitions.js');
      if (!defs.TEMPLATES[tpl]) continue;
      const pages = await render(doc, tpl);
      for (let p = 0; p < pages.length; p++) {
        const seq = readingSequence(pages[p]);
        const heads = seq.map((el, i) => ({ el, i }));
        for (const parent of src) {
          const child = childOf(src, parent);
          if (!child) continue;
          const ph = locate(heads, parent.text);
          const ch = locate(heads, child.text);
          if (!ph || !ch) continue;
          // An inversion is the child's index being SMALLER: it is read
          // earlier. Page index counts too — a child on an earlier page is
          // read first just as surely as one higher up a column.
          if (ch.i < ph.i) {
            found.push({ id: `${doc}/${tpl}`,
              where: `p${p + 1}`, parent: parent.text, child: child.text,
              ph: ph.i, ch: ch.i });
          }
        }
      }
    }
  }
  return found;
}

describe('G19c — no heading is read after its own sub-heading (parity lock)', () => {
  it('inversions sit at parity with the reference, and are the measured three', async () => {
    const found = await auditCorpus();
    const ids = found.map((f) => f.id).sort();
    assert.ok(found.length <= MAX_INVERSIONS,
      `${found.length} heading-order inversion(s), above the parity ceiling of ${MAX_INVERSIONS} `
      + `(copy 34, the reference, has 3):\n      `
      + found.map((f) => `      ${f.id} ${f.where}: H "${f.parent.slice(0, 28)}" READ#${f.ph} `
        + `after its child "${f.child.slice(0, 28)}" READ#${f.ch}`).join('\n      '));
    assert.deepEqual(ids, EXPECTED.slice().sort(),
      `the SET of inversions changed. Parity is about identity, not just count: a new\n`
      + `document failing, or a known one silently repaired, both mean heading order\n`
      + `moved. Expected exactly:\n      ${EXPECTED.slice().sort().join('\n      ')}\n`
      + `      got:\n      ${ids.join('\n      ') || '(none)'}`);
  });

  it('the scan actually covers the corpus (non-vacuous)', async () => {
    // A predicate that locates nothing trivially reports zero inversions, so
    // prove pairs are being found at all.
    const src = sourceHeadings(readCorpus('taskfiles/sampletext2.md'));
    const pages = await render('taskfiles/sampletext2.md', 'bauhaus');
    let located = 0;
    for (const p of pages) {
      const heads = readingSequence(p).map((el, i) => ({ el, i }));
      for (const parent of src) {
        const child = childOf(src, parent);
        if (!child) continue;
        if (locate(heads, parent.text) && locate(heads, child.text)) located++;
      }
    }
    assert.ok(located > 0,
      `no parent/child pair located in sampletext2.md/bauhaus — the oracle is matching `
      + `nothing, so any zero it reports is meaningless (located ${located})`);
  });
});
