import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { decideTableSpan, decideImageSpan, isSpan, isRuleSpan } from '../../src/v2/layout/span-coordinator.js';

describe('span policy', () => {
  it('compact never spans', () => {
    assert.equal(decideTableSpan({ layoutMode: 'compact' }).span, false);
  });
  it('panoramic always spans', () => {
    assert.equal(decideTableSpan({ layoutMode: 'panoramic' }).span, true);
  });
  it('rotated defaults cw and spans', () => {
    assert.equal(decideTableSpan({ layoutMode: 'rotated' }).span, true);
  });
  it('image full-width spans, column does not', () => {
    assert.equal(decideImageSpan('full-width').span, true);
    assert.equal(decideImageSpan('column').span, false);
    assert.equal(decideImageSpan(undefined).span, false);
  });
  it('isSpan only panoramic table/image', () => {
    assert.equal(isSpan({ kind: 'table', panoramic: true }), true);
    assert.equal(isSpan({ kind: 'image', panoramic: true }), true);
    assert.equal(isSpan({ kind: 'table', panoramic: false }), false);
    assert.equal(isSpan({ kind: 'para' }), false);
  });
  it('rule between spans is fullWidth', () => {
    const items = [{ kind: 'table', panoramic: true }, { kind: 'rule' }, { kind: 'image', panoramic: true }];
    assert.equal(isRuleSpan(items[1], 1, items), true);
    assert.equal(isRuleSpan({ kind: 'rule' }, 0, [{ kind: 'rule' }]), false);
  });
});
