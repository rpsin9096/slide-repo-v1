/**
 * M1 — per-column independent funding.
 *
 * The seam substrate was built so each column can flush to the region foot on
 * its own seams (FEATHERING-PADDING-SPEC §3.2, §3.5: "each flushes to the
 * region foot"). The shipped consumer did the opposite: it picked ONE funding
 * scope — the deeper column foot — resolved it against the full page slack, and
 * handed every other column that same ratio. A column whose own void exceeded
 * its own capacity at the neighbour's ratio was recorded `partial-lift` and
 * left where it was.
 *
 * M1 makes each column fund its own void from its own seams, at its own ratio,
 * with a bounded lift when it cannot fund the whole thing.
 *
 * These are UNIT gates on the resolver decision, deliberately not corpus
 * gates: they fail on a synthetic two-column page where the old ladder provably
 * refuses, and they pin the properties the fix must preserve (per-column
 * independence, the ratio bound, heading bonds, footer safety).
 *
 * Spec: COLUMN-FOOT-EVENNESS-SPEC.md §2.1 / R1. Roadmap M1.
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readCorpus } from '../corpus/index.js';
import {
  resolveSeams, computeElementShifts, capShiftsToFoot, boundedLift, STRETCH_CEILING_PITCH_RATIO,
} from '../../src/v2/layout/glue-allocator.js';
import { capacityForClass, classForItemKind, makeSeam, elementExtent, SEAM_CLASS } from '../../src/v2/layout/stretch-seam.js';
import { runPipeline } from '../../src/v2/runtime/pipeline.js';
import { rhythmForTemplate, TEMPLATES } from '../../src/v2/templates/definitions.js';
import { PAGE_SIZES } from '../../src/v2/core/geometry.js';

const here = dirname(fileURLToPath(import.meta.url));
const repo = join(here, '..', '..');
const SEED = 'percol';
const TIMESTAMP = 1700000000000;
const tmpl = TEMPLATES.base;

/** The region foot a page's columns are measured against. */
const contentBottomY = (template) => {
  const t = TEMPLATES[template];
  return PAGE_SIZES.A4.height - t.margins.bottom - t.footskip;
};

const seam = (seq, scope, klass = 'para', capacity = null) => makeSeam({
  seq, page: 1, region: null, scope, y: 100 + seq * 10, klass,
  capacity: capacity === null ? capacityForClass(klass, tmpl) : capacity,
});

/**
 * Lowest inked y of each column on a compiled page, measured against the
 * region foot so an element that has bled past the foot cannot hide a void.
 * Same rule as the M0 PDF probe: the guarantee is about what lands on the
 * page, not about what the layout intended.
 */
const columnFeet = (page, cbY) => {
  const midX = PAGE_SIZES.A4.width / 2;
  let left = -Infinity;
  let right = -Infinity;
  for (const el of (page.elements || [])) {
    if (!el || el.type === 'rule' || typeof el.y !== 'number') continue;
    const bottom = el.y + (el.size || 10);
    if (bottom >= cbY + 0.5) continue;
    const x = el.x ?? el.x1 ?? 0;
    if (x < midX) left = Math.max(left, bottom); else right = Math.max(right, bottom);
  }
  return { left, right };
};

describe('M1 per-column independent funding', () => {
  it('no column is left UNLIFTED: every ragged column moved on its own seams', async () => {
    // The defect, asserted where it actually lives: the COMPILER's funding
    // decision, on a real two-column page.
    //
    // An earlier version of this test called `resolveSeams` directly and
    // passed on the unfixed tree — the resolver was never the broken part, so
    // a test of the resolver gated nothing. The broken part is the CHOICE of
    // funding scope in the 3b post-pass: it picked one scope and broadcast its
    // ratio to the others. That decision is only observable from the
    // allocator's own ledger, so this test reads compiled diagnostics.
    //
    // The case is sample2/bauhaus, where p2 had col:0 already at the foot
    // (void 0 -> broadcast ratio 0) while col:1 sat 31.9pt above it with 30pt
    // of its own capacity. col:1 inherited ratio 0, moved nothing, and the
    // ledger still called the page `applied`.
    //
    // SCOPE — this is M1's gate, not the whole guarantee. The defect was a
    // column left COMPLETELY unmoved while the ledger called the page
    // `applied`. So the gate is the accounting invariant: a page may only be
    // reported `applied` if every one of its columns actually reached the
    // foot. Whatever is still short must be visible as `partial-lift` with a
    // real number attached, so M2 inherits a true baseline.
    //
    // ASSERTED ON GEOMETRY, NOT ON LABELS. A first version of this gate
    // filtered notes by the reason string and passed on the UNFIXED tree,
    // because the label is something this code chose to write: renaming the
    // note made the test green without moving a single pixel. A second
    // version read `deliveredPt` from a ledger built on `scopeFoot` — a
    // seam-TOP estimate that read col:1 at 732.4pt on p2 while the real ink
    // sat at 792.9pt, so it reported a page as fully funded that was still
    // 12.9pt short. Both times the gate measured the label instead of the
    // page. This one measures inked feet directly.
    const md = readCorpus('sample2.md');
    const { displayList: dl } = await runPipeline({
      payload: {
        title: 'PerCol', template: 'bauhaus',
        blocks: [{
          title: 'A', markdown: md, masthead: { enabled: false },
          flags: { autofix: true, optimize_tables: true, split_equations: true },
          columns: null,
        }],
      },
      mode: 'paginate', seed: SEED, timestamp: TIMESTAMP,
    });
    const cbY = contentBottomY('bauhaus');
    const j = dl.diagnostics.justify;
    const applied = new Set(j.pages || []);
    const skipped = new Map((j.skipped || []).map((s) => [s.page, s.reason]));

    // G16: every page is accounted exactly once.
    for (const p of (dl.pages || [])) {
      const inA = applied.has(p.pageNumber);
      const inS = skipped.has(p.pageNumber);
      assert.ok(inA !== inS, `p${p.pageNumber} accounted exactly once (applied=${inA} skipped=${inS})`);
    }

    // THE M1 INVARIANT: a page reported `applied` has no column left short
    // of the foot. Measured from inked geometry, per column.
    const FALSE_APPLIED = [];
    for (const page of (dl.pages || [])) {
      if (!applied.has(page.pageNumber)) continue;
      const { left, right } = columnFeet(page, cbY);
      for (const [side, foot] of [['left', left], ['right', right]]) {
        if (!Number.isFinite(foot)) continue;
        const voidPt = cbY - foot;
        if (voidPt > 1.0) {
          FALSE_APPLIED.push(`p${page.pageNumber} ${side} short ${voidPt.toFixed(1)}pt but page reported applied`);
        }
      }
    }
    assert.deepEqual(
      FALSE_APPLIED, [],
      `pages reported applied with a column left short: ${FALSE_APPLIED.join('; ')}. `
      + 'The 3b pass must fund each column from its own seams and must not '
      + 'report a page as flushed while a column is still above the foot.',
    );

    // And the converse: a short column must be VISIBLE in the ledger with a
    // real number, never silently dropped.
    const lifted = (j.skipped || []).filter((s) => s.reason === 'partial-lift');
    for (const s of lifted) {
      const page = (dl.pages || []).find((p) => p.pageNumber === s.page);
      const { left, right } = columnFeet(page, cbY);
      const worst = Math.max(cbY - left, cbY - right);
      assert.ok(worst > 1.0, `p${s.page} partial-lift matches a real void (${worst.toFixed(1)}pt)`);
      assert.ok(s.slackPt > 0, `p${s.page} partial-lift reports its slack`);
    }
  });

  it('a column over its own capacity LIFTS via boundedLift instead of refusing', () => {
    // The refusal is what stranded col:1 on sample2/bauhaus p2: 31.9pt void,
    // 30.0pt capacity, ratio 1.065 -> over-ratio -> zero movement.
    //
    // This test previously asserted only that a reduce over `capacity` equalled
    // the same reduce over `capacity` -- `x === x`, true for any input, and
    // green with `boundedLift` deleted outright. It now calls the real function
    // and pins the three properties the compiler depends on. Non-vacuity is
    // proven by the deletion test at the foot of this file.
    const own = [seam(0, 'col:1'), seam(1, 'col:1')];
    const total = own.reduce((a, s) => a + s.capacity, 0);
    const voidPt = total * 1.5; // 50% over budget, like the 1.065 case
    const res = resolveSeams(own, voidPt);
    assert.equal(res.verdict, 'ragged', 'the strict resolver still refuses (unchanged)');
    assert.equal(res.reason, 'over-ratio');

    // The lift runs at the compiler's real ceiling, not at raw capacity.
    const ceilingPt = 12.4;
    assert.equal(STRETCH_CEILING_PITCH_RATIO, 0.30, 'the ceiling is the pitch fraction');
    const off = boundedLift(own, ceilingPt);

    // 1. It actually MOVES something (the old test could not see this).
    assert.equal(off.length, own.length, 'one offset per seam');
    const spent = off.reduce((a, b) => a + b, 0);
    assert.ok(spent > 0, `the lift spends a positive budget (got ${spent})`);

    // 2. It never moves a seam PAST its own capacity nor past the ceiling.
    for (const [i, s] of own.entries()) {
      assert.ok(off[i] <= s.capacity + 1e-9,
        `seam ${i} moved ${off[i].toFixed(3)}pt past its ${s.capacity.toFixed(3)}pt capacity`);
      assert.ok(off[i] <= ceilingPt + 1e-9,
        `seam ${i} moved ${off[i].toFixed(3)}pt past the ${ceilingPt}pt ceiling`);
    }

    // 3. It does NOT spend the full nominal budget when the ceiling is lower --
    //    this is the property the `fundColumn` comment got wrong. With the
    //    ceiling strictly below capacity the spend must be under `total`.
    const smallCeiling = Math.min(...own.map((s) => s.capacity)) * 0.5;
    const offTight = boundedLift(own, smallCeiling);
    const spentTight = offTight.reduce((a, b) => a + b, 0);
    assert.ok(spentTight < total,
      `a tight ceiling must spend less than the ${total.toFixed(3)}pt nominal budget `
      + `(got ${spentTight.toFixed(3)}pt)`);
    for (const v of offTight) {
      assert.ok(v <= smallCeiling + 1e-9, `offset ${v} exceeds the ${smallCeiling}pt ceiling`);
    }
  });

  it('a bounded lift never spends more than the void it closes (doc-87 regression)', () => {
    // The defect: page 2 of a 2-column bauhaus document was over-cap in col:1,
    // so the v3 sibling-sync branch replaced col:0's `applied` offsets with a
    // per-seam `boundedLift`. Sixteen seams x the 3.55pt ceiling summed to
    // 38.5pt against a 9.7pt void, and the overshoot guard then clamped a
    // 3-line list item by a different amount per line -- all three baselines
    // landed on the foot. The lift must spend the column's void, not
    // `ceiling x seams`.
    const seamCount = 16;
    const cap = capacityForClass(SEAM_CLASS.PARA, TEMPLATES.bauhaus);
    const seams = Array.from({ length: seamCount }, (_, i) => ({
      seq: i, scope: 'col:0', capacity: cap,
    }));
    const voidPt = 9.66;
    const ceiling = rhythmForTemplate(TEMPLATES.bauhaus).bodyPitchPt * STRETCH_CEILING_PITCH_RATIO;
    const sum = (a) => a.reduce((x, y) => x + y, 0);

    const uncapped = boundedLift(seams, ceiling);
    assert.ok(sum(uncapped) > voidPt,
      `non-vacuity: the uncapped lift must overshoot this void (got ${sum(uncapped).toFixed(2)}pt)`);

    const capped = boundedLift(seams, ceiling, voidPt);
    assert.ok(sum(capped) <= voidPt + 1e-9,
      `the lift spent ${sum(capped).toFixed(2)}pt of a ${voidPt.toFixed(2)}pt void`);
    // It must still close the void rather than refuse to move.
    assert.ok(sum(capped) >= voidPt - 0.25,
      `the lift left ${(voidPt - sum(capped)).toFixed(2)}pt of the void unspent`);
    for (const [i, v] of capped.entries()) {
      assert.ok(v <= cap + 1e-9, `seam ${i} past its capacity`);
      assert.ok(v <= ceiling + 1e-9, `seam ${i} past the ceiling`);
    }
  });

  it('the foot guard moves a multiline atom as one ownership group', () => {
    // Same shape as the doc-87 item: three lines stamped with one seamSeq.
    // Each line's own headroom differs, so per-element clamping collapsed
    // them; the group cap is the deepest line's headroom and the spacing
    // survives.
    const contentBottomY = 805.8;
    const lines = [764.0, 775.82, 787.64].map((y, i) => ({
      type: 'text', y, size: 8.5, seamSeq: 49, scope: 'col:0', text: `linha ${i}`,
    }));
    const shifts = new Map(lines.map((_, i) => [i, 38.54]));
    const capped = capShiftsToFoot(lines, shifts, contentBottomY, elementExtent);
    const moved = lines.map((el, i) => el.y + capped.get(i));

    assert.equal(capped.get(0), capped.get(1));
    assert.equal(capped.get(1), capped.get(2));
    const gaps = moved.slice(1).map((y, i) => Math.round((y - moved[i]) * 100) / 100);
    assert.deepEqual(gaps, [11.82, 11.82],
      `the atom's line spacing collapsed: ${JSON.stringify(moved)}`);
    assert.ok(moved[2] + 8.5 <= contentBottomY + 1e-9,
      `the atom crossed the foot: bottom ${(moved[2] + 8.5).toFixed(2)}`);

    // Untagged content has no group; it keeps the per-element guard.
    const lone = { type: 'text', y: 764.0, size: 8.5 };
    const loneShift = capShiftsToFoot([lone], new Map([[0, 38.54]]), contentBottomY, elementExtent);
    assert.equal(Math.round(loneShift.get(0) * 100) / 100, 33.3);
  });

  it('per-column funding keeps columns independent (G15)', () => {
    // Two columns, only col:1 has a void. Applying col:1 offsets must move
    // col:1 elements and must NOT move col:0 elements.
    const seams = [seam(0, 'col:0'), seam(1, 'col:0'), seam(2, 'col:1'), seam(3, 'col:1')];
    const offsets = new Map();
    for (const s of seams) offsets.set(s.seq, s.scope === 'col:1' ? (s.capacity || 0) : 0);
    const els = [
      { type: 'text', y: 120, seamSeq: 0, scope: 'col:0' },   // below col:0 seams
      { type: 'text', y: 200, seamSeq: 1, scope: 'col:0' },
      { type: 'text', y: 120, seamSeq: 2, scope: 'col:1' },   // below col:1 seams
      { type: 'text', y: 200, seamSeq: 3, scope: 'col:1' },
    ];
    const shifts = computeElementShifts(els, seams, offsets);
    assert.equal(shifts.get(0), 0, 'col:0 element unmoved by col:1 stretch');
    assert.equal(shifts.get(1), 0, 'col:0 element unmoved by col:1 stretch');
    assert.ok(shifts.get(2) > 0, 'col:1 element moves with its own seams');
    assert.ok(shifts.get(3) > 0, 'col:1 element moves with its own seams');
  });

  it('a headingBond seam still has zero capacity and cannot drift (G14)', () => {
    // Independent funding must not become "every gap stretches" — the bond
    // between a heading and its body is the one gap that must not move.
    assert.equal(capacityForClass('headingBond', tmpl), 0, 'bond capacity is zero');
    assert.equal(classForItemKind({ kind: 'heading' }), 'headingBond');
    const seams = [seam(0, 'col:0', 'para', 2), seam(1, 'col:0', 'headingBond', 0), seam(2, 'col:0', 'para', 2)];
    const offsets = new Map([[0, 2], [1, 0], [2, 2]]);
    const els = [{ type: 'text', y: 300, seamSeq: 2, scope: 'col:0' }];
    const shifts = computeElementShifts(els, seams, offsets);
    // Element below both bonds accumulates 2+0+2 = 4; the bond contributes 0.
    assert.equal(shifts.get(0), 4, 'bond seam contributes exactly zero');
  });

  it('a full-width span rides its own scope and both columns (never a sum)', () => {
    // A span below stretched columns must ride the DEEPER column foot, not
    // the sum of both scopes (they overlap in Y, so summing double-counts
    // one void into one visible jump).
    const seams = [seam(0, 'col:0', 'para', 3), seam(1, 'col:1', 'para', 5), seam(2, 'span', 'spanEdge', 2)];
    const offsets = new Map([[0, 3], [1, 5], [2, 2]]);
    const els = [{ type: 'rect', y: 400, seamSeq: 2, scope: 'span' }];
    const shifts = computeElementShifts(els, seams, offsets);
    // max(col scopes) + span = max(3,5) + 2 = 7, NOT 3+5+2 = 10.
    assert.equal(shifts.get(0), 7, 'span rides maxColAcc + spanAcc, never the sum');
  });
});

describe('M1 integration: per-column funding, real compile', () => {
  const docOf = (markdown, template) => ({
    title: 'PerCol',
    template,
    blocks: [{
      title: 'A', markdown, masthead: { enabled: false },
      flags: { autofix: true, optimize_tables: true, split_equations: true },
      columns: null,
    }],
  });

  it('sample2/bauhaus: the page that was 31.9pt short still lands safe and honest', async () => {
    // The measured case from the spec. The properties asserted here are the
    // ones the fix must NOT break — they are the safety envelope for R1.
    const md = readCorpus('sample2.md');
    const { displayList: dl } = await runPipeline({
      payload: docOf(md, 'bauhaus'), mode: 'paginate', seed: SEED, timestamp: TIMESTAMP,
    });
    const j = dl.diagnostics.justify;
    assert.ok(j, 'diagnostics.justify exists');
    // The page must be accounted for exactly once (G16): applied OR skipped
    // with a reason, never neither, never both.
    const applied = new Set(j.pages || []);
    const skipped = new Map((j.skipped || []).map((s) => [s.page, s.reason]));
    for (const p of (dl.pages || [])) {
      const inApplied = applied.has(p.pageNumber);
      const inSkipped = skipped.has(p.pageNumber);
      assert.ok(inApplied !== inSkipped, `p${p.pageNumber} accounted exactly once (applied=${inApplied} skipped=${inSkipped})`);
      if (inSkipped) assert.ok(skipped.get(p.pageNumber), `p${p.pageNumber} skip carries a reason`);
    }
    // G13: no applied page may exceed the ratio bound.
    assert.ok((j.maxRatio || 0) <= 1.0, `maxRatio ${j.maxRatio} within bound`);
    // G14: no headingBond seam moved despite zero capacity.
    assert.deepEqual(j.bondShifts || [], [], 'no heading bond drifted');
    // Footer safety: independent per-column movement must not bleed past the
    // region foot. This is the whole risk of the change.
    assert.equal(dl.diagnostics.bottomMarginViolations, 0,
      `footer bleed: ${dl.diagnostics.bottomMarginViolations} worst=${JSON.stringify(dl.diagnostics.bottomMarginWorst || [])}`);
    assert.equal(dl.diagnostics.overfullColumns, 0, 'no overfull column');
  });
});
