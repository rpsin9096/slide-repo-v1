import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  resolveSeams,
  MIN_VISIBLE_PT,
  MAX_RATIO,
} from '../../src/v2/layout/glue-allocator.js';
import {
  makeSeam,
  capacityForClass,
  SEAM_CLASS,
} from '../../src/v2/layout/stretch-seam.js';
import { TEMPLATES } from '../../src/v2/templates/definitions.js';

const tmpl = TEMPLATES.base;
const cap = (klass) => capacityForClass(klass, tmpl);

// Production-adapter seam: built through the real seam value object +
// template token capacity table (not hand-picked numbers).
const prodSeam = (seq, klass, scope = 'col:0', y = 100 + seq * 10) => makeSeam({
  seq, page: 1, region: null, scope, y, klass, capacity: cap(klass),
});

// Fixture-adapter seam: plain record, as M3 will read back off frozen pages.
const fixSeam = (seq, capacity, scope = 'col:0', y = 100 + seq * 10) => ({
  seq, page: 1, region: null, scope, y, klass: 'para', capacity,
});

const sum = (perSeam) => perSeam.reduce((a, s) => a + (s.offset || 0), 0);

describe('M2 VerticalGlueAllocator (pure, unwired)', () => {
  it('exposes the perceptibility contract constants', () => {
    assert.equal(MIN_VISIBLE_PT, 0.5);
    assert.equal(MAX_RATIO, 1.0);
  });

  it('zero slack → ragged negligible, zero shifts', () => {
    for (const seams of [
      [prodSeam(0, SEAM_CLASS.PARA), prodSeam(1, SEAM_CLASS.PARA)],
      [fixSeam(0, 2.5), fixSeam(1, 2.5)],
    ]) {
      const r = resolveSeams(seams, 0);
      assert.equal(r.verdict, 'ragged');
      assert.equal(r.reason, 'negligible');
      assert.ok(r.perSeam.every((s) => s.offset === 0), 'nothing shifts');
    }
  });

  it('negligible slack (≤0.5pt) → ragged negligible', () => {
    const r = resolveSeams([prodSeam(0, SEAM_CLASS.PARA), prodSeam(1, SEAM_CLASS.PARA)], 0.5);
    assert.equal(r.verdict, 'ragged');
    assert.equal(r.reason, 'negligible');
    assert.ok(r.perSeam.every((s) => s.offset === 0));
  });

  it('exactly at ratio 1.0 → applied, each seam at full capacity', () => {
    const seams = [prodSeam(0, SEAM_CLASS.PARA), prodSeam(1, SEAM_CLASS.PARA)];
    const total = seams.reduce((a, s) => a + s.capacity, 0);
    const r = resolveSeams(seams, total);
    assert.equal(r.verdict, 'applied');
    assert.ok(Math.abs(r.ratio - 1.0) < 1e-9, `ratio=${r.ratio}`);
    assert.ok(Math.abs(sum(r.perSeam) - total) < 1e-9, 'shifts sum exactly to slack');
    for (let i = 0; i < seams.length; i++) {
      assert.ok(Math.abs(r.perSeam[i].offset - seams[i].capacity) < 1e-9, 'ratio 1.0 ⇒ offset == capacity');
    }
  });

  it('over ratio → ragged over-ratio, zero shifts', () => {
    const seams = [prodSeam(0, SEAM_CLASS.PARA), prodSeam(1, SEAM_CLASS.PARA)];
    const total = seams.reduce((a, s) => a + s.capacity, 0);
    const r = resolveSeams(seams, total + 0.01);
    assert.equal(r.verdict, 'ragged');
    assert.equal(r.reason, 'over-ratio');
    assert.ok(r.perSeam.every((s) => s.offset === 0));
    assert.ok(r.ratio > 1.0);
  });

  it('capacity-0-only page (heading-bond / block-end) → ragged no-capacity', () => {
    const seams = [prodSeam(0, SEAM_CLASS.HEADING_BOND), prodSeam(1, SEAM_CLASS.BLOCK_END)];
    assert.ok(seams.every((s) => s.capacity === 0), 'bond classes carry zero capacity');
    const r = resolveSeams(seams, 3);
    assert.equal(r.verdict, 'ragged');
    assert.equal(r.reason, 'no-capacity');
    assert.ok(r.perSeam.every((s) => s.offset === 0));
  });

  it('single seam absorbs slack up to its own capacity', () => {
    const seams = [fixSeam(0, 4)];
    const ok = resolveSeams(seams, 4);
    assert.equal(ok.verdict, 'applied');
    assert.ok(Math.abs(ok.perSeam[0].offset - 4) < 1e-9);
    const over = resolveSeams(seams, 4.01);
    assert.equal(over.verdict, 'ragged');
    assert.equal(over.perSeam[0].offset, 0);
  });

  it('66-seam page absorbs 24pt (0.36pt each) → applied', () => {
    const seams = Array.from({ length: 66 }, (_, i) => fixSeam(i, cap(SEAM_CLASS.PARA), i % 2 ? 'col:1' : 'col:0'));
    const r = resolveSeams(seams, 24);
    assert.equal(r.verdict, 'applied');
    assert.ok(r.ratio <= 1.0, `ratio=${r.ratio}`);
    assert.ok(Math.abs(sum(r.perSeam) - 24) < 1e-6, 'shifts sum exactly to slack');
    assert.ok(r.perSeam.every((s) => s.offset <= s.capacity + 1e-9), 'no seam exceeds its own stretch');
    assert.ok(Math.max(...r.perSeam.map((s) => s.offset)) < 0.5, 'each shift sub-visible');
  });

  it('span+col mixed scopes distribute proportionally, zero-capacity seams hold still', () => {
    const seams = [
      prodSeam(0, SEAM_CLASS.PARA, 'col:0'),
      prodSeam(1, SEAM_CLASS.HEADING_BOND, 'col:0'),
      prodSeam(2, SEAM_CLASS.TABLE_EDGE, 'col:1'),
      prodSeam(3, SEAM_CLASS.SPAN_EDGE, 'span'),
    ];
    const total = seams.reduce((a, s) => a + s.capacity, 0);
    const slack = total * 0.5;
    const r = resolveSeams(seams, slack);
    assert.equal(r.verdict, 'applied');
    assert.ok(Math.abs(sum(r.perSeam) - slack) < 1e-9);
    assert.equal(r.perSeam[1].offset, 0, 'heading bond never drifts');
    for (let i = 0; i < seams.length; i++) {
      const want = slack * (seams[i].capacity / total);
      assert.ok(Math.abs(r.perSeam[i].offset - want) < 1e-9, `seam ${i} proportional`);
    }
  });

  it('is total: empty and all-zero inputs never throw', () => {
    assert.doesNotThrow(() => resolveSeams([], 5));
    assert.doesNotThrow(() => resolveSeams(null, 5));
    assert.doesNotThrow(() => resolveSeams([], 0));
    const e = resolveSeams([], 5);
    assert.equal(e.verdict, 'ragged');
    assert.deepEqual(e.perSeam, []);
    const z = resolveSeams(undefined, 2);
    assert.equal(z.verdict, 'ragged');
  });
});
