// Unit gate for the progress guarantee in _continuousFill.
//
// The guarantee is "the item opening a column always lands there, so a column is
// never empty while content waits." That is necessary — without it a column can
// stay empty and the caller has no progress — but it is not sufficient, and the
// gap it leaves is a stranded heading: when the item opening a column is a
// heading whose block continues, the heading is placed alone and the rest of its
// block goes to the next column.
//
// The exemption must therefore be scoped: an item may open a column freely when
// it is the start of a whole region, not when it is merely the next item of a
// block that began earlier.
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { GalleyEngine } from '../../src/v2/layout/galley-engine.js';

const engine = new GalleyEngine();
const heading = (h = 24) => ({ kind: 'heading', heightPt: h, lineHeight: 12 });
const body = (h = 22) => ({ kind: 'list-item', heightPt: h, lineHeight: 11 });

// A heading that fits at the head of an otherwise empty column, with its body
// following in the same block. The column is far taller than either item.
const block = [heading(24), body(22), body(22), body(22)];

describe('continuous fill — progress guarantee must not strand a block head', () => {
  it('a block-opening heading is not left alone in a column with room for its body', () => {
    const plan = engine.planColumns(block, { availableHeight: 200, balance: false });
    const col1Kinds = plan.col1.map((i) => i.kind);
    const col1 = plan.col1;
    const col2 = plan.col2;

    // The defect: col1 holds exactly the heading and nothing else, even though
    // availableHeight could hold the heading plus at least one body item.
    assert.ok(
      !(col1.length === 1 && col1[0].kind === 'heading' && col2.length > 0),
      `heading stranded alone: col1=${JSON.stringify(col1Kinds)} col2=${JSON.stringify(col2.map((i) => i.kind))}`,
    );
  });

  it('when the heading cannot be followed, the whole block stays unplaced rather than splitting', () => {
    // Only enough room for the heading itself.
    const tight = engine.planColumns(block, { availableHeight: 25, balance: false });
    // Either the heading is deferred (block unplaced) or it is followed, but it
    // must never be placed with the body split off into the other column.
    const headingAloneInCol1 = tight.col1.length === 1 && tight.col1[0].kind === 'heading';
    if (headingAloneInCol1) {
      assert.equal(
        tight.col2.length, 0,
        'heading alone in col1 with its body pushed to col2: the strand',
      );
    }
  });

  it('an item opening an empty column still lands (progress is preserved)', () => {
    // The guarantee the exemption exists for: an item taller than the column
    // must still be placed somewhere, never dropped and never looping forever.
    const huge = [{ kind: 'table', heightPt: 900, lineHeight: 12 }];
    const plan = engine.planColumns(huge, { availableHeight: 100, balance: false });
    const placed = plan.col1.length + plan.col2.length + (plan.unplaced || []).length;
    assert.equal(placed, 1, 'the oversized item must be accounted for exactly once');
  });
});
