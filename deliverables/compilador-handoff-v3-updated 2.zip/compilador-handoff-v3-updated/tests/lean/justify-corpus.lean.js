/**
 * VGA M5 — corpus distribution lock + dead-model absence.
 *
 * Two gates over the whole corpus (6 docs × 3 templates × balance on/off):
 *
 *  G12 distribution — every page is accounted for as applied or skipped with
 *  a reason, and every APPLIED page bottoms within 1pt of the region foot.
 *  The per-page void/ratio snapshot is frozen in
 *  `tests/fixtures/vertical-justify.json` so a future change to the
 *  allocator that moves geometry shows up as a diff, not as a silent
 *  regression. The fixture is regenerated deliberately:
 *      node scripts/probe-vertical-justification.mjs --json \
 *        > tests/fixtures/vertical-justify.json
 *
 *  G18 — no dead slack model survives in the source. The three retirements
 *  (the third glue distributor, the legacy gap Y-list, the per-call-site
 *  extent guesswork) must not come back in a refactor, even as comments.
 *
 * Spec: FEATHERING-PADDING-SPEC.md §5 (G12, G18). Roadmap M5.
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readCorpus } from '../corpus/index.js';
import { runPipeline } from '../../src/v2/runtime/pipeline.js';
import { TEMPLATES } from '../../src/v2/templates/definitions.js';
import { PAGE_SIZES } from '../../src/v2/core/geometry.js';
import { elementExtent } from '../../src/v2/layout/stretch-seam.js';

const here = dirname(fileURLToPath(import.meta.url));
const repo = join(here, '..', '..');
const SEED = 'vertical-justify';
const TIMESTAMP = 1700000000000;

const FIXTURE = join(repo, 'tests', 'fixtures', 'vertical-justify.json');

const contentBottomY = (template) => {
  const t = TEMPLATES[template];
  return PAGE_SIZES.A4.height - t.margins.bottom - t.footskip;
};

const docOf = (markdown, template, balance) => ({
  title: 'Probe',
  template,
  blocks: [{
    title: 'A', markdown, masthead: { enabled: false },
    flags: { autofix: true, optimize_tables: true, split_equations: true, ...(balance ? { balance_columns: true } : {}) },
    columns: null,
  }],
});

const pageVoidPt = (page, cbY) => {
  let bottom = -Infinity;
  for (const el of (page.elements || [])) {
    if (el && el.type === 'rule' && (el.y1 || 0) !== (el.y2 || 0)) continue;
    const ext = elementExtent(el);
    if (!ext || ext.top >= cbY + 0.5) continue;
    if (ext.bottom > bottom) bottom = ext.bottom;
  }
  return Number.isFinite(bottom) ? Math.round((cbY - bottom) * 100) / 100 : null;
};

describe('VGA M5 — corpus lock and dead-model removal', () => {
  // G12: the distribution gate. The frozen fixture is the regression lock
  // (geometry moved ⇒ the diff is visible and must be reviewed); the live
  // pass re-derives the same rows so the fixture cannot go stale silently.
  it('G12 distribution: applied pages flush, every page accounted, matches frozen fixture', async () => {
    const frozen = JSON.parse(readFileSync(FIXTURE, 'utf8'));
    const key = (r) => `${r.doc}|${r.template}|${r.balance}|${r.page}`;
    const frozenByKey = new Map((frozen.rows || []).map((r) => [key(r), r]));
    assert.ok(frozenByKey.size > 0, `frozen fixture ${FIXTURE} has rows`);

    let checked = 0;
    const appliedVoids = [];
    for (const row of frozen.rows) {
      const markdown = readCorpus(row.doc);
      const { displayList: dl } = await runPipeline({
        payload: docOf(markdown, row.template, row.balance), mode: 'paginate', seed: SEED, timestamp: TIMESTAMP,
      });
      const j = dl.diagnostics.justify || {};
      const page = (dl.pages || []).find((p) => p.pageNumber === row.page);
      assert.ok(page, `page ${row.page} exists [${row.doc}/${row.template}/bal=${row.balance}]`);

      // G12 distribution: every page applied or skipped-with-reason.
      const isApplied = (j.pages || []).includes(row.page);
      const isSkipped = (j.skipped || []).some((s) => s.page === row.page);
      assert.ok(isApplied !== isSkipped,
        `G12 [${row.doc}/${row.template}/bal=${row.balance}] p${row.page} neither applied nor skipped, or both`);

      if (isApplied) {
        // G12: an applied page bottoms within 1pt of the region foot.
        const cbY = contentBottomY(row.template);
        const voidPt = pageVoidPt(page, cbY);
        assert.ok(voidPt !== null && voidPt <= 1.0,
          `G12 [${row.doc}/${row.template}/bal=${row.balance}] p${row.page} applied but void=${voidPt}pt > 1pt`);
        appliedVoids.push(voidPt);
      }
      // Geometry lock: the void is compared for EVERY page, applied or not.
      // A ragged page's void is exactly the number that must stay large — if
      // an allocator change quietly flushed a page that should stay ragged,
      // this is where it shows. (Comparing only applied pages would let that
      // change pass silently, and comparing applied-vs-non-applied shapes is
      // the bug this gate had on its first run.)
      const frozenRow = frozenByKey.get(key(row));
      assert.ok(frozenRow, `frozen fixture has no row for ${key(row)} — the corpus changed shape`);
      const liveVoid = pageVoidPt(page, contentBottomY(row.template));
      assert.equal(liveVoid, frozenRow.voidPt,
        `G12 geometry drift [${row.doc}/${row.template}/bal=${row.balance}] p${row.page}: live void=${liveVoid}pt vs frozen ${frozenRow.voidPt}pt — regenerate the fixture only if the change is intended`);
      // Applied/lifted state must also be stable: a page flipping from
      // ragged to applied (or back) changes the document's character even
      // when the void happens to match.
      assert.equal(isApplied, frozenRow.applied,
        `G12 verdict drift [${row.doc}/${row.template}/bal=${row.balance}] p${row.page}: live applied=${isApplied} vs frozen ${frozenRow.applied}`);
      checked++;
    }
    assert.ok(checked > 0, 'G12 checked at least one page');
    assert.ok(appliedVoids.length > 0, 'G12 the corpus has applied pages to measure');
  });

  // G18: the three retirements must not come back — not even as a comment
  // that names them, because the check is a grep.
  it('G18 no dead slack model: retirements absent from src/', () => {
    const srcDir = join(repo, 'src');
    const stack = [srcDir];
    const banned = ['ElasticGlueDistributor', '_featherGaps', 'contentExtentOf'];
    const hits = [];
    while (stack.length) {
      const dir = stack.pop();
      for (const entry of readdirSync(dir, { withFileTypes: true })) {
        const full = join(dir, entry.name);
        if (entry.isDirectory()) { stack.push(full); continue; }
        if (!entry.name.endsWith('.js')) continue;
        const text = readFileSync(full, 'utf8');
        for (const sym of banned) {
          if (text.includes(sym)) hits.push(`${full.replace(repo + '/', '')}: ${sym}`);
        }
      }
    }
    assert.deepEqual(hits, [], `G18 dead slack model reintroduced: ${hits.join('; ')}`);
  });
});
