import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { slashNavIndex, pasteUrlLink, ceApplyInline } from '../../static/editor-core.js';

describe('B1 slash active-descendant nav', () => {
  it('ArrowDown/ArrowUp cycle with wrap', () => {
    assert.equal(slashNavIndex('ArrowDown', 0, 5), 1);
    assert.equal(slashNavIndex('ArrowDown', 4, 5), 0);
    assert.equal(slashNavIndex('ArrowUp', 0, 5), 4);
    assert.equal(slashNavIndex('ArrowUp', 2, 5), 1);
  });

  it('filter reset returns to first; empty list is -1', () => {
    assert.equal(slashNavIndex('reset', 3, 5), 0);
    assert.equal(slashNavIndex('ArrowDown', 0, 0), -1);
    assert.equal(slashNavIndex('ArrowDown', -1, 3), 0);
  });
});

describe('B2 paste-URL-over-selection (V5)', () => {
  it('bare URL over selected text becomes [text](url)', () => {
    const r = pasteUrlLink('hello world', 0, 5, 'https://example.com/x');
    assert.ok(r);
    assert.equal(r.text, '[hello](https://example.com/x) world');
  });

  it('collapses to null when inapplicable', () => {
    assert.equal(pasteUrlLink('hello', 2, 2, 'https://example.com'), null);
    assert.equal(pasteUrlLink('hello', 0, 5, 'not a url'), null);
    assert.equal(pasteUrlLink('[a](https://x)', 0, 16, 'https://y'), null);
    assert.equal(pasteUrlLink('a\nb', 0, 3, 'https://x'), null);
  });

  it('link toggle unwraps an existing link (toolbar symmetry)', () => {
    const r = ceApplyInline('[texto](https://a)', 0, 18, 'link');
    assert.equal(r.text, 'texto');
  });
});
