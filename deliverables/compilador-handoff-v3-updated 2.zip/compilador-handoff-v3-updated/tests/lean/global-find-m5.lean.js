import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

/* M5 global find: Ctrl/Cmd+K docks a document-wide find bar above the block
 * list — same match engine as the per-card rows, but the index spans blocks
 * and stepping jumps card-to-card through the highlight() seam. Per-card
 * rows stay untouched.
 * Run: node --test tests/lean/global-find-m5.lean.js */

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..');
const src = (p) => readFileSync(join(root, p), 'utf8');

describe('M5 — document-wide find', () => {
  it('find bar docks above the block list', () => {
    const html = src('static/index.html');
    assert.ok(html.includes('id="gsearch-row"'), 'bar element exists');
    assert.ok(html.includes('id="gsearch-input"'), 'query input exists');
    assert.ok(html.includes('id="greplace-all"'), 'replace-all exists');
    const css = src('static/design-system.css');
    const i = css.indexOf('.global-search-row {');
    assert.notEqual(i, -1, 'in-flow sticky rule (not the absolute overlay)');
    const b = css.slice(css.indexOf('{', i) + 1, css.indexOf('}', css.indexOf('{', i)));
    assert.ok(b.includes('sticky'), `must stick on scroll, got: ${b.trim()}`);
  });

  it('Ctrl/Cmd+K toggles; controller walks blocks via adapters', () => {
    const js = src('static/v2-app.js');
    assert.ok(js.includes("key === 'k'") || js.includes('key === "k"'), 'K shortcut bound');
    assert.ok(js.includes('toggleGlobalSearch'), 'toggle entry exists');
    assert.ok(js.includes('gsr'), 'cross-block match index exists');
    assert.ok(js.includes('[data-box-id="'), 'stepping resolves cards by id');
    assert.ok(js.includes('greplace-all'), 'replace-all wired');
  });

  it('guards: per-card rows untouched', () => {
    const js = src('static/v2-app.js');
    assert.ok(js.includes('doReplace'), 'per-card replace intact');
    assert.ok(js.includes("data-act=\"search\""), 'per-card toggle intact');
  });

  it('trigger: one quiet button with two homes', () => {
    const html = src('static/index.html');
    assert.ok(html.includes('id="global-search-btn"'), 'button in topbar-actions');
    assert.ok(html.includes('i-search'), 'reuses the search glyph');
    const js = src('static/v2-app.js');
    assert.ok(js.includes("$('#global-search-btn')"), 'button wired');
    assert.ok(js.includes('toggleGlobalSearch(true)'), 'opens the bar directly');
    assert.ok(js.includes("'global-search-btn'"), 'rides the Mais sheet move list');
  });

  it('trigger: sheet home shows a label, topbar stays icon-only', () => {
    const html = src('static/index.html');
    assert.ok(html.includes('>Localizar</span>'), 'button carries a label for the sheet');
    const css = src('static/design-system.css');
    assert.ok(css.includes('#sheet-body #global-search-btn'), 'sheet home styled');
    const i = css.indexOf('#sheet-body #global-search-btn {');
    const b = css.slice(css.indexOf('{', i) + 1, css.indexOf('}', css.indexOf('{', i)));
    assert.ok(b.includes('grid-auto-flow: column'), `icon + label side by side, got: ${b.trim()}`);
  });
});
