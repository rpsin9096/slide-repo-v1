import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { slashNavIndex } from '../../static/editor-core.js';

/* M6 insert-menu keyboard nav: the portal quick-menu gets ArrowUp/Down +
 * Home/End roving focus (Enter picks natively, Esc already closes),
 * reusing the slash menu's slashNavIndex — extended with a 'last' branch.
 * Run: node --test tests/lean/menu-keyboard-m6.lean.js */

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..');
const src = (p) => readFileSync(join(root, p), 'utf8');

describe('M6 — portal menu arrow-key nav', () => {
  it('slashNavIndex covers first + last with wrap-around', () => {
    assert.equal(slashNavIndex('ArrowDown', 3, 4), 0);
    assert.equal(slashNavIndex('ArrowUp', 0, 4), 3);
    assert.equal(slashNavIndex('first', 2, 4), 0);
    assert.equal(slashNavIndex('last', 1, 4), 3);
    assert.equal(slashNavIndex('End', 0, 5), 4);
  });

  it('openPortalMenu drives roving focus through slashNavIndex', () => {
    const js = src('static/editor-core.js');
    const i = js.indexOf('openPortalMenu(anchorBtn');
    assert.notEqual(i, -1, 'openPortalMenu exists');
    const body = js.slice(i, js.indexOf('\n  }\n', i) + 5);
    assert.ok(body.includes('ArrowDown'), 'arrow keys handled');
    assert.ok(body.includes('slashNavIndex'), 'reuses the shared nav helper');
    assert.ok(body.includes('scrollIntoView'), 'keeps focus visible in capped menus');
  });
});
