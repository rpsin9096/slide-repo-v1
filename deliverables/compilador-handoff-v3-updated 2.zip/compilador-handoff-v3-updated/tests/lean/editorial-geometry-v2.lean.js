import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createMockEditorialDom } from '../../scripts/probe-editorial-geometry-v2.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../..');

describe('EditorialGeometryEngine v2.0 — Template-Aware Geometry, Fragmentation & Bottom-Padding Suite', () => {
  const guardrailsConfig = JSON.parse(
    fs.readFileSync(path.join(ROOT, 'design-guardrails.config.json'), 'utf8')
  );

  it('1. Multi-unit & paper preset resolution at 96 DPI + landscape dimension swap', async () => {
    const { EditorialGeometryEngine } = await import('../../pdf-engine.js');
    const engine = new EditorialGeometryEngine(guardrailsConfig);

    assert.ok(Math.abs(engine.parseDimensionToPx('1in') - 96) < 1e-6);
    assert.ok(Math.abs(engine.parseDimensionToPx('25.4mm') - 96) < 1e-6);
    assert.ok(Math.abs(engine.parseDimensionToPx('2.54cm') - 96) < 1e-6);
    assert.ok(Math.abs(engine.parseDimensionToPx('72pt') - 96) < 1e-6);
    assert.ok(Math.abs(engine.parseDimensionToPx('1pc') - 16) < 1e-6);
    assert.equal(engine.parseDimensionToPx(130), 130);

    // Portrait A4 vs Landscape Dossier vs US Letter vs A3/A5/Legal/Tabloid
    const a4 = new EditorialGeometryEngine(guardrailsConfig, { templateId: 'default' });
    assert.ok(Math.abs(a4.config.px.width - 793.700787) < 0.01);
    assert.ok(Math.abs(a4.config.px.height - 1122.519685) < 0.01);

    const landscape = new EditorialGeometryEngine(guardrailsConfig, { templateId: 'landscape-dossier' });
    assert.equal(landscape.config.orientation, 'landscape');
    assert.ok(landscape.config.px.width > landscape.config.px.height, 'landscape swaps width > height');
    assert.ok(Math.abs(landscape.config.px.width - 1122.519685) < 0.01);
    assert.ok(Math.abs(landscape.config.px.height - 793.700787) < 0.01);

    const letter = new EditorialGeometryEngine(guardrailsConfig, { templateId: 'us-letter-brief' });
    assert.ok(Math.abs(letter.config.px.width - 816) < 0.5);
    assert.ok(Math.abs(letter.config.px.height - 1056) < 0.5);

    const a3Landscape = new EditorialGeometryEngine(guardrailsConfig, {
      templateConfig: { geometry: { format: 'A3', orientation: 'landscape' } },
    });
    assert.ok(Math.abs(a3Landscape.config.px.width - 1587.401575) < 0.05);
    assert.ok(Math.abs(a3Landscape.config.px.height - 1122.519685) < 0.05);
  });

  it('2. 4-Tier Template Geometry Resolution Hierarchy & Per-Page Usable Height (Page 1 vs Page N)', async () => {
    const { EditorialGeometryEngine } = await import('../../pdf-engine.js');
    const env = createMockEditorialDom({
      template: 'executive-report',
      cssVars: { '--template-margin-top': '20mm' },
    });
    env.installGlobals();
    try {
      // Tier 2 (DOM data-template="executive-report") beats Tier 3 (--template-margin-top: 20mm) and Tier 4 (defaults)
      const engDom = new EditorialGeometryEngine(guardrailsConfig, {}, env.documentRoot);
      assert.equal(engDom.config.templateId, 'executive-report');
      assert.equal(engDom.config.css.marginTop, '26mm');
      assert.equal(engDom.config.css.firstPageMarginTop, '35mm');
      assert.equal(engDom.config.css.firstPageHeaderSafeZone, '0mm');
      assert.notEqual(
        engDom.getUsablePageHeightPx(0),
        engDom.getUsablePageHeightPx(1),
        'executive-report has distinct Page 1 vs Page 2 usable height'
      );

      // Tier 1 (Runtime Override) beats Tier 2
      const engRuntime = new EditorialGeometryEngine(
        guardrailsConfig,
        { templateId: 'legal-contract', templateConfig: { geometry: { marginTop: '40mm' } } },
        env.documentRoot
      );
      assert.equal(engRuntime.config.templateId, 'legal-contract');
      assert.equal(engRuntime.config.css.marginTop, '40mm');
      assert.equal(engRuntime.config.fragmentation.minOrphanLines, 4);

      // Tier 3 (CSS Custom Properties on documentRoot when template is default) beats Tier 4
      const envCss = createMockEditorialDom({
        template: 'default',
        cssVars: { '--template-margin-top': '19mm', '--template-page-orientation': 'landscape' },
      });
      const engCss = new EditorialGeometryEngine(guardrailsConfig, {}, envCss.documentRoot);
      assert.equal(engCss.config.css.marginTop, '19mm');
      assert.equal(engCss.config.orientation, 'landscape');
    } finally {
      env.restoreGlobals();
    }
  });

  it('3. Transitive Heading & List-Intro Glueing, Atomic Push-Down, Table/List Continuation Splitting, and 6-Gate Audit', async () => {
    const { normalizeEditorialGeometry, verifyTemplateEditorialGeometry } = await import('../../pdf-engine.js');
    const env = createMockEditorialDom({ template: 'executive-report' });
    env.installGlobals();
    try {
      const { doc, documentRoot } = env;

      // Page 1 usable height on executive-report is 297 - (35 + 30 + 0 + 14) = 218mm (~823.9px)
      // 1. Place a tall intro paragraph inside a semantic <section class="document-section"> wrapper (700px)
      const sec1 = doc.createElement('section');
      sec1.className = 'document-section';
      const p1 = doc.createElement('p');
      p1.textContent = 'Bloco inicial longo ocupando grande parte da primeira página.';
      p1.setBoxMetrics({ height: 700, marginBottom: 16, paddingBottom: 10 });
      sec1.appendChild(p1);
      documentRoot.appendChild(sec1);

      // 2. Chained headings h2 -> h3 -> p.list-intro -> ol (cannot fit in remaining ~123px -> must push entire chain to Page 2!)
      const h2 = doc.createElement('h2');
      h2.textContent = '1. Diretrizes Clínicas';
      h2.setBoxMetrics({ height: 28, marginTop: 16, marginBottom: 8 });
      const h3 = doc.createElement('h3');
      h3.textContent = '1.1. Protocolo Escalonado';
      h3.setBoxMetrics({ height: 24, marginTop: 8, marginBottom: 8 });
      const intro = doc.createElement('p');
      intro.className = 'list-intro';
      intro.textContent = 'Siga os passos obrigatórios abaixo:';
      intro.setBoxMetrics({ height: 22, marginTop: 4, marginBottom: 8 });

      const ol = doc.createElement('ol');
      ol.setAttribute('start', '5');
      ol.setBoxMetrics({ marginTop: 0, marginBottom: 16 });
      for (let i = 1; i <= 6; i++) {
        const li = doc.createElement('li');
        li.textContent = `Item ordenado número ${i + 4}`;
        li.setBoxMetrics({ height: 140, marginTop: 4, marginBottom: 8 });
        ol.appendChild(li);
      }
      documentRoot.appendChild(h2);
      documentRoot.appendChild(h3);
      documentRoot.appendChild(intro);
      documentRoot.appendChild(ol);

      // 3. Framed callout box near page bottom -> must push down atomically and keep internal padding when .is-page-bottom
      const callout = doc.createElement('div');
      callout.className = 'callout-box';
      callout.textContent = 'Caixa de destaque atômica.';
      callout.setBoxMetrics({
        height: 220,
        marginTop: 12,
        marginBottom: 16,
        paddingTop: 16,
        paddingBottom: 16,
        borderTopWidth: 1,
        borderBottomWidth: 1,
        backgroundColor: '#f8fafc',
      });
      documentRoot.appendChild(callout);

      // 4. Multi-page table with rowspan, thead, and tfoot
      const table = doc.createElement('table');
      table.setBoxMetrics({ marginTop: 12, marginBottom: 20, paddingBottom: 0 });
      const thead = doc.createElement('thead');
      const headTr = doc.createElement('tr');
      headTr.setBoxMetrics({ height: 36 });
      const th = doc.createElement('th');
      th.textContent = 'Parâmetro';
      headTr.appendChild(th);
      thead.appendChild(headTr);
      table.appendChild(thead);

      const tbody = doc.createElement('tbody');
      for (let r = 0; r < 6; r++) {
        const tr = doc.createElement('tr');
        tr.setBoxMetrics({ height: 150 });
        const td = doc.createElement('td');
        td.textContent = `Linha ${r + 1}`;
        if (r === 2) td.setAttribute('rowspan', '2'); // lock row 2 and row 3 together
        tr.appendChild(td);
        tbody.appendChild(tr);
      }
      table.appendChild(tbody);

      const tfoot = doc.createElement('tfoot');
      const footTr = doc.createElement('tr');
      footTr.setBoxMetrics({ height: 32 });
      tfoot.appendChild(footTr);
      table.appendChild(tfoot);
      documentRoot.appendChild(table);

      const res1 = await normalizeEditorialGeometry(documentRoot, guardrailsConfig);
      assert.equal(res1.status, 'normalized');
      assert.equal(res1.templateId, 'executive-report');
      assert.ok(res1.totalPagesEstimated >= 3);

      // Verify all 6 gates in verifyTemplateEditorialGeometry
      const audit = verifyTemplateEditorialGeometry(documentRoot);
      assert.equal(audit.passed, true, `Audit failed with errors: ${audit.errors.join('; ')}`);
      assert.equal(audit.errorCount, 0);

      // Verify h2 pushed to Page 2 and p1 + sec1 marked .is-page-bottom
      assert.equal(h2.classList.contains('js-forced-page-break'), true, 'h2 pushed to top of Page 2');
      assert.equal(p1.classList.contains('is-page-bottom'), true, 'p1 marked .is-page-bottom');
      assert.equal(sec1.classList.contains('is-page-bottom'), true, 'ancestor sec1 marked .is-page-bottom');

      // Verify <ol start="5"> split with continuation marker and preserved start="N"
      const splitOls = documentRoot.querySelectorAll('ol[data-split-origin-id]');
      assert.ok(splitOls.length >= 2, 'ordered list was split across pages');
      const secondOl = splitOls[1];
      assert.ok(secondOl.previousElementSibling.classList.contains('list-continuation-caption'));
      assert.equal(Number(secondOl.getAttribute('start')), 5 + splitOls[0].children.length);

      // Verify <table> split with cloned thead, relocated tfoot, and respected rowspan lock
      const splitTables = documentRoot.querySelectorAll('table[data-split-origin-id]');
      assert.ok(splitTables.length >= 2, 'table was split across pages');
      assert.equal(splitTables[0].querySelector('tfoot'), null, 'tfoot removed from non-terminal table fragment');
      assert.ok(splitTables[splitTables.length - 1].querySelector('tfoot'), 'tfoot present on terminal table fragment');

      // Verify idempotency on second pass
      const res2 = await normalizeEditorialGeometry(documentRoot, guardrailsConfig);
      assert.equal(res2.totalPagesEstimated, res1.totalPagesEstimated, 'repeated pass is 100% idempotent');
      const audit2 = verifyTemplateEditorialGeometry(documentRoot);
      assert.equal(audit2.passed, true);
    } finally {
      env.restoreGlobals();
    }
  });

  it('4. Emergency atomic split (.allow-emergency-split), colon-heuristic list intro, and framed vs unframed .is-page-bottom padding preservation', async () => {
    const { normalizeEditorialGeometry, verifyTemplateEditorialGeometry } = await import('../../pdf-engine.js');
    const env = createMockEditorialDom({ template: 'default' });
    env.installGlobals();
    try {
      const { doc, documentRoot, mockWindow } = env;

      // 1. Oversized atomic block (> 100% of blank page usable height ~834px) -> gets .allow-emergency-split
      const giantCallout = doc.createElement('div');
      giantCallout.className = 'callout-box';
      giantCallout.textContent = 'Bloco atômico maior que uma página inteira.';
      giantCallout.setBoxMetrics({
        height: 1100,
        marginTop: 0,
        marginBottom: 16,
        paddingTop: 16,
        paddingBottom: 16,
        borderBottomWidth: 1,
        backgroundColor: '#f8fafc',
      });
      documentRoot.appendChild(giantCallout);

      // 2. Colon-terminated paragraph immediately preceding a list -> treated as list-intro
      const colonIntro = doc.createElement('p');
      colonIntro.textContent = 'Observe os itens a seguir:';
      colonIntro.setBoxMetrics({ height: 24, marginTop: 12, marginBottom: 8 });
      const ul = doc.createElement('ul');
      for (let i = 0; i < 4; i++) {
        const li = doc.createElement('li');
        li.textContent = `Item ${i + 1}`;
        li.setBoxMetrics({ height: 40, marginTop: 4, marginBottom: 4 });
        ul.appendChild(li);
      }
      documentRoot.appendChild(colonIntro);
      documentRoot.appendChild(ul);

      // 3. Framed terminal box at end of document -> gets .is-page-bottom AND .is-framed-box (preserving paddingBottom: 16px)
      const terminalCard = doc.createElement('div');
      terminalCard.className = 'metric-card';
      terminalCard.setBoxMetrics({
        height: 120,
        marginTop: 12,
        marginBottom: 24,
        paddingTop: 16,
        paddingBottom: 16,
        borderBottomWidth: 1,
        backgroundColor: '#ffffff',
      });
      documentRoot.appendChild(terminalCard);

      await normalizeEditorialGeometry(documentRoot, guardrailsConfig);
      assert.equal(giantCallout.classList.contains('allow-emergency-split'), true);
      assert.equal(terminalCard.classList.contains('is-page-bottom'), true);
      assert.equal(terminalCard.classList.contains('is-framed-box'), true);
      assert.equal(parseFloat(mockWindow.getComputedStyle(terminalCard).marginBottom), 0);
      assert.equal(parseFloat(mockWindow.getComputedStyle(terminalCard).paddingBottom), 16, 'framed box keeps internal paddingBottom');

      const audit = verifyTemplateEditorialGeometry(documentRoot);
      assert.equal(audit.passed, true, `Audit errors: ${audit.errors.join('; ')}`);
    } finally {
      env.restoreGlobals();
    }
  });

  it('5. Deliverable D integration: initializeEditorialPagination in editor-core.js and generateEditorialPdf in pdf-generator.js', async () => {
    const { initializeEditorialPagination } = await import('../../static/editor-core.js');
    const { generateEditorialPdf } = await import('../../pdf-generator.js');

    const env = createMockEditorialDom();
    env.installGlobals();
    try {
      const p = env.doc.createElement('p');
      p.textContent = 'Parágrafo de teste';
      p.setBoxMetrics({ height: 80, marginBottom: 16 });
      env.documentRoot.appendChild(p);

      const controller = initializeEditorialPagination(env.documentRoot, 'compact-technical');
      assert.equal(env.documentRoot.getAttribute('data-template'), 'compact-technical');
      assert.equal(typeof globalThis.window.normalizeEditorialGeometry, 'function');

      const switchRes = await controller.setTemplate('landscape-dossier');
      assert.equal(switchRes.templateId, 'landscape-dossier');
      assert.equal(switchRes.resolvedGeometry.orientation, 'landscape');

      // Test generateEditorialPdf with a mock Puppeteer page
      let pdfCallArgs = null;
      let mediaType = null;
      const fakePage = {
        async emulateMediaType(m) { mediaType = m; },
        async evaluateHandle() { return {}; },
        async evaluate(fn, cfg, opts) {
          return await fn(cfg, opts);
        },
        async pdf(opts) {
          pdfCallArgs = opts;
          return Buffer.from('%PDF-1.4 mock');
        },
      };

      const pdfBuf = await generateEditorialPdf(fakePage, '/tmp/out.pdf', { templateId: 'landscape-dossier' });
      assert.ok(Buffer.isBuffer(pdfBuf));
      assert.equal(mediaType, 'print');
      assert.equal(pdfCallArgs.landscape, true);
      assert.equal(pdfCallArgs.preferCSSPageSize, true);
      assert.deepEqual(pdfCallArgs.margin, { top: '0mm', right: '0mm', bottom: '0mm', left: '0mm' });
    } finally {
      env.restoreGlobals();
    }
  });
});
