// M4 — a stranded-heading deferral must terminate the replan loop.
//
// The stranded-heading defect (5 corpus cases, G19) lives in
// `GalleyEngine._continuousFill`: the progress guarantee places the item that
// OPENS a column unconditionally, so a heading that opens a column is placed
// alone and its body starts the next column. Fixing the engine is necessary but
// NOT sufficient, and the reason is written in that function's own doc comment:
//
//   "Deferring it here instead is not a local fix: the caller's replan loop
//    cannot distinguish a partition that came back short by deferral from one
//    that came back short by capacity, and retries it identically."
//
// That is measurable, and this gate measures it. The compiler's region loop
// (`geometry-compiler.js:1946`, `for (;;)` spanning ~189 lines) has no iteration
// cap: it only ever shrinks `bite` and re-plans, and escapes via `break` on
// the fit test at :2121, the page-break branches, or `break regions` on
// `pageBreak`. When the engine defers a lone heading, `col2` comes back empty,
// both column heights measure 0, the fit test at :2070 PASSES, and the loop
// exits through the normal path — or, with the heading deferred, the region is
// never satisfied and it spins.
//
// MEASURED 2026-09-29 on the naive engine-only fix (defer a lone heading that
// cannot get its clearance): the corpus census went from 2.2s to 3m13s at 97%
// CPU. An infinite loop, not slow rendering. So the engine fix ALONE ships a
// hang, and the regression this gate exists to prevent is not "a stranded
// heading comes back" but "the pipeline stops terminating".
//
// THE ORACLE: run the real pipeline over the corpus and assert it terminates
// within a budget. At HEAD this is green (2.2s); with the naive engine fix it
// is RED by timeout. That makes it a discriminating gate for the SHAPE of the
// fix, not just its presence — an engine-only fix fails it.
//
// It is deliberately not a timing assertion on a fast path: a fixed sleep
// budget would be machine-dependent. Instead the test spawns a child with a
// hard timeout and fails on the exit code, so a hang is a clean failure rather
// than a wedged suite.
import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { readFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { corpusPath, readCorpus } from '../corpus/index.js';

const here = dirname(fileURLToPath(import.meta.url));
const repo = join(here, '..', '..');

const DOCS = [
  'sample1.md', 'sample2.md', 'sample3.md',
  'sample4.md', 'text-test.md', 'taskfiles/sampletext2.md',
];

// The hang is NOT corpus-wide. Measured 2026-09-29 with the naive engine fix
// over all 18 doc/template combinations: 16 terminate in 270-740ms, and exactly
// two spin until killed — `taskfiles/sampletext2.md` on `bauhaus` and on
// `bauhaus_minimalist`. Both are among the G19 stranded cases. So the gate
// probes a case that is KNOWN to hang, not a convenient one; probing
// `sample4.md/base` (my first choice) stayed green in both arms and proved
// nothing.
const PROBES = [
  ['taskfiles/sampletext2.md', 'bauhaus'],
  ['taskfiles/sampletext2.md', 'bauhaus_minimalist'],
];

// Generous on purpose: each combination takes 270-740ms when it terminates. A
// hang runs for minutes. The budget only has to separate those two regimes and
// must not flake on a loaded machine. It is 20s per combination, 2 of them.
const PER_PROBE_MS = 20000;


describe('M4 — a stranded-heading deferral must not spin the replan loop', () => {
  for (const [doc, tpl] of PROBES) {
    it(`the pipeline terminates on ${doc}/${tpl} (${PER_PROBE_MS}ms budget)`, () => {
      const child = `
        import { readFileSync } from 'node:fs';
        import { runPipeline } from ${JSON.stringify(join(repo, 'src/v2/runtime/pipeline.js'))};
        const md = readFileSync(${JSON.stringify(corpusPath(doc))}, 'utf-8');
        const r = await runPipeline({
          payload: { title: 'M4', template: ${JSON.stringify(tpl)}, blocks: [{
            title: 'B', markdown: md, masthead: { enabled: false },
            flags: { autofix: true, optimize_tables: true, split_equations: true }, columns: null,
          }] },
          mode: 'paginate', timestamp: 1700000000000, seed: 'stranded-census',
        });
        process.stdout.write('PAGES ' + r.displayList.pages.length);
      `;
      // Run as a real child so a hang is a killed process with a non-zero exit
      // code, not a wedged test runner. A swallowed exception in runPipeline
      // would otherwise read as success (see item 12 in the skill).
      const res = spawnSync(process.execPath, ['--input-type=module', '-e', child], {
        encoding: 'utf-8', timeout: PER_PROBE_MS, cwd: repo,
      });
      assert.notEqual(
        res.signal, 'SIGTERM',
        `the pipeline did not terminate within ${PER_PROBE_MS}ms on `
        + `${doc}/${tpl} — the replan loop is spinning. Deferring a lone `
        + `heading in _continuousFill is necessary but the caller's replan `
        + `must also recognise a deferral-short partition and break.`,
      );
      assert.equal(
        res.status, 0,
        `the pipeline exited ${res.status} (${res.signal || 'no signal'}) on `
        + `${doc}/${tpl}.\n${(res.stderr || '').slice(-1200)}`,
      );
      assert.match(res.stdout || '', /PAGES \d+/, 'the pipeline produced a display list');
    });
  }

  it('the corpus probe documents every input it reads', () => {
    // Non-vacuity: a corpus that silently shrinks passes the timing gate for
    // the wrong reason. Assert the document set is what the engine sees.
    assert.ok(DOCS.length >= 6, 'the corpus list is intact');
    for (const d of DOCS) {
      assert.ok(
        readCorpus(d).length > 0,
        `${d} is present and non-empty`,
      );
    }
  });
});
