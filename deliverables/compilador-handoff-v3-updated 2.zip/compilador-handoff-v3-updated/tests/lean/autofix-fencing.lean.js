/**
 * Autofix fencing (assessment bugs 5+6: critical/major).
 *
 *  G-fence1 — inline code spans are byte-identical after autofix:
 *  `` `a -> b` `` keeps its arrow and backticks.
 *
 *  G-fence2 — absolute URLs are byte-identical after autofix:
 *  query-string operators (`<=`, `->`) survive.
 *
 *  G-fence3 — fencing is selective: prose outside fences still converts.
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { TypographicAutofix } from '../../src/v2/ingest/sanitizer.js';

const apply = (s) => TypographicAutofix.apply(s, true);

describe('autofix fencing', () => {
  it('G-fence1: code spans untouched', () => {
    assert.equal(apply('`a -> b`'), '`a -> b`');
    assert.equal(apply('`x <= y` and `if (a>=b) {}`'), '`x <= y` and `if (a>=b) {}`');
  });

  it('G-fence2: URLs untouched', () => {
    assert.equal(apply('see http://x.com/?a<=b&c>=d'), 'see http://x.com/?a<=b&c>=d');
    assert.equal(apply('go http://x.com/a->b now'), 'go http://x.com/a->b now');
  });

  it('G-fence3: prose outside fences still converts', () => {
    assert.equal(apply('`x` -> `y`'), '`x` → `y`');
    assert.equal(apply('a -> `b` ok'), 'a → `b` ok');
  });

  it('G-fence4: no PUA sentinel ever leaks into output', () => {
    const LEAK = /[\uE000-\uE0FF]/u;
    const samples = [
      '`a -> b` and x -> y',
      'snake\\_case and file\\_2 ok',
      'Grupo $10\\text{ a }100$ com $50\\%$ e $x_2$ fora `code $y$`',
      'see http://x.com/?a<=b and $$F = 2$$ done',
    ];
    for (const s of samples) {
      assert.ok(!LEAK.test(apply(s)), `sentinel leaked for ${JSON.stringify(s)}`);
    }
  });
});
