/**
 * Math-span fencing (user report: dollars leaking around \text{}/\% math).
 *
 *  Root cause: whole-block autofix runs BEFORE the `$…$` gate, so
 *  `$10\text{ a }100$` becomes `$10 a 100$` and looksLikeMath sees plain
 *  text → literal dollars. Fencing math-gated spans first preserves the
 *  TeX evidence the gate needs.
 *
 *  G-mathfence1 — `$10\text{ a }100$` renders as math, no literal dollars.
 *  G-mathfence2 — `$50\%$` renders as math containing `50%`.
 *  G-mathfence3 — display `$$F = 2$$` still parses as display math
 *  (the `$$` exclusion guard).
 *  G-mathfence4 — currency `$100 and $50` stays literal, dollars kept.
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { GeometryCompiler } from '../../src/v2/compiler/geometry-compiler.js';

const compile = (markdown) => new GeometryCompiler().compile(
  { title: 'T', template: 'base', blocks: [{ title: 'A', markdown }] }, {},
);

const textsOf = (dl) => dl.pages
  .flatMap((p) => p.elements || [])
  .filter((e) => e.type === 'text')
  .map((e) => e.text || '');

const mathRunTexts = (dl) => dl.pages
  .flatMap((p) => p.elements || [])
  .filter((e) => e.type === 'text')
  .flatMap((e) => e.runs || [])
  .filter((r) => String(r.style || '').includes('math'))
  .map((r) => r.text || '');

describe('math-span fencing', () => {
  it('G-mathfence1: \\text math survives autofix as math', () => {
    const dl = compile('Grupo $10\\text{ a }100$ voluntários.');
    const texts = textsOf(dl);
    assert.ok(
      !texts.some((t) => t.includes('$')),
      `literal dollars leaked: ${JSON.stringify(texts)}`,
    );
    assert.ok(
      mathRunTexts(dl).some((t) => t.includes('10 a 100')),
      `math interior lost: ${JSON.stringify(texts)}`,
    );
  });

  it('G-mathfence2: \\% math survives autofix as math', () => {
    const dl = compile('Evasão parcial ($50\\%$) da via.');
    assert.ok(
      mathRunTexts(dl).some((t) => t.includes('50%')),
      `percent math lost: ${JSON.stringify(textsOf(dl))}`,
    );
    assert.ok(
      !textsOf(dl).some((t) => t.includes('$')),
      `literal dollars leaked: ${JSON.stringify(textsOf(dl))}`,
    );
  });

  it('G-mathfence3: display $$ blocks unaffected', () => {
    const dl = compile('$$F = 2$$');
    const fonts = dl.pages
      .flatMap((p) => p.elements || [])
      .filter((e) => e.type === 'text')
      .map((e) => e.font);
    assert.ok(fonts.includes('courier'), `display math lost: ${JSON.stringify(fonts)}`);
  });

  it('G-mathfence4: currency pairs stay literal', () => {    const dl = compile('price $100 and $50 each');
    const texts = textsOf(dl);
    assert.ok(
      mathRunTexts(dl).length === 0,
      `currency math-styled: ${JSON.stringify(mathRunTexts(dl))}`,
    );
    assert.equal(
      texts.join('').replace(/[^$]/g, '').length, 2,
      `dollars lost: ${JSON.stringify(texts)}`,
    );
  });

  it('G-mathfence5: bracket intervals read as math', () => {
    const dl = compile('Faixa $[CME, CMT]$ delimitada.');
    assert.ok(
      mathRunTexts(dl).some((t) => t.includes('[CME, CMT]')),
      `interval not math: ${JSON.stringify(textsOf(dl))}`,
    );
    assert.ok(
      !textsOf(dl).some((t) => t.includes('$')),
      `literal dollars leaked: ${JSON.stringify(textsOf(dl))}`,
    );
  });
});
