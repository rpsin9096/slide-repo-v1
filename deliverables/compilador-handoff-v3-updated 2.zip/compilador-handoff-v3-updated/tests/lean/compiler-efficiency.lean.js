/**
 * Wave 12 — Compiler & Cloudflare Worker Efficiency Regression Suite
 *
 * Verifies W12.1..W12.6:
 *   W12.1: Trigger-indexed parseInlineRuns speed & exactness
 *   W12.2: Compiled alternation TypographicAutofix speed & fencing invariants
 *   W12.3: Single-pass wrapRunsToLines token width & space memoization (<= 6000 calls on sample1.md)
 *   W12.4: 3-Tier Incremental Compiler Cache (DISPLAY_LIST_CACHE, BLOCK_FLOW_CACHE, BLOCK_ITEMS_CACHE)
 *   W12.5: Zero-overhead default TelemetryBus / EngineEventBus & WeakMap countCommands
 *   W12.6: Cloudflare Worker /api/paginate X-Cache HIT/MISS & O(1) virtual-fs lookup
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { performance } from 'node:perf_hooks';
import { TypographicAutofix, TagSanitizer } from '../../src/v2/ingest/sanitizer.js';
import { calculateStringWidth, getFontMetrics } from '../../src/v2/fonts/metrics.js';
import { GeometryCompiler, parseInlineRuns, wrapRunsToLines } from '../../src/v2/compiler/geometry-compiler.js';
import { createMeasureContext } from '../../src/v2/drivers/pdfkit/blaster.js';
import { countCommands } from '../../src/v2/core/display-list.js';
import { runPipeline } from '../../src/v2/runtime/pipeline.js';
import worker from '../../src/_worker.js';

const s1 = fs.readFileSync('tests/corpus/sample1.md', 'utf8');
const s2 = fs.readFileSync('tests/corpus/sample2.md', 'utf8');
const s3 = fs.readFileSync('tests/corpus/sample3.md', 'utf8');
const s4 = fs.readFileSync('tests/corpus/sample4.md', 'utf8');

test('W12.1: Trigger-indexed parseInlineRuns preserves exact run semantics and fast-paths plain text', () => {
  const plain = parseInlineRuns('Texto simples sem marcadores inline de formatação.');
  assert.deepEqual(plain, [{ text: 'Texto simples sem marcadores inline de formatação.', style: 'normal' }]);

  const styled = parseInlineRuns('Início **negrito e *itálico* interno** com `código`, ~~riscado~~, $R$ 50 e $\\alpha + x_1^2$.');
  assert.ok(styled.some((r) => r.style === 'bold' && r.text.includes('negrito')));
  assert.ok(styled.some((r) => r.style === 'bold_italic' && r.text === 'itálico'));
  assert.ok(styled.some((r) => r.style === 'code' && r.text === 'código'));

  const lines = s1.split('\n').filter((l) => l.trim());
  // Warmup
  for (const l of lines) parseInlineRuns(l);
  const t0 = performance.now();
  for (const l of lines) parseInlineRuns(l);
  const dt = performance.now() - t0;
  assert.ok(dt < 15, `Expected parseInlineRuns on sample1.md < 15ms, got ${dt.toFixed(2)}ms`);
});

test('W12.2: Compiled TypographicAutofix preserves code/URL fencing, math symbols, and particle ties', () => {
  const raw = 'Em `a -> b` e https://example.com/a_1->b o código fica intacto, mas fora: a -> b, H_2O, 10^3, \\alpha <= \\beta, Art. 5 e 10 mg de sal.';
  const fixed = TypographicAutofix.apply(raw, true);
  assert.ok(fixed.includes('`a -> b`'), 'Inline code must remain untouched');
  assert.ok(fixed.includes('https://example.com/a_1->b'), 'URL must remain untouched');
  assert.ok(fixed.includes('H₂O') && fixed.includes('10³') && fixed.includes('α ≤ β'), 'Math and chemistry symbols must normalize');
  assert.ok(fixed.includes('Art.\u00A05') && fixed.includes('10\u00A0mg') && fixed.includes('de\u00A0sal'), 'Particles and units must tie with NBSP');

  const w1 = calculateStringWidth('Relatório Editorial — 2026 “Teste” • Item', 'helvetica', 9.5);
  assert.ok(w1 > 100 && Number.isFinite(w1));
  const m1 = getFontMetrics('arimo', 9.5);
  const m2 = getFontMetrics('arimo', 9.5);
  assert.equal(m1, m2, 'getFontMetrics should return cached frozen record for string font keys');
});

test('W12.3: Single-pass wrapRunsToLines eliminates duplicate word width measurements', () => {
  const ctx = createMeasureContext('base', null);
  let calls = 0;
  const countingMeasure = (w, f, s) => {
    calls += 1;
    return ctx.measure(w, f, s);
  };
  const gc = new GeometryCompiler();
  const dl = gc.compile(
    { markdown: s1, title: 'S1' },
    { geometry: 'v3', measure: countingMeasure, skip_fit_audit: true, bypassCache: true }
  );
  assert.equal(dl.totalPages, 7);
  assert.ok(calls <= 6000, `Expected <= 6000 measure() calls on sample1.md (was 10926), got ${calls}`);
});

test('W12.4: 3-Tier Incremental Compiler Cache reuses DisplayLists and finalized frozen block pages', async () => {
  const multiPayload = {
    title: 'Incremental Suite',
    template: 'base',
    geometry: 'v3',
    sections: [
      { title: 'S1', markdown: s1 },
      { title: 'S2', markdown: s2 },
      { title: 'S3', markdown: s3 },
      { title: 'S4', markdown: s4 },
    ],
  };

  // 1. Uncached full compile (populates BLOCK_ITEMS_CACHE, BLOCK_FLOW_CACHE, DISPLAY_LIST_CACHE)
  const tCold0 = performance.now();
  const fullUncached = await runPipeline({
    payload: multiPayload,
    mode: 'paginate',
    geometry: 'v3',
    options: { skip_fit_audit: true, bypassCache: true },
  });
  const coldMs = performance.now() - tCold0;

  // 2. Exact DisplayList cache hit
  const tHit0 = performance.now();
  const fullCached = await runPipeline({
    payload: multiPayload,
    mode: 'paginate',
    geometry: 'v3',
    options: { skip_fit_audit: true },
  });
  const hitMs = performance.now() - tHit0;
  assert.equal(fullUncached.displayList, fullCached.displayList, 'DISPLAY_LIST_CACHE must return identical frozen reference');
  assert.ok(hitMs < 10, `Expected DISPLAY_LIST_CACHE hit < 10ms, got ${hitMs.toFixed(2)}ms`);

  // 3. Incremental edit of Section 4 (Sections 1..3 reuse finalized frozen pages from BLOCK_FLOW_CACHE)
  const editedPayload = {
    ...multiPayload,
    sections: [
      multiPayload.sections[0],
      multiPayload.sections[1],
      multiPayload.sections[2],
      { title: 'S4', markdown: s4 + '\n\nNovo parágrafo incremental no final da seção 4.' },
    ],
  };
  const tInc0 = performance.now();
  const incCompiled = await runPipeline({
    payload: editedPayload,
    mode: 'paginate',
    geometry: 'v3',
    options: { skip_fit_audit: true },
  });
  const incMs = performance.now() - tInc0;

  // Verify that pages 0..19 of incCompiled are the exact frozen page references from fullUncached
  assert.equal(incCompiled.displayList.pages[0], fullUncached.displayList.pages[0]);
  assert.equal(incCompiled.displayList.pages[10], fullUncached.displayList.pages[10]);
  assert.ok(incMs < coldMs * 0.55, `Expected incremental compile (${incMs.toFixed(2)}ms) < 55% of full uncached compile (${coldMs.toFixed(2)}ms)`);

  // Verify 100% parity against compiling editedPayload from scratch with bypassCache: true
  const editedScratch = await runPipeline({
    payload: editedPayload,
    mode: 'paginate',
    geometry: 'v3',
    options: { skip_fit_audit: true, bypassCache: true },
  });
  assert.equal(incCompiled.totalPages, editedScratch.totalPages);
  assert.equal(incCompiled.displayList.metadata.elementCount, editedScratch.displayList.metadata.elementCount);
  assert.deepEqual(incCompiled.pagination, editedScratch.pagination);
  assert.deepEqual(incCompiled.displayList.diagnostics.justify, editedScratch.displayList.diagnostics.justify);
});

test('W12.5: TelemetryBus skips process.memoryUsage by default and countCommands memoizes frozen IR', async () => {
  const resDefault = await runPipeline({
    payload: { markdown: s4, title: 'Telemetry Test', geometry: 'v3' },
    mode: 'paginate',
    geometry: 'v3',
    options: { skip_fit_audit: true },
  });
  assert.ok(resDefault.telemetry.stages.every((s) => s.memoryDeltaBytes === 0));

  const c1 = countCommands(resDefault.displayList);
  const c2 = countCommands(resDefault.displayList);
  assert.equal(c1, c2, 'countCommands must return WeakMap-memoized result on frozen DisplayList');
});

test('W12.6: Cloudflare Worker /api/paginate sets X-Cache MISS then HIT', async () => {
  const body = JSON.stringify({
    title: 'Worker Paginate Cache Test',
    template: 'base',
    geometry: 'v3',
    sections: [{ title: 'Cap 1', markdown: '# Título\n\nParágrafo de teste para o Cloudflare Worker.' }],
  });
  const req1 = new Request('https://example.com/api/paginate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body,
  });
  const res1 = await worker.fetch(req1, {}, {});
  assert.equal(res1.status, 200);
  assert.equal(res1.headers.get('X-Cache'), 'MISS');
  const json1 = await res1.json();
  assert.equal(json1.success, true);
  assert.equal(json1.totalPages, 1);

  const req2 = new Request('https://example.com/api/paginate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body,
  });
  const res2 = await worker.fetch(req2, {}, {});
  assert.equal(res2.status, 200);
  assert.equal(res2.headers.get('X-Cache'), 'HIT');
  const json2 = await res2.json();
  assert.equal(json2.totalPages, 1);
});
