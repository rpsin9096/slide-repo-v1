/**
 * Band-structure gate — column TOP alignment, measured on rendered PDFs.
 *
 * The page is a stack of bands; each band's two columns hang from the same
 * band top. The reader-visible corruption this gate pins: a band whose right
 * column starts hundreds of points below the left one — content pinned at
 * the foot of an empty column (the sampletext/base p2 defect: col2's first
 * line 631pt below col1's, above it a void) or a degenerate pre-span band
 * (sampletext2/bauhaus p3: col1 = one 30pt heading, col2 = 107.8pt).
 *
 * WHY A SEPARATE GATE: `column-foot.lean.js` measured `Math.max` of
 * bottom-up glyph y and documented it as the FOOT — but in bottom-up space
 * max y is the TOPMOST ink, so that suite was (unknowingly) asserting top
 * alignment, and only on its own fixture set, which excludes
 * `taskfiles/sampletext.md` — the very document that regressed. This gate
 * states the top-alignment invariant outright, on the full corpus, with a
 * per-page bound (a mean hides a 631pt page).
 *
 * Coordinate convention: `decodePdfRuns` returns PDF user-space positions,
 * BOTTOM-UP (y grows toward the page top). The column TOP of body text is
 * therefore the MAXIMUM body y; the chrome band `20 < y < H-60` drops the
 * folio and the running head, the same window `column-foot.lean.js` uses.
 *
 * Bound: 60pt — one heading-run clearance. Both columns of a band start at
 * the same band top, so legitimate top offsets come only from item
 * granularity inside the first line of each column; measured corpus
 * (2026-09-30, 92 pages): every healthy page is <= 24pt, the three defect
 * pages are 78.85 / 86.58 / 630.99pt.
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { corpusPath, readCorpus } from '../corpus/index.js';
import { runPipeline } from '../../src/v2/runtime/pipeline.js';
import { decodePdfRuns } from '../../scripts/pdf-text-runs.mjs';

const here = dirname(fileURLToPath(import.meta.url));
const repo = join(here, '..', '..');
const SEED = 'band-structure';
const TIMESTAMP = 1700000000000;

const TOP_MAX_PT = 60;

const FIXTURES = [
  'sample1.md', 'sample2.md', 'sample3.md', 'text-test.md',
  'taskfiles/sampletext.md', 'taskfiles/sampletext2.md',
];
const TEMPLATE_IDS = ['base', 'bauhaus', 'bauhaus_minimalist'];

const presentFixtures = () => FIXTURES.filter((f) => {
  try { readCorpus(f); return true; } catch { return false; }
});

const docOf = (markdown, template) => ({
  title: 'BandStructure',
  template,
  blocks: [{
    title: 'A',
    markdown,
    masthead: { enabled: false },
    flags: { autofix: true, optimize_tables: true, split_equations: true },
    columns: null,
  }],
});

const r2 = (v) => Math.round(v * 100) / 100;

/**
 * Per-page body-text TOP offset between the two columns. A page is counted
 * only when BOTH columns carry body text — the single-column page has its
 * own assertion below. Bottom-up space: top of body = max y.
 */
const measureTops = async (md, template) => {
  const { buffer } = await runPipeline({
    payload: docOf(md, template), mode: 'pdf', seed: SEED, timestamp: TIMESTAMP,
  });
  assert.ok(buffer && buffer.length > 1000, `pdf rendered [${template}]`);
  const pages = decodePdfRuns(buffer);
  const rows = [];
  pages.forEach(({ W, H, runs }, i) => {
    const body = runs.filter((p) => p.y > 20 && p.y < H - 60);
    const left = body.filter((p) => p.x < W / 2).map((p) => p.y);
    const right = body.filter((p) => p.x >= W / 2).map((p) => p.y);
    if (!left.length || !right.length) return;
    rows.push({
      page: i + 1,
      ofPages: pages.length,
      isLast: i === pages.length - 1,
      topPt: r2(Math.abs(Math.max(...left) - Math.max(...right))),
    });
  });
  return rows;
};

describe('band structure — both columns of a band start at the band top', () => {
  it('no page starts its right column more than one heading-run below its left', async () => {
    const offenders = [];
    let measured = 0;
    for (const f of presentFixtures()) {
      const md = readCorpus(f);
      for (const template of TEMPLATE_IDS) {
        for (const row of await measureTops(md, template)) {
          measured++;
          if (row.topPt > TOP_MAX_PT) {
            offenders.push(`${f}/${template} p${row.page}/${row.ofPages} = ${row.topPt}pt`);
          }
        }
      }
    }
    assert.ok(measured >= 40, `measured ${measured} two-column pages, expected >= 40`);
    assert.deepEqual(
      offenders.sort((a, b) => parseFloat(b.split('=')[1]) - parseFloat(a.split('=')[1])),
      [],
      `${offenders.length} pages with a column top offset over ${TOP_MAX_PT}pt: ${offenders.join('; ')}`,
    );
  });

  it('no mid-document page leaves the right column empty while the left ends early', async () => {
    // The other half of the band-structure invariant: a page whose right
    // column carries no body text at all while the left column stops well
    // above the foot and the document continues — the collapsed-region
    // shape (one used column, the rest of the page void). The last page of
    // a document is exempt: a ragged tail ending in one column is honest.
    const offenders = [];
    for (const f of presentFixtures()) {
      const md = readCorpus(f);
      for (const template of TEMPLATE_IDS) {
        const { buffer } = await runPipeline({
          payload: docOf(md, template), mode: 'pdf', seed: SEED, timestamp: TIMESTAMP,
        });
        const pages = decodePdfRuns(buffer);
        pages.forEach(({ W, H, runs }, i) => {
          if (i === pages.length - 1) return;
          const body = runs.filter((p) => p.y > 20 && p.y < H - 60);
          const left = body.filter((p) => p.x < W / 2).map((p) => p.y);
          const right = body.filter((p) => p.x >= W / 2).map((p) => p.y);
          if (!left.length || right.length > 0) return;
          // Left column ends > 90pt above the body band's floor: the page
          // was abandoned, not filled. 90pt = one heading-run clearance plus
          // slack, so an honest final flush (foot at the band floor) passes.
          if (Math.min(...left) - 20 > 90) {
            offenders.push(`${f}/${template} p${i + 1}/${pages.length} (left foot ${r2(Math.min(...left))}pt above band floor)`);
          }
        });
      }
    }
    assert.deepEqual(offenders, [],
      `pages with an empty right column and an early left foot: ${offenders.join('; ')}`);
  });

  it('compact tables + flush off: the pre-table region does not collapse to one column', async () => {
    // Regression lock for the 2026-10-03 user report (taskfiles/2):
    // a compact (column-width) table section — heading lead-in at col1's
    // foot, its table opening col2 — collapsed the whole region when the
    // column-boundary keep-with-next block peeled the lead-in heading and
    // the continuous-mode replan emptied col2 (page 4: col1 ending 175pt
    // early, col2 100% void, the table pushed to the next page). The
    // workspace payload behind the report: table_layout_mode 'compact'
    // (tables forced column-width, never panoramic spans), flush_columns
    // off (no vertical justification), bauhaus, empty masthead course.
    // Asserts the structural invariant on the reported page shape: no
    // mid-document page may carry an empty right column while the left
    // ends early.
    let md;
    try { md = readCorpus('taskfiles/2/sampletext.md'); } catch { return; }
    const payload = {
      title: 'Material de Teste do Corpus',
      template: 'bauhaus',
      header_text: '', header_position: 'top', show_header_top: true,
      header_date: { enabled: true, format: 'dd/mm/yyyy', custom_value: null },
      clean_spans: true, alignment: 'justify', raggedright: false,
      loose_line_guard: true, balance_columns: false, split_list_items: false,
      flush_columns: false, chapters_toc: false, toc_include_headings: true,
      table_layout_mode: 'compact', column_layout: 2, columns: 2,
      image_captions_enabled: false,
      sections: [{
        index: 1, id: 's1', name: 'Seção 1', title: 'A', markdown: md,
        autofix: true, optimize_tables: true, split_equations: true,
        enable_masthead: true, masthead_header: true, masthead_prefix: '',
        masthead_course: '', masthead_topic: '',
        masthead: { enabled: true, prefix: '', course: '', topic: '', header: true },
        table_layout: null, tableLayout: null,
        table_rotation_direction: 'cw', tableRotationDirection: 'cw',
        columns: null, column_layout: null,
      }],
    };
    const { buffer } = await runPipeline({
      payload, mode: 'pdf', seed: SEED, timestamp: TIMESTAMP,
    });
    const pages = decodePdfRuns(buffer);
    const offenders = [];
    pages.forEach(({ W, H, runs }, i) => {
      if (i === pages.length - 1) return;
      const body = runs.filter((p) => p.y > 20 && p.y < H - 60);
      const left = body.filter((p) => p.x < W / 2).map((p) => p.y);
      const right = body.filter((p) => p.x >= W / 2).map((p) => p.y);
      if (!left.length || right.length > 0) return;
      if (Math.min(...left) - 20 > 90) {
        offenders.push(`p${i + 1}/${pages.length} (left foot ${r2(Math.min(...left))}pt above band floor)`);
      }
    });
    assert.deepEqual(offenders, [],
      `compact-table collapse pages: ${offenders.join('; ')}`);
    // Caption-pair invariant: the table lead-in heading and its table must
    // share a column, the heading directly above the table. The 2026-10-03
    // report's shapes both separated the pair: the lead-in at col1's foot
    // with the table opening col2, and the doc-tail balancer splitting
    // [heading | table] across both columns of the last page.
    const lead = pages.flatMap(({ W, runs }, i) => runs
      .filter((p) => /Diagn.stico diferencial de pigmenturia/.test(p.text))
      .map((p) => ({ page: i + 1, x: p.x, y: p.y, W })));
    assert.ok(lead.length >= 1, 'lead-in heading found in the render');
    const pairOffenders = [];
    for (const h of lead) {
      const { W, H, runs } = pages[h.page - 1];
      const sameColRuns = runs.filter((p) => (p.x < W / 2) === (h.x < W / 2)
        && p.y < h.y && p.y > 20);
      // The table's header row must sit directly under the heading, same
      // column: within 60pt below (one heading-run clearance).
      // The table's header row arrives as per-cell runs; "biomarcador" is
      // the lead cell text of this table's header row.
      const tableHead = runs.find((p) => (p.x < W / 2) === (h.x < W / 2)
        && /biomarcador/.test(p.text));
      if (!tableHead) { pairOffenders.push(`p${h.page}: table not found near lead-in`); continue; }
      if (Math.abs(tableHead.y - h.y) > 60) {
        pairOffenders.push(`p${h.page}: lead-in ${Math.round(h.y)}pt vs table head ${Math.round(tableHead.y)}pt — pair separated`);
      }
    }
    assert.deepEqual(pairOffenders, [],
      `lead-in heading separated from its table: ${pairOffenders.join('; ')}`);
  });
});
