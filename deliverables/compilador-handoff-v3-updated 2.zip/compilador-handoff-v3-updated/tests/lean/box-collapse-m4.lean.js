import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

/* M4 box-collapse fade parity: Recolher stops snapping via the same honest
 * two-phase as the W6 config accordion — .is-closing fades opacity, .hidden
 * lands after. No height animation claimed (multi-child flex, no wrapper).
 * Run: node --test tests/lean/box-collapse-m4.lean.js */

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..');
const src = (p) => readFileSync(join(root, p), 'utf8');

const blockOf = (css, selector) => {
  const esc = selector.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const m = new RegExp('(^|\\n)[ \\t]*' + esc + ' \\{', 'm').exec(css);
  assert.ok(m, `missing rule: ${selector}`);
  const open = css.indexOf('{', m.index);
  const close = css.indexOf('}', open);
  return css.slice(open + 1, close);
};

describe('M4 — box collapse fades, never snaps', () => {
  it('closing state fades without hiding', () => {
    const b = blockOf(src('static/design-system.css'), '.box-body.is-closing');
    assert.ok(b.includes('opacity: 0'), `expected fade, got: ${b.trim()}`);
    assert.ok(!b.includes('display'), `must not hide mid-transition, got: ${b.trim()}`);
  });

  it('box-body owns an opacity transition', () => {
    const b = blockOf(src('static/design-system.css'), '.box-body');
    assert.ok(b.includes('opacity'), `expected opacity transition, got: ${b.trim()}`);
  });

  it('JS drives the cancellable two-phase close', () => {
    assert.ok(src('static/v2-app.js').includes('_bodyCloseT'), 'pending close cancellable');
  });

  it('guards: flex layout untouched', () => {
    const b = blockOf(src('static/design-system.css'), '.box-body');
    assert.ok(b.includes('display: flex'), 'body stays flex column');
  });
});
