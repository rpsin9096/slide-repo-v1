import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { runPipeline } from '../../src/v2/runtime/pipeline.js';
import { TEMPLATES } from '../../src/v2/templates/definitions.js';
import { PAGE_SIZES } from '../../src/v2/core/geometry.js';

const SEED = 'terminal-balance';
const TIMESTAMP = 1700000000000;
const tmpl = TEMPLATES.bauhaus;
const { width: A4W, height: A4H } = PAGE_SIZES.A4;
const colW = (A4W - tmpl.margins.left - tmpl.margins.right - tmpl.columnsep) / 2;
const col1Left = tmpl.margins.left + colW + tmpl.columnsep;
const contentBottomY = A4H - tmpl.margins.bottom - tmpl.footskip;

const body = 'Linha de corpo com palavras suficientes para embrulhar uma coluna estreita do documento compilado.';

const docOf = (blocks, extra) => ({ title: 'Terminal balance', template: 'bauhaus', blocks, ...(extra || {}) });
const blk = (nHead, nPara, tag = 'A') => ({
  title: tag,
  masthead: { enabled: false },
  markdown: Array.from({ length: nHead }, (_, i) => `# Título ${i}\n\n${
    Array.from({ length: nPara }, (_, j) => `Parágrafo ${i}.${j} ${body} ${body}`).join('\n\n')}`).join('\n'),
});

const run = (payload) => runPipeline({ payload, mode: 'paginate', seed: SEED, timestamp: TIMESTAMP })
  .then((r) => r.displayList);

// Visual column feet per page: deepest body-text bottom per column band,
// chrome excluded (anything at or past the content bottom is footer).
const footOf = (dl) => dl.pages.map((page) => {
  let left = -Infinity;
  let right = -Infinity;
  for (const el of (page.elements || [])) {
    if (!el || el.type !== 'text') continue;
    const bottom = (el.y || 0) + (el.size || 10);
    if (bottom > contentBottomY + 0.01) continue;
    if (el.x < col1Left - 1) left = Math.max(left, bottom);
    else right = Math.max(right, bottom);
  }
  return { left: Number.isFinite(left) ? left : null, right: Number.isFinite(right) ? right : null };
});

// "Approximately the same vertical position": the terminal partition is
// item-granular with line-quantized seam splits and elastic glue below it,
// so the residual is bounded by one body line pitch plus trailing parskip
// (item boxes end together; glyphs can sit a parskip higher).
const TAIL_TOL = 14;

describe('terminal column balancing — both columns end together on the last page', () => {
  // v1 multicols parity, extended to the default flow: LaTeX multicol always
  // balances its final page, and the reader reads the even ending as the
  // document closing. Coluna corrida keeps its interior pages full — only
  // the tail widens to the balanced partition, so the last page's two text
  // columns terminate at the same vertical position under every control
  // state (balance on/off, flush on/off, single or multi-block).
  it('coluna corrida: the doc tail balances so both columns end together', async () => {
    const dl = await run(docOf([blk(10, 5)]));
    assert.ok(dl.totalPages >= 2, 'fixture must reach a distinct last page');
    const feet = footOf(dl);
    const last = feet[feet.length - 1];
    assert.ok(last.left != null && last.right != null, 'balanced tail leaves no column empty');
    assert.ok(Math.abs(last.left - last.right) <= TAIL_TOL,
      `tail columns end ${Math.abs(last.left - last.right).toFixed(1)}pt apart`);
    // Interior pages keep the continuous full-foot fill (the void a mid-
    // document balance leaves reads as a broken column).
    for (const f of feet.slice(0, -1)) {
      assert.ok(f.left != null && contentBottomY - f.left <= 32, 'interior col1 keeps running to the foot');
      assert.ok(f.right != null && contentBottomY - f.right <= 32, 'interior col2 keeps running to the foot');
    }
  });

  it('terminal balance is independent of the flush-bottom control', async () => {
    const off = await run(docOf([blk(10, 5)], { flush_columns: false }));
    const last = footOf(off).pop();
    assert.ok(last.left != null && last.right != null, 'flush-off tail still fills both columns');
    assert.ok(Math.abs(last.left - last.right) <= TAIL_TOL,
      `flush-off tail columns end ${Math.abs(last.left - last.right).toFixed(1)}pt apart`);
  });

  it('balance mode keeps terminal parity and continuous never costs a page', async () => {
    const cont = await run(docOf([blk(10, 5)]));
    const bal = await run(docOf([{ ...blk(10, 5), flags: { balance_columns: true } }]));
    assert.equal(cont.totalPages, bal.totalPages, 'terminal balancing redistributes, never repaginates');
    const lastBal = footOf(bal).pop();
    assert.ok(Math.abs(lastBal.left - lastBal.right) <= TAIL_TOL,
      'balance-mode tail stays even (regression)');
  });

  // Multi-block: each block starts on a fresh page, so every block's final
  // region is that block's last page — and every one of them terminates
  // evenly (v1 multicols parity: each block is its own multicols
  // environment, and LaTeX balances each environment's final page).
  it("multi-block: every block's tail balances — section ends are even across the layout", async () => {
    const dl = await run(docOf([blk(22, 5, 'B1'), blk(3, 5, 'B2'), blk(6, 4, 'B3')]));
    const feet = footOf(dl);
    assert.ok(dl.totalPages >= 3, 'block1 must own multiple interior pages');
    // Interior pages (mid-block regions) keep the continuous full-foot fill.
    for (const f of feet.slice(0, -3)) {
      assert.ok(f.left != null && contentBottomY - f.left <= 32, 'interior col1 keeps running to the foot');
      assert.ok(f.right != null && contentBottomY - f.right <= 32, 'interior col2 keeps running to the foot');
    }
    // Every block tail (the last page of each block) ends evenly.
    for (const f of feet.slice(-3)) {
      assert.ok(f.left != null && f.right != null, 'balanced tail leaves no column empty');
      assert.ok(Math.abs(f.left - f.right) <= TAIL_TOL,
        `tail columns end ${Math.abs(f.left - f.right).toFixed(1)}pt apart`);
    }
  });

  // Pathological granularity: a tail of one long paragraph over one short
  // one leaves the item-granular balancer hundreds of points apart. The
  // terminal seam split closes it — the boundary paragraph breaks across
  // the column seam the way multicol does, feet land within one pitch.
  it('long-paragraph tail: the terminal seam split closes the granularity gap', async () => {
    const markdown = Array.from({ length: 8 }, (_, i) => `# Título ${i}\n\n${body} ${body}`).join('\n')
      + '\n\n' + Array.from({ length: 34 }, () => body).join(' ')
      + '\n\n' + `Parágrafo curto ${body}`;
    const dl = await run(docOf([{ title: 'A', masthead: { enabled: false }, markdown }]));
    const last = footOf(dl).pop();
    assert.ok(last.left != null && last.right != null, 'split tail keeps both columns alive');
    assert.ok(Math.abs(last.left - last.right) <= TAIL_TOL,
      `seam-split tail ends ${Math.abs(last.left - last.right).toFixed(1)}pt apart`);
  });

  // Masthead-only trailing block: the banner owns its own page (no columns
  // to balance there), and the text block ahead of it still terminates
  // evenly on its own last page — the banner page never disturbs it.
  it('masthead-only trailing block: the text tail stays even behind a banner page', async () => {
    const dl = await run(docOf([
      blk(10, 5, 'B1'),
      { title: 'Banner', masthead: { enabled: true, course: 'IMAGENOLOGIA', topic: 'P1:' }, markdown: '' },
    ]));
    const feet = footOf(dl);
    const textTail = feet[feet.length - 2];
    assert.ok(textTail.left != null && textTail.right != null, 'balanced text tail keeps both columns alive');
    assert.ok(Math.abs(textTail.left - textTail.right) <= TAIL_TOL,
      `text tail columns end ${Math.abs(textTail.left - textTail.right).toFixed(1)}pt apart`);
  });
});
