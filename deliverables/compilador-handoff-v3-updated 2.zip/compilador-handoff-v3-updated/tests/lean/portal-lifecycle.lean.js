import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {
  uiPortal, menuShelf, closePortalMenus, hidePortalToolbars, purgePortalToolbars,
} from '../../static/editor-core.js';

const cls = () => {
  const s = new Set();
  return {
    add: (c) => s.add(c), remove: (c) => s.delete(c),
    contains: (c) => s.has(c),
    toggle: (c, f) => { if (f === undefined) { if (s.has(c)) s.delete(c); else s.add(c); } else if (f) s.add(c); else s.delete(c); },
  };
};
const mkEl = (tag = 'div') => ({
  tag, id: '', children: [], style: {}, attrs: {}, classList: cls(),
  innerHTML: '', textContent: '',
  setAttribute(k, v) { this.attrs[k] = String(v); },
  getAttribute(k) { return this.attrs[k] ?? null; },
  appendChild(c) { this.children.push(c); return c; },
  remove() { this.removed = true; },
  querySelectorAll() { return []; },
  contains() { return false; },
});
function installFakeDoc() {
  const byId = {};
  const toolbars = [];
  const mkReg = (tag = 'div') => {
    const el = mkEl(tag);
    let _id = '';
    Object.defineProperty(el, 'id', {
      get() { return _id; },
      set(v) { _id = String(v || ''); if (_id) byId[_id] = el; },
      configurable: true,
    });
    const origAppend = el.appendChild.bind(el);
    el.appendChild = (c) => { if (c && c.id) byId[c.id] = c; return origAppend(c); };
    return el;
  };
  globalThis.document = {
    getElementById: (id) => byId[id] || null,
    createElement: (t) => mkReg(t),
    querySelectorAll: (sel) => (String(sel).includes('toolbar') ? toolbars : []),
    addEventListener() {}, removeEventListener() {},
    documentElement: { clientWidth: 1280 },
    body: { appendChild: (el) => { if (el && el.id) byId[el.id] = el; } },
  };
  globalThis.window = { addEventListener() {}, innerHeight: 800 };
  return { byId, toolbars };
}
const uninstall = () => { delete globalThis.document; delete globalThis.window; };

describe('P0 portal lifecycle', () => {
  it('uiPortal creates a single shared layer, aria-hidden=false', () => {
    const { byId } = installFakeDoc();
    try {
      const p1 = uiPortal();
      const p2 = uiPortal();
      assert.equal(p1, p2);
      assert.equal(p1.id, 'ui-portal');
      assert.equal(p1.getAttribute('aria-hidden'), 'false');
      assert.ok(byId['ui-portal']);
    } finally { uninstall(); }
  });

  it('menuShelf creates the dedicated shelf inside the portal', () => {
    installFakeDoc();
    try {
      uiPortal();
      const shelf = menuShelf();
      assert.equal(shelf.id, 'bedit-menu-shelf');
      assert.equal(menuShelf(), shelf);
    } finally { uninstall(); }
  });

  it('closePortalMenus clears the shelf and hides toolbars', () => {
    const { toolbars } = installFakeDoc();
    try {
      uiPortal();
      const shelf = menuShelf();
      shelf.innerHTML = '<div class="bedit-quick-menu portal-open"></div>';
      const bar = mkEl('div');
      bar.classList.remove('hidden');
      toolbars.push(bar);
      closePortalMenus();
      assert.equal(shelf.innerHTML, '');
      assert.equal(bar.classList.contains('hidden'), true);
    } finally { uninstall(); }
  });

  it('purgePortalToolbars removes orphan bars and clears the shelf', () => {
    const { toolbars } = installFakeDoc();
    try {
      uiPortal();
      const shelf = menuShelf();
      shelf.innerHTML = '<div></div>';
      const bar = mkEl('div');
      toolbars.push(bar);
      purgePortalToolbars();
      assert.equal(bar.removed, true);
      assert.equal(shelf.innerHTML, '');
    } finally { uninstall(); }
  });

  it('DOM-less runtimes no-op instead of throwing (SSR/worker safe)', () => {
    assert.equal(uiPortal(), null);
    assert.equal(menuShelf(), null);
    assert.doesNotThrow(() => { closePortalMenus(); hidePortalToolbars(); purgePortalToolbars(); });
  });

  it('fixed-layer positioning never adds scroll offsets (right-corner drift)', () => {
    const src = fs.readFileSync(new URL('../../static/v2-app.js', import.meta.url), 'utf8');
    assert.ok(!src.includes('r.top + window.scrollY'), 'md toolbar/slash must use viewport coords');
    assert.ok(!src.includes('r.left + window.scrollX'), 'md toolbar/slash must use viewport coords');
  });

  it('mode switch always dismisses the portal', () => {
    const src = fs.readFileSync(new URL('../../static/v2-app.js', import.meta.url), 'utf8');
    const at = src.indexOf('const applyMode');
    assert.ok(at >= 0);
    const body = src.slice(at, at + 400);
    assert.ok(body.includes('closePortalMenus'), 'applyMode must close portal menus');
    assert.ok(body.includes('hidePortalToolbars'), 'applyMode must hide portal toolbars');
  });
});
