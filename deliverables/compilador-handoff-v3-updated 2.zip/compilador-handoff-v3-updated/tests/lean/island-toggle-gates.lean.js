import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  BlockStore, splitBlocks,
  parseFigureLine, serializeFigureLine,
  splitTableRow, isDelimiterRow,
  pushUndo, popUndo,
  ceShouldSync, ceSaveCaret, ceRestoreCaret,
} from '../../static/editor-core.js';
import { normalizeForEditor } from '../../static/v2-app.js';

const FIG = '![Alt da figura](img_1 "Legenda aqui") {#fig-intro width=0.5 place=full-width ratio=2}';

/* Spec §5 P1: islands — figure lines byte-identical, table split-row safe. */

describe('P1 islands: figure lines survive store ops', () => {
  it('insert elsewhere keeps the figure line byte-identical', () => {
    const s = new BlockStore(`${FIG}\n\nTexto\n`);
    s.insertBlockAt(1, '## Novo Título\n');
    const back = s.blocks.find((b) => b.kind === 'figure');
    assert.equal(back.lines.join('\n'), FIG);
  });

  it('undo checkpoint round-trip preserves the figure line', () => {
    const s = new BlockStore(`${FIG}\n\nTexto\n`);
    let undo = pushUndo([], s.getMarkdown());
    s.updateBlockText(1, 'Texto editado');
    s.updateFigure(0, { caption: 'Nova legenda' });
    const { snapshot, rest } = popUndo(undo);
    undo = rest;
    s.setSource(snapshot);
    const back = s.blocks.find((b) => b.kind === 'figure');
    assert.equal(back.lines.join('\n'), FIG);
    void undo;
  });

  it('parse→serialize is a stable fixpoint (auto slugs omitted)', () => {
    const once = serializeFigureLine(parseFigureLine(FIG));
    assert.equal(once, FIG);
    const twice = serializeFigureLine(parseFigureLine(once));
    assert.equal(twice, FIG);
    const auto = serializeFigureLine({ alt: 'A', src: 'img_2', slug: 'fig-slug-x7k2' });
    assert.equal(auto.includes('#fig-slug-'), false);
  });

  it('updateFigure patches one field, keeps the rest', () => {
    const s = new BlockStore(`${FIG}\n`);
    s.updateFigure(0, { caption: 'Trocada' });
    const f = parseFigureLine(s.blocks[0].lines.join('\n'));
    assert.equal(f.caption, 'Trocada');
    assert.equal(f.alt, 'Alt da figura');
    assert.equal(f.scale, 0.5);
    assert.equal(f.place, 'full-width');
    assert.equal(f.slug, 'fig-intro');
  });
});

describe('P1 islands: table split-row safety', () => {
  it('escaped pipes survive split/update without column drift', () => {
    const cells = splitTableRow('| a \\| b | c |');
    assert.deepEqual(cells, ['a | b', 'c']);
    const s = new BlockStore('| H1 | H2 |\n| --- | --- |\n| a \\| b | c |\n');
    s.updateTableCell(0, 2, 1, 'novo');
    const rows = s.blocks[0].lines.map(splitTableRow);
    assert.equal(rows.length, 3);
    assert.ok(rows.every((r) => r.length === 2));
    assert.deepEqual(rows[2], ['a | b', 'novo']);
    assert.equal(isDelimiterRow(s.blocks[0].lines[1]), true);
  });

  it('cell edit touches no other block (no-remount semantics)', () => {
    const s = new BlockStore(`Antes\n\n| H |\n| --- |\n| x |\n\nDepois\n`);
    const before = s.blocks.map((b) => b.lines.join('\n'));
    const seps = s.blocks.map((b) => b.sep);
    s.updateTableCell(1, 2, 0, 'y');
    assert.equal(s.blocks[0].lines.join('\n'), before[0]);
    assert.equal(s.blocks[2].lines.join('\n'), before[2]);
    assert.deepEqual(s.blocks.map((b) => b.sep), seps);
    assert.equal(splitBlocks(s.getMarkdown()).length, 3);
  });

  it('add/delete row keeps delimiter + column count', () => {
    const s = new BlockStore('| A | B |\n| --- | --- |\n| 1 | 2 |\n');
    s.addTableRow(0);
    let rows = s.blocks[0].lines.map(splitTableRow);
    assert.equal(rows.length, 4);
    assert.ok(rows.every((r) => r.length === 2));
    s.deleteTableRow(0, 3);
    rows = s.blocks[0].lines.map(splitTableRow);
    assert.equal(rows.length, 3);
    assert.equal(isDelimiterRow(s.blocks[0].lines[1]), true);
  });
});

/* Spec §5 P2: toggle lossless + normalize idempotent. */

describe('P2 toggle + normalize gates', () => {
  it('setSource(getMarkdown()) is lossless incl. figures', () => {
    const md = `${FIG}\n\n# Título\n\n- a\n- b\n\n> citação\n`;
    const s = new BlockStore(md);
    s.setSource(s.getMarkdown());
    assert.equal(
      s.blocks.find((b) => b.kind === 'figure').lines.join('\n'),
      FIG,
    );
    assert.equal(splitBlocks(s.getMarkdown()).length, 4);
  });

  it('normalize(normalize(x)) === normalize(x) across artifact battery', () => {
    const cases = [
      'Texto [span_12] com [cite_abc] tags',
      '• item com bullet unicode',
      '- • composto duplo',
      '• 1. ordenada composta',
      '![alt](img_1 "cap")',
      '1. primeira\n2. segunda',
      '  - aninhado com indent',
      '# Título **negrito**',
      '&nbsp; entidades <strong>html</strong>',
      '',
    ];
    for (const c of cases) {
      const once = normalizeForEditor(c);
      assert.equal(normalizeForEditor(once), once, `not idempotent: ${JSON.stringify(c)}`);
    }
  });

  it('normalize preserves image lines byte-identical', () => {
    const img = '![alt](img_1 "cap")';
    assert.equal(normalizeForEditor(img), img);
  });
});

/* Spec §5 P0 completeness: pure CompositionGuard + CaretAnchor clamps. */

describe('P0 pure depth: IME guard + caret clamps', () => {
  it('ceShouldSync blocks composing + composition input', () => {
    assert.equal(ceShouldSync(true, 'insertText'), false);
    assert.equal(ceShouldSync(false, 'insertCompositionText'), false);
    assert.equal(ceShouldSync(false, 'insertText'), true);
  });

  it('caret helpers clamp to [0, plainLen]', () => {
    assert.equal(ceSaveCaret(5, 99), 5);
    assert.equal(ceSaveCaret(5, -3), 0);
    assert.equal(ceRestoreCaret(5, 99), 5);
    assert.equal(ceRestoreCaret(5, 3), 3);
  });
});
