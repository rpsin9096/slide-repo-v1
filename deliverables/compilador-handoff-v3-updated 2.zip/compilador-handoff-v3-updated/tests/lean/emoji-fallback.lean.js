import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createEngine } from '../../pdf-engine.js';
import {
  splitEmojiSegments,
  hasEmojiCandidate,
  isEmojiCodePoint,
  EMOJI_FONT_ALIAS,
} from '../../src/v2/fonts/emoji.js';

/* Emoji fallback seam: pictographs missing from Arimo/Inter route to the
 * vendored Noto Emoji face; everything the base faces render stays put
 * (byte-identical metrics for non-emoji documents). */

describe('emoji splitEmojiSegments (pure)', () => {
  it('keeps plain text in a single non-emoji run', () => {
    assert.deepEqual(splitEmojiSegments('Olá mundo → teste'), [
      { text: 'Olá mundo → teste', emoji: false },
    ]);
    assert.equal(hasEmojiCandidate('Olá mundo → teste'), false);
  });

  it('splits pictographs, stars and hearts into emoji runs', () => {
    assert.deepEqual(splitEmojiSegments('Nota ⭐ fim ❤️ ok 😀!'), [
      { text: 'Nota ', emoji: false },
      { text: '⭐', emoji: true },
      { text: ' fim ', emoji: false },
      { text: '❤️', emoji: true },
      { text: ' ok ', emoji: false },
      { text: '😀', emoji: true },
      { text: '!', emoji: false },
    ]);
  });

  it('keeps multi-code-point sequences in one emoji run', () => {
    // Keycap, ZWJ family, skin-tone modifier, regional-indicator flag.
    const [keycap] = splitEmojiSegments('1️⃣').filter((s) => s.emoji);
    assert.equal(keycap.text, '1️⃣');
    const [family] = splitEmojiSegments('👨‍👩‍👧').filter((s) => s.emoji);
    assert.equal(family.text, '👨‍👩‍👧');
    const [tone] = splitEmojiSegments('👍🏽').filter((s) => s.emoji);
    assert.equal(tone.text, '👍🏽');
  });

  it('preserves base-face glyphs on the base font (no metric drift)', () => {
    // Arrows, base-covered symbols (♥ ♪ ☺), ©/® stay non-emoji.
    for (const cp of [0x2192, 0x2665, 0x266a, 0x263a, 0x00a9, 0x00ae]) {
      assert.equal(isEmojiCodePoint(cp), false, `U+${cp.toString(16)} must stay on base font`);
    }
    assert.deepEqual(splitEmojiSegments('a → ♥ b'), [{ text: 'a → ♥ b', emoji: false }]);
  });

  it('handles empty input', () => {
    assert.deepEqual(splitEmojiSegments(''), []);
    assert.deepEqual(splitEmojiSegments(null), []);
    assert.equal(hasEmojiCandidate(''), false);
  });
});

describe('emoji pdfkit integration', () => {
  it('embeds the fallback face and keeps body text when markdown has emoji', async () => {
    const engine = createEngine();
    const out = await engine.convertDocument(
      { sections: [{ title: 'T', markdown: 'Olá 😀 mundo ⭐ fim ❤️' }] },
      { driver: 'pdfkit', format: 'pdf' },
    );
    assert.ok(Buffer.isBuffer(out), 'pdfkit emits a PDF buffer');
    const raw = out.toString('latin1');
    assert.ok(raw.includes('NotoEmoji'), 'fallback face must be embedded');
  });

  it('does NOT embed the fallback face for emoji-free documents', async () => {
    const engine = createEngine();
    const out = await engine.convertDocument(
      { sections: [{ title: 'T', markdown: 'Olá mundo → teste ♥ normal' }] },
      { driver: 'pdfkit', format: 'pdf' },
    );
    assert.ok(Buffer.isBuffer(out), 'pdfkit emits a PDF buffer');
    assert.ok(!out.toString('latin1').includes('NotoEmoji'), 'zero extra bytes without emoji');
  });

  it('measures emoji words to a finite positive width', async () => {
    const { createMeasureContext } = await import('../../src/v2/drivers/pdfkit/blaster.js');
    const ctx = createMeasureContext('base', null);
    const w = ctx.measure('😀', 'helvetica', 10);
    assert.ok(typeof w === 'number' && isFinite(w) && w > 0, `width=${w}`);
    assert.equal(EMOJI_FONT_ALIAS, 'V2Emoji');
  });
});
