import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { applyRichCommand, ceApplyInline, detectRichState } from '../../static/editor-core.js';

describe('P4 bold/idempotent inline formatting', () => {
  it('B(B(x)) === B(x) for bold', () => {
    const r1 = applyRichCommand('hello', 0, 5, 'bold');
    assert.equal(r1.text, '**hello**');
    const r2 = applyRichCommand(r1.text, 0, r1.text.length, 'bold');
    assert.equal(r2.text, 'hello');
    const r3 = applyRichCommand(r2.text, 0, r2.text.length, 'bold');
    assert.equal(r3.text, r1.text);
  });

  it('italic on bold yields *** (valid bold+italic), not corruption', () => {
    const bold = applyRichCommand('bold', 0, 4, 'bold').text;
    assert.equal(bold, '**bold**');
    const r = ceApplyInline(bold, 0, bold.length, 'italic');
    assert.equal(r.text, '***bold***');
  });

  it('hug-strip unwraps markers hugging the selection', () => {
    const r = ceApplyInline('**hello**', 2, 7, 'bold');
    assert.equal(r.text, 'hello');
  });

  it('partial-word and multi-node selections stay single-wrapped', () => {
    const r1 = applyRichCommand('hello world', 0, 5, 'bold');
    assert.equal(r1.text, '**hello** world');
    const back = applyRichCommand(r1.text, 0, 9, 'bold');
    assert.equal(back.text, 'hello world');
  });

  it('detectRichState agrees with the toggle (toolbar aria-pressed)', () => {
    assert.equal(detectRichState('**hi**', 0, 6, 'bold'), true);
    assert.equal(detectRichState('hi', 0, 2, 'bold'), false);
    assert.equal(detectRichState('***hi***', 0, 9, 'bold'), true);
  });

  it('code/strike/link share the same toggle seam', () => {
    for (const fmt of ['code', 'strike']) {
      const r1 = applyRichCommand('x', 0, 1, fmt);
      const r2 = applyRichCommand(r1.text, 0, r1.text.length, fmt);
      assert.equal(r2.text, 'x');
    }
    const link = applyRichCommand('texto', 0, 5, 'link');
    assert.equal(link.text, '[texto](https://)');
  });
});
