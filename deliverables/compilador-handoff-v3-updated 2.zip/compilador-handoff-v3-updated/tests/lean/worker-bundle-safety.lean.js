/**
 * Worker bundle safety — Cloudflare validation guard.
 *
 * workerd evaluates module scope with `import.meta.url === undefined`.
 * A module-scope `fileURLToPath(import.meta.url)` therefore throws while the
 * script is being validated and Cloudflare rejects the upload with error
 * 10021 (regression fixed 2026-10-26 in src/v2/drivers/pdfkit/blaster.js).
 *
 * The guard walks the static `src/_worker.js` import graph and fails if any
 * reachable module reintroduces the pattern. Function-scoped uses are allowed
 * because they only run when a caller asks for a disk path, which embedded
 * Worker font assets never do.
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const ROOT = process.cwd();
const ENTRY = path.join(ROOT, 'src', '_worker.js');

const IMPORT_RE = /^\s*import\s+(?:[^'"]*?\sfrom\s+)?['"]([^'"]+)['"]/gm;
const MODULE_SCOPE_URL_RE = /^(?:const|let|var)\b[^\n]*fileURLToPath\s*\(\s*import\.meta\.url/gm;

function resolveSpecifier(fromFile, spec) {
  if (!spec.startsWith('.')) return null; // node: builtins and packages are out of scope
  let target = path.resolve(path.dirname(fromFile), spec);
  try {
    if (fs.statSync(target).isDirectory()) target = path.join(target, 'index.js');
  } catch { /* keep the literal target */ }
  return target;
}

function collectWorkerGraph(entry) {
  const seen = new Set();
  const stack = [entry];
  while (stack.length > 0) {
    const file = stack.pop();
    if (seen.has(file)) continue;
    seen.add(file);

    let src;
    try {
      src = fs.readFileSync(file, 'utf8');
    } catch {
      continue; // unresolved optional import; nothing to scan
    }

    for (const match of src.matchAll(IMPORT_RE)) {
      const target = resolveSpecifier(file, match[1]);
      if (target && !seen.has(target)) stack.push(target);
    }
  }
  return seen;
}

test('W13.1: the blaster module is part of the Worker import graph', () => {
  const graph = collectWorkerGraph(ENTRY);
  const blaster = path.join(ROOT, 'src', 'v2', 'drivers', 'pdfkit', 'blaster.js');
  assert.ok(graph.has(blaster), 'expected src/_worker.js to reach the PDFKit blaster');
});

test('W13.2: no Worker-reachable module calls fileURLToPath(import.meta.url) at module scope', () => {
  const offenders = [];
  for (const file of collectWorkerGraph(ENTRY)) {
    const src = fs.readFileSync(file, 'utf8');
    if (MODULE_SCOPE_URL_RE.test(src)) offenders.push(path.relative(ROOT, file));
    MODULE_SCOPE_URL_RE.lastIndex = 0;
  }
  assert.deepEqual(
    offenders,
    [],
    `module-scope fileURLToPath(import.meta.url) aborts Cloudflare validation (error 10021): ${offenders.join(', ')}`,
  );
});
