import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { ExportPayloadBuilder, ENGINE } from '../../static/export-payload.js';
import {
  DocumentStore, normalizeBox, migrateGlobals,
  STORAGE_KEY, STORAGE_VERSION, DEFAULT_GLOBALS, normalizeForEditor,
} from '../../static/document-store.js';

/* CC1 seam lock: ExportPayloadBuilder purity + storage versioning.
 * Builder duck-types { getBoxes(), getGlobals() } — no store import (no cycle). */

const fakeStore = (boxes, globals) => ({
  getBoxes: () => boxes,
  getGlobals: () => ({ ...DEFAULT_GLOBALS, ...globals }),
});

const box = (over = {}) => normalizeBox({ title: 'T', markdown: 'hello', ...over }, 0);

describe('CC1 ExportPayloadBuilder', () => {
  it('excludes ignored and empty-markdown boxes, indexes sections from 1', () => {
    const store = fakeStore([
      box({ title: 'Keep', markdown: '# Hi\n' }),
      box({ title: 'Empty', markdown: '   \n' }),
      box({ title: 'Skip', markdown: 'x', ignored: true }),
      box({ title: '', markdown: 'y' }),
    ], {});
    const payload = ExportPayloadBuilder.build(store, {});
    assert.equal(payload.sections.length, 2);
    assert.equal(payload.sections[0].index, 1);
    assert.equal(payload.sections[0].name, 'Keep');
    assert.equal(payload.sections[1].name, 'Seção 2');
  });

  it('mirrors masthead/table/column aliases and nulls inherited columns', () => {
    const store = fakeStore([
      box({ tableLayout: 'panoramic', columns: '' }),
    ], { tableLayoutMode: 'auto' });
    const payload = ExportPayloadBuilder.build(store, {});
    const s = payload.sections[0];
    assert.equal(s.table_layout, 'panoramic');
    assert.equal(s.tableLayout, 'panoramic');
    // normalizeBox defaults tableRotationDirection to 'cw', which wins over
    // the rotated_ccw derivation for normalized boxes (verbatim CC1 behavior).
    assert.equal(s.table_rotation_direction, 'cw');
    assert.equal(s.tableRotationDirection, 'cw');
    assert.equal(s.columns, null);
    assert.equal(s.column_layout, null);
    assert.equal(payload.table_layout_mode, 'auto');
    assert.equal(payload.tableLayoutMode, 'auto');
  });

  it('derives ccw rotation for un-normalized rotated_ccw sections', () => {
    const raw = {
      id: 'x', title: 'R', markdown: 'y', ignored: false,
      flags: { autofix: true, optimize_tables: true, split_equations: true },
      masthead: { enabled: false, prefix: '', course: '', topic: '', header: false },
      tableLayout: 'rotated_ccw', tableRotationDirection: '',
      columns: 1,
    };
    const payload = ExportPayloadBuilder.build(fakeStore([raw], {}), {});
    assert.equal(payload.sections[0].table_rotation_direction, 'ccw');
    assert.equal(payload.sections[0].tableRotationDirection, 'ccw');
    assert.equal(payload.sections[0].columns, 1);
  });

  it('locks engine while letting preview overrides through', () => {
    const store = fakeStore([box()], {});
    const payload = ExportPayloadBuilder.build(store, { preview: true, engine: 'evil' });
    assert.equal(payload.engine, ENGINE);
    assert.equal(payload.preview, true);
  });

  it('resolves doc title from chaptersToc globals, falls back to masthead', () => {
    const withTitles = fakeStore([box()], { chaptersToc: true, docTitlesEnabled: true, docTitle: ' Rel ', docSubtitle: 'Sub' });
    const p1 = ExportPayloadBuilder.build(withTitles, {});
    assert.equal(p1.doc_title, 'Rel');
    assert.equal(p1.doc_subtitle, 'Sub');

    const mhBox = box({ masthead: { enabled: true, course: 'Física', topic: 'Óptica', prefix: '', header: false } });
    const p2 = ExportPayloadBuilder.build(fakeStore([mhBox], {}), {});
    assert.equal(p2.doc_title, 'Física');
    assert.equal(p2.doc_subtitle, 'Óptica');
  });
});

describe('CC1 storage versioning', () => {
  const stubStorage = (seed) => {
    const m = new Map(Object.entries(seed || {}));
    globalThis.localStorage = {
      getItem: (k) => (m.has(k) ? m.get(k) : null),
      setItem: (k, v) => { m.set(k, String(v)); },
      removeItem: (k) => { m.delete(k); },
    };
    return m;
  };
  const unstub = () => { delete globalThis.localStorage; };

  it('save() writes versioned envelope { v, boxes, globals }', () => {
    const m = stubStorage();
    try {
      const store = new DocumentStore();
      store.save();
      const raw = m.get(STORAGE_KEY);
      assert.ok(raw);
      const parsed = JSON.parse(raw);
      assert.equal(parsed.v, STORAGE_VERSION);
      assert.ok(Array.isArray(parsed.boxes));
      assert.ok(parsed.globals && typeof parsed.globals === 'object');
    } finally { unstub(); }
  });

  it('loads legacy unversioned { boxes, globals } and migrates deprecated toggles', () => {
    const m = stubStorage({
      [STORAGE_KEY]: JSON.stringify({
        boxes: [{ title: 'A', markdown: 'hello' }],
        globals: { template: 'bauhaus', balanceColumns: false },
      }),
    });
    try {
      const store = new DocumentStore();
      assert.equal(store.getBoxes()[0].title, 'A');
      assert.equal(store.getGlobals().template, 'bauhaus');
      // balanceColumns is its own opt-in toggle now; editorialLayout renamed
      // to flushColumns ("Encaixar pé da página", default on).
      assert.equal(store.getGlobals().balanceColumns, false);
      assert.equal(store.getGlobals().flushColumns, true);
      assert.equal(store.getGlobals().balance_columns, undefined);
      assert.equal(store.getGlobals().editorialLayout, undefined);
    } finally { unstub(); void m; }
  });

  it('loads legacy raw-array shape', () => {
    stubStorage({ [STORAGE_KEY]: JSON.stringify([{ title: 'R', markdown: 'x' }]) });
    try {
      const store = new DocumentStore();
      assert.equal(store.getBoxes()[0].title, 'R');
    } finally { unstub(); }
  });

  it('migrateGlobals is pure and folds legacy editorialLayout into flushColumns', () => {
    const before = { template: 'base', editorialLayout: true, balanceColumns: false };
    const after = migrateGlobals(before);
    assert.equal(after.editorialLayout, undefined);
    assert.equal(after.flushColumns, true);
    assert.equal(before.balanceColumns, false);
    // An explicit off survives the migration in either direction.
    assert.equal(migrateGlobals({ editorialLayout: false }).flushColumns, false);
    assert.equal(migrateGlobals({ flush_columns: false }).flushColumns, false);
  });
});

describe('CC1 v2-app seam parity', () => {
  it('v2-app re-exports the identical module bindings', async () => {
    const app = await import('../../static/v2-app.js');
    const payloadMod = await import('../../static/export-payload.js');
    const storeMod = await import('../../static/document-store.js');
    assert.equal(app.ExportPayloadBuilder, payloadMod.ExportPayloadBuilder);
    assert.equal(app.normalizeForEditor, storeMod.normalizeForEditor);
    assert.equal(app.DocumentStore, storeMod.DocumentStore);
    assert.equal(app.normalizeBox, storeMod.normalizeBox);
  });
});
