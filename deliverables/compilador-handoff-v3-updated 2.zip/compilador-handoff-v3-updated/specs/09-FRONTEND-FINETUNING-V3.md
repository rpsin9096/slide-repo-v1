# 09 — Frontend Finetuning & Multi-Viewport Visual Specification (Wave 11)

| Field | Value |
| --- | --- |
| **Status** | **Implemented & Active (Wave 11 — 7/7 FocusGate Gates Settled; 0 Design-Guardrails Errors/Warnings; 9-Viewport Chromium CDP Verified).** |
| **Date** | 2026-10-25 |
| **Basis** | Handoff snapshot 2026-10-25 (`npm test`: 9/9 verify + 311/311 lean across 79 suites; `npm run test:design`: 38/38 pass across 9 suites; `design_guardrails.py --audit-all`: 0 errors, 0 warnings; `focus_gate.py --report --fresh`: 7/7 settled, 28 evidence records, 0 blockers) |
| **Governance** | Audited with **FocusGate v1.0.0-UNIFIED** (Red-Before-Green evidence gates, 2-adapter seams, 10-rule `GateIntegrity` checks, Micro-ADRs) and **Design-Guardrails v3.0.0** (declared archetype, 3-layer token hierarchy, WCAG 2.1 AA contrast blockers, `4px` structural grid, closed radius scale, multi-viewport visual verification) |
| **Owns** | Browser shell CSS token graph (`static/design-system.css`, `static/shell.css`), WCAG 2.1 AA light/dark contrast pairs, `4px` spacing & control grid, closed radius scale (`[0, 4, 8, 12, 16, 9999]px`), 5-state interactive matrix, 9-viewport responsive contracts (`DESIGN.md`, `design-guardrails.config.json`, `tests/design/visual-w11-guardrails.lean.js`) |
| **Does not own** | Backend PDF geometry math (`08-LAYOUT-GEOMETRY-V3.md`), Markdown parser grammar (`03-INPUT.md`), server HTTP transport (`05-OUTPUT.md`, `06-OPERATIONS.md`) |

Keywords **MUST / SHOULD / MAY** are used in the RFC 2119 sense. Every gate in §6 pairs a measurable metric and threshold with an executable **FocusGate** `CHECK:` and `EXPECT:` contract and its recorded `RED -> GREEN` transition.

---

## 0. Domain Anchors (FocusGate Micro-Glossary)

1. **Primitive Token (`--primitive-*`)**: A raw color, alpha, or dimensional literal declared exclusively inside `:root` of `static/design-system.css` (e.g., `--primitive-ink-light-mute: #626770`, `--primitive-surface-dark-page: #17181b`). Component selectors and semantic theme overrides MUST NEVER declare raw `#hex` or `rgba()` literals directly.
2. **Semantic Token (`--color-*`, `--surface-*`, `--ink-*`, `--line-*`)**: A role-based custom property bound in `:root, html[data-theme="light"]` and rebound in `html[data-theme="dark"]` exclusively via `var(--primitive-*)` references.
3. **Structural Base (`spacing_base: 4px`)**: The fundamental spatial quantum (`4px`) governing all layout paddings, gaps, margins, and interactive control dimensions (`24px`, `32px`, `40px`, `44px`, `48px`), reserving `0.5px–2px` strictly for hairlines and optical micro-adjustments.
4. **Closed Radius Scale (`[0, 4, 8, 12, 16, 9999]px`)**: The exhaustive set of allowed `border-radius` values (`--radius-none: 0px`, `--radius-xs: 4px`, `--radius-sm: 4px`, `--radius-md: 8px`, `--radius-lg: 12px`, `--radius-xl: 16px`, `--radius-pill: 9999px`). Off-step radii (`5px`, `6px`, `7px`, `10px`, `18px`) are prohibited.
5. **In-Flow Composer Pill (`.rich-composer`)**: The centered `+ Inserir` trigger inside `.rich-container` (`position: relative; display: inline-flex; align-self: center; width: fit-content; margin-top: var(--space-xs); z-index: 2`), which flows beneath `.rich-editor` content rather than floating over multi-paragraph prose with `position: absolute`.

---

## 1. Empirical RED -> GREEN Baseline & Remediation Summary

Before modifying a single line of CSS, both `scripts/design_guardrails.py` and `scripts/focus_gate.py` were executed against `/tmp/compilador-handoff-v3` to capture a tamper-evident `RED` baseline in `.focusgate/GATES.evidence.jsonl`, followed by 4-pass remediation and headless Chromium visual inspection:

| Gate ID | Audit Surface | Pre-Remediation (`RED` Baseline) | Post-Remediation (`GREEN` Settlement) |
| --- | --- | --- | --- |
| `gate-1-token-integrity` | 3-Layer CSS Token Graph (`static/design-system.css`, `static/shell.css`) | **57 errors**: 34 raw `#hex`/`rgba()` literals in `html[data-theme="dark"]` & component rules; 23 FocusGate token leaks | **0 errors, 0 warnings** (`100%` of light/dark semantic & component rules resolve via `var(--primitive-*)` / `var(--*)`) |
| `gate-2-contrast-wcag-aa` | WCAG 2.1 AA Luminance Contrast (`static/design-system.css`) | **1 blocker**: light `--ink-mute` (`#6b7079`) on `--page` (`#eceef1`) measured `4.28:1` (`< 4.5:1` AA floor) | **0 errors, 0 warnings** (`--ink-mute` darkened to `#626770`: `4.89:1` on `--page`, `5.30:1` on `--surface-1`) |
| `gate-3-spacing-radius-grid` | Global `4px` Grid, Radii & Touch Targets (`static/*.css`) | **64 off-grid values** (`--space-xs: 6px`, `--space-md: 10px`, `14px/18px/22px` paddings) + **20 off-scale radii** (`5px`, `6px`, `7px`, `10px`, `18px`) | **0 errors, 0 warnings** (`--space-xs: 4px`, `--space-md: 8px`, radii strictly in `[0, 4, 8, 12, 16, 9999]px`, mobile bar `min-height: 48px`) |
| `gate-4-typography-states-layout` | Wrapping, States, Hover Guards & Viewport Caps (`static/*.css`) | Missing `text-wrap: balance/pretty`, unguarded `:hover` rules, opacity-only `:disabled`, missing `.ticon:active`, `100vh` without `100dvh` | **0 errors, 0 warnings** (`text-wrap: balance/pretty`, `@media (hover: hover)`, `.ticon:active`, surface `:disabled`, `100dvh`/`82dvh` caps) |
| `gate-5-design-md-contract` | Normative `DESIGN.md` 9-Section Schema | `DESIGN.md` missing (`1` blocker) | **0 errors, 0 warnings** (all 9 required sections + Known Gaps verified by `design_guardrails.py --document DESIGN.md`) |
| `gate-6-design-test-regression` | Existing + New Wave 11 Design Locks (`tests/design/*.lean.js`) | `W1`–`W10` (`33` tests); no `W11` lock | **38/38 PASS** across `9` suites (`visual-w1` through `visual-w11-guardrails.lean.js`) + **311/311 PASS** lean tests |
| `gate-7-consolidation` | Combined Guardrails + FocusGate Ledger Integrity | Unsettled (`0/7` gates) | **7/7 SETTLED**, anchored SHA-256 hash chain (`28` evidence records, `0` blockers, `[LINT_PASS]`, `[REPORT_PASS]`) |

---

## 2. Three-Layer Token Hierarchy & WCAG 2.1 AA Contrast Matrix

### 2.1 Token Resolution Graph (`static/design-system.css`)

```text
Layer 1: Primitive Palette (:root only)
  --primitive-surface-light-page: #eceef1
  --primitive-surface-light-0:    #ffffff
  --primitive-surface-light-1:    #f6f7f9
  --primitive-ink-light-mute:     #626770
  --primitive-surface-dark-page:  #17181b
  --primitive-surface-dark-0:     #1c1d22
  --primitive-surface-dark-1:     #232429
  --primitive-ink-dark-mute:      #93969e
  --primitive-alpha-cobalt-14:    rgba(37, 99, 235, 0.14)
        │
        ▼
Layer 2: Semantic Theme Roles (:root, html[data-theme="light"] / html[data-theme="dark"])
  --page        -> var(--primitive-surface-light-page) | var(--primitive-surface-dark-page)
  --surface     -> var(--primitive-surface-light-0)    | var(--primitive-surface-dark-0)
  --surface-1   -> var(--primitive-surface-light-1)    | var(--primitive-surface-dark-1)
  --ink-mute    -> var(--primitive-ink-light-mute)     | var(--primitive-ink-dark-mute)
  --color-bg    -> var(--page)
  --color-muted -> var(--ink-mute)
        │
        ▼
Layer 3: Component Selectors (static/design-system.css & static/shell.css)
  .box-card, .settings-pane, .m-bubble, .rich-composer, #sheet-body, #bottom-bar
```

### 2.2 Verified WCAG 2.1 AA Luminance Contrast Pairs

| Theme | Foreground Token | Hex | Background Token | Hex | Measured Ratio | WCAG 2.1 Target | Status |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Light | `--ink` / `--color-text` | `#14151a` | `--surface` | `#ffffff` | **18.06:1** | `>= 4.5:1` (AA) | PASS (AAA) |
| Light | `--ink-2` / `--color-text-secondary` | `#52565f` | `--surface` | `#ffffff` | **7.32:1** | `>= 4.5:1` (AA) | PASS (AAA) |
| Light | `--ink-mute` / `--color-muted` | `#626770` | `--surface` | `#ffffff` | **5.74:1** | `>= 4.5:1` (AA) | PASS |
| Light | `--ink-mute` / `--color-muted` | `#626770` | `--surface-1` | `#f6f7f9` | **5.30:1** | `>= 4.5:1` (AA) | PASS |
| Light | `--ink-mute` / `--color-muted` | `#626770` | `--page` | `#eceef1` | **4.89:1** | `>= 4.5:1` (AA) | PASS |
| Light | `--color-on-primary` | `#ffffff` | `--accent` | `#2563eb` | **5.17:1** | `>= 4.5:1` (AA) | PASS |
| Dark | `--ink` / `--color-text` | `#f0f1f3` | `--surface` | `#1c1d22` | **14.37:1** | `>= 4.5:1` (AA) | PASS (AAA) |
| Dark | `--ink-2` / `--color-text-secondary` | `#b4b7be` | `--surface` | `#1c1d22` | **8.27:1** | `>= 4.5:1` (AA) | PASS (AAA) |
| Dark | `--ink-mute` / `--color-muted` | `#93969e` | `--surface-1` | `#232429` | **5.23:1** | `>= 4.5:1` (AA) | PASS |
| Dark | `--ink-mute` / `--color-muted` | `#93969e` | `--surface-3` | `#2c2e35` | **4.58:1** | `>= 4.5:1` (AA) | PASS |
| Dark | `--color-accent-text` | `#549af9` | `--surface` | `#1c1d22` | **5.90:1** | `>= 4.5:1` (AA) | PASS |

---

## 3. Global `4px` Structural Grid, Closed Radius Scale & Touch Targets

1. **Spacing Scale (`static/design-system.css`)**:
   - `--space-0: 0px`, `--space-px: 1px`, `--space-3xs: 2px` (optical hairlines only)
   - `--space-2xs: 4px`, `--space-xs: 4px`, `--space-sm: 8px`, `--space-md: 8px`, `--space-lg: 12px`, `--space-xl: 16px`, `--space-2xl: 20px`, `--space-3xl: 24px`, `--space-4xl: 32px`, `--space-5xl: 40px`
2. **Closed Border-Radius Scale (`static/design-system.css`)**:
   - `--radius-none: 0px`, `--radius-xs: 4px`, `--radius-sm: 4px`, `--radius-md: 8px`, `--radius-lg: 12px`, `--radius-xl: 16px`, `--radius-pill: 9999px`
3. **Control Heights & Touch Floors**:
   - Desktop icon controls (`.ticon`, `.m-bubble button`): `32px × 32px` (`var(--control-h-md)`)
   - Coarse-pointer / mobile touch controls (`@media (pointer: coarse)`): `44px × 44px` (`var(--control-h-touch)`)
   - Mobile bottom action bar (`#bottom-bar .btn`, `#bottom-bar .file-btn`) and mobile sheet rows (`#sheet-body .btn`, `#sheet-body .file-btn`, `#sheet-body #add-box-btn`, `#sheet-body .ticon`): `min-height: 48px`
   - Ultra-narrow `<= 359px` (`320x568` iPhone SE) topbar: `.brand-mark` (`24px × 24px`), `#add-box-btn` (`padding: 8px`), `#toggle-settings-pane` (`40px × 40px`)

---

## 4. Multi-Viewport Headless Chromium Inspection & Runtime Fixes

The frontend was rendered and visually inspected across **9 screen types and interactive states** in headless Chromium (`128.0.6613.137`) via CDP `Page.setDocumentContent`:

| Viewport ID | Resolution | Theme & UI State | DOM Metrics (`scrollWidth <= clientWidth`) | Visual Inspection Outcome |
| --- | --- | --- | --- | --- |
| `01_desktop_1440x900_light` | `1440×900` | Light — Wide Desktop + Docked `320px` Settings Rail + 2 Cards (Rich + Markdown) | `1440 <= 1440` (`overflowX: false`) | Crisp hairline hierarchy, balanced 2-column workspace, in-flow `+ Inserir` pill centered cleanly below Rich prose |
| `02_desktop_1280x800_light_find` | `1280×800` | Light — Standard Desktop + Global Find Bar (`Ctrl+K`) + 2-Col `/2c` Split Badge | `1280 <= 1280` (`overflowX: false`) | Docked find bar (`Localizar no documento...`) and `/2c` badge align on the `4px` grid |
| `03_desktop_1280x800_dark` | `1280×800` | Dark (`html[data-theme="dark"]`) — Semantic-Only Overrides + Active Rich & Markdown Cards | `1280 <= 1280` (`overflowX: false`) | `#17181b` canvas, `#1c1d22` cards, `#232429` wells, and `#93969e` muted ink (`5.23:1`) render with zero raw hex leaks |
| `04_desktop_1280x800_portal_menu` | `1280×800` | Light — Shared `#ui-portal` Floating Insert Menu + `.m-bubble` Selection Toolbar | `1280 <= 1280` (`overflowX: false`) | Two-column categorized insert menu (`clamp(260px, 340px, calc(100vw - 24px))`) and `32×32px` `.m-bubble` controls |
| `05_desktop_1280x800_shortcuts_modal` | `1280×800` | Light — Keyboard Shortcuts Modal (`#shortcuts-modal`) + Scrim (`var(--color-backdrop)`) | `1280 <= 1280` (`overflowX: false`) | Centered `16px`-radius modal (`min(480px, 100%)`), balanced headings, aligned `<kbd>` badges |
| `06_tablet_768x1024_light` | `768×1024` | Light — Tablet Portrait (`< 860px`) + Collapsible Settings Drawer Open + `#bottom-bar` | `768 <= 768` (`overflowX: false`) | Settings rail transitions cleanly into a right slide-over drawer (`max-height: 100dvh`) with `48px` bottom bar |
| `07_mobile_375x812_light` | `375×812` | Light — Mobile Portrait + Touch Toolbar (`44×44px`) + `48px` Bottom Action Bar (`Mais · Pré-ver · Gerar PDF`) | `375 <= 375` (`overflowX: false`) | Single-line `nowrap` bottom buttons (`height: 48px`), `44×44px` touch toolbar icons, zero horizontal overflow |
| `08_mobile_375x812_dark_sheet` | `375×812` | Dark — Mobile `"Mais"` Bottom Action Sheet (`#mobile-sheet.open`) | `375 <= 375` (`overflowX: false`) | Full-width `48px` sheet rows (`+ Novo bloco`, `Importar .md`, `Exportar .md`, `Atalhos (?)`, `Alternar tema`) |
| `09_mobile_320x568_light` | `320×568` | Light — Ultra-Narrow `320px` Floor (iPhone SE) | `320 <= 320` (`overflowX: false`) | `24×24px` `.brand-mark`, compact `#add-box-btn`, and `40×40px` `#toggle-settings-pane` fit on one row (`topBarH: 52px`) |
| `10_landscape_667x375_portal` | `667×375` | Light — Short Mobile Landscape + Open `#ui-portal` Insert Menu (`max-height: calc(100vh - 16px)`) | `667 <= 667` (`overflowX: false`) | Portal menu clamps to `359px` (`<= 375px` viewport) with internal vertical scrolling (`overflow-y: auto`) |

### Runtime Visual Defects Discovered & Fixed During Inspection

1. **Defect V-1 (`.rich-composer` Overlapping Rich Editor Text)**:
   - *Symptom*: In `static/design-system.css`, `.rich-composer` was positioned with `position: absolute; bottom: var(--space-sm); left: 50%; transform: translateX(-50%)`, while `.rich-container` is a flex column (`display: flex; flex-direction: column`). When `.rich-editor` contained multiple blocks, the floating `+ Inserir` pill sat directly on top of the last line of text or block toolbar.
   - *Fix*: Converted `.rich-composer` to an in-flow centered flex child (`position: relative; display: inline-flex; align-self: center; width: fit-content; margin-top: var(--space-xs); z-index: 2`) and reduced `.rich-editor` bottom padding to `var(--space-sm)`.
2. **Defect V-2 (`#sheet-body` Mobile Action Sheet Button Alignment & Missing Label)**:
   - *Symptom*: When mobile controls moved into `#sheet-body` (`static/v2-app.js`), `#add-box-btn` hid `.btn-long` (`Novo bloco`) below `600px`, rendering as a bare `+` icon, and `.ticon` buttons (`#shortcuts-btn`, `#theme-toggle-btn`) stayed `32×32px` instead of matching full-width sheet rows.
   - *Fix*: Added `#sheet-body .btn, #sheet-body .file-btn, #sheet-body #add-box-btn, #sheet-body .ticon { width: 100%; min-height: 48px; justify-content: flex-start; padding: var(--space-sm) var(--space-lg); font-size: var(--font-size-base); border-radius: var(--radius-md); gap: var(--space-lg); }` and `#sheet-body #add-box-btn .btn-long { display: inline; margin: var(--space-0, 0px); }` in `static/shell.css`.

---

## 5. Architectural Decision Records (Micro-ADRs)

- **ADR-0901 (Thesis A — Token-First Structural Determinism)**: Chose a strict 3-layer CSS variable graph (`--primitive-* -> --color-* -> component`) in `static/design-system.css` over ad-hoc component overrides so dark mode (`html[data-theme="dark"]`) is 100% semantic-only (`0` raw hex/rgba literals).
- **ADR-0902 (Global `4px` Structural Base — `1A`)**: Locked `spacing_base: 4` in `design-guardrails.config.json` and snapped `--space-xs` (`4px`), `--space-md` (`8px`), and all component dimensions to `4px` multiples while preserving `W1`–`W10` design locks (`32px` `.field-row`, `12px` editor padding, `8px` editor radius, `132px` floor).
- **ADR-0903 (WCAG 2.1 AA Muted Ink Calibration)**: Adjusted `--primitive-ink-light-mute` from `#6b7079` (`4.28:1` on `--page`) to `#626770` (`4.89:1` on `--page`, `5.30:1` on `--surface-1`), clearing the `4.5:1` AA floor across every light surface without collapsing visual hierarchy against `--ink-2` (`#52565f`, `7.32:1`).
- **ADR-0904 (In-Flow `.rich-composer` Pill)**: Replaced `position: absolute` on `.rich-composer` with `position: relative; display: inline-flex; align-self: center; width: fit-content;` inside the `.rich-container` flex column to eliminate text collision across all viewports.
- **ADR-0905 (Unified `#sheet-body` Mobile Action Rows)**: Standardized all migrated mobile controls inside `#sheet-body` to full-width `48px` touch rows and un-hid `.btn-long` on `#sheet-body #add-box-btn`.

---

## 6. Executable Acceptance Gates

All 7 gates in `.focusgate/GATES.md` and the Wave 11 regression lock (`tests/design/visual-w11-guardrails.lean.js`) are active and verified:

```bash
# 1. Design Guardrails v3.0 full static & DESIGN.md audit
python3 scripts/design_guardrails.py --config design-guardrails.config.json --audit-all static --document DESIGN.md
# -> Summary: 0 error(s), 0 warning(s) across 7 check(s).

# 2. FocusGate v1.0 ledger lint & fresh report
python3 scripts/focus_gate.py --lint --strict --ledger .focusgate/GATES.md
python3 scripts/focus_gate.py --report --fresh --ledger .focusgate/GATES.md
# -> [LINT_PASS] .focusgate/GATES.md: 7 gates valid (7 settled, 0 active).
# -> [REPORT_PASS] DELIVERABLE (7/7 settled, 28 evidence records, 0 blockers)

# 3. Node verify + lean + design test suites
npm run test:all
# -> 9/9 verify suites PASS, 311/311 lean tests PASS (79 suites), 38/38 design tests PASS (9 suites)
```
