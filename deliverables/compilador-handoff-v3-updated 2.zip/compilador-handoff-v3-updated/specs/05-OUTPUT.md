# 05 — Output and PDF

This spec owns the compiler's output object, the driver contract, PDF bytes, fonts, response headers, and the pagination JSON. Input normalization is in [03-INPUT.md](03-INPUT.md); layout decisions are in [04-LAYOUT.md](04-LAYOUT.md).

## DisplayList

The compiler emits a frozen **DisplayList** (`irVersion: '2.2.0'` when `geometry === 'v3'`, or `'2.1.0'` in legacy `'v2'` mode; see [08-LAYOUT-GEOMETRY-V3.md](08-LAYOUT-GEOMETRY-V3.md) §5.11 for `page.frame`, `page.columns`, `el.baseline`, and `diagnostics.geometry`):

```js
{
  irVersion: '2.2.0',
  schemaVersion: '2.2.0',
  template: 'base',
  totalPages: 12,
  pages: [
    {
      pageNumber: 1,
      elements: [ /* ... */ ]
    }
  ],
  anchors: { /* heading anchors/destinations */ },
  diagnostics: { /* fit, justify, tables, headings, images */ },
  toc: { /* enabled, sections, title, ... */ },
  pagination: { /* totalPages, hasToC, tocPage, sections */ },
  metadata: { /* title, creation data */ }
}
```

The exact page/element fields are produced by `GeometryCompiler.compile`; the contract is enforced by `freezeIR` and `assertDriverPurity` in `src/v2/core/display-list.js`.

### Element types

| Type | Meaning |
| --- | --- |
| `text` | Positioned text with `runs` (style/format spans), `prewrapped` lines, `width`, and `align` |
| `rect` | Filled/stroked rectangle, including table/card chrome |
| `rule` | Horizontal or vertical line |
| `bullet` | List bullet glyph |
| `checkbox` | Task-list checkbox |
| `image` | Placed image; the binary rides in the image map/IR buffer, not as a layout closure |
| `destination` | Internal anchor/destination for TOC or links |
| `rotated` | A rotated table or element on a dedicated page |
| `tag_struct_start` / `tag_struct_end` | Structural markers; their presence does not make the PDF a tagged/accessible PDF |

Drivers may consume **only** this IR. They must not receive `blocks`, `markdown`, AST nodes, `paint`, or `measure` closures. `assertDriverPurity` throws `IR_REJECTED`, `AST_LEAK`, or `CLOSURE_LEAK` when the boundary is violated.

### Freezing and immutability

- `freezeIR` deep-freezes the DisplayList, skipping `Buffer`/typed arrays. It is idempotent.
- The same `DisplayList` reference is safe to hand to a driver; drivers must not mutate it.
- Coordinates are verbatim; the driver performs zero measuring, line-breaking, or re-layout.
- The compiler is pure: no driver calls, file reads, network, or input mutation.

## PDFKit driver

The default production driver is PDFKit.

- Entry points: `src/v2/drivers/pdfkit/driver.js` (`emit`, `emitPdf`), `src/v2/drivers/pdfkit/blaster.js` (`PDFKitVectorBlaster.blast`).
- The driver compiles a DocIR to a DisplayList when given one (the `emit` path) and then blasts the list. `emitPdf` is the direct buffer entry used by the Worker.
- Font registration uses the vendored assets and `createMeasureContext`; measurement uses the same faces as rendering.
- Shaping may cache fontkit layout runs, but a cached run must never be handed to more than one caller. PDFKit's `EmbeddedFont.layoutRun` normalizes `positions` in place (`position[key] *= scale`), so a shared mutable run is rescaled on every document that reuses the font — in a long-lived Worker isolate this produced large negative per-glyph tracking (broken spacing) after the first render. `attachFkFontLayoutCache` returns a per-call copy that preserves the fontkit prototype getters (`advanceWidth`, `advanceHeight`, `bbox`); `tests/lean/shaping-layout-cache.lean.js` guards the invariant.
- The blaster may set `CreationDate`/`ModDate` when an explicit timestamp or `displayList.createdAt` is present. Without one, PDFKit's default date is used. Tests pin the timestamp for byte-level determinism.
- The output is a PDF buffer. The pipeline can attach `buffer.pagination` so the server can emit TOC/page headers.

The vendored faces are:

- Arimo: Regular, Bold, Italic, BoldItalic.
- Inter: Regular, Bold, Italic, SemiBoldItalic.
- Noto Emoji: Regular (monochrome fallback, selected only for emoji runs).

`assets/fonts/` contains the files. `src/font-assets-data.js` is the Worker's generated base64 bundle; it is not committed and is rebuilt by `npm run build`. `src/afm-data.js` is generated from PDFKit's AFM/ICC data and is committed because the local path and Worker bundle expect it.

## Typst driver (optional)

The Typst path is not the default and is not available in the Worker.

- `src/v2/drivers/typst/emitter.js` turns measured boxes into `.typ` source.
- `src/v2/drivers/typst/compile.js` shells out to the Typst binary (`TYPST_BIN`, `~/.local/bin/typst`, or `typst` on `PATH`).
- Default compile timeout: 60,000 ms (`TYPST_TIMEOUT_MS` override).
- `sandboxTypstAssets` copies local image references into a temporary sandbox; remote references pass through. See [06-OPERATIONS.md](06-OPERATIONS.md) for the path-containment caveat.
- Typst returns a plain PDF buffer without the PDFKit `pagination` sidecar, so Node's `/api/convert` may omit `X-Document-TOC`/`X-Total-Pages` for Typst renders.

The `/api/convert-v2` staging endpoint uses the Typst/autobalance path. It is not part of the default browser flow.

## Response shapes

### `POST /api/convert`

Node returns PDF bytes. Depending on the render path:

| Header | Meaning |
| --- | --- |
| `Content-Type: application/pdf` | PDF body |
| `Content-Disposition: inline` | When `preview` is truthy |
| `Content-Disposition: attachment; filename="document.pdf"` | Full conversion |
| `X-Engine-Used` | The requested engine label (`body.engine || 'v1'`); the browser sends `v2-modular` |
| `X-Geometry-Version` | `'v3'` or `'v2'`, matching the active compiler geometry mode |
| `X-Document-TOC` | URL-encoded JSON TOC (`{ totalPages, hasToC, chaptersToc, tocPage, tocPages, geometry, sections }`) |
| `X-Total-Pages` | Total page count, under the same condition |

The browser names the downloaded file `document-<engineUsed>.pdf`, normally `document-v2-modular.pdf`. It does not use the server's `Content-Disposition` filename.

### `POST /api/paginate`

The local endpoint returns a coarse estimate:

```json
{
  "success": true,
  "totalPages": 12,
  "sections": [
    { "index": 0, "title": "Section A", "estimatedHeight": 1234.5 }
  ],
  "estimated": true,
  "metrics": {
    "totalHeight": 14814,
    "availableHeight": 700,
    "boxCount": 42
  },
  "durationMs": 3
}
```

When `geometry: 'v3'` is passed in the request body (the browser default via `ExportPayloadBuilder`), both Node and the Cloudflare Worker execute `runPipeline({ mode: 'paginate', geometry: 'v3' })` and return the compiler's exact page map:

```json
{
  "success": true,
  "totalPages": 3,
  "hasToC": true,
  "chaptersToc": true,
  "tocPage": 1,
  "tocPages": 1,
  "geometry": "v3",
  "sections": [
    {
      "index": 1,
      "name": "Capítulo 1",
      "title": "Capítulo 1",
      "startPage": 2,
      "bodyPage": 1,
      "headings": [
        { "level": 1, "text": "1. Fundamentos", "page": 2, "bodyPage": 1 }
      ]
    }
  ],
  "durationMs": 12
}
```

When `geometry` is omitted or `'v2'`, `/api/paginate` returns the coarse `estimated: true` shape above for legacy callers.

### Worker `/api/convert`

The Worker returns PDFKit PDF bytes with the same engine/TOC/page headers when available, plus cache behavior:

- `X-Cache: HIT` or `MISS` for `/api/convert`.
- `Cache-Control: public, max-age=600` on cached render responses.
- Cache key is a stable hash of the body after image extraction/stripping, minus preview flags, plus `RENDER_ENGINE_REVISION`.
- Cache is best-effort (`caches.default`, 10 MB max, 600 s TTL). A cache miss renders locally or proxies to `PDF_BACKEND_URL`.

The Worker sets its own `Content-Disposition` (`inline; filename="preview.pdf"` for previews, `attachment; filename="document.pdf"` otherwise); the browser still keeps its own download naming.

### Worker `/api/paginate`

Same coarse estimator shape as Node. It is subject to the Worker's 150k text / 30-section limits and does not fetch or validate images.

## Output guarantees

- The PDF body is a valid PDF and is returned as a single buffer.
- The DisplayList is frozen and pure before emission.
- Page numbers are monotonic and start at 1.
- Body content is inside the content region; overflow is a diagnostic defect, not a silent clip.
- Applied vertical-justification pages bottom within 1 pt of the content foot; skipped pages carry a valid reason.
- A block starts a new page; the TOC page, when present, is page 1 and block pages follow.
- Headers/footers are chrome and do not participate in body glue.
- The same input plus the same seed/timestamp produces the same geometry; PDF creation metadata may differ when the timestamp is not pinned.

## Failure output

Render and validation failures return JSON on the API surfaces, not a partial PDF. See [03-INPUT.md](03-INPUT.md) for status codes. The PDFKit driver may throw `DriverError` with a driver prefix; the pipeline rehydrates errors as `PipelineError` with a stable code. A failed render must not leave a truncated PDF download in the browser.

## Non-goals

- Tagged/accessible PDF conformance is not implemented, even though structural markers exist in the IR.
- PDF/A, PDF/X, encryption, signatures, and embedded metadata standards are not implemented.
- Pixel-identical output across machines is not guaranteed; the geometry is deterministic, but font rasterization and PDFKit/library versions can differ.
