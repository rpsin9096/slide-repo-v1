# 02 — Architecture

## System context

Compilador do Raul is a single-document compiler with two deployment surfaces and one shared layout core.

```text
┌─────────────────────────────┐
│ Browser (static/)           │
│ editor + DocumentStore      │
│ ExportPayloadBuilder        │
└──────────────┬──────────────┘
               │ JSON over HTTP
      ┌────────┴─────────┐
      │                  │
┌─────▼──────┐    ┌──────▼─────────┐
│ Node       │    │ Cloudflare     │
│ server.js  │    │ src/_worker.js │
│ Express    │    │ fetch + cache  │
└─────┬──────┘    └──────┬─────────┘
      │                  │
      └────────┬─────────┘
               │ normalized payload
      ┌────────▼─────────────────────────┐
      │ src/v2/runtime/pipeline.js       │
      │ normalize → validate → compile   │
      │ → freeze → driver                │
      └────────┬─────────────────────────┘
               │ DisplayList
      ┌────────▼──────────┐
      │ PDFKit or Typst   │
      └────────┬──────────┘
               │
          PDF bytes / source / page map
```

The browser never imports `src/v2/` directly. The shared contract is the HTTP JSON payload and the returned PDF or pagination JSON.

## Components

| Component | Files | Responsibility |
| --- | --- | --- |
| Browser shell & design system | `static/index.html`, `static/design-system.css`, `static/shell.css`, `static/icons.svg`, `DESIGN.md`, `design-guardrails.config.json` | 3-layer CSS token graph (`--primitive-* -> --color-* -> component`), 4px structural grid, responsive layout, WCAG AA themes (`light` + `dark`) |
| Editor controller | `static/v2-app.js` | Card lifecycle, editing modes, toolbars, settings, preview, download, boot |
| State | `static/document-store.js` | Single source of truth for boxes/globals, defaults, migration, persistence |
| Payload builder | `static/export-payload.js` | Pure conversion from store state to the server request |
| Editor primitives | `static/editor-core.js`, `static/editor-adapters.js` | Markdown commands, block store, adapter contract, undo/redo |
| Local API | `server.js` | Express routes, static serving, uploads, limits, CORS, rate limits |
| Public engine facade | `pdf-engine.js` | Normalization, image pre-resolution, driver selection, coarse pagination |
| Deprecated facade | `pdf-generator.js` | Compatibility wrapper for `generatePdf` and old tests; keep |
| Pipeline | `src/v2/runtime/pipeline.js` | Canonical stage order, modes, telemetry, fit gate, error restoration |
| Ingest | `src/v2/ingest/` | Markdown → DocIR-ish blocks, sanitizer, tables, language, serialization |
| Contracts | `src/v2/core/contracts.js` | Validation, normalization, enum guards, canonical DocumentIR |
| Layout | `src/v2/layout/` | Measurement, galleys, column bands, multicol balance, seams/glue, calibration |
| Compiler | `src/v2/compiler/geometry-compiler.js`, `src/v2/compiler/v3/` | Page/band/column placement, integer-millipoint V3 baseline engine (`frame`, `atoms`, `galley`, `solver`, `glue`, `decorate`), pagination, diagnostics, multi-page TOC, chrome |
| Modules | `src/v2/modules/` | Tables, math, images, TOC, chrome, captions, image security |
| Drivers | `src/v2/drivers/pdfkit/`, `src/v2/drivers/typst/` | DisplayList → PDF bytes, or DisplayList → Typst source → PDF |
| Fonts | `src/v2/fonts/` | Font assets, AFM fallback, shaping/measurement |
| Templates | `src/v2/templates/` | Pure template tokens and legacy `renderWithTemplate` |
| QA & Guardrails | `src/v2/qa/`, `scripts/design_guardrails.py` | Verify matrix, span predicates, and deterministic CSS/design-system audit CLI |
| Worker | `src/_worker.js` | Edge routes, embedded font/AFM assets, PDFKit render, proxy, cache |
| Build | `scripts/build-cloudflare.js` | Generate embedded data modules and bundle `dist/` |

## Canonical data flow

### 1. Browser state to request

`DocumentStore` holds one workspace:

```js
{ v: 2, boxes: [...], globals: {...} }
```

`ExportPayloadBuilder.build(store, overrides)` filters ignored/empty boxes, assembles `sections`, forwards the global settings, locks `engine: 'v2-modular'`, and sets `geometry: 'v3'` by default so browser preview, export, and live TOC pagination use the V3 vertical engine. See [03-INPUT.md](03-INPUT.md) for the field contract.

### 2. Transport

- Node: `POST /api/convert`, `/api/paginate`, `/api/upload-image`, `/api/convert-v2` (staging), `GET /api/health`.
- Worker: the same core routes except `/api/convert-v2`; it also proxies `/api/convert` and `/api/paginate` to `PDF_BACKEND_URL` when configured.

The Worker is not a second layout implementation. It imports the same contracts and `emitPdf` driver, with embedded font assets.

### 3. Normalize and validate

`normalizeToDocIR(payload)` maps `sections` or `blocks` into canonical blocks, applies defaults, and canonicalizes aliases. `validateDocIR(doc)` rejects malformed structures before layout. The normalized object is the **DocumentIR**; the compiler does not depend on the raw HTTP payload.

The public facades then forward compile-relevant fields that are not part of DocumentIR (TOC intent, document title/subtitle, caption mode, flush/balance/split controls) through `resolveCompileOptions(payload)` or the driver options. This two-layer design is intentional: DocumentIR is structural, while presentation controls are compile options.

### 4. Layout

`GeometryCompiler.compile(docIR, compileOpts)` is pure layout:

- Creates pages and optional TOC.
- Compiles each block (masthead, headings, paragraphs, lists, tables, images, math, rules).
- Places items into bands and columns or panoramic runs.
- Splits overflow and records seams.
- Runs the glue/vertical-justification post-pass.
- Stamps running chrome, page numbers, anchors, and TOC.
- Returns a DisplayList plus diagnostics/audits.

The compiler MUST NOT call a driver, read files, fetch URLs, or mutate the input. Image bytes are pre-resolved by the facade and passed as an image map.

### 5. Freeze and emit

`freezeIR(displayList)` deep-freezes the display list, excluding binary buffers. `assertDriverPurity` rejects AST nodes, closures, and non-IR payloads. The PDFKit driver measures with the same fonts it renders and blasts the list to PDF. The Typst driver emits `.typ` source and shells out to the Typst CLI.

### 6. Return

- `/api/convert`: PDF bytes, with `X-Engine-Used`, `X-Geometry-Version` (`v3` or `v2`), `X-Document-TOC`, and `X-Total-Pages` when the renderer returns pagination metadata.
- `/api/paginate`: When `geometry: 'v3'` (browser default), runs the exact compiler pagination pass and returns `{ success, totalPages, hasToC, chaptersToc, tocPage, tocPages, geometry: 'v3', sections: [{ index, name, title, startPage, bodyPage, headings }], durationMs }`. When `geometry` is omitted or `'v2'`, returns the fast coarse estimate `{ success, totalPages, sections, estimated: true, metrics, durationMs }`.
- Worker `/api/convert` and `/api/paginate`: Forward all compile options via `resolveWorkerCompileOptions(body)`, expose `X-Geometry-Version`, and run the same exact V3 pagination pass when `geometry === 'v3'`.

Exact response shapes and headers are in [05-OUTPUT.md](05-OUTPUT.md).

## Runtime variants

| Capability | Node (`server.js`) | Cloudflare Worker (`src/_worker.js`) |
| --- | --- | --- |
| Default driver | PDFKit | PDFKit |
| Typst | Yes, if binary installed | No |
| `/api/convert-v2` staging | Yes | No |
| `/api/upload-image` | Writes to `static/uploads/` | Returns a data URI, no disk |
| Remote image fetch | Yes, with SSRF guards | No; only embedded PNG/JPEG data URIs |
| Payload limit | 2,000,000 raw characters | 150,000 text characters, 30 sections, 25 MB wire |
| CORS | `CORS_ORIGINS` or open fallback | Always `*` |
| Rate limits | In-memory per process | None |
| Cache | None | Edge cache for `/api/convert` (10 MB, 600 s) |
| Backend offload | N/A | `PDF_BACKEND_URL` proxy |

## State ownership

| State | Owner | Notes |
| --- | --- | --- |
| Boxes, globals, editor preferences | Browser `DocumentStore` | Persisted in `localStorage` under `doe-v2-new-v1` and related keys |
| Uploaded images | Node filesystem `static/uploads/` | Served statically; not part of the repository |
| Rate-limit counters | Node process memory | Reset on restart; not shared across processes |
| Render cache | Worker `caches.default` | Keyed by stable body hash and engine revision |
| Generated PDFs | Caller | Streamed/downloaded; not stored by the server |

There is no database, session store, or server-side document model.

## Dependency rules

- `src/v2/compiler/` and `src/v2/layout/` must not import `src/v2/drivers/`, `static/`, `server.js`, or `src/_worker.js`.
- Drivers may import the compiler only where the facade contract requires it (`pdfkit/driver.js` compiles a DocIR for its `emit` path). Drivers must not mutate the DisplayList or depend on browser state.
- `src/v2/core/` must remain dependency-light and runtime-neutral.
- `src/v2/qa/` may import tests and probes; it is not part of the production request path.
- The browser may not import `src/` modules. Keep shared logic in `static/` or duplicate the small contract deliberately.
- `pdf-generator.js` is a compatibility facade. New code should use `pdf-engine.js` or the pipeline directly.

## Generated artifacts

| File | Status | Rebuild |
| --- | --- | --- |
| `src/afm-data.js` | Generated, committed | `npm run build` reads `node_modules/pdfkit/js/data` |
| `src/font-assets-data.js` | Generated, gitignored | `npm run build` embeds nine font faces |
| `dist/` | Generated, gitignored | `npm run build` |
| `static/uploads/` | Runtime data, gitignored | Created by `server.js`; never commit |
| `node_modules/` | Install output, gitignored | `npm ci` |

Do not hand-edit generated data modules. `src/afm-data.js` is committed because the local PDF path and Worker bundle expect it; `src/font-assets-data.js` is deliberately not committed because it is large and reproducible from `assets/fonts/`.

## Known seams

These are current architectural facts a maintainer should know, not TODOs:

- The browser keeps Markdown in `box.markdown` and in per-card editor adapters. `flushAdaptersToStore()` is load-bearing; an adapter mismatch can discard edits.
- `readGlobalsFromUI()` reads every settings control on each change and writes all globals. Missing DOM can overwrite stored values.
- When `geometry: 'v3'` is passed (the browser default via `ExportPayloadBuilder`), both `/api/paginate` and `/api/convert` (via `X-Document-TOC`) return exact compiler pagination (`totalPages`, `tocPages`, 1-based `sections[].index`, `name`, `startPage`, `bodyPage`, `headings[]`), and `static/v2-app.js` updates `lastPaginationData` on both live paginate and full preview/download. Legacy callers that omit `geometry` on `/api/paginate` still receive the coarse `calculatePagination` estimate.
- CSS ownership is split across `static/design-system.css` and `static/shell.css`, governed by `DESIGN.md` and `design-guardrails.config.json`:
  - `static/design-system.css` declares the 3-layer token hierarchy (`:root` primitive palette `--primitive-*`, semantic `:root, html[data-theme="light"]` and `html[data-theme="dark"]` blocks referencing `var(--primitive-*)` with zero raw hex/rgba literals, and component rules), global `4px` structural grid (`--space-xs: 4px`, `--space-md: 8px`), closed border-radius scale (`[0, 4, 8, 12, 16, 9999]px`), and in-flow `.rich-composer` pill (`position: relative; display: inline-flex; align-self: center; width: fit-content`).
  - `static/shell.css` loads after `static/design-system.css` and defines the two-column workspace shell, `100dvh`/`82dvh` dynamic viewport bounds, `@media (hover: hover)` pointer guards, `>= 48px` mobile bottom action bar targets, and unified `#sheet-body` mobile action items (`#sheet-body #add-box-btn .btn-long { display: inline; }`).
- `/api/convert-v2` is a staging surface with a separate Typst/autobalance path. It is not part of the default product flow.
- Both `server.js` (`resolveCompileOptions`) and `src/_worker.js` (`resolveWorkerCompileOptions`) now forward presentation compile options (`chapters_toc`, `toc_title`, `toc_include_headings`, `doc_title`, `doc_subtitle`, `image_captions_enabled`, `balance_columns`, `clean_spans`, `split_list_items`, `flush_columns`, `split_equations`, `geometry`) to the compiler.
- The Worker cache key strips image payloads; two requests with identical text and different embedded images can collide for the cache TTL. See [06-OPERATIONS.md](06-OPERATIONS.md).

When changing any of these, update this section rather than leaving the next maintainer to rediscover it.
