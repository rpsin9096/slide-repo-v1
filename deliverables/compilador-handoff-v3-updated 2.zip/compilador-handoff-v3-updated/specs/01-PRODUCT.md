# 01 — Product

## Identity

**Compilador do Raul** is the product name and must not be rebranded in this handoff. The npm package is `compilador-raul`; the Cloudflare Worker keeps its historical deployment name `doe-formatter` so an existing deployment is not renamed by accident.

The product is a local-first editor and compiler for long-form study material. It turns structured Markdown into print-oriented A4 PDFs with editorial layout: columns, running headers, mastheads, a table of contents, tables, figures, equations, and deterministic page geometry.

## Problem

The author writes dense study notes in Markdown, usually in Portuguese, and needs a PDF that reads like a designed study handout rather than a browser printout. Generic Markdown-to-PDF tools do not handle two-column bands, panoramic tables, stratified headings, vertical justification, or repeated running chrome. This project does.

The generated PDF is the primary artifact. The browser editor exists to make the source and its layout controls usable without hand-editing JSON.

## Users and jobs

| User | Job |
| --- | --- |
| Author/editor | Write or paste Markdown, arrange blocks, choose a template, preview, and download a PDF |
| Maintainer/operator | Install, run, test, build, deploy, and diagnose the compiler |
| Recipient of this handoff | Run the project now; later rebuild or extend it from the specs and tests |

There is one workspace and one document at a time. This is a single-user tool, not a collaborative product.

## Core workflow

1. The browser loads a workspace from `localStorage` (`doe-v2-new-v1`) or seeds a first block.
2. The author edits one or more **blocks** (chapters/sections), each with its own Markdown string and optional per-block overrides.
3. Global settings choose a template, language, columns, table behavior, header/footer, TOC, and typography controls.
4. **Pré-visualizar** sends a preview request; **Gerar PDF** sends a full request.
5. The server normalizes the payload into a DocumentIR, compiles it to a display list, and renders PDF bytes.
6. The browser shows the PDF in an iframe or downloads it as `document-<engine>.pdf`.

The local Node server and the Cloudflare Worker expose the same core conversion intent but not identical capabilities. See [02-ARCHITECTURE.md](02-ARCHITECTURE.md) and [06-OPERATIONS.md](06-OPERATIONS.md).

## Product principles

- **Content first.** Markdown is the source of truth; rich-text editing is a convenience layer over the same Markdown.
- **Print geometry is deterministic.** The same input, seed, and timestamp produce the same layout. The engine quantizes geometry and freezes the display list.
- **Layout is explicit.** Columns, bands, spans, and glue are modeled, measured, and audited rather than left to a browser.
- **Fail honestly.** Unsupported images, invalid payloads, overflow, and impossible fit gates produce diagnostic information instead of silent corruption.
- **Local-first.** The default path runs on one machine with no account, database, or cloud dependency. Deployment is optional.
- **One product name.** Portuguese UI labels and domain terms stay in Portuguese; the documentation is English.

## Scope

In scope:

- Browser editor and document store.
- Markdown ingest, normalization, and DocumentIR validation.
- Deterministic layout compiler and PDFKit driver.
- Optional Typst driver and staging endpoint.
- Node/Express API and Cloudflare Worker API.
- Static assets, fonts, build scripts, fixture probes, and tests.
- The corpus and fixtures needed to prove layout behavior.

Out of scope:

- Authentication, authorization, tenancy, user accounts, or collaboration.
- Cloud storage, sync, revision history, or a document database.
- DOCX, HTML, or EPUB import.
- A pixel-perfect WYSIWYG canvas; the editor is Markdown-first with a structured rich mode.
- A general-purpose publishing system, CMS, or analytics product.
- Guaranteed accessibility conformance of the editor or generated PDFs. The editor has ARIA labels and keyboard paths; the PDFs are not tagged-PDF compliant.
- Backups of user content. The browser store is local; clearing site data removes it.

## Templates

The three template IDs are stable API values. Their exact metrics, colors, and heading treatments belong to [04-LAYOUT.md](04-LAYOUT.md).

| UI name | ID | Character | Typical use |
| --- | --- | --- | --- |
| Minimalist | `base` | Swiss editorial clean; restrained rules and graphite accents | Dense text where the content should dominate |
| Modern | `bauhaus` | Linear studio/tech; sapphire accent, pill badges, cards | Mixed text, tables, and figures with more visual structure |
| Compact | `bauhaus_minimalist` | High-density engineering; smaller type, tighter leading, teal accent | Maximum content per page; reference sheets and revision material |

Template choice affects typography, spacing, heading decoration, table chrome, TOC styling, and color. It does not change the input contract.

## Language

The default document language is Portuguese (`pt`). Spanish (`es`) and English (`en`) are accepted for language-sensitive behavior. The editor UI is Portuguese. Domain terms such as **masthead**, **bloco**, **sumário**, **cabeçalho**, **rodapé**, **coluna**, **panorâmica**, and **girada** should remain recognizable in the product even when the surrounding documentation is English.

Language detection is heuristic. Do not assume it is a full hyphenation or spell-check system; see [04-LAYOUT.md](04-LAYOUT.md) for what is actually wired.

## Glossary

These definitions are canonical. Other specs use the terms without redefining them.

| Term | Meaning |
| --- | --- |
| **DocumentIR** | The normalized, validated document object consumed by the compiler. Its structural shape is defined by `src/v2/core/contracts.js` and summarized in [03-INPUT.md](03-INPUT.md). |
| **Block** | A chapter-like unit with a title, a Markdown string, optional masthead, flags, table layout, and column override. The UI calls these cards/blocos. |
| **Section** | The public API name for a block in `sections[]`; `blocks[]` is also accepted. |
| **Template** | A named set of page geometry, typography, colors, and chrome rules: `base`, `bauhaus`, or `bauhaus_minimalist`. |
| **Masthead** | The per-block banner area carrying prefix, course, topic, and optional header text. Not the running page header. |
| **Running chrome** | The repeated page header/footer: running title, optional date, and page number. |
| **Band** | A horizontal slice of a page. A band has one or two columns that hang from the same top. |
| **Column** | A vertical text region inside a band. The engine supports one or two columns and a full-width panorama run. |
| **Span / panoramic** | An element that occupies the full printable width across columns, usually a wide table or a full-page figure. |
| **Glue / seam** | The vertical slack between adjacent layout items. A seam records where a page may stretch and how much it may move. |
| **Vertical justification / flush** | The post-pass that distributes bounded slack so applied pages bottom near the content foot. “Encaixar pé da página” is the UI control. |
| **DisplayList** | The frozen, driver-independent page/element output of the compiler (`2.1.0` in legacy v2 mode, `2.2.0` in the frontend-default `geometry: 'v3'` mode). It contains no AST nodes or closures. |
| **Driver** | The emitter that turns a DisplayList into bytes or source: PDFKit, Typst, or a custom registered driver. |
| **TOC / sumário** | The optional table of contents, rendered on 1 or more dynamically reserved front pages (`tocPages`) with section and heading entries. |
| **Corpus** | The fixed Markdown documents in `tests/corpus/` used as layout evidence. |
| **Fixture** | A frozen JSON or script used to lock a measurement, diagnostic, or visual rule. |
| **Lean test** | A `node:test` file in `tests/lean/` that exercises behavior without a browser. |
| **Design lock** | A source/CSS assertion in `tests/design/` that protects an exact visual token or structure. It is a tripwire, not a rendered-pixel test. |
| **Verify suite** | The nine hard-number acceptance suites in `src/v2/qa/verify-suite.js`. |

## Quality bar

A change is acceptable when:

- `npm run lint` passes.
- `npm test` passes, including the verify suites and lean behavior tests.
- `npm run test:design` passes when the change touches editor markup, CSS, or design tokens.
- A converted PDF has no content past the region foot, no empty page, and no stranded heading or empty right column where the layout gates forbid it.
- The change updates the owning spec and the alterations log.
- No secret, personal artifact, session note, screenshot, generated bundle, or uploaded file is introduced into the repository.

## Handoff success

The recipient should be able to:

1. `npm ci && npm run dev` and convert a document at `http://localhost:3000`.
2. `npm test` and `npm run test:design` and see green.
3. `npm run build` and deploy the Worker with their own Cloudflare account.
4. Read `specs/00-INDEX.md`, find the owning spec for a change, and know which tests are evidence.
