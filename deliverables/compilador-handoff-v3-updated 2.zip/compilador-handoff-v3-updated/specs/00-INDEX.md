# 00 — Specification Index

This directory is the normative system specification for **Compilador do Raul**. It describes the current, runnable system, not the historical development plan.

**Last verified:** 2026-10-26, against the V3 Layout & Geometry + Wave 11 Frontend Design Guardrails + Spec 10 Google AI Workspace Port + atomic-list-balance deploy snapshot.
**Status of code:** `npm test` (9/9 verify + 327/327 lean), `npm run test:design` (38/38 design across 9 suites), `python3 scripts/design_guardrails.py --config design-guardrails.config.json --audit-all static --document DESIGN.md` (`AUDIT_ALL_PASS`), and `node scripts/probe-geometry-baseline.mjs --geometry v3 --gate all --verify-v2-fixture` (`ALL_VG_GATES=PASS`, `V2_FIXTURE_ROWS=157 V2_FIXTURE_DIFFS=0`) pass on that date.

## How to read

1. Read [01-PRODUCT.md](01-PRODUCT.md) for purpose, vocabulary, and scope.
2. Read [02-ARCHITECTURE.md](02-ARCHITECTURE.md) for the component map and data flow.
3. Read [../DESIGN.md](../DESIGN.md) and [09-FRONTEND-FINETUNING-V3.md](09-FRONTEND-FINETUNING-V3.md) for the frontend visual design system, 3-layer CSS token architecture, 4px structural grid, WCAG 2.1 AA contrast ratios, and multi-viewport responsive rules.
4. Read [10-GOOGLE-AI-WORKSPACE-PORT.md](10-GOOGLE-AI-WORKSPACE-PORT.md) for the Google AI Studio Build Mode full-stack/isomorphic port architecture and the 9 compatible file formats (`.compilador.md`, `.compilador.json`, `.pdf`, Google Docs, Google Sheets/CSV, `.docx`, `.typ`, `.html`, raster figures).
5. Read the spec that owns the behavior you are changing.
6. Use [07-TESTING.md](07-TESTING.md), [08-LAYOUT-GEOMETRY-V3.md](08-LAYOUT-GEOMETRY-V3.md), [09-FRONTEND-FINETUNING-V3.md](09-FRONTEND-FINETUNING-V3.md), and [10-GOOGLE-AI-WORKSPACE-PORT.md](10-GOOGLE-AI-WORKSPACE-PORT.md) to choose the evidence required for the change.
7. Follow [../AGENTS.md](../AGENTS.md) for the change protocol.

## The set

| Spec | Owns | Does not own |
| --- | --- | --- |
| [01-PRODUCT.md](01-PRODUCT.md) | Product identity, users, workflow, scope, non-goals, glossary, templates at product level | Request field schemas, algorithms, deployment commands |
| [02-ARCHITECTURE.md](02-ARCHITECTURE.md) | Component boundaries, data flow, module map, runtime variants, dependency rules, generated artifacts | Field-level contracts, layout math, endpoint payload details |
| [03-INPUT.md](03-INPUT.md) | Public request envelope, normalization, aliases, defaults, limits, Markdown grammar, input errors | Layout results, PDF rendering, deployment |
| [04-LAYOUT.md](04-LAYOUT.md) | Page model, templates, bands, columns, spans, glue, pagination, headings, tables, images, chrome, diagnostics | Transport formats, API status codes, test commands |
| [05-OUTPUT.md](05-OUTPUT.md) | DisplayList/IR shape, purity, PDF drivers, fonts, response headers, pagination JSON, output guarantees | Input normalization, layout decisions, build/deploy steps |
| [06-OPERATIONS.md](06-OPERATIONS.md) | Local run, environment variables, build, deploy, Worker differences, security, troubleshooting, smoke tests | Product behavior, layout internals, test fixture policy |
| [07-TESTING.md](07-TESTING.md) | Test tiers, commands, verify suites, lean/design catalogs, fixtures, corpus, regeneration, coverage gaps | Feature requirements, implementation algorithms |
| [08-LAYOUT-GEOMETRY-V3.md](08-LAYOUT-GEOMETRY-V3.md) | V3 baseline-first integer-mpt geometry, 3-layer token hierarchy, container splitting, deferred-span re-solve, single-authority glue, DisplayList 2.2.0, `VG-0`..`VG-17` acceptance gates | Legacy v1 monolith, unrelated UI CSS rules |
| [09-FRONTEND-FINETUNING-V3.md](09-FRONTEND-FINETUNING-V3.md) | Wave 11 frontend finetuning (`gate-1`..`gate-7`), 3-layer CSS token graph (`--primitive-* -> --color-* -> component`), WCAG 2.1 AA contrast matrix, `4px` structural grid, closed radius scale, 9-viewport Chromium CDP inspection & fixes | Backend PDF geometry math, server API payloads |
| [10-GOOGLE-AI-WORKSPACE-PORT.md](10-GOOGLE-AI-WORKSPACE-PORT.md) | Google AI Studio Build Mode topology (`metadata.json`, `server/index.ts`, Web Worker fallback), Node-to-Isomorphic V3 seams, 9-format bidirectional compatibility matrix (`.compilador.md`, `.compilador.json`, `.pdf`, Google Docs, Google Sheets/CSV, `.docx`, `.typ`, `.html`, raster images), `@google/genai` server-side assist, `GW-0`..`GW-7` gates | Core V3 vertical math (`08-LAYOUT-GEOMETRY-V3.md`) |
| [11-COMPILER-EFFICIENCY-W12.md](11-COMPILER-EFFICIENCY-W12.md) | Wave 12 compiler hot-path optimizations, 3-tier incremental cache, and Cloudflare Workers Free Plan (< 10 ms warm CPU) compliance | Layout geometry semantics, request field schemas, deployment commands |
| [12-EDITORIAL-GEOMETRY-OVERHAUL-V2.md](12-EDITORIAL-GEOMETRY-OVERHAUL-V2.md) | Wave 13 Template-Aware Editorial Document Geometry, Fragmentation & Bottom-Padding Overhaul (v2.0): 96-DPI multi-unit/paper-preset resolver, 4-tier template hierarchy, dynamic `@page` injection, transitive heading/list-intro glue, atomic push-downs, rowspan-safe table/list continuation splitting, framed-safe `.is-page-bottom`, and 6-gate DOM audit (`verifyTemplateEditorialGeometry`) | Server PDFKit vector emission, Worker isolate LRU caches |
| [../DESIGN.md](../DESIGN.md) | Normative 9-section Design Guardrails v3.0 system contract paired with `design-guardrails.config.json` | Backend PDF geometry math, server API payloads |

## Source-of-truth rules

- **Code is current behavior.** A spec describes the code that exists in this snapshot. If they disagree, the disagreement is a defect: fix the code or the spec in the same change, and record it in `ALTERATIONS.md`.
- **Specs are normative for intent.** Do not silently change a documented invariant to make a test pass. If the invariant is wrong, change the owning spec and explain why.
- **Facts live in one place.** If a fact belongs to another spec, link to it instead of copying it. In particular: request fields live in 03, layout rules in 04 and 08, output shapes in 05, commands in 06, test evidence in 07, frontend design tokens/guardrails in 09, `DESIGN.md`, and `design-guardrails.config.json`, and Google AI Studio / Workspace port contracts in 10.
- **Generated files are not hand-edited.** `src/font-assets-data.js` and `dist/` are generated. `src/afm-data.js` is generated but committed because the local PDF path and Worker bundle expect it. Rebuild with `npm run build`.
- **The test corpus is evidence.** `tests/corpus/` documents are fixed inputs for layout gates. Changing one changes the measured geometry and may require a reviewed golden update; see 07.

## Change protocol

Every behavior change should include:

1. The implementation change.
2. The owning spec update, if behavior or intent changed.
3. A test that would fail before the change and pass after it, or a documented reason why no executable test is practical.
4. An append-only entry in [../ALTERATIONS.md](../ALTERATIONS.md) with date, change, reason, and verification.
5. A verification run appropriate to the surface: `npm test`, plus `npm run test:design` and `python3 scripts/design_guardrails.py --config design-guardrails.config.json --audit-all static --document DESIGN.md` for UI/CSS changes.

If a change is intentionally breaking, say so in the spec and the alterations entry. Do not leave a stale “TODO” in place of a decision.
