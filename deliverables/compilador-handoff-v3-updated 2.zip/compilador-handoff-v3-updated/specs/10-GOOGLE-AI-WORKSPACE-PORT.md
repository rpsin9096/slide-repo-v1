# 10 — Google AI Studio App Builder & Google Workspace High-Fidelity Port Specification

| Field | Value |
| --- | --- |
| **Status** | **Normative Port & Format Interoperability Specification (v1.0 — FocusGate v1.0 + Design-Guardrails v3.0 Governed).** |
| **Date** | 2026-10-25 |
| **Basis** | Compilador do Raul V3 Handoff (`npm test`: 9/9 verify + 311/311 lean; `npm run test:design`: 38/38 pass across 9 suites; `VG-0`..`VG-17`: 18/18 pass; `gate-1`..`gate-7`: 7/7 settled) |
| **Target Platform** | **Google AI Studio Build Mode** (`aistudio.google.com` Antigravity Full-Stack React + Node.js/Cloud Run runtime + Client-Side Web Worker fallback) & **Google Workspace APIs** (Google Drive v3, Google Docs v1, Google Sheets v4, Google Picker) |
| **Owns** | AI Studio project structure (`metadata.json`, `package.json`, `server/index.ts`, `src/`), Node-to-Isomorphic V3 compiler seams, 9-format bidirectional import/export specification (`.compilador.json`, `.md`, `.pdf`, Google Docs, Google Sheets/CSV, `.docx`, `.typ`, `.html`, raster images), server-side `@google/genai` integration, and `GW-0`..`GW-8` acceptance gates |
| **Preserves 100%** | V3 integer-millipoint (`1 pt = 1000 mpt`) vertical geometry (`08-LAYOUT-GEOMETRY-V3.md`), Wave 11 3-layer CSS token system & `4px` structural grid (`09-FRONTEND-FINETUNING-V3.md`, `DESIGN.md`), and all 38 visual design locks (`W1`–`W11`) |

Keywords **MUST / SHOULD / MAY** are used in the RFC 2119 sense. Every requirement pairs an explicit file/module contract with a verifiable **FocusGate** `CHECK:` and `EXPECT:` oracle.

---

## 0. Domain Anchors (FocusGate Micro-Glossary)

1. **AI Studio Full-Stack Bundle (`AIStudioApp`)**: The canonical Google AI Studio Build Mode project topology combining a browser frontend (`index.html`, `src/`), a `metadata.json` capability manifest, and an integrated Node.js server runtime (`server/index.ts` deployed to Google Cloud Run) with `process.env.GEMINI_API_KEY` and automatic Google Workspace OAuth provisioning.
2. **Isomorphic V3 Engine (`IsomorphicPipeline`)**: The pure ES-module subset of `src/v2/` (`contracts`, `ingest`, `layout`, `compiler/geometry-compiler.js`, `compiler/v3/*`, `drivers/pdfkit`, `drivers/typst/emitter.js`) bound to `createEmbeddedFontAssets(FONT_ASSETS)` and the `AFM_DATA` virtual-FS shim so identical `DisplayList 2.2.0` and PDF bytes are produced in both the AI Studio Node server (`server/index.ts`) and a browser Web Worker (`src/workers/compiler.worker.ts`).
3. **Round-Trip Markdown Envelope (`.compilador.md`)**: A standard UTF-8 Markdown file (`text/markdown`) enriched with YAML frontmatter (for `store.globals`) and non-rendering HTML comment fences (`<!-- @box {"id":"...","title":"...","kind":"text","masthead":{...},"flags":{...}} -->`) that opens natively in any Markdown editor or Google Docs while restoring 100% of multi-box `DocumentStore` state on re-import.
4. **Workspace Document Bridge (`WorkspaceBridge`)**: The bidirectional translator between `DocumentStore` / `DisplayList 2.2.0` and Google Workspace file formats (`application/vnd.google-apps.document` via Docs API v1, `application/vnd.google-apps.spreadsheet` via Sheets API v4, and `application/pdf` / `.compilador.json` via Drive API v3).
5. **Server-Side Gemini Assist (`GeminiEditorialService`)**: A strictly server-side (`server/index.ts`) `@google/genai` service (`gemini-2.5-flash` / `gemini-2.5-pro`) that executes structured editorial actions (table extraction, typographic normalization, heading hierarchy audit, LaTeX math repair) without ever exposing `GEMINI_API_KEY` to the browser bundle.

---

## 1. Executive Architecture & Dual-Runtime Topology

Google AI Studio Build Mode executes web applications in a **dual-tier container** (a Vite/React frontend paired with a Node.js backend deployed to Cloud Run, plus optional static/offline export). To guarantee 100% layout, typographic, and visual fidelity across both hosted Cloud Run deployments and standalone/offline browser previews, the port uses a **Dual-Runtime Isomorphic Topology**:

```text
┌──────────────────────────────────────────────────────────────────────────────┐
│ Browser Client (Google AI Studio Preview / Cloud Run Web App)                │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐  │
│  │ Compilador Studio Shell (DESIGN.md 3-Layer CSS + 4px Grid, W1–W11)     │  │
│  │  • DocumentStore (v:2 boxes + globals, localStorage + Drive Auto-Sync) │  │
│  │  • EditorAdapter Seam: TextareaAdapter (Markdown) + BlockEditor (Rich) │  │
│  │  • Workspace Import/Export Modal (Drive Picker, .md, .docx, .json)     │  │
│  └───────────────┬────────────────────────────────────────┬───────────────┘  │
│                  │ Primary: HTTP JSON                     │ Fallback / Local │
│                  ▼ (when server/index.ts active)          ▼ (offline/static) │
│  ┌───────────────────────────────┐        ┌───────────────────────────────┐  │
│  │ AI Studio Node Server Runtime │        │ Browser Web Worker Runtime    │  │
│  │ (server/index.ts — Cloud Run) │        │ (src/workers/pdf.worker.ts)   │  │
│  │  • /api/convert (PDF/Typst)   │        │  • In-memory AFM_DATA shim    │  │
│  │  • /api/paginate (V3 exact)   │        │  • Embedded FONT_ASSETS       │  │
│  │  • /api/workspace/* (OAuth)   │        │  • Pure V3 GeometryCompiler   │  │
│  │  • /api/ai/* (@google/genai)  │        │  • PDFKit Blob Stream         │  │
│  └───────────────┬───────────────┘        └───────────────┬───────────────┘  │
│                  └───────────────────┬────────────────────┘                  │
│                                      ▼                                       │
│            ┌───────────────────────────────────────────────────┐             │
│            │ Shared Isomorphic V3 Core (src/v2/)               │             │
│            │  normalizeToDocIR -> validateDocIR                │             │
│            │  -> GeometryCompiler (geometry: 'v3', integer mpt)│             │
│            │  -> freezeIR (DisplayList 2.2.0)                  │             │
│            │  -> Drivers: PDFKit | Typst | Google Docs | HTML5 │             │
│            └───────────────────────────────────────────────────┘             │
└──────────────────────────────────────────────────────────────────────────────┘
```

### Architectural Invariants
1. **Zero Visual or Behavioral Regression**: Rather than rewriting the tested DOM controller (`static/v2-app.js`), rich block editor (`static/editor-core.js`), or CSS (`static/design-system.css`, `static/shell.css`) into synthetic Tailwind/JSX approximations that would break the 38 `W1`–`W11` design locks, the AI Studio port mounts the exact `Compilador Studio` DOM template inside a thin React 19 host (`src/App.tsx`) and loads `design-system.css` + `shell.css` verbatim.
2. **Single-Source V3 Geometry (`geometry: 'v3'`)**: Both the Node server (`server/index.ts`) and the client Web Worker (`src/workers/pdf.worker.ts`) execute the exact same `src/v2/compiler/geometry-compiler.js` and `src/v2/compiler/v3/{frame,atoms,galley,solver,glue,decorate}.js` modules in integer millipoints (`1 pt = 1000 mpt`), preserving `VG-0`..`VG-17` and the 157-row `vertical-justify.json` lock.
3. **Server-Only Credentials**: `process.env.GEMINI_API_KEY` and Google Workspace OAuth tokens are accessed exclusively inside `server/index.ts` (or via AI Studio's managed Workspace OAuth connector), never embedded in client bundle code.

---

## 2. Google AI Studio Build Mode File Tree & Module Mapping

Google AI Studio Build Mode expects a standard root structure with `metadata.json`, `package.json`, `index.html`, `src/`, and `server/`. Every file from `compilador-handoff-v3` maps deterministically into this structure:

```text
compilador-aistudio-workspace/
├── metadata.json                          # AI Studio capability & frame permission manifest
├── package.json                           # React 19, Express, @google/genai, pdfkit, googleapis
├── tsconfig.json                          # TypeScript configuration (allowJs: true, checkJs: false)
├── vite.config.ts                         # Vite bundler with /api proxy to server/index.ts
├── index.html                             # Studio root HTML + inline SVG sprite (#i-doc..#i-redo)
├── DESIGN.md                              # Normative 9-section Design Guardrails v3.0 contract
├── design-guardrails.config.json          # Machine-readable guardrail thresholds (spacing_base: 4)
├── server/
│   ├── index.ts                           # Express API: /api/convert, /api/paginate, /api/workspace/*, /api/ai/*
│   ├── gemini-assist.ts                   # @google/genai server-side editorial assistant
│   └── workspace-bridge.ts                # Google Drive v3, Docs v1, Sheets v4 import/export adapters
├── src/
│   ├── index.tsx                          # React 19 entry point
│   ├── App.tsx                            # Thin React host mounting the canonical Studio DOM + Workspace modals
│   ├── styles/
│   │   ├── design-system.css              # Verbatim Wave 11 3-layer token system (--primitive -> --color -> component)
│   │   └── shell.css                      # Verbatim Wave 11 responsive shell (100dvh, 82dvh, 48px touch targets)
│   ├── studio/
│   │   ├── document-store.js              # Verbatim DocumentStore + .compilador.md / Drive sync hooks
│   │   ├── editor-core.js                 # Verbatim BlockEditor & BlockStore (Rich mode)
│   │   ├── editor-adapters.js             # Verbatim TextareaAdapter & isEditorAdapter contract
│   │   ├── export-payload.js              # Verbatim ExportPayloadBuilder (geometry: 'v3' default)
│   │   ├── format-converters.js           # Client-side .compilador.md, .csv, .html, .docx converters
│   │   └── v2-app.js                      # Studio controller wired with Workspace & Local Worker fallback
│   ├── workers/
│   │   └── pdf.worker.js                  # Isomorphic browser Web Worker running V3 pipeline + PDFKit
│   ├── afm-data.js                        # Committed PDFKit AFM font metrics & ICC profile map
│   ├── font-assets-data.js                # Base64-inlined Arimo, Inter, and NotoEmoji TTF faces
│   └── v2/                                # Shared V2/V3 Compiler Core (identical to compilador-handoff-v3/src/v2)
│       ├── core/                          # ast-schema, clock, contracts, date, display-list, events, geometry, tokens
│       ├── ingest/                        # from-markdown, lang, sanitizer, schema, serialize
│       ├── layout/                        # atom, box, column-band, coordinator, galley-engine, glue-allocator, ...
│       ├── compiler/
│       │   ├── geometry-compiler.js       # V2/V3 GeometryCompiler
│       │   └── v3/                        # frame.js, atoms.js, galley.js, solver.js, glue.js, decorate.js, index.js
│       ├── modules/                       # chrome-module, image-module (isomorphic), math-module, table-module, toc-module
│       ├── fonts/                         # assets (isomorphic), catalog, emoji, metrics, shaping (isomorphic)
│       ├── templates/                     # base, bauhaus, minimal, chrome, definitions, themes
│       ├── drivers/                       # pdfkit/{blaster,driver}, typst/{compile,emitter,md}, google-docs/emitter.js
│       └── runtime/                       # pipeline.js, pool.js
└── tests/
    ├── lean/                              # All 60 lean test suites + workspace-formats.lean.js
    └── design/                            # All 9 design suites (visual-w1..visual-w11)
```

### 2.1 `metadata.json` Contract (Google AI Studio Build Mode)

```json
{
  "name": "Compilador do Raul — Studio Editorial & PDF V3",
  "description": "High-density Markdown & Rich-Text editorial studio with TeX-grade V3 two-column PDF compilation, Google Docs/Drive/Sheets bidirectional sync, and Gemini editorial assistance.",
  "requestFramePermissions": [
    "clipboard-read"
  ]
}
```

---

## 3. Compatible File Formats & Bidirectional Conversion Matrix

The port supports **9 compatible file formats** across local files and Google Workspace cloud resources. Every format maps through a deterministic schema converter into or out of `DocumentStore` (`{ v: 2, boxes, globals }`) and `DisplayList 2.2.0`:

| Format | MIME Type / Extension | Direction | Fidelity Tier | Conversion Contract & Metadata Preservation |
| --- | --- | --- | --- | --- |
| **1. Annotated Markdown (`.compilador.md` / `.md`)** | `text/markdown` (`.md`, `.markdown`) | **Import & Export (Lossless Round-Trip)** | **100% Lossless** | YAML frontmatter stores `globals` (`template`, `lang`, `columnLayout`, `tableLayoutMode`, `chaptersToc`, `docTitle`, `docSubtitle`, `geometry: v3`). Each card is preceded by `<!-- @box {"id":"...","title":"...","kind":"text","masthead":{...},"flags":{...},"tableLayout":null,"columns":null} -->`. Plain `.md` files without `@box` fences split into cards on top-level `# H1` boundaries (or load as a single card). |
| **2. Workspace Snapshot (`.compilador.json`)** | `application/json` (`.compilador.json`, `.json`) | **Import & Export (Lossless Native)** | **100% Lossless** | Exact serialized `{ v: 2, boxes: [...], globals: {...} }` JSON envelope matching `localStorage['doe-v2-new-v1']`. Supports local download/upload and direct save/open in Google Drive (`appProperties: { app: 'compilador-raul', schemaVersion: '2' }`). |
| **3. Typeset PDF (`.pdf`)** | `application/pdf` (`.pdf`) | **Export (Local Download + Save to Google Drive)** | **100% Print-Exact** | Emitted by `GeometryCompiler` (`geometry: 'v3'`) -> `DisplayList 2.2.0` -> `PDFKit Vector Blaster` with embedded `Arimo`, `Inter`, and `NotoEmoji` TTF subsets, optical cap-height/descender alignment (`<= 0.022 pt`), 2-column balancing, and multi-page clickable TOC. |
| **4. Google Docs (`gdoc`)** | `application/vnd.google-apps.document` | **Import & Export (Bidirectional API)** | **Semantic + Structural** | **Import**: `documents.get({ includeTabsContent: true })` maps document tabs or `HEADING_1` sections to `boxes[]`, paragraphs/lists to Markdown, Docs tables to GFM pipe tables (`kind: 'table'`), and inline images to base64 figure lines. **Export**: `documents.create` + `documents.batchUpdate` maps `DocumentIR` blocks, `1`/`2`-column section styles, callout shaded tables, and figures into a native Google Doc. |
| **5. Google Sheets & Delimited Tables (`gsheet`, `.csv`, `.tsv`)** | `application/vnd.google-apps.spreadsheet`, `text/csv`, `text/tab-separated-values` | **Import & Export (Table Blocks)** | **100% Tabular** | **Import**: Converts any Sheet tab (`spreadsheets.values.get`) or `.csv`/`.tsv` file into a `kind: 'table'` box with escaped pipes (`\|`) and automatic numeric right-alignment (`---:`). **Export**: Exports all `kind: 'table'` boxes (or the active table island) to a multi-tab Google Sheet or `.csv` download. |
| **6. Microsoft Word (`.docx`)** | `application/vnd.openxmlformats-officedocument.wordprocessingml.document` | **Import (Local or via Drive)** | **Semantic + Figures** | Parses `word/document.xml` paragraphs (`w:pStyle` `Heading1`..`Heading4`), character runs (`w:b`, `w:i`, `w:strike`, `w:vertAlign`), tables (`w:tbl`), and `word/media/*` relationships into canonical Markdown + downscaled base64 figures. |
| **7. Typst Source (`.typ`)** | `text/x-typst` (`.typ`) | **Export** | **100% Layout-Parity** | Emitted by `src/v2/drivers/typst/emitter.js` (`emitTypstSource(displayList)`), producing a standalone `.typ` source file with exact V3 page frame margins, template typography, 2-column bands, and table definitions. |
| **8. Standalone HTML5 Reader (`.html`)** | `text/html` (`.html`) | **Export** | **100% Interactive Web/Print** | Self-contained single-file HTML5 document embedding the Wave 11 3-layer CSS token sheet (`light` + `dark` toggle), interactive sidebar TOC with page badges (`lastPaginationData`), and `@page { size: A4; }` print rules. |
| **9. Raster Figures (`.png`, `.jpg`, `.webp`, `.gif`, `.bmp`)** | `image/png`, `image/jpeg`, `image/webp`, `image/gif`, `image/bmp` | **Import (Picker, Paste, Drag-Drop, Drive)** | **Normalized Raster** | Client-side `downscaleImageToDataUrl()` transcodes GIF/BMP/WebP/PNG/JPEG (`<= 1600px`, white-matte JPEG `q=0.82`) and emits `![alt](data:image/jpeg;base64,... "caption") {width=W place=P ratio=R}`. `.heic`/`.heif` fails fast with actionable conversion guidance. |

---

## 4. Node-to-Isomorphic Porting Seams (Exact Code-Level Specification)

In `compilador-handoff-v3`, `92%` of `src/v2/` is already pure ES module code with zero Node.js dependencies. Only **6 runtime files** import `node:*` built-ins. Below is the exact refactoring specification for each file so the entire V3 pipeline runs identically in Node (`server/index.ts`), Cloudflare Workers (`src/_worker.js`), and Browser Web Workers (`src/workers/pdf.worker.ts`):

### 4.1 Seam 1 — `src/v2/fonts/assets.js` (Remove Top-Level `node:fs` / `node:path`)
- **Current State**: Lines 13–15 import `node:fs`, `node:path`, and `node:url` at module top-level, which throws in browser/worker bundlers unless polyfilled.
- **Port Contract**:
  - Keep `createEmbeddedFontAssets(base64Map)` 100% free of `node:*` imports, decoding base64 strings into `Uint8Array` (wrapped in `Buffer.from(u8)` when `Buffer` is global or a lightweight `Uint8Array` subclass carrying `_fontFile = file`).
  - Make `createNodeFontAssets` lazy-resolve `node:fs` and `node:path` via dynamic `await import('node:fs')` or guarded `globalThis.process?.versions?.node` check so browser bundlers tree-shake it cleanly.

### 4.2 Seam 2 — `src/v2/fonts/shaping.js` (Isomorphic `fontkit` + `AFM_DATA` Injection)
- **Current State**: Uses `createRequire(import.meta.url)('fontkit')` and `fs.readFileSync` fallback.
- **Port Contract**:
  - Export `registerFontkit(fkInstance)` and `registerDefaultFontAssets(fontAssets)` so browser/worker runtimes can pass an ESM `fontkit` import and `createEmbeddedFontAssets(FONT_ASSETS)` at boot without touching `node:module` or `node:fs`.
  - Retain `AFM_DATA` (from `src/afm-data.js`) as the zero-I/O metric fallback whenever a standard PDF base-14 font (`Helvetica`, `Times-Roman`, `Courier`) is queried.

### 4.3 Seam 3 — `src/v2/drivers/pdfkit/blaster.js` (Browser Stream & Virtual AFM FS)
- **Current State**: Imports `node:fs`, `node:path`, `node:module`, `node:url` and streams `PDFDocument` chunks into `Buffer.concat(chunks)`.
- **Port Contract**:
  - Extract the 35-line `AFM_DATA` virtual-FS interceptor from `src/_worker.js` into a shared helper `src/v2/fonts/virtual-afm-fs.js` imported before `pdfkit`.
  - When `options.fontAssets` is not explicitly passed in browser/worker environments, default to `createEmbeddedFontAssets(FONT_ASSETS)` so `Arimo`, `Inter`, and `NotoEmoji` always resolve from memory.
  - Accumulate `doc.on('data', chunk)` into `Uint8Array` chunks and return a `Uint8Array` / `Buffer` compatible with both Node HTTP responses (`res.end(pdfBuffer)`) and browser `new Blob([pdfBytes], { type: 'application/pdf' })`.

### 4.4 Seam 4 — `src/v2/modules/image-module.js` (Isomorphic Data-URI & Fetch Resolver)
- **Current State**: Imports `node:fs`, `node:path`, `node:http`, `node:https` at top level for local `/uploads/*` and SSRF-guarded remote URL fetching.
- **Port Contract**:
  - Split `image-module.js` into:
    - `image-geometry.js` (pure, zero-dependency PNG/JPEG header parser, aspect-ratio box calculator, decompression-bomb guard `MAX_IMAGE_PIXELS = 25_000_000`, and `data:image/*;base64,...` decoder — usable in both Node and browser Web Workers).
    - `image-net-node.js` (Node-only `/uploads/*` disk reader and SSRF-guarded `http`/`https` + `node:dns` fetcher, loaded only by `server/index.ts`).

### 4.5 Seam 5 — `src/v2/layout/autobalance.js` & `src/v2/drivers/typst/compile.js`
- **Current State**: Both spawn the external `typst` CLI via `node:child_process` (`execFile` / `execFileSync`) for the legacy `/api/convert-v2` Typst driver.
- **Port Contract**:
  - Keep `src/v2/drivers/typst/emitter.js` and `src/v2/drivers/typst/md.js` (which are 100% pure string emitters with zero `node:*` imports!) in the isomorphic core so **Export `.typ`** works everywhere.
  - Isolate `compile.js` and `autobalance.js` behind server-only dynamic imports in `server/index.ts`.

---

## 5. Round-Trip File Format Specifications

### 5.1 Lossless Annotated Markdown (`.compilador.md`)

When the user clicks **Exportar `.md`** (or saves to Google Drive as Markdown), `format-converters.js` emits a valid Markdown file that any Markdown viewer renders cleanly, while embedding full `DocumentStore` fidelity in YAML frontmatter and HTML comment directives:

```markdown
---
compilador_schema: 2
geometry: v3
template: base
lang: auto
columnLayout: "2"
tableLayoutMode: auto
tableRotationDirection: cw
alignment: justify
flushColumns: true
balanceColumns: false
splitListItems: true
imageCaptions: true
chaptersToc: true
tocTitle: SUMÁRIO
tocHeadings: true
docTitlesEnabled: true
docTitle: Tratado de Fisiopatologia Clínica
docSubtitle: Síntese Estruturada
---

<!-- @box {"id":"b_1","title":"1. Hemodinâmica","mode":"rich","kind":"text","ignored":false,"collapsed":false,"masthead":{"enabled":true,"prefix":"M1","course":"Clínica Médica","topic":"Choque Circulatório","header":false},"flags":{"autofix":true,"optimize_tables":true,"split_equations":true},"tableLayout":null,"columns":null} -->
# 1. Hemodinâmica e Perfusão Tecidual

A pressão arterial média ($\text{PAM} = \text{DC} \times \text{RVS}$) governa a perfusão cerebral e coronariana.

<!-- @box {"id":"b_2","title":"2. Matriz Comparativa","mode":"markdown","kind":"table","ignored":false,"collapsed":false,"masthead":{"enabled":false,"prefix":"","course":"","topic":"","header":false},"flags":{"autofix":true,"optimize_tables":true,"split_equations":true},"tableLayout":"panoramic","columns":"1"} -->
| Fenótipo | Índice Cardíaco | RVS | $\text{SvO}_2$ |
| :--- | :---: | :---: | ---: |
| Hipovolêmico | $\downarrow\downarrow$ | $\uparrow\uparrow$ | $< 65\%$ |
| Distributivo | $\uparrow$ ou normal | $\downarrow\downarrow$ | $> 70\%$ |
```

**Import Parser (`parseCompiladorMarkdown(rawText)`)**:
1. If YAML frontmatter with `compilador_schema: 2` is present, parse and merge into `store.globals` via `migrateGlobals()`.
2. If `<!-- @box {...} -->` fences are present, split at each fence, parse the JSON metadata via `normalizeBox()`, and assign the following Markdown slice to `box.markdown`.
3. Otherwise (standard external `.md` file), extract optional frontmatter (`title` -> `docTitle`) and split into separate cards at top-level `# Heading 1` lines (or a single card if no `# H1` exists), auto-detecting `kind: 'table'` when pipe tables dominate a section.

### 5.2 Google Docs Bidirectional Mapping (`WorkspaceBridge`)

#### Import (`Google Doc -> DocumentStore`)
1. Call `docs.documents.get({ documentId, includeTabsContent: true })`.
2. Walk `body.content` (or each tab's `documentTab.body.content`):
   - `paragraph` with `namedStyleType === 'HEADING_1'`: starts a new `box` (`box.title = plainText`) when `splitOnH1` is enabled (default `true`).
   - `paragraph` with `HEADING_2`..`HEADING_4`: emits `##`..`####`.
   - `paragraph` with `bullet`: inspects `nestingLevel` (`0..5`) and `listProperties.nestingLevels[level].glyphType` to emit `'  '.repeat(level) + '- '` or `'1. '`.
   - `textRun`: maps `bold` -> `**`, `italic` -> `*`, `strikethrough` -> `~~`, `weightedFontFamily === 'Courier New' | 'Consolas' | 'JetBrains Mono'` -> `` ` ``, and `link.url` -> `[text](url)`.
   - `table`: extracts cell text per row, escapes internal pipes (`\|`), synthesizes a GFM alignment delimiter row (`| :--- |`), and sets `box.kind = 'table'` if the section is a standalone table.
   - `inlineObjectElement`: fetches `inlineObjects[id].inlineObjectProperties.embeddedObject.imageProperties.contentUri`, transcodes via `downscaleImageToDataUrl()`, and emits `![alt](data:image/jpeg;base64,... "title")`.

#### Export (`DocumentStore / DisplayList 2.2.0 -> Google Doc`)
1. Call `docs.documents.create({ requestBody: { title: resolvedDocTitle } })`.
2. Build a deterministic `requests[]` array for `docs.documents.batchUpdate`:
   - Set page margins (`updateDocumentStyle`) from V3 `resolveFrameAndTokens(template).frame` (`top`, `bottom`, `left`, `right` in points).
   - For each active section in `ExportPayloadBuilder.build(store).sections`:
     - Insert a section break (`insertSectionBreak`) and apply `updateSectionStyle` with `columnProperties` (`1` or `2` columns, `16 pt` gutter) matching the section's effective column count.
     - Emit masthead banner (if `masthead.enabled`), headings (`HEADING_1`..`HEADING_4`), body paragraphs (`NORMAL_TEXT` with `alignment: 'JUSTIFIED' | 'START'`), lists (`createParagraphBullets`), and tables (`insertTable` + cell population).

---

## 6. UI/UX Extensions Under Design Guardrails v3.0

All new Google AI Workspace controls MUST obey the Wave 11 Design Guardrails contract (`DESIGN.md` and `design-guardrails.config.json`: `spacing_base: 4px`, closed radius scale `[0, 4, 8, 12, 16, 9999]px`, 3-layer CSS tokens, zero raw `#hex`/`rgba()`, single primary button `.btn-primary` per cluster):

1. **Topbar Overflow & Mobile `"Mais"` Sheet (`#topbar-overflow-panel` & `#sheet-body`)**:
   - Add two ghost action items using existing token classes (`.btn.btn-ghost.btn-icon-label` on desktop, `.btn` `48px` full-width row in `#sheet-body` on mobile):
     - **`#workspace-io-btn` (`Importar / Exportar`)**: Opens the unified **Arquivo & Google Workspace** modal (`#workspace-modal`).
     - **`#ai-assist-btn` (`Assistente IA`)**: Opens the contextual **Gemini Editorial Assist** popover (`#ai-assist-popover`).
2. **Unified File & Google Workspace Modal (`#workspace-modal`)**:
   - Uses `.modal-card` (`border-radius: var(--radius-lg)` `16px`, `border: 0.5px solid var(--line)`, `background: var(--glass-modal-bg)`).
   - **Tab 1 — `Importar`**:
     - Local file dropzone (`.compilador.md`, `.md`, `.compilador.json`, `.csv`, `.tsv`, `.docx`).
     - Google Workspace Picker buttons (`Importar do Google Docs`, `Importar Tabela do Google Sheets`, `Abrir .compilador.json do Drive`).
   - **Tab 2 — `Exportar`**:
     - Format selector (`segmented-sm` / `field-row` on `4px` grid):
       - `PDF V3 (.pdf)` — Download local or `Salvar no Google Drive`
       - `Markdown Anotado (.compilador.md)` — 100% lossless round-trip
       - `Projeto JSON (.compilador.json)` — Native store snapshot
       - `Google Docs (Nativo)` — Creates formatted Google Doc in Drive
       - `Código Typst (.typ)` — Pure V3 Typst source
       - `HTML5 Interativo (.html)` — Standalone reader with dark mode & print rules
3. **Contextual Gemini Editorial Assist (`#ai-assist-popover`)**:
   - Invokes `POST /api/ai/assist` on `server/index.ts` (backed by `@google/genai` `ai.models.generateContent` with `model: 'gemini-2.5-flash'`).
   - Four deterministic operations on the active block (each pushing an `adapter.checkpoint()` undo boundary before applying):
     - `Revisar ortografia e coesão` (preserves Markdown structure and quantitative invariants)
     - `Converter texto em tabela Markdown` (extracts structured data into a GFM pipe table)
     - `Normalizar fórmulas LaTeX ($...$ / $$...$$)` (fixes unescaped `%`, `_`, and `\frac` syntax)
     - `Sugerir divisão de capítulos e títulos (H1–H3)`

---

## 7. Ready-to-Use Google AI Studio Build Mode Master Prompt

When initializing or updating the project inside **Google AI Studio Build Mode** (`aistudio.google.com`), use the following blueprint prompt:

```text
Build a full-stack web application in Google AI Studio ("Compilador do Raul — Studio Editorial & PDF V3") by mounting the provided compilador-handoff-v3 codebase with zero visual or layout regressions:

1. RUNTIME & SERVER ARCHITECTURE:
   - Keep the entire src/v2/ layout & V3 integer-millipoint compiler (src/v2/compiler/geometry-compiler.js and src/v2/compiler/v3/*) intact.
   - Expose Express routes in server/index.ts for POST /api/convert, POST /api/paginate, POST /api/upload-image, POST /api/workspace/import, POST /api/workspace/export, and POST /api/ai/assist.
   - Include the Web Worker fallback (src/workers/pdf.worker.ts) using createEmbeddedFontAssets(FONT_ASSETS) and the AFM_DATA virtual-FS shim so PDF compilation and V3 pagination work both server-side and client-side.

2. DESIGN SYSTEM GUARDRAILS (WAVE 11):
   - Load static/design-system.css and static/shell.css verbatim.
   - Preserve the 3-layer CSS token graph (:root --primitive-* -> :root/html[data-theme="dark"] semantic tokens -> component rules) with zero raw #hex or rgba() literals in components.
   - Maintain the 4px structural grid, [0, 4, 8, 12, 16, 9999]px radius scale, >= 4.5:1 WCAG AA contrast (--ink-mute #626770), in-flow .rich-composer pill, and >= 48px mobile bottom bar & #sheet-body targets.

3. FILE FORMATS & GOOGLE WORKSPACE INTEGRATIONS:
   - Support importing and exporting: Lossless Annotated Markdown (.compilador.md / .md), Workspace JSON (.compilador.json), Typeset PDF (.pdf to local download or Google Drive), Google Docs (via Docs API v1), Google Sheets / CSV (.csv / .tsv to table blocks), Word (.docx), Typst source (.typ), and standalone HTML5 (.html).
   - Use @google/genai server-side (process.env.GEMINI_API_KEY) for /api/ai/assist block transformations with full undo-stack checkpointing.
```

---

## 8. FocusGate Acceptance Gates (`GW-0`..`GW-8`) & Micro-ADRs

### 8.1 Acceptance Gate Matrix

| Gate ID | Requirement | Executable `CHECK:` Command | `EXPECT:` |
| --- | --- | --- | --- |
| `GW-0` | **Isomorphic V3 Core Purity**: Zero unguarded `node:fs` / `node:child_process` imports in browser-reachable V3 compiler & embedded font modules | `node --test tests/lean/geometry-v3-gates.lean.js` | `pass` |
| `GW-1` | **Lossless `.compilador.md` Round-Trip**: Exporting `DocumentStore` to `.compilador.md` and re-importing preserves 100% of `boxes[]` (titles, markdown, `kind`, `masthead`, `flags`, `tableLayout`, `columns`) and `globals` byte-for-byte | `node --test tests/lean/workspace-formats.lean.js` | `GW-1 PASS` |
| `GW-2` | **Plain `.md` & `.csv`/`.tsv` Ingest**: Importing an external multi-heading `.md` splits on `# H1` into normalized cards; importing `.csv`/`.tsv` produces a valid GFM pipe table with numeric right-alignment (`---:`) | `node --test tests/lean/workspace-formats.lean.js` | `GW-2 PASS` |
| `GW-3` | **Google Docs AST Translator Purity**: `googleDocToStoreBoxes(docJson)` and `docIrToGoogleDocsRequests(docIR, displayList)` round-trip headings (`H1`–`H4`), lists, pipe tables, callouts, and 1/2-column section breaks deterministically | `node --test tests/lean/workspace-formats.lean.js` | `GW-3 PASS` |
| `GW-4` | **Typst (`.typ`) & Standalone HTML5 (`.html`) Export**: Exporting `.typ` and `.html` from V3 `DisplayList 2.2.0` emits non-empty, valid artifacts containing all section titles, TOC page numbers, and 3-layer CSS tokens | `node --test tests/lean/workspace-formats.lean.js` | `GW-4 PASS` |
| `GW-5` | **Server-Only Secret Boundary**: Zero occurrences of `GEMINI_API_KEY` or `GoogleGenAI` in client-side `static/` or `src/studio/` files | `python3 scripts/design_guardrails.py --config design-guardrails.config.json --audit-all static --document DESIGN.md` | `AUDIT_ALL_PASS` |
| `GW-6` | **Design Guardrails v3.0 & Wave 11 Lock Preservation**: All 38 design tests (`visual-w1`..`visual-w11`) and all 7 `design_guardrails.py` checks pass with `0` errors and `0` warnings | `npm run test:design` | `fail 0` |
| `GW-7` | **V3 Geometry & V2 Corpus Parity**: All 18 V3 gates (`VG-0`..`VG-17`) and 157 frozen `vertical-justify.json` rows pass with `0` diffs | `node scripts/probe-geometry-baseline.mjs --geometry v3 --gate all --verify-v2-fixture` | `ALL_VG_GATES=PASS` |

### 8.2 Architectural Decision Records (Micro-ADRs)

- **ADR-1001 (DOM-Preserving React Host over JSX Rewrite)**: Mounting the verified `Compilador Studio` DOM and CSS (`static/design-system.css`, `static/shell.css`, `static/v2-app.js`, `static/editor-core.js`) inside AI Studio's React entry point preserves 100% of the 38 `W1`–`W11` CSS/DOM locks and 15 frontend `.lean.js` behavioral suites without introducing React state-tearing into `contenteditable` or drag-and-drop.
- **ADR-1002 (Dual Server + Web Worker V3 Execution)**: Running `GeometryCompiler` (`geometry: 'v3'`) + `PDFKit` on `server/index.ts` when Cloud Run is active and falling back automatically to an in-browser Web Worker (`createEmbeddedFontAssets(FONT_ASSETS)` + `AFM_DATA` shim) guarantees identical PDF output in both full-stack and static/offline environments.
- **ADR-1003 (HTML-Comment `@box` Directives in `.compilador.md`)**: Encoding per-card metadata (`masthead`, `flags`, `tableLayout`, `columns`) inside `<!-- @box {...} -->` comments rather than custom non-Markdown syntax ensures `.compilador.md` files render cleanly in GitHub, Obsidian, VS Code, and Google Docs while remaining 100% lossless on re-import.
