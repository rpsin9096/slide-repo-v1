# 04 — Layout Engine

This spec owns page geometry, template tokens, band/column/span placement, vertical justification, pagination, headings, tables, images, chrome, and layout diagnostics. It assumes the normalized DocumentIR described in [03-INPUT.md](03-INPUT.md).

> **V3 Vertical Geometry (`geometry: 'v3'`, Browser Default):** The integer-millipoint, baseline-first vertical architecture (`src/v2/compiler/v3/`), 3-layer token hierarchy (`vertical` + `tokens` in `src/v2/templates/definitions.js`), shared running pitch `u`, optical head/foot ink anchoring, boxed-element outside gap separation, Gestalt heading proximity (`before / after >= 1.5`), pre-span coupled column lift, and dynamic multi-page TOC reservation (`tocPages`) are specified normatively in [08-LAYOUT-GEOMETRY-V3.md](08-LAYOUT-GEOMETRY-V3.md). When `geometry` is omitted or `'v2'`, the legacy v2 rules remain active for frozen fixture compatibility.

## Page model

The effective print page is A4 in portrait orientation (`595.28 × 841.89 pt`). `PAGE_SIZES` also defines Letter and Legal for utilities, but there is no user-facing page-size control and the templates are calibrated for A4.

Each **block** begins on a fresh page. A block is the chapter-like unit in `sections[]`/`blocks[]`; its content flows through one- or two-column bands within that block. A document may therefore contain several page groups, one per block.

Page anatomy:

- Top margin, running header band (`headheight` + `headsep`).
- Printable content region, bounded left/right by margins and bottom by `bottom + footskip`.
- Footer/rodapé band with page number and optional running text.
- Optional reserved TOC page at the front (`toc.enabled`). TOC counts as page 1 when present.
- Column separator rule between columns when columns are enabled.

The compiler quantizes geometry to 4 decimal places through `q()` and removes negative zero. Layout decisions are deterministic for a given input, seed, and timestamp.

## Template tokens

Exact tokens live in `src/v2/templates/definitions.js`. These are the values that define the visual families; do not duplicate them in feature code.

| Token | `base` (Minimalist) | `bauhaus` (Modern) | `bauhaus_minimalist` (Compact) |
| --- | --- | --- | --- |
| Body size | 9.5 pt | 9.0 pt | 8.0 pt |
| Line stretch | 1.15 | 1.18 | 1.04 |
| Paragraph skip | 2.2 pt | 2.8 pt | 1.2 pt |
| Grid unit | 12 pt | 12 pt | 12 pt |
| Left/right margin | 28.35 pt | 28.35 pt | 22.68 pt |
| Top margin | 26.93 pt | 22.68 pt | 19.84 pt |
| Bottom margin | 28.35 pt | 24.09 pt | 19.84 pt |
| Column separation | 14.17 pt | 15.00 pt | 12.00 pt |
| Accent | Graphite `#111827` | Sapphire `#2563EB` | Deep teal `#0F766E` |
| Character | Swiss editorial, hairline rules | Linear studio, pills/cards | Dense engineering, tight leading |

Typography uses the vendored faces in `assets/fonts/`: Arimo for the base/bauhaus body and UI faces, Inter for the compact (`bauhaus_minimalist`) family and modern/display aliases, and Noto Emoji as a monochrome emoji fallback. The PDFKit blaster maps generic compiler font names to these faces and falls back to built-in Helvetica when custom faces are unavailable.

Heading levels have per-template decoration and spacing: underlines/bars/dots on `base`, stronger bars and run-in headings on `bauhaus`, compact bars and smaller type on `bauhaus_minimalist`. The heading decorators also control `spaceBefore` and extra height. Do not infer heading spacing from body leading alone.

## Bands, columns, and spans

The page is modeled as a stack of **bands**. A band has a top, a bottom, and one or two columns. Both columns hang from the same band top; content in a band is not independently bottom-aligned unless a later glue pass moves it.

- **One column**: the printable width is one column.
- **Two columns**: each column gets half the printable width minus half the column separation. The band's columns share a top and are filled forward.
- **Panoramic run**: an element that spans the full printable width. A panorama opens its own band; content before and after it is partitioned into separate bands. Tables, full-width figures, and some rules can trigger a panorama.
- **Rotated table**: a full-width table that is emitted on a dedicated portrait page as a rotated element. The page still carries the normal header/footer unless the layout says otherwise.

`ColumnBand` quantizes items into grid slots and partitions content at panos. `GalleyEngine.planColumns` plans the fill; `multicol` handles the two-column balancer. The grid unit is 12 pt for all three templates.

### Continuous fill vs balance

The default is **continuous fill** (“coluna corrida”): fill the left column, then the right, with anti-orphan guards. The document-level `balance_columns` control (“Quebrar colunas para acomodar”) is opt-in. When enabled for a block, the balancer may move a break or stretch the terminal tail to keep the last page's columns closer together. It must not create an extra page merely to balance.

The terminal page is the important case: a document should not end with a nearly empty right column when a better split exists. Mid-document pages may remain ragged; that is intentional.

## Vertical justification (glue)

Vertical justification is a post-pass over a page's inter-item seams.

- A **seam** is a permitted stretch boundary between items. `stretch-seam.js` classifies seams and assigns a capacity; `glue-allocator.js` resolves them into a bounded lift.
- The total lift is bounded by a pitch-ratio ceiling (`STRETCH_CEILING_PITCH_RATIO = 0.30`), per-class capacity, and the column's own void. A lift never moves content past the content foot; when a column cannot fund its void, the unspent residue is reported as `partial-lift`.
- Shifts are applied by ownership group. All elements stamped with the same `(scope, seamSeq)` by `_placeWithSeam` — every line of a paragraph or list item, a heading plus its decorator, a whole table — move together, and the foot guard caps the group by its deepest element. A multi-line atom therefore keeps its internal line spacing even when the guard limits the shift.
- The pass runs only when `flush_columns` is true. `flush_columns: false` leaves page feet honestly ragged and tags skipped pages with `flush-off`.
- Bond classes (for example heading-to-next-content) carry zero capacity so a heading is not separated from the content it introduces.
- Pages are skipped with a reason when there is nothing meaningful to do: `toc`, `rotated`, `block-end`, `no-gaps`, `empty`, `full`, `negligible`, `partial-lift`, or `over-cap`. See `displayList.diagnostics.justify` for the per-page record.
- For an **applied** page, the target is the content foot; the layout tests require the measured bottom void to be at most 1 pt. Do not “fix” a failing applied page by weakening that threshold without changing this spec and explaining why.

The pass is deliberately conservative: a visible gap is worse than a slightly short page. Tests `gap-distribution`, `glue-smoothness`, `glue-allocator`, `percol-funding`, `terminal-balance`, and `vertical-justify` are the evidence for this behavior; see [07-TESTING.md](07-TESTING.md).

## Pagination

Pagination is block-scoped and deterministic.

1. Start a new page for each block (or the reserved TOC page first).
2. Place the block's masthead and first heading.
3. Measure and place items into the current band/columns.
4. If an item does not fit, split it when the item type permits; otherwise move it to the next band/page. List items are a flagged case: they split only when `split_list_items` is `true`; when `false` they move whole, and a v3 region whose continuous fill leaves a material column disparity re-partitions by whole items (see [03-INPUT.md](03-INPUT.md) for the flag contract and [08-LAYOUT-GEOMETRY-V3.md](08-LAYOUT-GEOMETRY-V3.md) §5.9.3 for the mechanics).
5. Tables split by row groups; a repeated header band is used where the table module supports it.
6. Headings obey keep-with-next: a heading is not left alone at a column or page foot. The `AntiOrphanGuard` and heading-bond seams enforce this.
7. Widows and orphans are suppressed where the item type allows; the diagnostics record suppressions.
8. Page chrome, anchors, TOC entries, and page numbers are stamped after content placement.
9. The region planner must make progress. A plan that places zero items while its bite is non-empty is not accepted: mid-page the bite is deferred to a fresh page; at page top an oversized atomic table is row-split, otherwise the first item is placed. `tests/lean/table-region-zero-placement.lean.js` pins this.

A block's first page is not merged with the previous block, even if the previous block ends early. This is a product rule: blocks are chapters.

### Heading behavior

- Heading levels 1–4 have per-template decorations and rhythm.
- A heading plus its immediate following run-in content is a bonded unit; the bond must not stretch.
- “Heading run fit” means the heading and at least the first line of its following content fit in the same column/band before a break is considered.
- Headings feed anchors and TOC entries. The TOC index is built from the document's heading structure; a heading may be excluded by the `toc_include_headings` policy.
- Known historical inversion cases are pinned by `heading-run-order` and `stacked-sliver-order`; do not assume reading order is perfect for every unusual table/heading adjacency without checking those tests.

## Tables

Table behavior is selected by `table_layout_mode` and per-block overrides.

| Mode | Placement | Use |
| --- | --- | --- |
| `compact` | Column-width; table stays inside a column | Dense reference tables |
| `panoramic` | Full printable width; opens a panorama band | Wide tables that need all columns |
| `auto` | Engine decides from column count/width | Default |
| `rotated` / `rotated_cw` / `rotated_ccw` | Dedicated portrait page with rotated table element | Very wide tables that read better sideways |

Table rules:

- Pipe tables are normalized to a rectangle by padding/trimming rows.
- The table header is a band, not a dark full-width slab; header text is dark by default.
- Rows may split at safe boundaries. Bold first-column tokens should stay whole rather than producing one-letter shards.
- A pipe inside `$...$` math is cell content, not a column separator.
- Panoramic tables may carry a caption. A caption before a panorama is span-scoped; it must not be attached to a column that starts after the panorama.
- `optimize_tables` enables table optimization. The table module also guards long tokens and hyphenation points; language-specific hyphenation is not fully wired into the PDFKit path.

## Images

Image sources are resolved before layout by `PdfEngine.resolveBlockImages` (deduped, capped concurrency) and passed to the compiler as an image map. The compiler itself does not fetch.

- Supported raster bytes: PNG and JPEG. The upload endpoint accepts SVG for storage, but the render pipeline validates non-SVG bytes and rejects unsupported raster types.
- Per-image limits: 15 MB decoded, 25 MP. Remote fetch timeout: 5 s per hop, at most 3 redirects.
- Placement: column flow (normal) or full-page panorama. Width/scale and caption attributes come from the editor's image syntax.
- Captions are enabled by `image_captions_enabled`; the caption is attached to the figure and participates in the span/glue rules.
- A failed or unsupported image becomes a diagnostic placeholder rather than crashing the document.
- SSRF protection is in `src/v2/modules/image-module.js`: only HTTP/HTTPS, private/loopback hosts blocked, obfuscated IPv4 blocked, DNS best-effort public check, every redirect re-checked. See [06-OPERATIONS.md](06-OPERATIONS.md) for the residual gaps.

## Math

Inline math uses `$...$`; block math uses `$$...$$`. The math module parses a supported subset of commands (fractions, text, escapes, sub/superscripts, common operators) and maps it to styled runs. It is not a full TeX engine.

- Unclosed delimiters must not swallow prose.
- `\%`, `\_`, `\begin`/`\end`, and currency-like `$` are guarded.
- Unmappable bodies fall back to a single styled run rather than dropping content.
- Block equations can be subject to `split_equations`; the flag is per block and document-level.
- Footnote references are parsed by the AST/serializer path but are not laid out as footnote bodies by the PDFKit compiler. Do not describe the product as supporting footnotes until the compiler implements them.

## Running chrome

`src/v2/modules/chrome-module.js` builds the running header/footer.

- The running title is `docIR.headerText` when supplied; otherwise the template's default header text.
- `show_header_top`/`header_position` decide top vs footer placement.
- `header_date` supports the UI formats: `dd/mm/yyyy`, long Portuguese month, month/year, ISO, year, and a custom value. The date is resolved server-side at compile time (or pinned by a test timestamp).
- Page numbers are stamped on each page. The footer text is derived from `doc_title`/`title`/the resolved title, excluding the generic `Document`.
- Headers/footers are chrome: they do not participate in body glue and are excluded from the content-bottom void measurement.

## Table of contents

- `toc.enabled` reserves a front page and builds entries from the heading structure.
- `chapters_toc` selects chapter-style TOC behavior; `toc_title` overrides the default `SUMÁRIO`; `toc_include_headings` controls whether subheadings are listed.
- The TOC renderer can show a document title banner derived from `doc_title`/`doc_subtitle` or the first block's masthead. Generic titles such as a block fallback are suppressed.
- Under `geometry: 'v3'` (browser default), `GeometryCompiler.compile` dynamically reserves `tocPages = computeMultiPageTocLayout(...).tocPages` front pages and `renderChaptersTOC` overflows across pages with `SUMÁRIO (CONTINUAÇÃO)` headers. Both `/api/paginate` and `/api/convert` (`X-Document-TOC`) return exact compiler `sections[]` and `tocPages` to the frontend.

## Diagnostics and invariants

The compiler returns a `DisplayList` with `diagnostics` and `pagination`. Diagnostic categories include:

- **fit**: estimate-vs-render overflow audit (`checked`, `overflows`, `maxOverflowPt`, `worst`).
- **justify**: applied pages, skipped pages with reasons, lift/void/ratio data.
- **tables**: table slices, panoramic transitions, overfull columns.
- **headings/layout**: keep-with-next breaks, orphan/widow suppressions, stranded-heading cases.
- **images**: placeholder/fallback records.

The core invariants:

- No body content may extend past the content foot.
- Every page is either applied or skipped by justification with a valid reason.
- A heading must not be stranded at a column foot without its following content.
- An applied page's bottom void must be ≤ 1 pt.
- Page numbers are monotonic and start at 1.
- A block starts a new page; a page never contains content from two blocks unless a future spec explicitly changes that.
- Geometry is finite and quantized; the DisplayList is frozen before emission.
- The compiler is pure: no file I/O, network, driver calls, or input mutation.

## Known limits

- A4 portrait is the only calibrated print page.
- Footnotes are not placed.
- Language detection does not drive full hyphenation for every language.
- Tagged/accessible PDF output is not implemented.
- The balancer and glue pass are conservative; a page may remain ragged rather than accept a visible gap.
- The editor's pagination estimator is approximate; only the compiler's DisplayList is exact.
- The tests are the executable definition of the layout gates. When a layout change is intentional, update the owning spec and the reviewed fixture together; never regenerate a golden to hide a regression.
