# 11 — Compiler Efficiency & Cloudflare Free Plan Optimization (Wave 12)

> **Status:** Normative — Verified (`gate-8-compiler-hotpaths`, `gate-9-worker-isolate-budget`, `gate-10-zero-drift-parity` settled GREEN)
> **Target Environment:** Cloudflare Workers Free Plan (`10 ms` CPU budget per request, `128 MB` isolate memory limit) & Node.js 22+
> **Engine Revision:** `2026-10-25-layout-geometry-v3-w12`

## 1. Executive Summary & Benchmark Receipts

Wave 12 eliminates CPU and GC bottlenecks across the V2/V3 deterministic layout engine and Cloudflare Worker entrypoint while preserving **100% bit-for-bit geometric and visual parity** across all 157 `vertical-justify.json` baseline rows, all 18 V3 visual gates (`VG-0`..`VG-17`), and all 317 lean tests.

| Subsystem / Metric | Pre-Wave 12 Baseline | Post-Wave 12 Verified | Speedup / Improvement |
| :--- | :--- | :--- | :--- |
| **`parseInlineRuns` (6-corpus sum)** | `119.00 ms` | **`1.06 – 1.70 ms`** | **70x – 112x faster** |
| **`TypographicAutofix.apply` (6-corpus sum)** | `43.00 ms` | **`4.25 ms`** | **10.1x faster** |
| **`calculateStringWidth` (6-corpus sum)** | `3.80 ms` | **`0.388 ms`** | **9.8x faster** |
| **Word `measure()` calls (`sample1.md`)** | `10,926 calls` | **`4,493 calls`** | **58.9% reduction** |
| **Uncached 6-Corpus Compile (`bypassCache: true`, V3)** | `527.0 ms` warm / `866.0 ms` cold | **`181.53 ms`** | **2.9x – 4.8x faster** |
| **Cached 6-Corpus Compile (`DISPLAY_LIST_CACHE`)** | `527.0 ms` | **`1.60 ms`** (`0.27 ms/doc`) | **329x faster** |
| **Warm `/api/paginate` Worker Latency (`geometry: 'v3'`)** | `82.30 ms` avg | **`1.09 ms` avg** (`2.17 ms` max) | **75x faster (89% under 10 ms limit)** |
| **Incremental 1-Section Edit (4-section, 110 KB, 22-page doc)** | `174.43 ms` | **`19.41 ms`** | **8.99x incremental speedup** |
| **V8 Heap Retained Delta (Bounded Caches)** | Unbounded / thrashing at 2,000 | **`4.32 MB`** | **< 3.5% of 128 MB isolate cap** |

## 2. Bottleneck Root Causes & Architectural Optimizations

### 2.1 Trigger-Indexed Inline Run Parser (`src/v2/compiler/geometry-compiler.js`)
- **Root Cause:** `parseInlineRuns` previously scanned text character-by-character when no inline pattern matched at index 0, executing `rest = rest.slice(1)` and testing all 8 inline regexes at every character offset ($O(N^2)$ string slicing and regex backtracking).
- **Optimization:**
  - Introduced `INLINE_TRIGGER_RE = /[*_~`$\[]/` to jump directly over plain-text runs in a single native C++ RegExp scan.
  - Replaced the 8-regex linear loop with a first-character dispatch table (`INLINE_PATTERNS_BY_CHAR[rest[0]]`) so `*` only tests bold/italic patterns, `\`` only tests code spans, `$` only tests inline math, and `[` only tests links.
  - Added a fast exit (`if (!INLINE_TRIGGER_RE.test(str))`) for plain paragraphs with no inline markdown markers.

### 2.2 Single-Pass Token Measurement & Space Memoization (`src/v2/compiler/geometry-compiler.js`)
- **Root Cause:** `wrapRunsToLines` measured every word token during token splitting and then re-invoked `M(word, ...)` inside the line-packing loop, while also measuring `' '` via full OpenType shaping on every space token.
- **Optimization:**
  - Stored the measured width (`.width`) directly on each non-space word token during initial tokenization and reused `t.width` during greedy line packing.
  - Memoized space widths per `(font, size, bold, italic, underline, strike, smallCaps, tracking)` style signature in `spaceWCache`.
  - Replaced `/^\s+$/.test(part)` on `part.split(/(\s+)/)` outputs with odd-index parity `(pi & 1) === 1`.

### 2.3 3-Tier Incremental Compiler Cache (`src/v2/compiler/geometry-compiler.js`)
To prevent redundant full-document recompilation during live studio editing and back-to-back `/api/paginate` -> `/api/convert` requests, `GeometryCompiler` implements a bounded 3-tier incremental cache keyed by rapid FNV-1a 64-bit content fingerprints:

1. **Tier 1 — `DISPLAY_LIST_CACHE` (16 entries):**
   - Caches the frozen `DisplayList` keyed by full document + layout option signature.
   - Delivers `0.27 ms` average compile time when `/api/convert` or `/api/paginate` is invoked with an already-compiled state.
2. **Tier 2 — `BLOCK_FLOW_CACHE` (64 entries):**
   - Keyed by each block's content hash + preceding layout state (`(startPageIndex, startPageNumber, startY, precedingSectionHeading)`).
   - Stores **post-finalized, vertically justified, chromed, audited, V3-decorated, frozen `page` objects** along with non-enumerable telemetry snapshots (`_justifyMeta`, `_blMeta`, `_bmMeta`, `_v3Meta`).
   - When a user edits Section 4 of a multi-section document, Sections 1–3 bypass flow, vertical justification, page chrome, baseline snapping, margin auditing, V3 decoration, and `deepFreeze` in $O(1)$ time (**8.99x speedup**).
3. **Tier 3 — `BLOCK_ITEMS_CACHE` (64 entries):**
   - Keyed by `(optionSig, blockTextHash)`. Reuses pre-parsed, pre-wrapped `items[]` even when an earlier section edit shifts the starting `y` coordinate or page number of downstream sections.

### 2.4 Batch Regex Alternation in `TypographicAutofix` (`src/v2/ingest/sanitizer.js`)
- **Root Cause:** `TypographicAutofix.apply` iterated through 135+ `TEX_SYMBOL_MAP` regexes sequentially across every prose segment.
- **Optimization:**
  - Grouped consecutive simple `/^\\([A-Za-z]+)\\b$/` rules into compiled alternation batches (`\\(?:alpha|beta|gamma|...)\\b`) with $O(1)$ dictionary lookup.
  - Added character-presence guards (`hasBackslash`, `hasCaret`, `hasUnderscore`, `hasSubSupTag`) to skip entire rule families when their trigger characters are absent.
  - Fast-pathed `fenceSpans` and `stripGroundingTags` when no `\``, `~`, `$`, or `[` characters exist.

### 2.5 OpenType Font Layout Cache & Lookup Tables (`src/v2/fonts/shaping.js`, `metrics.js`, `blaster.js`)
- **Per-Font `fkFont.layout` Cache:** Wrapped `fontObj._fontkitCache[key].layout` via `attachFkFontLayoutCache` (`16,384` entries) so PDFKit's vector draw loop reuses OpenType glyph runs already shaped during compiler measurement instead of re-running GSUB/GPOS tables.
- **Expanded Bounded Caches:** Increased `shapeCache` and `WORD_MEASURE_CACHE` from `2,000` to `16,384` entries, eliminating mid-document cache eviction on 15+ page manuals while keeping memory overhead under `1.5 MB`.
- **ASCII Lookup Table & Metric Memoization:** Replaced per-character `String.fromCharCode` allocations in `calculateStringWidth` with a pre-computed `Uint16Array(128)` lookup table (`HELVETICA_ASCII_LUT`) and memoized `getFontMetrics(fontName, fontSize)`.
- **Zero-Syscall Font Registration:** Cached resolved font paths in `RESOLVED_FONT_PATH_CACHE` and wrapped `PDFDocument.prototype.registerFont` so each `PDFDocument` instance reuses loaded fontkit descriptors without calling `fs.existsSync` 19 times per render.

### 2.6 Zero-Overhead Telemetry & DisplayList Freezing (`src/v2/core/display-list.js`, `events.js`, `pipeline.js`)
- **`Object.isFrozen` Guard in `deepFreeze`:** Replaced `new Set()` allocation and `seen.has(node)` lookups in `deepFreeze` with `Object.isFrozen(node)`, allowing shared/cached subtrees and frozen pages to short-circuit in $O(1)$.
- **`WeakMap` Command Counting:** Memoized `countCommands(ir)` via `COMMAND_COUNT_CACHE` (`WeakMap`).
- **Opt-In Heap Walks:** Disabled synchronous `process.memoryUsage()` V8 heap walks on every pipeline stage in `TelemetryBus` and `EngineEventBus` by default (saving 6.1% of total CPU time; re-enabled when `options.trackMemory === true`).

### 2.7 Cloudflare Worker Isolate Fast-Paths (`src/_worker.js`)
- **`O(1)` Virtual `fs` Asset Lookup:** Replaced $O(N)$ `Object.entries(AFM_DATA)` / `Object.keys(AFM_DATA)` scans in `fs.readFileSync` and `fs.existsSync` with $O(1)$ basename property lookup and cached decoded `.icc` color profile buffers (`ICC_BUFFER_CACHE`).
- **Isolate-Level `PAGINATE_MEM_CACHE` (32 entries):** Added an in-memory isolate cache in front of Cloudflare Cache API on `/api/paginate` with `X-Cache: HIT | MISS` headers, serving repeated pagination probes in `~1.09 ms` CPU time.

## 3. Verification Commands

```bash
# Run the FocusGate compiler efficiency & Cloudflare isolate probe
node scripts/probe-compiler-efficiency.mjs

# Run the dedicated Wave 12 lean efficiency test suite
node --test tests/lean/compiler-efficiency.lean.js

# Verify FocusGate ledger & full test suites
python3 scripts/focus_gate.py --report --fresh
npm test
npm run test:design
```
