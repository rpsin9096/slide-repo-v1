# 03 — Input Contract

This spec owns the public request payload: what the browser sends, what the Node/Worker APIs accept, how it is normalized, and which limits apply. Layout behavior is in [04-LAYOUT.md](04-LAYOUT.md); PDF/response shapes are in [05-OUTPUT.md](05-OUTPUT.md).

## Two layers

The public payload is normalized in two layers:

1. **DocumentIR normalization** (`normalizeToDocIR`) maps the structural fields: title, blocks/sections, template, language, columns, alignment, masthead, flags, table layout, header text/date, TOC intent, and flush/balance defaults.
2. **Compile-option forwarding** (`resolveCompileOptions` in `pdf-engine.js`, `resolveWorkerCompileOptions` in `src/_worker.js`, or driver options) forwards presentation fields that do not belong in DocumentIR: `geometry` (`'v2' | 'v3'`), `chapters_toc`, `toc_title`, `toc_include_headings`, `doc_title`, `doc_subtitle`, `image_captions_enabled`, `clean_spans`, `split_list_items`, and the snake/camel aliases of the block flags.

A caller can send only the structural subset. The browser sends the full superset. Unknown fields are ignored rather than rejected, except for fields with strict enum validation.

## Envelope

A request is a JSON object. The content can be supplied in one of two forms:

```json
{ "markdown": "# Title\n\nBody" }
```

or:

```json
{
  "title": "Document title",
  "template": "base",
  "sections": [
    { "title": "Section A", "markdown": "# A\n\nBody" }
  ]
}
```

`blocks` is accepted as an alias for `sections`. If both are present, `blocks` wins in `normalizeToDocIR` when it is a non-empty array.

## Top-level fields

| Field | Type | Default | Behavior |
| --- | --- | --- | --- |
| `title` | string | `Document` | Document title. `doc_title` is an alias; `title` has precedence. A title equal to `Document` is treated as generic when deriving the masthead title. |
| `doc_title` | string | — | Alias/fallback for `title` and the running footer text. |
| `doc_subtitle` | string | — | Forwarded to the compiler for the optional document title banner. |
| `sections` | array | — | Block list. Empty/whitespace-only Markdown is filtered; a title-only block is kept. |
| `blocks` | array | — | Alias for `sections`, accepted by the normalizer and pipeline. |
| `markdown` | string | — | Single-block shorthand. Used only when no non-empty `sections`/`blocks` array is supplied. |
| `template` | enum | `base` | `base`, `bauhaus`, or `bauhaus_minimalist`. Invalid values fail `validateDocIR`. |
| `lang` | enum | `pt` | `pt`, `es`, or `en`. Invalid values silently become `pt` in normalization. |
| `column_layout` | `1`/`2`/string | `2` | `columnLayout` is an alias. Invalid values fall back to `2`. Per-block `columns` overrides it. |
| `alignment` | enum | `justify` | `justify`, `left`, or `right`. |
| `raggedright` | boolean | `false` | When true and `alignment` is absent, forces `left`. |
| `table_layout_mode` | enum | `auto` | `compact`, `panoramic`, `auto`, `rotated`, `rotated_cw`, `rotated_ccw`. Aliases: `tableLayoutMode`, `table_layout`, `tableLayout`. Legacy `full_width` becomes `panoramic`. Invalid values become `auto`. |
| `table_rotation_direction` | `cw`/`ccw` | `cw` | Alias `tableRotationDirection`. Used when the selected layout is `rotated`. |
| `header_text` | string | empty | Alias `headerText` (camelCase wins in the normalizer). Running header/footer text. |
| `header_date` | object | null | Alias `headerDate`. Shape `{ enabled, format, custom_value }`. Formats are listed in [04-LAYOUT.md](04-LAYOUT.md). |
| `show_header_top` | boolean | `true` | When false, header is placed at the footer. |
| `header_position` | `top`/`footer` | `top` | `footer` also forces header-on-bottom. |
| `enable_toc` | boolean | `true` (veto flag) | Not a TOC-on switch: when false, it forces TOC off; otherwise `toc.enabled` decides whether the TOC page is rendered. |
| `toc` | object | `{ enabled: false }` | TOC intent object. `toc.enabled` turns the front TOC page on. |
| `chapters_toc` | boolean | `false` | Forwarded compile option for chapter-style TOC. Alias `chaptersToc`. |
| `toc_title` | string | `SUMÁRIO` in the UI | Forwarded compile option. Alias `tocTitle`. |
| `toc_include_headings` | boolean | `true` | Forwarded compile option. Alias `tocIncludeHeadings`. |
| `loose_line_guard` | boolean | `true` | Alias `looseLineGuard`. Keeps loose-line/orphan guards enabled. |
| `balance_columns` | boolean/null | `null` | Alias `balanceColumns`. `null`/absent means continuous fill (no terminal balance opt-in); `true` or `false` is propagated to each block unless the block specifies its own value. |
| `flush_columns` | boolean | `true` | Alias `flushColumns`. “Encaixar pé da página.” When false, the vertical-justification post-pass skips every page with reason `flush-off`. |
| `clean_spans` | boolean | `true` | Forwarded compile option. Removes citation/span tags from display text. |
| `split_list_items` | boolean | `true` | Forwarded compile option. `true` allows long list items to split across pages/columns. `false` makes every list item atomic: when continuous fill leaves a material column disparity, the v3 flow re-partitions the region by whole items and does not enforce the parent-list keep at that region tail. Residual short columns are the honest cost of an item that cannot fit; see [08-LAYOUT-GEOMETRY-V3.md](08-LAYOUT-GEOMETRY-V3.md) §5.9.3. The editor checkbox **Dividir itens longos** (Portuguese, checked by default) sends this flag through `ExportPayloadBuilder` (`static/export-payload.js`); the store default lives in `static/document-store.js`. |
| `split_equations` | boolean | `true` | Forwarded compile option. Per-block flags take precedence. |
| `image_captions_enabled` | boolean | `true` | Forwarded compile option. Aliases `imageCaptionsEnabled`. |
| `geometry` | `'v2'`/`'v3'` | `'v2'` (API) / `'v3'` (UI) | Selects the vertical geometry engine. `ExportPayloadBuilder` in the browser sends `'v3'` by default (`specs/08-LAYOUT-GEOMETRY-V3.md`); direct API callers omitting `geometry` default to `'v2'` for backward fixture compatibility. |
| `engine` | string | `v2-modular` | UI lock. Node treats `v2-typst` as a request for the Typst driver; any other value selects PDFKit. |
| `driver` | `pdfkit`/`typst` | — | Node-only explicit driver override. It takes precedence over `engine` in `server.js`. |
| `preview` | boolean | `false` | Server uses it for `Content-Disposition: inline`; the browser uses it to request a preview. It does not change layout. |
| `preview_full` | boolean | `false` | Browser preview mode; the full preview sends all sections, the mini preview only the first non-empty section. |
| `ast` | object | — | Internal ingest seam. Not part of the public contract; do not send from external clients. |

## Section fields

| Field | Type | Default | Behavior |
| --- | --- | --- | --- |
| `title` | string | `''` | Section/block title. `name` is an alias. Used in TOC and masthead fallbacks. |
| `name` | string | — | Alias for `title`. |
| `markdown` | string | `''` | The block body. Empty bodies are dropped from `sections` unless the block has a title. |
| `masthead` | object | disabled | `{ enabled, prefix, course, topic, header }`. Only whitelisted keys are accepted by `validateDocIR`. |
| `enable_masthead` | boolean | — | Flat alias used by the browser payload. |
| `masthead_enabled` | boolean | — | Flat alias. |
| `masthead_prefix` | string | — | Flat alias for `masthead.prefix`. |
| `masthead_course` | string | — | Flat alias for `masthead.course`. |
| `masthead_topic` | string | — | Flat alias for `masthead.topic`. |
| `masthead_header` | boolean | — | Flat alias for `masthead.header`. |
| `flags` | object | `{autofix:true, optimize_tables:true, split_equations:true}` | Allowed keys: `autofix`, `optimize_tables`, `split_equations`, `balance_columns`. All must be booleans. |
| `autofix` | boolean | `true` | Flat alias for `flags.autofix`. |
| `optimize_tables` | boolean | `true` | Flat alias for `flags.optimize_tables`. |
| `split_equations` | boolean | `true` | Flat alias for `flags.split_equations`. |
| `balance_columns` | boolean | inherited | Flat alias for `flags.balance_columns`. |
| `table_layout` | enum | `null` | Per-block override. Aliases: `tableLayout`, `table_layout_mode`, `tableLayoutMode`. `null` inherits the document mode. |
| `table_rotation_direction` | `cw`/`ccw` | `cw` | Per-block rotation direction. Alias `tableRotationDirection`. |
| `columns` | `1`/`2`/null | `null` | Per-block column override. Aliases: `column_layout`, `columnLayout`. `null` inherits `column_layout`. |
| `index`, `id` | number/string | — | Echo fields from the browser. The normalizer preserves array order; it does not use these for ordering. |

## Normalization rules

- **Empty content is not a document.** The server rejects a request with no non-empty Markdown. The normalizer filters sections whose Markdown is empty/whitespace, but keeps a section that has a title so masthead-only pages remain possible.
- **First-block masthead title.** If the first block has a masthead enabled (or has course/topic and is not explicitly disabled), its `course` or `topic` becomes the title fallback when no explicit title is supplied.
- **Title fallback.** Explicit `title`/`doc_title` wins; otherwise the masthead title; otherwise `Document`.
- **Flags default on.** Block flags are opt-out: absent or `!== false` means enabled. `balance_columns` is the exception: absent means “no per-block decision,” so the document default applies, and if that is also absent the engine uses continuous fill.
- **Per-block overrides.** A block's `table_layout`, `table_rotation_direction`, `columns`, and `balance_columns` override the document value. `null` means inherit.
- **Legacy table value.** `full_width` is migrated to `panoramic`; `rotated` plus a direction becomes `rotated_cw` or `rotated_ccw`.
- **Invalid enums.** When a pre-normalized DocumentIR is supplied, `validateDocIR` rejects an invalid `template`, `alignment`, `lang`, `columns`, or flag type. The public normalizer repairs some values before that check (for example, invalid `lang` to `pt`, invalid per-block `columns` to inherit, invalid table layout to `auto`). It does not reject unknown top-level presentation fields; those are ignored.
- **Table layout validation.** The normalizer drops invalid per-block table layouts to `null` (inherit); the document-level invalid value falls back to `auto`.
- **Header aliases.** `headerText` wins over `header_text`; `headerDate` wins over `header_date`; `show_header_top` defaults true; `header_position: 'footer'` forces bottom placement.
- **Footer text.** Derived from `doc_title`, then `title`, then the resolved title, excluding the generic `Document`.

## Limits

| Surface | Limit | Enforcement |
| --- | --- | --- |
| Node request body | 25 MB | `express.json({ limit: '25mb' })` |
| Node Markdown content | 2,000,000 characters | `convertBodyStats`; 413 |
| Node upload | 15 MB decoded per image | `/api/upload-image`; 413 |
| Worker wire body | 25 MB | `content-length` and parse gate |
| Worker text | 150,000 characters after image stripping | 413 |
| Worker sections | 30 | 413 |
| Worker image | 15 MB decoded, 25 MP, 15 MB total | 413 |
| Browser preflight | 30 sections, 150,000 characters, 15 MB decoded images | Client-side error before request |
| Preview mini | First non-empty section, Markdown truncated at 12,000 characters | UI notice |

The Node limit counts raw Markdown, including base64 image data. A large embedded image can hit the 2M character cap before the image-specific 15 MB check. The Worker extracts data-URI images before counting text, so its text and image budgets are separate.

## Markdown grammar

The ingest layer accepts a practical Markdown subset:

- ATX (`#`) and setext headings; heading levels drive TOC entries and heading rhythm.
- Paragraphs, hard/soft line breaks, emphasis, strong, inline code, links.
- Ordered and unordered lists with nesting; list item splitting depends on `split_list_items`.
- Blockquotes and fenced code blocks.
- Pipe tables, including math-aware cell splitting.
- Images: `![alt](src "caption")` plus optional attribute syntax used by the editor (`{#slug width=... place=... ratio=...}`).
- Math: inline `$...$` and block `$$...$$`; the math module normalizes supported commands and leaves unmappable bodies as styled runs.
- Horizontal rules.
- Token placeholders such as `{{token}}` and date tokens, resolved by the ingest sanitizer.
- Raw HTML is stripped or escaped by `TagSanitizer`; it is not rendered as HTML.
- Footnote references are parsed by the AST/serializer path, but the PDFKit compiler does not place footnote bodies. Do not promise footnote layout.

`autofix` applies typographic normalization (quotes, dashes, ellipses, non-breaking spaces, arrow composites) while preserving code spans, URLs, and math where the guards apply. `optimize_tables` controls table column/row optimization. `split_equations` controls whether equation blocks may split.

## Error contract

| Status | When | Body |
| --- | --- | --- |
| 400 | Empty Markdown / no content | `{ detail: 'Markdown content is empty' }` (Node) or the Worker equivalent |
| 400 | Invalid DocumentIR on the Worker | `{ detail: 'Invalid DocumentIR: ...' }` |
| 400 | Missing upload data | `{ error: 'Dados da imagem não fornecidos' }` |
| 413 | Content/body/image over limit | `{ detail }` or `{ error, code: 'IMAGE_TOO_LARGE' }` |
| 422 | Unsupported image bytes | `{ error, code: 'IMAGE_UNSUPPORTED_TYPE' }` |
| 429 | Rate limit exceeded | `{ detail }` plus `Retry-After` |
| 500 | Invalid DocumentIR or render failure on Node | `{ detail: err.message }` |
| 502 | Worker backend proxy unreachable | `{ detail: 'Backend indisponível ...' }` |

Node malformed JSON is handled by Express and may return an HTML error, not the JSON shape above. The Worker has its own parse/error paths. Do not rely on a single error envelope across both surfaces.

## Determinism fields

The internal pipeline accepts `seed` and `timestamp` for reproducible layout and byte comparison. They are not part of the browser payload. Tests pin them (for example `seed: 'span-baseline'`, `timestamp: 1700000000000`). Production calls use the clock, so PDF creation dates vary.

## Minimal examples

Single block:

```json
{
  "markdown": "# Hematologia\n\nTexto de estudo.",
  "template": "base",
  "lang": "pt",
  "preview": true
}
```

Two sections with per-block overrides:

```json
{
  "title": "Material de estudo",
  "template": "bauhaus",
  "column_layout": 2,
  "table_layout_mode": "auto",
  "flush_columns": true,
  "sections": [
    {
      "title": "Introdução",
      "markdown": "# Introdução\n\nTexto.",
      "masthead": { "enabled": true, "course": "Curso", "topic": "Aula 1" }
    },
    {
      "title": "Tabelas",
      "markdown": "| A | B |\n|---|---|\n| 1 | 2 |",
      "table_layout": "panoramic",
      "column_layout": 1
    }
  ]
}
```
