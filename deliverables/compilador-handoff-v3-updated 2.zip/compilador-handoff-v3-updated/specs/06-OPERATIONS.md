# 06 — Operations

This spec owns installation, local operation, environment variables, build, deployment, security posture, and troubleshooting. Request fields are in [03-INPUT.md](03-INPUT.md); response shapes are in [05-OUTPUT.md](05-OUTPUT.md); architecture/runtime differences are summarized in [02-ARCHITECTURE.md](02-ARCHITECTURE.md).

## Prerequisites

- Node.js 20 or newer. `.nvmrc` pins `20`; `package.json` declares `engines.node >= 20`.
- npm.
- A POSIX-like shell for the test scripts (macOS/Linux; the scripts use shell globs and `chmod`).
- Optional: Typst, only for the `v2-typst` driver and `/api/convert-v2`.
- Optional: Cloudflare account, `wrangler`, and network access, only for deployment.

Puppeteer is not a dependency in this snapshot. The design tier is source/CSS assertion, so no browser download is required.

## Install and run

```bash
cd compilador-raul-handoff-2026-10-21
npm ci
npm run dev
```

Open <http://localhost:3000>. `server.js` is hardcoded to port 3000 and binds `0.0.0.0`. It creates `static/uploads/` on startup and serves `static/` at the root.

On macOS, `run-server.command` is a double-clickable launcher that performs the same steps: it changes to its own directory, checks Node 20+, runs `npm ci` when `node_modules/` is missing (falling back to `npm install`), starts `npm run dev`, and opens `http://localhost:3000` in the default browser once `/api/health` answers.

Useful commands:

| Command | Purpose |
| --- | --- |
| `npm run dev` | Start the Express server |
| `npm run dev:watch` | Nodemon watch for server, static, src, scripts |
| `npm start` | Same as `dev` |
| `npm run lint` | `node --check` the entry points |
| `npm test` | Verify suites + 60 lean files |
| `npm run test:verify` | Nine verify suites only |
| `npm run test:lean` | 60 lean files only (includes `geometry-v3-gates.lean.js`) |
| `npm run test:design` | 8 exact-CSS/design locks |
| `npm run test:all` | `npm test` + design tier |
| `node scripts/probe-geometry-baseline.mjs --geometry v3 --gate all --verify-v2-fixture` | Evaluate all 18 V3 gates (`VG-0`..`VG-17`) and verify 0 diffs on `vertical-justify.json` |
| `npm run build` | Generate embedded data and `dist/` |
| `npm run dev:cf` | Build, then `wrangler dev` on :8787 |
| `npm run deploy` | Build, then `wrangler deploy` |
| `npm run baseline:span` | Regenerate `tests/fixtures/span-baseline.json` |
| `npm run parity` | Manual legacy-vs-V2 differential harness (expected red today) |

## Environment variables

The Node server does **not** load `.env` automatically. Export variables in the shell, or use `node --env-file=.env server.js`. `.env` is gitignored; `.env.example` is the documented template.

| Variable | Surface | Meaning |
| --- | --- | --- |
| `CORS_ORIGINS` | Node | Comma-separated allowed origins. If unset/empty, CORS allows all origins and logs a warning. |
| `PDF_BACKEND_URL` | Worker | Base URL of a Node render backend. When set, `/api/convert` and `/api/paginate` proxy there. |
| `BACKEND_URL` | Worker | Alias for `PDF_BACKEND_URL`. |
| `V2_STAGING` | Node | `0` disables `/api/convert-v2`; otherwise the staging endpoint is available. |
| `V2_TEMPLATE` | Node | Default template for `/api/convert-v2`; does not override `/api/convert`. |
| `V2_BALANCE` | Node | `0` disables autobalance for `/api/convert-v2` PDF output. |
| `TYPST_BIN` | Node | Path to the Typst binary. Otherwise tries `~/.local/bin/typst`, then `typst` on `PATH`. |
| `TYPST_TIMEOUT_MS` | Node | Typst compile timeout in milliseconds; default 60000. |
| `TYPST_FONT_DIR` | Node | Font directory for Typst/autobalance; defaults to `assets/fonts`. |
| `V2_BAL_DEBUG` | Node | Enables verbose autobalance logging when set. |

Do not put secrets in `wrangler.json` vars. Use `npx wrangler secret put ...` for values that must not be committed. `PDF_BACKEND_URL` is a URL, not an auth token; protect the backend with network policy or an authenticated proxy.

## API surface

| Method | Path | Surface | Purpose |
| --- | --- | --- | --- |
| GET | `/api/health` | Node, Worker | Liveness/status JSON |
| POST | `/api/upload-image` | Node, Worker | Store an image (Node filesystem; Worker data URI) |
| POST | `/api/convert` | Node, Worker | Render a PDF |
| POST | `/api/paginate` | Node, Worker | Coarse page estimate JSON |
| POST | `/api/convert-v2` | Node only | Staging Typst/autobalance PDF or source |
| GET | `*` | Node | Static file or `index.html` fallback |
| GET | `*` | Worker | Static asset via `ASSETS`, else 404 |

The Node server rate-limits in memory: convert 60/min, upload 60/min, paginate 300/min, keyed by `req.ip` in 60-second windows. It has no `trust proxy` setting, so behind a proxy all clients may share one key. The Worker has no rate limiter.

The Node server has no authentication, CSRF protection, helmet/CSP, compression, or app-level request timeout. Express handles malformed/oversized JSON with its own error path, which may be HTML rather than the API's JSON envelope.

## Build

```bash
npm run build
```

`scripts/build-cloudflare.js`:

1. Reads `node_modules/pdfkit/js/data` and writes `src/afm-data.js`.
2. Reads nine faces from `assets/fonts/` and writes `src/font-assets-data.js`.
3. Creates `dist/.assetsignore` and copies the browser assets.
4. Runs `npx wrangler deploy src/_worker.js --dry-run --minify --outdir=dist ...`.
5. Verifies the expected `dist/` files and exits.

Notes:

- `npx wrangler` is not in `package.json`/the lockfile, so the version is resolved from the network at build time. Pin it in your environment if you need reproducible bundles.
- The build does not clean `dist/`; stale files can survive a partial build. Remove `dist/` before a release if that matters.
- `src/afm-data.js` is generated but committed. `src/font-assets-data.js` is generated and gitignored. Do not hand-edit either.
- The browser assets copied to `dist/` are `index.html`, `design-system.css`, `shell.css`, `icons.svg`, `v2-app.js`, `editor-core.js`, `document-store.js`, `export-payload.js`, `editor-adapters.js`, and `static/vendor` if present. `static/uploads/` is never copied.

## Cloudflare deployment

The Worker configuration is `wrangler.json`:

- Worker name: `doe-formatter` (historical deployment name; do not rename casually).
- Entry: `dist/_worker.js`.
- Compatibility date: `2024-09-23`; `nodejs_compat`.
- Static assets binding: `ASSETS` at `./dist`.
- Observability enabled.
- No D1/KV/R2 bindings; the render cache uses `caches.default`.

Typical flow:

```bash
npx wrangler login
# Optional: offload renders to a Node backend
npx wrangler secret put PDF_BACKEND_URL
npm run deploy
npx wrangler tail
```

`npm run dev:cf` builds and starts `wrangler dev --port=8787`. The Worker health response reports `backend: 'proxy'` or `'local'` based on whether `PDF_BACKEND_URL`/`BACKEND_URL` is set; it does not verify that the backend is reachable.

Worker-reachable modules must not evaluate `import.meta.url` at module scope: workerd leaves it `undefined`, so `fileURLToPath(import.meta.url)` throws during script validation and `wrangler deploy` rejects the upload with error `10021`. Resolve disk paths lazily (function scope) and fall back to the embedded FontsPort adapter, which Workers always use. `tests/lean/worker-bundle-safety.lean.js` walks the static `src/_worker.js` import graph and fails if the pattern returns.

`npm run deploy:pages` exists, but the supported configuration in this snapshot is Workers + Static Assets. Pages advanced-mode behavior is not verified here.

## Security posture

This is a **trusted-user/local-first** application, not a public multi-tenant service.

- No authentication or authorization on any API.
- Node CORS is open when `CORS_ORIGINS` is unset; Worker CORS is always `*`.
- Node rate limits are in-memory, per-process, and proxy-IP-sensitive.
- Node uploads are written to `static/uploads/` and served same-origin. SVG is accepted and served without a CSP or `Content-Disposition`, which is a stored-XSS/disk-growth surface. Do not expose uploads publicly without a policy.
- Worker `/api/upload-image` does not validate or cap the data; it returns a data URI. The render path has its own image limits, but the upload endpoint itself is permissive.
- Remote image fetch in Node blocks private/loopback hosts (including obfuscated IPv4), re-checks redirects, and does a best-effort DNS public check. Residual risks: no host allowlist, DNS rebinding is best-effort, HTTP is allowed, and the 15 MB cap is applied after `arrayBuffer()`.
- Typst `sandboxTypstAssets` copies local image references without full path containment. Markdown-controlled `..` references can copy files outside `static/` into the sandbox. Treat Typst/Typst staging as a trusted-input feature.
- The Worker cache key strips image payloads; two requests with identical text but different embedded images can collide for the TTL. Bump `RENDER_ENGINE_REVISION` when engine output changes.
- Worker error paths often omit CORS headers. If you build a cross-origin client, verify each path.
- If a secret was ever committed in another repository, rotate it. This snapshot contains no secret values; `.env` and `.env.*` are ignored except `.env.example`.

If you must expose the service, add authentication, a strict CORS allowlist, a CSP, upload type/size policy, request timeouts, and a rate limiter at the edge. Do not rely on the current defaults.

## Cloudflare limits and failure modes

The Worker is constrained by the platform. The app-level limits are:

- 25 MB wire body.
- 150,000 text characters after image stripping.
- 30 sections.
- 15 MB per image, 25 MP, 15 MB total decoded images.

The Free plan's CPU budget is small; a heavy `/api/convert` can surface as Cloudflare **Error 1102 / HTTP 503**. The supported mitigation is to run the Node server as a render backend and set `PDF_BACKEND_URL`; the Worker then proxies the request. The proxy has no app-level timeout or retry, so make the backend reliable and network-restricted.

## Troubleshooting

| Symptom | Check |
| --- | --- |
| `npm ci` fails on Node version | `node --version`; use Node 20+ (`nvm use` reads `.nvmrc`) |
| Port 3000 already in use | `lsof -i :3000`; stop the other process. The port is hardcoded in `server.js` |
| `npm run build` fails with wrangler/network | `npx wrangler --version`; install/pin wrangler or use network access |
| `dist/_worker.js` missing or stale | Remove `dist/`, rerun `npm run build` |
| `wrangler deploy` fails with error `10021` | A Worker-reachable module evaluates `import.meta.url` at module scope; move the path resolution into a guarded function (see Cloudflare deployment) |
| A deployed Worker still returns the previous layout | The edge render cache survives deploys; bump `RENDER_ENGINE_REVISION` in `src/_worker.js` and redeploy |
| Worker says missing font/AFM data | Run `npm run build`; `src/font-assets-data.js` is generated and ignored |
| Typst render fails | Install Typst or set `TYPST_BIN`; check `typst --version`; use `/api/convert` (PDFKit) instead |
| `/api/convert-v2` returns 409 | `V2_STAGING=0` is set; unset it or use `/api/convert` |
| CORS error from another origin | Set `CORS_ORIGINS` on Node; Worker is always `*` |
| Upload rejected 422 | The renderer accepts PNG/JPEG bytes; SVG is stored but not raster-rendered |
| Tests fail because corpus is missing | Keep `tests/corpus/` intact; tests load through `tests/corpus/index.js` |
| Design tests fail after a CSS refactor | They are exact source locks; update the lock only if the visual contract intentionally changed |
| Preview page numbers differ from TOC | `/api/paginate` is a coarse estimate; use the generated PDF/compiler page map for exact numbers |
| Save pill says “Salvo” but content is lost | The store catches quota errors; check browser storage and the adapter flush path before trusting the indicator |

## Smoke tests

Start the server first.

```bash
curl -s http://localhost:3000/api/health

curl -sS -D /tmp/convert.headers -o /tmp/smoke.pdf \
  -X POST http://localhost:3000/api/convert \
  -H 'Content-Type: application/json' \
  -d '{"markdown":"# Smoke\n\nHello PDF","preview":true}'
file /tmp/smoke.pdf
head -20 /tmp/convert.headers

curl -sS -X POST http://localhost:3000/api/paginate \
  -H 'Content-Type: application/json' \
  -d '{"markdown":"# Smoke\n\nHello PDF"}'

curl -sS -X POST http://localhost:3000/api/upload-image \
  -H 'Content-Type: application/json' \
  -d '{"data":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=","filename":"smoke.png"}'
```

For the Worker, substitute `http://localhost:8787` after `npm run dev:cf`, or the deployed `workers.dev` URL. Start with a small payload on the Free plan, then test a real document.

## Known operational limits

- `/api/paginate` is approximate; the frontend can show fallback page numbers.
- The Node server does not auto-load `.env`.
- The build depends on network-resolved `npx wrangler`.
- There is no CI configuration, coverage tool, or HTTP-level test suite in this snapshot.
- The test corpus and goldens are calibrated on the included documents; changing them changes measured layout.
- The Worker has no Typst and no `/api/convert-v2`.
- A local Worker render does not forward all Node compile options; presentation fields outside DocumentIR may differ. Use `PDF_BACKEND_URL` when exact Node parity matters. See [02-ARCHITECTURE.md](02-ARCHITECTURE.md).
- The original development history, screenshots, and planning artifacts are intentionally absent. Use the specs, tests, and `ALTERATIONS.md` for current context.

## Wave 12 — Cloudflare Workers Free Plan Isolate Budget (< 10 ms CPU)
- **Engine Revision**: `2026-10-25-layout-geometry-v3-w12`
- **Isolate Memory & Cache Discipline**: `PAGINATE_MEM_CACHE` (32 entries), `DISPLAY_LIST_CACHE` (16 entries), `BLOCK_FLOW_CACHE` (64 entries), `BLOCK_ITEMS_CACHE` (64 entries), and `shapeCache` / `WORD_MEASURE_CACHE` (16,384 entries) maintain total steady-state heap growth under `5 MB` (< 4% of the `128 MB` Worker isolate limit).
- **Virtual FS & Font Registration**: `src/_worker.js` resolves AFM and ICC assets in $O(1)$ via direct property lookup and `ICC_BUFFER_CACHE`, while `blaster.js` caches fontkit layout runs (`attachFkFontLayoutCache`) and `registerFont` descriptors per isolate.
