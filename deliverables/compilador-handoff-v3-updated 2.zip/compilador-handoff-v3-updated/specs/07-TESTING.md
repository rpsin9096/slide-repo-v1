# 07 — Testing

This spec owns the test tiers, commands, catalogs, fixtures, corpus, regeneration rules, and coverage gaps. It is the evidence map for changes to the layout and editor.

## Policy

Tests are **evidence**, not immutable law. They exist to catch regressions in behavior the product has chosen to protect. When a test fails, classify it before changing anything:

1. **Regression** — the code no longer does what the test names. Fix the code.
2. **Intentional behavior change** — the product decision changed. Update the owning spec first, then the test/fixture, and record the change in `ALTERATIONS.md`. Review golden diffs; do not auto-accept them.
3. **Environment/flake** — the test depends on a missing binary, network, filesystem permission, or timing. Fix the isolation; do not silently skip it.
4. **Obsolete test** — the behavior no longer exists. Remove or rewrite it only with an explicit spec change and an alterations entry.

Never delete, skip, or weaken a test merely to make a run green. If a threshold is wrong, change the threshold and explain why in the owning spec.

## Tiers and commands

| Tier | Command | What it proves |
| --- | --- | --- |
| Verify | `npm run test:verify` | Nine hard-number acceptance suites over the compiler |
| Lean | `npm run test:lean` | 65 `node:test` files: contracts, V2 & V3 layout invariants, editor logic, security, performance |
| Design | `npm run test:design` | 9 exact source/CSS locks (`38` tests) for the editor's visual contract and Design Guardrails v3.0 invariants |
| Guardrails CLI | `python3 scripts/design_guardrails.py --config design-guardrails.config.json --audit-all static --document DESIGN.md` | Deterministic audit of 3-layer token hierarchy, WCAG 2.1 AA contrast, 4px spacing grid, closed radius scale, and `DESIGN.md` 9-section schema |
| V3 Gates | `node scripts/probe-geometry-baseline.mjs --geometry v3 --gate all --verify-v2-fixture` | All 18 V3 acceptance gates (`VG-0`..`VG-17`) + 157-row V2 fixture parity |
| Full | `npm test` | Verify + lean |
| Everything | `npm run test:all` | Full + design |
| Manual parity | `npm run parity` | Legacy vs V2 differential harness; expected red today |
| Fixture regen | `npm run baseline:span` | Rewrites `tests/fixtures/span-baseline.json` |

Baseline on 2026-10-26 (zero-placement guard + atomic-list-balance deploy handoff; all commands run on that date):

- `npm test`: verify suites all `PASS` (9/9); 327 tests in 81 suites, 327 pass, 0 fail (`VERIFY: PASS`).
- `npm run test:design`: 38 tests in 9 suites, all pass (`0` failures).
- `python3 scripts/design_guardrails.py --config design-guardrails.config.json --audit-all static --document DESIGN.md`: `AUDIT_ALL_PASS` (all 6 design gates + code rigor clean).
- `node scripts/probe-geometry-baseline.mjs --geometry v3 --gate all --verify-v2-fixture`: `ALL_VG_GATES=PASS` (`VG-0`..`VG-17`); `V2_FIXTURE_ROWS=157 V2_FIXTURE_DIFFS=0`.
- `npm run lint`: pass. `npm run build`: pass (`dist/_worker.js` 6106.4 KB).
- Live Worker parity at revision `2026-10-26-atomic-list-balance`: the atomic-list reproduction document with `split_list_items: false` renders identically to local in both `base` and `bauhaus` — 4 pages each, equal byte size, `X-Cache: MISS`, text-run drift `0.000`, `0` text diffs.

Counts are evidence of the snapshot, not contracts. Adding a test should change the count; that is expected.

## Verify suites

`src/v2/qa/verify-suite.js` runs nine suites. Each suite prints `PASS`/`FAIL` and the process exits non-zero on failure. You can filter by passing a suite name as an argument (for example, `node src/v2/qa/verify-suite.js grid`).

| Suite | Checks |
| --- | --- |
| `grid` | 80-row table + heading-dense document; ≥2 pages, no empty page, frozen IR, table slices, tracer counters, baseline audit, keep-with-next, orphan/widow units, command count |
| `determinism` | Same seed+timestamp → identical SHA-16; timestamp+1000 ms → different bytes |
| `isolation` | Driver rejects AST/closures; accepts frozen IR; blaster import audit; idempotent freeze; image Buffer passes through |
| `roundtrip` | 200 seeded random documents: parse → serialize → parse preserves block count/type/table alignment and validates AST |
| `concurrency` | 10 pool jobs; valid buffers; pool accounting; event-loop samples; max loop lateness <400 ms |
| `fit` | Exact base/compact pitch and grid tokens; fit audit non-vacuous with zero overflows; impossible fit gate throws `FIT_GATE` |
| `assets` | SSRF private/public/obfuscated IPv4; supported types; PNG magic; 1×1 probe; validation; data URI; traversal/empty blocked |
| `dualrun` | `runBoth({dual:true})` parity; Typst source length; PDFKit boxes >0 |
| `spangates` | Frozen `span-baseline.json` for four docs; core diagnostics; `overfullColumns===0`; even-galley order/disparity |

`src/v2/qa/span-gates.js` exports the pure predicates used by the span suites: `checkColumnOrder`, `checkDisparity`, `checkDiagnostics`.

## Lean catalog (65 files)

### Ingest, math, and contracts (8)

| File | Purpose |
| --- | --- |
| `autofix-arrows.lean.js` | Composite arrow ordering (`<=>`, `<->`) through autofix |
| `autofix-fencing.lean.js` | Code spans/URLs stay byte-identical; selective prose fixes; no sentinel leak |
| `block-option-lifecycle.lean.js` | Per-block `split_equations`, `auto`, and `autofix` are honored |
| `display-math-guards.lean.js` | Unclosed/trailing `$$` never swallows prose |
| `inline-math-scripts.lean.js` | Braced sub/sup groups stay whole; unmappable body is one styled run |
| `math-escapes.lean.js` | `\%`, `\_`, `\begin`/`\end`, currency literals |
| `math-fencing.lean.js` | `\text`/`\%` math survives autofix; `$$`/currency guards |
| `nested-frac.lean.js` | Recursive `\frac{\text{…}}` expansion |

### Layout, pagination, vertical justification (14)

| File | Purpose |
| --- | --- |
| `atomic-list-balance.lean.js` | `split_list_items: false` honored end to end: zero list-item splits; continuous-fill disparity triggers whole-item rebalance; interior fixture columns land within 14 pt of the region foot; flush continuous pages stay untouched |
| `column-band-structure.lean.js` | Rendered band-top alignment; no empty right column mid-document; compact/flush-off pre-table region |
| `column-flow.lean.js` | Straight-flow default vs opt-in balance; document break control; flush toggle; continuous fill |
| `column-foot.lean.js` | Corpus foot disparity mean ≤6 pt; terminal section end ≤66 pt / mean ≤14 |
| `continuous-fill.lean.js` | Progress guarantee must not strand a block-opening heading |
| `gap-distribution.lean.js` | Seam capacity is an invisibility budget; absurd void refused; no visible hole |
| `glue-allocator.lean.js` | Resolver boundary matrix: zero/negligible/at-1.0/over/zero-capacity/mixed scope/total |
| `glue-smoothness.lean.js` | Bounded gradient not uniform step; ceiling respected; flush retained |
| `justify-corpus.lean.js` | Exact 157-row `vertical-justify.json` lock + G18 dead-symbol grep |
| `percol-funding.lean.js` | Per-column independent funding; bounded lift; heading bonds; span scope; sample2 integration |
| `stretch-seam.lean.js` | Class table/capacities; one seam per boundary; `{seamSeq,scope}`; derived Y list |
| `terminal-balance.lean.js` | Last page's columns end together across six scenarios |
| `vertical-justify.lean.js` | G12/G13/G14/G15/G16/F-9 corpus invariants |
| `geometry-v3-gates.lean.js` | V3 gates `VG-0`..`VG-17`, `F-6`/`F-13`/`F-14` regression checks, synthetic multi-element stress across 3 templates, 30-seed PRNG fuzzing, and Frontend-to-Backend (`DocumentStore` → `ExportPayloadBuilder` → `paginate`/`convertDocument`) E2E seam |

### Columns and spans (4)

| File | Purpose |
| --- | --- |
| `span-coordinator.lean.js` | Pure span policy for compact/panoramic/rotated/image/rule |
| `span-baseline.lean.js` | Four docs match the frozen span diagnostics |
| `span-gates.lean.js` | Balancer order/disparity plus fixture repeat |
| `span-parity.lean.js` | Coordinator flag on/off produces identical core output for sample3/text-test |

### Headings (5)

| File | Purpose |
| --- | --- |
| `heading-rhythm.lean.js` | Monotonic heading tokens per template; heading-run pagination |
| `heading-run-fit.lean.js` | Four named G19b shapes plus corpus-wide no-bare-heading |
| `heading-run-order.lean.js` | G19c reading order; exactly two known inversions (`sampletext2/base`, `sampletext2/bauhaus`) |
| `stacked-sliver-order.lean.js` | Minimized doc across three templates; child never before parent; non-vacuous |
| `stranded-heading.lean.js` | G19: six docs × three templates, zero stranded headings |

### Tables and captions (5)

| File | Purpose |
| --- | --- |
| `caption-glue.lean.js` | Region-opening caption before a panoramic span is span-scoped; no closing punctuation/script at line start |
| `caption-promotion.lean.js` | Mid-bite H3/bold-colon bullet promotes; plain bullet does not; balanced-prefix room; symmetric rhythm |
| `table-first-col-shard.lean.js` | Bold first-column words stay whole in compact/auto; crowded prefers no orphan shard |
| `table-header-band.lean.js` | No dark full-width band; dark header text |
| `table-math-pipe.lean.js` | Pipe inside `$…$` is cell content, not a column split |

### Images and security (1)

| File | Purpose |
| --- | --- |
| `image-normalize-m1.lean.js` | GIF/BMP transcode locks; white canvas fill; HEIC fast-fail; uploader error surfacing |

### Typography and metrics (4)

| File | Purpose |
| --- | --- |
| `emoji-fallback.lean.js` | Pure splitting; Noto only for emoji; finite measure |
| `measure-calibration.lean.js` | Legacy estimate rates; coordinator box match; real/stub measurer; idempotent opts |
| `measure-wiring.lean.js` | Default vs real measurement; Typst-source opt-in |
| `shaping-layout-cache.lean.js` | `attachFkFontLayoutCache` returns per-call position copies, so Worker `FK_PARSED_CACHE` font reuse cannot double-scale glyph advances (compressed-text regression) |

### Engine and runtime contracts (6)

| File | Purpose |
| --- | --- |
| `pdf-engine-seam.lean.js` | Image collection/dedupe/order/concurrency; option alias canonicalization; lazy engines; “estimated” pagination honesty |
| `elastic-counter.lean.js` | Legacy `{items,headings,paras}` parity; GFM/image/math coverage |
| `typst-compile.lean.js` | Fake-binary roundtrip; timeout; missing binary; env resolution; asset sandbox |
| `rate-limit.lean.js` | Fixed window/429/Retry-After/reset/keying/envInt |
| `export-payload.lean.js` | Builder alias/engine/title rules; versioned storage envelope; legacy migration |
| `worker-bundle-safety.lean.js` | Static `src/_worker.js` import graph never evaluates `import.meta.url` at module scope (Cloudflare upload error 10021); function-scoped uses allowed |

### Frontend and editor (15)

| File | Purpose |
| --- | --- |
| `bold-idempotent.lean.js` | Bold involution, `***`, hug-strip, partial selection, state probe |
| `box-collapse-m4.lean.js` | Two-phase fade (`is-closing`/`hidden`); flex untouched |
| `editor-adapters.lean.js` | Adapter contract get/set/insert/undo/redo/exec/DOM-safe |
| `empty-hints-m3.lean.js` | Textarea placeholder and rich empty hint |
| `global-find-m5.lean.js` | Docked find bar, Ctrl/Cmd+K, per-card untouched, trigger homes |
| `insert-parity.lean.js` | Catalog/snippets byte-identical; H4 seam; markdown bar |
| `island-toggle-gates.lean.js` | Figure/table byte-identity through store/undo/update; normalize idempotence; IME/caret |
| `menu-keyboard-m6.lean.js` | `slashNavIndex` and portal roving focus |
| `mobile-theme-m7.lean.js` | Theme toggle rides the “Mais” sheet; init/persist |
| `portal-lifecycle.lean.js` | Shared layer/shelf; close/purge; SSR no-op; fixed positioning; mode switch |
| `rich-blocks.lean.js` | Card count survives reserialize (insert/append/move/CRLF/CR) |
| `rich-commands.lean.js` | Command toggles; undo limit; lists/numbering/indent/range mapping |
| `save-indicator-m2.lean.js` | Save pill; single save choke; pagehide flush; token-only |
| `slash-paste.lean.js` | Slash nav wrap/reset; paste URL over selection; link unwrap |
| `undo-redo-buttons.lean.js` | Adapter `canUndo/canRedo`; toolbar icons; disabled sync |

### Performance and termination (3)

| File | Purpose |
| --- | --- |
| `stranded-replan-bound.lean.js` | Real child process probes the two known-hang cases (`sampletext2/bauhaus`, `/bauhaus_minimalist`) with a 20 s budget; corpus non-vacuity |
| `table-region-zero-placement.lean.js` | Real child process: a 16-row table arriving after two tables on a 298.7 pt region and a 220-row table at page top both terminate; pins the region-planner progress guarantee |
| `compiler-efficiency.lean.js` | Wave 12 hot-path locks: trigger-indexed inline-run parsing, batch `TypographicAutofix`, single-pass word measurement, 3-tier incremental cache (`>= 2.2x` speedup), warm Worker `/api/paginate` under 10 ms, zero-drift V2/V3 parity |

## Design catalog (9 files)

The design tier is a set of **source/CSS tripwires** (`npm run test:design`, 38 tests across 9 suites) paired with `scripts/design_guardrails.py`. They parse CSS strings and assert exact tokens, WCAG contrast ratios, 4px grid compliance, or check that `v2-app.js` and `DESIGN.md` contain required structural idioms.

| File | Locks |
| --- | --- |
| `visual-w1-cards-topbar.lean.js` | Focus ring uses `var(--focus-glow)`, no `color-mix`; card hover hairline, no shadow/rgba; token-only brand/primary buttons; nowrap topbar/card toolbars |
| `visual-w2-pane.lean.js` | `field-row` min-height token; accordion head min-height; tabular TOC page numbers; focus-visible segment ring |
| `visual-w3-mobile-tokens.lean.js` | Sheet/drawer backdrops use `var(--color-backdrop)`; mobile bubbles token-only; mobile action labels nowrap |
| `visual-w4-block-chrome.lean.js` | Card toolbar opacity 1; hairline footer, 12px muted text; pill mode switch; right-aligned tabular char count |
| `visual-w5-editor-surfaces.lean.js` | Editor surfaces 12px/8px radius, 132px/42vh shell, 14px/1.6 type, inset cue; H1 preview token; autosize cap |
| `visual-w6-config-collapse.lean.js` | `is-closing` uses `0fr` + opacity, no `display:none`; JS drives two-phase close via `_configCloseT` |
| `visual-w9-insert-unified.lean.js` | Single portal insert idiom; no retired `md-insert-*`/`data-mi`; catalog and gutter selectors |
| `visual-w10-menu-viewport.lean.js` | Portal menu `max-height` viewport clamp, `overflow-y:auto`, width clamps, two-column fallback |
| `visual-w11-guardrails.lean.js` | 3-layer token discipline (0 raw hex/rgba in semantic blocks), WCAG AA `--ink-mute` (`#626770`, `>= 4.5:1`), 4px structural grid & closed radius scale, `text-wrap: balance/pretty`, `@media (hover: hover)`, `100dvh`/`82dvh` viewport caps, in-flow `.rich-composer` pill, and unified `#sheet-body` mobile labels |

## Fixtures

| Fixture | Contents | Consumers | Regeneration |
| --- | --- | --- | --- |
| `tests/fixtures/span-baseline.json` | Seed `span-baseline`, timestamp `1700000000000`, template `base`, four docs; locks `totalPages`, `tableSlices`, `panoramicTransitions`, `overfullColumns`, plus keep-with-next/orphan/widow counters | `verify-suite` spangates, `span-baseline.lean.js`, `span-gates.lean.js` | `npm run baseline:span` (review the diff) |
| `tests/fixtures/vertical-justify.json` | Seed `vertical-justify`, timestamp `1700000000000`; 6 docs × 3 templates × balance false/true; 157 rows with `applied`, `voidPt`, `reason`, `lifted` | `justify-corpus.lean.js` | `node scripts/probe-vertical-justification.mjs --json > tests/fixtures/vertical-justify.json` |
| `tests/fixtures/typst-fake-copy.sh` | Fake Typst binary that copies source to output | `typst-compile.lean.js` | Keep executable (`chmod 755` in test setup) |
| `tests/fixtures/typst-fake-slow.sh` | Fake Typst binary that sleeps, to test timeout | `typst-compile.lean.js` | Keep executable |

`span-baseline.json` only asserts the recorded page counts and the first three diagnostics; the other counters are written but not all consumed. Treat it as a reviewed golden, not proof that every field matters.

`vertical-justify.json` is exact to 0.01 pt across its frozen rows, but `justify-corpus` iterates only the frozen rows; adding a corpus document or a new page does not automatically expand the lock. When the corpus changes, update the fixture deliberately.

The regeneration command for `vertical-justify.json` was verified on 2026-10-21: it produced 157 rows identical to the committed fixture. Do not use the stale comment in the fixture header as the command; use the command above.

## Corpus

`tests/corpus/` contains eight Markdown documents plus `index.js`:

| File | Role |
| --- | --- |
| `sample1.md` | General corpus; span trio; column-flow; verify spangates |
| `sample2.md` | General corpus; span trio; percol-funding |
| `sample3.md` | General corpus; span trio; span-parity |
| `sample4.md` | General corpus; column-flow; heading/stranded suites |
| `text-test.md` | General corpus; span trio |
| `taskfiles/sampletext2.md` (logical name) | Dense corpus; column-band/flow/foot, gap/glue, headings, termination probes |
| `sampletext.md` | Column-band fixture corpus |
| `2-sampletext.md` | Optional compact/flush-off column-band regression; skipped if absent |

The loader `tests/corpus/index.js` maps logical names to flat files:

- `taskfiles/sampletext2.md` → `sampletext2.md`
- `taskfiles/sampletext.md` → `sampletext.md`
- `taskfiles/2/sampletext.md` → `2-sampletext.md`

Tests import `readCorpus(name)` or `corpusPath(name)`. Do not move the corpus back to the repository root; the root is intentionally product-only. If you add a document, add it to the loader/alias map and decide which gates should consume it.

## Determinism and environment

- Every pipeline test passes an explicit `seed` and `timestamp: 1700000000000` (or a suite-specific seed). The verify determinism suite proves same-input hash equality and timestamp sensitivity.
- `parity-harness.mjs` pins a header date (`01/01/2026`) on both engines.
- Tests assume Node 20+ and a POSIX shell. `node --test` runs lean files in parallel child processes; keep tests independent and clean up temp files.
- No network or browser is required for `npm test` or `npm run test:design`. Typst tests use fake binaries; `typst-compile` checks the real seam without requiring Typst.
- `stranded-replan-bound` spawns real child processes and can take several seconds; it is a termination gate, not a unit test.
- There is no runner-level global timeout. Per-test timeouts are local (`stranded-replan` 20 s, Typst 300 ms/10 s, concurrency 400 ms).

## Adding tests

- Put behavioral/unit tests in `tests/lean/` with the `.lean.js` suffix.
- Put exact CSS/source locks in `tests/design/` with the `.lean.js` suffix.
- Import the corpus through `tests/corpus/index.js`, not by hard-coding root paths.
- Use `node:test` and `node:assert/strict`; do not add a test framework or network dependency.
- Prefer a failing test that names the behavior over a broad snapshot.
- If the test needs a fixture, keep it small, deterministic, and checked in. Regeneration must be a checked-in command.
- If a test is intentionally slow (child process, large corpus), state the budget and keep it isolated.

## Coverage gaps

Known gaps, not promises:

- No HTTP-level tests for `server.js` routes, status codes, headers, or upload cleanup.
- No Worker tests for routing, proxy behavior, cache keys, or limits.
- No CI configuration, coverage report, or per-file timeout in this snapshot.
- No byte-for-byte PDF identity guarantee across machines or library versions.
- `npm run parity` is a manual harness and is expected red today; it is not part of `npm test`.
- `span-baseline` is under-asserted (some recorded counters are unused).
- `vertical-justify` only checks frozen rows; corpus growth is not auto-detected.
- Source-grep locks (including G18 dead-symbol checks) fail on comments and refactors even when behavior is unchanged.
- `column-foot` and `column-band` filter absent corpus files; non-vacuity guards reduce, but do not eliminate, silent shrinkage.

When closing a gap, add the smallest executable evidence and update this section.

### Wave 12 — Compiler Efficiency & Cloudflare Free Plan Suite
- `tests/lean/compiler-efficiency.lean.js` (`W12.1`..`W12.6`, 6 tests): Verifies trigger-indexed inline run parsing, batch `TypographicAutofix`, single-pass word measurement, 3-tier incremental section caching (`>= 2.2x` multi-section incremental speedup), warm Cloudflare Worker `/api/paginate` latency (`< 10 ms`), and zero-drift V2/V3 geometric parity.
- `scripts/probe-compiler-efficiency.mjs`: Executable FocusGate verification oracle for `gate-8-compiler-hotpaths`, `gate-9-worker-isolate-budget`, and `gate-10-zero-drift-parity`.
