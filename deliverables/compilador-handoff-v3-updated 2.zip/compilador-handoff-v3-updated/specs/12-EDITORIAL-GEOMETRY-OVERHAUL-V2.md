# 12 — Deterministic Editorial Document Geometry, Fragmentation & Bottom-Padding Overhaul (v2.0 — Template-Aware Edition)

| Field | Value |
| --- | --- |
| **Status** | **Implemented & Active (Wave 13 — `gate-11`..`gate-13` Settled GREEN; 6/6 DOM Audit Gates PASS Across All 9 Templates).** |
| **Date** | 2026-10-27 |
| **Governance** | Audited with **FocusGate v1.0.0-UNIFIED** (`--lint --strict`, `--baseline`, `--settle --strict --receipt`, `--report --fresh`) and **Design Guardrails v3.0** (`design-guardrails.config.json`, `scripts/design_guardrails.py --audit-all`) |
| **Owns** | 96-DPI multi-unit & paper-preset resolver (`A3`, `A4`, `A5`, `Letter`, `Legal`, `Tabloid`, `portrait`/`landscape`), 4-tier template geometry resolution hierarchy, per-page usable height (`firstPage*` vs body pages), dynamic `<style id="editorial-template-page-rules">` injection, transitive heading & list-intro glue clearance, atomic container push-downs & `.allow-emergency-split`, rowspan-safe `<table>` & `<ul>`/`<ol>` continuation splitting, framed-safe `.is-page-bottom` suppression, `generateEditorialPdf`, `initializeEditorialPagination`, and the 6-gate `verifyTemplateEditorialGeometry` audit suite |
| **Does not own** | Server-side PDFKit integer-mpt DisplayList math (`08-LAYOUT-GEOMETRY-V3.md`), Worker isolate LRU caches (`11-COMPILER-EFFICIENCY-W12.md`) |

---

## 1. Locked Architectural Constraints

1. **Template-Driven Geometry:** Page dimensions, orientation, margins, running header/footer safe zones, first-page overrides, and push-down thresholds are dynamically resolved per active template (`design-guardrails.config.json` template profiles + DOM `[data-template]` attributes + CSS Custom Properties `--template-*`).
2. **Continuation Markers:** Physical DOM splitting via JS (`EditorialGeometryEngine`) for multi-page tables and lists, injecting a localized `<div class="continuation-marker">(Continuação...)</div>`, cloning `<thead>`, relocating `<tfoot>` to the terminal segment, and preserving `<ol start="N">` numbering.
3. **Atomic Containers & Callouts:** Strict atomic push-down (`break-inside: avoid !important` + JS measurement verification) for callouts, advisory boxes, metric/stat cards, blockquotes, figures, and signature zones, with `.allow-emergency-split` fallback when an atomic block exceeds a full blank page.
4. **Transitive Heading & List-Intro Glueing:** Mandatory physical binding of `h1`–`h4` chains and `.list-intro` / `[data-list-intro="true"]` (plus colon-terminated paragraphs preceding a list) to the first 2 lines of prose, first 2 list items, or `thead` + first 2 table rows (`break-after: avoid-page` + JS transitive clearance verification).
5. **Bottom Margin & Padding Suppression:** JS-injected utility class (`.is-page-bottom`) on the terminal element of every virtual page (and its unframed last-child ancestor chain) to strip trailing whitespace at the page-break boundary without crushing internal padding on bordered/shaded boxes (`.is-framed-box`).

---

## 2. Mathematical Foundations & 4-Tier Resolution Hierarchy

### 2.1 Multi-Unit & Paper Preset Resolution at 96 DPI
- `1in = 96px`, `1mm = 96 / 25.4 px`, `1cm = 96 / 2.54 px`, `1pt = 96 / 72 px`, `1pc = 16px`, `1px = 1px`.
- Presets (`PAPER_PRESETS_MM` in `static/editorial-geometry-engine.js` and `PAGE_SIZES` in `src/v2/core/geometry.js`):
  - `A4`: `210mm × 297mm` (`793.70px × 1122.52px`)
  - `A3`: `297mm × 420mm` (`1122.52px × 1587.40px`)
  - `A5`: `148mm × 210mm` (`559.37px × 793.70px`)
  - `Letter`: `215.9mm × 279.4mm` (`816.00px × 1056.00px`)
  - `Legal`: `215.9mm × 355.6mm` (`816.00px × 1344.00px`)
  - `Tabloid`: `279.4mm × 431.8mm` (`1056.00px × 1632.00px`)
- When `orientation === "landscape"`, `width` and `height` are swapped prior to usable budget calculation.

### 2.2 4-Tier Precedence Order
1. **Tier 1 (Runtime Override):** `options.templateConfig` / `options.geometry` / `options.fragmentation` / `options.templateId` passed to `normalizeEditorialGeometry(documentRoot, config, options)`.
2. **Tier 2 (DOM Template Attribute):** `documentRoot.getAttribute('data-template')` or `document.body.getAttribute('data-template')` matched against `config.templates[templateId]` in `design-guardrails.config.json` (`default`, `base`, `bauhaus`, `bauhaus_minimalist`, `executive-report`, `legal-contract`, `compact-technical`, `landscape-dossier`, `us-letter-brief`).
3. **Tier 3 (Template CSS Custom Properties):** Computed `--template-page-format`, `--template-page-orientation`, `--template-page-width`, `--template-page-height`, `--template-margin-top`, `--template-margin-bottom`, `--template-margin-inside`, `--template-margin-outside`, `--template-header-safe-zone`, `--template-footer-safe-zone` on `documentRoot`.
4. **Tier 4 (Base Guardrail Defaults):** `config.defaults.geometry` and `config.defaults.fragmentation` in `design-guardrails.config.json`.

---

## 3. Module & Deliverable Map

| File | Responsibility |
| --- | --- |
| `design-guardrails.config.json` | Dual-contract config holding Design Guardrails v3.0 archetype/token rules plus `defaults` (`geometry`, `fragmentation`) and 9 template profiles (`default`, `base`, `bauhaus`, `bauhaus_minimalist`, `executive-report`, `legal-contract`, `compact-technical`, `landscape-dossier`, `us-letter-brief`) |
| `static/design-system.css` | `:root` template geometry custom properties, `@page` / `:first` / `:left` / `:right`, `.virtual-page-preview`, orphan/widow & heading/list-intro glue rules, atomic container rules, `.continuation-marker`, and `.js-forced-page-break` / `.is-page-bottom` / `.is-framed-box` suppression |
| `static/editorial-geometry-engine.js` | Isomorphic zero-dependency implementation of `EditorialGeometryEngine`, `normalizeEditorialGeometry`, and `verifyTemplateEditorialGeometry` |
| `pdf-engine.js` | Re-exports `EditorialGeometryEngine`, `normalizeEditorialGeometry`, `verifyTemplateEditorialGeometry`, `DEFAULT_GUARDRAILS_CONFIG`, `UNIT_TO_PX`, and `PAPER_PRESETS_MM` alongside `PdfEngine` and `convertDocument` |
| `pdf-generator.js` | Exports `generateEditorialPdf(page, outputPath, options)` for Chromium/Puppeteer print pipelines alongside legacy/V2 compatibility facades |
| `static/editor-core.js` & `static/v2-app.js` | Exports and wires `initializeEditorialPagination(editorRootElement, initialTemplateId)` on workspace boot, `beforeprint`, and live template switching |
| `scripts/probe-editorial-geometry-v2.mjs` | Executable FocusGate verification probe (`--gate config-css`, `--gate engine`, `--gate all`) |
| `tests/lean/editorial-geometry-v2.lean.js` | Behavioral unit & integration suite for `EditorialGeometryEngine` and all 6 audit gates |
| `tests/design/visual-w13-editorial-geometry.lean.js` | Exact CSS & config tripwire suite for Wave 13 template geometry rules |

---

## 4. Verification Commands

```bash
node scripts/probe-editorial-geometry-v2.mjs --gate all
node --test tests/lean/editorial-geometry-v2.lean.js
node --test tests/design/visual-w13-editorial-geometry.lean.js
python3 scripts/design_guardrails.py --config design-guardrails.config.json --audit-all static --document DESIGN.md
python3 scripts/focus_gate.py --report --fresh --ledger .focusgate/GATES.md
```
