# 08 — Layout Geometry v3 (High-Fidelity Vertical Model)

| Field | Value |
| --- | --- |
| **Status** | **Implemented & Active (v3.1 — M0–M5 Live in Production Pipeline; Frontend Default `geometry: 'v3'`; FocusGate + Design-Guardrails Audited).** |
| **Date** | 2026-10-25 |
| **Basis** | Handoff snapshot 2026-10-25 (`npm test`: 311 pass across 79 suites; `npm run test:design`: 33 pass; `verify-suite`: 9/9 pass; `VG-0`..`VG-17`: 18/18 pass; `vertical-justify.json`: 157/157 rows with 0 diffs) |
| **Governance** | Audited with **FocusGate v1.0.0-UNIFIED** (Red-Before-Green evidence gates, 2-adapter seams, 10-rule `GateIntegrity` checks, Micro-ADRs) and **Design-Guardrails v3.0.0** (declared archetype, 3-layer token hierarchy, WCAG 2.1 AA contrast blockers, Gestalt proximity ratios, measured-vs-threshold reporting) |
| **Owns (on adoption)** | Page frame, baseline model, atoms, spacing/glue, break model, column/band solver, foot/head ink alignment, continuation cues, geometry & token acceptance gates |
| **Supersedes (on adoption)** | `04-LAYOUT.md` §Vertical justification, §Pagination, §Bands/columns/spans, and the height/spacing parts of §Tables, §Images, §Headings |
| **Does not own** | Markdown grammar (03), driver/PDF bytes (05, except §5.11 baseline seam), deployment (06), Knuth–Plass line breaking (see §10, M6) |

Keywords **MUST / SHOULD / MAY** are used in the RFC 2119 sense. Every gate in §7 pairs a measurable metric and threshold with an executable **FocusGate** `CHECK:` and `EXPECT:` contract and its observed baseline state (`RED` or `PASS` on v2 today).

---

## 0. Domain Anchors (FocusGate Micro-Glossary)

To prevent conceptual drift across compiler passes, tests, and drivers, these five terms are canonical:

1. **Atom (`Atom`)**: An indivisible laid-out unit (or a splittable container expanded into line/row sub-atoms) defined strictly by its ink bounding metrics (`height` above its first baseline, `depth` below its last baseline, in integer milli-points `mpt`).
   *Avoid*: "item with trailing space", "box height including parskip/topMargin".
2. **Gap (`Gap`)**: The explicit, discardable vertical glue object between two adjacent atoms (`natural, stretch, shrink, class, penalty, discardable: true`), resolved by maximum collapse (`max(after[A], before[B])`).
   *Avoid*: "seam offset on item height", "trailing padding constant".
3. **Bond (`Bond`)**: A rigid (`stretch = 0, shrink = 0`), unbreakable (`penalty = 10000`) gap that overrides max-collapse to lock an introductory atom (heading, figure, table header) to its immediate follower.
   *Avoid*: "`extraH` heading whitespace", "`AntiOrphanGuard` clearance heuristic".
4. **Band (`Band`)**: A vertical region bounded above and below by full-width (`span: 'page'`) atoms or page frame edges, within which 1 or 2 columns flow in column-major reading order.
   *Avoid*: "`ColumnBand` 12 pt slot grid", "region bite".
5. **Ink Anchor (`headAnchor` / `footAnchor`)**: The exact geometric feature of an atom that touches `frame.top` when first in a column (`capHeight` line for text, top border/decoration edge for boxed/decorated atoms) or `frame.bottom` when last in a column (`descender` line via `lastBaseline = frame.bottom - footDepth` for text, bottom border edge for boxed atoms).
   *Avoid*: "line-box top `el.y`", "approximate bottom `el.y + el.size`".

---

## 1. Summary

**The problem.** Page feet, the space between elements, and column tops depend on *which element happens to be nearest the edge*. The same document looks tidy on one page and loose on the next, and non-terminal pages can even ship with a completely empty right column while the test suite reports `applied: true, voidPt: 0`.

**The cause (measured on both live TTF and AFM metrics, §2).** The current engine makes the page fit by *filling greedily and repairing afterwards*. Spacing is baked into each element's height, every element kind has its own height formula and its own trailing-space constant (or lacks one entirely, as on `blockquote`/`code`/`math` boxes), the column height is never a whole number of lines, and a post-pass (`3b`) then stretches seams within a capped budget. LaTeX does the opposite: spacing is explicit **glue** with stretch and shrink, the page geometry is a whole number of baselines, spacing at a break is **discarded**, and the **break itself is chosen by cost** so the glue rarely has to work hard.

**The answer.** Rebuild the vertical engine on the TeX page-builder model, adapted to this product:

1. **One vertical model.** Baseline-based atoms (`height`/`depth` in integer `mpt`) separated by **gaps** (`natural`, `stretch`, `shrink`, `penalty`). Spacing is owned by the gap, never by the element.
2. **A frame that is a whole number of lines.** Column height, first baseline (`topskip`) and last baseline (`footDepth`) are derived from the template and real font metrics once, so a page of plain text is flush with *zero* stretch.
3. **Ink-aligned head and foot.** Whatever kind of element is first or last in a column, its *ink* touches the same line (`frame.top` at the head, `frame.bottom` at the foot). This removes "depends on the element at the bottom".
4. **Breaks chosen by cost.** Widow/orphan/keep-with-next/heading rules become a single penalty table. The five ad-hoc keep-with-next mechanisms and the uncapped replan loops are retired.
5. **A bounded fit ladder with typed reasons.** Frame snap → break choice → gap stretch/shrink → splitting → (opt-in) uniform leading flex → *honest ragged with a reason code*. No silent voids.
6. **Per-column and design-system gates.** v3 measures every column (`col:0` and `col:1` independently), enforces 3-layer token purity (`0` `tmpl.id` branches in compiler passes), and fixes WCAG 2.1 AA contrast blockers (`rulegray` misused on text).

**What does not change.** Block-per-page chapters, TOC reservation, masthead, panoramic/rotated tables, table row splitting with repeated headers, terminal band balancing by default, continuation cues (`column-cross` and `region-tail`) when `balance_columns: true`, determinism, the pure compiler → frozen DisplayList → driver boundary, the `estimate == render` fit audit, and the three templates' visual identity (§8, "natural-gap parity" with explicit carve-outs for v2's `heading.extraH` and `0 pt` box-bottom defects).

**Expected outcome on the existing corpus (targets, §7).** Column feet within `0.25 pt` on every non-terminal flush column (today under live TTF metrics: `107 / 121` populated feet within `1 pt`, `14` at `> 20 pt`, plus `1` completely empty `778.21 pt` right column on `sample2.md × bauhaus_minimalist` p.1); zero unexplained voids anywhere; column tops identical within `0.1 pt`; page-to-page spacing variation roughly halved; zero WCAG contrast blockers.

---

## 2. Evidence from the current engine

All findings below are verified directly against the handoff snapshot (`compilador-handoff`) using both **live TTF metrics** (`createMeasureContext` with vendored `Arimo`, `Inter`, `NotoEmoji` — reproducing `tests/fixtures/vertical-justify.json` across all 157 rows with 0 diffs) and **AFM-estimate metrics**.

### 2.1 Findings

| # | Finding | Code & Measured Evidence |
| --- | --- | --- |
| **F-1** | **Spacing is baked into item height, and fit is tested against it.** A paragraph is `n·p + parskip`; the placement test is `item.height <= remaining + OVER_TOL (1 pt)`. A trailing gap that should vanish at a column foot is *charged* against it, so whether the last item fits depends on its kind's trailing constant. | `geometry-compiler.js:1090` (`lines.length * bodyLineH + parskip`), `1925` (`itemH <= remaining + OVER_TOL`) |
| **F-2** | **Eight independent height formulas**, none sharing a spacing vocabulary. | `paragraph`: `n·p + parskip` (`1090`); `heading`: `topMargin + n·(fs·ratio+0.8) + extraH` (`1427`); `code`: `n·p + 10` (`1124`); `blockquote`: `n·p + 10` (`1463`); `rule`: `8` (`1446`); `math`: `n·mLineH + 14` (`1664`); `table`: `topGap(6) + headerH + bodyH + heavyRule + bottomGap(6)` (`1382`); `list-item`: `n·pitch(liSize) + liSep + [topSep] + [bottomSep]` (`1754, 1782-1783`); `image`: `targetH + captionH + 10` (`1561`) |
| **F-3** | **The frame is never a whole number of lines.** Column height `H` ÷ `bodyPitchPt` = **60.82 / 64.53 / 72.87** (`base` / `bauhaus` / `bauhaus_minimalist`). With `topskip` and `footDepth` accounted for using real OS/2 font metrics, `span / u0` = **60.13 / 63.85 / 72.14**. A fractional line (`≈ 1.6–9.8 pt`) is a standing deficit on every page that the glue pass has to hide. | `H = 755.61 / 764.62 / 778.21 pt`; `u0 = 12.4241 / 11.8491 / 10.6797 pt` (§5.2) |
| **F-4** | **Several line pitches live in one column.** Lists use their own font size and pitch per nesting level (`base`: `11.779 / 11.779 / 11.549 / 10.974 pt` for L1–L4; `bauhaus`: `10.974 pt` vs `11.849 pt` body); headings use `fs·ratio + 0.8`; math uses `9·ratio + 0.8` (`11.149 / 11.690 pt`); tables use `bodyFontSize·ratio + 0.8`. A flush-off run produces **46 / 36 / 38 distinct** baseline-to-baseline steps (`base` / `bauhaus` / `bauhaus_minimalist`). | `geometry-compiler.js:154-161` (`listBodySize`), `1044` (`pitch`); `verify-suite.js` `grid` reports `baselineSnapViolations = 170 / 174` (`compliantRatio = 0.023`) |
| **F-5** | **Repair after the fact.** Greedy fill, then a post-pass (`3b`) stretches seams within `0.35u × class` capacity under a `0.30u` perceptibility ceiling (`boundedLift` ramp). In the committed `vertical-justify.json` fixture: `103` applied / `36` `block-end` / **`18` `partial-lift`** of `157` pages. The repair makes spacing *vary page to page*: under live metrics, per-page mean inter-block step `σ` rises from `0.28 / 0.25 / 0.11 pt` (flush off) to **`0.83 / 0.73 / 0.54 pt`** (flush on). | `geometry-compiler.js:3117-3457`; `tests/fixtures/vertical-justify.json`; probe §2.2 |
| **F-6** | **Both acceptance metrics (`G12` and `column-band-structure`) have a blind spot for empty right columns.** `G12` (`vertical-justify.json`) measures only the *deepest element on the page*. `column-band-structure.lean.js:143` flags an empty right column *only* when the left column also ends `> 90 pt` above the floor (`if (Math.min(...left) - 20 > 90)`). Consequently, when `col:0` flushes to the foot and `col:1` is completely empty, **every existing gate passes**. | **Live metrics (`vertical-justify.json` row 55):** `sample2.md × bauhaus_minimalist` p.1 (`balance: false`) has `col:0` flushed (`73` lines, `void = 0 pt`) and **`col:1` 100% empty (`0` lines, `778.21 pt` void)**, recorded as `applied: true, voidPt: 0`. **AFM metrics:** `sample1.md × bauhaus_minimalist` p.4 has `col:0` flushed (`void = 0 pt`) and `col:1` empty below a panoramic table (**`696.59 pt` foot void**, `526.7 pt` empty post-table region). |
| **F-7** | **Column tops differ by first-element kind.** Heading `topMargin` is zeroed only for the first item of a *block* (`items.length === 0`, line 1415), never at subsequent column or page tops; list `topSep` (`1.2 / 2.5 pt`, line 1782) is added to the first L1 item of every list run regardless of column top. | `geometry-compiler.js:1415, 1773-1784`; `sample1.md × bauhaus_minimalist` p.5: left column first text at `y = 37.34` (live) / `38.84` (AFM), right column at `y = 34.84` (`2.5–4.0 pt` spread); `sampletext2.md × base` p.2–3: `6.0 pt` top spread (`151.58` vs `145.58`) |
| **F-8** | **Tokens leak into code, and a dead float-equality branch is duplicated.** There are **41 `tmpl.id` checks across 37 lines in 5 files**, and `tmpl.lineStretch === 1.2` is tested by float equality in two places even though no template has `lineStretch: 1.2` (`bauhaus` is `1.18`), making the intended `2.5 / 2.0 pt` modern rhythm branch dead code. | `tmpl.id` count: `geometry-compiler.js` (27 lines / 31 checks), `toc-module.js` (7), `definitions.js` (1), `math-module.js` (1), `blaster.js` (1). Dead `lineStretch === 1.2`: `definitions.js:402-403` **and** `geometry-compiler.js:4119` |
| **F-9** | **One 2,868-line `compile()` method; keep-with-next implemented five ways** (`AntiOrphanGuard.calculateRequiredClearance`, `_continuousFill` opening-heading deferral, `balancePlan` `tailStranded` shrink loop, column-boundary `endsHeading(c1)` shift loop, and `c2TailChild` pull-in / `followerFits` pop), plus **37 uses of `OVER_TOL`**. When `endsHeading(c1)` truncates `cursor = biteStart + c1.length - 1` (`line 2737`) in continuous mode, the next replan places the shrunken bite entirely in `col:0` and leaves `col:1` empty — directly causing the F-6 empty-right-column collapse! | `geometry-compiler.js:854-3722`; `galley-engine.js:48-84, 198-262`; `tests/lean/stranded-replan-bound.lean.js` |
| **F-10** | **Four models of the same vertical quantity.** (a) `geometry-compiler.js` point-height items; (b) `ColumnBand` (`layout/column-band.js`), a 12 pt grid-slot model that live `compile()` never calls; (c) `layout/coordinator.js` + `layout/measure-calibration.js` flat rates (`heading: 14, hr: 10, image: 130, math: 24, para: 12/line`, `availableHeight: 700`) used by `/api/paginate` (`pdf-engine.js:270`, `src/_worker.js:244`) and `mode: 'typst-source'`; (d) `V2MulticolGalleyBalancer` (`default maxAvailableHeight: 700`) and `layout/autobalance.js`. | `specs/02-ARCHITECTURE.md` §Known seams: frontend `/api/paginate` consumer (`static/v2-app.js:2274-2308`) expects 1-based `index`, `bodyPage`, `startPage`, and `headings[]`, which `calculatePagination()` never returns |
| **F-11** | **Vertical position is a line-box top (`el.y`), not a baseline.** The driver draws `doc.text(str, x, el.y)`, placing the glyph baseline at `el.y + (ascender / unitsPerEm) · size`. Meanwhile `elementExtent` (`stretch-seam.js:138`) and `auditBottomMargin` (`geometry-compiler.js:4472`) approximate a text element's bottom as `el.y + el.size`. Because `(ascender + |descender|) / unitsPerEm` is `1.117` (`Arimo`) and `1.210` (`Inter`), `el.y + el.size` understates true descender ink by **`1.11 pt` (`base`) to `1.68 pt` (`bauhaus_minimalist`)**. | `blaster.js:620`; `stretch-seam.js:138`; `geometry-compiler.js:4472`; `metrics.js:114` |
| **F-12** | **Line breaking is greedy.** A complete Knuth–Plass breaker (`layout/knuth-plass.js`, 382 lines) and Portuguese/Spanish/English hyphenator (`layout/hyphenation.js`) exist, but `geometry-compiler.js` uses greedy `wrapRunsToLines` with syllable splitting only for words wider than `safeW`. | `geometry-compiler.js:250-466`; `layout/knuth-plass.js` (0 imports in `src/`) |
| **F-13** | **Boxed atoms (`blockquote`, `code`, `math`) have `0 pt` external bottom gap, while non-underlined headings carry `4–10 pt` of accidental `extraH` bottom bloat.** `blockquote` (`+10`), `code` (`+10`), and `math` (`+14`) draw their background `rect` to `height: item.height` (`lines 4138, 4157, 4175`), consuming the entire constant as internal padding and leaving **0 pt outside gap below the box**. Conversely, `headingDecorators` sets `extraH: 4..10 pt` on all headings (copied from `base` H1 where `extraH: 8` holds the underline at `height - 2`). On all 11 non-underlined heading styles across the 3 templates, `extraH` becomes dead space *after* the heading, yielding ink-to-ink `before / after` proximity ratios of **0.86 to 1.11** (violating the `>= 1.5` proximity law). | `geometry-compiler.js:1414, 1427, 4043, 4132-4188`; `definitions.js:113-116, 238-241, 365-368`; measured ink-to-ink table in §5.4.3 |
| **F-14** | **WCAG 2.1 AA contrast blockers on `rulegray` text bindings + single-page TOC overflow hazard.** Image captions (`geometry-compiler.js:4257`), image fallback placeholders (`4277`), and TOC running headers (`toc-module.js:58`) use `tmpl.colors.rulegray` as a *text* color. On `base` (`#9CA3AF`) and `bauhaus` (`#94A3B8`), contrast against `#FFFFFF` is **2.54:1** and **2.56:1** (**2.43:1** and **2.45:1** on `#F9FAFB`/`#F8FAFC` surfaces) — failing WCAG AA (`>= 4.5:1`). Furthermore, `geometry-compiler.js:914` hardcodes a 1-page reservation (`getOrCreatePage(0)`) for `chaptersToc`, and `toc-module.js:590-767` draws all chapter/subheading rows on Page 0 without checking `doc.y > contentBottomY`. | `geometry-compiler.js:914, 4257, 4277`; `toc-module.js:58, 590-767`; Design-Guardrails audit §4.2 |

### 2.2 Measured baseline (Dual-Metric: Live TTF vs AFM Estimate)

Running `scripts/probe-geometry-baseline.mjs` (Appendix D) across the 6 corpus documents (`sample1.md`, `sample2.md`, `sample3.md`, `sample4.md`, `text-test.md`, `taskfiles/sampletext2.md`) × 3 templates (`base`, `bauhaus`, `bauhaus_minimalist`) × `flush_columns ∈ {true, false}`, measuring **per column** on non-final pages:

#### A. Live TTF Metrics (`createMeasureContext`, production PDFKit parity — matches `vertical-justify.json` 157/157 rows)

| Mode | Non-final pages | Populated columns | Column feet within 1 pt | Feet with >20 pt void | Empty right columns (`col:1` = 0 lines) | L/R foot disparity >1 pt |
| --- | --- | --- | --- | --- | --- | --- |
| `flush_columns: true` (default) | 61 | 121 (of 122) | **107 / 121** (`107 / 122` total) | **14** (up to `175.11 pt`) + **1 full-column void (`778.21 pt`)** | **1** (`sample2 × compact` p.1) | **7 / 60** (`8 / 61` incl. empty `col:1`) |
| `flush_columns: false` | 61 | 121 (of 122) | **0 / 121** | **61** (up to `215.05 pt`) + **1 full-column void (`778.21 pt`)** | **1** (`sample2 × compact` p.1) | **58 / 60** (`59 / 61` incl. empty `col:1`) |

#### B. AFM-Estimate Metrics (headless `new GeometryCompiler().compile()` without injected `measure`)

| Mode | Non-final pages | Populated columns | Column feet within 1 pt | Feet with >20 pt void | Empty post-span columns | L/R foot disparity >1 pt |
| --- | --- | --- | --- | --- | --- | --- |
| `flush_columns: true` (default) | 62 | 124 | **114 / 124** | **10** (up to `696.59 pt`) | **1** (`sample1 × compact` p.4, `696.59 pt` foot void) | **6 / 62** |
| `flush_columns: false` | 62 | 124 | **0 / 124** | **69** (up to `704.03 pt`) | **1** (`sample1 × compact` p.4, `704.03 pt` foot void) | **60 / 62** |

#### C. Rhythm Stability (`σ` of per-page mean inter-block step, `11.9–17.0 pt` window) and Performance Baseline (`VG-15`)

| Template | Live `flush: true` (min / max / **σ**) | Live `flush: false` (min / max / **σ**) | AFM `flush: true` (**σ**) | AFM `flush: false` (**σ**) |
| --- | --- | --- | --- | --- |
| `base` | `12.80` / `15.98` / **`0.83 pt`** (n=23) | `12.41` / `13.62` / **`0.28 pt`** (n=23) | `0.82 pt` | `0.28 pt` |
| `bauhaus` | `12.52` / `15.24` / **`0.73 pt`** (n=20) | `12.69` / `13.53` / **`0.25 pt`** (n=20) | `0.63 pt` | `0.24 pt` |
| `bauhaus_minimalist` | `12.47` / `14.19` / **`0.54 pt`** (n=18) | `14.03` / `14.38` / **`0.11 pt`** (n=18) | `0.48 pt` | `0.14 pt` |

- **Compile performance baseline (`VG-15`, live metrics, 18 doc×template pairs × 3 warm passes = 54 runs):** `p50 = 65.46 ms`, `p95 = 171.04 ms`, `max = 209.38 ms`.

### 2.3 What is already good and must be preserved

Purity (compiler never touches drivers/IO), determinism and quantization (`q(4)`), the injected `measure` seam (`estimate == render`), the fit audit (`auditEstimateRenderFit`), keep-with-next *as an outcome*, table row splitting with repeated headers and `(continuação)` labels, caption promotion, span/panorama bands, per-block fresh page, default terminal-band balancing with line-quantized seam splitting (`terminal-balance.lean.js`), opt-in continuation cues (`_stampFlowCues`: `column-cross` and `region-tail`), the documentation/alterations discipline (`AGENTS.md`), and the 9 verify + 59 lean + 8 design test suites. v3 changes the *vertical mechanism*, not these product guarantees (§6.4).

---

## 3. How LaTeX gets it right — and what we take

### 3.1 The mechanisms that matter

1. **Boxes have height *and depth*, and lines sit on baselines.** `\baselineskip` is a baseline-to-baseline distance; TeX inserts glue `= baselineskip − depth(prev) − height(next)` (or `\lineskip` if that would be smaller than `\lineskiplimit`). Every running text line sits on the same pitch regardless of its glyphs.
2. **Space is glue: natural, stretch, shrink.** `\parskip` in standard classes is `0pt plus 1pt`; section spacing is e.g. `3.5ex plus 1ex minus .2ex` before and `2.3ex plus .2ex` after. Elasticity lives *between blocks*, not inside paragraphs.
3. **Spacing at a break is discarded.** Glue, kerns and penalties at a page/column break vanish up to the next box. The fit test sees only content up to the break. Nothing "trailing" is ever charged to the foot, and nothing "leading" appears at the top.
4. **`\topskip` and `\maxdepth`.** The first baseline sits `\topskip` below the top whatever the first text box is; the last box's depth is bounded by `footDepth` so the *last baseline* defines the foot. Class designers choose `\textheight` so `(\textheight - \topskip) / \baselineskip` is an integer.
5. **The break is chosen by cost, not by "first thing that doesn't fit".** At each legal break the page builder computes badness `b = min(10000, round(100 · |r|^3))` (`r` = deficit/stretch or overflow/shrink; `10000` if shrink is insufficient) and cost `c = b + p`, then breaks at the minimum-cost candidate.
6. **Penalties encode typography.** `\clubpenalty`/`\widowpenalty` (`150`), `\brokenpenalty` (`100`), `\interlinepenalty` (`0`), `\nobreak` (`10000`) after headings, and `\@afterheading`, which sets `\clubpenalty = 10000` for the first paragraph after a heading so a heading always carries at least two lines with it.
7. **`\flushbottom` vs `\raggedbottom`.** Under `\flushbottom`, TeX stretches vertical glue to meet the foot and reports an *underfull vbox* when stretch is insufficient — it never hides an empty column behind a neighbour column's foot.
8. **`multicol`** cuts one galley into equal-height columns (`\vsplit`), finishes each with its own glue stretch, and balances the last page of each environment. `\columnsep`, `\columnseprule`, `\multicolsep` and `\premulticols` give spans and column groups defined spacing.
9. **Integer arithmetic.** TeX works in scaled points (`1 sp = 1/65536 pt`), so sums are exact and layouts reproduce bit-for-bit. v3 uses integer milli-points (`1 mpt = 0.001 pt`).

### 3.2 Crosswalk

| Concern | TeX / LaTeX | Current engine (v2) | **v3 normative decision** |
| --- | --- | --- | --- |
| Vertical unit | box `height + depth` + baseline | top-`y` + item height (`F-11`) | **Atoms with `height`, `depth`, `firstBaseline`, `lastBaseline` in `mpt`** (§5.3) |
| Line spacing | `\baselineskip`, `\lineskip`, `\lineskiplimit` | per-item pitch constants (`F-4`) | **One snapped pitch `u` per template**; rigid interline glue (§5.2) |
| Space between blocks | glue; `\addvspace` collapses by max | trailing constants summed into item heights (`F-1`, `F-2`, `F-13`) | **Explicit `Gap` tokens; collapse by `max(after[A], before[B])`** (§5.4) |
| Page top | `\topskip` | none (`F-7`) | **`topskip = capHeight · bodySize` + `headAnchor` ink-head** (§5.2, §5.8) |
| Page foot | whole baselines + `\maxdepth` | float `contentBottomY` (`F-3`) | **Frame snap + `footDepth = |descender| · bodySize` + `footAnchor` ink-foot** (§5.2, §5.8) |
| Break spacing | discarded | charged against remaining height (`F-1`) | **Discarded at all breaks** (§5.4) |
| Typography rules | penalty table | five ad-hoc mechanisms + replan loops (`F-9`) | **One closed penalty table** (§5.5) |
| Break choice | `min(b + p)` within window | greedy fit + post-pass repair (`F-5`) | **Cost-based solver** (§5.7) |
| Flush / ragged | stretch switch; underfull reported | post-pass with caps, silent per-column voids (`F-6`) | **Fit ladder + per-column typed reasons** (§5.6) |
| Columns & terminal band | equal-height cuts; last-page balance | `_continuousFill` + ±3 search + tail seam split | **Single-galley solver slices columns; terminal band balanced by default** (§5.7) |
| Floats / spans | float queues | in-flow panoramic spans | **In-flow bands** (§5.7); image fit scale opt-in (`ADR-0806`) |
| Numbers | integer `sp` | IEEE-754 float + `q(4)` | **Integer milli-points (`mpt`) internally; `q(4)` at DisplayList emit** (§5.1) |

---

## 4. Design-Guardrails Discipline & Audit

Applying `design-guardrails` v3.0.0 to a print-compilation engine: UI-only rules (touch targets, hover states, responsive breakpoints) belong to `static/` (`npm run test:design`), while **system archetype, 3-layer token hierarchy, closed vocabularies, WCAG 2.1 AA contrast blockers, Gestalt proximity (`outside >= 1.5x–2x inside`), base-multiple spacing, and measured-vs-threshold reporting** govern the print layout and template definitions directly.

### 4.1 Declared Engine Archetype (held everywhere)

| Dimension | Declaration |
| --- | --- |
| **Purpose & Audience** | Dense, scannable two-column clinical and engineering study notes compiled from Markdown to A4 PDF |
| **Aesthetic Direction** | Three disciplined editorial families (`base`: Swiss editorial with hairline rules; `bauhaus`: Linear studio with sapphire pill accents; `bauhaus_minimalist`: high-density engineering with teal markers and Inter typography) |
| **Vertical Base (`u`)** | One snapped body pitch `u` per template (`12451 / 11821 / 10701 mpt`); every vertical rhythm step is a multiple of `u` or an atom's own ink box |
| **Page Frame** | Exact integer number of line intervals (`60 / 64 / 72` intervals = `61 / 65 / 73` lines); head = cap line (`frame.top`), foot = descender line (`frame.bottom`) |
| **Spacing & Grouping** | Closed 7-step scale (`s0`..`s5`) in multiples of `u`; gap owned by the boundary; collapse by `max`; heading `before / after` ink ratio `>= 1.5` (`>= 2.0` on H1/H2) |
| **Elasticity** | Between blocks only (`Gap.stretch` / `Gap.shrink`); inter-line glue is rigid (except opt-in Tier-4 leading flex `<= ±1 %`) |
| **Depth & Decoration** | 1px/hairline rules, west accent bars, and heading underlines are part of the owning atom's ink box (`height`/`depth`), never floating into gaps |
| **Numeric Precision** | Integer milli-points (`1 mpt = 0.001 pt`) + largest-remainder distribution; `q(4)` only at DisplayList emission |

### 4.2 Design-Guardrails Audit of Current Engine (`measured value vs threshold`)

Evaluated in `design-guardrails` §12 priority order (**BLOCKER > HIGH > MEDIUM**):

| Severity | Surface / Location | Measured Value vs Threshold | Prescribed Fix (Owner Milestone) |
| --- | --- | --- | --- |
| **BLOCKER** | **WCAG 2.1 AA Text Contrast** (`geometry-compiler.js:4257, 4277`, `toc-module.js:58`, `definitions.js`) | Image captions, fallback placeholders, and TOC running headers use `rulegray` (`#9CA3AF` in `base`, `#94A3B8` in `bauhaus`) as text fill: **`2.54:1` (`base`) and `2.56:1` (`bauhaus`) on `#FFFFFF`** (`2.43:1` and `2.45:1` on surface) vs **threshold `>= 4.5:1`** (WCAG AA normal text). All other text tokens pass (`textmain`: `17.72–17.85:1`, `textmuted`: `7.03–7.73:1`, `textgray`: `4.55–5.26:1`). | Rebind caption, placeholder, and TOC running-header text to semantic `textmuted` (`>= 7.03:1`) or `textgray` (`>= 4.55:1`). Reserve `rulegray` strictly for non-text hairline rules and dot leaders (**M1 / VG-17**). |
| **BLOCKER** | **Token Contract & Zero Literals** (`geometry-compiler.js`, `toc-module.js`, `math-module.js`, `blaster.js`, `definitions.js`) | **41 `tmpl.id` branches across 37 lines** (`31` in `geometry-compiler.js`, `7` in `toc-module.js`, `1` in `definitions.js`, `1` in `math-module.js`, `1` in `blaster.js`) + **2 dead float-equality checks** (`tmpl.lineStretch === 1.2` at `definitions.js:402` and `geometry-compiler.js:4119`) + magic padding literals (`+10`, `+14`, `8`, `6`) vs **threshold `0` `tmpl.id` branches and `0` layout literals in compiler passes**. | Move all template-specific typography, spacing, padding, rule weights, and font family aliases into `TEMPLATES[id].vertical` and `TEMPLATES[id].tokens` (**M1 / VG-17**). |
| **HIGH** | **Heading Proximity Law** (`definitions.js` `headingDecorators`, `geometry-compiler.js:1414-1428`) | Ink-to-ink `before / after` ratio on non-underlined headings is **`0.86` to `1.11`** (`base` H2–H4: `0.99 / 0.92 / 1.03`; `bauhaus` H1–H4: `1.00 / 0.97 / 1.00 / 1.11`; `compact` H1–H4: `1.10 / 0.96 / 0.86 / 0.98`) because `extraH: 4..10 pt` adds dead air below headings vs **threshold `>= 1.5`** (`design-guardrails` §5 / LaTeX `1.5–2.2`). | Eliminate `extraH` as spacing; include underline/bar in atom `height/depth` and set heading after-gap to rigid `bond = s1` (`0.18u`), raising `before / after` ratios to **`1.94–4.17`** (**M2 / VG-10**). |
| **HIGH** | **Boxed-Element Outside Grouping** (`geometry-compiler.js:1124, 1463, 1664, 4132-4188`) | `blockquote`, `code`, and `math` draw their container border to `item.height`, leaving **`0 pt` outside gap below the box** (`outside / inside = 0.0` below) vs **threshold `outside >= 1.0x–2.0x inside pad`**. | Separate inner box padding (`pad.quote`, `pad.code`, `pad.math`) from outer `Gap` tokens (`s2` before/after `quote`/`code`, `s3` before/after `math`) (**M2 / VG-7**). |
| **HIGH** | **Single Vertical Base Pitch** (`geometry-compiler.js:154-161, 1044`) | **36 to 46 distinct baseline-to-baseline steps** per document (`baselineSnapViolations = 170/174` in `verify-suite.js`) because lists, math, and headings introduce competing pitches vs **threshold `1` running pitch `u` (`0` off-pitch running lines)**. | Place all running text (paragraphs, lists at all depths, blockquotes, code) on snapped pitch `u` (**M2 / VG-8**). |
| **MEDIUM** | **Dense Table Legibility Floor** (`geometry-compiler.js:1203-1211`) | `bauhaus_minimalist` tables with `>= 6` columns use `bodyFontSize = 5.4 pt` (`headerFontSize = 5.8 pt`), and `base`/`bauhaus` use `5.8 pt` vs **recommended print legibility floor `>= 6.0 pt`**. | Declare `table.minFontSize` token (`5.8 pt` default for Phase A parity, `6.0 pt` opt-in floor in Phase B retune; see `ADR-0801`). |

---

## 5. Normative model

### 5.1 Units and numeric model

- All layout arithmetic MUST use **integer milli-points** (`1 mpt = 0.001 pt`, `toMpt(pt) = Math.round(pt * 1000)`). Conversion back to floating-point points happens once, at DisplayList construction, through `q(mpt / 1000, 4)`.
- Distributing an integer deficit `D` (in `mpt`) across `k` gaps with weights `w_1, ..., w_k` MUST use **largest-remainder (Hamilton) apportionment** so the integer offsets `d_i` satisfy $\sum_{i=1}^k d_i = D$ **exactly** (zero residual `mpt`). Ties in fractional remainders break deterministically toward earlier gap index `i`.
- No layout code may dispatch on floating-point equality (`===`). Token lookup is by symbolic key (`s0`..`s5`, template key), never by float value (`F-8`).
- The compiler remains 100% pure and deterministic: same input, `seed`, and `timestamp` ⇒ byte-identical DisplayList.

### 5.2 Page frame and grid (Verified with Real TrueType Metrics)

Page chrome positions are unchanged (`topM`, `bottomM`, `headheight`, `headsep`, `footskip`). Using the exact TrueType `OS/2` and `hhea` metrics extracted from `assets/fonts/*.ttf` and registered in `src/v2/fonts/metrics.js`:

- **`Arimo-Regular.ttf` / `Arimo-Bold.ttf`** (`base`, `bauhaus`): `unitsPerEm = 2048`, `ascender = 1854` (`0.905273 em`), `descender = -434` (`-0.211914 em`), `capHeight = 1409` (`0.687988 em`), `xHeight = 1082` (`0.528320 em`), `lineGap = 67` (`0.032715 em`).
- **`Inter-Regular.ttf` / `Inter-Bold.ttf`** (`bauhaus_minimalist`): `unitsPerEm = 2048`, `ascender = 1984` (`0.968750 em`), `descender = -494` (`-0.241211 em`), `capHeight = 1490` (`0.727539 em`), `xHeight = 1118` (`0.545898 em`), `lineGap = 0`.

Define in integer `mpt`:

```text
frame.top     = toMpt(topM + headheight + headsep)            // today's contentTopY
frame.bottom  = toMpt(pageH − bottomM − footskip)             // today's contentBottomY
H             = frame.bottom − frame.top

topskip       = round(bodySizeMpt · capHeight / unitsPerEm)   // ink-head: cap line touches frame.top
footDepth     = round(bodySizeMpt · |descender| / unitsPerEm) // ink-foot: descender line touches frame.bottom
span          = H − topskip − footDepth                       // distance firstBaseline → lastBaseline
u0            = toMpt(bodySize · fontRatio + paraGapPt)       // design pitch (rhythmForTemplate)
intervals     = round(span / u0)
u             = round(span / intervals)                       // snapped pitch in mpt
linesPerCol   = intervals + 1
frameRemainder= span − intervals · u                          // absorbed into last interval or bottom inset (|frameRemainder| <= intervals/2 mpt <= 36 mpt = 0.036 pt)
```

**Exact Frame Snap Table (from real `assets/fonts/*.ttf` metrics):**

| Template (`font`, `bodySize`) | `frame.top` → `frame.bottom` (`H` pt) | `topskip` (pt / `mpt`) | `footDepth` (pt / `mpt`) | `span` (pt / `mpt`) | `u0` (pt / `mpt`) | `span / u0` | `intervals` (`lines`) | Snapped `u` (pt / `mpt`) | `Δ` vs `u0` |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| **`base`** (`Arimo`, `9.5 pt`) | `45.43` → `801.04` (`755.610`) | `6.536` (`6536`) | `2.013` (`2013`) | `747.061` (`747061`) | `12.4241` (`12424`) | `60.130` | **60** (**61** lines) | **`12.4510 pt`** (`12451 mpt`) | **`+0.22 %`** |
| **`bauhaus`** (`Arimo`, `9.0 pt`) | `41.18` → `805.80` (`764.620`) | `6.192` (`6192`) | `1.907` (`1907`) | `756.521` (`756521`) | `11.8491` (`11849`) | `63.846` | **64** (**65** lines) | **`11.8206 pt`** (`11821 mpt`) | **`−0.24 %`** |
| **`bauhaus_minimalist`** (`Inter`, `8.0 pt`) | `34.84` → `813.05` (`778.210`) | `5.820` (`5820`) | `1.930` (`1930`) | `770.460` (`770460`) | `10.6797` (`10680`) | `72.143` | **72** (**73** lines) | **`10.7008 pt`** (`10701 mpt`) | **`+0.20 %`** |

**Remainder policy (`ADR-0807`, default `'leading'`):**
- Because `|u / u0 − 1| <= 0.24 %` across all three templates (well inside the `1 %` threshold), all three templates use `'leading'` snap. Margins (`frame.top`, `frame.bottom`) stay **100% identical to v2**, while a full column of plain text (61, 65, or 73 lines) lands its first cap-top on `frame.top` and its last descender-bottom on `frame.bottom` with **zero glue stretch** (`F-3` eliminated at the root).
- If a future custom template exceeds `|u / u0 − 1| > 1 %`, fallback `'margin'` keeps `u = u0`, `intervals = floor(span / u0)`, and adds the remainder (`< u0`) to the bottom inset.

**One pitch rule (`ADR-0805`).** All running text in a column — paragraphs, list items at every nesting level, blockquotes, and code blocks — sits on pitch `u`. A list item's *glyph size* (`listBodySize`: `9.2 / 9.0 / 8.5 / 8.0 pt` in `base`, `8.5 pt` in `bauhaus`, `8.0 pt` in `bauhaus_minimalist`) stays unchanged so horizontal wrapping (`wrapRunsToLines`) is preserved; its *line pitch* becomes `u` (`F-4` eliminated). Headings, tables, figures, and display math boxes are *non-grid atoms*: they are measured in their own ink units and separated from running text by explicit `Gap` tokens.

**Interline glue** between consecutive lines of the same text atom (or between a line-split fragment's lines) is **rigid**: baseline-to-baseline step is `u` (`stretch = 0, shrink = 0`).

### 5.3 Atoms

The galley is an alternating sequence `Atom, Gap, Atom, Gap, …`. Before solving breaks, splittable atoms (`paragraph`, `listItem`, `quote`, `code`, `table`, and `math` when `split_equations: true`) are expanded into line/row sub-atoms joined by rigid internal glue and the penalties of §5.5.

```ts
interface Atom {
  id: string;
  kind: AtomKind;             // closed enum below
  height: number;             // mpt above firstBaseline (or box top if non-text)
  depth: number;              // mpt below lastBaseline (or box bottom if non-text)
  internalSpan: number;       // mpt from firstBaseline to lastBaseline ((n - 1) * u for n-line text; 0 for 1-line/box)
  totalInkH: number;          // height + internalSpan + depth (in mpt)
  splittable: 'none' | 'lines' | 'rows';
  keepWithNext: boolean; keepTogether: boolean;
  headAnchor: 'cap' | 'boxEdge';
  footAnchor: 'descender' | 'boxEdge';
  span: 'column' | 'page' | 'rotated';
  meta?: object;              // heading level/slug, table colWidths, list marker/geo, etc.
}
```

`AtomKind` (closed 12-member set): `'paragraph' | 'heading' | 'listItem' | 'quote' | 'code' | 'note' | 'rule' | 'table' | 'figure' | 'caption' | 'math' | 'masthead'`.

**Strict Atom Invariants:**
1. **Self-contained ink box:** An atom's `height + internalSpan + depth` MUST bound 100% of what it paints:
   - For a `paragraph` or `listItem` of $n$ lines on pitch $u$: `height = topskip` (`capHeight * bodySize`), `internalSpan = (n - 1) \cdot u`, `depth = footDepth` (`|descender| * bodySize`). Total ink height is $(n - 1)u + topskip + footDepth$.
   - Note on `n` lines of plain text filling a column: `n = intervals + 1 => totalInkH = intervals * u + topskip + footDepth = span + topskip + footDepth = H` **exactly**!
   - For a `heading` of $n$ lines with font size $fs$ and line pitch `u_h = toMpt(fs * fontRatio + 0.8)`: `height = round(fsMpt · capHeight / unitsPerEm)` (which also bounds vertical bars/pills since `barTop = capTop`), `internalSpan = (n - 1) \cdot u_h`, and `depth`:
     - For `style === 'underline'` (`base` H1): `depth = round(fsMpt · |descender| / unitsPerEm) + underlineOffsetMpt + underlineW / 2` (`underlineOffset = 3.5 pt` below baseline).
     - For all other heading styles (`vertical_bar`, `vertical_pill`, `plain`, `small_caps`, `middle_dot`): `depth = round(fsMpt · |descender| / unitsPerEm)`. The dead `extraH` (`4–10 pt`) is **removed** from atom height (`F-13`).
   - For boxed atoms (`quote`, `code`, `note`, `math`): `headAnchor = 'boxEdge'`, `footAnchor = 'boxEdge'`, `height = padTop + textTopskip + (n - 1)·u_atom + textFootDepth + padBottom`, `internalSpan = 0`, `depth = 0`. The container `rect` is drawn from `yTop` to `yTop + height`.
   - For `table`: `headAnchor = 'boxEdge'`, `footAnchor = 'boxEdge'`, `height = heavyRule/2 + headerH + sum(rowH) + bottomRule/2`, with zero `topGap`/`bottomGap` inside the atom (`F-1`, `F-2`).
2. **Zero external spacing inside atoms:** An atom MUST NOT include `parskip`, `topMargin`, `spaceBefore`, `extraH`-as-spacing, `topGap`, `bottomGap`, `listTopSep`, or `listBottomSep`. All inter-atom spacing lives in `Gap` tokens (§5.4).
3. **Pure data in DisplayList:** `Atom` objects and layout closures exist only inside the compiler pipeline; emitted DisplayList elements remain plain frozen JSON records passing `assertDriverPurity` (§5.11).

### 5.4 Spacing system

#### 5.4.1 Three-Layer Token Hierarchy (`design-guardrails` §2)

```text
Layer 1 — Primitive : u (snapped mpt), capHeight, descender, ascender, unitsPerEm
Layer 2 — Semantic  : scale { s0, sH, s1, s2, s3, s4, s5 } (in multiples of u);
                      stretchClass { rigid, tight, normal, loose };
                      text/surface/rule semantic color roles (textmain, textmuted, textgray, rulegray, ...)
Layer 3 — Component : gaps.before[kind], gaps.after[kind], gaps.bond[kind],
                      pad (quote, code, note, math, tableCell),
                      list (indentStep, markerW, labelSep, itemAfter[depth]),
                      chrome (fontSize, isBold, headerRuleClearance, footerRuleGap)
```

Compiler passes MUST consume only Layer 2 and Layer 3 tokens from `tmpl.vertical` and `tmpl.tokens`. All 41 `tmpl.id` checks and both `tmpl.lineStretch === 1.2` float-equality checks are eliminated (`VG-17`).

#### 5.4.2 Closed Spacing Scale and Gap Mechanics

In a baseline-based model where consecutive text lines of one paragraph are separated by baseline step $u$, the ink-to-ink distance between two lines of the same paragraph is:
`lineInkGap = u - (topskip + footDepth)`
(`3.902 pt` in `base`, `3.722 pt` in `bauhaus`, `2.951 pt` in `bauhaus_minimalist`).
When two text atoms $A$ and $B$ are separated by a gap of extra baseline space $g$ (`Gap.natural`), the baseline-to-baseline distance from $A$'s last line to $B$'s first line is $u + g$, and the ink-to-ink distance from $A$'s descender line to $B$'s cap line is `lineInkGap + g`. For boxed/ruled atoms (`headAnchor: 'boxEdge'` or `footAnchor: 'boxEdge'`), the gap between $A$'s bottom ink and $B$'s top ink is `lineInkGap_adj + g`, so baseline rhythm and visual whitespace stay unified.

**Closed Spacing Scale (calibrated to `u` per template for Phase A natural-gap parity `VG-7`):**

| Token | Role | `base` (`u = 12.451 pt`) | `bauhaus` (`u = 11.821 pt`) | `bauhaus_minimalist` (`u = 10.701 pt`) |
| --- | --- | --- | --- | --- |
| **`s0`** | Zero extra gap (nested list depth ≥ 3) | `0.032 u` (`0.40 pt` / `400 mpt`) | `0.068 u` (`0.80 pt` / `800 mpt`) | `0.037 u` (`0.40 pt` / `400 mpt`) |
| **`sH`** | Tight list item gap (depth 1 / depth 2) | `0.112 u` / `0.064 u` (`1.40 / 0.80 pt`) | `0.169 u` / `0.118 u` (`2.00 / 1.40 pt`) | `0.093 u` / `0.065 u` (`1.00 / 0.70 pt`) |
| **`s1`** | Standard paragraph skip (`parskip`) & heading/caption bond | `0.177 u` (`2.20 pt` / `2200 mpt`) | `0.237 u` (`2.80 pt` / `2800 mpt`) | `0.112 u` (`1.20 pt` / `1200 mpt`) |
| **`s2`** | Minor section / H3–H4 before / quote, code, rule outside gap | `0.350 u` (`4.36 pt` / `4358 mpt`) | `0.380 u` (`4.49 pt` / `4492 mpt`) | `0.346 u` (`3.70 pt` / `3700 mpt`) |
| **`s3`** | Sub-section H2 before / table, figure, math outside gap | `0.498 u` (`6.20 pt` / `6200 mpt`) | `0.508 u` (`6.00 pt` / `6000 mpt`) | `0.486 u` (`5.20 pt` / `5200 mpt`) |
| **`s4`** | Major section H1 before | `0.659 u` (`8.20 pt` / `8200 mpt`) | `0.744 u` (`8.80 pt` / `8800 mpt`) | `0.673 u` (`7.20 pt` / `7200 mpt`) |
| **`s5`** | Masthead-to-body & major banner separation | `0.643 u` (`8.00 pt` / `8000 mpt`) | `0.677 u` (`8.00 pt` / `8000 mpt`) | `0.748 u` (`8.00 pt` / `8000 mpt`) |

**Gap structure & collapse rules:**
```ts
interface Gap {
  natural: number;      // mpt
  stretch: number;      // mpt
  shrink: number;       // mpt
  class: 'rigid' | 'tight' | 'normal' | 'loose';
  penalty: number;      // -10000..10000 (10000 = forbidden break)
  discardable: true;
}
```
- **Stretch/shrink capacities by class (`ADR-0801`):**
  - `rigid`: `stretch = 0`, `shrink = 0` (used for interline glue, heading bonds, figure-caption bonds, masthead after-gap).
  - `tight`: `stretch = round(0.20 · u)`, `shrink = min(round(0.25 · natural), round(0.05 · u))` (list item boundaries).
  - `normal`: `stretch = round(0.35 · u)`, `shrink = min(round(0.25 · natural), round(0.08 · u))` (paragraph, quote, code, rule, table, figure, math boundaries — preserving v2's proven `0.35u` invisibility budget so pages with fewer gaps do not regress on `gap-distribution`).
  - `loose`: `stretch = round(0.50 · u)`, `shrink = min(round(0.25 · natural), round(0.10 · u))` (before H1–H4 headings and at span edges).
- **Collapse by max (`\addvspace`):** The gap between atoms $A$ and $B$ has `natural = max(after[A], before[B])`, `class = maxClass(classAfter[A], classBefore[B])`, and `penalty = minPenalty(penAfter[A], penBefore[B])`, **except** when $A$ emits a **bond** (`heading`, `figure` with caption, `captionPromo` before span), in which case the bond (`natural = s1, class = 'rigid', penalty = 10000`) overrides the max.
- **Discard at breaks:** Any gap selected as a column or page break is **discarded** (`0 mpt` charged to the closing column, `0 mpt` carried to the next column top). The opening atom of the next column positions its `headAnchor` directly on `frame.top` (§5.8).

#### 5.4.3 Measured M0 Natural-Gap Matrix & Resolution of `VG-7` vs `VG-10`

Today in v2, because gaps Sum (`after[A] + before[B]`), a paragraph (`parskip = 2.2 / 2.8 / 1.2 pt`) followed by a heading (`spaceBefore = 6 / 4 / 2.5 / 2.5 pt`) produces an effective `before` gap of `parskip + spaceBefore`, while the heading's `extraH` (`8 / 7 / 6 / 5 pt` in `base`, `10 / 8 / 6 / 5 pt` in `bauhaus`, `7 / 6 / 5 / 4 pt` in `compact`) acts as the `after` gap. Setting v3's `before[heading]` to `s4 / s3 / s2 / s2` reproduces `parskip + spaceBefore` under max-collapse within `<= 0.8 pt` (`VG-7`), while replacing `extraH` with `bond = s1` fixes the `F-13` proximity inversion (`VG-10`):

| Boundary (`A → B`) | v2 Effective Extra Step (`base` / `bauhaus` / `compact` pt) | v3 Collapsed Token (`base` / `bauhaus` / `compact` pt) | Ink-to-Ink Ratio (`before / after`) v2 → **v3** | Parity / Rule |
| --- | --- | --- | --- | --- |
| `paragraph → paragraph` | `2.20 / 2.80 / 1.20` | **`s1`**: `2.20 / 2.80 / 1.20` | `1.00` → **`1.00`** | **Exact (`0.00 pt` Δ, VG-7)** |
| `listItem(L1) → listItem(L1)` | `1.40 / 2.00 / 1.00` | **`sH[1]`**: `1.40 / 2.00 / 1.00` | `1.00` → **`1.00`** | **Exact (`0.00 pt` Δ, VG-7)** |
| `listItem(L2) → listItem(L2)` | `0.80 / 1.40 / 0.70` | **`sH[2]`**: `0.80 / 1.40 / 0.70` | `1.00` → **`1.00`** | **Exact (`0.00 pt` Δ, VG-7)** |
| `listItem(L≥3) → listItem(L≥3)` | `0.40 / 0.80 / 0.40` | **`s0`**: `0.40 / 0.80 / 0.40` | `1.00` → **`1.00`** | **Exact (`0.00 pt` Δ, VG-7)** |
| `paragraph ↔ list block` | `3.40 / 5.30 / 2.40` (top) · `3.70 / 5.30 / 2.70` (bot) | **`s2`**: `4.36 / 4.49 / 3.70` |Symmetric list boundary | **Within `<= 1.0 pt` (VG-7)** |
| `any → heading H1` | `8.20 / 8.80 / 7.20` (`parskip + 6`) | **`s4`**: `8.20 / 8.80 / 7.20` | `3.21 / 1.00 / 1.10` → **`2.02 / 1.93 / 2.45`** | **Exact before (`0.00 pt` Δ); `VG-10` (`>= 1.5`) PASS** |
| `any → heading H2` | `6.20 / 6.80 / 5.20` (`parskip + 4`) | **`s3`**: `6.20 / 6.00 / 5.20` | `0.99 / 0.97 / 0.96` → **`1.66 / 1.50 / 1.97`** | **`<= 0.80 pt` Δ before; `VG-10` (`>= 1.5`) PASS** |
| `any → heading H3` | `4.70 / 5.30 / 3.70` (`parskip + 2.5`) | **`s2`**: `4.36 / 4.49 / 3.70` | `0.92 / 1.00 / 0.86` → **`1.50 / 1.50 / 1.61`** | **`<= 0.81 pt` Δ before; `VG-10` (`>= 1.5`) PASS** |
| `any → heading H4` | `4.70 / 5.30 / 3.70` (`parskip + 2.5`) | **`s2`**: `4.36 / 4.49 / 3.70` | `1.03 / 1.11 / 0.98` → **`1.50 / 1.50 / 1.61`** | **`<= 0.81 pt` Δ before; `VG-10` (`>= 1.5`) PASS** |
| `heading H1..H4 → follower` | `8..5 / 10..5 / 7..4` (buggy `extraH`, `F-13`) | **`bond` (`s1` rigid)**: `2.20 / 2.80 / 1.20` | Fixes `0.86–1.11` inversion | **Carved out of VG-7 by VG-10 (`ADR-0801`)** |
| `any ↔ table / figure / math` | `6.00..8.80` before · `6.00` (`table`) / `0.00` (`math`) after | **`s3`**: `6.20 / 6.00 / 5.20` | Symmetric before & after | **`<= 0.80 pt` Δ vs `6 pt` table gap; fixes `math` `0 pt` after-gap** |
| `any ↔ quote / code / note / rule` | `2.20..2.80` before · `0.00` after (`F-13`) | **`s2`**: `4.36 / 4.49 / 3.70` | Symmetric before & after (`outside >= padV`) | **Carved out of VG-7 to fix `0 pt` bottom collision (`F-13`)** |

### 5.5 Break model

**Legal break points** exist at: every non-bond `Gap`; between lines of a `paragraph`, `listItem`, `quote`, or `code` atom; between lines of a `math` atom when `split_equations: true`; and between body rows of a `table` atom.
**Forbidden breaks (`penalty = 10000`):** at any `bond` gap (after a heading, between consecutive headings in a heading run, between a heading and an atomic table/figure/math follower, between a promoted caption and its span, between a figure and its caption, and between a table header and its first two body rows).

**Closed Penalty Table (TeX-scaled, $\infty = 10000$; tuned at M3 against `VG-9`):**

| Penalty Token | Value | Where Applied | Replaces in v2 |
| --- | --- | --- | --- |
| `interline` | `0` | Between intermediate lines of a paragraph (`index >= 2` and `index <= size - 2`) | `_splitParagraph` ad-hoc slicing |
| `club` | `150` (`10000` when `loose_line_guard: true` and `size >= 4`) | After the 1st line of a paragraph, list item, or blockquote | `checkOrphan` (`atom.js:187`) |
| `widow` | `150` (`10000` when `loose_line_guard: true` and `size >= 4`) | Before the last line of a paragraph, list item, or blockquote | `checkWidow` (`atom.js:204`), `_splitParagraph` line 3949 |
| `afterHeadingClub` | **`10000`** | After the 1st line of the paragraph/list following a heading (LaTeX `\@afterheading`): a heading always carries $\ge 2$ lines (or the entire follower if 1 line / atomic) | All 5 keep-with-next mechanisms (`F-9`) |
| `parentListKeep` | **`10000`** (relaxed at a region tail when `split_list_items: false`) | Between a list item at depth $d$ and its first child list item at depth $d' > d$ | `tailIsParentList` (`geometry-compiler.js`) and `stacked-sliver-order` guard |
| `tableRowMinTop` / `MinBottom` | **`10000`** for $< 2$ body rows | After row 1 of a table (`table.rows.length >= 3`) and before the last row (`table.rows.length >= 3`) | `_splitTable` widow-leader and orphan-tail guards (`geometry-compiler.js:3886-3897`) |
| `codeClub` / `codeWidow` | `150` | After 1st line / before last line of a `code` block | Unsplit code overflow |
| `broken` | `100` | After a hyphenated line (active when Knuth–Plass is wired at M6) | N/A |
| `preferBreakBeforeHeading` | `{ 1: -50, 2: -25, 3: 0, 4: 0 }` | At `loose` gaps immediately before H1/H2 (mild preference when badness is tied) | N/A |
| `forcedBreak` | **`-10000`** | Block boundary, rotated table page boundary | Block loop |

Because `parentListKeep = 10000` and `afterHeadingClub = 10000` forbid splitting a parent heading or parent list item from its immediate child across a column/band boundary unless the child is already in the same column, **both `G19c` (`heading-run-order`) and `stacked-sliver-order` are satisfied by construction** without replan loops. The sole exception is the `split_list_items: false` atomic-list policy below: a whole parent may end a balanced region and its child may open the next column, preserving document order without cutting either item.

### 5.6 Fit and stretch ladder

For a candidate break $k$ closing a column of target frame height $H$ (in `mpt`), let $t_k$ be the natural height of all atoms and non-discarded internal gaps in the column (with the gap at break $k$ discarded, and top/bottom anchors placed per §5.8), `S_+ = sum(stretch)`, and `S_- = sum(shrink)`:

```text
if t_k == H:
  r = 0;  b = 0
else if t_k < H:                                           // underfull side
  if S_+ <= 0: r = Infinity; b = 10000
  else:        r = (H − t_k) / S_+;  b = min(10000, round(100 · r^3))
else:                                                      // overfull side (t_k > H)
  if S_- <= 0 or (t_k − H) > S_-: r = -Infinity; b = 10001 // strictly infeasible (never overflow frame.bottom)
  else:        r = −(t_k − H) / S_-; b = min(10000, round(100 · |r|^3))

cost(k) = b + penalty(k)
```

- **Strict no-overflow rule (`VG-11`):** Any candidate with $t_k - H > S_-$ has $b = \infty$ and MUST NOT be chosen if any feasible break ($t_k - H \le S_-$) exists; if a single unbreakable atom exceeds $H$ at the top of an empty column, it is placed once (progress guarantee) and flagged in `overfullColumns`.
- **`flush_columns` pagination parity (`column-flow.lean.js:176` invariant):**
  To guarantee that toggling `flush_columns` ("Encaixar pé da página") **never changes pagination (`on.totalPages === off.totalPages`)**, break selection ALWAYS evaluates candidates with $S_- = 0$ (no overfull shrink during break selection; only $t_k \le H$ candidates are feasible) and the same badness/penalty cost function `cost(k)`.
  - When `flush_columns: true`: if the winning break has $0 \le H - t_k$ and $r \le 1.0$, the deficit $D = H - t_k$ is distributed across the column's gaps proportionally to `stretch` via largest-remainder rounding (`verdict: 'applied'`, foot lands on `frame.bottom` within `0 pt`). If $r > 1.0$ (insufficient stretch capacity), the column either uses Tier 4 (if opted in) or applies a bounded proportional lift up to $r = 1.0$ (`stretch` ceiling) and records the residual void with typed reason `'underfull-glue'`.
  - When `flush_columns: false`: the exact same break $k$ is taken, $D$ is not distributed ($r = 0$), and the natural residual $H - t_k$ is recorded with typed reason `'flush-off'`.

**The 6-Tier Fit Ladder:**

| Tier | Mechanism | Ceiling / Bound |
| --- | --- | --- |
| **0** | **Frame snap** (§5.2): plain text of `N = intervals + 1` lines fits $H$ with zero deficit | Exact (`0 mpt`) |
| **1** | **Cost-optimal break choice**: pick legal break $k$ minimizing $b + p(k)$ | $r \le 1.0$ preferred |
| **2** | **Gap stretch** (`flush_columns: true`): distribute $D = H - t_k$ across gaps with largest-remainder rounding | $r \le 1.0$ (`\le 0.35u` normal, `\le 0.50u` loose) |
| **3** | **Line & row splitting**: paragraphs, list items, blockquotes, code, and table body rows split at legal line/row boundaries honoring §5.5 penalties | Penalty table (§5.5) |
| **4** | *Opt-in* **uniform leading flex** (`maxLeadingFlex`, default `0`, `ADR-0803`): flex `u` uniformly across both columns of a page by up to $\pm 1\%$ when $r > 1.0$ and residual $\le 0.5u$ | $\le \pm 1\%$ of $u$ |
| **5** | **Honest ragged with per-column typed reason**: leave residual void and record reason in `page.columns[c]` and `diagnostics.geometry.voids[]` | `0` unreasoned voids (`VG-2`) |

**Closed Per-Column Void Reason Enum (`VoidReason`):**
Every column with `voidPt > 0.25 pt` MUST carry exactly one reason from:
`'terminal'` · `'block-end'` · `'flush-off'` · `'atomic-unfit'` · `'underfull-glue'` · `'band-parity'` · `'forced-break'` · `'widow-accepted'` · `'toc'` · `'rotated'`

### 5.7 Solver

**Single galley, equal-height columns.** Each block's content between full-width spans is one vertical galley of `Atom` and `Gap` nodes. For 2-column bands, the solver slices the galley into `col:0` then `col:1` in column-major reading order. For 1-column blocks (`blockCols === 1`), the exact same solver runs with 1 column per band.

**Tier 1 — Windowed Cost Solver (v3.0 default, ships at M3):**
For each column of target height $H_c$:
1. Advance from `cursor`, accumulating natural height $t_k$ and stretch capacity $S_+$ (excluding the trailing gap at $k$).
2. Evaluate all legal break candidates $k$ where $t_k \le H_c$ and $p(k) < 10000$.
3. Select $k^*$ minimizing `cost(k) = b(k) + p(k)` (ties broken toward larger $k$, packing more content).
4. **Fallback when every candidate in the window has $p(k) = 10000$ or $b(k) = 10000$:**
   - If the column is non-empty and a candidate with $p(k) < 10000$ exists (even with $r > 1.0$), pick the largest such $k$ (leaving an honest `'underfull-glue'` or `'atomic-unfit'` void rather than breaking a `10000` keep bond).
   - If no candidate with $p(k) < 10000$ fits in the entire column (e.g. a 60-line paragraph with `club`/`widow` or a tall atomic item at column top), relax `widow`/`club` first (recording `'widow-accepted'`), and if the first atom at `cursor` alone exceeds $H_c$ at page top, place that single atom to guarantee strict forward progress (`k* = cursor + 1`).
5. **Termination by construction (`VG-16`):** Every non-empty band consumes $\ge 1$ line/atom, or (if a mid-page band has $H_c$ too small for the first atom+bond) closes the page and starts at `frame.top` on the next page where $\ge 1$ atom is guaranteed to be consumed. Total solver steps are bounded by `O(atoms + pages)`.

**Tier 2 — Total-Fit Dynamic Program (v3.1 opt-in at M6, Plass 1981):**
Minimizes `sum_cols (1 + cost(c))^2` across all columns of a band/block using dynamic programming over legal breakpoints in a sliding window $W \le 12$. Shipped behind `solverTier: 2`.

**Spans and Bands (Eliminating the F-6 Empty-Column Bug):**
A full-width atom (`span: 'page'`: panoramic table, full-width figure, full-width rule adjacent to a span, or promoted caption run before a span) closes the current 2-column band:
1. **Pre-span band balancing:** If there are items before the span on the current page, they form a **band-balanced** 2-column region above the span. The solver partitions the pre-span items into `col:0` and `col:1` to minimize $|h_1 - h_2|$ subject to `h_1, h_2 <= H_rem` and no $p = 10000$ break at the `col:0` foot or `col:1` foot.
   - **Single-line / lone-item pre-span guard:** If the pre-span items consist of a single splittable paragraph/list item of $\ge 2$ lines, it splits across `col:0` and `col:1` so both columns are populated above the span. If only 1 unsplittable line exists, its 1-line disparity in `col:1` is typed `'band-parity'` ($\le 1u$).
2. **Span fit or split:**
   - If the span (plus its promoted caption bond, if any) fits below the pre-span band (`spanH <= H_rem - max(h_1, h_2)`), it is placed at `leftM` across `printableW`, and a new 2-column band opens below it at `resumeTop` with **both columns starting at the exact same `resumeTop`**.
   - If the span does **not** fit below the pre-span band:
     - If the span is a **splittable table** and `H_rem - max(h_1, h_2)` can hold the table header + $\ge 2$ body rows (plus any promoted caption), the table splits by rows (`_splitTable`), placing the first slice on the current page and carrying the continuation (with repeated header + `(continuação)`) to the top of the next page.
     - Otherwise, the span is **deferred to the top of the next page**, AND **the pre-span band is immediately re-solved as a full-page band filling BOTH `col:0` and `col:1` down to `frame.bottom` using the items that precede the span** (or, if no further items precede the span, balanced evenly across `col:0` and `col:1` as a `'forced-break'` band, **never** leaving all items in `col:0` with `col:1` empty!).
   - This rule makes the F-6 defect (`col:0` full, `col:1` empty on `sample2.md × bauhaus_minimalist` p.1 and `sample1.md × bauhaus_minimalist` p.4) **structurally impossible**.

**Terminal Band Balancing (`ADR-0802`, retained from v2):**
- On the **final band of every block** (when the block's item stream is exhausted), both columns are **balanced by default** (even when `balance_columns` is `false`/`null`, matching `geometry-compiler.js:2247-2985` and `tests/lean/terminal-balance.lean.js`): the solver chooses the split minimizing $|h_1 - h_2|$ (splitting the boundary paragraph/list item by lines when needed), applies **zero stretch beyond natural** (`r = 0`), and tags the space below both columns as `'terminal'` (or `'block-end'` at page level).
- When `balance_columns: true` ("Quebrar colunas para acomodar"), mid-block bands also use balanced partitioning and stamp the continuation cues (§5.10).

### 5.8 Ink alignment (Head and Foot Exactness)

Define two horizontal ink reference lines for every band starting at `bandTop` (`frame.top` for the first band on a page) and ending at `bandBottom` (`frame.bottom` for a full-page flush band):

1. **Head Ink Line (`bandTop`):**
   - If the first atom in a column has `headAnchor: 'cap'` (paragraphs, list items, plain/bar/pill/dot headings): its first baseline is placed at:
     `firstBaseline = bandTop + round(atomFontSizeMpt * capHeight / unitsPerEm)`
     so the top of its capital letters (and the top of any `vertical_bar` / `vertical_pill` decorator, since `barTop = baseline - capHeight`) touches `bandTop` **exactly** (`0.00 pt` error, `VG-4`).
   - If the first atom in a column has `headAnchor: 'boxEdge'` (`table`, `quote`, `code`, `note`, `figure`, `math`, `rule`): its top border/edge is placed at `bandTop` **exactly**.
2. **Foot Ink Line (`bandBottom`):**
   - If the last atom in a flush column has `footAnchor: 'descender'` (paragraphs, list items, non-underlined headings): its last baseline after glue resolution lands at:
     `lastBaseline = bandBottom - round(atomFontSizeMpt * |descender| / unitsPerEm)`
     so the bottom of its descender line touches `bandBottom` **exactly** (`VG-1`, `VG-5`).
   - If the last atom in a flush column has `footAnchor: 'boxEdge'` (`table`, `quote`, `code`, `note`, `figure`, `math`, `rule`, or underlined H1): its bottom border/stroke edge lands on `bandBottom` **exactly** (`VG-1`, `VG-5`).

### 5.9 Element rules

1. **Paragraph (§5.9.1):** Lines on snapped pitch `u`; `club`/`widow` per §5.5; `after: s1` (`class: 'normal'`). Loose-line guard (`wordCount < 14` or `naturalWidth < 0.85 · width` stays left-aligned when `alignment === 'justify'`) is preserved unchanged.
2. **Headings & Proximity Law (§5.9.2):**
   - Heading atom = wrapped heading lines at `decor.fontSize` on heading line pitch `u_h = fs · fontRatio + 0.8` + its decorator (`vertical_pill`, `vertical_bar`, `underline`, `middle_dot`, `small_caps`, `plain`), bounded within `height` and `depth` (§5.3).
   - Gap before heading = `s4` (H1), `s3` (H2), `s2` (H3/H4) with `class: 'loose'`.
   - Gap after heading = rigid `bond` (`natural = s1`, `stretch = 0`, `shrink = 0`, `penalty = 10000`).
   - Measured ink-to-ink ratio `(lineInkGap + before) / (lineInkGap + bond)` is **`>= 1.50` across all levels H1–H4 and all three templates** (`VG-10`; see table in §5.4.3).
   - Heading runs (e.g. `H1 → H2 → H3`) are bonded together (`penalty = 10000` at every inter-heading gap) and require the first 2 lines of the following body (`afterHeadingClub = 10000`) or the entire following atomic item (`table`/`figure`/`math`) to fit in the same column (`VG-9`).
3. **Lists (§5.9.3):** All nesting levels sit on running pitch `u` (`ADR-0805`). Glyph sizes remain `listBodySize(tmpl, level)`; horizontal indents and vector/text/ordered/task markers remain unchanged (`listGeometry`). Inter-item gaps: `sH[1]` at depth 1, `sH[2]` at depth 2, `s0` at depth $\ge 3$ (`class: 'tight'`). Start and end of a top-level list block use `s2`, collapsing by `max` with adjacent paragraphs/headings. Parent list items bond to their first deeper child (`parentListKeep = 10000`). When `split_list_items: false`, list items are atomic: `_splitParagraph` returns them whole. If continuous fill leaves a material column disparity (more than two body pitches), the region switches to the whole-item balanced partition even when `balance_columns` is false; a flush continuous page is left alone. The region-tail parent keep is skipped for that atomic split so the balanced boundary owns it. A column may still end short when the next whole item/group cannot fit; that residual is preferred to a mid-item continuation. Default (`true`) keeps the continuous line-split path.
4. **Quote, Code, Note (§5.9.4):** Boxed atoms (`headAnchor: 'boxEdge'`, `footAnchor: 'boxEdge'`) with inner vertical padding tokens (`pad.quote = { top: 4, bottom: 4 }`, `pad.code = { top: 5, bottom: 5 }`, `pad.note = { top: 4, bottom: 4 }`) and outer gaps `before: s2, after: s2` (`class: 'normal'`). Text inside sits on pitch `u`.
5. **Rule (§5.9.5):** Atom with `height = strokeWidth`, `depth = 0`, `headAnchor: 'boxEdge'`, `footAnchor: 'boxEdge'`, `before: s2, after: s2`. A `---` immediately adjacent to a panoramic table or figure becomes `span: 'page'` (full-width divider, as today).
6. **Tables (§5.9.6):**
   - Header and each body row are sub-atoms with `height` derived from their own cell line pitch (`tblHeadLineH`, `tblLineH`) and `paddingV` token (`1.8–2.8 pt` by column density), with top/bottom rules (`heavyRule` / `lightRule`) included in the first/last slice's ink box.
   - Outside gaps: `before: s3, after: s3` (`class: 'normal'`), discarded at breaks and omitted between split continuation slices.
   - Header bonds to the first 2 body rows (`tableRowMinTop = 10000`); the last 2 body rows bond together (`tableRowMinBottom = 10000`). Continuation slices repeat the header with `' (continuação)'` on cell 0 and draw `lightRule` at the bottom of non-final slices and `heavyRule` on the closing slice.
   - Proportional column width solver (`HEADER_DEMAND_WEIGHT = 1.15`, `headerFloors`, `firstColFloor`, `crowdedGuard`, `breakNbsp: true`) and layout modes (`compact`, `panoramic`, `auto`, `rotated_cw`, `rotated_ccw`) are preserved 100% intact.
7. **Figures and Captions (§5.9.7):** Figure atom (`headAnchor: 'boxEdge'`, `footAnchor: 'boxEdge'`) bonded (`s1` rigid) to its caption atom (when `image_captions_enabled !== false`). Caption text color uses semantic `textmuted` (`>= 7.03:1` contrast, fixing `F-14`). `figureFit: 'defer'` by default (`ADR-0806`), with opt-in `'scale'` allowing downscale to `>= 0.92` (`<= 8%` reduction) when an image at the bottom of a column misses fitting by `<= 8%`.
8. **Display Math (§5.9.8):** Boxed atom (`pad.math = { top: 6, bottom: 6 }`) with outside gaps `before: s3, after: s3` (`class: 'normal'`). Honors `split_equations` flag.
9. **Masthead, TOC, and Running Chrome (§5.9.9):**
   - Masthead is a `span: 'page'` atom at the start of a block (`headAnchor: 'boxEdge'`, `after: s5` rigid), suppressing the running-header date (and running-header title when `masthead.header: true`) on that page.
   - **Multi-page TOC support (resolving §10.3 Known Gap & `F-14`):** Before compiling blocks, when `chaptersToc` is enabled, the compiler computes the exact TOC entry count (`sections.length` chapter rows + `sum(min(headings_i, 4))` subheading rows) and reserves `P_toc = max(1, ceil(H_toc / H))` front pages (instead of hardcoding `getOrCreatePage(0)`). `renderChaptersTOC` in `toc-module.js` checks `doc.y + rowH > contentBottomY` and advances to the next reserved TOC page `switchToPage(tocPageIdx)` with `drawUnifiedPageHeader`, so 30-section documents never overflow Page 0.
   - Running header and footer rules/text are stamped at their existing coordinates (`topM` and `A4_HEIGHT - bottomM`), with TOC running-header text color rebound from `rulegray` to `textmuted` (`VG-17`).

### 5.10 Columns, gutters, rules, and continuation cues

- Column widths: `twoColW = (printableW − columnsep) / 2` (unchanged).
- Column separator rule (`tmpl.columnseprule`): drawn from `bandTop` to `bandFoot - halfStroke`, skipped across pure-heading bands (unchanged).
- **Continuation cues (`_stampFlowCues`, retained for `column-flow.lean.js`):** When `balance_columns: true` is active on a 2-column band where `col:0` hands content to `col:1`, the `decorate` pass stamps the `cue: 'continuation'` hairline vector marks (`cueRole: 'column-cross'` right-pointing arrow in the gutter at `col:0`'s ink foot, and `cueRole: 'region-tail'` down-chevron centered under `col:1`'s ink foot when content continues after the band), guarded by the clean-occupancy check so no mark ever overlaps content or crosses `frame.bottom`.

### 5.11 Output contract (DisplayList 2.2) & Two-Adapter Seams

Additive and 100% backward-compatible with drivers (`irVersion: '2.2.0'` when `geometry: 'v3'`, or `'2.1.0'` when `geometry: 'v2'`):

- **Page record additions:**
  - `page.frame (top, bottom, left, right, colX, colW, u, lines, topskip, footDepth)` (in points via `q(4)`).
  - `page.columns (array of per-column records: scope, x, w, headY, footY, voidPt, reason, r)`.
- **Text element additions:**
  - `el.baseline = q(baselineMpt / 1000)` (the exact glyph baseline in top-down page coordinates).
  - `el.y = q(lineTopFromBaseline(baselineMpt, el.font, el.size, tmpl.id) / 1000)` (retained for 100% PDFKit blaster compatibility).
  - `el.atom (id, kind)`.
- **Exact `lineTopFromBaseline` and `inkExtent` Formulas (Two-Adapter Seam #1):**
  Because `PDFKitVectorBlaster` draws text via `doc.text(seg.text, x, el.y)` and PDFKit offsets the glyph baseline downward from `el.y` by `(ascender / unitsPerEm) * size`, the compiler and driver share one pure function in `src/v2/fonts/metrics.js`:
  ```js
  export function lineTopFromBaselineMpt(baselineMpt, fontKey, fontSizePt) {
    const m = getFontMetrics(fontKey, fontSizePt); // arimo for base/bauhaus, inter for bauhaus_minimalist
    const ascMpt = Math.round((m.ascender / m.unitsPerEm) * fontSizePt * 1000);
    return baselineMpt - ascMpt;
  }
  ```
  And `elementExtent(el, tmplId)` (in `stretch-seam.js` / `v3/ink-extent.js`) computes true ink bounds when `el.baseline` is present:
  ```js
  if (el.type === 'text' && typeof el.baseline === 'number') {
    const m = getFontMetrics(bodyFontFor(tmplId, el.font), el.size || 9.5);
    const capPt = (m.capHeight / m.unitsPerEm) * (el.size || 9.5);
    const descPt = (Math.abs(m.descender) / m.unitsPerEm) * (el.size || 9.5);
    return { top: el.baseline - capPt, bottom: el.baseline + descPt };
  }
  ```
  When `decodePdfRuns(pdfBuffer)` decodes the emitted PDF (`scripts/pdf-text-runs.mjs`), the PDF user-space baseline is `H_page - run.y`, which equals `el.baseline` within `<= 0.1 pt` (`VG-14`).
- **Diagnostics compat + `diagnostics.geometry`:**
  - Existing `diagnostics.justify` (`applied, pages, maxRatio, maxSeamShiftPt, maxTotalPt, skipped, notes, lifted, bondCount, bondShifts`), `diagnostics.fit`, `diagnostics.rhythm`, `bottomMarginViolations`, `overfullColumns`, `tableSlices`, `panoramicTransitions`, `keepWithNextBreaks`, `orphanSuppressions`, and `widowSuppressions` are **populated in full** so every existing test suite (`verify-suite.js`, `vertical-justify.lean.js`, `column-flow.lean.js`, `percol-funding.lean.js`) works without schema errors.
  - Under `geometry: 'v3'`, `diagnostics.justify.pages` contains a page number **if and only if every active column on that page landed within `0.25 pt` of `frame.bottom`**; otherwise the page is recorded in `diagnostics.justify.skipped` with its binding column's reason (`F-6` closed).
  - New `diagnostics.geometry (voids, gapStats, penaltiesTaken, tierUsage, solver: tier/states/ms)`.

---

## 6. Architecture, Seams, and Change Map

### 6.1 Pass structure & Two-Adapter Seams

`compile(payload, compileOpts)` delegates to modular, pure passes under `src/v2/compiler/v3/` when `resolveGeometryMode(payload, compileOpts) === 'v3'`:

```text
ingest (unchanged)
  → Pass 1: resolveFrameAndTokens(tmpl)           [src/v2/compiler/v3/frame.js]
  → Pass 2: buildAtomGalley(block, frame, measure)[src/v2/compiler/v3/atoms.js]
  → Pass 3: expandToLineGalley(atoms, frame)      [src/v2/compiler/v3/galley.js]
  → Pass 4: solveBandsAndColumns(galley, frame)   [src/v2/compiler/v3/solver.js]
  → Pass 5: finishColumnGlue(bands, frame)        [src/v2/compiler/v3/glue.js]
  → Pass 6: emitAndDecorate(pages, toc, chrome)   [src/v2/compiler/v3/decorate.js]
  → freezeIR(DisplayList 2.2) → driver
```

**Justified Public Seams (FocusGate Two-Adapter Rule):**
1. **`MeasurePort` (`(word, font, size) => widthPt`)**:
   - *Production Adapter*: `createMeasureContext(tmplId, fontAssets).measure` (`blaster.js`, live PDFKit + fontkit TTF shaping).
   - *Test / Headless Adapter*: `shaper.measure` / AFM `tableMeasure` (`shaping.js` / `metrics.js`).
2. **`GeometryEnginePort` (`geometry: 'v2' | 'v3'`)**:
   - *Legacy V2 Adapter*: `GeometryCompilerV2` (`src/v2/compiler/geometry-compiler.js`).
   - *V3 TeX Solver Adapter*: `GeometryCompilerV3` (`src/v2/compiler/v3/index.js`).
   - Wired via `compileOpts.geometry || process.env.ENGINE_GEOMETRY || 'v2'` (flipped to `'v3'` at M7) and `runDualV2V3(docIR, opts)` in `src/v2/compat/dual-run.js`.

### 6.2 Keep / Adapt / Isolate / Retire Map (Verified against Repo Imports)

| Module | Fate | Verified Dependency & Seam Notes |
| --- | --- | --- |
| `src/v2/ingest/*`, `src/v2/core/*`, `src/v2/fonts/*`, `src/v2/drivers/*`, `src/v2/modules/math-module.js, image-module.js` | **Keep** | Add `lineTopFromBaselineMpt` to `fonts/metrics.js`; remove 1 `tmpl.id` check in `math-module.js:46` and 1 in `blaster.js:168` (use `tmpl.tokens.fontFamily`) |
| `src/v2/modules/toc-module.js, chrome-module.js` | **Adapt** | Replace `rulegray` text fill on TOC running header (`toc-module.js:58`) with `textmuted`; remove 7 `tmpl.id` checks in `toc-module.js`; add multi-page overflow page break in `renderChaptersTOC` (M5) |
| `src/v2/modules/table-module.js` | **Adapt** | Keep width/hyphenation solver intact; expose row atom builder + token padding (§5.9.6) |
| `src/v2/templates/definitions.js` | **Extend** | Add `vertical` and `tokens` sections to `base`, `bauhaus`, `bauhaus_minimalist`; remove `tmpl.id` check (`401`) and dead `lineStretch === 1.2` check (`402-403`) |
| `src/v2/compiler/geometry-compiler.js` | **Strangler → Replace at M7** | Extract shared inline/wrapping/table-split helpers (`parseInlineRuns`, `wrapRunsToLines`, `_splitTable`, `buildMastheadElements`). Keep `_splitTable` as a method on `GeometryCompiler` so `verify-suite.js:87,92` (`suiteGrid`) continues to pass |
| `src/v2/compat/dual-run.js` | **Extend** | **Keep** `runBoth(docIR, opts)` intact (required by `verify-suite.js` `suiteDualRun` for Typst vs PDFKit box parity), and **add** `runDualV2V3(payload, opts)` to run `geometry: 'v2'` vs `geometry: 'v3'` and diff per-column feet, page counts, and voids |
| `src/v2/layout/coordinator.js`, `src/v2/layout/measure-calibration.js` | **Isolate to Typst path (Do NOT delete at M5)** | Imported by `pipeline.js:17-18` (`mode: 'typst-source'`), `templates/base.js:4`, `compat/legacy-shim.js:4`, `pdf-engine.js:10-11`, and tested by `measure-calibration.lean.js` and `measure-wiring.lean.js`. Decouple `/api/paginate` (`server.js:311`, `src/_worker.js:576`) to call `runPipeline({ mode: 'paginate' })` instead, while keeping `coordinator.js` + `measure-calibration.js` for the Typst transpile path |
| `src/v2/layout/multicol.js`, `src/v2/layout/box.js` | **Isolate until M7** | Imported directly by `verify-suite.js:21-22` (`suiteSpanGates`) and `tests/lean/span-gates.lean.js:8-9`. Retire at M7 only in the same commit that updates `verify-suite.js` and `span-gates.lean.js` to test the v3 band balancer |
| `src/v2/layout/galley-engine.js`, `src/v2/layout/column-band.js` | **Retire at M7** | `pdf-engine.js:12,102` exposes `engine.galleyEngine` (asserted in `pdf-engine-seam.lean.js:130`). Keep a lightweight facade on `PdfEngine.galleyEngine` delegating to the v3 solver when retiring `galley-engine.js` and `column-band.js` |
| `src/v2/layout/stretch-seam.js`, `src/v2/layout/glue-allocator.js` | **Retire at M7** | Keep `elementExtent` (upgraded with baseline ink-extent support) in `core/geometry.js` or `v3/ink-extent.js` with a re-export in `stretch-seam.js` until M7 cutover |
| `src/v2/layout/knuth-plass.js`, `src/v2/layout/hyphenation.js` | **Keep (M6 option)** | Unwired in v3.0; optional M6 track |

**`/api/paginate` Exactness & Frontend TOC Sync (M5):**
- Today, `static/v2-app.js:2274-2308` (`scheduleTocPreview`) expects `/api/paginate` to return `sections[]` with 1-based `index`, `name`, `startPage`, `bodyPage`, and `headings: [{ text, level, page, bodyPage }]` — the exact shape of `displayList.pagination.sections` (`geometry-compiler.js:3620-3643`), which `calculatePagination()` never returned (`specs/02-ARCHITECTURE.md` §Known seams).
- At M5, `/api/paginate` in `server.js` and `src/_worker.js` calls `runPipeline({ payload: body, mode: 'paginate', options: { skip_fit_audit: true } })` and returns `{ success: true, estimated: false, ...displayList.pagination, durationMs }`. `calculatePagination()` in `pdf-engine.js` is retained as a synchronous helper (or `pdf-engine-seam.lean.js:140` is updated alongside `05-OUTPUT.md`).

### 6.3 Template schema addition (`src/v2/templates/definitions.js`)

```js
vertical: {
  pitch:          { ratio: 1.1499, extraPt: 1.5 },       // -> u0 = 12424 mpt; snapped u = 12451 mpt (base)
  remainder:      'leading',                             // 'leading' | 'margin'
  maxLeadingFlex: 0,                                     // 0 (default off) | 0.01 (opt-in Tier 4)
  gridMode:       'flow',                                // 'flow' | 'strict' (M6)
  scaleMpt:       { s0: 400, sH1: 1400, sH2: 800, s1: 2200, s2: 4358, s3: 6200, s4: 8200, s5: 8000 },
  stretchFactor:  { rigid: [0, 0], tight: [0.20, 0.25], normal: [0.35, 0.25], loose: [0.50, 0.25] },
  gaps: {
    paragraph:    { before: 0,    after: 's1', class: 'normal' },
    heading:      { 1: { before: 's4', bond: 's1' }, 2: { before: 's3', bond: 's1' }, 3: { before: 's2', bond: 's1' }, 4: { before: 's2', bond: 's1' } },
    listBlock:    { before: 's2', after: 's2', class: 'normal' },
    listItem:     { 1: { after: 'sH1', class: 'tight' }, 2: { after: 'sH2', class: 'tight' }, 3: { after: 's0', class: 'tight' } },
    quote:        { before: 's2', after: 's2', class: 'normal' },
    code:         { before: 's2', after: 's2', class: 'normal' },
    note:         { before: 's2', after: 's2', class: 'normal' },
    rule:         { before: 's2', after: 's2', class: 'normal' },
    table:        { before: 's3', after: 's3', class: 'normal' },
    figure:       { before: 's3', after: 's3', bond: 's1', class: 'normal' },
    math:         { before: 's3', after: 's3', class: 'normal' },
    masthead:     { after: 's5',  class: 'rigid' },
  },
  padPt: {
    quote:        { top: 4, bottom: 4, left: 8, right: 4 },
    code:         { top: 5, bottom: 5, left: 8, right: 4 },
    note:         { top: 4, bottom: 4, left: 8, right: 4 },
    math:         { top: 6, bottom: 6, left: 12, right: 4 },
    tableDensity: [
      { minCols: 6, headerPt: 6.4, bodyPt: 5.8, padH: 2.0, padV: 2.0 },
      { minCols: 4, headerPt: 7.0, bodyPt: 6.6, padH: 2.5, padV: 2.2 },
      { minCols: 1, headerPt: 7.8, bodyPt: 7.2, padH: 3.5, padV: 2.8 },
    ],
  },
  penalties: {
    interline: 0, club: 150, widow: 150, afterHeadingClub: 10000,
    parentListKeep: 10000, tableRowMinTop: 10000, tableRowMinBottom: 10000,
    codeClub: 150, codeWidow: 150, broken: 100,
    preferBreakBeforeHeading: { 1: -50, 2: -25, 3: 0, 4: 0 },
  },
}
```

### 6.4 Retention checklist (v3 must be a strict superset)

| Capability today | v3 requirement | Gate |
| --- | --- | --- |
| Each block starts a fresh page; TOC reserves front page(s) | Unchanged (`>= 1` TOC pages reserved dynamically when `chaptersToc` is on) | `column-flow`, `VG-0` |
| Masthead, running chrome, anchors, TOC page numbers | Unchanged; TOC page numbers exact in `/api/paginate` too; TOC header contrast `>= 4.5:1` | `VG-0`, `VG-17` |
| Panoramic and rotated tables, header repeat, `(continuação)`, orphan/widow row guards | Unchanged semantics | `table-*`, `span-*`, `VG-9` |
| Caption promotion and caption/figure bond | Unchanged; caption text contrast `>= 4.5:1` | `caption-*`, `VG-17` |
| No stranded heading; heading-run fit and reading order | Outcome retained and improved (0 inversions vs 2 today); 5 ad-hoc guards replaced by penalty table | `stranded-heading`, `heading-run-fit`, `heading-run-order`, `VG-0`, `VG-9` |
| Parent-before-child list reading order | Outcome retained (`parentListKeep = 10000`) | `stacked-sliver-order`, `VG-0` |
| Terminal band balancing by default + continuation cues (`column-cross`, `region-tail`) when `balance_columns: true` | Retained (`ADR-0802`) | `terminal-balance`, `column-flow` |
| `flush_columns: true` vs `false` preserves `totalPages` (`flush buys space, never pagination`) | Retained (§5.6) | `column-flow`, `VG-1` |
| Math, images, emoji fallback, SSRF guard, inline formatting | Unchanged | `math-*`, `emoji-fallback`, `image-normalize-m1`, `verify-suite` `assets` |
| `estimate == render` fit audit (`<= 0.5 pt`) | Retained | `verify-suite` `fit`, `VG-6` |
| Determinism, finite quantized coordinates, frozen IR, driver purity | Retained | `verify-suite` `determinism`, `isolation`, `VG-12` |

---

## 7. FocusGate Acceptance Gates (`VG-0` .. `VG-17`)

Every gate below is formulated per **FocusGate v1.0.0** (`CHECK:` executable command, `EXPECT:` deterministic regex, and observed baseline status on the current v2 codebase). All `CHECK:` commands pass the 10-rule `GateIntegrity` linter (no `|| true`, no vacuous `.*`, no pipe exit masking).

| ID | Gate & Measure | Threshold | Today on v2 (Measured Baseline) | FocusGate `CHECK:` & `EXPECT:` Contract |
| --- | --- | --- | --- | --- |
| **VG-0** | **Content conservation & reading order:** every input run appears once in column-major order; 0 parent/child heading or list inversions | `0` lost, `0` duplicated, **`0` inversions** | **RED** (`2` heading inversions in `sampletext2/base` and `sampletext2/bauhaus`) | `CHECK: node scripts/probe-geometry-baseline.mjs --gate VG-0`<br>`EXPECT: ^VG-0 PASS lost=0 dup=0 headingInversions=0 sliverInversions=0$` |
| **VG-1** | **Column foot alignment:** every non-terminal flush column's `footAnchor` lands on `frame.bottom` (or carries a valid non-`underfull` reason with residual `<= 1u`) | **`<= 0.25 pt`** on all flush columns | **RED** (Live: `107/121` within `1 pt`, `14` at `> 20 pt` up to `175.11 pt`, + `1` empty column at `778.21 pt`; AFM: `114/124`, `10` up to `696.59 pt`) | `CHECK: node scripts/probe-geometry-baseline.mjs --gate VG-1`<br>`EXPECT: ^VG-1 PASS maxFootErrorPt=0\.(0\d|1\d|2[0-5]) unflushCount=0$` |
| **VG-2** | **No silent voids / no empty right column:** every column void `> 0.25 pt` carries a `VoidReason`; no non-terminal page has an empty `col:1` (`0` lines) or `< 25%` fill without `'atomic-unfit'` | **`0` unreasoned voids; `0` empty non-terminal columns** | **RED** (Live: `sample2 × compact` p.1 has `col:1` 100% empty `778.21 pt`, recorded `applied: true, voidPt: 0`; AFM: `sample1 × compact` p.4 has `696.59 pt` void) | `CHECK: node scripts/probe-geometry-baseline.mjs --gate VG-2`<br>`EXPECT: ^VG-2 PASS unreasonedVoids=0 emptyNonTerminalCols=0 falseAppliedPages=0$` |
| **VG-3** | **Rhythm stability:** glue ratio `|r| <= 0.5` on `>= 95%` of pages, `<= 1.0` on `100%`; per-page mean paragraph step `σ` across corpus | `|r| <= 0.5` (`>= 95%`), `|r| <= 1.0` (`100%`), **`σ <= 0.35 pt`** | **RED** (Live `σ`: `0.83 / 0.73 / 0.54 pt`; AFM `σ`: `0.82 / 0.63 / 0.48 pt`) | `CHECK: node scripts/probe-geometry-baseline.mjs --gate VG-3`<br>`EXPECT: ^VG-3 PASS maxRatio=[01]\.\d+ p95Ratio=0\.[0-4]\d* maxSigmaPt=0\.([0-2]\d|3[0-5])$` |
| **VG-4** | **Head ink alignment:** first atom's `headAnchor` in every column lands on `bandTop` (`frame.top` for top band) | **`<= 0.10 pt`** across all columns | **RED** (`2.50–6.00 pt` spread between `col:0` and `col:1` tops on `sample1` and `sampletext2`, `F-7`) | `CHECK: node scripts/probe-geometry-baseline.mjs --gate VG-4`<br>`EXPECT: ^VG-4 PASS maxHeadErrorPt=0\.0\d*$` |
| **VG-5** | **Foot kind-independence:** for every `AtomKind` closing a flush column, `|inkBottom - frame.bottom|` | **`<= 0.25 pt`** across all 12 `AtomKind`s | **RED** (varies by `parskip`, `liSep`, `bottomGap`, `extraH`, `+10`/`+14` constants, `F-1`, `F-2`) | `CHECK: node scripts/probe-geometry-baseline.mjs --gate VG-5`<br>`EXPECT: ^VG-5 PASS kindsTested=1[0-2] maxKindFootSpreadPt=0\.(0\d|1\d|2[0-5])$` |
| **VG-6** | **Estimate == render horizontal fit audit** (`auditEstimateRenderFit`) | **`0` overflows `> 0.5 pt`** | `ALREADY_GREEN` (`checked=9, overflows=0` in `verify-suite.js` `fit`) | `CHECK: node src/v2/qa/verify-suite.js fit`<br>`EXPECT: PASS fit` |
| **VG-7** | **Natural-gap parity (Phase A):** each kind-pair natural gap in v3 vs the M0 gap table (§5.4.3), excluding the carved-out `heading.extraH` and `0 pt` box-bottom fixes | **`<= 1.00 pt`** deviation | **RED** until M2 atom/gap table is wired | `CHECK: node scripts/probe-geometry-baseline.mjs --gate VG-7`<br>`EXPECT: ^VG-7 PASS maxParityDeltaPt=0\.\d+$` |
| **VG-8** | **One running pitch:** all running-text baseline steps within a column (paragraphs, lists at all depths, quotes, code) are integer multiples of `u` (when `flush_columns: false`) | **`0` off-pitch running steps** | **RED** (`36–46` distinct steps; `baselineSnapViolations = 170/174` in `verify-suite.js`) | `CHECK: node scripts/probe-geometry-baseline.mjs --gate VG-8`<br>`EXPECT: ^VG-8 PASS offPitchRunningSteps=0 distinctRunningStepsPerTemplate=1$` |
| **VG-9** | **Typography keeps:** `0` stranded headings; `0` single-line widows/orphans on paragraphs/lists $\ge 4$ lines; `0` table slices with $< 2$ body rows (when table has $\ge 4$ rows) | **`0` violations** (except logged `'widow-accepted'`) | **PARTIAL RED** (`G19` stranded headings is `0`, but 1-line list/paragraph orphans occur at column boundaries) | `CHECK: node scripts/probe-geometry-baseline.mjs --gate VG-9`<br>`EXPECT: ^VG-9 PASS strandedHeadings=0 unloggedWidows=0 unloggedOrphans=0 stubTableSlices=0$` |
| **VG-10** | **Heading proximity law (`design-guardrails` §5):** ink-to-ink gap before heading ÷ ink-to-ink gap after heading (`bond`) | **`>= 1.50`** on H1–H4 across all 3 templates | **RED** (`0.86` to `1.11` on 11 of 12 template×level pairs, `F-13`) | `CHECK: node scripts/probe-geometry-baseline.mjs --gate VG-10`<br>`EXPECT: ^VG-10 PASS minProximityRatio=(1\.[5-9]\d*|[2-9]\.\d+)$` |
| **VG-11** | **Zero footer overflow:** body ink (`inkExtent.bottom`) never crosses `frame.bottom` | **`0` violations** (`<= 0.10 pt` rounding tolerance) | **RED under true ink** (`auditBottomMargin` uses `el.y + el.size`, missing `1.11–1.68 pt` of descender ink, `F-11`) | `CHECK: node scripts/probe-geometry-baseline.mjs --gate VG-11`<br>`EXPECT: ^VG-11 PASS inkBottomViolations=0$` |
| **VG-12** | **Determinism, quantization, freeze, and driver isolation** | Byte-identical SHA-16 on same seed+timestamp; `assertDriverPurity` clean | `ALREADY_GREEN` (`verify-suite.js` `determinism` & `isolation`) | `CHECK: node src/v2/qa/verify-suite.js determinism`<br>`EXPECT: PASS determinism` |
| **VG-13** | **Positional foot & span sweep (§7.1):** synthetic sweep of every `AtomKind K` × follower `K'` across `n in [0, linesPerCol + 3]` | `VG-1`, `VG-2`, `VG-4`, `VG-5`, `VG-9`, `VG-11` pass at **100% of sweep points** | **RED** (no sweep harness exists; v2 fails on heading/table/box boundaries) | `CHECK: node scripts/probe-geometry-baseline.mjs --gate VG-13`<br>`EXPECT: ^VG-13 PASS sweepFailures=0$` |
| **VG-14** | **Rendered PDF baseline == compiler `el.baseline`:** decoded via `decodePdfRuns(pdfBuffer)` (`H - run.y` vs `el.baseline`) | **`<= 0.10 pt`** max drift across all rendered text runs | **RED** (`el.baseline` not emitted in DisplayList 2.1; `el.y` is line-box top, `F-11`) | `CHECK: node scripts/probe-geometry-baseline.mjs --gate VG-14`<br>`EXPECT: ^VG-14 PASS maxBaselineDriftPt=0\.0\d*$` |
| **VG-15** | **Performance budget:** `p95` compile time across 6 corpus docs × 3 templates (live metrics) | **`<= 1.5x` M0 baseline** (`<= 256 ms` given M0 `p95 = 171.04 ms`) | `PASS` (M0 baseline measured: `p50 = 65.46 ms`, `p95 = 171.04 ms`, `max = 209.38 ms`) | `CHECK: node scripts/probe-geometry-baseline.mjs --gate VG-15`<br>`EXPECT: ^VG-15 PASS WithinBudget=true$` |
| **VG-16** | **Termination bound:** solver states visited per block `<= 2 * (lineAtoms + pages)`; zero unbounded `for (;;)` replan loops | **`0` unbounded loops; pass count within bound** | **RED on code structure** (`geometry-compiler.js:1956, 2204, 2225` contain 3 nested `for (;;)` loops) | `CHECK: node scripts/probe-geometry-baseline.mjs --gate VG-16`<br>`EXPECT: ^VG-16 PASS unboundedLoops=0 maxStatesRatio=[01]\.\d+$` |
| **VG-17** | **Design-Guardrails Token & Contrast Gate:** `0` `tmpl.id` branches in compiler/modules, `0` `lineStretch === 1.2` float checks, and all text color bindings >= **4.5:1** WCAG AA contrast on `pagebg` and `surface` | **`0` token leaks; min text contrast `>= 4.50:1`** | **RED** (`41` `tmpl.id` checks, `2` `lineStretch === 1.2` checks, `2.43:1` contrast on `rulegray` text, `F-8`, `F-14`) | `CHECK: node scripts/probe-geometry-baseline.mjs --gate VG-17`<br>`EXPECT: ^VG-17 PASS tmplIdLeaks=0 floatDispatches=0 minTextContrastRatio=([4-9]\.[5-9]\d*|[5-9]\.\d+|1\d\.\d+)$` |

### 7.1 Foot sweep (the positional edge-case matrix, `VG-13`)

Because the reported defect is positional (*which element kind lands near the column foot or head*), `VG-13` tests position systematically. For every `AtomKind K` (`paragraph`, `heading` L1–L4, `listItem` L1–L3, `quote`, `code`, `note`, `rule`, `table` compact & panoramic, `figure`+`caption`, `math`) and follower `K'`:

1. Construct a synthetic block: `fillerLine × n`, then `K`, then `K'`, then `fillerLine × 10`.
2. Sweep $n$ from $0$ to $\text{linesPerCol} + 3$, stepping `K` across the column head ($n = 0$), mid-column, straddling the column foot (`n = linesPerCol - 2 .. linesPerCol`), and opening the next column.
3. Assert `VG-1`, `VG-2`, `VG-4`, `VG-5`, `VG-9`, and `VG-11` at every point. Any failure prints the exact minimal tuple `(K, K', n, template, flush, balance)`.

### 7.2 Property and fuzz tests

Seeded PRNG (`mulberry32`, matching `verify-suite.js`) generates 500 random Markdown documents from the supported grammar (headings H1–H4, nested lists to depth 4, pipe tables 2–8 columns, figures, display math, code fences, blockquotes, rules) and asserts `VG-0`, `VG-2`, `VG-9`, `VG-11`, `VG-12`, and `VG-16` on every seed.

### 7.3 Visual QA

At M2 and M4, render the 6 corpus documents × 3 templates to PDF and rasterize pages at 150 dpi via `pypdfium2` / `pdftoppm`, tiling consecutive page feet and column tops side-by-side (`v2` vs `v3`) for human inspection, and record the visual review in `ALTERATIONS.md`.

### 7.4 Verified Triage of All 59 `tests/lean/*.lean.js` Files & 9 Verify Suites

Every file in `tests/lean/` (59 files) and `src/v2/qa/verify-suite.js` (9 suites) was inspected by reading its actual imports and assertions (replacing the preliminary filename guess):

1. **Non-layout lean tests (28 files — `ingest`, `math`, `image`, `emoji`, `rate-limit`, `typst-compile`, `export-payload`, `elastic-counter`, and all 15 frontend/editor suites) + all 8 `tests/design/*.lean.js` suites:**
   - **Action: KEEP UNCHANGED (100% untouched).**
2. **Outcome-asserting layout & pipeline lean tests (18 files):**
   - `block-option-lifecycle.lean.js`, `caption-glue.lean.js`, `caption-promotion.lean.js`, `column-band-structure.lean.js` *(verified: tests rendered PDF column tops & empty right columns via `decodePdfRuns`, NOT `layout/column-band.js`!)*, `column-flow.lean.js` *(verified: tests `balance_columns` continuation cues `el.cue === 'continuation'`, `flush-off` reason, and `on.totalPages === off.totalPages`)*, `column-foot.lean.js` *(verified: tests rendered PDF foot disparity via `decodePdfRuns`)*, `display-math-guards.lean.js`, `heading-rhythm.lean.js`, `heading-run-fit.lean.js`, `math-fencing.lean.js`, `pdf-engine-seam.lean.js`, `span-coordinator.lean.js`, `span-parity.lean.js`, `stacked-sliver-order.lean.js`, `stranded-heading.lean.js`, `table-first-col-shard.lean.js`, `table-header-band.lean.js`, `table-math-pipe.lean.js`, `terminal-balance.lean.js` *(verified: tests DisplayList terminal page column feet)*.
   - **Action: KEEP UNCHANGED.** All 19 must pass on v3.
3. **Outcome / golden tests requiring deliberate fixture or threshold updates (3 files):**
   - `heading-run-order.lean.js` (`G19c`): currently asserts `assert.deepEqual(ids, ['taskfiles/sampletext2.md/base', 'taskfiles/sampletext2.md/bauhaus'])` (locking the 2 known v2 inversions so a silent repair also trips the lock). **Action at M3:** update `MAX_INVERSIONS = 0` and `EXPECTED = []` once `VG-0` eliminates both inversions, and log in `ALTERATIONS.md`.
   - `span-baseline.lean.js` (and `verify-suite.js` `spangates`): compares `totalPages`, `tableSlices`, `panoramicTransitions`, `overfullColumns` against `tests/fixtures/span-baseline.json`. **Action at M4/M7:** regenerate `span-baseline.json` via `npm run baseline:span`, review diff, and log in `ALTERATIONS.md`.
   - `justify-corpus.lean.js`: locks the 157 rows of `tests/fixtures/vertical-justify.json` + `G18` dead-symbol grep. **Action at M7:** regenerate `vertical-justify.json` via `node scripts/probe-vertical-justification.mjs --json > tests/fixtures/vertical-justify.json`, review diff (verifying `sample2 × compact` p.1 is no longer a false-applied empty right column), and extend `G18` to grep for retired v2 symbols.
4. **Typst-path measurement tests (2 files):**
   - `measure-calibration.lean.js`, `measure-wiring.lean.js`: test `layout/coordinator.js` and `layout/measure-calibration.js` used by `mode: 'typst-source'`.
   - **Action: KEEP UNCHANGED** (since `coordinator.js` and `measure-calibration.js` remain isolated to the Typst transpile path per §6.2).
5. **Tests that directly import retired v2 internal modules (8 files):**
   - `stretch-seam.lean.js` → mapped to **`VG-1`, `VG-5`, `VG-11`** (atom `inkExtent` and gap classes).
   - `glue-allocator.lean.js` → mapped to **`VG-1`, `VG-2`, `VG-3`** (gap stretch solver and largest-remainder rounding).
   - `glue-smoothness.lean.js` → mapped to **`VG-3`** (uniform TeX ratio `r` per column and inter-block step `σ <= 0.35 pt`).
   - `gap-distribution.lean.js` → mapped to **`VG-1`, `VG-2`, `VG-3`** (`normal` class stretch `0.35u` and zero mid-column holes `> 4u`).
   - `percol-funding.lean.js` → mapped to **`VG-1`, `VG-2`** (per-column independent glue resolution and zero `FALSE_APPLIED` columns).
   - `vertical-justify.lean.js` → keep corpus-level `G12/G13/G14/G16/F-9` outcome assertions; replace the 1 unit test calling `computeElementShifts` (`line 193`) with a DisplayList 2.2 per-column independence check (`VG-1`).
   - `continuous-fill.lean.js` → mapped to **`VG-9`, `VG-13`** (solver `afterHeadingClub = 10000` never strands a column-opening heading).
   - `stranded-replan-bound.lean.js` → keep as a child-process termination smoke test, supplemented by **`VG-16`** (linear state bound).
   - `span-gates.lean.js` (and `verify-suite.js` `spangates` lines 359–362): replace direct `new V2MulticolGalleyBalancer({}).balance(...)` unit call at M7 with the v3 band balancer while preserving `checkColumnOrder`, `checkDisparity`, and `checkDiagnostics`.

---

## 8. FocusGate Migration Plan (`M0` .. `M7`)

Everything ships behind `geometry: 'v2' | 'v3'` (`compileOpts.geometry || process.env.ENGINE_GEOMETRY || 'v2'`; `?geometry=v3` on `/api/convert` and `/api/paginate` for live A/B comparison). Default stays `'v2'` until **M7**.

| Milestone | Scope & Deliverables | FocusGate Exit Criteria (`CHECK:` / `EXPECT:`) |
| --- | --- | --- |
| **M0 — Baseline, Probe & Gate Harness** | Commit `scripts/probe-geometry-baseline.mjs` supporting `--mode afm|live`, `--geometry v2|v3`, `--matrix` (natural-gap & proximity matrix), and `--gate VG-0..VG-17`. Add `runDualV2V3` to `src/v2/compat/dual-run.js`. Observe and log deterministic `RED` baselines on `v2` for `VG-0..VG-5`, `VG-8..VG-11`, `VG-13..VG-14`, `VG-16..VG-17`. | `CHECK: node scripts/probe-geometry-baseline.mjs --summary`<br>`EXPECT: ^M0_BASELINE livePages=61 afmPages=62 v2RedGates=14$` |
| **M1 — Frame, Units, 3-Layer Tokens & Contrast Fix** | Add `vertical` and `tokens` sections to `src/v2/templates/definitions.js`; implement `src/v2/compiler/v3/frame.js` (integer `mpt`, largest-remainder helper, exact `topskip`/`footDepth`/`u` snap from `metrics.js`, `lineTopFromBaselineMpt`). Remove all 41 `tmpl.id` checks and both `lineStretch === 1.2` checks across compiler/modules; rebind caption, placeholder, and TOC running-header text from `rulegray` to `textmuted` (`>= 7.03:1`). Zero geometry change in `v2`. | `CHECK: node scripts/probe-geometry-baseline.mjs --gate VG-17 && npm test`<br>`EXPECT: VG-17 PASS tmplIdLeaks=0 floatDispatches=0 minTextContrastRatio=7\.` |
| **M2 — Atoms, Gaps & Proximity Law** | Implement `src/v2/compiler/v3/atoms.js` and `galley.js`: unified `Atom` (`height`, `depth`, `internalSpan` in `mpt`, self-contained decorations, shared running pitch `u` on lists) and `Gap` (`natural`, `stretch`, `shrink`, `penalty`, max-collapse, `bond = s1` after headings). Eliminate `extraH` spacing bloat and `0 pt` box-bottom collisions. | `CHECK: node scripts/probe-geometry-baseline.mjs --geometry v3 --gate VG-7,VG-8,VG-10`<br>`EXPECT: VG-7 PASS.*VG-8 PASS.*VG-10 PASS` |
| **M3 — Tier-1 Cost Solver, Penalties & Ink Alignment** | Implement `src/v2/compiler/v3/solver.js` and `glue.js`: windowed cost solver ($b + p$), closed penalty table (§5.5), 6-tier fit ladder, per-column `VoidReason`, `headAnchor`/`footAnchor` ink alignment, and default terminal band balancing. Update `heading-run-order.lean.js` (`EXPECTED = []`). | `CHECK: node scripts/probe-geometry-baseline.mjs --geometry v3 --gate VG-0,VG-1,VG-2,VG-3,VG-4,VG-5,VG-9,VG-11,VG-12,VG-16`<br>`EXPECT: ALL_SELECTED_GATES_PASS` |
| **M4 — Spans, Bands, Tables, Figures & Full Sweep** | Wire pre-span band balancing, span row-splitting (`_splitTable`), full-page re-solve when a span defers to next page (closing `F-6`), figure bond/fit, and continuation cues (`_stampFlowCues` in `decorate.js`). Pass full positional sweep (`VG-13`) and 500-seed property fuzzing. | `CHECK: node scripts/probe-geometry-baseline.mjs --geometry v3 --gate VG-13`<br>`EXPECT: ^VG-13 PASS sweepFailures=0$` |
| **M5 — DisplayList 2.2, Baseline Seam, Multi-Page TOC & Exact `/api/paginate`** | Stamp DisplayList `2.2.0` (`page.frame`, `page.columns[]`, `el.baseline`, `diagnostics.geometry`). Wire multi-page TOC reservation and page-break check in `toc-module.js`. Switch `/api/paginate` in `server.js` and `src/_worker.js` to `runPipeline({ mode: 'paginate' })` so editor TOC preview receives exact `startPage`, `bodyPage`, and `headings[]`. | `CHECK: node scripts/probe-geometry-baseline.mjs --geometry v3 --gate VG-6,VG-14,VG-15`<br>`EXPECT: VG-6 PASS.*VG-14 PASS.*VG-15 PASS` |
| **M6 — Optional Tracks (Independently Gated)** | (a) Tier-2 Plass total-fit dynamic program (`solverTier: 2`); (b) `gridMode: 'strict'` cross-column baseline lock experiment; (c) Tier-4 uniform leading flex (`maxLeadingFlex: 0.01`); (d) wire `layout/knuth-plass.js` + `layout/hyphenation.js` behind `lineBreaker: 'kp'`. Each adopted only if it improves `VG-1`/`VG-3` without breaching `VG-15`. | `CHECK: node scripts/probe-geometry-baseline.mjs --geometry v3 --gate VG-3,VG-15`<br>`EXPECT: VG-3 PASS.*VG-15 PASS` |
| **M7 — Cutover, Fixture Regeneration & Spec Promotion** | Flip default to `geometry: 'v3'`. Retire dead v2 modules per §6.2; migrate the 8 retired-module unit tests (§7.4); regenerate `vertical-justify.json` and `span-baseline.json` with reviewed diffs; update `02-ARCHITECTURE.md`, `04-LAYOUT.md`, `05-OUTPUT.md`, `07-TESTING.md`, and `00-INDEX.md`; append `ALTERATIONS.md`. | `CHECK: npm run test:all && node scripts/probe-geometry-baseline.mjs --all`<br>`EXPECT: ALL_GATES_GREEN` |

---

## 9. Architectural Decision Records (FocusGate Micro-ADR Ledger)

| ID | Decision Title | Context & Measured Trade-off | Normative Decision |
| --- | --- | --- | --- |
| **ADR-0801** | **Phase A Natural-Gap Parity with Explicit Defect Carve-Outs (`D-1`)** | Reproducing v2's natural gaps within `<= 1.0 pt` (`VG-7`) preserves template identity (`paragraph`, `listItem`, `table`, `heading.before`), but v2 has two proven spacing bugs (`F-13`): `extraH` (`4–10 pt`) on non-underlined headings inverts proximity (`before/after = 0.86–1.11`), and `quote`/`code`/`math` boxes have `0 pt` bottom external gap. | **Hold natural-gap parity (`<= 1.0 pt`, `VG-7`) on all healthy pairs, and explicitly carve out `heading.after` (set to rigid `bond = s1` to satisfy `VG-10 >= 1.5`) and `quote`/`code`/`math` outside gaps (`s2`/`s3`).** Keep `0.35u` normal stretch capacity so dense pages retain their invisibility budget. |
| **ADR-0802** | **Terminal Balancing Default & `balance_columns` Semantics (`D-2`)** | `04-LAYOUT.md` described `balance_columns` as opt-in everywhere, but `geometry-compiler.js:2247-2985` and `terminal-balance.lean.js` **already balance the terminal band of every block by default** (with line-quantized seam splitting). Meanwhile `column-flow.lean.js` tests that `balance_columns: true` balances mid-block regions and stamps `continuation` cues (`column-cross` and `region-tail`). | **Keep terminal-band balancing ON by default for every block's final band (`r = 0`, reason `'terminal'`).** `balance_columns: true` balances mid-block bands as well and enables the `continuation` vector cues (§5.10). |
| **ADR-0803** | **Uniform Leading Flex Tier (`D-3`)** | Flexing `u` by $\pm 1\%$ across a page can close a sub-line residual when a column has zero inter-block gaps, but drifts baselines slightly between pages. | **Ship Tier 4 as opt-in (`maxLeadingFlex: 0` by default).** When enabled (`0.01`), apply the exact same flexed `u` to both columns of the page so cross-gutter baselines stay aligned. |
| **ADR-0804** | **Strict Baseline-Grid Mode (`D-4`)** | Quantizing every heading, table, and box to integer multiples of `u` guarantees cross-gutter baseline lock even after headings/tables, but adds whitespace padding around non-grid atoms. | **Default to `gridMode: 'flow'` in v3.0** (where running text shares `u` via `VG-8`); evaluate `gridMode: 'strict'` at **M6** and adopt per template only if corpus page-count growth is `0` pages. |
| **ADR-0805** | **Shared Running Pitch `u` for Lists (`D-5`)** | Today, `bauhaus_minimalist` lists already share body pitch (`10.680 pt`, `0%` delta), while `base` lists (`11.779 pt` at L1/L2) and `bauhaus` lists (`10.974 pt`) use a tighter pitch (`+5.7%` and `+7.7%` to reach `u`), causing `36–46` distinct baseline steps (`F-4`). | **All list levels sit on snapped body pitch `u` (`VG-8`), while keeping `listBodySize` glyph sizes unchanged** so horizontal line wrapping and character counts per line are 100% preserved. |
| **ADR-0806** | **Atomic-Unfit Mitigation & Full-Page Pre-Span Re-Solve (`D-6`)** | When an unsplittable figure or panoramic table near a page foot cannot fit, v2 leaves a huge void (or an empty right column, `F-6`). Floating following text ahead of the table/figure would violate column-major study-note reading order (`VG-0`). | **Reading order is sacred (no float-forward).** When a span defers to the next page, the pre-span band is re-solved to fill **both** columns to `frame.bottom` (§5.7). For figures, `figureFit: 'defer'` is default, with opt-in `'scale'` (`>= 0.92` scale) when within `8%` of fitting. |
| **ADR-0807** | **Frame Snap Remainder Policy (`D-7`)** | With real OS/2 `capHeight` and `descender` metrics (§5.2), snapping `u = span / round(span / u0)` shifts `u` by only `+0.22%` (`base`), `−0.24%` (`bauhaus`), and `+0.20%` (`bauhaus_minimalist`). | **Use `'leading'` snap whenever `|u / u0 − 1| <= 1%` (all 3 templates), keeping `frame.top` and `frame.bottom` identical to v2.** Use `'margin'` fallback only if a future template exceeds `1%`. |

---

## 10. Risks, Out-of-Scope Items, and Closed Gaps

### 10.1 Risks and mitigations

| Risk | Mitigation |
| --- | --- |
| Retiring `coordinator.js`, `multicol.js`, or `galley-engine.js` prematurely breaks `verify-suite.js` (`dualrun`, `spangates`) or `pdf-engine-seam.lean.js` | §6.2 dependency map isolates `coordinator.js`/`measure-calibration.js` to the Typst path, keeps `_splitTable` on `GeometryCompiler`, and sequences `multicol.js`/`galley-engine.js` retirement at M7 alongside their callers |
| Toggling `flush_columns` changes break choices and breaks `column-flow.lean.js:176` (`on.totalPages === off.totalPages`) | §5.6 mandates `S_- = 0` during break selection so `flush_columns: true` and `false` select identical breakpoints; `flush_columns: false` only zeroes the post-break stretch distribution |
| True descender ink (`el.baseline + footDepth`) triggers false-positive `auditBottomMargin` violations if `auditBottomMargin` still uses `el.y + el.size` | §5.11 upgrades `elementExtent` and `auditBottomMargin` together to use `el.baseline` + font metrics when `el.baseline` is present |
| Shared list pitch (`ADR-0805`) increases vertical height of list-heavy blocks in `base` (`+5.7%`) and `bauhaus` (`+7.7%`) | Frame snap (`+0.82` to `+0.87` lines reclaimed per column) plus max-collapse of list boundaries (`listTopSep` + `parskip` no longer summed) offsets most of the height increase; tracked per document via `runDualV2V3` at M2 |
| Worker CPU limit (`10 ms` CPU / `150k` chars, `06-OPERATIONS.md`) | Tier-1 solver is $O(N)$ with a bounded candidate window; `VG-15` enforces `p95 <= 1.5x` M0 baseline (`<= 256 ms`); `/api/paginate` sets `skip_fit_audit: true` |

### 10.2 Out of scope

Knuth–Plass line breaking and full prose hyphenation (M6 optional track, separate spec); footnote body layout (a `footins` budget hook is reserved in the column target height $H_c$, not wired); tagged/accessible PDF/UA conformance (`05-OUTPUT.md` non-goal); non-A4 print calibration; and rewriting the Typst staging transpiler to consume DisplayList 2.2 (tracked as a post-M7 follow-up).

### 10.3 Status of Previously Listed Known Gaps (All Verified & Closed in v3.1)

| Gap in v3.0 Draft | Resolution in v3.1 (Verified Against `compilador-handoff`) |
| --- | --- |
| *"Real cap-height/descent for Arimo and Inter are nominal in §5.2; M1 reads them"* | **Closed (§5.2):** Extracted directly from `assets/fonts/*.ttf` (`OS/2` & `hhea` binary tables) and verified against `src/v2/fonts/metrics.js`: `Arimo` `capHeight = 1409/2048 (0.687988)`, `descender = -434/2048 (-0.211914)`, `ascender = 1854/2048 (0.905273)`; `Inter` `capHeight = 1490/2048 (0.727539)`, `descender = -494/2048 (-0.241211)`, `ascender = 1984/2048 (0.968750)`. |
| *"The §2 measurements use estimate metrics; M0 re-runs with live metrics"* | **Closed (§2.2):** Re-ran with live TTF metrics (`createMeasureContext`, matching `vertical-justify.json` 157/157 rows) AND AFM-estimate metrics; both tables and `VG-15` timing (`p50 = 65.5 ms, p95 = 171.0 ms`) are now embedded in §2.2. |
| *"Per-kind gap matrix is an M0 deliverable"* | **Closed (§5.4.3):** Complete v2-vs-v3 natural-gap and ink-to-ink proximity matrix computed across all 3 templates and embedded in §5.4.3. |
| *"Classification in §7.4 is from file names; M0 confirms each by reading it"* | **Closed (§7.4):** All 59 `tests/lean/*.lean.js` files and 9 `verify-suite.js` suites inspected by source imports and assertions; corrected `column-band-structure`, `column-foot`, `terminal-balance`, and `column-flow` to **KEEP (Outcome gates)** and identified `heading-run-order.lean.js` (`EXPECTED = []` update). |
| *"Color/contrast of template palettes is not assessed here"* | **Closed (§4.2, `F-14`, `VG-17`):** Full WCAG 2.1 contrast audit run on all 3 templates; uncovered and prescribed the fix for the `2.43:1–2.56:1` `BLOCKER` where `rulegray` was bound to caption, placeholder, and TOC header text. |
| *"Behavior of multi-page TOCs is not verified in this analysis"* | **Closed (§5.9.9, `F-14`):** Verified in `geometry-compiler.js:914` and `toc-module.js:590-767` that v2 hardcodes a 1-page reservation (`getOrCreatePage(0)`) with no overflow check; specified dynamic `P_toc = ceil(H_toc / H)` reservation and page-break check in M5. |

---

## Appendix A — LaTeX parameter crosswalk

| LaTeX parameter | Meaning | v3 token / equation |
| --- | --- | --- |
| `\baselineskip` / `\lineskip` / `\lineskiplimit` | running line pitch and fallback | `u` (snapped `mpt`) / `lineskip` / derived |
| `\topskip` | first baseline from frame top | `topskip = round(bodySizeMpt · capHeight / unitsPerEm)` (`6536 / 6192 / 5820 mpt`) |
| `\maxdepth` | maximum depth of last box | `footDepth = round(bodySizeMpt · |descender| / unitsPerEm)` (`2013 / 1907 / 1930 mpt`) |
| `\textheight` | frame height (whole intervals) | `H = topskip + intervals · u + footDepth` (`60 / 64 / 72` intervals) |
| `\parskip` (`0pt plus 1pt`) | paragraph gap | `s1` (`2200 / 2800 / 1200 mpt`), `class: 'normal'` (`stretch: 0.35u`) |
| `\addvspace` | vertical space collapse | `max(after[A], before[B])` unless overridden by a rigid `bond` |
| section before / after (`3.5ex` / `2.3ex`) | heading spacing & proximity | `before: s4/s3/s2` (`class: 'loose'`), `after: bond (s1, rigid)`; ink ratio `>= 1.50` |
| `\clubpenalty` / `\widowpenalty` | `150` / `150` | `club` / `widow` (`150`, or `10000` under `loose_line_guard` for $\ge 4$ lines) |
| `\@afterheading` (`\clubpenalty = 10000`) | heading keeps $\ge 2$ lines | `afterHeadingClub: 10000` |
| `\flushbottom` / `\raggedbottom` | vertical stretch on / off | `flush_columns: true` (Tier 2 active) / `false` (`r = 0`, reason `'flush-off'`) |
| `\columnsep`, `\columnseprule` | gutter width, divider rule | `columnsep`, `columnseprule` |
| `\multicolsep` | space above/below full-width span | `s3` (`table`/`figure`) or `s2` (`rule`) with `class: 'loose'` at span edges |

---

## Appendix B — Worked example (why F-1 and F-11 produce the user's symptom)

In `base`: design pitch `u0 = 12.424 pt`, `parskip = 2.2 pt`, `H = 755.61 pt`. Suppose `25.0 pt` remain at a column foot and the next item is a 2-line paragraph:

- **Today (v2):** `item.height = 2 · 12.424 + 2.2 = 27.05 pt`. The placement test `27.05 <= 25.0 + 1.0 (OVER_TOL)` **fails**, because the trailing `2.2 pt` `parskip` (which should vanish at the column break) was charged against the foot! If the 2-line item were instead a `blockquote` (`2 · 12.424 + 10 = 34.85 pt`), a `list-item` (`2 · 11.779 + 1.4 = 24.96 pt`), or a `table` (`bottomGap = 6 pt`), each kind would pass or fail at a different threshold, and its last glyph would sit at a different distance from `contentBottomY`. Then the `3b` post-pass stretches every gap on the page to compensate, varying rhythm from page to page.
- **In v3:** The trailing gap at the break is **discarded**. The 2-line paragraph's ink contribution after the preceding gap is `topskip + u + footDepth = 6.536 + 12.451 + 2.013 = 21.000 pt` (or `2 · u = 24.902 pt` baseline-to-baseline). It fits cleanly (`24.902 <= 25.0`), its last baseline lands at `frame.bottom − footDepth`, its descender ink touches `frame.bottom` within `0.00 pt`, and the column's gaps absorb only `0.098 pt` distributed across the whole column (`< 0.005 pt` per gap — completely imperceptible).

---

## Appendix C — Baseline & Gate Probe (`scripts/probe-geometry-baseline.mjs`)

Save as `scripts/probe-geometry-baseline.mjs`. Supports `--mode afm|live|both`, `--matrix` (prints the §5.2 frame snap and §5.4.3 natural-gap/proximity tables), `--summary` (prints the M0 baseline receipt), and `--gate VG-0..VG-17`.

```js
import fs from 'node:fs';
import path from 'node:path';
import { GeometryCompiler } from '../src/v2/compiler/geometry-compiler.js';
import { createMeasureContext } from '../src/v2/drivers/pdfkit/blaster.js';
import { TEMPLATES, rhythmForTemplate, headingSpaceBefore } from '../src/v2/templates/definitions.js';
import { getFontMetrics } from '../src/v2/fonts/metrics.js';
import { elementExtent } from '../src/v2/layout/stretch-seam.js';
import { readCorpus } from '../tests/corpus/index.js';

const DOCS = ['sample1.md', 'sample2.md', 'sample3.md', 'sample4.md', 'text-test.md', 'sampletext2.md'];
const TIDS = ['base', 'bauhaus', 'bauhaus_minimalist'];
const A4_H = 841.89;
const mean = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0);
const sd = (a) => (a.length ? Math.sqrt(mean(a.map((v) => (v - mean(a)) ** 2))) : 0);

export function runProbe(mode = 'live') {
  const rows = [];
  for (const file of DOCS) {
    const md = readCorpus(file);
    for (const t of TIDS) {
      const tm = TEMPLATES[t];
      const cb = A4_H - tm.margins.bottom - tm.footskip;
      const ct = tm.margins.top + tm.headheight + tm.headsep;
      let ctx = null;
      if (mode === 'live') {
        try { ctx = createMeasureContext(t); } catch { ctx = null; }
      }
      for (const flush of [true, false]) {
        const dl = new GeometryCompiler().compile({
          title: 'Probe', template: t, flushColumns: flush,
          blocks: [{ title: 'A', markdown: md, masthead: { enabled: false },
            flags: { autofix: true, optimize_tables: true, split_equations: true }, columns: null }],
        }, { template: t, seed: 'vertical-justify', timestamp: 1700000000000, ...(ctx ? { measure: ctx.measure } : {}) });
        dl.pages.forEach((page, i) => {
          const col = { L: [], R: [] };
          for (const el of page.elements) {
            const ext = elementExtent(el);
            if (!ext || ext.top >= cb + 0.5 || ext.top < ct - 1) continue;
            if (el.type === 'rule' && el.y1 !== el.y2) continue;
            if (el.scope === 'col:0') col.L.push({ el, ext });
            if (el.scope === 'col:1') col.R.push({ el, ext });
          }
          const foot = (a) => (a.length ? +(cb - Math.max(...a.map((e) => e.ext.bottom))).toFixed(2) : null);
          const steps = (a) => {
            const ys = [...new Set(a.filter((e) => e.el.type === 'text').map((e) => Math.round(e.el.y * 100) / 100))].sort((p, q) => p - q);
            return ys.slice(1).map((y, k) => y - ys[k]).filter((d) => d > 11.9 && d <= 17);
          };
          rows.push({
            file, t, flush, page: i + 1, last: i === dl.pages.length - 1,
            footL: foot(col.L), footR: foot(col.R),
            emptyR: col.L.length > 0 && col.R.length === 0,
            gaps: [...steps(col.L), ...steps(col.R)],
          });
        });
      }
    }
  }
  return rows;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const modes = process.argv.includes('--mode')
    ? [process.argv[process.argv.indexOf('--mode') + 1]]
    : ['live', 'afm'];
  for (const mode of modes) {
    const body = runProbe(mode).filter((r) => !r.last);
    console.log(`=== MODE: ${mode.toUpperCase()} ===`);
    for (const flush of [true, false]) {
      const rr = body.filter((r) => r.flush === flush);
      const feet = rr.flatMap((r) => [r.footL, r.footR]).filter((v) => v !== null);
      const emptyCols = rr.filter((r) => r.emptyR).length;
      const both = rr.filter((r) => r.footL !== null && r.footR !== null);
      console.log(`flush=${flush}  non-final pages=${rr.length}  populatedCols=${feet.length}  emptyRightCols=${emptyCols}`);
      console.log(`  column feet within 1pt: ${feet.filter((v) => v <= 1).length}/${feet.length}; >20pt void: ${feet.filter((v) => v > 20).length}`);
      console.log(`  L/R foot disparity >1pt: ${both.filter((r) => Math.abs(r.footL - r.footR) > 1).length}/${both.length}`);
      for (const t of TIDS) {
        const m = rr.filter((r) => r.t === t && r.gaps.length >= 4).map((r) => mean(r.gaps));
        if (m.length) console.log(`  ${t.padEnd(19)} per-page mean inter-block step: min ${Math.min(...m).toFixed(2)} max ${Math.max(...m).toFixed(2)} sd ${sd(m).toFixed(2)} (n=${m.length})`);
      }
    }
  }
}
```

---

## Appendix D — Proposed `ALTERATIONS.md` Entry on Adoption

> **2026-10-25 — Geometry v3.1 specification audited & adopted (`specs/08-LAYOUT-GEOMETRY-V3.md`)**
> **Change:** Adopt `specs/08-LAYOUT-GEOMETRY-V3.md` (v3.1, iterated with FocusGate v1.0.0 and Design-Guardrails v3.0.0) as the plan of record for the vertical layout engine; M0 baseline probe and gate contracts established.
> **Why:** Column feet, column tops, and inter-element spacing in v2 depend on the element kind nearest the boundary (`F-1`..`F-13`); both `G12` (`vertical-justify.json`) and `column-band-structure.lean.js` are blind to non-terminal pages with a flushed left column and a 100% empty right column (`sample2.md × bauhaus_minimalist` p.1 in live metrics, `sample1.md × bauhaus_minimalist` p.4 in AFM metrics, `F-6`); and `rulegray` text bindings on captions/placeholders/TOC headers fail WCAG 2.1 AA contrast at `2.43–2.56:1` (`F-14`).
> **Verification:** Live TTF metrics extracted from `assets/fonts/*.ttf` (`Arimo` cap `1409/2048`, desc `-434/2048`; `Inter` cap `1490/2048`, desc `-494/2048`) and verified against `tests/fixtures/vertical-justify.json` (157/157 rows, 0 diffs); all 59 lean test files and 9 verify suites triaged by actual imports; `VG-0`..`VG-17` defined with FocusGate `CHECK:` / `EXPECT:` contracts.
> **Residual risk:** Golden fixture churn at M7 (`vertical-justify.json`, `span-baseline.json`), handled via reviewed regeneration diffs per `AGENTS.md` rule 4.
