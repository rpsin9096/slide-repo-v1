/**
 * DEPRECATED: Legacy pdf-generator entrypoint + Editorial PDF Print Pipeline (Deliverable D.1).
 * The legacy monolith has been retired. This facade forwards directly
 * to the modular V2 PdfEngine (pdf-engine.js) and exposes generateEditorialPdf
 * for headless Chromium / Puppeteer print export pipelines.
 */

import {
  convertDocument,
  calculatePagination,
  PdfEngine,
  EditorialGeometryEngine,
  normalizeEditorialGeometry,
  verifyTemplateEditorialGeometry,
  DEFAULT_GUARDRAILS_CONFIG,
} from './pdf-engine.js';
import { TEMPLATES } from './src/v2/templates/definitions.js';

export {
  convertDocument,
  calculatePagination,
  PdfEngine,
  TEMPLATES,
  EditorialGeometryEngine,
  normalizeEditorialGeometry,
  verifyTemplateEditorialGeometry,
};

/**
 * Puppeteer / Chromium Print Export Pipeline (Master Specification v2.0 Deliverable D.1).
 * Switches to print media, runs normalizeEditorialGeometry inside the page DOM,
 * and exports the PDF honoring the resolved template @page size and margins.
 */
export async function generateEditorialPdf(page, outputPath, options = {}) {
  const guardrailsConfig = options.guardrailsConfig || DEFAULT_GUARDRAILS_CONFIG;

  // 1. Switch to print media and wait for fonts and layout stability
  await page.emulateMediaType('print');
  await page.evaluateHandle('document.fonts.ready');

  // 2. Run the template-aware geometry normalizer inside the page DOM
  const normalizationResult = await page.evaluate(
    async (config, runtimeOptions) => {
      const root =
        document.querySelector('[data-document-root], .document-root, .page-content, main') ||
        document.body;

      if (typeof window.normalizeEditorialGeometry !== 'function') {
        throw new Error('window.normalizeEditorialGeometry is not registered on the page.');
      }
      return await window.normalizeEditorialGeometry(root, config, runtimeOptions);
    },
    guardrailsConfig,
    options
  );

  const { resolvedGeometry } = normalizationResult;

  // 3. Export PDF honoring the injected template @page size and margins
  return await page.pdf({
    path: outputPath,
    width: resolvedGeometry.css.width,
    height: resolvedGeometry.css.height,
    landscape: resolvedGeometry.orientation === 'landscape',
    printBackground: true,
    preferCSSPageSize: true,
    margin: { top: '0mm', right: '0mm', bottom: '0mm', left: '0mm' }, // Controlled by injected @page CSS
  });
}

/**
 * Main PDF Generation Entrypoint (facade).
 * Delegates to modular V2 PdfEngine.
 */
export async function generatePdf(options = {}) {
  const driver = options.driver || (options.engine === 'v2-typst' ? 'typst' : 'pdfkit');
  return convertDocument(options, { driver, format: 'pdf' });
}

/**
 * Fast-path pagination calculation (facade).
 */
export async function calculateDocumentPagination(options = {}) {
  return calculatePagination(options);
}

/**
 * Rotated table detector (facade). Handled natively in V2 modular engine.
 */
export function hasRotatedTable(options = {}) {
  if (!options || typeof options !== 'object') return false;
  const isRot = (v) => typeof v === 'string' && /^(rotated|rotated_cw|rotated_ccw|rotated_d1|rotated_d2)$/i.test(v.trim());
  if (
    isRot(options.table_layout) ||
    isRot(options.tableLayout) ||
    isRot(options.table_layout_mode) ||
    isRot(options.tableLayoutMode)
  ) {
    return true;
  }
  const items = Array.isArray(options.sections)
    ? options.sections
    : Array.isArray(options.blocks)
      ? options.blocks
      : [];
  return items.some(item =>
    item && (
      isRot(item.table_layout) ||
      isRot(item.tableLayout) ||
      isRot(item.table_layout_mode) ||
      isRot(item.tableLayoutMode)
    )
  );
}

/**
 * Elastic elements counter (used by geometry verification tests).
 */
export function countElasticElements(tokens) {
  let itemCount = 0, headingCount = 0, paragraphCount = 0;
  let tableCount = 0, rowCount = 0, imageCount = 0, mathCount = 0;

  const countMathPairs = (raw) => {
    if (typeof raw !== 'string') return 0;
    const fences = raw.match(/\$\$/g);
    return fences ? Math.floor(fences.length / 2) : 0;
  };
  const walkInline = (toks) => {
    for (const t of (toks || [])) {
      if (!t) continue;
      if (t.type === 'image') imageCount += 1;
      if (Array.isArray(t.tokens)) walkInline(t.tokens);
    }
  };
  const walkBlocks = (toks) => {
    for (const tok of (toks || [])) {
      if (!tok) continue;
      switch (tok.type) {
        case 'list':
          for (const item of (tok.items || [])) {
            itemCount += 1;
            if (Array.isArray(item.tokens)) walkBlocks(item.tokens);
          }
          break;
        case 'heading':
          headingCount += 1;
          mathCount += countMathPairs(tok.raw);
          walkInline(tok.tokens);
          break;
        case 'paragraph':
          paragraphCount += 1;
          mathCount += countMathPairs(tok.raw);
          walkInline(tok.tokens);
          break;
        case 'table':
          tableCount += 1;
          rowCount += 1 + (tok.rows ? tok.rows.length : 0);
          for (const c of (tok.header || [])) walkInline(c.tokens);
          for (const r of (tok.rows || [])) for (const c of (r || [])) walkInline(c.tokens);
          break;
        case 'blockquote':
          if (Array.isArray(tok.tokens)) walkBlocks(tok.tokens);
          break;
        case 'image':
          imageCount += 1;
          break;
        default:
          if (tok.type === 'text' && Array.isArray(tok.tokens)) walkInline(tok.tokens);
          break;
      }
    }
  };
  walkBlocks(tokens);
  return { itemCount, headingCount, paragraphCount, tableCount, rowCount, imageCount, mathCount };
}

export default {
  generatePdf,
  generateEditorialPdf,
  calculateDocumentPagination,
  hasRotatedTable,
  convertDocument,
  calculatePagination,
  PdfEngine,
  TEMPLATES,
  EditorialGeometryEngine,
  normalizeEditorialGeometry,
  verifyTemplateEditorialGeometry,
};
