/**
 * FocusGate / PDF Engine V2: Clean-Sheet PDF Conversion & Layout Engine
 * 
 * Modular, decoupled, event-driven architecture with high token efficiency,
 * stateless geometry planning, and dual-driver execution.
 */

import { EngineEventBus, createEngineEventBus } from './src/v2/core/events.js';
import { validateDocIR, normalizeToDocIR, assertLayoutBox } from './src/v2/core/contracts.js';
import { measure } from './src/v2/layout/coordinator.js';
import { resolveCalOpts } from './src/v2/layout/measure-calibration.js';
import { GalleyEngine } from './src/v2/layout/galley-engine.js';
import { renderWithTemplate, TEMPLATES } from './src/v2/templates/index.js';
import { emit as emitTypst } from './src/v2/drivers/typst/emitter.js';
import { emit as emitPdfkit, FontMetrics } from './src/v2/drivers/pdfkit/driver.js';
import { isDriver } from './src/v2/drivers/interface.js';
import { ModularTableEngine } from './src/v2/modules/table-module.js';
import { ModularMathEngine } from './src/v2/modules/math-module.js';
import { ModularImageResolver } from './src/v2/modules/image-module.js';
import { ModularChromeEngine } from './src/v2/modules/chrome-module.js';
import { renderChaptersTOC } from './src/v2/modules/toc-module.js';

const IMAGE_REF_RE = /!\[([^\]]*)\]\(([^)]+)\)/g;

/** Max parallel image resolves on the convert hot path (CC2). */
export const IMAGE_PRE_RESOLVE_CONCURRENCY = 4;

/**
 * Collects unique image sources across blocks in first-occurrence order.
 * Strips `"title"` suffixes so `![a](src "t")` resolves as `src`.
 * Fresh match per block (matchAll): the old shared /g exec loop leaked
 * lastIndex across blocks and could skip leading images of later blocks.
 * @param {Array} blocks DocumentIR blocks
 * @returns {string[]}
 */
export function collectImageSources(blocks) {
  const seen = new Set();
  const ordered = [];
  for (const block of blocks || []) {
    if (!block || typeof block.markdown !== 'string') continue;
    for (const match of block.markdown.matchAll(IMAGE_REF_RE)) {
      let src = (match[2] || '').trim();
      const titleM = src.match(/^(\S+)\s+["'](.*)["']$/);
      if (titleM) src = titleM[1];
      if (src && !seen.has(src)) {
        seen.add(src);
        ordered.push(src);
      }
    }
  }
  return ordered;
}

const passthroughKey = (obj, ...keys) => {
  for (const k of keys) {
    if (obj && obj[k] !== undefined) return obj[k];
  }
  return undefined;
};

/**
 * Canonicalizes the raw payload's compile-relevant aliases (CC2 single seam).
 * Output shape and per-key precedence are identical to the former inline
 * `fwd` closure: snake-first for table_layout_mode/chapters_toc-style keys,
 * camel-first for their mirrors; undefined entries are dropped.
 * @param {object} payload
 * @returns {object}
 */
export function resolveCompileOptions(payload = {}) {
  const fwd = {
    table_layout_mode: passthroughKey(payload, 'table_layout_mode', 'tableLayoutMode', 'table_layout', 'tableLayout'),
    tableLayoutMode: passthroughKey(payload, 'tableLayoutMode', 'table_layout_mode', 'tableLayout', 'table_layout'),
    table_rotation_direction: passthroughKey(payload, 'table_rotation_direction', 'tableRotationDirection'),
    tableRotationDirection: passthroughKey(payload, 'tableRotationDirection', 'table_rotation_direction'),
    chapters_toc: passthroughKey(payload, 'chapters_toc', 'chaptersToc'),
    chaptersToc: passthroughKey(payload, 'chaptersToc', 'chapters_toc'),
    toc_title: passthroughKey(payload, 'toc_title', 'tocTitle', 'tocTitleInput'),
    toc_include_headings: passthroughKey(payload, 'toc_include_headings', 'tocIncludeHeadings'),
    doc_title: passthroughKey(payload, 'doc_title', 'document_title'),
    docTitle: passthroughKey(payload, 'docTitle', 'doc_title', 'document_title'),
    doc_subtitle: passthroughKey(payload, 'doc_subtitle', 'document_subtitle'),
    docSubtitle: passthroughKey(payload, 'docSubtitle', 'doc_subtitle', 'document_subtitle'),
    image_captions_enabled: passthroughKey(payload, 'image_captions_enabled', 'imageCaptionsEnabled'),
    imageCaptionsEnabled: passthroughKey(payload, 'imageCaptionsEnabled', 'image_captions_enabled'),
    balance_columns: passthroughKey(payload, 'balance_columns', 'balanceColumns'),
    clean_spans: passthroughKey(payload, 'clean_spans', 'cleanSpans'),
    split_list_items: passthroughKey(payload, 'split_list_items', 'splitListItems'),
    flush_columns: passthroughKey(payload, 'flush_columns', 'flushColumns'),
    split_equations: passthroughKey(payload, 'split_equations', 'splitEquations'),
    geometry: passthroughKey(payload, 'geometry'),
  };
  for (const k of Object.keys(fwd)) {
    if (fwd[k] === undefined) delete fwd[k];
  }
  return fwd;
}

export class PdfEngine {
  constructor(options = {}) {
    this.options = options;
    this.events = options.eventBus || createEngineEventBus();
    // Lazy engine singletons (CC2): the pdfkit hot path never touches the
    // coarse table/math/chrome engines, so constructing them eagerly was pure
    // waste. Getters build on first access; setters preserve the old
    // assignable-field API (e.g. stubbing imageResolver in tests).
    this._engines = {};
    this._drivers = new Map([
      ['typst', { name: 'typst', emit: emitTypst }],
      ['pdfkit', { name: 'pdfkit', emit: emitPdfkit }],
    ]);
  }

  get tableEngine() { return this._engines.table ??= new ModularTableEngine(this.options); }
  set tableEngine(v) { this._engines.table = v; }
  get mathEngine() { return this._engines.math ??= new ModularMathEngine(this.options); }
  set mathEngine(v) { this._engines.math = v; }
  get imageResolver() { return this._engines.images ??= new ModularImageResolver(this.options); }
  set imageResolver(v) { this._engines.images = v; }
  get chromeEngine() { return this._engines.chrome ??= new ModularChromeEngine(this.options); }
  set chromeEngine(v) { this._engines.chrome = v; }
  get galleyEngine() { return this._engines.galley ??= new GalleyEngine(this.options); }
  set galleyEngine(v) { this._engines.galley = v; }

  /**
   * Registers a custom driver.
   * @param {string} name 
   * @param {object} driver 
   */
  registerDriver(name, driver) {
    if (!isDriver(driver)) {
      throw new TypeError(`Driver "${name}" does not implement Driver interface`);
    }
    this._drivers.set(name, driver);
  }

  /**
   * Converts a markdown payload or DocumentIR into the target driver output.
   * @param {object} payload 
   * @param {object} [options={}] 
   * @returns {Promise<any>|any}
   */
  async convertDocument(payload, options = {}) {
    const startTime = Date.now();
    this.events.emit('pipeline:start', { payload, options });

    // 1. Ingestion & Normalization
    const docIR = normalizeToDocIR(payload);
    const validation = validateDocIR(docIR);
    if (!validation.ok) {
      const err = new Error(`Invalid DocumentIR: ${validation.errors.join('; ')}`);
      this.events.emit('error', err);
      throw err;
    }
    this.events.emit('ingest:complete', { docIR });

    // 2. Template Resolution + 3. Layout Planning (A1: skipped for the
    // pdfkit driver — GeometryCompiler re-parses block.markdown from
    // scratch and never consumes templateRender/layoutTree/layoutPlan,
    // so computing them here is 100% dead work on the hot path).
    // Typst and custom drivers still get the full coarse pipeline.
    const driverNameEarly = options.driver || this.options.defaultDriver || 'typst';
    const needsCoarse = driverNameEarly !== 'pdfkit';
    const templateName = options.template || docIR.template || 'base';
    const templateRender = needsCoarse ? renderWithTemplate(docIR, templateName) : null;
    this.events.emit('template:resolved', { template: templateName, templateRender, ...(needsCoarse ? {} : { skipped: true }) });

    // 3. Layout Planning (Measure & Galley Allocation)
    // Fase 3b: calibration opt-in via options (default estimado = identical).
    // No shaper fallback here: real mode without a measurer falls back to
    // estimado inside calibrateHeight, keeping the hot path byte-identical.
    const layoutTree = needsCoarse ? measure(docIR.blocks, resolveCalOpts(options)) : [];
    const layoutPlan = needsCoarse
      ? this.galleyEngine.planColumns(layoutTree, {
        availableHeight: options.availableHeight || 700,
        balance: docIR.blocks.some(b => b.flags?.balance_columns === true),
      })
      : null;
    this.events.emit('layout:complete', { layoutTree, layoutPlan, ...(needsCoarse ? {} : { skipped: true }) });

    // 4. Pre-resolve Image Assets (deduped, capped concurrency; failures
    // fall back to the compiler placeholder — same contract as before).
    const imageMap = options.images instanceof Map
      ? options.images
      : new Map(Object.entries(options.images || {}));

    await this.resolveBlockImages(docIR.blocks, imageMap);

    // 5. Driver Emission (driver name resolved in step 2 for the A1
    // coarse-pass skip; reused here so behavior is identical).
    const driverName = driverNameEarly;
    const driver = this._drivers.get(driverName);
    if (!driver) {
      throw new Error(`Unknown driver: ${driverName} (available: ${Array.from(this._drivers.keys()).join(', ')})`);
    }

    this.events.emit('driver:emit:start', { driver: driverName, boxCount: layoutTree.length });
    // State-sync seam: normalizeToDocIR() drops several frontend controls
    // (TOC intent, captions, column-balance, …). Forward the raw payload's
    // compile-relevant aliases so GeometryCompiler.compile() sees the same
    // options the author selected. Defaults preserve current behavior when
    // callers omit them (all reads below are opt-out `!== false` / falsy).
    // Canonicalized once in resolveCompileOptions() (CC2) instead of an
    // inline closure, so the alias precedence is unit-testable.
    const output = await driver.emit(layoutTree, { ...options, ...resolveCompileOptions(payload), docIR, templateRender, images: imageMap });
    
    const durationMs = Date.now() - startTime;
    this.events.emit('pipeline:complete', { driver: driverName, durationMs });

    return output;
  }

  /**
   * Pre-resolves block image sources into `imageMap` (CC2).
   * Deduped + capped concurrency; results are committed in first-occurrence
   * order so map insertion order is deterministic. Resolution failures and
   * null buffers are skipped (compiler placeholder path, as before).
   * Sources already present in `imageMap` (caller-provided) are never
   * re-resolved.
   * @param {Array} blocks DocumentIR blocks
   * @param {Map} imageMap target map src -> Buffer
   * @param {object} [opts] `{ concurrency }`
   */
  async resolveBlockImages(blocks, imageMap, opts = {}) {
    const concurrency = opts.concurrency ?? IMAGE_PRE_RESOLVE_CONCURRENCY;
    const pending = collectImageSources(blocks).filter((src) => !imageMap.has(src));
    const results = new Array(pending.length);
    let next = 0;
    const workers = Array.from(
      { length: Math.min(Math.max(1, concurrency), pending.length) },
      async () => {
        while (next < pending.length) {
          const i = next++;
          try {
            results[i] = await this.imageResolver.resolve(pending[i]);
          } catch {
            results[i] = null;
          }
        }
      },
    );
    await Promise.all(workers);
    pending.forEach((src, i) => {
      if (results[i]) imageMap.set(src, results[i]);
    });
    return imageMap;
  }

  /**
   * Fast-path pagination estimator for preview and TOC index calculation.
   * @param {object} payload 
   * @param {object} [options={}] 
   * @returns {{ totalPages: number, sections: object[], durationMs: number }}
   */
  calculatePagination(payload, options = {}) {
    const startTime = Date.now();
    const docIR = normalizeToDocIR(payload);
    const layoutTree = measure(docIR.blocks);

    const availableHeight = options.availableHeight || 700;
    let totalHeight = 0;
    for (const box of layoutTree) {
      totalHeight += box.heightPt || box.height || 0;
    }

    // 2 columns per page
    const pageCapacity = availableHeight * 2;
    const estimatedPages = Math.max(1, Math.ceil(totalHeight / pageCapacity));

    const sections = docIR.blocks.map((b, idx) => ({
      index: idx,
      title: b.title,
      estimatedHeight: (b.markdown || '').length * 0.4,
    }));

    return {
      totalPages: estimatedPages,
      sections,
      // Honest PaginationParityBridge flag (CC2): coarse heights + char-count
      // section estimates, NOT compiler pagination. Mirrored in the worker's
      // inlined copy (src/_worker.js). Consumers must not treat this as exact.
      estimated: true,
      metrics: {
        totalHeight,
        availableHeight,
        boxCount: layoutTree.length,
      },
      durationMs: Date.now() - startTime,
    };
  }
}

// Global default engine singleton
const defaultEngine = new PdfEngine();

/**
 * Clean entrypoint for document conversion.
 * @param {object} payload 
 * @param {object} [options={}] 
 * @returns {Promise<any>|any}
 */
export function convertDocument(payload, options = {}) {
  return defaultEngine.convertDocument(payload, options);
}

/**
 * Clean entrypoint for fast-path pagination calculation.
 * @param {object} payload 
 * @param {object} [options={}] 
 * @returns {object}
 */
export function calculatePagination(payload, options = {}) {
  return defaultEngine.calculatePagination(payload, options);
}

export function createEngine(options) {
  return new PdfEngine(options);
}

// Re-exports for modular consumption
export {
  EngineEventBus,
  createEngineEventBus,
  validateDocIR,
  normalizeToDocIR,
  assertLayoutBox,
  GalleyEngine,
  ModularTableEngine,
  ModularMathEngine,
  ModularImageResolver,
  ModularChromeEngine,
  renderChaptersTOC,
  TEMPLATES,
  FontMetrics,
};

export default defaultEngine;


// Master Orchestration Specification v2.0 (Template-Aware Edition) exports
export {
  UNIT_TO_PX,
  PAPER_PRESETS_MM,
  DEFAULT_GUARDRAILS_CONFIG,
  EditorialGeometryEngine,
  normalizeEditorialGeometry,
  verifyTemplateEditorialGeometry,
} from './static/editorial-geometry-engine.js';
