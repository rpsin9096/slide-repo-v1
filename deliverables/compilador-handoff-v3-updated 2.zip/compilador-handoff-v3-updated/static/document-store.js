/* DOE Formatter — DocumentStore (Workspace & Editor Store domain).
 *
 * Canonical single-source-of-truth for workspace state: boxes + globals, one
 * versioned storage key. Zero DOM reads at import time; safe to import from
 * node (lean tests) and the browser bundle alike.
 *
 * Moved verbatim from static/v2-app.js (CC1 step 1); v2-app.js re-imports and
 * re-exports the test seam. Doh: same markdown-normalization helpers
 * (TagSanitizer/BulletNormalizer port) live here so both adapters share them.
 */

export const STORAGE_KEY = 'doe-v2-new-v1';

/** Schema version of the persisted `{ v, boxes, globals }` envelope. */
export const STORAGE_VERSION = 2;

export const uid = () => `b_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;

/* ------------------------------------------------------------------ */
/* EditorText: editor-bound normalization (ported from the canonical
 * markdown-pipeline.js TagSanitizer/BulletNormalizer; server pipeline
 * untouched). Idempotent: normalize(normalize(x)) === normalize(x).
 * Deliberately NOT typographic autofix: Milkdown owns formatting, and
 * autofix rewrites URL-unsafe sequences (proven: `img_1…` → `img₁…`). */
/* ------------------------------------------------------------------ */
const GROUNDING_TAG_PATTERNS = [
  /\[span_\d+\]/g,
  /\(start_span\)/g,
  /\(end_span\)/g,
  /\[cite_?[^\]]*\]/g,
];
export function stripGroundingTags(text) {
  if (!text) return '';
  let cleaned = text;
  for (const pattern of GROUNDING_TAG_PATTERNS) {
    cleaned = cleaned.replace(pattern, '');
  }
  return cleaned;
}
export function normalizeBullets(md) {
  if (!md) return '';
  const lines = md.split('\n');
  const out = [];
  for (const rawLine of lines) {
    // Image lines are canonical (`![alt](src)`): never touch — preserves
    // figure references byte-identical across Rich↔Markdown toggles.
    if (/^!\[/.test(rawLine.trimStart())) { out.push(rawLine); continue; }
    const indentMatch = rawLine.match(/^([\s\u200B]*)/);
    const rawIndent = indentMatch ? indentMatch[1] : '';
    const indent = rawIndent.replace(/\t/g, '  ').replace(/[\u200B]/g, '  ');
    let content = rawLine.slice(rawIndent.length);
    // Collapse redundant composite markers ("- • ", "• • ", "• 1. ") —
    // second marker must also be followed by whitespace so "**bold**" survives.
    while (/^[•◦○●–—*+-]\s+(?=[•◦○●–—*+-]\s+|\d+[.)]\s+)/.test(content)) {
      content = content.replace(/^[•◦○●–—*+-]\s+/, '');
    }
    const m = content.match(/^([•◦○●–—*+]|\d+[.)])\s+(.*)$/);
    if (m) {
      if (/^\d+[.)]/.test(m[1])) out.push(`${indent}${m[1]} ${m[2]}`);
      else out.push(`${indent}- ${m[2]}`);
    } else if (/^-\s+(.*)$/.test(content)) {
      out.push(`${indent}${content}`);
    } else if (content) {
      out.push(`${indent}${content}`);
    } else {
      out.push('');
    }
  }
  return out.join('\n');
}
export function normalizeForEditor(md) {
  return normalizeBullets(stripGroundingTags(String(md || '').replace(/\r\n?/g, '\n')));
}

/* ------------------------------------------------------------------ */
/* DocumentStore: sole writer. No DOM reads; UI renders FROM the store */
/* ------------------------------------------------------------------ */
export const DEFAULT_GLOBALS = Object.freeze({
  template: 'base',
  lang: 'auto',
  headerCustomEnabled: false,
  headerText: '',
  headerPosition: 'top',
  headerDateEnabled: true,
  dateFormat: 'dd_mm_yyyy',
  dateCustom: '',
  docTitlesEnabled: false,
  docTitle: '',
  docSubtitle: '',
  chaptersToc: false,
  tocTitle: '',
  tocHeadings: true,
  columnLayout: '2',
  tableLayoutMode: 'auto',
  tableRotationDirection: 'cw',
  alignment: 'justify',
  flushColumns: true,
  balanceColumns: false,
  splitListItems: true,
  imageCaptions: true,
  geometry: 'v3',
});

export function normalizeBox(raw, idx = 0) {
  return {
    id: raw.id || uid(),
    title: raw.title ?? raw.name ?? `Bloco ${idx + 1}`,
    markdown: raw.markdown ?? raw.content ?? '',
    mode: raw.mode === 'rich' ? 'rich' : 'markdown',
    ce: !!raw.ce,
    preview: !!raw.preview,
    collapsed: !!raw.collapsed,
    ignored: !!raw.ignored,
    configOpen: raw.configOpen ?? false,
    kind: raw.kind === 'table' ? 'table' : (raw.kind === 'text' ? 'text' : (/^\s*\|.*\|/m.test(raw.markdown ?? raw.content ?? '') ? 'table' : 'text')),
    masthead: {
      enabled: raw.masthead?.enabled ?? raw.enable_masthead ?? false,
      prefix: raw.masthead?.prefix ?? raw.masthead_prefix ?? '',
      course: raw.masthead?.course ?? raw.masthead_course ?? '',
      topic: raw.masthead?.topic ?? raw.masthead_topic ?? '',
      header: raw.masthead?.header ?? raw.masthead_header ?? false,
    },
    flags: {
      autofix: raw.flags?.autofix ?? raw.autofix ?? true,
      optimize_tables: raw.flags?.optimize_tables ?? raw.optimize_tables ?? true,
      split_equations: raw.flags?.split_equations ?? raw.split_equations ?? true,
    },
    tableLayout: raw.tableLayout ?? raw.table_layout ?? '', // '' = inherit
    tableRotationDirection: raw.tableRotationDirection ?? raw.table_rotation_direction ?? 'cw',
    columns: raw.columns ?? raw.column_layout ?? raw.columnLayout ?? '', // '' = inherit
    insertOpen: raw.insertOpen ?? true, // markdown "Inserir" bar expanded
  };
}

export function migrateGlobals(globals) {
  const migrated = { ...globals };
  // balanceColumns is a dedicated opt-in toggle (default false = coluna
  // corrida). Editorial flush is its own control ("Encaixar pé da página",
  // default on): adopt the explicit legacy value whichever key carried it —
  // flushColumns/flush_columns, then the old editorialLayout umbrella — before
  // deleting every ghost so no false name survives the migration.
  const legacyBalance = migrated.balanceColumns ?? migrated.balance_columns;
  delete migrated.balance_columns;
  if (legacyBalance !== undefined) migrated.balanceColumns = legacyBalance === true;
  const legacyFlush = migrated.flushColumns ?? migrated.flush_columns ?? migrated.editorialLayout;
  if (legacyFlush !== undefined) migrated.flushColumns = legacyFlush !== false;
  delete migrated.editorialLayout; delete migrated.flush_columns;
  delete migrated.looseLineGuard; delete migrated.loose_line_guard;
  delete migrated.cleanSpans; delete migrated.clean_spans;
  return { ...DEFAULT_GLOBALS, ...migrated };
}

export class DocumentStore {
  constructor() {
    this.boxes = [];
    this.globals = { ...DEFAULT_GLOBALS };
    this.subs = new Set();
    this.load();
    if (this.boxes.length === 0) {
      this.boxes = [normalizeBox({ title: 'Bloco 1', markdown: '# Título\n\nEscreva em Markdown…\n' }, 0)];
    }
  }
  subscribe(fn) { this.subs.add(fn); return () => this.subs.delete(fn); }
  emit(evt, data) { for (const fn of this.subs) { try { fn(evt, data); } catch (e) { console.error(e); } } }
  getBoxes() { return this.boxes; }
  getGlobals() { return this.globals; }
  setGlobal(key, value) { this.globals[key] = value; this.save(); this.emit('global', { key, value }); }
  addBox(afterIdx = this.boxes.length - 1, seed = {}) {
    const box = normalizeBox({ title: `Bloco ${this.boxes.length + 1}`, markdown: '', ...seed }, this.boxes.length);
    this.boxes.splice(afterIdx + 1, 0, box);
    this.save(); this.emit('boxes', { structural: true });
    return box;
  }
  splitBoxAtHeader(id, title, beforeMd, afterMd) {
    const idx = this.boxes.findIndex((x) => x.id === id);
    if (idx < 0) return null;
    const cur = this.boxes[idx];
    cur.markdown = beforeMd || '';
    const seeded = normalizeBox({
      title: title || `Bloco ${this.boxes.length + 1}`,
      markdown: afterMd || '',
      mode: cur.mode, ce: cur.ce, preview: cur.preview,
      masthead: { ...cur.masthead }, flags: { ...cur.flags },
      kind: /^\s*\|.*\|/m.test(afterMd || '') ? 'table' : 'text',
    }, this.boxes.length);
    this.boxes.splice(idx + 1, 0, seeded);
    this.save(); this.emit('boxes', { structural: true });
    return seeded;
  }
  updateBox(id, patch) {
    const b = this.boxes.find((x) => x.id === id);
    if (!b) return;
    Object.assign(b, patch);
    this.save(); this.emit('boxes', { id, structural: false });
  }
  updateBoxDeep(id, path, value) {
    const b = this.boxes.find((x) => x.id === id);
    if (!b) return;
    const [head, tail] = path;
    if (tail) b[head][tail] = value; else b[head] = value;
    this.save(); this.emit('boxes', { id, structural: false });
  }
  removeBox(id) {
    this.boxes = this.boxes.filter((x) => x.id !== id);
    if (this.boxes.length === 0) this.boxes = [normalizeBox({ title: 'Bloco 1', markdown: '' }, 0)];
    this.save(); this.emit('boxes', { structural: true });
  }
  moveBox(id, dir) {
    const i = this.boxes.findIndex((x) => x.id === id);
    const j = i + dir;
    if (i < 0 || j < 0 || j >= this.boxes.length) return;
    [this.boxes[i], this.boxes[j]] = [this.boxes[j], this.boxes[i]];
    this.save(); this.emit('boxes', { structural: true });
  }
  moveBoxTo(id, toIdx) {
    const from = this.boxes.findIndex((x) => x.id === id);
    if (from < 0) return;
    const clamped = Math.max(0, Math.min(toIdx, this.boxes.length - 1));
    if (clamped === from) return;
    const [b] = this.boxes.splice(from, 1);
    this.boxes.splice(clamped, 0, b);
    this.save(); this.emit('boxes', { structural: true });
  }
  save() {
    try {
      if (typeof localStorage === 'undefined') return;
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ v: STORAGE_VERSION, boxes: this.boxes, globals: this.globals }));
    }
    catch (e) { console.warn('persist failed', e); }
  }
  load() {
    try {
      if (typeof localStorage === 'undefined') return;
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed.boxes)) this.boxes = parsed.boxes.map((b, i) => normalizeBox(b, i));
      else if (Array.isArray(parsed)) this.boxes = parsed.map((b, i) => normalizeBox(b, i)); // legacy shape
      // One-time reset: the old Rich-entry force-open wrote configOpen:true
      // into stored boxes, so Opções loads expanded even though the default
      // is collapsed. Clear it once for pre-v2 payloads; explicit user
      // toggles after this persist normally.
      if (parsed.v === undefined || parsed.v < 2) {
        for (const b of this.boxes) b.configOpen = false;
      }
      if (parsed.globals && typeof parsed.globals === 'object') {
        this.globals = migrateGlobals(parsed.globals);
      }
      if (parsed.v !== undefined && parsed.v !== STORAGE_VERSION) {
        console.warn(`workspace storage v${parsed.v} != v${STORAGE_VERSION}; loaded known fields`);
      }
    } catch (e) { console.warn('restore failed', e); }
  }
}
