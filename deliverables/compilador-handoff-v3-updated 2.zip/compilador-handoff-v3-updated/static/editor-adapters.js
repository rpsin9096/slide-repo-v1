/* DOE Formatter — EditorAdapter seam (Workspace & Editor Store domain).
 *
 * Uniform read/write/mode-switch/highlight contract over the two editor
 * implementations: TextareaAdapter (plain Markdown <textarea>) and
 * BlockEditor from ./editor-core.js (Rich block cards). WorkspaceController
 * code must program to this interface, never to editor DOM.
 *
 * Moved verbatim from static/v2-app.js (CC1 step 2); v2-app.js re-imports.
 * Import-time side-effect free; DOM is touched only inside methods.
 */

import {
  applyRichCommand, detectRichState, canExecCommand,
  pushUndo, popUndo, hidePortalToolbars, closePortalMenus,
} from './editor-core.js';

/* ------------------------------------------------------------------ */
/* EditorAdapter interface (duck-typed; see isEditorAdapter below):     */
/*   getContent() -> string                                            */
/*   setContent(markdown: string) -> Promise<void>                     */
/*   insertText(text: string) -> void                                  */
/*   canExec(format) -> bool — RichCommandInterface parity             */
/*   getCommandState(format) -> bool                                   */
/*   execCommand(format) -> bool                                       */
/*   undo() / redo() -> bool                                           */
/*   canUndo() / canRedo() -> bool — stack availability for button states */
/*   highlight(start: number, end: number) -> void                     */
/*   checkpoint() -> void — push explicit undo boundary               */
/*   destroy() -> void — dismiss portals, release listeners           */
/* ------------------------------------------------------------------ */

const ADAPTER_METHODS = [
  'getContent', 'setContent', 'insertText',
  'canExec', 'getCommandState', 'execCommand',
  'undo', 'redo', 'canUndo', 'canRedo',
  'highlight', 'checkpoint', 'destroy',
];

/** Structural guard: true when `obj` implements the EditorAdapter contract. */
export function isEditorAdapter(obj) {
  if (!obj || (typeof obj !== 'object' && typeof obj !== 'function')) return false;
  return ADAPTER_METHODS.every((m) => typeof obj[m] === 'function');
}

export class TextareaAdapter {
  constructor(el) { this.el = el; this._undo = []; this._redo = []; }
  getContent() { return this.el.value; }
  async setContent(md) { this.el.value = md ?? ''; this._undo = []; this._redo = []; }
  checkpoint() {
    this._undo = pushUndo(this._undo, this.el.value);
    this._redo = [];
  }
  insertText(text) {
    const { selectionStart: s = 0, selectionEnd: e = 0 } = this.el;
    const v = this.el.value;
    this._undo = pushUndo(this._undo, v);
    this._redo = [];
    this.el.value = `${v.slice(0, s)}${text}${v.slice(e)}`;
    const pos = s + text.length;
    this.el.setSelectionRange(pos, pos);
    this.el.focus();
  }
  /* RichCommandInterface parity: same pure seam as BlockEditor. */
  canExec(fmt) { return canExecCommand(fmt); }
  getCommandState(fmt) {
    if (!canExecCommand(fmt)) return false;
    try {
      return detectRichState(this.el.value, this.el.selectionStart, this.el.selectionEnd, fmt);
    } catch { return false; }
  }
  execCommand(fmt) {
    if (!canExecCommand(fmt)) return false;
    const v = this.el.value;
    const s = this.el.selectionStart ?? v.length;
    const e = this.el.selectionEnd ?? v.length;
    const res = applyRichCommand(v, s, e, fmt);
    if (res.text === v) return true;
    this._undo = pushUndo(this._undo, v);
    this._redo = [];
    this.el.value = res.text;
    try { this.el.setSelectionRange(res.caretStart, res.caretEnd); } catch { /* noop */ }
    this.el.focus();
    this.el.dispatchEvent(new Event('input', { bubbles: true }));
    return true;
  }
  undo() {
    const { snapshot, rest } = popUndo(this._undo);
    if (snapshot === null) return false;
    this._redo = pushUndo(this._redo, this.el.value);
    this._undo = rest;
    this.el.value = snapshot;
    this.el.dispatchEvent(new Event('input', { bubbles: true }));
    return true;
  }
  redo() {
    const { snapshot, rest } = popUndo(this._redo);
    if (snapshot === null) return false;
    this._undo = pushUndo(this._undo, this.el.value);
    this._redo = rest;
    this.el.value = snapshot;
    this.el.dispatchEvent(new Event('input', { bubbles: true }));
    return true;
  }
  canUndo() { return this._undo.length > 0; }
  canRedo() { return this._redo.length > 0; }
  highlight(start, end) {
    this.el.focus();
    this.el.setSelectionRange(start, end);
    // Follow selection: ensure match is visible inside 340px shell.
    try { this.el.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch { /* ignore */ }
    // Scroll textarea to match line.
    try {
      const before = this.el.value.slice(0, start).split('\n').length;
      const lineH = 21;
      this.el.scrollTop = Math.max(0, before * lineH - this.el.clientHeight / 2);
    } catch { /* ignore */ }
  }
  destroy() {
    try {
      if (typeof document !== 'undefined') {
        hidePortalToolbars();
        closePortalMenus();
      }
    } catch { /* cosmetic */ }
  }
}
