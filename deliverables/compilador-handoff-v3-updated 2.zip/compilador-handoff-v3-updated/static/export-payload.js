/* DOE Formatter — ExportPayloadBuilder (Workspace & Editor Store domain).
 *
 * Pure utility: aggregates DocumentStore state into the normalized JSON
 * payload expected by `/api/convert` and preview endpoints. Duck-types its
 * store argument (`getBoxes()` / `getGlobals()`) so it never imports the
 * store module — no import cycle, trivially testable in node.
 *
 * Moved verbatim from static/v2-app.js (CC1 step 1); engine stays locked.
 */

/** Server engine id this frontend targets. */
export const ENGINE = 'v2-modular';

export class ExportPayloadBuilder {
  static build(store, overrides = {}) {
    const boxes = store.getBoxes();
    const g = store.getGlobals();
    const sections = boxes
      .filter((b) => !b.ignored && (b.markdown || '').trim().length > 0)
      .map((b, idx) => ({
        index: idx + 1,
        id: b.id,
        name: b.title || `Seção ${idx + 1}`,
        title: b.title || '',
        markdown: b.markdown,
        autofix: b.flags.autofix !== false,
        optimize_tables: b.flags.optimize_tables !== false,
        split_equations: b.flags.split_equations !== false,
        enable_masthead: b.masthead.enabled === true,
        masthead_header: b.masthead.header === true,
        masthead_prefix: b.masthead.prefix || '',
        masthead_course: b.masthead.course || '',
        masthead_topic: b.masthead.topic || '',
        masthead: { enabled: b.masthead.enabled === true, prefix: b.masthead.prefix || '', course: b.masthead.course || '', topic: b.masthead.topic || '', header: b.masthead.header === true },
        table_layout: b.tableLayout || null,
        tableLayout: b.tableLayout || null,
        table_rotation_direction: b.tableRotationDirection || (b.tableLayout === 'rotated_ccw' ? 'ccw' : 'cw'),
        tableRotationDirection: b.tableRotationDirection || (b.tableLayout === 'rotated_ccw' ? 'ccw' : 'cw'),
        columns: b.columns === '' || b.columns == null ? null : Number(b.columns),
        column_layout: b.columns === '' || b.columns == null ? null : Number(b.columns),
      }));
    const headerPosition = g.headerPosition || 'top';
    const firstBox = boxes.find((b) => !b.ignored && ((b.title || '').trim() || (b.markdown || '').trim())) || boxes[0];
    const firstMh = firstBox?.masthead;
    const isFirstMhOn = firstBox && (firstMh?.enabled === true || firstBox.enable_masthead === true || firstBox.masthead_enabled === true);
    const adaptedDocTitle = (isFirstMhOn && (firstMh?.course || firstMh?.topic)) ? (firstMh.course || firstMh.topic).trim() : '';
    const adaptedDocSubtitle = (isFirstMhOn && firstMh?.course && firstMh?.topic) ? firstMh.topic.trim() : '';

    const docTitlesActive = !!(g.chaptersToc && g.docTitlesEnabled);
    let resolvedDocTitle = docTitlesActive ? (g.docTitle || '').trim() : '';
    let resolvedDocSub = docTitlesActive ? (g.docSubtitle || '').trim() : '';
    if (!resolvedDocTitle && adaptedDocTitle) {
      resolvedDocTitle = adaptedDocTitle;
      if (!resolvedDocSub && adaptedDocSubtitle && adaptedDocSubtitle !== resolvedDocTitle) {
        resolvedDocSub = adaptedDocSubtitle;
      }
    }

    return {
      template: g.template || 'base',
      engine: ENGINE,
      lang: g.lang === 'auto' ? undefined : g.lang,
      title: resolvedDocTitle || adaptedDocTitle || 'Document',
      header_text: g.headerCustomEnabled ? (g.headerText || '') : '',
      header_position: headerPosition,
      show_header_top: headerPosition === 'top',
      header_date: { enabled: !!g.headerDateEnabled, format: g.dateFormat, custom_value: g.dateCustom || null },
      clean_spans: true,
      alignment: g.alignment || 'justify',
      raggedright: (g.alignment || 'justify') === 'left',
      loose_line_guard: true,
      balance_columns: g.balanceColumns === true,
      split_list_items: !!g.splitListItems,
      flush_columns: g.flushColumns !== false,
      doc_title: resolvedDocTitle,
      doc_subtitle: resolvedDocSub,
      chapters_toc: !!g.chaptersToc,
      chaptersToc: !!g.chaptersToc,
      toc_title: (g.tocTitle && g.tocTitle.trim()) ? g.tocTitle.trim() : 'SUMÁRIO',
      tocTitle: (g.tocTitle && g.tocTitle.trim()) ? g.tocTitle.trim() : 'SUMÁRIO',
      toc_include_headings: g.tocHeadings !== false,
      tocIncludeHeadings: g.tocHeadings !== false,
      table_layout_mode: g.tableLayoutMode || 'auto',
      tableLayoutMode: g.tableLayoutMode || 'auto',
      table_rotation_direction: g.tableRotationDirection || (g.tableLayoutMode === 'rotated_ccw' ? 'ccw' : 'cw'),
      tableRotationDirection: g.tableRotationDirection || (g.tableLayoutMode === 'rotated_ccw' ? 'ccw' : 'cw'),
      column_layout: Number(g.columnLayout || 2),
      columns: Number(g.columnLayout || 2),
      image_captions_enabled: !!g.imageCaptions,
      geometry: overrides.geometry || g.geometry || 'v3',
      sections,
      ...overrides, // preview / preview_full win here; engine stays locked below
      engine: ENGINE,
    };
  }
}
