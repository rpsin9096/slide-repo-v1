/* DOE Formatter — Block Editor Core (custom rich editor, zero dependencies).
 * Zero dependencies, zero CDN fetches. The AST-canonical Rich view:
 * markdown is the single source of truth; cards render from it and every
 * edit writes canonical markdown back. Mode toggles never parse editor DOM.
 *
 * Pure helpers (DOM-free, node-testable): clampFigureScale,
 * parseFigureLine, serializeFigureLine, splitBlocks, serializeBlocks,
 * ceApplyInline, applyRichCommand, detectRichState, pushUndo, popUndo.
 * DOM: BlockStore (block model over one markdown string) + BlockEditor
 * (card renderer implementing the EditorAdapter seam:
 * mount/setContent/getContent/insertText/destroy/highlight/execCommand/
 * canExec/getCommandState/undo/redo).
 */

export const FIGURE_WIDTH_MIN = 0.05;
export const FIGURE_WIDTH_MAX = 1;
export const FIGURE_RATIO_DEFAULT = 1.5;
export const FIGURE_PLACEMENTS = ['column', 'full-width'];

/* Phase 3 (gated) contentEditable helpers: pure, node-testable.
 * ceShouldSync blocks store writes while IME composes; caret helpers
 * clamp plain-text offsets across styled re-renders; ceFigureCommand
 * is the atomic-island focus protocol (Enter in, Esc out). */
export function ceShouldSync(isComposing, inputType) {
  return !isComposing && inputType !== 'insertCompositionText';
}
export function ceSaveCaret(plainLen, anchorOffset) {
  const len = Math.max(0, Number(plainLen) || 0);
  return Math.max(0, Math.min(len, Number(anchorOffset) || 0));
}
export function ceRestoreCaret(plainLen, saved) {
  const len = Math.max(0, Number(plainLen) || 0);
  return Math.max(0, Math.min(len, Number(saved) || 0));
}
export function ceFigureCommand(key, insideIsland) {
  if (key === 'Enter' && !insideIsland) return 'enter-island';
  if (key === 'Escape' && insideIsland) return 'exit-island';
  return 'stay';
}
/* Layout-robust digit for shortcuts: with Shift held, `e.key` yields the
 * shifted symbol (`&`, `*`), so prefer physical `e.code` (Digit7/Digit8). */
export function digitOf(e) {
  try {
    const code = e && e.code;
    if (typeof code === 'string' && /^Digit\d$/.test(code)) return code.slice(5);
  } catch { /* fall through */ }
  return (e && e.key) || '';
}
/* Pure inline-format toggler (state-aware): detects surrounding markers and
 * unwraps (toggle-off) instead of nesting. `**text**` + bold -> `text`.
 * Returns updated text + caret. Node-testable. */
export function mdInlineMarkers(fmt) {
  if (fmt === 'bold') return ['**', '**'];
  if (fmt === 'italic') return ['*', '*'];
  if (fmt === 'code') return ['`', '`'];
  if (fmt === 'strike') return ['~~', '~~'];
  return null;
}
export function ceApplyInline(plain, start, end, fmt) {
  const t = String(plain ?? '');
  const s = Math.max(0, Math.min(t.length, Number(start) || 0));
  const e = Math.max(0, Math.min(t.length, Number(end) || 0));
  const a = Math.min(s, e);
  const b = Math.max(s, e);
  const sel = t.slice(a, b);
  if (fmt === 'link') {
    const m = sel.match(/^\[(.+)\]\((.+)\)$/);
    if (m) {
      const text = t.slice(0, a) + m[1] + t.slice(b);
      return { text, caretStart: a, caretEnd: a + m[1].length };
    }
    const wrapped = `[${sel}](https://)`;
    const text = t.slice(0, a) + wrapped + t.slice(b);
    const urlStart = a + 1 + sel.length + 2;
    return { text, caretStart: urlStart, caretEnd: urlStart + 8 };
  }
  const m = mdInlineMarkers(fmt);
  if (!m) return { text: t, caretStart: a, caretEnd: b };
  const [before, after] = m;
  // Toggle-off: selection already exactly wrapped -> unwrap.
  // Italic guard: `*` must not match the first/last star of a `**` pair.
  const exactWrapped = sel.length >= before.length + after.length
    && sel.startsWith(before) && sel.endsWith(after)
    && !(before === '*' && (sel.startsWith('**') || sel.endsWith('**')));
  if (exactWrapped) {
    const inner = sel.slice(before.length, sel.length - after.length);
    const text = t.slice(0, a) + inner + t.slice(b);
    return { text, caretStart: a, caretEnd: a + inner.length };
  }
  // Toggle-off: markers hug the selection edges -> strip them.
  if (t.slice(a - before.length, a) === before && t.slice(b, b + after.length) === after) {
    const text = t.slice(0, a - before.length) + sel + t.slice(b + after.length);
    return { text, caretStart: a - before.length, caretEnd: a - before.length + sel.length };
  }
  const wrapped = `${before}${sel}${after}`;
  const text = t.slice(0, a) + wrapped + t.slice(b);
  const caretStart = a + wrapped.length;
  return { text, caretStart, caretEnd: caretStart };
}
/* RichCommandInterface: pure, DOM-free command layer shared by both
 * EditorAdapter implementations (BlockEditor + TextareaAdapter + test fake).
 * Single seam: toolbar / slash / shortcuts call applyRichCommand, never
 * hand-roll markers. Deletion test: remove the toolbar, editing stays correct. */
export const RICH_INLINE_COMMANDS = ['bold', 'italic', 'code', 'strike', 'link'];
export const RICH_BLOCK_COMMANDS = ['h1', 'h2', 'h3', 'h4', 'quote', 'p'];
export const RICH_LIST_COMMANDS = ['ul', 'ol'];
export const RICH_COMMANDS = [...RICH_INLINE_COMMANDS, ...RICH_BLOCK_COMMANDS, ...RICH_LIST_COMMANDS];
/* Unified Inserir catalog: single data-driven list behind every insert
 * surface (gutter, composer, rich slash, markdown slash, md insert bar).
 * Both EditorAdapters map picks onto the same seam (atCursor vs
 * handleInsertAt) — Markdown stays truth. */
export const INSERT_ITEMS = [
  { key: 'h1', sym: 'h1', label: 'Título 1', md: '# Novo Título' },
  { key: 'h2', sym: 'h1', label: 'Título 2', md: '## Novo Subtítulo' },
  { key: 'h3', sym: 'h1', label: 'Título 3', md: '### Novo Sub-subtítulo' },
  { key: 'h4', sym: 'h4', label: 'Título 4', md: '#### Novo Título 4' },
  { key: 'p', sym: 'para', label: 'Texto', md: 'Novo parágrafo de texto.' },
  { key: 'ul', sym: 'ul', label: 'Lista com marcadores', md: '- Novo item\n- Outro item' },
  { key: 'ol', sym: 'ol', label: 'Lista numerada', md: '1. Novo item\n2. Outro item' },
  { key: 'quote', sym: 'quote', label: 'Citação', md: '> Nova citação.' },
  { key: 'tbl', sym: 'table', label: 'Tabela', md: '| Coluna 1 | Coluna 2 |\n| :--- | ---: |\n| Item A | 100 |\n| Item B | 200 |' },
  { key: 'fig', sym: 'image', label: 'Imagem', md: null },
  { key: 'code', sym: 'code', label: 'Código', md: '```\ncódigo\n```' },
  { key: 'math', sym: 'math', label: 'Equação', md: '$$\\alpha^2 + \\beta^2 = \\gamma^2$$' },
  { key: 'callout', sym: 'callout', label: 'Destaque', md: '::: info Observação\nTexto em destaque informativo.\n:::' },
  { key: 'rule', sym: 'rule', label: 'Divisória', md: '---' },
];
export function insertSnippetFor(type) {
  const it = INSERT_ITEMS.find((x) => x.key === type);
  return it ? it.md : '';
}
/* Slash-nav index math: pure, node-testable. next = ArrowDown (+1, wrap),
 * prev = ArrowUp (−1, wrap); filter reset clamps back to 0; Enter picks the
 * highlighted item (falls back to first when nothing matches). */
export function slashNavIndex(key, current, count) {
  const n = Math.max(0, Number(count) || 0);
  if (n === 0) return -1;
  const cur = Number.isFinite(Number(current)) ? Number(current) : -1;
  if (key === 'ArrowDown') return (cur + 1 + n) % n;
  if (key === 'ArrowUp') return (cur - 1 + n) % n;
  if (key === 'reset') return 0;
  if (key === 'first') return 0;
  if (key === 'last' || key === 'End') return n - 1;
  return cur;
}
/* Paste-URL-over-selection (V5): pure, node-testable. When pasted text is a
 * bare http(s) URL and the selection is non-empty plain text, produce
 * `[text](url)` instead of a raw paste. Returns null when inapplicable. */
export function pasteUrlLink(plain, start, end, raw) {
  const t = String(plain ?? '');
  const s = Math.max(0, Math.min(t.length, Number(start) || 0));
  const e = Math.max(0, Math.min(t.length, Number(end) || 0));
  const a = Math.min(s, e);
  const b = Math.max(s, e);
  if (b <= a) return null;
  const url = String(raw ?? '').trim();
  if (!/^https?:\/\/\S+$/i.test(url)) return null;
  const sel = t.slice(a, b);
  if (/^\[.+\]\(.+\)$/.test(sel)) return null;
  if (/^\s*$/.test(sel) || /\n/.test(sel)) return null;
  const text = t.slice(0, a) + `[${sel}](${url})` + t.slice(b);
  return { text, caretStart: a, caretEnd: a + sel.length + url.length + 4 };
}
export function canExecCommand(fmt) {
  return RICH_COMMANDS.includes(fmt);
}
function blockPrefixFor(fmt) {
  if (fmt === 'h1') return '# ';
  if (fmt === 'h2') return '## ';
  if (fmt === 'h3') return '### ';
  if (fmt === 'h4') return '#### ';
  if (fmt === 'quote') return '> ';
  return '';
}
/* Strips a heading/quote block prefix, preserving indent. Used when
 * converting lines into list items (Notion-style: `# T` + bullets → `- T`).
 * Pure, node-testable. */
export function stripBlockPrefix(line = '') {
  const m = String(line ?? '').match(/^(\s*)(#{1,6}\s+|>+\s*)(.*)$/);
  return m ? `${m[1]}${m[3]}` : String(line ?? '');
}
/* List markers: pure, DOM-free. Unordered `- * +` (canonical `-`);
 * ordered `1.` / `1)` with numeric continuation. Indent is preserved. */
export function parseListMarker(line = '') {
  const m = String(line ?? '').match(/^(\s*)(-|\*|\+|\d+[.)])(\s+)(.*)$/);
  if (!m) return null;
  const ordered = /^\d+[.)]$/.test(m[2]);
  const num = ordered ? parseInt(m[2], 10) : null;
  return { indent: m[1], marker: m[2], ordered, num, rest: m[4] };
}
/* Multi-line list toggle (Notion-style): operates on every non-blank line
 * spanned by the range. All-target → strip (toggle off). Otherwise normalize
 * every non-blank line to the target kind (convert + add in one pass).
 * Ordered numbering continues from a directly-above ordered item. */
export function applyListCommand(plain, start, end, fmt) {
  const t = String(plain ?? '');
  const targetOrdered = fmt === 'ol';
  const s = Math.max(0, Math.min(t.length, Number(start) || 0));
  const e = Math.max(0, Math.min(t.length, Number(end) || 0));
  const a = Math.min(s, e);
  const b = Math.max(s, e);
  const firstStart = t.lastIndexOf('\n', a - 1) + 1;
  let lastEnd = t.indexOf('\n', b);
  if (lastEnd < 0) lastEnd = t.length;
  const lines = t.slice(firstStart, lastEnd).split('\n');
  const kinds = lines.map((l) => {
    if (!l.trim()) return 'blank';
    const p = parseListMarker(l);
    if (!p) return 'none';
    return p.ordered ? 'ol' : 'ul';
  });
  const live = kinds.map((k, idx) => ({ k, idx })).filter((x) => x.k !== 'blank');
  const want = targetOrdered ? 'ol' : 'ul';
  // Continuation: number after a directly-above ordered item.
  let nextNum = 1;
  if (firstStart > 0) {
    const above = t.slice(0, firstStart - 1).split('\n').pop();
    const p = parseListMarker(above || '');
    if (p && p.ordered && Number.isFinite(p.num)) nextNum = p.num + 1;
  }
  let out;
  if (live.length === 0) {
    const marker = targetOrdered ? `${nextNum}. ` : '- ';
    out = t.slice(0, firstStart) + marker + t.slice(firstStart);
    const caret = firstStart + marker.length;
    return { text: out, caretStart: caret, caretEnd: caret };
  }
  if (live.every((x) => x.k === want)) {
    out = lines.map((l, idx) => {
      if (kinds[idx] === 'blank') return l;
      const p = parseListMarker(l);
      return p ? `${p.indent}${p.rest}` : l;
    });
  } else {
    out = lines.map((l, idx) => {
      if (kinds[idx] === 'blank') return l;
      // Converting into a list strips heading/quote prefixes too
      // (`# T` → `- T`), mirroring block-command normalization.
      const deb = stripBlockPrefix(l);
      const p = parseListMarker(deb);
      const indent = p ? p.indent : (deb.match(/^\s*/) || [''])[0];
      const content = p ? p.rest : deb.trimStart();
      if (targetOrdered) return `${indent}${nextNum++}. ${content}`;
      return `${indent}- ${content}`;
    });
  }
  const text = t.slice(0, firstStart) + out.join('\n') + t.slice(lastEnd);
  if (a !== b) {
    return { text, caretStart: firstStart, caretEnd: firstStart + out.join('\n').length };
  }
  // Collapsed caret: land inside the caret line (after an inserted marker,
  // before a stripped one) so typing continues the item — Notion-style.
  let acc = firstStart;
  let caretLine = 0;
  for (let i = 0; i < lines.length; i++) {
    if (a <= acc + lines[i].length) { caretLine = i; break; }
    caretLine = i;
    acc += lines[i].length + 1;
  }
  const lineStart = acc;
  const col = Math.max(0, a - lineStart);
  const oldLen = lines[caretLine].length;
  const newLen = (out[caretLine] || '').length;
  const delta = newLen - oldLen;
  let newCol;
  if (delta >= 0) {
    const p = parseListMarker(lines[caretLine]);
    const insertAt = p ? p.indent.length : (lines[caretLine].match(/^\s*/) || [''])[0].length;
    // Before the insertion point the caret holds still; at/after it rides
    // with the content (line-start caret lands after the new marker).
    newCol = col < insertAt ? col : col + delta;
  } else {
    newCol = Math.max(0, col + delta);
  }
  const caret = lineStart + newCol;
  return { text, caretStart: caret, caretEnd: caret };
}
/* Maps a CE-body plain-text range onto store-markdown offsets. CE shows the
 * body without heading hashes / quote prefixes; the store keeps them.
 * Pure + node-testable (takes strings, no DOM). */
export function mapBodyRangeToStore(storeText, bodyText, hashes = '', quoted = false, bodyStart = 0, bodyEnd = 0) {
  const st = String(storeText ?? '');
  const bt = String(bodyText ?? '');
  const bs = Math.max(0, Math.min(bt.length, Number(bodyStart) || 0));
  const be = Math.max(0, Math.min(bt.length, Number(bodyEnd) || 0));
  const a = Math.min(bs, be);
  const b = Math.max(bs, be);
  if (!quoted) {
    const shift = String(hashes || '').length;
    return { start: Math.min(st.length, a + shift), end: Math.min(st.length, b + shift) };
  }
  const bl = bt.split('\n');
  const sl = st.split('\n');
  const toStore = (bo) => {
    let bacc = 0;
    for (let i = 0; i < bl.length; i++) {
      const blen = bl[i].length;
      if (bo <= bacc + blen) {
        const slineStart = sl.slice(0, i).join('\n').length + (i > 0 ? 1 : 0);
        return Math.min(st.length, slineStart + 2 + (bo - bacc));
      }
      bacc += blen + 1;
    }
    return st.length;
  };
  return { start: toStore(a), end: toStore(b) };
}
/* Active-state probe for toolbar aria-pressed. Inline: selection exactly
 * wrapped or hugged by markers. Block: line prefix at selection line.
 * List: every non-blank spanned line carries the kind marker. */
export function detectRichState(plain, start, end, fmt) {
  const t = String(plain ?? '');
  const s = Math.max(0, Math.min(t.length, Number(start) || 0));
  const e = Math.max(0, Math.min(t.length, Number(end) || 0));
  const a = Math.min(s, e);
  const b = Math.max(s, e);
  if (RICH_INLINE_COMMANDS.includes(fmt)) {
    const m = fmt === 'link' ? null : mdInlineMarkers(fmt);
    if (fmt === 'link') {
      const sel = t.slice(a, b);
      return /^\[.+\]\(.+\)$/.test(sel);
    }
    if (!m) return false;
    const [before, after] = m;
    const sel = t.slice(a, b);
    if (sel.length >= before.length + after.length && sel.startsWith(before) && sel.endsWith(after)) {
      if (before === '*' && (sel.startsWith('**') || sel.endsWith('**'))) return false;
      return true;
    }
    return t.slice(a - before.length, a) === before && t.slice(b, b + after.length) === after;
  }
  const lineStart = t.lastIndexOf('\n', a - 1) + 1;
  const line = t.slice(lineStart);
  if (fmt === 'h1') return /^#\s+/.test(line) && !/^##\s+/.test(line);
  if (fmt === 'h2') return /^##\s+/.test(line) && !/^###\s+/.test(line);
  if (fmt === 'h3') return /^###\s+/.test(line) && !/^####\s+/.test(line);
  if (fmt === 'h4') return /^####\s+/.test(line);
  if (fmt === 'quote') return /^>\s?/.test(line);
  if (fmt === 'p') return !/^(#{1,6}\s+|>+\s*)/.test(line);
  if (fmt === 'ul' || fmt === 'ol') {
    const firstStart = t.lastIndexOf('\n', a - 1) + 1;
    let lastEnd = t.indexOf('\n', b);
    if (lastEnd < 0) lastEnd = t.length;
    const rows = t.slice(firstStart, lastEnd).split('\n').filter((l) => l.trim());
    if (rows.length === 0) return false;
    return rows.every((l) => {
      const p = parseListMarker(l);
      return !!p && (fmt === 'ol' ? p.ordered : !p.ordered);
    });
  }
  return false;
}
/* Applies one rich command to plain text. Inline -> ceApplyInline toggle.
 * Block (h1/h2/h3/quote/p) -> swaps the line prefix at the selection line,
 * toggling off when the prefix is already present. Returns text + caret. */
export function applyRichCommand(plain, start, end, fmt) {
  const t = String(plain ?? '');
  if (RICH_INLINE_COMMANDS.includes(fmt)) return ceApplyInline(t, start, end, fmt);
  if (RICH_LIST_COMMANDS.includes(fmt)) return applyListCommand(t, start, end, fmt);
  if (!RICH_BLOCK_COMMANDS.includes(fmt)) {
    const s = Math.max(0, Math.min(t.length, Number(start) || 0));
    const e = Math.max(0, Math.min(t.length, Number(end) || 0));
    return { text: t, caretStart: Math.min(s, e), caretEnd: Math.max(s, e) };
  }
  const s = Math.max(0, Math.min(t.length, Number(start) || 0));
  const e = Math.max(0, Math.min(t.length, Number(end) || 0));
  const a = Math.min(s, e);
  const b = Math.max(s, e);
  const lineStart = t.lastIndexOf('\n', a - 1) + 1;
  // Normalizes heading/quote/list prefixes alike so formats convert into
  // each other (`- item` + H1 → `# item`, never `# - item`).
  const cur = t.slice(lineStart).match(/^(#{1,6}\s+|>+\s*|(?:-|\*|\+|\d+[.)])\s+)/);
  const curLen = cur ? cur[0].length : 0;
  const want = fmt === 'p' ? '' : blockPrefixFor(fmt);
  // Toggle-off: same prefix already present -> strip to paragraph.
  if (cur && want && t.slice(lineStart, lineStart + want.length) === want
    && (fmt !== 'h1' || !t.slice(lineStart).startsWith('## '))) {
    const text = t.slice(0, lineStart) + t.slice(lineStart + curLen);
    const d = curLen;
    return { text, caretStart: Math.max(lineStart, a - d), caretEnd: Math.max(lineStart, b - d) };
  }
  const text = t.slice(0, lineStart) + want + t.slice(lineStart + curLen);
  const d = want.length - curLen;
  return { text, caretStart: a + d, caretEnd: b + d };
}
/* UndoCheckpoint: bounded snapshot stack over BlockStore markdown strings.
 * Pure push/pop so the depth is node-testable; BlockEditor owns the stacks. */
export const UNDO_LIMIT = 50;
export function pushUndo(stack, snapshot, limit = UNDO_LIMIT) {
  const arr = Array.isArray(stack) ? [...stack, String(snapshot ?? '')] : [String(snapshot ?? '')];
  const cap = Math.max(1, Number(limit) || UNDO_LIMIT);
  return arr.length > cap ? arr.slice(arr.length - cap) : arr;
}
export function popUndo(stack) {
  const arr = Array.isArray(stack) ? [...stack] : [];
  const snapshot = arr.pop();
  return { snapshot: snapshot === undefined ? null : snapshot, rest: arr };
}
/* Plain-text offsets of the live DOM Range inside a [data-ce] surface. */
function ceRangeOffsets(ce) {
  const sel = window.getSelection();
  if (!sel || sel.rangeCount === 0) return null;
  const range = sel.getRangeAt(0);
  if (!ce.contains(range.commonAncestorContainer)) return null;
  const pre = range.cloneRange();
  pre.selectNodeContents(ce);
  pre.setEnd(range.startContainer, range.startOffset);
  const start = pre.toString().length;
  return { start, end: start + range.toString().length };
}
/* Restores a plain-text caret range across styled runs via node walk. */
function ceSetCaret(ce, start, end) {
  try {
    const range = document.createRange();
    const walker = document.createTreeWalker(ce, 4);
    let acc = 0;
    let sNode = null;
    let sOff = 0;
    let eNode = null;
    let eOff = 0;
    let node = null;
    const a = Math.min(start, end);
    const b = Math.max(start, end);
    while ((node = walker.nextNode())) {
      const len = (node.textContent || '').length;
      if (sNode === null && acc + len >= a) { sNode = node; sOff = a - acc; }
      if (acc + len >= b) { eNode = node; eOff = b - acc; break; }
      acc += len;
    }
    const sel = window.getSelection();
    if (sNode && eNode) {
      range.setStart(sNode, Math.min(sOff, sNode.textContent.length));
      range.setEnd(eNode, Math.min(eOff, eNode.textContent.length));
    } else {
      range.selectNodeContents(ce);
      range.collapse(false);
    }
    sel?.removeAllRanges();
    sel?.addRange(range);
  } catch { /* caret restore is best effort */ }
}

export function clampFigureScale(n) {
  const v = Number(n);
  if (!Number.isFinite(v)) return 1;
  return Math.min(FIGURE_WIDTH_MAX, Math.max(FIGURE_WIDTH_MIN, v));
}

/* Parses one canonical/legacy figure line.
 * Returns null when the line is not a standalone figure.
 * Attr block wins; legacy `"caption {width=N}"` title suffix fills gaps. */
export function parseFigureLine(line = '') {
  const m = String(line ?? '').trim().match(/^!\[([^\]]*)\]\(([^)]+)\)\s*(\{([^}]*)\})?\s*$/);
  if (!m) return null;
  const alt = m[1] || '';
  const ref = m[2].trim();
  const refM = ref.match(/^(\S+)\s+["'](.*)["']$/);
  const src = refM ? refM[1] : ref;
  const title = refM ? refM[2] : '';
  let caption = title.trim();
  let scale = 1;
  const legM = caption.match(/\{\s*width\s*=\s*([0-9]*\.?[0-9]+)\s*\}\s*$/);
  if (legM) {
    caption = caption.slice(0, legM.index).trim();
    scale = clampFigureScale(legM[1]);
  }
  let place = 'column';
  let ratio = FIGURE_RATIO_DEFAULT;
  let slug = '';
  const attrBody = m[4] || '';
  if (attrBody) {
    const idM = attrBody.match(/#([A-Za-z0-9_-]+)/);
    if (idM) slug = idM[1];
    for (const kv of attrBody.matchAll(/(\w+)\s*=\s*"?([^"\s}]+)"?/g)) {
      const key = kv[1].toLowerCase();
      if (key === 'width') scale = clampFigureScale(kv[2]);
      else if ((key === 'place' || key === 'placement') && FIGURE_PLACEMENTS.includes(kv[2])) place = kv[2];
      else if (key === 'ratio' || key === 'aspect') {
        const r = Number(kv[2]);
        if (Number.isFinite(r) && r > 0) ratio = r;
      }
    }
  }
  return { alt, src, caption, scale, place, ratio, slug };
}

/* Canonical emission: `![alt](src "caption") {#slug width=W place=P ratio=R}`.
 * width omitted when 1, place when column, ratio when default 1.5,
 * auto `fig-slug-*` ids omitted (re-generated on parse, zero information). */
export function serializeFigureLine(f = {}) {
  const alt = String(f.alt ?? '').replace(/[\[\]]/g, '');
  const src = String(f.src ?? '').trim();
  const caption = String(f.caption ?? '').trim();
  const scale = clampFigureScale(f.scale ?? 1);
  const hasScale = Math.abs(scale - 1) > 1e-9;
  const place = f.place === 'full-width' ? 'full-width' : 'column';
  const ratio = Number(f.ratio);
  const hasRatio = Number.isFinite(ratio) && ratio > 0 && Math.abs(ratio - FIGURE_RATIO_DEFAULT) > 1e-9;
  const slug = String(f.slug || '');
  const keepSlug = slug && !/^fig-slug-[0-9a-z]+$/.test(slug);
  const parts = [];
  if (keepSlug) parts.push(`#${slug.replace(/[^A-Za-z0-9_-]/g, '')}`);
  if (hasScale) parts.push(`width=${scale}`);
  if (place !== 'column') parts.push(`place=${place}`);
  if (hasRatio) parts.push(`ratio=${Math.round(ratio * 100) / 100}`);
  const attrs = parts.length > 0 ? ` {${parts.join(' ')}}` : '';
  if (!caption) return `![${alt}](${src})${attrs}`;
  return `![${alt}](${src} "${caption.replace(/"/g, '')}")${attrs}`;
}

/* Splits markdown into blank-line-separated blocks, preserving the exact
 * separator after each block so edits never reflow untouched whitespace. */
export function splitBlocks(md = '') {
  const text = String(md ?? '').replace(/\r\n?/g, '\n');
  const blocks = [];
  if (!text.trim()) return blocks;
  const re = /([^\n]*(?:\n(?!\n)[^\n]*)*)(\n{2,}|\n?$)/g;
  let m;
  const pushLines = (lines, sep) => {
    if (!lines.length || lines.every((l) => !l.trim())) {
      if (blocks.length > 0 && sep) blocks[blocks.length - 1].sep += sep;
      return;
    }
    const body = lines.join('\n');
    blocks.push({ kind: classifyBlock(body), lines: [...lines], sep });
  };
  while ((m = re.exec(text)) !== null) {
    if (m[0] === '') break;
    const body = m[1];
    const sep = m[2] && m[2].length > 1 ? m[2] : (m[2] === '\n' ? '' : '');
    if (body.trim() === '' && sep === '') continue;
    if (body.trim() === '') {
      if (blocks.length > 0) blocks[blocks.length - 1].sep += m[2];
      continue;
    }
    let lines = body.split('\n');
    // Tokenizer artifact (gate-locked): the body pattern consumes a single
    // end-of-input newline (`\n(?!\n)` succeeds at EOS), leaving a phantom
    // '' line that table ops later materialize into real rows. It is never
    // content — only the final chunk at end-of-input can carry it.
    const atEnd = m.index + m[0].length >= text.length;
    if (atEnd && lines.length > 1 && lines[lines.length - 1] === '') lines.pop();
    // Structural split: a heading line glued to following list/text lines
    // (single \n, no blank line) must not share one card — the heading row
    // renders its own styled surface while the list renders bullets, so one
    // merged textarea reads as "glued" elements in the rich view.
    // Splits ONLY the heading-leading case (highest signal, zero behavior
    // change for paragraph/table/figure/math/callout/rule bodies).
    if (lines.length > 1 && /^(#{1,6})\s+/.test(lines[0].trim()) && !/^(#{1,6})\s+/.test(lines[1].trim() || '')) {
      const head = [lines[0]];
      const rest = lines.slice(1);
      const restHasContent = rest.some((l) => l.trim());
      pushLines(head, restHasContent ? '\n' : sep);
      if (restHasContent) pushLines(rest, sep);
      continue;
    }
    blocks.push({ kind: classifyBlock(body), lines, sep });
  }
  return blocks;
}

export function classifyBlock(body = '') {
  const t = String(body ?? '').trim();
  const first = t.split('\n')[0];
  if (/^(#{1,6})\s+/.test(first) && !t.includes('\n')) return 'heading';
  if (/^!\[([^\]]*)\]\(([^)]+)\)\s*(\{[^}]*\})?\s*$/.test(t) && !t.includes('\n')) return 'figure';
  if (/^\s*\|/.test(first) && t.split('\n').every((l) => /^\s*\|/.test(l))) return 'table';
  if (/^\$\$/.test(first)) return 'math';
  if (/^:::/.test(first)) return 'callout';
  if (/^(---|___|\*\*\*)\s*$/.test(t) && !t.includes('\n')) return 'rule';
  return 'paragraph';
}

export function serializeBlocks(blocks = []) {
  return blocks.map((b) => `${b.lines.join('\n')}${b.sep || ''}`).join('').replace(/\n+$/, '\n').replace(/^\n+/, '');
}

/* Drop-target resolution shared by the 3 row-drop sites + the outer card
 * path concept. `after` = first index whose midpoint clears the pointer.
 * Insert-before is a same-slot no-op only against the dragged block's own
 * immediate successor — then land after it. Every other target lands
 * before it (both directions). Pure, node-testable. */
export function resolveDropIndex(fromIdx, afterIdxOrNull, length) {
  const visibleLen = Math.max(0, (Number(length) || 0) - 1);
  if (afterIdxOrNull === null || afterIdxOrNull === undefined) return visibleLen;
  const after = Number(afterIdxOrNull);
  if (!Number.isFinite(after)) return visibleLen;
  if (after === fromIdx + 1) {
    const visIdx = after > fromIdx ? after - 1 : after;
    return Math.max(0, Math.min(visIdx + 1, visibleLen));
  }
  const visIdx = after > fromIdx ? after - 1 : after;
  return Math.max(0, Math.min(visIdx, visibleLen));
}

/* Escaped-pipe-aware row split (mirrors from-markdown splitRow). */
export function splitTableRow(r = '') {
  const cells = [];
  let cur = '';
  let escaped = false;
  const inner = String(r ?? '').trim().replace(/^\||\|$/g, '');
  for (let k = 0; k < inner.length; k++) {
    const ch = inner[k];
    if (escaped) { cur += (ch === '|' ? '|' : `\\${ch}`); escaped = false; }
    else if (ch === '\\') escaped = true;
    else if (ch === '|') { cells.push(cur.trim()); cur = ''; }
    else cur += ch;
  }
  cells.push(cur.trim());
  return cells;
}

const escCell = (t) => String(t ?? '').replace(/\\/g, '\\\\').replace(/\|/g, '\\|');

export const isDelimiterRow = (line = '') => {
  const cells = splitTableRow(line);
  return cells.length > 0 && cells.every(c => /^:?-+:?$/.test(c.trim()));
};

export const alignCellFormat = (align = 'left') => {
  if (align === 'center') return ':---:';
  if (align === 'right') return '---:';
  return '---';
};

/* Block model over one markdown string. All mutations keep separators of
 * untouched blocks, so Rich edits never reflow surrounding whitespace. */
export class BlockStore {
  constructor(md = '') {
    this.setSource(md);
  }
  setSource(md = '') {
    this.source = String(md ?? '');
    this.blocks = splitBlocks(this.source);
  }
  getMarkdown() {
    return serializeBlocks(this.blocks);
  }
  updateBlockText(i, text) {
    const b = this.blocks[i];
    if (!b) return;
    b.lines = String(text ?? '').replace(/\r\n?/g, '\n').split('\n');
    b.kind = classifyBlock(b.lines.join('\n'));
  }
  updateFigure(i, patch = {}) {
    const b = this.blocks[i];
    if (!b || b.kind !== 'figure') return;
    const cur = parseFigureLine(b.lines.join('\n')) || { alt: '', src: '', caption: '', scale: 1, place: 'column', ratio: FIGURE_RATIO_DEFAULT, slug: '' };
    b.lines = [serializeFigureLine({ ...cur, ...patch })];
  }
  updateTableCell(i, r, c, val) {
    const b = this.blocks[i];
    if (!b || b.kind !== 'table') return;
    const rows = b.lines.map(splitTableRow);
    if (!rows[r] || c >= rows[r].length) return;
    rows[r][c] = String(val ?? '');
    b.lines = rows.map((cells) => `| ${cells.map(escCell).join(' | ')} |`);
  }
  addTableRow(i, atRow = -1) {
    const b = this.blocks[i];
    if (!b || b.kind !== 'table') return;
    const rows = b.lines.map(splitTableRow);
    const numCols = Math.max(1, ...rows.map(r => r.length));
    const emptyRow = Array(numCols).fill('');
    // If table has header and delimiter, ensure insertion happens in body
    const insertIdx = atRow >= 0 ? atRow : rows.length;
    rows.splice(insertIdx, 0, emptyRow);
    b.lines = rows.map((cells) => `| ${cells.map(escCell).join(' | ')} |`);
  }
  deleteTableRow(i, r) {
    const b = this.blocks[i];
    if (!b || b.kind !== 'table') return;
    const rows = b.lines.map(splitTableRow);
    // Disallow deleting if only header + delimiter + 1 row remain
    if (rows.length <= 2 && isDelimiterRow(b.lines[1])) return;
    if (rows.length <= 1) return;
    rows.splice(r, 1);
    b.lines = rows.map((cells) => `| ${cells.map(escCell).join(' | ')} |`);
  }
  addTableColumn(i, atCol = -1) {
    const b = this.blocks[i];
    if (!b || b.kind !== 'table') return;
    const isDelim = (l) => isDelimiterRow(l);
    b.lines = b.lines.map((line, rIdx) => {
      const cells = splitTableRow(line);
      const colIdx = atCol >= 0 ? atCol : cells.length;
      if (rIdx === 1 && isDelim(line)) {
        cells.splice(colIdx, 0, '---');
      } else {
        cells.splice(colIdx, 0, '');
      }
      return `| ${cells.map(escCell).join(' | ')} |`;
    });
  }
  deleteTableColumn(i, c) {
    const b = this.blocks[i];
    if (!b || b.kind !== 'table') return;
    const sample = splitTableRow(b.lines[0]);
    if (sample.length <= 1) return; // Disallow deleting last column
    b.lines = b.lines.map((line) => {
      const cells = splitTableRow(line);
      cells.splice(c, 1);
      return `| ${cells.map(escCell).join(' | ')} |`;
    });
  }
  setTableColAlign(i, c, align = 'left') {
    const b = this.blocks[i];
    if (!b || b.kind !== 'table' || b.lines.length < 2) return;
    if (isDelimiterRow(b.lines[1])) {
      const cells = splitTableRow(b.lines[1]);
      if (c >= 0 && c < cells.length) {
        cells[c] = alignCellFormat(align);
        b.lines[1] = `| ${cells.join(' | ')} |`;
      }
    }
  }
  removeBlock(i) {
    if (i >= 0 && i < this.blocks.length) this.blocks.splice(i, 1);
    this._fixSeps();
  }
  insertBlockAt(index, snippet) {
    const add = splitBlocks(String(snippet ?? ''));
    if (add.length > 0) {
      const at = Math.max(0, Math.min(this.blocks.length, Number(index) || 0));
      this.blocks.splice(at, 0, ...add);
      this._fixSeps();
    }
  }
  moveBlock(fromIdx, toIdx) {
    if (fromIdx < 0 || fromIdx >= this.blocks.length) return;
    if (toIdx < 0 || toIdx >= this.blocks.length) return;
    if (fromIdx === toIdx) return;
    const [moved] = this.blocks.splice(fromIdx, 1);
    this.blocks.splice(toIdx, 0, moved);
    this._fixSeps();
  }
  appendLines(lines) {
    const add = splitBlocks(String(lines ?? ''));
    if (add.length > 0) {
      this.blocks.push(...add);
      this._fixSeps();
    }
  }
  /* Separators are positional, not attached to blocks: every non-last block
   * must end with a blank line so serialize→split round-trips stable.
   * Fixes reload-merge where a moved/appended block carried sep='' mid-list. */
  _fixSeps() {
    for (let k = 0; k < this.blocks.length; k++) {
      const b = this.blocks[k];
      if (k < this.blocks.length - 1) {
        if (!b.sep || !b.sep.includes('\n\n')) b.sep = '\n\n';
      } else if (b.sep && b.sep.length > 1) {
        b.sep = '';
      }
    }
  }
}

const escHtml = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/* Body-level popup portal (L1 layering fix): quick-insert menus and the
 * floating format toolbar render here — above every scroll/clipping context
 * (.rich-container overflow:auto, .box-card overflow:hidden) — positioned
 * from getBoundingClientRect viewport coords (fixed layer, no scroll offsets).
 * Single shared layer per page. */
export function uiPortal() {
  if (typeof document === 'undefined') return null;
  let portal = document.getElementById('ui-portal');
  if (!portal) {
    portal = document.createElement('div');
    portal.id = 'ui-portal';
    // AT exposure (P0 ARIA gate): the container must NOT be aria-hidden —
    // that hid the toolbar + all menus from screen readers (ancestor
    // aria-hidden wins over descendants). Hidden popups already leave the
    // a11y tree via display:none (.hidden); visible ones manage shelf state.
    portal.setAttribute('aria-hidden', 'false');
    document.body.appendChild(portal);
  } else if (portal.getAttribute('aria-hidden') === 'true') {
    // Self-heal portals created before this fix (e.g. restored DOM).
    portal.setAttribute('aria-hidden', 'false');
  }
  ensurePortalGlobalHandlers();
  return portal;
}
/* Dedicated menu shelf inside the portal: menus render here so wiping a
 * menu never destroys a floating toolbar. Single seam for both adapters. */
export function menuShelf() {
  const portal = uiPortal();
  if (!portal) return null;
  let shelf = document.getElementById('bedit-menu-shelf');
  if (!shelf) {
    shelf = document.createElement('div');
    shelf.id = 'bedit-menu-shelf';
    shelf.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:auto;';
    portal.appendChild(shelf);
  }
  return shelf;
}
/* Global portal dismiss: hides floating toolbars + removes open menus.
 * Called on editor mode switch, scroll/resize (stale viewport coords),
 * Escape, and outside pointerdown. Idempotent. */
export function closePortalMenus() {
  if (typeof document === 'undefined') return;
  try {
    const shelf = document.getElementById('bedit-menu-shelf');
    if (shelf) shelf.innerHTML = '';
    document.querySelectorAll('#ui-portal .bedit-quick-menu.portal-open, #ui-portal .bedit-slash-wrap.portal-open')
      .forEach((el) => el.remove());
  } catch { /* cosmetic */ }
  hidePortalToolbars();
}
let _portalGlobalBound = false;
function ensurePortalGlobalHandlers() {
  if (_portalGlobalBound || typeof document === 'undefined') return;
  _portalGlobalBound = true;
  try {
    document.addEventListener('pointerdown', (e) => {
      try {
        const t = e.target;
        if (t?.closest?.('#ui-portal .bedit-floating-toolbar, #ui-portal .md-float-toolbar, #ui-portal .bedit-quick-menu, #ui-portal .bedit-slash-wrap')) return;
        if (t?.closest?.('textarea, [data-ce], [data-raw]')) return;
        if (t?.closest?.('[data-fmt], [data-md], [data-ins], [data-mi]')) return;
        hidePortalToolbars();
        closePortalMenus();
      } catch { /* cosmetic */ }
    }, true);
    const hideOnScroll = () => { hidePortalToolbars(); closePortalMenus(); };
    document.addEventListener('scroll', hideOnScroll, true);
    window.addEventListener('resize', hideOnScroll);
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') { hidePortalToolbars(); closePortalMenus(); }
    }, true);
  } catch { /* cosmetic */ }
}
/* Singleton-visible portal toolbars: showing one toolbar hides every other
 * floating format bar in the portal (rich + markdown). Prevents stuck or
 * duplicated visible bars when several cards are alive or adapters re-mount.
 * Pure-DOM helper shared by BlockEditor and the markdown toolbar (v2-app). */
export function hidePortalToolbars(except = null) {
  if (typeof document === 'undefined') return;
  try {
    document.querySelectorAll('#ui-portal .bedit-floating-toolbar, #ui-portal .md-float-toolbar')
      .forEach((el) => { if (el !== except) el.classList.add('hidden'); });
  } catch { /* cosmetic */ }
}
/* Purges orphaned portal toolbars left by discarded adapters (deleted boxes
 * never run destroy). Called before structural re-renders. */
export function purgePortalToolbars() {
  if (typeof document === 'undefined') return;
  try {
    document.querySelectorAll('#ui-portal .bedit-floating-toolbar, #ui-portal .md-float-toolbar')
      .forEach((el) => el.remove());
    const shelf = document.getElementById('bedit-menu-shelf');
    if (shelf) shelf.innerHTML = '';
  } catch { /* cosmetic */ }
}

/* Styled inline readout (L3): renders canonical markdown runs with visual
 * weight (bold/italic/code/strike) inside a read-only line. Editing stays in
 * the textarea (canonical, lossless); this kills the "just symbols" feel. */
export function renderStyledPreview(text = '') {
  let t = escHtml(String(text ?? ''));
  t = t.replace(/`([^`]+?)`/g, '<code>$1</code>');
  t = t.replace(/\*\*\*([^*]+?)\*\*\*/g, '<strong><em>$1</em></strong>');
  t = t.replace(/\*\*([^*]+?)\*\*/g, '<strong>$1</strong>');
  t = t.replace(/(^|[^*])\*([^*\n]+?)\*/g, '$1<em>$2</em>');
  t = t.replace(/~~(.+?)~~/g, '<s>$1</s>');
  return t;
}

/* Phase 3 gated view: DOM → markdown for the contentEditable surface.
 * Inverse of renderStyledPreview: <strong>→**, <em>→*, <code>→`,
 * <s>/del→~~, <br>/block ends→\n. Figure/table islands never enter here. */
export function ceDomToMarkdown(node) {
  if (!node) return '';
  if (node.nodeType === 3) return node.nodeValue || '';
  if (node.nodeType !== 1) return '';
  const tag = (node.tagName || '').toUpperCase();
  if (tag === 'BR') return '\n';
  if (tag === 'A') {
    const href = (node.getAttribute && node.getAttribute('href')) || '';
    const text = ceKids(node);
    return href ? `[${text}](${href})` : text;
  }
  const inner = tag === 'DIV' || tag === 'P' || tag === 'LI' || tag === 'H1' || tag === 'H2' || tag === 'H3' || tag === 'H4'
    ? `${ceKids(node)}\n` : ceKids(node);
  if (tag === 'STRONG' || tag === 'B') {
    const t = inner.replace(/\n+$/g, '');
    if (t.startsWith('**') && t.endsWith('**') && t.length >= 4) return t;
    return `**${inner}**`;
  }
  if (tag === 'EM' || tag === 'I') {
    const t = inner.replace(/\n+$/g, '');
    if ((t.startsWith('**') && t.endsWith('**')) || (t.startsWith('*') && t.endsWith('*') && t.length >= 2)) return t;
    return `*${inner}*`;
  }
  if (tag === 'CODE') {
    const t = inner.replace(/\n+$/g, '');
    if (t.startsWith('`') && t.endsWith('`') && t.length >= 2) return t;
    return `\`${inner}\``;
  }
  if (tag === 'S' || tag === 'DEL' || tag === 'STRIKE') {
    const t = inner.replace(/\n+$/g, '');
    if (t.startsWith('~~') && t.endsWith('~~') && t.length >= 4) return t;
    return `~~${inner}~~`;
  }
  return inner;
}
function ceKids(node) {
  let out = '';
  for (const c of node.childNodes || []) out += ceDomToMarkdown(c);
  return out.replace(/\n+$/g, '');
}
/* RowRenderer seam: one pure body builder per kind. cardFor owns the
 * chrome (gutter + badge + delete + DnD wiring); each builder owns only
 * its kind's inner HTML. Deletion test: remove one builder, other kinds
 * render untouched. */
const ROW_BADGE = { heading: 'Título', paragraph: 'Texto', figure: 'Figura', table: 'Tabela', math: 'Equação', callout: 'Destaque', rule: 'Divisória' };
function rowBadge(kind) { return ROW_BADGE[kind] || 'Texto'; }
function figureBodyHTML(b, i) {
  const f = parseFigureLine(b.lines.join('\n')) || { alt: '', src: '', caption: '', scale: 1, place: 'column', ratio: FIGURE_RATIO_DEFAULT, slug: '' };
  const pct = Math.round(f.scale * 100);
  const ratioVal = Math.round(f.ratio * 100) / 100;
  return `
        <div class="bedit-figthumb" data-ratio="${ratioVal}" style="--fig-ratio: ${ratioVal}; aspect-ratio: var(--fig-ratio, 1.5);" title="Duplo-clique para abrir modal de edição">
          <img src="${escHtml(f.src)}" alt="${escHtml(f.alt || 'Figura')}" loading="lazy">
          <div class="bedit-figthumb-overlay">
            <button type="button" class="btn btn-secondary sm bedit-quickedit-btn" data-act="quick-edit">Editar no Modal</button>
          </div>
        </div>
        <label class="bedit-field"><span>Texto alternativo</span><input class="text-input sm" data-f="alt" value="${escHtml(f.alt)}"></label>
        <label class="bedit-field"><span>Legenda</span><input class="text-input sm" data-f="caption" value="${escHtml(f.caption)}"></label>
        <label class="bedit-field"><span>Escala (${pct}%)</span>
          <span class="bedit-scale-row"><input type="range" data-f="scale" min="0.05" max="1" step="0.05" value="${f.scale}" aria-label="Escala da figura">
          <input class="text-input sm bedit-scale-num" data-f="scale-num" type="number" min="0.05" max="1" step="0.05" value="${f.scale}" aria-label="Escala exata"></span>
        </label>
        <label class="bedit-field"><span>Largura</span>
          <select class="text-input sm" data-f="place">
            <option value="column"${f.place === 'column' ? ' selected' : ''}>Coluna</option>
            <option value="full-width"${f.place === 'full-width' ? ' selected' : ''}>Página inteira</option>
          </select></label>
        <div class="bedit-meta">proporção ${escHtml(String(ratioVal))}${f.slug ? ` · #${escHtml(f.slug)}` : ''}</div>
        <div class="bedit-fig-actions">
          <button type="button" class="btn btn-secondary sm" data-act="modal-edit">Editar Detalhado</button>
          <button type="button" class="btn btn-secondary sm bedit-remove" data-remove="${i}">Remover figura</button>
        </div>`;
}
function tableBodyHTML(b, i) {
  const rows = b.lines.map(splitTableRow);
  const isDelim = (r) => isDelimiterRow(b.lines[r]);
  const alignments = rows.length > 1 && isDelim(1)
    ? rows[1].map(c => /^:.*:$/.test(c.trim()) ? 'center' : /:$/.test(c.trim()) ? 'right' : 'left')
    : rows[0].map(() => 'left');
  return `
        <div class="bedit-table-toolbar">
          <span class="bedit-table-dim">${rows.filter((_, r) => !isDelim(r)).length}×${rows[0].length}</span>
          <button type="button" class="btn btn-secondary sm" data-tbl-act="add-col">+ Coluna</button>
          <button type="button" class="btn btn-secondary sm" data-tbl-act="add-row">+ Linha</button>
        </div>
        <div class="bedit-table-wrapper">
          <table class="bedit-table" role="grid">
            <thead>
              <tr class="bedit-table-col-controls">
                <th class="bedit-th-corner"></th>
                ${rows[0].map((_, cIdx) => `
                  <th class="bedit-th-col">
                    <div class="bedit-col-actions">
                      <button type="button" class="bedit-tiny-btn bedit-align-btn" data-col-align="${cIdx}" title="Alinhamento: ${alignments[cIdx]} (clique para alternar)">${alignments[cIdx] === 'center' ? 'C' : alignments[cIdx] === 'right' ? 'D' : 'E'}</button>
                      <button type="button" class="bedit-tiny-btn btn-danger" data-col-del="${cIdx}" title="Excluir coluna ${cIdx + 1}">×</button>
                    </div>
                  </th>
                `).join('')}
              </tr>
            </thead>
            <tbody>
              ${rows.map((cells, rIdx) => {
                if (isDelim(rIdx)) return '';
                const isHeader = rIdx === 0;
                return `
                  <tr class="${isHeader ? 'bedit-tr-head' : 'bedit-tr-body'}">
                    <td class="bedit-td-row-ctrl">
                      <div class="bedit-row-actions">
                        ${!isHeader ? `<button type="button" class="bedit-tiny-btn btn-danger" data-row-del="${rIdx}" title="Excluir linha">×</button>` : `<span class="bedit-head-badge">H</span>`}
                      </div>
                    </td>
                    ${cells.map((c, cIdx) => `
                      <td class="bedit-td-cell">
                        <input class="text-input sm bedit-cell-input ${isHeader ? 'fw-bold' : ''}" data-align="${alignments[cIdx] || 'left'}" role="gridcell" data-cell="${rIdx}:${cIdx}" value="${escHtml(c)}" aria-label="Linha ${rIdx + 1} Coluna ${cIdx + 1}">
                      </td>
                    `).join('')}
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        </div>
        <button type="button" class="btn btn-secondary sm bedit-remove" data-remove="${i}">Remover tabela</button>`;
}
function calloutBodyHTML(b) {
  const first = (b.lines[0] || '').match(/^:::\s*(\S+)?\s*(.*)$/);
  const accent = (first && first[1]) || 'info';
  const title = (first && first[2]) || '';
  const body = b.lines.length > 2 ? b.lines.slice(1, -1).join('\n') : '';
  return `<div class="bedit-meta">Destaque · ${escHtml(accent)}</div>
        <label class="bedit-field"><span>Título</span><input class="text-input sm" data-c="title" value="${escHtml(title)}"></label>
        <label class="bedit-field"><span>Conteúdo</span><textarea class="text-input sm" data-c="body" rows="3">${escHtml(body)}</textarea></label>`;
}
function ruleBodyHTML() {
  return `<div class="bedit-rule-div" aria-hidden="true"><span class="bedit-rule-div-line"></span><span class="bedit-rule-div-pill">Divisória</span><span class="bedit-rule-div-line"></span></div>`;
}
function textBodyHTML(b, i, opts = {}) {
  const rawText = b.lines.join('\n');
  const hm = b.kind === 'heading' ? rawText.match(/^(#{1,6})\s+(.*)$/s) : null;
  const isQuote = rawText.split('\n').every((l) => /^\s*>/.test(l) || !l.trim());
  const useCE = opts.ceEnabled && (b.kind === 'paragraph' || b.kind === 'heading');
  let pvCls = 'bedit-preview';
  let pvBody = '';
  if (opts.previewEnabled && !useCE) {
    if (hm) {
      const lv = Math.min(hm[1].length, 4);
      pvCls = `bedit-preview bedit-preview-h${lv}`;
      pvBody = renderStyledPreview(hm[2]);
    } else if (isQuote && rawText.trim()) {
      const qt = rawText.split('\n').map((l) => l.replace(/^\s*>\s?/, '')).join('\n');
      pvCls = 'bedit-preview bedit-preview-quote';
      pvBody = renderStyledPreview(qt);
    } else if (rawText.trim()) {
      pvBody = renderStyledPreview(rawText);
    }
  }
  const rows = Math.min(12, Math.max(2, rawText.split('\n').length));
  const tabbedPreview = opts.previewEnabled && !useCE && pvBody;
  const activeTab = tabbedPreview ? (opts.activeTab || 'preview') : 'edit';
  if (useCE) {
    const ceBody = hm ? hm[2] : (isQuote && rawText.trim()
      ? rawText.split('\n').map((l) => l.replace(/^\s*>\s?/, '')).join('\n')
      : rawText);
    const ceCls = hm ? ` bedit-preview-h${Math.min(hm[1].length, 4)}` : (isQuote && rawText.trim() ? ' bedit-preview-quote' : '');
    const hashes = hm ? `${hm[1]} ` : '';
    const quote = (!hm && isQuote && rawText.trim()) ? '1' : '';
    return `<div class="bedit-ce${ceCls}" contenteditable="true" data-ce="1" data-hashes="${escHtml(hashes)}" data-quote="${quote}" spellcheck="false" role="textbox" aria-multiline="true" aria-label="Editar texto">${renderStyledPreview(ceBody)}</div><textarea class="text-input bedit-raw hidden" data-raw rows="${rows}" spellcheck="false" tabindex="-1" aria-hidden="true">${escHtml(rawText)}</textarea>`;
  }
  if (tabbedPreview) {
    const isPrev = activeTab !== 'edit';
    return `<div class="bedit-viewtabs" role="tablist" aria-label="Visualização do elemento ${i + 1}">`
      + `<button type="button" role="tab" data-tab="edit" aria-selected="${isPrev ? 'false' : 'true'}">Editar</button>`
      + `<button type="button" role="tab" data-tab="preview" aria-selected="${isPrev ? 'true' : 'false'}">Prévia</button></div>`
      + `<div class="${pvCls}${isPrev ? '' : ' hidden'}" data-pane="preview">${pvBody}</div>`
      + `<textarea class="text-input bedit-raw${isPrev ? ' hidden' : ''}" data-raw data-pane="edit" rows="${rows}" spellcheck="false"${isPrev ? ' tabindex="-1"' : ''}>${escHtml(rawText)}</textarea>`;
  }
  return `<textarea class="text-input bedit-raw" data-raw rows="${rows}" spellcheck="false">${escHtml(rawText)}</textarea>`;
}
/* Card renderer implementing the EditorAdapter seam
 * (mount/setContent/getContent/insertText/destroy/highlight).
 * Edits update inputs in place — never a destroy+recreate remount. */
export class BlockEditor {
  constructor(root, onImageUpload, opts = {}) {
    this.root = root;
    this.onImageUpload = onImageUpload;
    this.onSplit = typeof opts.onSplit === 'function' ? opts.onSplit : null;
    this.normalize = typeof opts.normalize === 'function' ? opts.normalize : ((s) => s);
    this.ceEnabled = opts.ce === true;
    this.previewEnabled = opts.preview === true;
    this._composing = false;
    this.activeCE = null;
    this.store = new BlockStore('');
    this.ready = false;
    this._undo = [];
    this._redo = [];
    this._tabByBlock = new WeakMap();
    this.floatingToolbar = null;
    this._selListener = null;
  }
  /* UndoCheckpoint: transaction snapshots over BlockStore markdown. */
  checkpoint() {
    this._undo = pushUndo(this._undo, this.store.getMarkdown());
    this._redo = [];
  }
  undo() {
    this.flushInputs();
    const cur = this.store.getMarkdown();
    const { snapshot, rest } = popUndo(this._undo);
    if (snapshot === null) return false;
    this._undo = rest;
    this._redo = pushUndo(this._redo, cur);
    this.store.setSource(snapshot);
    this.render();
    this.emit();
    return true;
  }
  redo() {
    this.flushInputs();
    const cur = this.store.getMarkdown();
    const { snapshot, rest } = popUndo(this._redo);
    if (snapshot === null) return false;
    this._redo = rest;
    this._undo = pushUndo(this._undo, cur);
    this.store.setSource(snapshot);
    this.render();
    this.emit();
    return true;
  }
  canUndo() { return this._undo.length > 0; }
  canRedo() { return this._redo.length > 0; }
  canExec(fmt) {
    return canExecCommand(fmt);
  }
  /* Active-state probe for toolbar aria-pressed. Headless-safe: with no DOM
   * cards, probes the store block text; with DOM, probes the live input. */
  getCommandState(fmt, blockIndex = 0, start = null, end = null) {
    if (!canExecCommand(fmt)) return false;
    try {
      const b = this.store.blocks[Number(blockIndex) || 0];
      const plain = b ? b.lines.join('\n') : '';
      let s = start;
      let e = end;
      if ((s === null || e === null) && this.root && typeof document !== 'undefined') {
        const card = this.root.querySelector(`[data-bi="${Number(blockIndex) || 0}"]`);
        const ta = card ? card.querySelector('textarea[data-raw]') : null;
        if (ta && typeof ta.selectionStart === 'number') { s = ta.selectionStart; e = ta.selectionEnd; }
        else { s = 0; e = 0; }
      }
      return detectRichState(plain, s ?? 0, e ?? 0, fmt);
    } catch { return false; }
  }
  /* RichCommandInterface entry: applies one command to a block's plain text
   * via the pure applyRichCommand, then syncs the live input in place.
   * Headless-safe (no root): mutates the store directly for tests/fakes. */
  execCommand(fmt, blockIndex = 0, start = null, end = null) {
    if (!canExecCommand(fmt)) return false;
    if (this._composing) return false;
    const bi = Number(blockIndex) || 0;
    const b = this.store.blocks[bi];
    if (!b || b.kind === 'figure' || b.kind === 'table' || b.kind === 'rule') return false;
    let plain = b.lines.join('\n');
    let s = start;
    let e = end;
    let liveTa = null;
    if ((s === null || e === null) && this.root && typeof document !== 'undefined') {
      const card = this.root.querySelector(`[data-bi="${bi}"]`);
      const ta = card ? card.querySelector('textarea[data-raw]') : null;
      if (ta && typeof ta.selectionStart === 'number') {
        liveTa = ta;
        plain = ta.value;
        s = ta.selectionStart;
        e = ta.selectionEnd;
      } else {
        s = plain.length;
        e = plain.length;
      }
    }
    const res = applyRichCommand(plain, s ?? plain.length, e ?? plain.length, fmt);
    if (res.text === plain) return true;
    this.checkpoint();
    this.store.updateBlockText(bi, res.text);
    if (liveTa) {
      liveTa.value = res.text;
      try { liveTa.setSelectionRange(res.caretStart, res.caretEnd); } catch { /* noop */ }
      const card = liveTa.closest('[data-bi]');
      if (card) this.switchTab(card, bi, 'edit');
      this.refreshPreview(card);
      try { liveTa.focus({ preventScroll: true }); } catch { /* keep focus */ }
    } else if (this.root) {
      this.render();
    }
    this.emit();
    return true;
  }
  setCEEnabled(on) {
    this.flushInputs();
    this.ceEnabled = on === true;
    this.render();
  }
  isCEEnabled() {
    return this.ceEnabled === true;
  }
  setPreviewEnabled(on) {
    this.flushInputs();
    this.previewEnabled = on === true;
    this.render();
  }
  isPreviewEnabled() {
    return this.previewEnabled === true;
  }
  async mount(initialMd) {
    this.setContent(initialMd ?? '');
    this.bindIO();
    this.bindContainerDrop();
    this.ready = true;
  }
  getContent() {
    this.flushInputs();
    return this.store.getMarkdown();
  }
  async setContent(md) {
    this.store.setSource(md ?? '');
    this._undo = [];
    this._redo = [];
    this.render();
  }
  async insertText(text) {
    this.checkpoint();
    this.store.appendLines(text);
    this.render();
    this.emit();
  }
  insertFigureLine(line) {
    this.checkpoint();
    this.store.appendLines(line);
    this.render();
    this.emit();
  }
  textareaListEnter(ta, e) {
    try {
      const v = ta.value, s = ta.selectionStart, ex = ta.selectionEnd;
      if (s !== ex || this._composing) return false;
      const ls = v.lastIndexOf('\n', s - 1) + 1;
      const le = v.indexOf('\n', s);
      const lineEnd = le < 0 ? v.length : le;
      const m = v.slice(ls, s).match(/^(\s*)(-|\*|\+|\d+[.)])(\s+)(.*)$/);
      if (!m || /\S/.test(v.slice(s, lineEnd))) return false;
      e.preventDefault();
      this.checkpoint();
      if (!m[4].trim()) {
        ta.value = v.slice(0, ls) + v.slice(lineEnd + (le < 0 ? 0 : 1));
        ta.setSelectionRange(ls, ls);
      } else {
        let mark = m[2];
        const nm = mark.match(/^(\d+)([.)])$/);
        if (nm) mark = `${Number(nm[1]) + 1}${nm[2]}`;
        const ins = `\n${m[1]}${mark} `;
        ta.value = v.slice(0, s) + ins + v.slice(s);
        ta.setSelectionRange(s + ins.length, s + ins.length);
      }
      ta.dispatchEvent(new Event('input', { bubbles: true }));
      return true;
    } catch { return false; }
  }
  textareaHeaderSplit(ta, e, bi) {
    try {
      const v = ta.value, s = ta.selectionStart, ex = ta.selectionEnd;
      if (s !== ex) return false;
      const ls = v.lastIndexOf('\n', s - 1) + 1;
      const le = v.indexOf('\n', s);
      const lineEnd = le < 0 ? v.length : le;
      if (s !== lineEnd) return false;
      const hm = v.slice(ls, lineEnd).match(/^(#{1,6})\s+(\S.*)$/);
      if (!hm || typeof this.onSplit !== 'function') return false;
      e.preventDefault();
      const local = v.split('\n');
      const headerAt = v.slice(0, ls).split('\n').length - 1;
      const before = local.slice(0, headerAt).join('\n');
      const rest = local.slice(headerAt + 1).join('\n');
      const beforeMd = this.store.blocks.slice(0, bi).map((x) => x.lines.join('\n')).concat(before ? [before] : []).join('\n\n');
      const afterMd = [rest].concat(this.store.blocks.slice(bi + 1).map((x) => x.lines.join('\n'))).filter((x) => x.trim()).join('\n\n');
      if (this.onSplit(bi, `${hm[1]} ${hm[2].trim()}`, beforeMd, afterMd)) return true;
      return false;
    } catch { return false; }
  }
  async destroy() {
    this.ready = false;
    try {
      if (this._selListener && typeof document !== 'undefined') {
        document.removeEventListener('selectionchange', this._selListener);
      }
    } catch { /* ignore */ }
    this._selListener = null;
    try {
      if (this.floatingToolbar && this.floatingToolbar.parentNode) {
        this.floatingToolbar.parentNode.removeChild(this.floatingToolbar);
      }
    } catch { /* ignore */ }
    this.floatingToolbar = null;
    this.activeInput = null;
    this.activeCE = null;
    try {
      if (this.root) {
        delete this.root._beditIO;
        delete this.root._beditDrop;
        this.root.innerHTML = '';
      }
    } catch { /* ignore */ }
  }
  /* Reads live input values back into the store without re-rendering. */
  flushInputs() {
    if (!this.root) return;
    const cards = this.root.querySelectorAll('[data-bi]');
    cards.forEach((card) => {
      const i = Number(card.dataset.bi);
      const kind = card.dataset.bkind;
      try {
        if (kind === 'figure') {
          const patch = {};
          const alt = card.querySelector('[data-f="alt"]');
          const cap = card.querySelector('[data-f="caption"]');
          const sc = card.querySelector('[data-f="scale"]');
          const pl = card.querySelector('[data-f="place"]');
          if (alt) patch.alt = alt.value;
          if (cap) patch.caption = cap.value;
          if (sc) patch.scale = clampFigureScale(sc.value);
          if (pl) patch.place = pl.value === 'full-width' ? 'full-width' : 'column';
          this.store.updateFigure(i, patch);
        } else if (kind === 'table') {
          card.querySelectorAll('[data-cell]').forEach((inp) => {
            const [r, c] = inp.dataset.cell.split(':').map(Number);
            const rows = this.store.blocks[i] ? this.store.blocks[i].lines.map(splitTableRow) : null;
            if (rows && rows[r] && c < rows[r].length && rows[r][c] !== inp.value) {
              this.store.updateTableCell(i, r, c, inp.value);
            }
          });
        } else if (kind === 'callout') {
          const title = card.querySelector('[data-c="title"]');
          const body = card.querySelector('[data-c="body"]');
          if (title || body) {
            const b = this.store.blocks[i];
            const first = (b.lines[0] || '').match(/^:::\s*(\S+)?\s*(.*)$/);
            const accent = first && first[1] ? first[1] : 'info';
            const t = title ? title.value.trim() : (first && first[2] ? first[2] : '');
            const lines = [`::: ${accent}${t ? ` ${t}` : ''}`, ...(body ? body.value.split('\n') : b.lines.slice(1, -1)), ':::'];
            b.lines = lines;
          }
        } else {
          const ce = card.querySelector('[data-ce]');
          const ta = card.querySelector('textarea[data-raw]');
          if (ce) {
            if (this._composing) return;
            const body = ceDomToMarkdown(ce).replace(/\n+$/g, '');
            const hashes = ce.dataset.hashes || '';
            const quoted = ce.dataset.quote === '1';
            const md = hashes ? `${hashes}${body}` : (quoted ? body.split('\n').map((l) => `> ${l}`).join('\n') : body);
            const cur = this.store.blocks[i] ? this.store.blocks[i].lines.join('\n') : '';
            if (md !== cur && (md.trim() || cur.trim())) this.store.updateBlockText(i, md);
          } else if (ta && ta.value !== this.store.blocks[i].lines.join('\n')) {
            this.store.updateBlockText(i, ta.value);
          }
        }
      } catch { /* per-card best effort; store keeps last good state */ }
    });
  }
  emit() {
    try { this.root.dispatchEvent(new CustomEvent('block-change', { bubbles: true })); } catch { /* ignore */ }
  }
  /* Container-level drop fallback: resolves the nearest row from the point
   * and performs the same live-index move — covers drops landing on gutters,
   * gaps, or any element whose own drop handler was swallowed. */
  bindContainerDrop() {
    if (!this.root || this.root._beditDrop) return;
    this.root._beditDrop = true;
    const clearDropLine = () => {
      try { this.root.querySelectorAll('.bedit-drop-line').forEach((d) => d.remove()); } catch { /* cosmetic */ }
    };
    const showDropLine = (rowEl, clientY) => {
      if (!rowEl || typeof document === 'undefined') return;
      try {
        clearDropLine();
        const r = rowEl.getBoundingClientRect();
        const line = document.createElement('div');
        line.className = 'bedit-drop-line';
        line.setAttribute('aria-hidden', 'true');
        if (clientY < r.top + r.height / 2) rowEl.before(line);
        else rowEl.after(line);
      } catch { /* cosmetic */ }
    };
    this.root._beditClearDropLine = clearDropLine;
    const rowIndexAt = (clientY) => {
      const rows = Array.from(this.root.querySelectorAll('.bedit-row'));
      for (let k = 0; k < rows.length; k++) {
        const r = rows[k].getBoundingClientRect();
        if (clientY < r.top + r.height / 2) return k;
      }
      return rows.length;
    };
    this.root.addEventListener('dragover', (e) => {
      if (!this.root.querySelector('.bedit-dragging')) return;
      e.preventDefault();
      // Edge auto-scroll: dragging near the container rim scrolls the list
      // so below-the-fold rows become real drop targets.
      try {
        const r = this.root.getBoundingClientRect();
        const EDGE = 64, STEP = 14;
        if (e.clientY > r.bottom - EDGE) this.root.scrollTop += STEP;
        else if (e.clientY < r.top + EDGE) this.root.scrollTop -= STEP;
      } catch { /* scroll is best effort */ }
      // Live drop-line fallback for gutter/gap hovers: pin the line to the
      // nearest row so the landing reads even without a row hover.
      try {
        const rows = Array.from(this.root.querySelectorAll('.bedit-row'));
        const idx = rowIndexAt(e.clientY);
        showDropLine(rows[Math.min(idx, rows.length - 1)] || null, e.clientY);
      } catch { /* cosmetic */ }
    });
    this.root.addEventListener('drop', (e) => {
      const dragEl = this.root.querySelector('.bedit-dragging');
      if (!dragEl) return;
      e.preventDefault();
      clearDropLine();
      this.root.classList.remove('bedit-drag-active');
      let fromIdx = NaN;
      try { fromIdx = Number(e.dataTransfer.getData('text/plain')); } catch { /* noop */ }
      if (!Number.isFinite(fromIdx)) fromIdx = Number(dragEl.dataset.bi);
      // Intent-first: the last hover-highlighted row is the target the user
      // saw (robust against scroll-shifted final points); point math fallback.
      const hovered = this.root.querySelector('.bedit-row.bedit-drag-over');
      const rowCount = this.root.querySelectorAll('.bedit-row').length;
      let toIdx;
      if (hovered) {
        const rows = Array.from(this.root.querySelectorAll('.bedit-row'));
        toIdx = resolveDropIndex(fromIdx, rows.indexOf(hovered), rowCount);
      } else {
        const pt = rowIndexAt(e.clientY);
        toIdx = resolveDropIndex(fromIdx, pt >= rowCount ? null : pt, rowCount);
      }
      if (!Number.isFinite(fromIdx) || fromIdx === toIdx) return;
      this.flushInputs();
      this.checkpoint();
      this.store.moveBlock(fromIdx, toIdx);
      this.root._dndDropped = true;
      this.render();
      this.emit();
    });
  }
  render() {
    if (!this.root) return;
    const md = this.store.getMarkdown();
    this.root.innerHTML = '';
    const frag = typeof document !== 'undefined' ? document.createDocumentFragment() : null;
    
    // Initial insert gutter at position 0
    if (frag) frag.appendChild(this.createInsertGutter(0));

    // M3: blockless content hints instead of blanking. The hint reuses the
    // .bedit-empty style and inserts a paragraph on tap; serialization reads
    // the store, so the hint row never leaks into markdown.
    if (frag && this.store.blocks.length === 0) {
      const empty = document.createElement('button');
      empty.type = 'button';
      empty.className = 'bedit-empty';
      empty.textContent = 'Escreva ou toque em + para começar';
      empty.setAttribute('aria-label', 'Começar a escrever: inserir parágrafo');
      empty.addEventListener('click', () => this.handleInsertAt(0, 'p'));
      frag.appendChild(empty);
    }

    const lastIdx = this.store.blocks.length - 1;
    this.store.blocks.forEach((b, i) => {
      const card = this.cardFor(b, i);
      if (frag) {
        frag.appendChild(card);
        // Inter-block gutters only: the trailing "+" after the last block
        // is intentionally omitted — the sticky composer footer below is the
        // single bottom insert affordance ("Adicionar elemento").
        if (i < lastIdx) frag.appendChild(this.createInsertGutter(i + 1));
      }
    });
    // Sticky composer footer (R3): bottom "+" always reachable in long docs.
    if (frag) {
      const composer = document.createElement('div');
      composer.className = 'rich-composer';
      composer.innerHTML = `
        <button type="button" class="bedit-plus-btn" title="Adicionar elemento ao final" aria-label="Adicionar elemento ao final"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-plus"/></svg></button>
        <span class="rich-composer-label">Adicionar elemento</span>
      `;
      composer.querySelector('.bedit-plus-btn')?.addEventListener('click', (e) => {
        e.stopPropagation();
        // Same unified catalog as every other insert surface (gutters,
        // slash menus, markdown bar) — picking "where" never changes "what".
        this.openPortalMenu(composer.querySelector('.bedit-plus-btn'), INSERT_ITEMS, (type) => {
          this.handleInsertAt(this.store.blocks.length, type);
          requestAnimationFrame(() => {
            const rows = this.root.querySelectorAll('.bedit-row');
            rows[rows.length - 1]?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
          });
        });
      });
      frag.appendChild(composer);
    }
    if (frag) {
      this.root.appendChild(frag);
    }
    void md;
  }

  /* Gutter keeps only the "+" anchor in-flow; the menu itself renders in
   * the body portal (L1) so no scroll container can clip it. */
  createInsertGutter(insertIndex) {
    const gutter = document.createElement('div');
    gutter.className = 'bedit-gutter';
    gutter.dataset.gutterIdx = String(insertIndex);
    gutter.innerHTML = `
      <div class="bedit-gutter-line"></div>
      <button type="button" class="bedit-plus-btn" title="Inserir elemento aqui" aria-label="Inserir elemento na posição ${insertIndex}">
        <svg class="ic" aria-hidden="true"><use href="./icons.svg#i-plus"/></svg>
      </button>
    `;

    const btn = gutter.querySelector('.bedit-plus-btn');
    btn?.addEventListener('click', (e) => {
      e.stopPropagation();
      // Full unified catalog — identical to the bottom composer menu.
      this.openPortalMenu(btn, INSERT_ITEMS, (type) => this.handleInsertAt(insertIndex, type));
    });

    return gutter;
  }

  /* Shared portal menu: one floating panel in #ui-portal, anchored under
   * the clicked button, viewport-clamped, Esc/backdrop dismisses. */
  openPortalMenu(anchorBtn, items = [], onPick = null) {
    const portal = menuShelf() || uiPortal();
    if (!portal || !anchorBtn) return;
    portal.innerHTML = '';
    portal.setAttribute('aria-hidden', 'false');
    const menu = document.createElement('div');
    menu.className = 'bedit-quick-menu portal-open';
    menu.setAttribute('role', 'menu');
    menu.setAttribute('aria-label', 'Inserir elemento');
    menu.innerHTML = items.map((it) =>
      `<button type="button" role="menuitem" data-ins="${it.key}"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-${it.sym || 'plus'}"/></svg> <span>${escHtml(it.label)}</span></button>`
    ).join('');
    portal.appendChild(menu);
    const r = anchorBtn.getBoundingClientRect();
    const mw = 360, mh = 240;
    const left = Math.max(8, Math.min(r.left - mw / 2 + r.width / 2, document.documentElement.clientWidth - mw - 8));
    const below = r.bottom + 6;
    const above = r.top - mh - 6;
    const fitsBelow = below + mh <= window.innerHeight - 8;
    menu.style.position = 'fixed';
    menu.style.left = `${left}px`;
    menu.style.top = `${(fitsBelow ? below : Math.max(8, above))}px`;
    const close = () => { menu.remove(); portal.setAttribute('aria-hidden', 'true'); document.removeEventListener('pointerdown', onDoc, true); document.removeEventListener('keydown', onKey, true); };
    const onDoc = (e) => { if (!menu.contains(e.target) && e.target !== anchorBtn) close(); };
    const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
    document.addEventListener('pointerdown', onDoc, true);
    document.addEventListener('keydown', onKey, true);
    menu.querySelectorAll('[data-ins]').forEach((item) => {
      item.addEventListener('click', (e) => {
        e.stopPropagation();
        const type = item.dataset.ins;
        close();
        if (typeof onPick === 'function') onPick(type);
      });
    });
    // M6 roving focus: arrows/Home/End move through items (Enter picks
    // natively, Esc closes via onKey). Shared slashNavIndex wrap-around;
    // scrollIntoView keeps focus visible in viewport-capped menus (W10).
    menu.addEventListener('keydown', (e) => {
      if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp' && e.key !== 'Home' && e.key !== 'End') return;
      e.preventDefault();
      const btns = Array.from(menu.querySelectorAll('[data-ins]'));
      if (!btns.length) return;
      const cur = btns.indexOf(document.activeElement);
      const next = slashNavIndex(e.key === 'Home' ? 'first' : e.key === 'End' ? 'last' : e.key, cur, btns.length);
      btns[next]?.focus();
      try { btns[next]?.scrollIntoView?.({ block: 'nearest' }); } catch { /* cosmetic */ }
    });
    menu.querySelector('button')?.focus();
  }

  /* Slash-command menu: typing "/" at a blank line start opens a portal
   * menu that either TRANSFORMS the current block (h1/h2/h3/quote when the
   * line has content) or INSERTS after it (empty line). Live-filtered. */
  openSlashMenu(ta, blockIdx) {
    const portal = menuShelf() || uiPortal();
    if (!portal) return;
    const v = ta.value, s = ta.selectionStart;
    const ls = v.lastIndexOf('\n', s - 1) + 1;
    const lineHasContent = v.slice(ls, s).trim().length > 0;
    const lineText = v.slice(ls).split('\n')[0];
    const items = lineHasContent
      ? [
          { key: 'h1', sym: 'h1', label: 'Título 1 — transformar linha', transform: '# ' },
          { key: 'h2', sym: 'h1', label: 'Título 2 — transformar linha', transform: '## ' },
          { key: 'h3', sym: 'h1', label: 'Título 3 — transformar linha', transform: '### ' },
          { key: 'h4', sym: 'h4', label: 'Título 4 — transformar linha', transform: '#### ' },
          { key: 'quote', sym: 'quote', label: 'Citação — transformar linha', transform: '> ' },
          { key: 'ul', sym: 'ul', label: 'Lista — transformar linha', list: 'ul' },
          { key: 'ol', sym: 'ol', label: 'Numerada — transformar linha', list: 'ol' },
          { key: 'p', sym: 'para', label: 'Texto — remover prefixo', transform: '' },
        ]
      : INSERT_ITEMS;
    portal.innerHTML = '';
    portal.setAttribute('aria-hidden', 'false');
    const wrap = document.createElement('div');
    wrap.className = 'bedit-slash-wrap portal-open';
    wrap.innerHTML = `
      <input class="text-input sm bedit-slash-filter" placeholder="/filtrar…  (Esc fecha)" aria-label="Filtrar comandos">
      <div class="bedit-quick-menu bedit-slash-menu" role="menu"></div>`;
    const menu = wrap.querySelector('.bedit-slash-menu');
    const filter = wrap.querySelector('.bedit-slash-filter');
    menu.setAttribute('role', 'listbox');
    filter.setAttribute('role', 'combobox');
    filter.setAttribute('aria-expanded', 'true');
    filter.setAttribute('aria-controls', 'bedit-slash-list');
    filter.setAttribute('aria-autocomplete', 'list');
    menu.id = 'bedit-slash-list';
    let activeIdx = 0;
    const caretPos = ta.selectionStart;
    const paintActive = () => {
      const btns = Array.from(menu.querySelectorAll('[data-ins]'));
      btns.forEach((b, k) => {
        const on = k === activeIdx;
        b.classList.toggle('is-active', on);
        b.setAttribute('aria-selected', on ? 'true' : 'false');
        if (on) filter.setAttribute('aria-activedescendant', `slash-${b.dataset.ins}`);
      });
      if (btns.length === 0) filter.removeAttribute('aria-activedescendant');
      else {
        const cur = btns[activeIdx];
        try { cur?.scrollIntoView?.({ block: 'nearest' }); } catch { /* cosmetic */ }
      }
    };
    portal.appendChild(wrap);
    const r = ta.getBoundingClientRect();
    wrap.style.position = 'fixed';
    wrap.style.left = `${Math.max(8, Math.min(r.left, document.documentElement.clientWidth - 400))}px`;
    wrap.style.top = `${Math.max(8, r.top + 24)}px`;
    const render = (q = '') => {
      const ql = q.toLowerCase().replace(/^\//, '');
      const shown = items
        .filter((it) => !ql || it.label.toLowerCase().includes(ql) || it.key.includes(ql));
      menu.innerHTML = shown
        .map((it) => `<button type="button" role="option" id="slash-${it.key}" data-ins="${it.key}" aria-selected="false"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-${it.sym || 'plus'}"/></svg> <span>${escHtml(it.label)}</span></button>`)
        .join('') || '<p class="bedit-slash-empty">Nenhum comando</p>';
      activeIdx = slashNavIndex('reset', activeIdx, shown.length);
      menu.querySelectorAll('[data-ins]').forEach((btn, k) => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          pick(btn.dataset.ins);
        });
        btn.addEventListener('mousemove', () => {
          if (activeIdx !== k) { activeIdx = k; paintActive(); }
        });
      });
      paintActive();
    };
    const close = (restoreCaret = false) => {
      wrap.remove();
      try { this.root._beditClearDropLine?.(); } catch { /* cosmetic */ }
      portal.setAttribute('aria-hidden', 'true');
      document.removeEventListener('pointerdown', onDoc, true);
      if (restoreCaret) {
        try {
          ta.focus();
          ta.setSelectionRange(caretPos, caretPos);
        } catch { /* keep focus */ }
      }
    };
    const onDoc = (e) => { if (!wrap.contains(e.target) && e.target !== ta) close(); };
    document.addEventListener('pointerdown', onDoc, true);
    const pick = (type) => {
      const item = items.find((x) => x.key === type);
      close();
      if (!item) return;
      if (item.list) {
        // List transform routes through the pure list command (multi-line
        // aware, toggle + renumber) — same seam as toolbar/shortcuts.
        this.flushInputs();
        const b = this.store.blocks[blockIdx];
        const plain = b ? b.lines.join('\n') : ta.value;
        const at = ta.selectionStart ?? plain.length;
        this.execCommand(item.list, blockIdx, at, at);
        try { ta.focus(); } catch { /* keep focus */ }
      } else if (item.transform !== undefined) {
        // Block transformation: swap the line prefix in place.
        this.checkpoint();
        const cur = lineText.match(/^(#{1,6}\s+|>+\s*)/);
        const nv = ta.value;
        const nls = nv.lastIndexOf('\n', ta.selectionStart - 1) + 1;
        ta.value = cur
          ? nv.slice(0, nls) + item.transform + nv.slice(nls + cur[0].length)
          : nv.slice(0, nls) + item.transform + nv.slice(nls);
        ta.focus();
        ta.dispatchEvent(new Event('input', { bubbles: true }));
      } else {
        this.handleInsertAt(blockIdx + 1, type);
      }
    };
    filter.addEventListener('input', () => render(filter.value));
    filter.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') { e.stopPropagation(); close(true); }
      else if (e.key === 'Enter') {
        e.preventDefault();
        const btns = Array.from(menu.querySelectorAll('[data-ins]'));
        const target = btns[activeIdx] || btns[0];
        if (target) pick(target.dataset.ins);
      } else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        const btns = Array.from(menu.querySelectorAll('[data-ins]'));
        activeIdx = slashNavIndex(e.key, activeIdx, btns.length);
        paintActive();
      }
    });
    render('');
    filter.focus();
  }

  handleInsertAt(index, type) {
    if (type === 'fig') {
      // Trigger upload or modal directly targeting this position
      this.root.dispatchEvent(new CustomEvent('insert-figure-at', {
        bubbles: true,
        detail: { insertIndex: index }
      }));
      return;
    }
    const snippet = `${insertSnippetFor(type) || ''}\n`;
    if (!snippet.trim()) return;

    this.checkpoint();
    this.store.insertBlockAt(index, snippet);
    this.render();
    this.emit();
  }
  cardFor(b, i) {
    const el = document.createElement('div');
    el.className = `bedit-row bedit-${b.kind}`;
    el.dataset.bi = String(i);
    el.dataset.bkind = b.kind;
    el.setAttribute('role', 'group');
    el.setAttribute('aria-label', `Elemento ${i + 1}: ${rowBadge(b.kind)}`);
    // Perpetually draggable: Chrome samples draggability at mousedown entry,
    // so mid-press arming never wins. Non-grip drags are vetoed in dragstart.
    el.setAttribute('draggable', 'true');
    const badge = rowBadge(b.kind);
    // Heading level pill (Direta/CE mode only): persistent H1–H4 indicator
    // docked right of the drag handle (clears the 52px content indent via
    // the heading row's widened left padding). Level refreshes live via
    // updateLevelPill. setCEEnabled re-renders, so toggles rebuild it.
    const hlMatch = (this.ceEnabled === true && b.kind === 'heading') ? b.lines.join('\n').match(/^(#{1,6})\s/) : null;
    const hl = hlMatch ? hlMatch[1].length : 0;
    let inner = `
      <div class="bedit-row-gutter${hl ? ' has-level' : ''}">
        <button type="button" class="bedit-drag-handle" title="Arrastar para reordenar (ou Alt+↑/↓)" aria-label="Reordenar elemento ${i + 1}"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-grip"/></svg></button>
        ${hl ? `<span class="bedit-level-pill" title="Título nível ${hl}">H${hl}</span>` : ''}
      </div>
      <div class="bedit-row-chrome">
        <span class="bedit-badge">${escHtml(badge)}</span>
        <div class="bedit-card-spacer"></div>
        <button type="button" class="bedit-card-del-btn" data-remove="${i}" title="Excluir elemento" aria-label="Excluir elemento"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-close"/></svg></button>
      </div>
    `;
    if (b.kind === 'figure') {
      inner += figureBodyHTML(b, i);
    } else if (b.kind === 'table') {
      inner += tableBodyHTML(b, i);
    } else if (b.kind === 'callout') {
      inner += calloutBodyHTML(b);
    } else if (b.kind === 'rule') {
      inner += ruleBodyHTML();
    } else {
      inner += textBodyHTML(b, i, {
        ceEnabled: this.ceEnabled === true,
        previewEnabled: this.previewEnabled === true,
        activeTab: this._tabByBlock.get(b) || 'preview',
      });
    }
    el.innerHTML = inner;
    // Wire contentEditable surface (Phase 3 gated): caret saved as plain
    // offset before sync, IME compositions never sync, Enter inside a
    // figure island exits back to text per ceFigureCommand.
    el.querySelectorAll('[data-ce]').forEach((ce) => {
      ce.addEventListener('compositionstart', () => { this._composing = true; });
      ce.addEventListener('compositionend', () => {
        this._composing = false;
        this.syncCard(el, i);
        this.emit();
      });
      ce.addEventListener('beforeinput', (e) => {
        if (!ceShouldSync(this._composing, e.inputType)) { e.preventDefault(); return; }
        try {
          const off = ceRangeOffsets(ce);
          if (off) ce._savedCaret = ceSaveCaret(ce.textContent.length, off.start);
        } catch { /* caret restore is best effort */ }
      });
      ce.addEventListener('input', () => {
        if (!ceShouldSync(this._composing, 'insertText')) return;
        this.syncCard(el, i);
        this.updateLevelPill(el, i);
        const ta = el.querySelector('textarea[data-raw]');
        if (ta) {
          const cur = this.store.blocks[i] ? this.store.blocks[i].lines.join('\n') : '';
          if (ta.value !== cur) ta.value = cur;
        }
        this.emit();
      });
      ce.addEventListener('keydown', (e) => {
        const cmd = ceFigureCommand(e.key, false);
        if (cmd === 'enter-island') {
          const fig = el.parentElement ? el.parentElement.querySelector('[data-bkind="figure"]') : null;
          const target = fig ? (fig.querySelector('[data-f="alt"]') || fig) : null;
          if (target) { e.preventDefault(); try { target.focus(); } catch { /* ignore */ } }
        }
      });
    });
    // Wire inputs: edit in place, emit change, never remount. Raw textareas
    // also refresh their styled preview live.
    el.querySelectorAll('textarea[data-raw], input[data-cell], input[data-c="title"], textarea[data-c="body"], input[data-f="alt"], input[data-f="caption"]').forEach((inp) => {
      inp.addEventListener('compositionstart', () => { this._composing = true; });
      inp.addEventListener('compositionend', () => {
        this._composing = false;
        this.syncCard(el, i);
        this.updateLevelPill(el, i);
        if (inp.hasAttribute('data-raw')) this.refreshPreview(el);
        this.emit();
      });
      inp.addEventListener('input', () => {
        if (this._composing) return;
        this.syncCard(el, i);
        this.updateLevelPill(el, i);
        if (inp.hasAttribute('data-raw')) this.refreshPreview(el);
        this.emit();
      });
    });
    // Tabbed Preview/Edit seam: single visible surface per text row. Tab
    // clicks flip panes in place (no remount); clicking the preview maps
    // the click fraction onto the textarea caret, then opens the edit tab.
    el.querySelectorAll('.bedit-viewtabs [data-tab]').forEach((btn) => {
      btn.addEventListener('click', () => this.switchTab(el, i, btn.dataset.tab));
    });
    const pv = el.querySelector('.bedit-preview');
    const ta = el.querySelector('textarea[data-raw]');
    if (pv && ta) {
      pv.setAttribute('role', 'button');
      pv.setAttribute('tabindex', '0');
      pv.setAttribute('title', 'Clique para editar');
      const editAtFraction = (clientX) => {
        let frac = 1;
        try {
          const r = pv.getBoundingClientRect();
          if (r && r.width > 0 && typeof clientX === 'number') {
            frac = Math.max(0, Math.min(1, (clientX - r.left) / r.width));
          }
        } catch { /* caret to end */ }
        this.switchTab(el, i, 'edit');
        try {
          ta.focus({ preventScroll: false });
          const pos = Math.round(ta.value.length * frac);
          ta.setSelectionRange(pos, pos);
        } catch { try { ta.focus(); } catch { /* ignore */ } }
      };
      pv.addEventListener('click', (e) => editAtFraction(e.clientX));
      pv.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); editAtFraction(); }
      });
    }
    el.querySelectorAll('input[data-f="scale"], input[data-f="scale-num"], select[data-f="place"]').forEach((inp) => {
      inp.addEventListener(inp.tagName === 'SELECT' ? 'change' : 'input', () => {
        if (inp.dataset.f === 'scale' || inp.dataset.f === 'scale-num') {
          const v = clampFigureScale(inp.value);
          const range = el.querySelector('input[data-f="scale"]');
          const num = el.querySelector('input[data-f="scale-num"]');
          const label = el.querySelector('.bedit-field span');
          if (range && range !== inp) range.value = String(v);
          if (num && num !== inp) num.value = String(v);
          if (label && label.textContent.startsWith('Escala')) label.textContent = `Escala (${Math.round(v * 100)}%)`;
        }
        this.syncCard(el, i);
        this.emit();
      });
    });
    // Wire image double-click and modal-edit button
    // Phase 3 islands: Esc inside figure inputs exits back to the
    // nearest text CE surface (or its readout) per ceFigureCommand.
    if (b.kind === 'figure') {
      const imgThumb = el.querySelector('.bedit-figthumb');
      const triggerModal = () => {
        const f = parseFigureLine(b.lines.join('\n'));
        if (f) {
          this.root.dispatchEvent(new CustomEvent('edit-figure', {
            bubbles: true,
            detail: { blockIndex: i, figure: f }
          }));
        }
      };
      if (imgThumb) imgThumb.addEventListener('dblclick', triggerModal);
      const qkBtn = el.querySelector('[data-act="quick-edit"]');
      if (qkBtn) qkBtn.addEventListener('click', (e) => { e.stopPropagation(); triggerModal(); });
      const mdBtn = el.querySelector('[data-act="modal-edit"]');
      if (mdBtn) mdBtn.addEventListener('click', triggerModal);
      el.querySelectorAll('input[data-f], select[data-f]').forEach((inp) => {
        inp.addEventListener('keydown', (e) => {
          if (ceFigureCommand(e.key, true) !== 'exit-island') return;
          e.preventDefault();
          const cards = this.root ? Array.from(this.root.querySelectorAll('[data-bi]')) : [];
          const idx = cards.indexOf(el);
          for (let k = idx - 1; k >= 0; k--) {
            const back = cards[k].querySelector('[data-ce]') || cards[k].querySelector('textarea[data-raw]');
            if (back) { try { back.focus(); } catch { /* ignore */ } break; }
          }
        });
      });
    }

    // Wire table inline buttons (Add Col, Add Row, Delete Col, Delete Row, Align Toggle)
    // Table cell edits stay in place via syncCard (no remount); structural
    // ops checkpoint for undo then re-render the island only.
    if (b.kind === 'table') {
      const addCol = el.querySelector('[data-tbl-act="add-col"]');
      if (addCol) addCol.addEventListener('click', () => {
        this.checkpoint();
        this.store.addTableColumn(i);
        this.render();
        this.emit();
      });

      const addRow = el.querySelector('[data-tbl-act="add-row"]');
      if (addRow) addRow.addEventListener('click', () => {
        this.checkpoint();
        this.store.addTableRow(i);
        this.render();
        this.emit();
      });

      el.querySelectorAll('[data-col-del]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const c = Number(btn.dataset.colDel);
          this.checkpoint();
          this.store.deleteTableColumn(i, c);
          this.render();
          this.emit();
        });
      });

      el.querySelectorAll('[data-row-del]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const r = Number(btn.dataset.rowDel);
          this.checkpoint();
          this.store.deleteTableRow(i, r);
          this.render();
          this.emit();
        });
      });

      el.querySelectorAll('[data-col-align]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const c = Number(btn.dataset.colAlign);
          const rows = b.lines.map(splitTableRow);
          const isDelim = (r) => isDelimiterRow(b.lines[r]);
          let curAlign = 'left';
          if (rows.length > 1 && isDelim(1) && rows[1][c]) {
            const raw = rows[1][c].trim();
            curAlign = /^:.*:$/.test(raw) ? 'center' : /:$/.test(raw) ? 'right' : 'left';
          }
          const nextAlign = curAlign === 'left' ? 'center' : curAlign === 'center' ? 'right' : 'left';
          this.checkpoint();
          this.store.setTableColAlign(i, c, nextAlign);
          this.render();
          this.emit();
        });
      });
    }

    // Block Drag-and-Drop Reordering via gutter handle (R2).
    // Pointer-capture arm/disarm; drop resolves live DOM index; Alt+Up/Down
    // keyboard fallback moves the block without any pointer.
    const handle = el.querySelector('.bedit-drag-handle');
    handle?.addEventListener('keydown', (e) => {
      if (e.altKey && (e.key === 'ArrowUp' || e.key === 'ArrowDown')) {
        e.preventDefault();
        const dir = e.key === 'ArrowUp' ? -1 : 1;
        const cur = Number(el.dataset.bi);
        const to = cur + dir;
        if (to < 0 || to >= this.store.blocks.length) return;
        this.flushInputs();
        this.checkpoint();
        this.store.moveBlock(cur, to);
        this.render();
        this.emit();
        this.root.querySelector(`[data-bi="${to}"] .bedit-drag-handle`)?.focus();
      }
    });
    if (handle) {
      // Grip press marks the row armed; dragstart (fired by Chrome only for
      // draggable elements) vetoes anything not grip-armed — this keeps
      // textarea text-selection drags out of the reorder path.
      handle.addEventListener('mousedown', () => {
        el.dataset.armed = '1';
      });
      handle.addEventListener('mouseup', () => {
        delete el.dataset.armed;
      });
      el.addEventListener('dragstart', (e) => {
        if (!el.dataset.armed) { e.preventDefault(); return; }
        e.dataTransfer.setData('text/plain', String(i));
        e.dataTransfer.effectAllowed = 'move';
        el.classList.add('bedit-dragging');
        // Textareas/inputs swallow dragover+drop (never dispatched, not even
        // to document capture). Blind them mid-flight so the row beneath
        // receives the gesture; restored on dragend/drop.
        this.root.classList.add('bedit-drag-active');
      });
      el.addEventListener('dragend', () => {
        // Release where no drop dispatched (gaps, composer, list edges):
        // commit the last hover-highlighted row once. Skipped when a drop
        // handler already moved (flag), avoiding a double move.
        if (!this.root._dndDropped) {
          const hovered = this.root.querySelector('.bedit-row.bedit-drag-over');
          const fromIdx = Number(el.dataset.bi);
          if (hovered) {
            const rows = Array.from(this.root.querySelectorAll('.bedit-row'));
            const toIdx = resolveDropIndex(fromIdx, rows.indexOf(hovered), rows.length);
            if (Number.isFinite(fromIdx) && fromIdx !== toIdx) {
              try {
                this.flushInputs();
                this.checkpoint();
                this.store.moveBlock(fromIdx, toIdx);
                this.render();
                this.emit();
              } catch { /* gesture is best effort */ }
            }
          }
        }
        this.root._dndDropped = false;
        delete el.dataset.armed;
        el.classList.remove('bedit-dragging');
        this.root.classList.remove('bedit-drag-active');
        this.root.querySelectorAll('.bedit-row').forEach(c => c.classList.remove('bedit-drag-over'));
        try { this.root._beditClearDropLine?.(); } catch { /* cosmetic */ }
      });
      // dragover always preventDefaults while a row-drag is in flight:
      // gating on dataTransfer.types breaks headless drops (types read
      // empty mid-gesture), which vetoes the drop entirely.
      const dragInFlight = () => !!this.root.querySelector('.bedit-dragging');
      const pinDropLine = (target, clientY) => {
        try {
          this.root._beditClearDropLine?.();
          if (typeof document === 'undefined') return;
          const line = document.createElement('div');
          line.className = 'bedit-drop-line';
          line.setAttribute('aria-hidden', 'true');
          const r = target.getBoundingClientRect();
          if (clientY < r.top + r.height / 2) target.before(line);
          else target.after(line);
        } catch { /* cosmetic */ }
      };
      el.addEventListener('dragenter', (e) => {
        if (dragInFlight()) { e.preventDefault(); el.classList.add('bedit-drag-over'); pinDropLine(el, e.clientY); }
      });
      el.addEventListener('dragover', (e) => {
        if (dragInFlight()) {
          e.preventDefault();
          try { e.dataTransfer.dropEffect = 'move'; } catch { /* noop */ }
          el.classList.add('bedit-drag-over');
          pinDropLine(el, e.clientY);
        }
      });
      el.addEventListener('dragleave', () => {
        el.classList.remove('bedit-drag-over');
      });
      el.addEventListener('drop', (e) => {
        {
          this.root.classList.remove('bedit-drag-active');
          e.preventDefault();
          el.classList.remove('bedit-drag-over');
          try { this.root._beditClearDropLine?.(); } catch { /* cosmetic */ }
          let fromIdx = NaN;
          try { fromIdx = Number(e.dataTransfer.getData('text/plain')); } catch { /* no payload */ }
          if (!Number.isFinite(fromIdx)) {
            const dragEl = this.root.querySelector('.bedit-dragging');
            fromIdx = dragEl ? Number(dragEl.dataset.bi) : NaN;
          }
          // Resolved index lives in this card's own data ordinal.
          const rows = Array.from(this.root.querySelectorAll('.bedit-row'));
          const afterIdx = rows.indexOf(el);
          const toIdx = resolveDropIndex(fromIdx, afterIdx, rows.length);
          if (Number.isFinite(fromIdx) && fromIdx !== toIdx) {
            this.flushInputs();
            this.checkpoint();
            this.store.moveBlock(fromIdx, toIdx);
            this.root._dndDropped = true;
            this.render();
            this.emit();
          }
        }
      });
    }

    const rm = el.querySelectorAll('[data-remove]');
    rm.forEach(btn => btn.addEventListener('click', () => {
      this.checkpoint();
      this.store.removeBlock(i);
      this.render();
      this.emit();
    }));
    return el;
  }
  /* Live heading-level pill: re-reads the store block after each keystroke
   * and creates/updates/removes the H1–H6 tag docked right of the drag
   * handle. Full re-renders (toolbar transforms, undo, DnD) rebuild the
   * pill from scratch in cardFor; this covers in-place typing only. */
  updateLevelPill(el, i) {
    try {
      const b = this.store.blocks[i];
      const gutter = el.querySelector?.('.bedit-row-gutter');
      if (!b || !gutter || typeof document === 'undefined') return;
      // Direta-only: without the CE surface there is no pill to maintain.
      if (this.ceEnabled !== true) {
        gutter.querySelector('.bedit-level-pill')?.remove();
        gutter.classList.remove('has-level');
        return;
      }
      const m = b.kind === 'heading' ? b.lines.join('\n').match(/^(#{1,6})\s/) : null;
      let pill = gutter.querySelector('.bedit-level-pill');
      if (!m) {
        pill?.remove();
        gutter.classList.remove('has-level');
        return;
      }
      const n = m[1].length;
      gutter.classList.add('has-level');
      if (!pill) {
        pill = document.createElement('span');
        pill.className = 'bedit-level-pill';
        gutter.appendChild(pill);
      }
      const label = `H${n}`;
      if (pill.textContent !== label) pill.textContent = label;
      pill.setAttribute('title', `Título nível ${n}`);
    } catch { /* indicator is cosmetic; store is authoritative */ }
  }
  /* Tabbed Preview/Edit seam: flips the two panes of one card in place
   * (no remount, no caret loss beyond the switch). Persists per-block so
   * typing + undo + DnD re-renders keep the user's chosen tab. */
  switchTab(el, i, tab) {
    try {
      const b = this.store.blocks[Number(i) || 0];
      const want = tab === 'edit' ? 'edit' : 'preview';
      if (b) this._tabByBlock.set(b, want);
      if (!el) return want;
      const isPrev = want !== 'edit';
      const pv = el.querySelector('[data-pane="preview"]');
      const ta = el.querySelector('textarea[data-pane="edit"]');
      if (pv) pv.classList.toggle('hidden', !isPrev);
      if (ta) {
        ta.classList.toggle('hidden', isPrev);
        if (isPrev) ta.setAttribute('tabindex', '-1');
        else ta.removeAttribute('tabindex');
      }
      el.querySelectorAll('.bedit-viewtabs [data-tab]').forEach((btn) => {
        btn.setAttribute('aria-selected', btn.dataset.tab === want ? 'true' : 'false');
      });
      return want;
    } catch { return tab; }
  }
  /* Re-renders a card's styled readout from its live textarea (L3). */
  refreshPreview(el) {
    try {
      const ta = el.querySelector('textarea[data-raw]');
      const pv = el.querySelector('.bedit-preview');
      if (!ta || !pv) return;
      const raw = ta.value;
      const hm = raw.match(/^(#{1,6})\s+(.*)$/s);
      const isQuote = raw.split('\n').every((l) => /^\s*>/.test(l) || !l.trim());
      const base = 'bedit-preview';
      const keepHidden = pv.classList.contains('hidden') ? ' hidden' : '';
      if (hm) {
        pv.className = `${base} bedit-preview-h${Math.min(hm[1].length, 4)}${keepHidden}`;
        pv.innerHTML = renderStyledPreview(hm[2]);
      } else if (isQuote && raw.trim()) {
        pv.className = `${base} bedit-preview-quote${keepHidden}`;
        pv.innerHTML = renderStyledPreview(raw.split('\n').map((l) => l.replace(/^\s*>\s?/, '')).join('\n'));
      } else {
        pv.className = `${base}${keepHidden}`;
        pv.innerHTML = renderStyledPreview(raw);
      }
    } catch { /* readout is cosmetic; store is authoritative */ }
  }
  /* Pushes one card's inputs into the store without touching other cards. */
  syncCard(el, i) {
    const kind = el.dataset.bkind;
    const b = this.store.blocks[i];
    if (!b) return;
    if (kind === 'figure') {
      const patch = {};
      const alt = el.querySelector('[data-f="alt"]');
      const cap = el.querySelector('[data-f="caption"]');
      const sc = el.querySelector('[data-f="scale-num"]') || el.querySelector('[data-f="scale"]');
      const pl = el.querySelector('[data-f="place"]');
      if (alt) patch.alt = alt.value;
      if (cap) patch.caption = cap.value;
      if (sc) patch.scale = clampFigureScale(sc.value);
      if (pl) patch.place = pl.value === 'full-width' ? 'full-width' : 'column';
      this.store.updateFigure(i, patch);
    } else if (kind === 'table') {
      el.querySelectorAll('[data-cell]').forEach((inp) => {
        const [r, c] = inp.dataset.cell.split(':').map(Number);
        this.store.updateTableCell(i, r, c, inp.value);
      });
    } else if (kind === 'callout') {
      const title = el.querySelector('[data-c="title"]');
      const body = el.querySelector('[data-c="body"]');
      const first = (b.lines[0] || '').match(/^:::\s*(\S+)?\s*(.*)$/);
      const accent = (first && first[1]) || 'info';
      const t = title ? title.value.trim() : '';
      b.lines = [`::: ${accent}${t ? ` ${t}` : ''}`, ...(body ? body.value.split('\n') : []), ':::'];
    } else {
      const ce = el.querySelector('[data-ce]');
      const ta = el.querySelector('textarea[data-raw]');
      if (ce) {
        if (this._composing) return;
        const body = ceDomToMarkdown(ce).replace(/\n+$/g, '');
        const hashes = ce.dataset.hashes || '';
        const quoted = ce.dataset.quote === '1';
        const md = hashes ? `${hashes}${body}` : (quoted ? body.split('\n').map((l) => `> ${l}`).join('\n') : body);
        const cur = b.lines.join('\n');
        if (md !== cur && (md.trim() || cur.trim())) this.store.updateBlockText(i, md);
        if (ta && ta.value !== this.store.blocks[i].lines.join('\n')) ta.value = this.store.blocks[i].lines.join('\n');
      } else if (ta) this.store.updateBlockText(i, ta.value);
    }
  }
  highlight(_start, _end, query = '') {
    // Offset-free rich highlight: locate query text in rendered cards + flash.
    // String offsets belong to markdown mode; here we scroll to the match.
    try {
      this.root.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      if (query && typeof document !== 'undefined') {
        const walker = document.createTreeWalker(this.root, 4 /* NodeFilter.SHOW_TEXT */);
        const q = String(query).toLowerCase();
        let node = null;
        while ((node = walker.nextNode())) {
          const at = (node.textContent || '').toLowerCase().indexOf(q);
          if (at >= 0) {
            const range = document.createRange();
            range.setStart(node, at);
            range.setEnd(node, Math.min(node.textContent.length, at + query.length));
            const sel = window.getSelection();
            sel?.removeAllRanges();
            sel?.addRange(range);
            break;
          }
        }
      }
    } catch { /* ignore */ }
    this.root.classList.remove('rich-flash');
    void this.root.offsetWidth;
    this.root.classList.add('rich-flash');
    return true;
  }
  bindIO() {
    if (!this.root) return;
    // Self-heal (portal-wipe fix): if the toolbar node was destroyed out from
    // under this instance (e.g. a foreign `portal.innerHTML=''`), rebuild it
    // WITHOUT double-binding root listeners (double keydown/paste would
    // toggle twice / insert images twice).
    const needRootIO = !this.root._beditIO;
    if (needRootIO) {
      this.root._beditIO = true;
      this.bindContainerDrop();
    }

    // Floating formatting toolbar lives in the body portal (L1): viewport
    // coordinates keep it visible above any scroll container. Inline marks +
    // H1/H2/H3/quote line transforms + ul/ol list toggles, all routed
    // through the pure RichCommandInterface (single seam).
    if (!this.floatingToolbar || !this.floatingToolbar.isConnected) {
      this.floatingToolbar = document.createElement('div');
      this.floatingToolbar.className = 'bedit-floating-toolbar hidden';
      this.floatingToolbar.setAttribute('data-bedit-toolbar', 'true');
      this.floatingToolbar.setAttribute('role', 'toolbar');
      this.floatingToolbar.setAttribute('aria-label', 'Formatação de texto');
      this.floatingToolbar.innerHTML = `
      <span class="tgroup" role="group" aria-label="Marcas inline">
        <button type="button" class="bedit-ft-btn ticon" data-fmt="bold" title="Negrito (Ctrl+B)" aria-label="Negrito" aria-pressed="false" aria-keyshortcuts="Control+b Meta+b"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-bold"/></svg></button>
        <button type="button" class="bedit-ft-btn ticon" data-fmt="italic" title="Itálico (Ctrl+I)" aria-label="Itálico" aria-pressed="false" aria-keyshortcuts="Control+i Meta+i"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-italic"/></svg></button>
        <button type="button" class="bedit-ft-btn ticon" data-fmt="code" title="Código inline (\`)" aria-label="Código inline" aria-pressed="false"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-code"/></svg></button>
        <button type="button" class="bedit-ft-btn ticon ft-danger-tint" data-fmt="strike" title="Tachado (~~)" aria-label="Tachado" aria-pressed="false"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-strike"/></svg></button>
        <button type="button" class="bedit-ft-btn ticon ft-preview-tint" data-fmt="link" title="Link (Ctrl+K)" aria-label="Link" aria-pressed="false" aria-keyshortcuts="Control+k Meta+k"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-link"/></svg></button>
      </span>
      <span class="tgroup" role="group" aria-label="Blocos">
        <span class="bedit-ft-hwrap"><button type="button" class="bedit-ft-btn ticon" data-fmt="h-menu" title="Transformar bloco (Ctrl+Shift+1..4, 0)" aria-label="Transformar bloco" aria-pressed="false" aria-haspopup="menu" aria-expanded="false"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-h1"/></svg><span aria-hidden="true" class="bedit-ft-caret">▾</span></button>
        <span class="bedit-ft-hmenu hidden" role="menu" aria-label="Transformar em"><button type="button" role="menuitemradio" data-fmt="h1" title="Título 1 (Ctrl+Shift+1)">H1</button><button type="button" role="menuitemradio" data-fmt="h2" title="Título 2 (Ctrl+Shift+2)">H2</button><button type="button" role="menuitemradio" data-fmt="h3" title="Título 3 (Ctrl+Shift+3)">H3</button><button type="button" role="menuitemradio" data-fmt="h4" title="Título 4 (Ctrl+Shift+4)">H4</button><button type="button" role="menuitemradio" data-fmt="p" title="Texto (Ctrl+Shift+0)">¶</button><button type="button" role="menuitemradio" data-fmt="quote" title="Citação">❝</button></span></span>
        <button type="button" class="bedit-ft-btn ticon" data-fmt="ul" title="Lista com marcadores (Ctrl+Shift+8)" aria-label="Lista com marcadores" aria-pressed="false"><span aria-hidden="true">•≡</span></button>
        <button type="button" class="bedit-ft-btn ticon" data-fmt="ol" title="Lista numerada (Ctrl+Shift+7)" aria-label="Lista numerada" aria-pressed="false"><span aria-hidden="true">1≡</span></button>
      </span>
      <span class="tgroup" role="group" aria-label="Inserção">
        <button type="button" class="bedit-ft-btn ticon" data-fmt="image" title="Inserir imagem" aria-label="Inserir imagem"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-image"/></svg></button>
        <button type="button" class="bedit-ft-btn ticon" data-fmt="tbl" title="Inserir tabela" aria-label="Inserir tabela"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-table"/></svg></button>
      </span>
    `;
      uiPortal()?.appendChild(this.floatingToolbar);
      // Toolbar keyboard: Esc dismisses + refocuses editor; arrows move between buttons.
      this.floatingToolbar.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
          e.stopPropagation();
          const hm = this.floatingToolbar.querySelector('.bedit-ft-hmenu');
          if (hm && !hm.classList.contains('hidden')) {
            hm.classList.add('hidden');
            this.floatingToolbar.querySelector('[data-fmt="h-menu"]')?.setAttribute('aria-expanded', 'false');
            this.floatingToolbar.querySelector('[data-fmt="h-menu"]')?.focus?.();
            return;
          }
          this.floatingToolbar.classList.add('hidden');
          try { (this.activeInput || this.activeCE?.ce)?.focus?.(); } catch { /* noop */ }
          this.activeInput = null;
          this.activeCE = null;
        } else if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
          e.preventDefault();
          const btns = Array.from(this.floatingToolbar.querySelectorAll('.tgroup > [data-fmt], .tgroup .bedit-ft-hwrap > [data-fmt]'));
          const at = btns.indexOf(document.activeElement);
          const next = e.key === 'ArrowRight' ? btns[(at + 1) % btns.length] : btns[(at - 1 + btns.length) % btns.length];
          next?.focus();
        } else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
          const hm = this.floatingToolbar.querySelector('.bedit-ft-hmenu');
          if (hm && document.activeElement?.closest?.('.bedit-ft-hwrap')) {
            e.preventDefault();
            const items = Array.from(hm.querySelectorAll('[data-fmt]'));
            const at = items.indexOf(document.activeElement);
            const next = e.key === 'ArrowDown' ? items[(at + 1) % items.length] : items[(at - 1 + items.length) % items.length];
            next?.focus();
          }
        }
      });
      this.floatingToolbar.querySelector('[data-fmt="h-menu"]')?.addEventListener('click', (e) => {
        e.stopPropagation();
        const menuBtn = this.floatingToolbar.querySelector('[data-fmt="h-menu"]');
        const hm = this.floatingToolbar.querySelector('.bedit-ft-hmenu');
        const open = hm.classList.contains('hidden');
        hm.classList.toggle('hidden', !open);
        menuBtn?.setAttribute('aria-expanded', open ? 'true' : 'false');
        if (open) hm.querySelector('[data-fmt]')?.focus?.();
      });
    }
    // Dedicated portal shelf for insert/slash menus: openPortalMenu wipes
    // only this shelf, never the format toolbar (popup-kill fix).
    menuShelf();

    this.activeInput = null;
    this.activeCE = null;

    const refreshToolbarState = () => {
      try {
        let plain = '';
        let s = 0;
        let e = 0;
        let bi = 0;
        if (this.activeInput) {
          const card = this.activeInput.closest?.('[data-bi]');
          bi = card ? Number(card.dataset.bi) : 0;
          plain = this.activeInput.value;
          s = this.activeInput.selectionStart;
          e = this.activeInput.selectionEnd;
        } else if (this.activeCE) {
          bi = Number(this.activeCE.index) || 0;
          const b = this.store.blocks[bi];
          plain = b ? b.lines.join('\n') : '';
          const off = ceRangeOffsets(this.activeCE.ce);
          s = off ? off.start : 0;
          e = off ? off.end : 0;
        } else return;
        this.floatingToolbar.querySelectorAll('[data-fmt]').forEach((btn) => {
          const fmt = btn.dataset.fmt;
          if (fmt === 'h-menu') return;
          let active = false;
          try { active = detectRichState(plain, s, e, fmt); } catch { active = false; }
          btn.setAttribute('aria-pressed', active ? 'true' : 'false');
          if (btn.getAttribute('role') === 'menuitemradio') btn.setAttribute('aria-checked', active ? 'true' : 'false');
          else btn.classList.toggle('is-active', active);
        });
        try {
          const anyH = ['h1', 'h2', 'h3', 'h4', 'p', 'quote'].some((f) => { try { return detectRichState(plain, s, e, f); } catch { return false; } });
          const menuBtn = this.floatingToolbar.querySelector('[data-fmt="h-menu"]');
          menuBtn?.setAttribute('aria-pressed', anyH ? 'true' : 'false');
          menuBtn?.classList.toggle('is-active', anyH);
        } catch { /* cosmetic */ }
        void bi;
      } catch { /* toolbar state is cosmetic */ }
    };
    const showToolbarFor = (rect) => {
      hidePortalToolbars(this.floatingToolbar);
      const vw = document.documentElement.clientWidth || 360;
      const tw = Math.min(340, vw - 16);
      const top = rect.top - 44;
      const left = Math.max(8,
        Math.min(rect.left + 12,
          document.documentElement.clientWidth - tw - 8));
      this.floatingToolbar.style.top = `${Math.max(8, top)}px`;
      this.floatingToolbar.style.left = `${left}px`;
      this.floatingToolbar.classList.remove('hidden');
      const isMobile = window.matchMedia?.('(max-width: 860px)').matches;
      this.floatingToolbar.classList.toggle('m-bubble', !!isMobile);
      refreshToolbarState();
    };
    const hideToolbar = () => {
      this.floatingToolbar.classList.add('hidden');
      this.activeInput = null;
      this.activeCE = null;
    };

    const handleSelection = (targetInput) => {
      this.activeCE = null;
      if (!targetInput) {
        hideToolbar();
        return;
      }
      const s = targetInput.selectionStart;
      const e = targetInput.selectionEnd;
      if (typeof s === 'number' && typeof e === 'number' && e > s) {
        this.activeInput = targetInput;
        showToolbarFor(targetInput.getBoundingClientRect());
      } else {
        hideToolbar();
      }
    };

    /* CE selection probe (Direta bug fix): the toolbar previously only read
     * textarea selectionStart/End, so CE selections never armed it. Probe the
     * live DOM Range, require it to sit inside a [data-ce] card, and arm.
     * Collapsed carets also arm (anchored to the CE box) so H1/H2/H3/quote
     * line transforms work without a text selection; inline marks still
     * require a non-collapsed range at apply time. */
    const handleCESelection = () => {
      try {
        const sel = window.getSelection();
        if (!sel || sel.rangeCount === 0) { hideToolbar(); return false; }
        const range = sel.getRangeAt(0);
        let node = range.commonAncestorContainer;
        const ce = (node.nodeType === 1 ? node.closest?.('[data-ce]') : node.parentElement?.closest?.('[data-ce]'));
        const card = (node.nodeType === 1 ? node.closest?.('[data-bi]') : node.parentElement?.closest?.('[data-bi]'));
        if (!ce || !card || !this.root.contains(ce)) { hideToolbar(); return false; }
        this.activeInput = null;
        this.activeCE = { ce, card, index: Number(card.dataset.bi) };
        let rect = null;
        try { rect = range.getBoundingClientRect(); } catch { rect = null; }
        if (!rect || (rect.width === 0 && rect.height === 0)) {
          try { rect = ce.getBoundingClientRect(); } catch { rect = null; }
        }
        if (!rect) { hideToolbar(); return false; }
        showToolbarFor(rect);
        return true;
      } catch { hideToolbar(); return false; }
    };

    // Root + document listeners bind exactly once per root (guarded by
    // needRootIO): rebinding would double-fire keydown (toggle twice) and
    // paste (double image insert). Toolbar heals independently above.
    if (needRootIO) {
    this.root.addEventListener('mouseup', (e) => {
      if (e.target.tagName === 'TEXTAREA' || e.target.tagName === 'INPUT') {
        setTimeout(() => handleSelection(e.target), 20);
      } else if (e.target.closest?.('[data-ce]')) {
        setTimeout(() => handleCESelection(), 20);
      } else if (!this.floatingToolbar.contains(e.target)) {
        hideToolbar();
      }
    });

    this.root.addEventListener('keyup', (e) => {
      if (e.target.tagName === 'TEXTAREA' || e.target.tagName === 'INPUT') {
        handleSelection(e.target);
      } else if (e.target.closest?.('[data-ce]')) {
        handleCESelection();
      }
    });
    this._selListener = () => {
      try {
        const sel = window.getSelection();
        const node = sel && sel.rangeCount > 0 ? sel.anchorNode : null;
        const el = node ? (node.nodeType === 1 ? node : node.parentElement) : null;
        if (el?.closest?.('[data-ce]') && this.root.contains(el) && sel && sel.rangeCount > 0) handleCESelection();
      } catch { /* probe is best effort */ }
    };
    document.addEventListener('selectionchange', this._selListener);

    // Keyboard: headings/paragraph (Cmd/Ctrl+Shift+1/2/3/0), lists (7/8),
    // inline (Cmd/Ctrl+B/I/K), undo/redo (Cmd/Ctrl+Z / Shift+Cmd/Ctrl+Z),
    // slash menu on "/" line start. All formatting funnels through
    // execCommand (single seam).
    this.root.addEventListener('keydown', (e) => {
      const ta = e.target;
      if (!ta || ta.tagName !== 'TEXTAREA' || !ta.hasAttribute('data-raw')) return;
      const card = ta.closest('[data-bi]');
      const bi = card ? Number(card.dataset.bi) : 0;
      const mod = e.metaKey || e.ctrlKey;
      if (mod && !e.altKey && (e.key === 'z' || e.key === 'Z')) {
        e.preventDefault();
        if (e.shiftKey) this.redo();
        else this.undo();
        return;
      }
      if (mod && !e.shiftKey && !e.altKey && ['b', 'B', 'i', 'I', 'k', 'K'].includes(e.key)) {
        e.preventDefault();
        const fmt = (e.key === 'b' || e.key === 'B') ? 'bold' : (e.key === 'i' || e.key === 'I') ? 'italic' : 'link';
        this.execCommand(fmt, bi, ta.selectionStart, ta.selectionEnd);
        return;
      }
      if (e.key === 'Enter' && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey && !this._composing) {
        if (this.textareaListEnter(ta, e)) return;
        if (this.textareaHeaderSplit(ta, e, bi)) return;
      }
      // Headings + paragraph (1/2/3/4/0) and lists: bullets 8, numbered 7
      // (Paper convention Ctrl/Cmd+Shift+8 / +7; e.code-based, Shift-safe).
      if (mod && e.shiftKey && ['1', '2', '3', '4', '0', '7', '8'].includes(digitOf(e))) {
        e.preventDefault();
        const d = digitOf(e);
        const fmt = d === '0' ? 'p' : d === '1' ? 'h1' : d === '2' ? 'h2' : d === '3' ? 'h3' : d === '4' ? 'h4' : d === '7' ? 'ol' : 'ul';
        this.execCommand(fmt, bi, ta.selectionStart, ta.selectionEnd);
        return;
      }
      if (e.key === '/' && ta.selectionStart === ta.selectionEnd) {
        const v = ta.value, s = ta.selectionStart;
        const ls = v.lastIndexOf('\n', s - 1) + 1;
        if (/^\s*$/.test(v.slice(ls, s))) {
          e.preventDefault();
          const kartu = ta.closest('[data-bi]');
          const bi = kartu ? Number(kartu.dataset.bi) : 0;
          this.openSlashMenu(ta, bi);
        }
      }
    });

    // Button wiring runs once per toolbar node: a reused (still-connected)
    // node keeps its listeners; rewiring would double-fire execCommand
    // (toggle on, then immediately off).
    // NOTE: this block intentionally sits OUTSIDE the needRootIO guard —
    // a healed (fresh) toolbar on an already-bound root still needs wiring.
    } // end if (needRootIO) — root/document listeners above
    if (!this.floatingToolbar._wired) {
    this.floatingToolbar._wired = true;
    this.floatingToolbar.querySelectorAll('[data-fmt]').forEach((btn) => {
      btn.addEventListener('mousedown', (e) => {
        e.preventDefault(); // Prevent blurring the input
        const fmt = btn.dataset.fmt;
        // Insertion group: image/table route through the insert flow at the
        // end (link stays an inline mark on the shared seam below).
        if ((fmt === 'image' || fmt === 'tbl') && !this.activeCE && !this.activeInput) {
          try { this.handleInsertAt(this.store.blocks.length, fmt === 'image' ? 'fig' : 'tbl'); } catch { /* best effort */ }
          this.floatingToolbar.classList.add('hidden');
          return;
        }
        if ((fmt === 'image' || fmt === 'tbl') && this.activeInput) {
          const card = this.activeInput.closest?.('[data-bi]');
          const bi = card ? Number(card.dataset.bi) : this.store.blocks.length;
          try { this.handleInsertAt(bi + 1, fmt === 'image' ? 'fig' : 'tbl'); } catch { /* best effort */ }
          this.floatingToolbar.classList.add('hidden');
          return;
        }
        /* Direta CE path (bug fix): wrap the live DOM Range with styled
         * elements, then sync via ceDomToMarkdown. Textarea path below. */
        if (this.activeCE && this.activeCE.ce) {
          const { ce, card, index } = this.activeCE;
          try {
            if (fmt === 'h1' || fmt === 'h2' || fmt === 'h3' || fmt === 'h4') {
              this.checkpoint();
              const target = fmt === 'h1' ? '# ' : fmt === 'h2' ? '## ' : fmt === 'h3' ? '### ' : '#### ';
              ce.dataset.hashes = ce.dataset.hashes === target ? '' : target;
              ce.dataset.quote = '';
              const m = (ce.dataset.hashes || '').match(/^(#{1,4})\s/);
              ce.classList.remove('bedit-preview-h1', 'bedit-preview-h2', 'bedit-preview-h3', 'bedit-preview-h4', 'bedit-preview-quote');
              if (m) ce.classList.add(`bedit-preview-h${m[1].length}`);
            } else if (fmt === 'quote' || fmt === 'p') {
              this.checkpoint();
              ce.dataset.hashes = '';
              ce.dataset.quote = fmt === 'quote' ? (ce.dataset.quote === '1' ? '' : '1') : '';
              ce.classList.remove('bedit-preview-h1', 'bedit-preview-h2', 'bedit-preview-h3', 'bedit-preview-h4', 'bedit-preview-quote');
              if (ce.dataset.quote === '1') ce.classList.add('bedit-preview-quote');
            } else if (fmt === 'ul' || fmt === 'ol') {
              // Lists apply at store level (CE is a styled single-flow
              // surface): flush, map the CE body range onto store offsets,
              // run the pure list command, then refocus the fresh surface.
              this.syncCard(card, index);
              const blk = this.store.blocks[index];
              if (!blk) return;
              const bodyText = ceDomToMarkdown(ce).replace(/\n+$/g, '');
              const off = ceRangeOffsets(ce) || { start: 0, end: 0 };
              const mapped = mapBodyRangeToStore(
                blk.lines.join('\n'), bodyText,
                ce.dataset.hashes || '', ce.dataset.quote === '1',
                off.start, off.end,
              );
              this.execCommand(fmt, index, mapped.start, mapped.end);
              try {
                const fresh = this.root.querySelector(`[data-bi="${index}"]`);
                const target = fresh ? (fresh.querySelector('[data-ce]') || fresh.querySelector('textarea[data-raw]')) : null;
                target?.focus?.();
              } catch { /* keep focus */ }
            } else {
              const sel = window.getSelection();
              if (!sel || sel.rangeCount === 0 || sel.isCollapsed) return;
              const range = sel.getRangeAt(0);
              if (!ce.contains(range.commonAncestorContainer)) return;
              const tag = fmt === 'bold' ? 'STRONG' : fmt === 'italic' ? 'EM' : fmt === 'code' ? 'CODE' : fmt === 'strike' ? 'S' : fmt === 'link' ? 'A' : '';
              if (!tag) return;
              this.checkpoint();
              // Toggle-off: walk up through matching styled ancestors and
              // unwrap the outermost (partial-word or nested <strong> inside
              // <strong> both collapse to plain instead of **** stacking).
              const host = range.commonAncestorContainer.nodeType === 1
                ? range.commonAncestorContainer
                : range.commonAncestorContainer.parentElement;
              let styled = host?.closest?.(tag);
              while (styled && ce.contains(styled) && styled.parentElement && styled.parentElement !== ce
                && styled.parentElement.closest?.(tag) && ce.contains(styled.parentElement.closest(tag))) {
                styled = styled.parentElement.closest(tag);
              }
              if (styled && ce.contains(styled) && tag !== 'A') {
                const parent = styled.parentNode;
                while (styled.firstChild) parent.insertBefore(styled.firstChild, styled);
                parent.removeChild(styled);
                try { sel.collapseToEnd(); } catch { /* keep caret */ }
              } else {
                const wrap = document.createElement(tag);
                if (tag === 'A') wrap.setAttribute('href', 'https://');
                try {
                  range.surroundContents(wrap);
                } catch {
                  const frag = range.extractContents();
                  wrap.appendChild(frag);
                  range.insertNode(wrap);
                }
                try {
                  sel.removeAllRanges();
                  const after = document.createRange();
                  after.selectNodeContents(wrap);
                  after.collapse(false);
                  sel.addRange(after);
                } catch { /* keep native caret */ }
              }
            }
            ce.dispatchEvent(new Event('input', { bubbles: true }));
          } catch { /* formatting is best effort */ }
          this.floatingToolbar.classList.add('hidden');
          this.floatingToolbar.querySelector('.bedit-ft-hmenu')?.classList.add('hidden');
          this.floatingToolbar.querySelector('[data-fmt="h-menu"]')?.setAttribute('aria-expanded', 'false');
          return;
        }
        if (!this.activeInput) return;
        // Single-seam path: every textarea command funnels through the pure
        // RichCommandInterface (applyRichCommand via execCommand), never
        // hand-rolled markers. Keeps toolbar/slash/shortcuts consistent.
        const ta = this.activeInput;
        const card = ta.closest?.('[data-bi]');
        const bi = card ? Number(card.dataset.bi) : 0;
        if (!this.canExec(fmt)) return;
        this.execCommand(fmt, bi, ta.selectionStart, ta.selectionEnd);
        try { ta.focus(); } catch { /* keep focus */ }
        this.floatingToolbar.classList.add('hidden');
        this.floatingToolbar.querySelector('.bedit-ft-hmenu')?.classList.add('hidden');
        this.floatingToolbar.querySelector('[data-fmt="h-menu"]')?.setAttribute('aria-expanded', 'false');
      });
    });
    } // _wired guard

    if (needRootIO) {
    // Pasted/dropped image files route through the upload pipeline, exactly
    // like the image modal; plain-text pastes pass through normalize first.
    this.root.addEventListener('paste', (e) => {
      try {
        const dt = e.clipboardData;
        if (!dt) return;
        const files = Array.from(dt.files || []).filter((f) => /^image\//.test(f.type));
        if (files.length > 0 && typeof this.onImageUpload === 'function') {
          e.preventDefault();
          for (const f of files) {
            Promise.resolve(this.onImageUpload(f)).then((url) => {
              if (url) this.insertFigureLine(serializeFigureLine({ alt: 'Figura', src: url }));
            }).catch(() => { /* uploader surfaces the error */ });
          }
          return;
        }
        let raw = dt.getData('text/plain');
        if ((!raw || !raw.trim()) && dt.types.includes('text/html')) {
          try {
            const html = dt.getData('text/html');
            const tmp = document.createElement('div');
            tmp.innerHTML = html;
            raw = tmp.textContent || '';
          } catch { /* fall through */ }
        }
        if (!raw) return;
        // V5 paste-URL-over-selection: bare URL pasted over a non-collapsed
        // selection becomes [text](url) instead of raw URL text. Same seam
        // as the toolbar link button, for textarea + Direta CE surfaces.
        try {
          const url = String(raw).trim();
          const t = e.target;
          if (/^https?:\/\/\S+$/i.test(url) && t && t.tagName === 'TEXTAREA'
            && typeof t.selectionStart === 'number' && t.selectionEnd > t.selectionStart) {
            const res = pasteUrlLink(t.value, t.selectionStart, t.selectionEnd, url);
            if (res) {
              e.preventDefault();
              const card = t.closest?.('[data-bi]');
              const bi = card ? Number(card.dataset.bi) : 0;
              const b = this.store.blocks[bi];
              if (b && b.kind !== 'figure' && b.kind !== 'table' && b.kind !== 'rule') this.checkpoint();
              t.value = res.text;
              try { t.setSelectionRange(res.caretStart, res.caretEnd); } catch { /* noop */ }
              t.dispatchEvent(new Event('input', { bubbles: true }));
              return;
            }
          }
          if (/^https?:\/\/\S+$/i.test(url) && t?.closest?.('[data-ce]')) {
            const sel = window.getSelection();
            const ce = t.closest('[data-ce]');
            if (sel && sel.rangeCount > 0 && !sel.isCollapsed && ce.contains(sel.getRangeAt(0).commonAncestorContainer)) {
              e.preventDefault();
              this.checkpoint();
              const range = sel.getRangeAt(0);
              const a = document.createElement('a');
              a.setAttribute('href', url);
              try { range.surroundContents(a); }
              catch {
                const frag = range.extractContents();
                a.appendChild(frag);
                range.insertNode(a);
              }
              ce.dispatchEvent(new Event('input', { bubbles: true }));
              return;
            }
          }
        } catch { /* fall through to normalize path */ }
        const norm = this.normalize(String(raw).replace(/^\s*\n+|\s*\n+\s*$/g, ''));
        if (norm === raw) return;
        e.preventDefault();
        document.execCommand('insertText', false, norm);
      } catch { /* fall through to native paste */ }
    });
    this.root.addEventListener('dragover', (e) => {
      if (e.dataTransfer && Array.from(e.dataTransfer.types || []).includes('Files')) {
        e.preventDefault();
        this.root.classList.add('bedit-dropzone-active');
      }
    });
    this.root.addEventListener('dragleave', (e) => {
      if (e.relatedTarget && this.root.contains(e.relatedTarget)) return;
      this.root.classList.remove('bedit-dropzone-active');
    });
    this.root.addEventListener('drop', (e) => {
      this.root.classList.remove('bedit-dropzone-active');
      try {
        const files = Array.from(e.dataTransfer?.files || []).filter((f) => /^image\//.test(f.type));
        if (files.length > 0 && typeof this.onImageUpload === 'function') {
          e.preventDefault();
          for (const f of files) {
            Promise.resolve(this.onImageUpload(f)).then((url) => {
              if (url) this.insertFigureLine(serializeFigureLine({ alt: 'Figura', src: url }));
            }).catch(() => { /* uploader surfaces the error */ });
          }
        }
      } catch { /* ignore */ }
    });
    } // end if (needRootIO) — paste/drop listeners above
  }
}


/* ==========================================================================
   Master Orchestration Specification v2.0 — Live Editor & Template Switcher Hook
   ========================================================================== */
import {
  EditorialGeometryEngine,
  normalizeEditorialGeometry,
  verifyTemplateEditorialGeometry,
  DEFAULT_GUARDRAILS_CONFIG,
} from './editorial-geometry-engine.js';

export {
  EditorialGeometryEngine,
  normalizeEditorialGeometry,
  verifyTemplateEditorialGeometry,
  DEFAULT_GUARDRAILS_CONFIG,
};

export function initializeEditorialPagination(editorRootElement, initialTemplateId = 'default', guardrailsConfig = DEFAULT_GUARDRAILS_CONFIG) {
  if (typeof window !== 'undefined') {
    window.normalizeEditorialGeometry = normalizeEditorialGeometry;
    window.verifyTemplateEditorialGeometry = verifyTemplateEditorialGeometry;
  }

  if (editorRootElement && initialTemplateId) {
    editorRootElement.setAttribute('data-template', initialTemplateId);
  }

  // Re-normalize automatically prior to native browser print
  if (typeof window !== 'undefined' && typeof window.addEventListener === 'function' && editorRootElement) {
    window.addEventListener('beforeprint', () => {
      normalizeEditorialGeometry(editorRootElement, guardrailsConfig, {
        templateId: editorRootElement.getAttribute('data-template') || initialTemplateId,
      });
    });
  }

  // Expose helper to switch templates dynamically in the editor
  return {
    async setTemplate(newTemplateId, customOverrides = {}) {
      if (editorRootElement) {
        editorRootElement.setAttribute('data-template', newTemplateId);
      }
      return await normalizeEditorialGeometry(editorRootElement, guardrailsConfig, {
        templateId: newTemplateId,
        templateConfig: customOverrides,
      });
    },
  };
}
