/**
 * @file editorial-geometry-engine.js
 * @description Template-Aware Deterministic Editorial Geometry, Fragmentation & Bottom-Margin Suppression Engine (v2.0)
 * Isomorphic zero-dependency ES module shared across browser (static/editor-core.js, static/v2-app.js)
 * and Node/Worker entrypoints (pdf-engine.js, pdf-generator.js).
 */

export const UNIT_TO_PX = Object.freeze({
  px: 1,
  in: 96,
  mm: 96 / 25.4,
  cm: 96 / 2.54,
  pt: 96 / 72,
  pc: 16,
});

export const PAPER_PRESETS_MM = Object.freeze({
  A3: { width: 297, height: 420 },
  A4: { width: 210, height: 297 },
  A5: { width: 148, height: 210 },
  LETTER: { width: 215.9, height: 279.4 },
  LEGAL: { width: 215.9, height: 355.6 },
  TABLOID: { width: 279.4, height: 431.8 },
});

export const DEFAULT_GUARDRAILS_CONFIG = Object.freeze({
  defaults: {
    geometry: {
      format: 'A4',
      orientation: 'portrait',
      width: '210mm',
      height: '297mm',
      marginTop: '24mm',
      marginBottom: '28mm',
      marginInside: '20mm',
      marginOutside: '24mm',
      headerSafeZone: '12mm',
      footerSafeZone: '12mm',
      firstPageMarginTop: null,
      firstPageMarginBottom: null,
      firstPageHeaderSafeZone: null,
      firstPageFooterSafeZone: null,
      pushDownThresholdPx: 130,
      subPixelTolerancePx: 1.5,
    },
    fragmentation: {
      continuationLabel: '(Continuação...)',
      minOrphanLines: 3,
      minWidowLines: 3,
      minTableRowsBeforeSplit: 2,
      minTableRowsAfterSplit: 2,
      minListItemsBeforeSplit: 2,
      minListItemsAfterSplit: 2,
      headingGlueLines: 2,
      atomicSelectors: [
        '.callout-box',
        '.advisory-box',
        '.metric-card',
        '.stat-card',
        '.signature-zone',
        '.metadata-panel',
        '.stamp-row',
        '.atomic-block',
        '.bedit-callout',
        '.bedit-figure',
        '.bedit-math',
        'blockquote',
        'figure',
        'pre',
      ],
      framedSelectors: [
        '.callout-box',
        '.advisory-box',
        '.metric-card',
        '.stat-card',
        '.signature-zone',
        '.metadata-panel',
        '.stamp-row',
        '.bedit-callout',
        'blockquote',
        'table',
        'pre',
      ],
      headingSelectors: ['h1', 'h2', 'h3', 'h4'],
      listIntroSelectors: ['.list-intro', "[data-list-intro='true']"],
      flowContainerSelectors: [
        '.document-section',
        '.section-body',
        '.flow-container',
        'section:not(.atomic-block):not(.callout-box):not(.signature-zone)',
        'article:not(.atomic-block)',
      ],
    },
  },
  templates: {
    default: {},
    base: {
      geometry: {
        format: 'A4',
        orientation: 'portrait',
        width: '210mm',
        height: '297mm',
        marginTop: '9.5mm',
        marginBottom: '10mm',
        marginInside: '10mm',
        marginOutside: '10mm',
        headerSafeZone: '6.53mm',
        footerSafeZone: '4.41mm',
        pushDownThresholdPx: 130,
      },
    },
    bauhaus: {
      geometry: {
        format: 'A4',
        orientation: 'portrait',
        width: '210mm',
        height: '297mm',
        marginTop: '8mm',
        marginBottom: '8.5mm',
        marginInside: '10mm',
        marginOutside: '10mm',
        headerSafeZone: '6.53mm',
        footerSafeZone: '4.23mm',
        pushDownThresholdPx: 130,
      },
    },
    bauhaus_minimalist: {
      geometry: {
        format: 'A4',
        orientation: 'portrait',
        width: '210mm',
        height: '297mm',
        marginTop: '7mm',
        marginBottom: '7mm',
        marginInside: '8mm',
        marginOutside: '8mm',
        headerSafeZone: '5.29mm',
        footerSafeZone: '3.17mm',
        pushDownThresholdPx: 100,
      },
    },
    'executive-report': {
      geometry: {
        format: 'A4',
        orientation: 'portrait',
        marginTop: '26mm',
        marginBottom: '30mm',
        marginInside: '22mm',
        marginOutside: '26mm',
        headerSafeZone: '14mm',
        footerSafeZone: '14mm',
        firstPageMarginTop: '35mm',
        firstPageHeaderSafeZone: '0mm',
        pushDownThresholdPx: 140,
      },
    },
    'legal-contract': {
      geometry: {
        format: 'A4',
        orientation: 'portrait',
        marginTop: '30mm',
        marginBottom: '32mm',
        marginInside: '30mm',
        marginOutside: '20mm',
        headerSafeZone: '10mm',
        footerSafeZone: '15mm',
        pushDownThresholdPx: 120,
      },
      fragmentation: {
        continuationLabel: '(Continuação na página seguinte / ...)',
        minOrphanLines: 4,
        minWidowLines: 4,
      },
    },
    'compact-technical': {
      geometry: {
        format: 'A4',
        orientation: 'portrait',
        marginTop: '16mm',
        marginBottom: '18mm',
        marginInside: '15mm',
        marginOutside: '15mm',
        headerSafeZone: '8mm',
        footerSafeZone: '8mm',
        pushDownThresholdPx: 100,
      },
    },
    'landscape-dossier': {
      geometry: {
        format: 'A4',
        orientation: 'landscape',
        width: '297mm',
        height: '210mm',
        marginTop: '18mm',
        marginBottom: '20mm',
        marginInside: '20mm',
        marginOutside: '20mm',
        headerSafeZone: '10mm',
        footerSafeZone: '10mm',
        pushDownThresholdPx: 110,
      },
    },
    'us-letter-brief': {
      geometry: {
        format: 'Letter',
        orientation: 'portrait',
        width: '8.5in',
        height: '11in',
        marginTop: '1in',
        marginBottom: '1.1in',
        marginInside: '1in',
        marginOutside: '1in',
        headerSafeZone: '0.45in',
        footerSafeZone: '0.45in',
        pushDownThresholdPx: 128,
      },
    },
  },
});

function getComputed(el) {
  if (typeof window !== 'undefined' && typeof window.getComputedStyle === 'function') {
    return window.getComputedStyle(el);
  }
  const win = el?.ownerDocument?.defaultView;
  if (win && typeof win.getComputedStyle === 'function') {
    return win.getComputedStyle(el);
  }
  return {
    display: 'block',
    position: 'static',
    breakBefore: 'auto',
    pageBreakBefore: 'auto',
    marginTop: '0px',
    marginBottom: '0px',
    paddingTop: '0px',
    paddingBottom: '0px',
    borderTopWidth: '0px',
    borderBottomWidth: '0px',
    fontSize: '16px',
    lineHeight: '22px',
    backgroundColor: 'transparent',
    getPropertyValue: () => '',
  };
}

export class EditorialGeometryEngine {
  /**
   * @param {Object} rawConfig - Full contents of design-guardrails.config.json
   * @param {Object} options - Optional { templateId, templateConfig } runtime overrides
   * @param {HTMLElement} documentRoot - Target root element for DOM/CSS variable inspection
   */
  constructor(rawConfig = {}, options = {}, documentRoot = null) {
    this.rawConfig = rawConfig && Object.keys(rawConfig).length > 0 ? rawConfig : DEFAULT_GUARDRAILS_CONFIG;
    this.options = options || {};
    this.documentRoot = documentRoot;
    this.config = this.resolveTemplateConfig(this.rawConfig, this.options, documentRoot);
  }

  /**
   * Converts any physical CSS dimension string ('24mm', '1in', '72pt', 130) to 96-DPI pixels.
   */
  parseDimensionToPx(value, fallbackPx = 0) {
    if (value === null || value === undefined || value === '') return fallbackPx;
    if (typeof value === 'number') return Number.isFinite(value) ? value : fallbackPx;

    const str = String(value).trim();
    const match = str.match(/^(-?\d+(?:\.\d+)?)\s*(px|mm|cm|in|pt|pc)?$/i);
    if (!match) return fallbackPx;

    const num = parseFloat(match[1]);
    const unit = (match[2] || 'px').toLowerCase();
    const factor = UNIT_TO_PX[unit] ?? 1;
    return num * factor;
  }

  /**
   * Normalizes a dimension value to a valid CSS unit string (defaults numbers to 'mm' or 'px')
   */
  normalizeCssUnitString(value, fallbackStr, defaultUnit = 'mm') {
    if (value === null || value === undefined || value === '') return fallbackStr;
    if (typeof value === 'number') return `${value}${defaultUnit}`;
    return String(value).trim();
  }

  /**
   * Resolves active template geometry & fragmentation rules across all 4 precedence tiers.
   */
  resolveTemplateConfig(rawConfig = {}, options = {}, documentRoot = null) {
    const baseGeo = {
      ...DEFAULT_GUARDRAILS_CONFIG.defaults.geometry,
      ...(rawConfig.defaults?.geometry || rawConfig.geometry || {}),
    };
    const baseFrag = {
      ...DEFAULT_GUARDRAILS_CONFIG.defaults.fragmentation,
      ...(rawConfig.defaults?.fragmentation || rawConfig.fragmentation || {}),
    };
    const templatesMap = {
      ...DEFAULT_GUARDRAILS_CONFIG.templates,
      ...(rawConfig.templates || {}),
    };

    // Determine active template ID from options or DOM attributes
    const domTemplateId =
      documentRoot?.getAttribute?.('data-template') ||
      documentRoot?.getAttribute?.('data-template-id') ||
      documentRoot?.ownerDocument?.body?.getAttribute?.('data-template') ||
      documentRoot?.ownerDocument?.body?.getAttribute?.('data-template-id') ||
      'default';

    const activeTemplateId = options.templateId || domTemplateId || 'default';
    const templateProfile = templatesMap[activeTemplateId] || {};
    const runtimeGeo = options.templateConfig?.geometry || options.geometry || {};
    const runtimeFrag = options.templateConfig?.fragmentation || options.fragmentation || {};

    // Read optional CSS Custom Property overrides if defined by template stylesheet
    const cssVarOverrides = {};
    if (documentRoot) {
      const computed = getComputed(documentRoot);
      const readVar = (name) => {
        const val = computed.getPropertyValue ? computed.getPropertyValue(name).trim() : '';
        return val.length > 0 ? val : undefined;
      };
      if (readVar('--template-page-format')) cssVarOverrides.format = readVar('--template-page-format');
      if (readVar('--template-page-orientation')) cssVarOverrides.orientation = readVar('--template-page-orientation');
      if (readVar('--template-page-width')) cssVarOverrides.width = readVar('--template-page-width');
      if (readVar('--template-page-height')) cssVarOverrides.height = readVar('--template-page-height');
      if (readVar('--template-margin-top')) cssVarOverrides.marginTop = readVar('--template-margin-top');
      if (readVar('--template-margin-bottom')) cssVarOverrides.marginBottom = readVar('--template-margin-bottom');
      if (readVar('--template-margin-inside')) cssVarOverrides.marginInside = readVar('--template-margin-inside');
      if (readVar('--template-margin-outside')) cssVarOverrides.marginOutside = readVar('--template-margin-outside');
      if (readVar('--template-header-safe-zone')) cssVarOverrides.headerSafeZone = readVar('--template-header-safe-zone');
      if (readVar('--template-footer-safe-zone')) cssVarOverrides.footerSafeZone = readVar('--template-footer-safe-zone');
    }

    // Merge tiers: Base (Tier 4) -> CSS Vars (Tier 3) -> Template Profile (Tier 2) -> Runtime Overrides (Tier 1)
    const mergedGeo = {
      ...baseGeo,
      ...cssVarOverrides,
      ...(templateProfile.geometry || {}),
      ...runtimeGeo,
    };

    const mergedFrag = {
      ...baseFrag,
      ...(templateProfile.fragmentation || {}),
      ...runtimeFrag,
    };

    // Resolve paper format & orientation dimensions
    const formatKey = String(mergedGeo.format || 'A4').toUpperCase();
    const preset = PAPER_PRESETS_MM[formatKey] || PAPER_PRESETS_MM.A4;
    const orientation = String(mergedGeo.orientation || 'portrait').toLowerCase();

    let defaultWidthCss = `${preset.width}mm`;
    let defaultHeightCss = `${preset.height}mm`;
    if (orientation === 'landscape') {
      defaultWidthCss = `${preset.height}mm`;
      defaultHeightCss = `${preset.width}mm`;
    }

    // Only use explicit width/height if specified by an overriding tier or when format/orientation matches baseGeo
    const hasExplicitWidth =
      runtimeGeo.width !== undefined ||
      templateProfile.geometry?.width !== undefined ||
      cssVarOverrides.width !== undefined;
    const hasExplicitHeight =
      runtimeGeo.height !== undefined ||
      templateProfile.geometry?.height !== undefined ||
      cssVarOverrides.height !== undefined;

    let widthCss = this.normalizeCssUnitString(
      hasExplicitWidth ? mergedGeo.width : defaultWidthCss,
      defaultWidthCss
    );
    let heightCss = this.normalizeCssUnitString(
      hasExplicitHeight ? mergedGeo.height : defaultHeightCss,
      defaultHeightCss
    );

    const marginTopCss = this.normalizeCssUnitString(mergedGeo.marginTop, '24mm');
    const marginBottomCss = this.normalizeCssUnitString(mergedGeo.marginBottom, '28mm');
    const marginInsideCss = this.normalizeCssUnitString(mergedGeo.marginInside, '20mm');
    const marginOutsideCss = this.normalizeCssUnitString(mergedGeo.marginOutside, '24mm');
    const headerSafeZoneCss = this.normalizeCssUnitString(mergedGeo.headerSafeZone, '12mm');
    const footerSafeZoneCss = this.normalizeCssUnitString(mergedGeo.footerSafeZone, '12mm');

    const firstPageMarginTopCss = this.normalizeCssUnitString(mergedGeo.firstPageMarginTop, marginTopCss);
    const firstPageMarginBottomCss = this.normalizeCssUnitString(mergedGeo.firstPageMarginBottom, marginBottomCss);
    const firstPageHeaderSafeZoneCss = this.normalizeCssUnitString(mergedGeo.firstPageHeaderSafeZone, headerSafeZoneCss);
    const firstPageFooterSafeZoneCss = this.normalizeCssUnitString(mergedGeo.firstPageFooterSafeZone, footerSafeZoneCss);

    // Compute exact 96-DPI pixel equivalents
    let widthPx = this.parseDimensionToPx(widthCss, 210 * UNIT_TO_PX.mm);
    let heightPx = this.parseDimensionToPx(heightCss, 297 * UNIT_TO_PX.mm);
    if (orientation === 'landscape' && widthPx < heightPx) {
      [widthPx, heightPx] = [heightPx, widthPx];
      [widthCss, heightCss] = [heightCss, widthCss];
    }

    const marginTopPx = this.parseDimensionToPx(marginTopCss, 24 * UNIT_TO_PX.mm);
    const marginBottomPx = this.parseDimensionToPx(marginBottomCss, 28 * UNIT_TO_PX.mm);
    const marginInsidePx = this.parseDimensionToPx(marginInsideCss, 20 * UNIT_TO_PX.mm);
    const marginOutsidePx = this.parseDimensionToPx(marginOutsideCss, 24 * UNIT_TO_PX.mm);
    const headerSafeZonePx = this.parseDimensionToPx(headerSafeZoneCss, 12 * UNIT_TO_PX.mm);
    const footerSafeZonePx = this.parseDimensionToPx(footerSafeZoneCss, 12 * UNIT_TO_PX.mm);

    const firstPageMarginTopPx = this.parseDimensionToPx(firstPageMarginTopCss, marginTopPx);
    const firstPageMarginBottomPx = this.parseDimensionToPx(firstPageMarginBottomCss, marginBottomPx);
    const firstPageHeaderSafeZonePx = this.parseDimensionToPx(firstPageHeaderSafeZoneCss, headerSafeZonePx);
    const firstPageFooterSafeZonePx = this.parseDimensionToPx(firstPageFooterSafeZoneCss, footerSafeZonePx);

    const bodyUsableHeightPx =
      heightPx - (marginTopPx + marginBottomPx + headerSafeZonePx + footerSafeZonePx);
    const firstPageUsableHeightPx =
      heightPx - (firstPageMarginTopPx + firstPageMarginBottomPx + firstPageHeaderSafeZonePx + firstPageFooterSafeZonePx);

    return {
      templateId: activeTemplateId,
      format: mergedGeo.format || 'A4',
      orientation,
      css: {
        width: widthCss,
        height: heightCss,
        marginTop: marginTopCss,
        marginBottom: marginBottomCss,
        marginInside: marginInsideCss,
        marginOutside: marginOutsideCss,
        headerSafeZone: headerSafeZoneCss,
        footerSafeZone: footerSafeZoneCss,
        firstPageMarginTop: firstPageMarginTopCss,
        firstPageMarginBottom: firstPageMarginBottomCss,
        firstPageHeaderSafeZone: firstPageHeaderSafeZoneCss,
        firstPageFooterSafeZone: firstPageFooterSafeZoneCss,
      },
      px: {
        width: widthPx,
        height: heightPx,
        marginTop: marginTopPx,
        marginBottom: marginBottomPx,
        marginInside: marginInsidePx,
        marginOutside: marginOutsidePx,
        headerSafeZone: headerSafeZonePx,
        footerSafeZone: footerSafeZonePx,
        firstPageUsableHeight: firstPageUsableHeightPx,
        bodyUsableHeight: bodyUsableHeightPx,
        pushDownThreshold: this.parseDimensionToPx(mergedGeo.pushDownThresholdPx, 130),
        subPixelTolerance: Number(mergedGeo.subPixelTolerancePx ?? 1.5),
      },
      fragmentation: {
        continuationLabel: mergedFrag.continuationLabel ?? '(Continuação...)',
        minOrphanLines: mergedFrag.minOrphanLines ?? 3,
        minWidowLines: mergedFrag.minWidowLines ?? 3,
        minTableRowsBeforeSplit: mergedFrag.minTableRowsBeforeSplit ?? 2,
        minTableRowsAfterSplit: mergedFrag.minTableRowsAfterSplit ?? 2,
        minListItemsBeforeSplit: mergedFrag.minListItemsBeforeSplit ?? 2,
        minListItemsAfterSplit: mergedFrag.minListItemsAfterSplit ?? 2,
        headingGlueLines: mergedFrag.headingGlueLines ?? 2,
        atomicSelectors: mergedFrag.atomicSelectors ?? [
          '.callout-box', '.advisory-box', '.metric-card', '.stat-card',
          '.signature-zone', '.metadata-panel', '.stamp-row', '.atomic-block',
          'blockquote', 'figure', 'pre',
        ],
        framedSelectors: mergedFrag.framedSelectors ?? [
          '.callout-box', '.advisory-box', '.metric-card', '.stat-card',
          '.signature-zone', '.metadata-panel', '.stamp-row', 'blockquote', 'table', 'pre',
        ],
        headingSelectors: mergedFrag.headingSelectors ?? ['h1', 'h2', 'h3', 'h4'],
        listIntroSelectors: mergedFrag.listIntroSelectors ?? ['.list-intro', "[data-list-intro='true']"],
        flowContainerSelectors: mergedFrag.flowContainerSelectors ?? [
          '.document-section', '.section-body', '.flow-container',
          'section:not(.atomic-block):not(.callout-box):not(.signature-zone)',
          'article:not(.atomic-block)',
        ],
      },
    };
  }

  /**
   * Returns usable vertical content budget for the given 0-based page index.
   */
  getUsablePageHeightPx(pageIndex = 0) {
    return pageIndex === 0 ? this.config.px.firstPageUsableHeight : this.config.px.bodyUsableHeight;
  }

  /**
   * Synchronizes CSS Custom Properties on :root AND injects a literal @page style block
   * to guarantee 100% Chromium print accuracy across all templates.
   */
  syncTemplateCssAndPageRules(doc = typeof document !== 'undefined' ? document : null) {
    if (!doc || !doc.documentElement) return;
    const root = doc.documentElement;
    const { css } = this.config;

    root.style.setProperty('--page-width', css.width);
    root.style.setProperty('--page-height', css.height);
    root.style.setProperty('--page-margin-top', css.marginTop);
    root.style.setProperty('--page-margin-bottom', css.marginBottom);
    root.style.setProperty('--page-margin-inside', css.marginInside);
    root.style.setProperty('--page-margin-outside', css.marginOutside);
    root.style.setProperty('--running-header-safe-zone', css.headerSafeZone);
    root.style.setProperty('--running-footer-safe-zone', css.footerSafeZone);
    root.style.setProperty('--first-page-margin-top', css.firstPageMarginTop);
    root.style.setProperty('--first-page-margin-bottom', css.firstPageMarginBottom);
    root.style.setProperty('--first-page-header-safe-zone', css.firstPageHeaderSafeZone);
    root.style.setProperty('--first-page-footer-safe-zone', css.firstPageFooterSafeZone);

    // Inject literal @page rules (bypasses Blink @page var() limitations)
    let styleEl = doc.getElementById('editorial-template-page-rules');
    if (!styleEl) {
      styleEl = doc.createElement('style');
      styleEl.id = 'editorial-template-page-rules';
      (doc.head || root).appendChild(styleEl);
    }

    styleEl.textContent = `
      @page {
        size: ${css.width} ${css.height};
        margin-top: calc(${css.marginTop} + ${css.headerSafeZone});
        margin-bottom: calc(${css.marginBottom} + ${css.footerSafeZone});
        margin-left: ${css.marginInside};
        margin-right: ${css.marginOutside};
      }
      @page :first {
        margin-top: calc(${css.firstPageMarginTop} + ${css.firstPageHeaderSafeZone});
        margin-bottom: calc(${css.firstPageMarginBottom} + ${css.firstPageFooterSafeZone});
      }
      @page :left {
        margin-left: ${css.marginOutside};
        margin-right: ${css.marginInside};
      }
      @page :right {
        margin-left: ${css.marginInside};
        margin-right: ${css.marginOutside};
      }
    `;
  }

  /**
   * Restores the DOM to its clean pre-paginated state so repeated passes are 100% idempotent.
   */
  unrollPaginationMutations(documentRoot) {
    // 1. Remove injected continuation markers
    documentRoot.querySelectorAll('[data-injected-continuation="true"]').forEach((el) => el.remove());

    // 2. Re-merge split tables in document order
    const splitTables = Array.from(documentRoot.querySelectorAll('table[data-split-origin-id]'));
    const tableGroups = new Map();
    for (const tbl of splitTables) {
      const id = tbl.getAttribute('data-split-origin-id');
      if (!tableGroups.has(id)) tableGroups.set(id, []);
      tableGroups.get(id).push(tbl);
    }

    for (const [, tables] of tableGroups.entries()) {
      if (tables.length > 1) {
        const primary = tables[0];
        const primaryTbody = primary.querySelector('tbody') || primary;
        for (let i = 1; i < tables.length; i++) {
          const fragment = tables[i];
          const rows = Array.from(fragment.querySelectorAll('tbody > tr, :scope > tr')).filter(
            (r) => !r.closest('thead') && !r.closest('tfoot')
          );
          rows.forEach((r) => primaryTbody.appendChild(r));
          const fragTfoot = fragment.querySelector('tfoot');
          if (fragTfoot && !primary.querySelector('tfoot')) {
            primary.appendChild(fragTfoot);
          }
          fragment.remove();
        }
      }
      tables[0].removeAttribute('data-split-origin-id');
    }

    // 3. Re-merge split lists in document order
    const splitLists = Array.from(documentRoot.querySelectorAll('ul[data-split-origin-id], ol[data-split-origin-id]'));
    const listGroups = new Map();
    for (const lst of splitLists) {
      const id = lst.getAttribute('data-split-origin-id');
      if (!listGroups.has(id)) listGroups.set(id, []);
      listGroups.get(id).push(lst);
    }

    for (const [, lists] of listGroups.entries()) {
      if (lists.length > 1) {
        const primary = lists[0];
        for (let i = 1; i < lists.length; i++) {
          const fragment = lists[i];
          Array.from(fragment.children).forEach((li) => primary.appendChild(li));
          fragment.remove();
        }
      }
      lists[0].removeAttribute('data-split-origin-id');
    }

    // 4. Strip utility classes
    documentRoot
      .querySelectorAll('.is-page-bottom, .is-framed-box, .js-forced-page-break, .allow-emergency-split')
      .forEach((el) => {
        el.classList.remove('is-page-bottom', 'is-framed-box', 'js-forced-page-break', 'allow-emergency-split');
      });
  }

  /**
   * Element classification helpers
   */
  matchesAny(el, selectors) {
    if (!el || el.nodeType !== 1 || !selectors || selectors.length === 0) return false;
    return el.matches(selectors.join(','));
  }

  isHeading(el) {
    return this.matchesAny(el, this.config.fragmentation.headingSelectors);
  }

  isListIntro(el) {
    if (!el || el.nodeType !== 1) return false;
    if (this.matchesAny(el, this.config.fragmentation.listIntroSelectors)) return true;
    // Heuristic: paragraph immediately preceding a list that ends with ':'
    if (el.tagName === 'P' && this.isList(el.nextElementSibling)) {
      const text = (el.textContent || '').trim();
      if (text.endsWith(':')) return true;
    }
    return false;
  }

  isAtomic(el) {
    return this.matchesAny(el, this.config.fragmentation.atomicSelectors);
  }

  isFramedBox(el) {
    if (this.matchesAny(el, this.config.fragmentation.framedSelectors)) return true;
    const style = getComputed(el);
    const hasBorder = (parseFloat(style.borderBottomWidth) || 0) > 0;
    const bg = style.backgroundColor;
    const hasBg = Boolean(bg && bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent');
    return hasBorder || hasBg;
  }

  isFlowContainer(el) {
    if (this.isAtomic(el)) return false;
    return this.matchesAny(el, this.config.fragmentation.flowContainerSelectors);
  }

  isTable(el) {
    return el?.tagName === 'TABLE';
  }

  isList(el) {
    return el?.tagName === 'UL' || el?.tagName === 'OL';
  }

  isContinuationMarker(el) {
    return el?.getAttribute?.('data-injected-continuation') === 'true';
  }

  /**
   * Computes box metrics for an element
   */
  getElementMetrics(el) {
    const rect = el.getBoundingClientRect();
    const style = getComputed(el);
    const marginTop = parseFloat(style.marginTop) || 0;
    const marginBottom = parseFloat(style.marginBottom) || 0;
    const paddingTop = parseFloat(style.paddingTop) || 0;
    const paddingBottom = parseFloat(style.paddingBottom) || 0;
    const borderTop = parseFloat(style.borderTopWidth) || 0;
    const borderBottom = parseFloat(style.borderBottomWidth) || 0;
    const fontSize = parseFloat(style.fontSize) || 16;
    const rawLh = parseFloat(style.lineHeight);
    const lineHeight = Number.isNaN(rawLh) ? fontSize * 1.4 : rawLh;

    return {
      height: rect.height,
      marginTop,
      marginBottom,
      paddingTop,
      paddingBottom,
      borderTop,
      borderBottom,
      lineHeight,
    };
  }

  /**
   * Computes vertical advance accounting for CSS margin collapse
   */
  getCollapsedAdvance(prevMarginBottom, currMarginTop, currHeight, isTopOfPage) {
    if (isTopOfPage) return currHeight;
    return Math.max(prevMarginBottom, currMarginTop) + currHeight;
  }

  /**
   * Marks the terminal node on a page (with framed-box protection and ancestor propagation)
   * and attaches .js-forced-page-break to the first node of the next page.
   * Never marks a heading or list-intro as .is-page-bottom: if lastElementOnPage is a
   * heading/list-intro chain, pulls the forced break back to the start of that chain.
   */
  commitPageBreak(lastElementOnPage, firstElementOnNextPage, rootBoundary) {
    let bottomTarget = lastElementOnPage;
    let breakTarget = firstElementOnNextPage;

    while (bottomTarget && (this.isHeading(bottomTarget) || this.isListIntro(bottomTarget))) {
      breakTarget = bottomTarget;
      bottomTarget = bottomTarget.previousElementSibling;
    }

    if (bottomTarget) {
      this.applyPageBottomSuppression(bottomTarget, rootBoundary);
    }
    if (breakTarget) {
      breakTarget.classList.add('js-forced-page-break');
    }
  }

  applyPageBottomSuppression(el, rootBoundary) {
    let curr = el;
    while (curr && curr !== rootBoundary && curr.nodeType === 1) {
      curr.classList.add('is-page-bottom');
      if (this.isFramedBox(curr)) {
        curr.classList.add('is-framed-box');
      }
      // If `curr` is the last visible element inside a parent flow container, propagate upward
      const parent = curr.parentElement;
      if (parent && parent !== rootBoundary && parent.lastElementChild === curr) {
        curr = parent;
      } else {
        break;
      }
    }
  }

  /**
   * Transitive Clearance Calculator for Headings & List Introductions.
   * Walks through chained headings (e.g., h1 -> h2 -> p.list-intro -> ul) so a heading chain
   * is never stranded at the bottom of a page without its target content block.
   */
  computeGlueChainClearance(startEl) {
    let totalHeight = 0;
    let curr = startEl;
    let prevMarginBottom = 0;
    let depth = 0;
    const {
      minTableRowsBeforeSplit,
      minTableRowsAfterSplit,
      minListItemsBeforeSplit,
      minListItemsAfterSplit,
      minOrphanLines,
      minWidowLines,
      headingGlueLines,
    } = this.config.fragmentation;

    while (curr && depth < 6) {
      const m = this.getElementMetrics(curr);
      const topGap = depth === 0 ? 0 : Math.max(prevMarginBottom, m.marginTop);

      if (this.isHeading(curr) || this.isListIntro(curr)) {
        totalHeight += topGap + m.height;
        prevMarginBottom = m.marginBottom;
        curr = curr.nextElementSibling;
        depth++;
        continue;
      }

      // Reached the terminal content target of the glue chain
      if (this.isAtomic(curr)) {
        totalHeight += topGap + m.height;
      } else if (this.isTable(curr)) {
        const thead = curr.querySelector('thead');
        const theadH = thead ? thead.getBoundingClientRect().height : 0;
        const rows = Array.from(curr.querySelectorAll('tbody > tr, :scope > tr')).filter(
          (r) => !r.closest('thead') && !r.closest('tfoot')
        );
        if (rows.length < minTableRowsBeforeSplit + minTableRowsAfterSplit) {
          totalHeight += topGap + m.height;
        } else {
          const minRows = rows.slice(0, minTableRowsBeforeSplit);
          const minRowsH = minRows.reduce((sum, r) => sum + r.getBoundingClientRect().height, 0);
          totalHeight += topGap + theadH + minRowsH;
        }
      } else if (this.isList(curr)) {
        const allItems = Array.from(curr.children).filter((c) => c.tagName === 'LI');
        if (allItems.length < minListItemsBeforeSplit + minListItemsAfterSplit) {
          totalHeight += topGap + m.height;
        } else {
          const items = allItems.slice(0, minListItemsBeforeSplit);
          let minItemsH = 0;
          for (let i = 0; i < items.length; i++) {
            const im = this.getElementMetrics(items[i]);
            const prevImb = i > 0 ? this.getElementMetrics(items[i - 1]).marginBottom : 0;
            minItemsH += im.height + (i > 0 ? Math.max(prevImb, im.marginTop) : 0);
          }
          totalHeight += topGap + minItemsH;
        }
      } else {
        // Standard prose paragraph: if too short to split under orphan+widow guards, require full height;
        // otherwise require at least max(headingGlueLines, minOrphanLines) lines.
        const minSplittableH = m.lineHeight * (minOrphanLines + minWidowLines);
        const requiredLinesH = m.height < minSplittableH
          ? m.height
          : Math.min(m.height, m.lineHeight * Math.max(headingGlueLines, minOrphanLines));
        totalHeight += topGap + requiredLinesH;
      }
      break;
    }

    return totalHeight;
  }

  /**
   * Computes active rowspan coverage so table splitting never slices through a spanned cell.
   */
  findSafeTableSplitIndex(rows, candidateSplitIndex) {
    const lockedToPrevious = new Array(rows.length).fill(false);
    for (let rIdx = 0; rIdx < rows.length; rIdx++) {
      const cells = rows[rIdx].querySelectorAll('td, th');
      cells.forEach((cell) => {
        const span = parseInt(cell.getAttribute('rowspan') || '1', 10);
        if (span > 1) {
          for (let k = 1; k < span && rIdx + k < rows.length; k++) {
            lockedToPrevious[rIdx + k] = true;
          }
        }
      });
    }

    let safeIdx = candidateSplitIndex;
    while (safeIdx > 0 && lockedToPrevious[safeIdx]) {
      safeIdx--;
    }
    return safeIdx;
  }

  /**
   * Splits a multi-row table across pages while enforcing orphan/widow row guards,
   * rowspan integrity, repeated <thead>, relocated <tfoot>, and injected continuation marker.
   */
  splitTableAtBoundary(tableEl, remainingBudgetPx, rootBoundary) {
    const { minTableRowsBeforeSplit, minTableRowsAfterSplit, continuationLabel } = this.config.fragmentation;
    const tolerance = this.config.px.subPixelTolerance;
    const doc = tableEl.ownerDocument || document;

    const thead = tableEl.querySelector('thead');
    const theadHeight = thead ? thead.getBoundingClientRect().height : 0;
    const tbody = tableEl.querySelector('tbody') || tableEl;
    const allRows = Array.from(tbody.querySelectorAll(':scope > tr')).filter(
      (r) => !r.closest('thead') && !r.closest('tfoot')
    );

    if (allRows.length < minTableRowsBeforeSplit + minTableRowsAfterSplit) {
      return null;
    }

    let consumedHeight = theadHeight;
    let rawSplitIndex = -1;

    for (let i = 0; i < allRows.length; i++) {
      const rowHeight = allRows[i].getBoundingClientRect().height;
      if (consumedHeight + rowHeight > remainingBudgetPx + tolerance) {
        rawSplitIndex = i;
        break;
      }
      consumedHeight += rowHeight;
    }

    if (rawSplitIndex === -1) return null;

    // Adjust for rowspan locks
    let splitIndex = this.findSafeTableSplitIndex(allRows, rawSplitIndex);

    if (splitIndex < minTableRowsBeforeSplit) {
      return null; // Cannot leave fewer than minTableRowsBeforeSplit on current page
    }

    const rowsRemaining = allRows.length - splitIndex;
    if (rowsRemaining < minTableRowsAfterSplit) {
      splitIndex = this.findSafeTableSplitIndex(allRows, allRows.length - minTableRowsAfterSplit);
      if (splitIndex < minTableRowsBeforeSplit) {
        return null;
      }
    }

    const originId = tableEl.getAttribute('data-split-origin-id') || `tbl-${Math.random().toString(36).slice(2, 9)}`;
    tableEl.setAttribute('data-split-origin-id', originId);

    // 1. Create continuation marker (starts the new page)
    const captionDiv = doc.createElement('div');
    captionDiv.className = 'continuation-marker table-continuation-caption js-forced-page-break';
    captionDiv.setAttribute('data-injected-continuation', 'true');
    captionDiv.textContent = continuationLabel;

    // 2. Clone table shell + thead
    const continuedTable = tableEl.cloneNode(false);
    continuedTable.classList.remove('js-forced-page-break', 'is-page-bottom', 'is-framed-box');
    continuedTable.setAttribute('data-split-origin-id', originId);

    if (thead) {
      continuedTable.appendChild(thead.cloneNode(true));
    }

    const continuedTbody = doc.createElement('tbody');
    const rowsToMove = allRows.slice(splitIndex);
    rowsToMove.forEach((r) => continuedTbody.appendChild(r));
    continuedTable.appendChild(continuedTbody);

    const tfoot = tableEl.querySelector('tfoot');
    if (tfoot) {
      continuedTable.appendChild(tfoot);
    }

    tableEl.after(captionDiv, continuedTable);
    this.applyPageBottomSuppression(tableEl, rootBoundary);

    return captionDiv;
  }

  /**
   * Splits an ordered or unordered list across pages with continuation marker and <ol start="N"> preservation.
   */
  splitListAtBoundary(listEl, remainingBudgetPx, rootBoundary) {
    const { minListItemsBeforeSplit, minListItemsAfterSplit, continuationLabel } = this.config.fragmentation;
    const tolerance = this.config.px.subPixelTolerance;
    const doc = listEl.ownerDocument || document;

    const items = Array.from(listEl.children).filter((el) => el.tagName === 'LI');
    if (items.length < minListItemsBeforeSplit + minListItemsAfterSplit) {
      return null;
    }

    let consumedHeight = 0;
    let splitIndex = -1;

    for (let i = 0; i < items.length; i++) {
      const m = this.getElementMetrics(items[i]);
      const prevMb = i > 0 ? this.getElementMetrics(items[i - 1]).marginBottom : 0;
      const itemAdvance = m.height + (i > 0 ? Math.max(prevMb, m.marginTop) : 0);

      if (consumedHeight + itemAdvance > remainingBudgetPx + tolerance) {
        splitIndex = i;
        break;
      }
      consumedHeight += itemAdvance;
    }

    if (splitIndex === -1) return null;
    if (splitIndex < minListItemsBeforeSplit) return null;

    const itemsRemaining = items.length - splitIndex;
    if (itemsRemaining < minListItemsAfterSplit) {
      splitIndex = items.length - minListItemsAfterSplit;
      if (splitIndex < minListItemsBeforeSplit) {
        return null;
      }
    }

    const originId = listEl.getAttribute('data-split-origin-id') || `lst-${Math.random().toString(36).slice(2, 9)}`;
    listEl.setAttribute('data-split-origin-id', originId);

    const captionDiv = doc.createElement('div');
    captionDiv.className = 'continuation-marker list-continuation-caption js-forced-page-break';
    captionDiv.setAttribute('data-injected-continuation', 'true');
    captionDiv.textContent = continuationLabel;

    const continuedList = listEl.cloneNode(false);
    continuedList.classList.remove('js-forced-page-break', 'is-page-bottom', 'is-framed-box');
    continuedList.setAttribute('data-split-origin-id', originId);

    if (listEl.tagName === 'OL') {
      const baseStart = parseInt(listEl.getAttribute('start') || '1', 10);
      continuedList.setAttribute('start', String(baseStart + splitIndex));
    }

    const itemsToMove = items.slice(splitIndex);
    itemsToMove.forEach((li) => continuedList.appendChild(li));

    listEl.after(captionDiv, continuedList);
    this.applyPageBottomSuppression(listEl, rootBoundary);

    return captionDiv;
  }

  /**
   * Next-node helper that descends into flow containers (`<section>`, `.flow-container`)
   * so template wrappers do not act as monolithic unbreakable blocks.
   */
  getNextFlowBlock(currentEl, rootBoundary) {
    if (!currentEl) return null;

    if (this.isFlowContainer(currentEl) && currentEl.firstElementChild) {
      return currentEl.firstElementChild;
    }

    if (currentEl.nextElementSibling) {
      return currentEl.nextElementSibling;
    }

    let parent = currentEl.parentElement;
    while (parent && parent !== rootBoundary) {
      if (parent.nextElementSibling) {
        return parent.nextElementSibling;
      }
      parent = parent.parentElement;
    }

    return null;
  }

  /**
   * Main execution pass: normalizes geometry, enforces glueing and atomic push-downs,
   * splits overflowing tables/lists with continuation markers, and suppresses bottom margins.
   */
  async normalizeEditorialGeometry(documentRoot = this.documentRoot) {
    if (!documentRoot) {
      throw new Error('[EditorialGeometryEngine] documentRoot is required.');
    }

    const doc = documentRoot.ownerDocument || (typeof document !== 'undefined' ? document : null);
    if (doc?.fonts?.ready) {
      await doc.fonts.ready;
    }

    // Re-resolve template config against documentRoot and apply CSS/@page rules
    this.documentRoot = documentRoot;
    this.config = this.resolveTemplateConfig(this.rawConfig, this.options, documentRoot);
    this.syncTemplateCssAndPageRules(doc);
    this.unrollPaginationMutations(documentRoot);

    const tolerance = this.config.px.subPixelTolerance;
    const pushDownThreshold = this.config.px.pushDownThreshold;
    const { minOrphanLines, minWidowLines } = this.config.fragmentation;

    let currentPageIndex = 0;
    let currentPageY = 0;
    let prevMarginBottom = 0;
    let lastElementOnCurrentPage = null;

    let cursor = documentRoot.firstElementChild;

    while (cursor) {
      const style = getComputed(cursor);
      if (style.display === 'none' || style.position === 'fixed' || style.position === 'absolute') {
        cursor = this.getNextFlowBlock(cursor, documentRoot);
        continue;
      }

      // If cursor is a transparent semantic wrapper (<section>, .flow-container), account for its top padding/border and descend
      if (this.isFlowContainer(cursor) && cursor.firstElementChild) {
        const wrapperMetrics = this.getElementMetrics(cursor);
        const topOffset = wrapperMetrics.paddingTop + wrapperMetrics.borderTop;
        if (currentPageY > 0) {
          currentPageY += Math.max(prevMarginBottom, wrapperMetrics.marginTop) + topOffset;
        } else {
          currentPageY += topOffset;
        }
        prevMarginBottom = 0;
        cursor = cursor.firstElementChild;
        continue;
      }

      // Handle explicit CSS/JS forced page break on current node
      const hasExplicitBreak =
        cursor.classList.contains('js-forced-page-break') ||
        style.breakBefore === 'page' ||
        style.pageBreakBefore === 'always';

      if (hasExplicitBreak && currentPageY > 0) {
        if (lastElementOnCurrentPage) {
          this.applyPageBottomSuppression(lastElementOnCurrentPage, documentRoot);
        }
        currentPageIndex++;
        currentPageY = 0;
        prevMarginBottom = 0;
      }

      const usableHeight = this.getUsablePageHeightPx(currentPageIndex);
      const isTopOfPage = currentPageY === 0;
      const isAfterContinuation = this.isContinuationMarker(cursor.previousElementSibling);
      const canBreakBeforeCursor = !isTopOfPage && !isAfterContinuation;

      const metrics = this.getElementMetrics(cursor);
      const remainingBudget = usableHeight - currentPageY;
      const advance = this.getCollapsedAdvance(prevMarginBottom, metrics.marginTop, metrics.height, isTopOfPage);

      // 1. CONTINUATION MARKERS (Always sit at the top of the newly broken page)
      if (this.isContinuationMarker(cursor)) {
        currentPageY += metrics.height;
        prevMarginBottom = metrics.marginBottom;
        lastElementOnCurrentPage = cursor;
        cursor = this.getNextFlowBlock(cursor, documentRoot);
        continue;
      }

      // 2. HEADINGS & LIST INTRODUCTIONS (Enforce threshold + transitive glue clearance)
      if (this.isHeading(cursor) || this.isListIntro(cursor)) {
        const glueClearance = this.computeGlueChainClearance(cursor);
        const topCollapse = isTopOfPage ? 0 : Math.max(prevMarginBottom, metrics.marginTop);
        const requiredClearance =
          topCollapse + Math.max(glueClearance, this.isHeading(cursor) ? pushDownThreshold : glueClearance);

        if (canBreakBeforeCursor && requiredClearance > remainingBudget + tolerance) {
          this.commitPageBreak(lastElementOnCurrentPage, cursor, documentRoot);
          currentPageIndex++;
          currentPageY = metrics.height;
          prevMarginBottom = metrics.marginBottom;
          lastElementOnCurrentPage = cursor;
          cursor = this.getNextFlowBlock(cursor, documentRoot);
          continue;
        }
      }

      // 3. ATOMIC CONTAINERS (Callouts, Metric Cards, Blockquotes, Signatures — Never split)
      if (this.isAtomic(cursor)) {
        const nextPageUsableHeight = this.getUsablePageHeightPx(currentPageIndex + 1);
        if (metrics.height > Math.max(usableHeight, nextPageUsableHeight)) {
          cursor.classList.add('allow-emergency-split');
        } else if (canBreakBeforeCursor && advance > remainingBudget + tolerance) {
          this.commitPageBreak(lastElementOnCurrentPage, cursor, documentRoot);
          currentPageIndex++;
          currentPageY = metrics.height;
          prevMarginBottom = metrics.marginBottom;
          lastElementOnCurrentPage = cursor;
          cursor = this.getNextFlowBlock(cursor, documentRoot);
          continue;
        }
      }

      // 4. MULTI-ROW TABLES (Split with repeated <thead> + continuation marker, or push down)
      if (this.isTable(cursor)) {
        if (advance > remainingBudget + tolerance) {
          const topCollapse = isTopOfPage ? 0 : Math.max(prevMarginBottom, metrics.marginTop);
          const tableBudget = remainingBudget - topCollapse;

          const injectedCaption = this.splitTableAtBoundary(cursor, tableBudget, documentRoot);
          if (injectedCaption) {
            currentPageIndex++;
            currentPageY = 0;
            prevMarginBottom = 0;
            lastElementOnCurrentPage = null;
            cursor = injectedCaption;
            continue;
          } else if (canBreakBeforeCursor) {
            this.commitPageBreak(lastElementOnCurrentPage, cursor, documentRoot);
            currentPageIndex++;
            currentPageY = 0;
            prevMarginBottom = 0;
            lastElementOnCurrentPage = null;
            continue;
          }
        }
      }

      // 5. LISTS (UL / OL — Split with continuation marker + <ol start="N">, or push down)
      if (this.isList(cursor)) {
        if (advance > remainingBudget + tolerance) {
          const topCollapse = isTopOfPage ? 0 : Math.max(prevMarginBottom, metrics.marginTop);
          const listBudget = remainingBudget - topCollapse;

          const injectedCaption = this.splitListAtBoundary(cursor, listBudget, documentRoot);
          if (injectedCaption) {
            currentPageIndex++;
            currentPageY = 0;
            prevMarginBottom = 0;
            lastElementOnCurrentPage = null;
            cursor = injectedCaption;
            continue;
          } else if (canBreakBeforeCursor) {
            this.commitPageBreak(lastElementOnCurrentPage, cursor, documentRoot);
            currentPageIndex++;
            currentPageY = 0;
            prevMarginBottom = 0;
            lastElementOnCurrentPage = null;
            continue;
          }
        }
      }

      // 6. STANDARD PROSE & GENERIC BLOCKS
      if (advance > remainingBudget + tolerance) {
        const topCollapse = isTopOfPage ? 0 : Math.max(prevMarginBottom, metrics.marginTop);
        const availableForText = remainingBudget - topCollapse;
        const minOrphanH = metrics.lineHeight * minOrphanLines;
        const minWidowH = metrics.lineHeight * minWidowLines;

        const canSplitProse =
          availableForText >= minOrphanH &&
          metrics.height - availableForText >= minWidowH;

        if (!canSplitProse && canBreakBeforeCursor) {
          this.commitPageBreak(lastElementOnCurrentPage, cursor, documentRoot);
          currentPageIndex++;
          currentPageY = metrics.height;
          prevMarginBottom = metrics.marginBottom;
          lastElementOnCurrentPage = cursor;
          cursor = this.getNextFlowBlock(cursor, documentRoot);
          continue;
        } else {
          const spilledHeight = Math.max(0, metrics.height - Math.max(0, availableForText));
          currentPageIndex++;
          const nextUsable = this.getUsablePageHeightPx(currentPageIndex);
          currentPageY = spilledHeight % nextUsable;
          prevMarginBottom = metrics.marginBottom;
          lastElementOnCurrentPage = cursor;
          cursor = this.getNextFlowBlock(cursor, documentRoot);
          continue;
        }
      }

      // Element fits cleanly on the current virtual page
      currentPageY += advance;
      prevMarginBottom = metrics.marginBottom;
      lastElementOnCurrentPage = cursor;
      cursor = this.getNextFlowBlock(cursor, documentRoot);
    }

    // Suppress trailing margin/padding on the final node of the entire document
    if (lastElementOnCurrentPage) {
      this.applyPageBottomSuppression(lastElementOnCurrentPage, documentRoot);
    }

    return {
      status: 'normalized',
      templateId: this.config.templateId,
      totalPagesEstimated: currentPageIndex + 1,
      resolvedGeometry: this.config,
    };
  }
}

export async function normalizeEditorialGeometry(documentRoot, rawConfig = {}, options = {}) {
  const engine = new EditorialGeometryEngine(rawConfig, options, documentRoot);
  return engine.normalizeEditorialGeometry(documentRoot);
}

/**
 * Falsifiable 6-Gate Verification & Automated Audit Suite (Master Specification §3).
 */
export function verifyTemplateEditorialGeometry(documentRoot) {
  const errors = [];
  const doc = documentRoot?.ownerDocument || (typeof document !== 'undefined' ? document : null);

  // Gate 1: Dynamic @page style tag exists and matches resolved CSS custom properties
  const pageStyleTag = doc?.getElementById?.('editorial-template-page-rules');
  if (!pageStyleTag || !pageStyleTag.textContent.includes('@page')) {
    errors.push('Gate 1 Failed: Missing #editorial-template-page-rules dynamic stylesheet.');
  }

  // Gate 2: Every .js-forced-page-break (except the very first element) is preceded by an .is-page-bottom ancestor/sibling
  const forcedBreaks = documentRoot.querySelectorAll('.js-forced-page-break');
  forcedBreaks.forEach((el, idx) => {
    const prev = el.previousElementSibling;
    if (prev && !prev.classList.contains('is-page-bottom') && !prev.querySelector('.is-page-bottom')) {
      errors.push(`Gate 2 Failed: Forced break #${idx} (${el.tagName}) is not preceded by an .is-page-bottom node.`);
    }
  });

  // Gate 3: Every .is-page-bottom element has 0px computed marginBottom (and 0px paddingBottom if unframed)
  documentRoot.querySelectorAll('.is-page-bottom').forEach((el, idx) => {
    const style = getComputed(el);
    if (parseFloat(style.marginBottom) !== 0) {
      errors.push(`Gate 3 Failed: .is-page-bottom #${idx} (${el.tagName}) has non-zero marginBottom (${style.marginBottom}).`);
    }
    if (!el.classList.contains('is-framed-box') && parseFloat(style.paddingBottom) !== 0) {
      errors.push(`Gate 3 Failed: Unframed .is-page-bottom #${idx} (${el.tagName}) has non-zero paddingBottom (${style.paddingBottom}).`);
    }
  });

  // Gate 4: No heading or list-intro is marked as .is-page-bottom (Zero stranded headings)
  documentRoot.querySelectorAll('h1, h2, h3, h4, .list-intro, [data-list-intro="true"]').forEach((h) => {
    if (h.classList.contains('is-page-bottom')) {
      errors.push(`Gate 4 Failed: Stranded heading/intro detected at page bottom (${h.tagName}: "${h.textContent.slice(0, 30)}").`);
    }
  });

  // Gate 5: Multi-page split tables and lists have an inseparable .continuation-marker and valid headers/numbering
  const seenTableOrigins = new Set();
  documentRoot.querySelectorAll('table[data-split-origin-id]').forEach((tbl) => {
    const originId = tbl.getAttribute('data-split-origin-id');
    if (seenTableOrigins.has(originId)) {
      const marker = tbl.previousElementSibling;
      if (!marker || !marker.classList.contains('table-continuation-caption')) {
        errors.push(`Gate 5 Failed: Split table (${originId}) missing preceding .table-continuation-caption.`);
      }
      if (tbl.classList.contains('js-forced-page-break')) {
        errors.push(`Gate 5 Failed: Split table (${originId}) broke away from its own continuation marker.`);
      }
      if (!tbl.querySelector('thead')) {
        errors.push(`Gate 5 Failed: Split table (${originId}) missing cloned <thead>.`);
      }
    }
    seenTableOrigins.add(originId);
  });

  // Gate 6: Final terminal element of the document has 0px bottom margin (No trailing blank page)
  const lastChild = documentRoot.lastElementChild;
  if (lastChild) {
    const lastStyle = getComputed(lastChild);
    if (parseFloat(lastStyle.marginBottom) !== 0) {
      errors.push(`Gate 6 Failed: Final document element has residual marginBottom (${lastStyle.marginBottom}).`);
    }
  }

  return {
    passed: errors.length === 0,
    errorCount: errors.length,
    errors,
  };
}
