/* DOE Formatter — V2-modular prototype app.
 * Single source of truth: DocumentStore (boxes + globals, one storage key).
 * Engine locked: engine:'v2-modular' -> PdfEngine + pdfkit driver (server-side).
 * Editors behind EditorAdapter seam: TextareaAdapter (Markdown) + BlockEditor
 * from ./editor-core.js (Rich block cards, zero dependencies).
 */
import { BlockEditor, serializeFigureLine, applyRichCommand, detectRichState, canExecCommand, pushUndo, popUndo, hidePortalToolbars, purgePortalToolbars, digitOf, uiPortal, menuShelf, closePortalMenus, INSERT_ITEMS, insertSnippetFor, slashNavIndex, pasteUrlLink, initializeEditorialPagination, normalizeEditorialGeometry, verifyTemplateEditorialGeometry } from './editor-core.js';
import { normalizeBox, normalizeForEditor, stripGroundingTags, DocumentStore, uid } from './document-store.js';
import { ENGINE, ExportPayloadBuilder } from './export-payload.js';
import { TextareaAdapter, isEditorAdapter } from './editor-adapters.js';

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

/* NOTE (CC1): EditorText normalization (TagSanitizer/BulletNormalizer port),
 * DocumentStore + ExportPayloadBuilder live in ./document-store.js and
 * ./export-payload.js; this bundle imports and re-exports the test seam. */


/* NOTE (CC1): moved to ./document-store.js — stripGroundingTags,
 * normalizeBullets, normalizeForEditor, DEFAULT_GLOBALS, normalizeBox,
 * DocumentStore (imported above). */

/* ------------------------------------------------------------------ */
/* EditorAdapter seam: uniform read/write/mode-switch/highlight        */
/* ------------------------------------------------------------------ */
/* NOTE (CC1): TextareaAdapter + isEditorAdapter moved to
 * ./editor-adapters.js (imported above, re-exported in the test seam below).
 * BlockEditor stays imported from ./editor-core.js; both program to the
 * EditorAdapter contract. */

/* Rich view: BlockEditor from ./editor-core.js (Phase 1 custom editor).
 * AST-canonical block cards over the same markdown string the store holds:
 * edits write canonical markdown back in place — no destroy+recreate
 * remount, no CDN fetch, no third-party reserialization. Toggle
 * Rich↔Markdown re-renders from the string, never parses editor DOM. */

/* NOTE (CC1): ExportPayloadBuilder moved to ./export-payload.js (imported above). */

/* ------------------------------------------------------------------ */
/* ExportService: all network triggers. Preview never downloads.       */
/* ------------------------------------------------------------------ */
function extractErrorMessage(data, fallback) {
  if (!data) return fallback;
  if (typeof data.detail === 'string') return data.detail;
  if (typeof data.error === 'string') return data.error;
  return fallback;
}

/* ------------------------------------------------------------------ */
/* Traffic shaping (D): client mirrors of the worker input guards.     */
/* Built payloads are traffic-only copies (fresh section objects from  */
/* ExportPayloadBuilder), so in-place scrubbing never touches the      */
/* DocumentStore. Server estimates are computed post-strip, therefore  */
/* stripping here changes zero TOC/pagination numbers — it only keeps  */
/* megabytes of base64 off the wire and out of the isolate.            */
/*                                                                     */
/* Worker-first images: preview/convert SEND data-URI bytes (the       */
/* worker extracts + renders real pixels pre-strip; Node resolves      */
/* them via resolveImageSource). Only the background paginate estimate */
/* strips, since it needs zero image bytes. Budgets still gate every   */
/* path via checkPayloadBudget.                                        */
/* ------------------------------------------------------------------ */
const DATA_URI_TRAFFIC_RE = /data:image\/[a-zA-Z0-9+.-]+;base64,[A-Za-z0-9+/=]+/g;
// Worker mirrors (src/_worker.js) — keep in sync or the client gate lies.
const BUDGET_MAX_SECTIONS = 30;
const BUDGET_MAX_CHARS = 150000;
const BUDGET_MAX_IMAGE_BYTES = 15 * 1024 * 1024;

function stripPayloadImages(payload, { strip = true } = {}) {
  let imageBytes = 0;
  let chars = 0;
  try {
    const scrub = (t) => {
      const stripped = String(t || '').replace(DATA_URI_TRAFFIC_RE, (m) => {
        const comma = m.indexOf(',');
        imageBytes += Math.max(0, m.length - comma - 1);
        return strip ? m.slice(0, comma + 1) : m;
      });
      chars += stripped.length;
      return stripped;
    };
    if (Array.isArray(payload.sections)) {
      for (const s of payload.sections) {
        if (s && typeof s.markdown === 'string') s.markdown = scrub(s.markdown);
        else if (s) chars += String(s.markdown || '').length;
      }
    }
    if (typeof payload.markdown === 'string') payload.markdown = scrub(payload.markdown);
  } catch { /* budgets read as accumulated */ }
  return { imageBytes: Math.floor(imageBytes * 3 / 4), chars };
}

function checkPayloadBudget(payload, scan) {
  if (Array.isArray(payload.sections) && payload.sections.length > BUDGET_MAX_SECTIONS) {
    return `Muitas seções (${payload.sections.length}/${BUDGET_MAX_SECTIONS}): divida o documento e gere em partes.`;
  }
  if (scan.imageBytes > BUDGET_MAX_IMAGE_BYTES) {
    return `Imagens pesam ~${(scan.imageBytes / 1048576).toFixed(1)}MB (limite 15MB): remova ou comprima figuras antes de enviar.`;
  }
  if (scan.chars > BUDGET_MAX_CHARS) {
    return `Texto com ${scan.chars} caracteres (limite 150000): divida em blocos menores.`;
  }
  return null;
}

const IMAGE_DOWNSCALE_MAX_DIM = 1600;
const IMAGE_DOWNSCALE_JPEG_Q = 0.82;
const IMAGE_DOWNSCALE_MIN_BYTES = 500 * 1024;

async function blobToDataUrl(blob) {
  if (typeof FileReader !== 'undefined') {
    return await new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(String(r.result));
      r.onerror = reject;
      r.readAsDataURL(blob);
    });
  }
  const bytes = new Uint8Array(await blob.arrayBuffer());
  let bin = '';
  const CHUNK = 0x8000;
  for (let i = 0; i < bytes.length; i += CHUNK) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
  }
  const b64 = (typeof btoa !== 'undefined') ? btoa(bin) : Buffer.from(bin, 'binary').toString('base64');
  return `data:${blob.type || 'application/octet-stream'};base64,${b64}`;
}

function loadImageEl(dataUrl) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = dataUrl;
  });
}

function canvasToBlob(canvas, type, quality) {
  return new Promise((resolve, reject) => {
    try {
      canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('toBlob null'))), type, quality);
    } catch (e) { reject(e); }
  });
}

// Downscale raster uploads at the source (user-approved: print-res not
// required). GIF/SVG/unknown types pass through untouched (animation +
// vectors must not be re-encoded). Never throws: any failure — missing
// canvas/Image APIs, decode error — falls back to the verbatim source.
async function downscaleImageToDataUrl(fileOrDataUrl) {
  const passthrough = (dataUrl) => ({ dataUrl, downscaled: false });
  try {
    let dataUrl;
    let mime = '';
    let bytes = 0;
    if (typeof Blob !== 'undefined' && fileOrDataUrl instanceof Blob) {
      mime = fileOrDataUrl.type || '';
      bytes = fileOrDataUrl.size || 0;
      dataUrl = await blobToDataUrl(fileOrDataUrl);
    } else if (typeof fileOrDataUrl === 'string' && fileOrDataUrl.startsWith('data:')) {
      dataUrl = fileOrDataUrl;
      const mm = dataUrl.match(/^data:([^;,]+)?(;base64)?,/);
      mime = (mm && mm[1]) || '';
      const comma = dataUrl.indexOf(',');
      bytes = Math.floor(Math.max(0, dataUrl.length - comma - 1) * 3 / 4);
    } else {
      return passthrough(fileOrDataUrl);
    }
    if (!/^(image\/jpeg|image\/jpg|image\/png|image\/webp)$/i.test(mime) && !/^(image\/gif|image\/bmp|image\/x-ms-bmp)$/i.test(mime)) return passthrough(dataUrl);
    // IMAGE M1: gif/bmp transcode at ANY size — transcoding is correctness,
    // not optimization (the server rasterizes png/jpeg only, so small ones
    // died at 422). HEIC is rejected upstream in uploadImage: no browser
    // decoder to lean on.
    if (!/^(image\/gif|image\/bmp|image\/x-ms-bmp)$/i.test(mime) && bytes < IMAGE_DOWNSCALE_MIN_BYTES) return passthrough(dataUrl);
    if (typeof Image === 'undefined' || typeof document === 'undefined') return passthrough(dataUrl);
    const img = await loadImageEl(dataUrl);
    const w = img.naturalWidth || img.width || 0;
    const h = img.naturalHeight || img.height || 0;
    if (!w || !h) return passthrough(dataUrl);
    const scale = Math.min(1, IMAGE_DOWNSCALE_MAX_DIM / Math.max(w, h));
    const cw = Math.max(1, Math.round(w * scale));
    const ch = Math.max(1, Math.round(h * scale));
    const canvas = document.createElement('canvas');
    canvas.width = cw; canvas.height = ch;
    const ctx = canvas.getContext('2d');
    if (!ctx) return passthrough(dataUrl);
    // IMAGE M1: JPEG has no alpha — fill white first or transparent PNGs
    // come out with black boxes downstream.
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, cw, ch);
    ctx.drawImage(img, 0, 0, cw, ch);
    const out = await canvasToBlob(canvas, 'image/jpeg', IMAGE_DOWNSCALE_JPEG_Q);
    return { dataUrl: await blobToDataUrl(out), downscaled: true };
  } catch {
    try {
      if (typeof Blob !== 'undefined' && fileOrDataUrl instanceof Blob) {
        return passthrough(await blobToDataUrl(fileOrDataUrl));
      }
    } catch { /* fall through */ }
    return passthrough(typeof fileOrDataUrl === 'string' ? fileOrDataUrl : '');
  }
}

const ExportService = {
  async convert(payload, signal = null) {
    // D: fail-fast single attempt. A 503 here is Cloudflare Error 1102
    // (isolate CPU exhausted) — retrying the identical multi-MB payload
    // would burn up to 3× isolate CPU (thundering herd on the exact
    // failure being reported), so surface the guidance immediately.
    const fetchOpts = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    };
    if (signal) fetchOpts.signal = signal;
    const res = await fetch('/api/convert', fetchOpts);

    if (!res || !res.ok) {
      let msg = `Falha na conversão (${res ? res.status : 'network error'})`;
      try { msg = extractErrorMessage(await res.json(), msg); } catch { /* keep default */ }
      if (res && res.status === 503) {
        // Cloudflare Error 1102: isolate CPU/memory budget exceeded, NOT a
        // backend 500. Actionable: shrink payload, strip images, split
        // sections, or offload via PDF_BACKEND_URL (see wrangler.json).
        msg = `${msg} — o Worker Cloudflare estourou o limite de CPU (Erro 1102). Tente: 1) pré-visualizar miniatura, 2) remover imagens grandes, 3) dividir em menos seções, 4) configurar PDF_BACKEND_URL para um backend Node.`;
      }
      throw new Error(msg);
    }
    const blob = await res.blob();
    return {
      blob,
      engineUsed: res.headers.get('X-Engine-Used') || ENGINE,
      geometryUsed: res.headers.get('X-Geometry-Version') || payload.geometry || 'v3',
      toc: ExportService.parseToc(res.headers.get('X-Document-TOC')),
      totalPages: Number(res.headers.get('X-Total-Pages') || 0) || null,
    };
  },
  parseToc(raw) {
    if (!raw) return null;
    try { return JSON.parse(decodeURIComponent(raw)); } catch { return null; }
  },
  download(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  },
  async uploadImage(fileOrDataUrl, filename = 'figura.png') {
    // IMAGE M1: HEIC fails fast with guidance — no browser decoder to lean
    // on for transcoding, and the server would 422 anyway. Covers picker,
    // paste, drop and data-URL paths (all funnel through here).
    const guessName = (typeof fileOrDataUrl !== 'string' && fileOrDataUrl?.name) || filename || '';
    const guessMime = (typeof fileOrDataUrl !== 'string' && fileOrDataUrl?.type)
      || (typeof fileOrDataUrl === 'string' ? (fileOrDataUrl.match(/^data:([^;,]+)/)?.[1] || '') : '');
    if (/heic|heif/i.test(guessMime) || /\.(heic|heif)(\?.*)?$/i.test(guessName)) {
      throw new Error('HEIC do iPhone não suportado: converta para JPEG ou PNG antes de enviar.');
    }
    let data = fileOrDataUrl;
    if (typeof Blob !== 'undefined' && fileOrDataUrl instanceof Blob) {
      // D: downscale raster photos/screenshots at the source (see
      // downscaleImageToDataUrl). Falls back to verbatim bytes, so this
      // never breaks uploads where canvas/Image are unavailable.
      filename = fileOrDataUrl.name || filename;
      ({ dataUrl: data } = await downscaleImageToDataUrl(fileOrDataUrl));
    } else if (typeof data === 'string' && /^data:image\//.test(data)) {
      // Re-upload path (pasted originals): same treatment, same fallback.
      ({ dataUrl: data } = await downscaleImageToDataUrl(data));
    }
    const res = await fetch('/api/upload-image', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ data, filename }),
    });
    if (!res.ok) {
      let msg = `Upload falhou (${res.status})`;
      try {
        const errJson = await res.json();
        const detail = errJson?.error || errJson?.detail;
        if (typeof detail === 'string' && detail) msg = detail;
        else if (detail?.message) msg = detail.message;
        else if (errJson?.code) msg = `${msg}: ${errJson.code}`;
      } catch { /* keep status message */ }
      throw new Error(msg);
    }
    const json = await res.json();
    if (!json.url) throw new Error('Upload sem URL de retorno');
    return json.url;
  },
  async paginate(payload, signal = null) {
    const fetchOpts = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    };
    if (signal) fetchOpts.signal = signal;
    const res = await fetch('/api/paginate', fetchOpts);
    if (!res.ok) return null;
    try { return await res.json(); } catch { return null; }
  },
};

/* ------------------------------------------------------------------ */
/* PreviewManager: inline blob lifecycle, mini vs full, badge          */
/* ------------------------------------------------------------------ */
const PreviewManager = {
  blobUrl: null,
  full: false,
  activeController: null,
  revoke() { if (this.blobUrl) { URL.revokeObjectURL(this.blobUrl); this.blobUrl = null; } },
  async open(store, { full = false } = {}) {
    if (this.activeController) {
      try { this.activeController.abort(); } catch { /* aborted */ }
    }
    this.activeController = new AbortController();
    const signal = this.activeController.signal;

    this.full = full;
    if (!this._lastFocus) this._lastFocus = document.activeElement;
    $('#preview-modal').classList.remove('hidden');
    $('#preview-loading').classList.remove('hidden');
    $('#preview-toggle-full-btn').textContent = full ? 'Ver Miniatura' : 'Ver Completo';
    const payload = ExportPayloadBuilder.build(store, { preview: true, preview_full: full });
    if (!full && Array.isArray(payload.sections) && payload.sections.length > 0) {
      // Mini preview stays inside the Workerd CPU budget (Error 1102/503):
      // first non-empty section, truncated to ~12k chars. "Ver Completo"
      // still sends the full payload.
      const first = payload.sections[0];
      const MAX_MINI_CHARS = 12000;
      if (typeof first.markdown === 'string' && first.markdown.length > MAX_MINI_CHARS) {
        first.markdown = `${first.markdown.slice(0, MAX_MINI_CHARS)}\n\n> …(pré-visualização truncada — use "Ver Completo" para o documento integral)`;
      }
      payload.sections = [first];
    }
    // D: measure (do NOT strip — the worker/Node render real pixels from
    // data-URI bytes) and enforce the worker budget client-side, so
    // oversized docs fail fast here instead of after upload + isolate CPU.
    // Note: mini truncation above may cut a data-URI mid-way; the worker
    // decode then fails soft to a placeholder for that figure only.
    const scan = stripPayloadImages(payload, { strip: false });
    const over = checkPayloadBudget(payload, scan);
    if (over) {
      // Fail fast with no stuck modal: hide spinner, close (revokes any stale
      // blob + restores focus), then surface the budget error as a toast.
      this.close();
      throw new Error(over);
    }

    try {
      const { blob, toc } = await ExportService.convert(payload, signal);
      if (signal.aborted) return null;
      if (full && toc?.sections) {
        lastPaginationData = toc;
        scheduleTocPreview();
      }
      this.revoke();
      this.blobUrl = URL.createObjectURL(blob);
      $('#preview-iframe').src = this.blobUrl;
      $('#preview-loading').classList.add('hidden');
      return blob;
    } catch (err) {
      if (err && err.name === 'AbortError') {
        return null; // Quietly handle user cancellation/debounce
      }
      $('#preview-loading').classList.add('hidden');
      throw err;
    } finally {
      if (this.activeController?.signal === signal) {
        this.activeController = null;
      }
    }
  },
  close() {
    if (this.activeController) {
      try { this.activeController.abort(); } catch { /* aborted */ }
      this.activeController = null;
    }
    $('#preview-modal').classList.add('hidden');
    $('#preview-iframe').removeAttribute('src');
    this.revoke();
    if (this._lastFocus?.focus) { this._lastFocus.focus(); this._lastFocus = null; }
  },
};

/* ------------------------------------------------------------------ */
/* WorkspaceController: flush adapters -> store, then build payload    */
/* ------------------------------------------------------------------ */
const adapters = new Map(); // boxId -> TextareaAdapter | BlockEditor
const store = new DocumentStore();

function flushAdaptersToStore() {
  for (const box of store.getBoxes()) {
    const ad = adapters.get(box.id);
    if (ad) box.markdown = ad.getContent();
  }
  store.save();
}

const errText = (e, fallback) => (e?.message || String(e || '') || fallback);

/* Menu open micro-fade (transform+opacity only: CLS-free). Called when a
   collapsed menu expands; restart-safe via reflow. */
function playMenuIn(el) {
  if (!el) return;
  el.classList.remove('menu-opening');
  void el.offsetWidth;
  el.classList.add('menu-opening');
}

/* Clean grounding/citation tags ([span_*], [cite_*]) across all boxes.
   Flushes adapters first (no keystroke loss), then pushes the cleaned text
   back through each adapter and the store. Cards re-render in place without shift. */
function cleanAllTags() {
  flushAdaptersToStore();
  let changed = 0;
  for (const box of store.getBoxes()) {
    const cleaned = stripGroundingTags(box.markdown || '');
    if (cleaned !== (box.markdown || '')) {
      changed++;
      box.markdown = cleaned;
      const card = document.querySelector(`[data-box-id="${box.id}"]`);
      const ad = adapters.get(box.id);
      if (box.mode === 'markdown' && ad instanceof TextareaAdapter) {
        ad.setContent(cleaned);
      } else if (ad && typeof ad.setContent === 'function') {
        ad.setContent(cleaned);
      } else if (card) {
        const ta = $('.box-md', card);
        if (ta) ta.value = cleaned;
      }
      if (card) updateCharCount(card, box.id);
    }
  }
  store.save();
  scheduleTocPreview();
  showError(
    changed === 0 ? 'Nenhuma tag encontrada.' : `Tags removidas em ${changed} bloco${changed === 1 ? '' : 's'}.`,
    { kind: changed === 0 ? 'warn' : 'ok' },
  );
}

function showError(msg, { sticky = false, kind = 'error' } = {}) {
  const box = $('#error-box');
  $('#error-message').textContent = msg;
  box.classList.toggle('is-ok', kind === 'ok');
  box.classList.remove('hidden');
  clearTimeout(showError._t);
  if (!sticky) showError._t = setTimeout(() => box.classList.add('hidden'), 6000);
}

/* ------------------------- card rendering ------------------------- */
function renderSegmented({ name, options, selectedValue, size = 'sm' }) {
  return `
    <div class="segmented ${size === 'sm' ? 'segmented-sm' : ''}" role="radiogroup">
      ${options.map(opt => `
        <label class="segment" ${opt.title ? `title="${escapeHtml(opt.title)}"` : ''}>
          <input type="radio" name="${name}" value="${opt.value}" ${opt.value === selectedValue ? 'checked' : ''}>
          <span>${escapeHtml(opt.label)}</span>
        </label>
      `).join('')}
    </div>
  `;
}

function cardTemplate(box, idx) {
  const el = document.createElement('article');
  el.className = `box-card block-card${box.ignored ? ' is-ignored' : ''}`;
  el.dataset.boxId = box.id;
  el.setAttribute('draggable', 'false');
  el.innerHTML = `
    <div class="box-header block-head">
      <div class="box-header-leading">
        <button class="icon-btn ticon drag-handle" data-act="drag" title="Arrastar para reordenar" aria-label="Arrastar bloco"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-grip"/></svg></button>
        <span class="box-index block-num">${idx + 1}</span>
        <input class="box-name block-title" value="${escapeHtml(box.title)}" aria-label="Título do bloco ${idx + 1}">
      </div>
    </div>
    <div class="box-header-actions toolbar-groups">
        <div class="action-cluster tgroup" role="group" aria-label="Reordenar bloco">
          <button class="icon-btn ticon" data-act="move-up" title="Mover bloco para cima" aria-label="Mover bloco para cima"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-up"/></svg></button>
          <button class="icon-btn ticon" data-act="move-down" title="Mover bloco para baixo" aria-label="Mover bloco para baixo"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-down"/></svg></button>
        </div>
        <div class="action-cluster tgroup" role="group" aria-label="Utilitários do bloco">
          <button class="icon-btn ticon" data-act="search" title="Buscar e substituir (Ctrl+F)" aria-label="Buscar e substituir no bloco"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-search"/></svg></button>
          <button class="icon-btn ticon" data-act="image" title="Inserir imagem no bloco" aria-label="Inserir imagem no bloco"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-image"/></svg></button>
        </div>
        <div class="action-cluster tgroup" role="group" aria-label="Histórico de edição">
          <button class="icon-btn ticon" data-act="undo" title="Desfazer (Ctrl+Z)" aria-label="Desfazer" disabled><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-undo"/></svg></button>
          <button class="icon-btn ticon" data-act="redo" title="Refazer (Ctrl+Shift+Z)" aria-label="Refazer" disabled><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-redo"/></svg></button>
        </div>
        <div class="action-cluster tgroup" role="group" aria-label="Estado do bloco">
          <button class="icon-btn ticon" data-act="ignore" aria-pressed="${box.ignored}" title="Ignorar bloco na compilação" aria-label="Ignorar bloco na compilação"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-ban"/></svg></button>
          <button class="icon-btn ticon" data-act="collapse" aria-pressed="${box.collapsed}" title="Recolher bloco" aria-label="Recolher bloco"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-minus"/></svg></button>
        </div>
        <div class="action-cluster tgroup action-cluster-danger" role="group" aria-label="Gestão do bloco">
          <button class="icon-btn ticon" data-act="dup" title="Duplicar bloco" aria-label="Duplicar bloco"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-copy"/></svg></button>
          <button class="icon-btn ticon ticon-danger btn-danger-action" data-act="del" title="Excluir bloco (2 cliques para confirmar)" aria-label="Excluir bloco, dois cliques para confirmar"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-trash"/></svg></button>
        </div>
    </div>
    <div class="box-body${box.collapsed ? ' hidden' : ''}">
      <div class="search-row hidden">
        <input class="text-input sm search-input" placeholder="Localizar…" aria-label="Localizar no bloco">
        <span class="search-count" aria-live="polite"></span>
        <button class="icon-btn search-prev" title="Anterior"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-up"/></svg></button>
        <button class="icon-btn search-next" title="Próximo (Enter)"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-down"/></svg></button>
        <input class="text-input sm replace-input" placeholder="Substituir por…" aria-label="Substituir por">
        <button class="btn btn-secondary sm replace-one">Substituir</button>
        <button class="btn btn-secondary sm replace-all">Todas</button>
      </div>
      <div class="box-editor-shell">
        <textarea class="box-md" spellcheck="false" placeholder="Escreva em Markdown…" aria-label="Markdown do bloco ${idx + 1}"></textarea>
        <div class="rich-container hidden" aria-label="Editor rich text do bloco ${idx + 1}"></div>
      </div>
      <div class="kb-toolbar" role="toolbar" aria-label="Formatação rápida">
        <div class="tgroup" role="group" aria-label="Marcas inline">
          <button type="button" class="ticon" data-kb="bold" title="Negrito" aria-label="Negrito"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-bold"/></svg></button>
          <button type="button" class="ticon" data-kb="italic" title="Itálico" aria-label="Itálico"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-italic"/></svg></button>
        </div>
        <div class="tgroup" role="group" aria-label="Blocos">
          <button type="button" class="ticon" data-kb="ul" title="Lista" aria-label="Lista"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-ul"/></svg></button>
          <button type="button" class="ticon" data-kb="h2" title="Título" aria-label="Título"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-h1"/></svg></button>
          <button type="button" class="ticon" data-kb="quote" title="Citação" aria-label="Citação"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-quote"/></svg></button>
        </div>
        <div class="tgroup" role="group" aria-label="Inserção">
          <button type="button" class="ticon" data-kb="image" title="Imagem" aria-label="Imagem"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-image"/></svg></button>
          <button type="button" class="ticon" data-kb="tbl" title="Tabela" aria-label="Tabela"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-table"/></svg></button>
          <button type="button" class="ticon" data-kb="link" title="Link" aria-label="Link"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-link"/></svg></button>
        </div>
      </div>
      <div class="box-footer block-footer">
        <div class="mode-switcher seg seg-mini" role="group" aria-label="Modo de edição">
          <button type="button" data-mode="markdown" class="${box.mode === 'markdown' ? 'active' : ''}">Markdown</button>
          <button type="button" data-mode="rich" class="${box.mode === 'rich' ? 'active' : ''}">Rich Text</button>
        </div>
        <span class="char-count">0 caracteres</span>
      </div>
      <div class="box-config">
        <button type="button" class="config-toggle" data-config-toggle aria-expanded="${box.configOpen ? 'true' : 'false'}"><span class="config-toggle-label">Opções do bloco</span><span class="config-toggle-kind">${box.kind === 'table' ? 'Tabela' : 'Texto'}</span><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-down"/></svg></button>
        <div class="config-body${box.configOpen ? '' : ' hidden'}"><div class="config-body-inner">
        <div class="config-field config-field--wide"><span>Tipo de bloco</span>
          <div class="segmented segmented-sm" role="radiogroup" aria-label="Tipo de bloco">
            <label class="segment"><input type="radio" name="kind-${box.id}" value="text" data-kind-radio ${box.kind !== 'table' ? 'checked' : ''}><span>Texto</span></label>
            <label class="segment"><input type="radio" name="kind-${box.id}" value="table" data-kind-radio ${box.kind === 'table' ? 'checked' : ''}><span>Tabela</span></label>
          </div>
        </div>
        <div class="config-field config-field--wide" data-view-flags${box.mode === 'rich' ? '' : ' hidden'}><span>Visualização</span>
          <div class="inline-checks">
            <label class="ce-toggle" title="Mostrar prévia estilizada acima da caixa de texto"><input type="checkbox" data-preview-toggle${box.preview ? ' checked' : ''}> Prévia</label>
            <label class="ce-toggle" title="Phase 3 gated: edição direta no texto estilizado"><input type="checkbox" data-ce-toggle${box.ce ? ' checked' : ''}> Direta</label>
          </div>
          <p class="view-flags-hint${box.ce && box.preview ? '' : ' hidden'}">Direta ativa: o texto editável substitui a prévia somente-leitura.</p>
        </div>
        <div class="config-field config-field--wide"><span>Masthead</span>
          <div class="masthead-toggles">
            <label class="ce-toggle"><input type="checkbox" data-cfg="masthead.enabled" ${box.masthead.enabled ? 'checked' : ''}> Ativar</label>
            <label class="ce-toggle"><input type="checkbox" data-cfg="masthead.header" ${box.masthead.header ? 'checked' : ''}> Mover cabeçalho para o masthead</label>
          </div>
          <div class="masthead-grid">
            <input class="text-input sm" data-cfg="masthead.prefix" placeholder="Prefixo / Identificador (Ex: P1)" aria-label="Prefixo do masthead" value="${escapeHtml(box.masthead.prefix)}">
            <input class="text-input sm" data-cfg="masthead.course" placeholder="Curso" aria-label="Curso do masthead" value="${escapeHtml(box.masthead.course)}">
            <input class="text-input sm" data-cfg="masthead.topic" placeholder="Tópico" aria-label="Tópico do masthead" value="${escapeHtml(box.masthead.topic)}">
          </div>
        </div>
        <div class="config-field"><span>Processamento</span>
          <div class="inline-checks">
            <label class="ce-toggle"><input type="checkbox" data-cfg="flags.autofix" ${box.flags.autofix ? 'checked' : ''}> autofix</label>
            <label class="ce-toggle"><input type="checkbox" data-cfg="flags.split_equations" ${box.flags.split_equations ? 'checked' : ''}> equações</label>
          </div>
        </div>
        ${box.kind === 'table' ? `<div class="config-field" data-table-override>
          <span>Tabela (override)</span>
          <select class="text-input sm" data-cfg="tableLayout">
            <option value="" ${!box.tableLayout ? 'selected' : ''}>Herdar global</option>
            <option value="compact" ${box.tableLayout === 'compact' ? 'selected' : ''}>Compacta</option>
            <option value="panoramic" ${box.tableLayout === 'panoramic' ? 'selected' : ''}>Panorâmica</option>
            <option value="auto" ${box.tableLayout === 'auto' ? 'selected' : ''}>Auto</option>
            <option value="rotated" ${(box.tableLayout === 'rotated' || box.tableLayout === 'rotated_cw' || box.tableLayout === 'rotated_ccw' || box.tableLayout === 'rotated_d1' || box.tableLayout === 'rotated_d2') ? 'selected' : ''}>Girada</option>
          </select>
          <div class="card-table-rot-container mt-2xs ${(box.tableLayout === 'rotated' || box.tableLayout === 'rotated_cw' || box.tableLayout === 'rotated_ccw' || box.tableLayout === 'rotated_d1' || box.tableLayout === 'rotated_d2') ? '' : 'hidden'}">
            <select class="text-input sm card-rot-select" data-rot-select="${box.id}" aria-label="Sentido de rotação da tabela">
              <option value="cw" ${(box.tableLayout === 'rotated_ccw' || box.tableLayout === 'rotated_d2' || box.tableRotationDirection === 'ccw') ? '' : 'selected'}>90° Horário (CW)</option>
              <option value="ccw" ${(box.tableLayout === 'rotated_ccw' || box.tableLayout === 'rotated_d2' || box.tableRotationDirection === 'ccw') ? 'selected' : ''}>90° Anti-horário (CCW)</option>
            </select>
          </div>
        </div>` : ''}
        <label class="config-field"><span>Colunas (override)</span>
          <select class="text-input sm" data-cfg="columns">
            <option value="" ${!box.columns ? 'selected' : ''}>Herdar global</option>
            <option value="1" ${String(box.columns) === '1' ? 'selected' : ''}>1 coluna</option>
            <option value="2" ${String(box.columns) === '2' ? 'selected' : ''}>2 colunas</option>
          </select>
        </label>
        </div></div>
      </div>
    </div>`;
  return el;
}

function escapeHtml(s) { return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

async function mountCardEditors(card, box) {
  const ta = $('.box-md', card);
  const richRoot = $('.rich-container', card);
  // Dispose previous adapter for this box id (re-render safe).
  // Synchronous on purpose: destroy() applies all DOM effects synchronously,
  // and awaiting here would suspend this card's re-mount into a microtask —
  // letting a nested renderBoxes() purge run BEFORE this card recreates its
  // portal toolbar (orphaned bars after every structural render). Do NOT
  // reintroduce await without re-proving portal ordering (see repro counts).
  const prev = adapters.get(box.id);
  if (prev) {
    try {
      const r = prev.destroy?.();
      if (r && typeof r.catch === 'function') r.catch(() => {});
    } catch { /* ignore */ }
    adapters.delete(box.id);
  }

  ta.value = box.markdown || '';
  const autosize = () => {
    try {
      ta.style.height = 'auto';
      const max = Math.round((window.innerHeight || 800) * 0.42);
      ta.style.height = `${Math.min(ta.scrollHeight, max)}px`;
    } catch { /* fixed rows fallback */ }
  };
  const taAdapter = new TextareaAdapter(ta);
  // Rich cards edit canonical markdown in place (editor-core.js): pasted /
  // dropped image files route through the same upload pipeline as the modal.
  // View flags default off: standard text box only. Preview adds the styled
  // readout; Direta swaps to the gated contentEditable surface.
  const richAdapter = new BlockEditor(richRoot, async (file) => {
    // Rich paste/drop has no modal catch: surface uploader failures here so
    // HEIC guidance (and 422s) reach the user instead of dying silently.
    try { return await ExportService.uploadImage(file); }
    catch (e) { showError(errText(e, 'Falha ao enviar imagem')); return null; }
  }, {
    normalize: normalizeForEditor, ce: box.ce === true, preview: box.preview === true,
    onSplit: (bi, headerLine, beforeMd, afterMd) => {
      flushSingleToStore(box.id);
      const plain = String(headerLine || '').replace(/^#{1,6}\s+/, '').trim();
      const tail = [headerLine || '', afterMd || ''].filter((x) => (x || '').trim()).join('\n\n');
      const seeded = store.splitBoxAtHeader(box.id, plain, beforeMd || '', tail);
      if (seeded) { newCardId = seeded.id; }
      return !!seeded;
    },
  });

  const applyMode = async (mode, { focus = false } = {}) => {
    try { hidePortalToolbars(); closePortalMenus(); } catch { /* cosmetic */ }
    flushSingleToStore(box.id);
    box.mode = mode;
    store.save();
    const isRich = mode === 'rich';
    // Crossfade: fade shell out, swap surfaces mid-fade, fade back in.
    // rAF-gated so the opacity transition actually runs; reduced-motion
    // users get the instant swap via the CSS media query.
    const shell = $('.box-editor-shell', card);
    const reduceMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    if (shell && !reduceMotion) {
      shell.classList.add('mode-fade');
      await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    }
    ta.classList.toggle('hidden', isRich);
    richRoot.classList.toggle('hidden', !isRich);
    $('.md-insert-wrap', card)?.classList.toggle('hidden', isRich);
    $$('.mode-switcher button', card).forEach((b) => b.classList.toggle('active', b.dataset.mode === mode));
    // Opções stays exactly as the user left it across mode switches:
    // configOpen persists per box and neither entry path touches it.
    // (The Visualização row inside gates itself on mode via syncViewFlagUI.)
    if (isRich) {
      // Normalize once on entry (idempotent); cards then own their inputs —
      // no remount, no reserialization, no content loss on toggle.
      // bindIO here: mount() only runs on first render, so a Markdown→Rich
      // switch would otherwise leave the format toolbar/gutter unbound.
      try { richAdapter.bindIO?.(); } catch { /* idempotent guard */ }
      const norm = normalizeForEditor(box.markdown || '');
      if (norm !== (box.markdown || '')) { box.markdown = norm; store.save(); }
      await richAdapter.setContent(box.markdown || '');
      adapters.set(box.id, richAdapter);
      try { richRoot.scrollTop = 0; } catch { /* elasticity reset is best effort */ }
    } else {
      ta.value = box.markdown || '';
      adapters.set(box.id, taAdapter);
      autosize();
    }
    updateCharCount(card, box.id);
    syncUndoButtons(card, box);
    const vf = $('[data-view-flags]', card);
    if (vf) vf.classList.toggle('hidden', mode !== 'rich');
    syncViewFlagUI(card, box);
    if (shell) {
      await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
      shell.classList.remove('mode-fade');
    }
    if (focus) (isRich ? richRoot : ta).focus?.();
  };

  adapters.set(box.id, box.mode === 'rich' ? richAdapter : taAdapter);
  syncUndoButtons(card, box);
  // Markdown chrome binds BEFORE the visibility block below: the insert bar
  // is created here, so the rich-mode hide step actually finds it. (Binding
  // after hiding left a stuck visible "Inserir:" bar on every fresh rich
  // mount — reload, add/dup/move re-render.)
  // Markdown mode: selection formatting toolbar + quick-insert bar +
  // slash-command menu + heading-cycle keybindings (Rich parity).
  bindMarkdownSelectionToolbar(card, ta, box);
  bindMarkdownInsertBar(card, ta, box, richAdapter);
  bindMarkdownSlashAndCycle(card, ta, box);
  if (box.mode === 'rich') {
    ta.classList.add('hidden'); richRoot.classList.remove('hidden');
    $('.md-insert-wrap', card)?.classList.add('hidden');
    richAdapter.mount(box.markdown || '').catch((e) => console.warn('Rich mount falhou:', e?.message || e));
  }

  ta.addEventListener('input', () => { box.markdown = ta.value; updateCharCount(card, box.id); syncUndoButtons(card, box); schedulePersist(); autosize(); });
  autosize();
  ta.addEventListener('paste', (e) => {
    try {
      const dt = e.clipboardData;
      if (!dt || Array.from(dt.files || []).length > 0) return;
      let raw = dt.getData('text/plain');
      if ((!raw || !raw.trim()) && dt.types.includes('text/html')) {
        const tmp = document.createElement('div');
        tmp.innerHTML = dt.getData('text/html');
        raw = tmp.textContent || '';
      }
      if (!raw) return;
      // V5 parity with Rich: bare URL over selection becomes [text](url).
      try {
        const res = pasteUrlLink(ta.value, ta.selectionStart, ta.selectionEnd, raw);
        if (res) {
          e.preventDefault();
          ta.value = res.text;
          ta.setSelectionRange(res.caretStart, res.caretEnd);
          ta.dispatchEvent(new Event('input', { bubbles: true }));
          return;
        }
      } catch { /* fall through */ }
      const norm = normalizeForEditor(String(raw).replace(/^\s*\n+|\s*\n+\s*$/g, ''));
      if (norm === raw) return;
      e.preventDefault();
      document.execCommand('insertText', false, norm);
    } catch { /* native paste */ }
  });
  richRoot.addEventListener('block-change', () => { box.markdown = richAdapter.getContent(); updateCharCount(card, box.id); syncUndoButtons(card, box); schedulePersist(); });
  richRoot.addEventListener('edit-figure', (e) => {
    const { blockIndex, figure } = e.detail || {};
    openImageModal(box.id, figure, blockIndex);
  });
  richRoot.addEventListener('insert-figure-at', (e) => {
    imageInsertIndex = e?.detail?.insertIndex ?? null;
    openImageModal(box.id, null, null);
  });

  bindKbBar(card, ta, box, richAdapter);
  $$('.mode-switcher button', card).forEach((b) => b.addEventListener('click', () => applyMode(b.dataset.mode)));
  // Delegated view-flag handlers: survive .box-config innerHTML rebuilds
  // (kind-switch path) that would orphan one-shot listeners. Bound once
  // per card; reads the live checkbox, writes through the store + adapter.
  if (!card._viewFlagsBound) {
    card._viewFlagsBound = true;
    card.addEventListener('change', (ev) => {
      const pv = ev.target.closest?.('[data-preview-toggle]');
      if (pv && card.contains(pv)) {
        flushSingleToStore(box.id);
        box.preview = pv.checked === true;
        store.save();
        richAdapter.setPreviewEnabled(box.preview);
        if (box.mode === 'rich') { box.markdown = richAdapter.getContent(); store.save(); updateCharCount(card, box.id); }
        syncViewFlagUI(card, box);
        return;
      }
      const ce = ev.target.closest?.('[data-ce-toggle]');
      if (ce && card.contains(ce)) {
        flushSingleToStore(box.id);
        box.ce = ce.checked === true;
        store.save();
        richAdapter.setCEEnabled(box.ce);
        if (box.mode === 'rich') { box.markdown = richAdapter.getContent(); store.save(); updateCharCount(card, box.id); }
        syncViewFlagUI(card, box);
      }
    });
  }
  syncViewFlagUI(card, box);
  card._applyMode = applyMode;
}

/* Re-sync Prévia/Direta checkboxes + hint from store truth. Call after
 * every mount, mode switch, and toggle so the UI can never show stale
 * flags while the Rich surface renders the real ones. */
function syncViewFlagUI(card, box) {
  const wrap = $('[data-view-flags]', card);
  if (wrap) wrap.classList.toggle('hidden', box.mode !== 'rich');
  const pv = $('[data-preview-toggle]', card);
  if (pv) pv.checked = box.preview === true;
  const ce = $('[data-ce-toggle]', card);
  if (ce) ce.checked = box.ce === true;
  const hint = $('.view-flags-hint', card);
  if (hint) hint.classList.toggle('hidden', !(box.ce === true && box.preview === true));
}

/* Markdown-mode contextual toolbar: floats above the textarea when text is
 * selected; applies canonical markdown wrappers at the selection. */
function bindMarkdownSelectionToolbar(card, ta, box) {
  if (!card || !ta || card._mdToolbarBound) return;
  card._mdToolbarBound = true;
  // L1: toolbar renders in the shared body portal (#ui-portal) using
  // viewport coordinates (fixed layer — never add scrollX/scrollY to
  // getBoundingClientRect values) — never clipped by .box-editor-shell.
  // L2: full control set H1/H2/H3 + quote alongside inline wrappers.
  // NOTE: portal stays aria-hidden=false (see uiPortal in editor-core.js) —
  // hiding it would remove this toolbar from screen readers.
  const portal = uiPortal();
  const bar = document.createElement('div');
  bar.className = 'md-float-toolbar hidden';
  bar.setAttribute('role', 'toolbar');
  bar.setAttribute('aria-label', 'Formatação Markdown');
  bar.innerHTML = `
    <button type="button" class="ticon" data-md="bold" title="Negrito" aria-label="Negrito"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-bold"/></svg></button>
    <button type="button" class="ticon" data-md="italic" title="Itálico" aria-label="Itálico"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-italic"/></svg></button>
    <button type="button" class="ticon" data-md="code" title="Código" aria-label="Código"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-code"/></svg></button>
    <button type="button" class="ticon" data-md="link" title="Link" aria-label="Link"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-link"/></svg></button>`;
  portal.appendChild(bar);
  card._mdToolbarEl = bar;
  const sync = () => {
    const s = ta.selectionStart, e = ta.selectionEnd;
    if (typeof s === 'number' && typeof e === 'number' && e > s && !ta.classList.contains('hidden')) {
      try { hidePortalToolbars(bar); } catch { /* cosmetic */ }
      const r = ta.getBoundingClientRect();
      const tw = 360;
      bar.style.top = `${Math.max(8, r.top - 44)}px`;
      bar.style.left = `${Math.max(8, Math.min(r.left + 12, document.documentElement.clientWidth - tw - 8))}px`;
      const isMobile = window.matchMedia?.('(max-width: 860px)').matches;
      bar.classList.toggle('m-bubble', !!isMobile);
      bar.classList.remove('hidden');
    } else {
      bar.classList.add('hidden');
    }
  };
  ta.addEventListener('mouseup', () => setTimeout(sync, 20));
  ta.addEventListener('keyup', sync);
  ta.addEventListener('blur', () => setTimeout(() => bar.classList.add('hidden'), 150));
  const toggleSel = (fmt, placeholder = '') => {
    try { adapters.get(box.id)?.checkpoint?.(); } catch { /* best effort */ }
    try {
      const v = ta.value, s = ta.selectionStart ?? v.length, e = ta.selectionEnd ?? v.length;
      if (s === e && !v.slice(s, e)) {
        const m = fmt === 'bold' ? ['**', '**'] : fmt === 'italic' ? ['*', '*'] : fmt === 'code' ? ['`', '`'] : fmt === 'strike' ? ['~~', '~~'] : null;
        if (!m) return;
        const sel = placeholder;
        ta.value = `${v.slice(0, s)}${m[0]}${sel}${m[1]}${v.slice(e)}`;
        ta.setSelectionRange(s + m[0].length, s + m[0].length + sel.length);
      } else {
        const res = applyRichCommand(v, s, e, fmt);
        ta.value = res.text;
        ta.setSelectionRange(res.caretStart, res.caretEnd);
      }
    } catch {
      const s = ta.selectionStart, e = ta.selectionEnd, v = ta.value;
      const before = fmt === 'bold' ? '**' : fmt === 'italic' ? '*' : fmt === 'code' ? '`' : fmt === 'strike' ? '~~' : null;
      if (!before) return;
      const after = before;
      const sel = v.slice(s, e);
      const guarded = sel.length >= before.length + after.length && sel.startsWith(before) && sel.endsWith(after)
        && !(before === '*' && (sel.startsWith('**') || sel.endsWith('**')));
      if (guarded) {
        const inner = sel.slice(before.length, sel.length - after.length);
        ta.value = v.slice(0, s) + inner + v.slice(e);
        ta.setSelectionRange(s, s + inner.length);
      } else if (v.slice(s - before.length, s) === before && v.slice(e, e + after.length) === after) {
        ta.value = v.slice(0, s - before.length) + sel + v.slice(e + after.length);
        ta.setSelectionRange(s - before.length, s - before.length + sel.length);
      } else {
        ta.value = `${v.slice(0, s)}${before}${sel}${after}${v.slice(e)}`;
        ta.setSelectionRange(s + before.length, s + before.length + sel.length);
      }
    }
    ta.focus();
    ta.dispatchEvent(new Event('input', { bubbles: true }));
  };
  const wrapSel = (before, after = before, placeholder = '') => {
    try { adapters.get(box.id)?.checkpoint?.(); } catch { /* best effort */ }
    try {
      const v = ta.value, s = ta.selectionStart ?? v.length, e = ta.selectionEnd ?? v.length;
      const sel = v.slice(s, e) || placeholder;
      if ((before === '[') && sel) {
        const linkM = sel.match(/^\[(.+)\]\((.+)\)$/);
        if (linkM) {
          ta.value = v.slice(0, s) + linkM[1] + v.slice(e);
          ta.setSelectionRange(s, s + linkM[1].length);
          ta.focus();
          ta.dispatchEvent(new Event('input', { bubbles: true }));
          return;
        }
        // Link polish: select the URL placeholder so typing replaces it.
        ta.value = v.slice(0, s) + before + sel + after + v.slice(e);
        const urlStart = s + before.length + sel.length + 1;
        ta.setSelectionRange(urlStart, urlStart + 8);
        ta.focus();
        ta.dispatchEvent(new Event('input', { bubbles: true }));
        return;
      }
      ta.value = v.slice(0, s) + before + sel + after + v.slice(e);
      ta.setSelectionRange(s + before.length, s + before.length + sel.length);
    } catch {
      const s = ta.selectionStart, e = ta.selectionEnd, v = ta.value;
      const sel = v.slice(s, e) || placeholder;
      ta.value = v.slice(0, s) + before + sel + after + v.slice(e);
      ta.setSelectionRange(s + before.length, s + before.length + sel.length);
    }
    ta.focus();
    ta.dispatchEvent(new Event('input', { bubbles: true }));
  };
  const linePrefix = (kind) => {
    try { adapters.get(box.id)?.checkpoint?.(); } catch { /* best effort */ }
    try {
      const res = applyRichCommand(ta.value, ta.selectionStart, ta.selectionEnd, kind);
      ta.value = res.text;
      ta.setSelectionRange(res.caretStart, res.caretEnd);
    } catch {
      const s = ta.selectionStart, e = ta.selectionEnd, v = ta.value;
      const ls = v.lastIndexOf('\n', s - 1) + 1;
      const hashes = kind === 'h1' ? '# ' : kind === 'h2' ? '## ' : kind === 'h3' ? '### ' : kind === 'h4' ? '#### ' : null;
      if (hashes || kind === 'quote') {
        const cur = v.slice(ls).match(/^(#{1,6}\s+|>+\s*)/);
        const rep = hashes || '> ';
        if (cur) {
          ta.value = v.slice(0, ls) + rep + v.slice(ls + cur[0].length);
          const d = rep.length - cur[0].length;
          ta.setSelectionRange(s + d, e + d);
        } else {
          ta.value = v.slice(0, ls) + rep + v.slice(ls);
          ta.setSelectionRange(s + rep.length, e + rep.length);
        }
      } else {
        const prefix = kind === 'ul' ? '- ' : kind;
        ta.value = v.slice(0, ls) + prefix + v.slice(ls);
        ta.setSelectionRange(s + prefix.length, e + prefix.length);
      }
    }
    ta.focus();
    ta.dispatchEvent(new Event('input', { bubbles: true }));
  };
  bar.querySelectorAll('[data-md]').forEach((b) => b.addEventListener('mousedown', (e) => {
    e.preventDefault();
    const k = b.dataset.md;
    if (k === 'bold') toggleSel('bold', 'negrito');
    else if (k === 'italic') toggleSel('italic', 'itálico');
    else if (k === 'code') toggleSel('code', 'código');
    else if (k === 'link') wrapSel('[', '](https://)', 'texto');
    bar.classList.add('hidden');
  }));
}

/* Markdown-mode insert: a single "+" opening the shared portal menu
 * (BlockEditor.openPortalMenu + INSERT_ITEMS) — one idiom, one catalog
 * across Markdown and Rich. Picking inserts the snippet at the caret;
 * Markdown stays truth (atCursor) vs Rich handleInsertAt. */
function bindMarkdownInsertBar(card, ta, box, richAdapter) {
  if (!card || !ta || card._mdInsertBound) return;
  card._mdInsertBound = true;
  const shell = $('.box-editor-shell', card);
  if (!shell) return;
  const wrap = document.createElement('div');
  wrap.className = 'md-insert-wrap';
  wrap.innerHTML = `<button type="button" class="bedit-plus-btn" title="Inserir elemento" aria-label="Inserir elemento" aria-haspopup="menu"><svg class="ic" aria-hidden="true"><use href="./icons.svg#i-plus"/></svg></button><span class="md-insert-label">Inserir</span>`;
  shell.insertBefore(wrap, shell.firstChild);
  const atCursor = (snippet) => {
    const s = ta.selectionStart ?? ta.value.length, e = ta.selectionEnd ?? s, v = ta.value;
    const before = v.slice(0, s), after = v.slice(e);
    const needsNl = before && !before.endsWith('\n') ? '\n' : '';
    const tailNl = after && !after.startsWith('\n') ? '\n' : '';
    ta.value = `${before}${needsNl}\n${snippet}\n${tailNl}${after}`;
    const pos = (before + needsNl + '\n' + snippet + '\n').length;
    ta.setSelectionRange(pos, pos);
    ta.focus();
    ta.dispatchEvent(new Event('input', { bubbles: true }));
  };
  const btn = $('.bedit-plus-btn', wrap);
  btn?.addEventListener('click', (e) => {
    e.stopPropagation();
    // openPortalMenu is stateless (portal + document only); the Rich adapter
    // is just its carrier so both modes share one menu component.
    const menuHost = richAdapter && typeof richAdapter.openPortalMenu === 'function' ? richAdapter : null;
    if (!menuHost) return;
    menuHost.openPortalMenu(btn, INSERT_ITEMS, (k) => {
      if (k === 'fig') { openImageModal(box.id, null, null); return; }
      try { adapters.get(box.id)?.checkpoint?.(); } catch { /* best effort */ }
      const snippet = insertSnippetFor(k);
      if (snippet) atCursor(snippet);
    });
  });
}

/* Mobile keyboard-docked bar: compact frequent actions above the virtual
 * keyboard (mockup dual-layer, second layer). Visible only on <=860px while
 * the card owns focus. Routes through the same seams as every other surface:
 * applyRichCommand for markdown, BlockEditor.execCommand/handleInsertAt for
 * rich, openImageModal for figures. */
function bindKbBar(card, ta, box, richAdapter) {
  if (!card || card._kbBound) return;
  card._kbBound = true;
  const bar = $('.kb-toolbar', card);
  if (!bar) return;
  const mq = window.matchMedia?.('(max-width: 860px)');
  const syncDock = () => {
    const on = !!mq?.matches && !!card.contains(document.activeElement);
    bar.classList.toggle('is-docked', on);
  };
  card.addEventListener('focusin', syncDock);
  card.addEventListener('focusout', () => setTimeout(syncDock, 60));
  mq?.addEventListener?.('change', syncDock);
  const mdAtCursor = (snippet) => {
    const s = ta.selectionStart ?? ta.value.length, e = ta.selectionEnd ?? s, v = ta.value;
    const before = v.slice(0, s), after = v.slice(e);
    const needsNl = before && !before.endsWith('\n') ? '\n' : '';
    const tailNl = after && !after.startsWith('\n') ? '\n' : '';
    ta.value = `${before}${needsNl}\n${snippet}\n${tailNl}${after}`;
    const pos = (before + needsNl + '\n' + snippet + '\n').length;
    ta.setSelectionRange(pos, pos);
    ta.focus();
    ta.dispatchEvent(new Event('input', { bubbles: true }));
  };
  bar.querySelectorAll('[data-kb]').forEach((b) => b.addEventListener('mousedown', (e) => {
    e.preventDefault();
    const k = b.dataset.kb;
    const isRich = box.mode === 'rich';
    if (k === 'image') { flushSingleToStore(box.id); openImageModal(box.id, null, null); return; }
    if (k === 'tbl') {
      if (isRich) { try { richAdapter.handleInsertAt(richAdapter.store.blocks.length, 'tbl'); } catch { /* best effort */ } }
      else { try { adapters.get(box.id)?.checkpoint?.(); } catch { /* best effort */ } mdAtCursor(insertSnippetFor('tbl')); }
      return;
    }
    if (isRich) {
      try { richAdapter.execCommand(k === 'h2' ? 'h2' : k); } catch { /* best effort */ }
    } else {
      try { adapters.get(box.id)?.checkpoint?.(); } catch { /* best effort */ }
      try {
        const res = applyRichCommand(ta.value, ta.selectionStart ?? 0, ta.selectionEnd ?? 0, k === 'h2' ? 'h2' : k);
        ta.value = res.text;
        ta.setSelectionRange(res.caretStart, res.caretEnd);
        ta.focus();
        ta.dispatchEvent(new Event('input', { bubbles: true }));
      } catch { /* formatting is best effort */ }
    }
  }));
}

function markdownListEnter(ta, e, box) {
  try {
    const v = ta.value, s = ta.selectionStart, ex = ta.selectionEnd;
    if (s !== ex) return false;
    const ls = v.lastIndexOf('\n', s - 1) + 1;
    const le = v.indexOf('\n', s);
    const lineEnd = le < 0 ? v.length : le;
    const m = v.slice(ls, s).match(/^(\s*)(-|\*|\+|\d+[.)])(\s+)(.*)$/);
    if (!m || /\S/.test(v.slice(s, lineEnd))) return false;
    e.preventDefault();
    if (!m[4].trim()) {
      ta.value = v.slice(0, ls) + v.slice(lineEnd + (le < 0 ? 0 : 1));
      ta.setSelectionRange(ls, ls);
    } else {
      let mark = m[2];
      const nm = mark.match(/^(\d+)([.)])$/);
      if (nm) mark = `${Number(nm[1]) + 1}${nm[2]}`;
      const ins = `\n${m[1]}${mark} `;
      ta.value = v.slice(0, s) + ins + v.slice(s);
      ta.setSelectionRange(s + ins.length, s + ins.length);
    }
    ta.dispatchEvent(new Event('input', { bubbles: true }));
    return true;
  } catch { return false; }
}
function markdownHeaderSplit(ta, e, box) {
  try {
    const v = ta.value, s = ta.selectionStart, ex = ta.selectionEnd;
    if (s !== ex) return false;
    const ls = v.lastIndexOf('\n', s - 1) + 1;
    const le = v.indexOf('\n', s);
    const lineEnd = le < 0 ? v.length : le;
    if (s !== lineEnd) return false;
    const hm = v.slice(ls, lineEnd).match(/^(#{1,6})\s+(\S.*)$/);
    if (!hm) return false;
    e.preventDefault();
    box.markdown = v;
    const local = v.split('\n');
    const headerAt = v.slice(0, ls).split('\n').length - 1;
    const before = local.slice(0, headerAt).join('\n');
    const rest = local.slice(headerAt + 1).join('\n');
    const after = [`${hm[1]} ${hm[2].trim()}`, rest].filter((x) => (x || '').trim()).join('\n\n');
    const seeded = store.splitBoxAtHeader(box.id, hm[2].trim(), before, after);
    if (seeded) newCardId = seeded.id;
    return !!seeded;
  } catch { return false; }
}

/* Markdown-mode slash-command + heading-cycle parity with Rich cards.
 * Cmd/Ctrl+Shift+1/2/3 → H1/H2/H3, +0 → paragraph; "/" at a blank line
 * start opens the shared portal menu (line transform when the line has
 * content, snippet insert after the line when blank). */
function bindMarkdownSlashAndCycle(card, ta, box) {
  if (!card || !ta || card._mdSlashBound) return;
  card._mdSlashBound = true;
  const cycleLine = (hashes) => {
    try { adapters.get(box.id)?.checkpoint?.(); } catch { /* best effort */ }
    const v = ta.value, s = ta.selectionStart, e = ta.selectionEnd;
    const ls = v.lastIndexOf('\n', s - 1) + 1;
    const cur = v.slice(ls).match(/^(#{1,6}\s+|>+\s*)/);
    if (cur) {
      ta.value = v.slice(0, ls) + hashes + v.slice(ls + cur[0].length);
      const d = hashes.length - cur[0].length;
      ta.setSelectionRange(s + d, e + d);
    } else {
      ta.value = v.slice(0, ls) + hashes + v.slice(ls);
      ta.setSelectionRange(s + hashes.length, e + hashes.length);
    }
    ta.dispatchEvent(new Event('input', { bubbles: true }));
  };
  const listShortcut = (kind) => {
    try { adapters.get(box.id)?.checkpoint?.(); } catch { /* best effort */ }
    try {
      const res = applyRichCommand(ta.value, ta.selectionStart, ta.selectionEnd, kind);
      if (res.text !== ta.value) {
        ta.value = res.text;
        ta.setSelectionRange(res.caretStart, res.caretEnd);
        ta.dispatchEvent(new Event('input', { bubbles: true }));
      }
    } catch { /* formatting is best effort */ }
  };
  ta.addEventListener('keydown', (e) => {
    const mod = e.metaKey || e.ctrlKey;
    if (mod && !e.altKey && !e.shiftKey && (e.key === 'z' || e.key === 'Z')) {
      const ad = adapters.get(box.id);
      if (ad && ad.constructor?.name === 'TextareaAdapter' && !ta.classList.contains('hidden')) {
        e.preventDefault();
        ad.undo();
        return;
      }
    }
    if (mod && !e.altKey && ((e.key === 'Z' && e.shiftKey) || (e.key === 'y' && !e.shiftKey))) {
      const ad = adapters.get(box.id);
      if (ad && ad.constructor?.name === 'TextareaAdapter' && !ta.classList.contains('hidden')) {
        e.preventDefault();
        ad.redo();
        return;
      }
    }
    if (e.key === 'Enter' && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey && !e.isComposing) {
      if (markdownListEnter(ta, e, box)) return;
      if (markdownHeaderSplit(ta, e, box)) return;
    }
    if (mod && e.shiftKey && ['1', '2', '3', '4', '0', '7', '8'].includes(digitOf(e))) {
      e.preventDefault();
      const d = digitOf(e);
      if (d === '7' || d === '8') listShortcut(d === '7' ? 'ol' : 'ul');
      else cycleLine(d === '0' ? '' : '#'.repeat(Number(d)) + ' ');
      return;
    }
    if (e.key === '/' && ta.selectionStart === ta.selectionEnd) {
      const v = ta.value, s = ta.selectionStart;
      const ls = v.lastIndexOf('\n', s - 1) + 1;
      if (!/^\s*$/.test(v.slice(ls, s)) || ta.classList.contains('hidden')) return;
      e.preventDefault();
      openMarkdownSlashMenu(ta, box);
    }
  });
}

/* Portal slash menu for the Markdown textarea: transform mode when the
 * current line has content, insert-after mode when blank. */
function openMarkdownSlashMenu(ta, box) {
  const portal = uiPortal();
  if (!portal) return;
  // Shelf-only rendering (portal-wipe fix): clearing #ui-portal here used to
  // destroy the Rich floating toolbar node out from under its BlockEditor,
  // permanently hiding it until a full re-render. Menus own just the shelf.
  const shelf = menuShelf() || portal;
  const v = ta.value, s = ta.selectionStart;
  const ls = v.lastIndexOf('\n', s - 1) + 1;
  const hasContent = v.slice(ls, s).trim().length > 0;
  const symOf = (key) => ({ h1: '#', h2: '##', h3: '###', h4: '####', quote: '❝', ul: '•≡', ol: '1≡', p: '¶', tbl: '⊞', fig: '🖼', code: '⟨⟩', math: '$', callout: '!', rule: '—' }[key] || '•');
  const items = hasContent
    ? [
        { key: 'h1', icon: '#', label: 'Título 1 — transformar linha', t: '# ' },
        { key: 'h2', icon: '##', label: 'Título 2 — transformar linha', t: '## ' },
        { key: 'h3', icon: '###', label: 'Título 3 — transformar linha', t: '### ' },
        { key: 'h4', icon: '####', label: 'Título 4 — transformar linha', t: '#### ' },
        { key: 'quote', icon: '❝', label: 'Citação — transformar linha', t: '> ' },
        { key: 'ul', icon: '•≡', label: 'Lista — transformar linha' },
        { key: 'ol', icon: '1≡', label: 'Numerada — transformar linha' },
        { key: 'p', icon: '¶', label: 'Texto — remover prefixo', t: '' },
      ]
    : INSERT_ITEMS.map((it) => ({ key: it.key, icon: symOf(it.key), label: it.label, s: it.md ?? undefined }));
  portal.setAttribute('aria-hidden', 'false');
  const wrap = document.createElement('div');
  wrap.className = 'bedit-slash-wrap portal-open';
  wrap.innerHTML = `
    <input class="text-input sm bedit-slash-filter" placeholder="/filtrar…  (Esc fecha)" aria-label="Filtrar comandos">
    <div class="bedit-quick-menu bedit-slash-menu" role="menu"></div>`;
  const menu = wrap.querySelector('.bedit-slash-menu');
  const filter = wrap.querySelector('.bedit-slash-filter');
  menu.setAttribute('role', 'listbox');
  menu.id = 'bedit-slash-list-md';
  filter.setAttribute('role', 'combobox');
  filter.setAttribute('aria-expanded', 'true');
  filter.setAttribute('aria-controls', 'bedit-slash-list-md');
  filter.setAttribute('aria-autocomplete', 'list');
  let activeIdx = 0;
  const caretPos = ta.selectionStart;
  const paintActive = () => {
    const btns = Array.from(menu.querySelectorAll('[data-ins]'));
    btns.forEach((b, k) => {
      const on = k === activeIdx;
      b.classList.toggle('is-active', on);
      b.setAttribute('aria-selected', on ? 'true' : 'false');
      if (on) filter.setAttribute('aria-activedescendant', `mdslash-${b.dataset.ins}`);
    });
    if (btns.length === 0) filter.removeAttribute('aria-activedescendant');
    else {
      try { btns[activeIdx]?.scrollIntoView?.({ block: 'nearest' }); } catch { /* cosmetic */ }
    }
  };
  shelf.innerHTML = '';
  shelf.appendChild(wrap);
  const r = ta.getBoundingClientRect();
  wrap.style.left = `${Math.max(8, Math.min(r.left, document.documentElement.clientWidth - 400))}px`;
  wrap.style.top = `${Math.max(8, r.top + 24)}px`;
  const render = (q = '') => {
    const ql = q.toLowerCase().replace(/^\//, '');
    const shown = items
      .filter((it) => !ql || it.label.toLowerCase().includes(ql) || it.key.includes(ql));
    menu.innerHTML = shown
      .map((it) => `<button type="button" role="option" id="mdslash-${it.key}" data-ins="${it.key}" aria-selected="false"><strong>${it.icon}</strong> ${it.label}</button>`)
      .join('') || '<p class="bedit-slash-empty">Nenhum comando</p>';
    activeIdx = slashNavIndex('reset', activeIdx, shown.length);
    menu.querySelectorAll('[data-ins]').forEach((btn, k) => {
      btn.addEventListener('click', (ev) => { ev.stopPropagation(); pick(btn.dataset.ins); });
      btn.addEventListener('mousemove', () => { if (activeIdx !== k) { activeIdx = k; paintActive(); } });
    });
    paintActive();
  };
  const close = (restoreCaret = false) => {
    wrap.remove();
    portal.setAttribute('aria-hidden', 'true');
    document.removeEventListener('pointerdown', onDoc, true);
    if (restoreCaret) {
      try { ta.focus(); ta.setSelectionRange(caretPos, caretPos); } catch { /* keep focus */ }
    }
  };
  const onDoc = (ev) => { if (!wrap.contains(ev.target) && ev.target !== ta) close(); };
  document.addEventListener('pointerdown', onDoc, true);
  const atCursorLine = (text) => {
    const nv = ta.value, cs = ta.selectionStart, ce = ta.selectionEnd;
    const nls = nv.lastIndexOf('\n', cs - 1) + 1;
    const nle = nv.indexOf('\n', ce);
    const end = nle < 0 ? nv.length : nle;
    ta.value = nv.slice(0, nls) + text + nv.slice(end);
    ta.setSelectionRange(nls + text.length, nls + text.length);
    ta.focus();
    ta.dispatchEvent(new Event('input', { bubbles: true }));
  };
  const afterLine = (snippet) => {
    const nv = ta.value, ce = ta.selectionEnd;
    const nle = nv.indexOf('\n', ce);
    const end = nle < 0 ? nv.length : nle;
    const tail = nv.slice(end);
    const tailNl = tail && !tail.startsWith('\n') ? '\n' : '';
    ta.value = `${nv.slice(0, end)}\n${snippet}\n${tailNl}${tail}`;
    ta.focus();
    ta.dispatchEvent(new Event('input', { bubbles: true }));
  };
  const pick = (type) => {
    const item = items.find((x) => x.key === type);
    close();
    if (!item) return;
    try { adapters.get(box.id)?.checkpoint?.(); } catch { /* best effort */ }
    if (hasContent) {
      if (type === 'ul' || type === 'ol') {
        // Lists route through the pure multi-line command (toggle aware),
        // same seam as toolbar buttons and shortcuts.
        try {
          const res = applyRichCommand(ta.value, ta.selectionStart, ta.selectionEnd, type);
          ta.value = res.text;
          ta.setSelectionRange(res.caretStart, res.caretEnd);
          ta.focus();
          ta.dispatchEvent(new Event('input', { bubbles: true }));
        } catch { /* formatting is best effort */ }
      } else {
        atCursorLine((item.t ?? '') + v.slice(ls).replace(/^(#{1,6}\s+|>+\s*)/, '').split('\n')[0]);
      }
    } else if (type === 'fig') {
      openImageModal(box.id, null, null);
    } else if (item.s !== undefined) {
      afterLine(item.s);
    }
    ta.focus();
  };
  filter.addEventListener('input', () => render(filter.value));
  filter.addEventListener('keydown', (ev) => {
    if (ev.key === 'Escape') { ev.stopPropagation(); close(true); }
    else if (ev.key === 'Enter') {
      ev.preventDefault();
      const btns = Array.from(menu.querySelectorAll('[data-ins]'));
      const target = btns[activeIdx] || btns[0];
      if (target) pick(target.dataset.ins);
    } else if (ev.key === 'ArrowDown' || ev.key === 'ArrowUp') {
      ev.preventDefault();
      const btns = Array.from(menu.querySelectorAll('[data-ins]'));
      activeIdx = slashNavIndex(ev.key, activeIdx, btns.length);
      paintActive();
    }
  });
  render('');
  filter.focus();
}

function flushSingleToStore(boxId) {
  const box = store.getBoxes().find((b) => b.id === boxId);
  const ad = adapters.get(boxId);
  if (!box || !ad) return;
  try {
    // Skip stale adapters: after a mode switch only the active editor
    // owns the text; a retired adapter's getContent would resurrect
    // pre-switch content and wipe the user's latest edits.
    const expected = box.mode === 'rich' ? 'BlockEditor' : 'TextareaAdapter';
    if (ad.constructor?.name && ad.constructor.name !== expected) return;
    box.markdown = ad.getContent();
  } catch { /* ignore */ }
}

let persistT = null;
function schedulePersist() { clearTimeout(persistT); persistT = setTimeout(() => { store.save(); scheduleTocPreview(); }, 250); }

function updateCharCount(card, boxId) {
  const box = store.getBoxes().find((b) => b.id === boxId);
  const ad = adapters.get(boxId);
  const len = (ad ? ad.getContent() : box?.markdown || '').length;
  $('.char-count', card).textContent = `${len} caracteres`;
}

/* M1: undo/redo button states follow the active adapter's stacks. Unknown or
 * stackless adapters read as nothing-to-do (both disabled), never enabled. */
function syncUndoButtons(card, box) {
  const ad = adapters.get(box?.id);
  const u = $('[data-act="undo"]', card), r = $('[data-act="redo"]', card);
  if (u) u.disabled = !(typeof ad?.canUndo === 'function' && ad.canUndo());
  if (r) r.disabled = !(typeof ad?.canRedo === 'function' && ad.canRedo());
}

let newCardId = null; // entry animation fires once, for this id only
let moveNudgeId = null; // directional nudge after moveBox re-render
function renderBoxes() {
  // Purge orphaned portal toolbars before rebuilding: adapters of deleted
  // boxes never run destroy(), so their floating bars would pile up in
  // #ui-portal with duplicate ids (portal-leak fix).
  try { purgePortalToolbars(); } catch { /* cosmetic */ }
  const list = $('#box-list');
  list.innerHTML = '';
  store.getBoxes().forEach((box, idx) => {
    const card = cardTemplate(box, idx);
    if (box.id === newCardId) card.classList.add('is-new');
    if (moveNudgeId && box.id === moveNudgeId.id) {
      card.classList.add(moveNudgeId.cls);
      requestAnimationFrame(() => card.scrollIntoView({ block: 'nearest', behavior: 'smooth' }));
    }
    list.appendChild(card);
    mountCardEditors(card, box);
    updateCharCount(card, box.id);
    bindCardActions(card, box);
  });
  newCardId = null;
  moveNudgeId = null;
  $('#doc-count').textContent = String(store.getBoxes().length);
  syncEmptyState();
  initCardDnd();
  scheduleTocPreview();
}

function syncEmptyState() {
  const empty = $('#workspace-empty');
  if (!empty) return;
  // Onboarding shows only when the store is truly empty. Ignored blocks
  // stay visible (glass-dimmed) so the user can always un-ignore them;
  // hiding the list here used to trap all blocks out of reach.
  const hasAny = store.getBoxes().length > 0;
  empty.classList.toggle('hidden', hasAny);
  if (hasAny) $('#box-list')?.classList.remove('hidden');
}

/* Inline validation banner: block index + message (ref-11 diagnostics). */
function renderValidationBanner(items = []) {
  const banner = $('#toc-validation-banner');
  if (!banner) return;
  if (!items.length) { banner.classList.add('hidden'); banner.innerHTML = ''; return; }
  banner.classList.remove('hidden');
  banner.innerHTML = `<strong>${items.length} aviso${items.length === 1 ? '' : 's'}:</strong> ` +
    items.map((m) => `<span>Bloco ${m.index}: ${escapeHtml(m.message)}</span>`).join(' · ');
}

/* Drag-and-drop reorder: native HTML5, handle-only, reuses moveBoxTo. */
let dndBound = false;
function initCardDnd() {
  const list = $('#box-list');
  if (!list) return;
  if (dndBound) return; // listeners bound once; cards re-render inside list
  dndBound = true;
  let dragId = null;
  let handleArmedId = null;
  const clearDropHints = () => {
    $$('.box-card', list).forEach((c) => c.classList.remove('drop-before', 'drop-after'));
  };
  const resetDraggable = () => {
    $$('.box-card', list).forEach((c) => c.setAttribute('draggable', 'false'));
  };
  // Restore helper: unhide only auto-hidden bodies (data-tmp-hide);
  // user-collapsed cards (toolbar Recolher) stay hidden.
  const restoreTmpCollapse = () => {
    $$('.box-body[data-tmp-hide]', list).forEach((bd) => { bd.classList.remove('hidden'); delete bd.dataset.tmpHide; });
  };
  const dndDebug = typeof location !== 'undefined' && /(?:\?|&)dnd-debug=1/.test(location.search);
  const dndLog = (...a) => { if (dndDebug) console.log('[dnd]', ...a); };
  let dndOverCount = 0;
  let hintKey = null;
  // Sprite cache: external <use href="./icons.svg#id"> refs don't rasterize
  // into the offscreen drag ghost, so ghost icons inline symbol paths.
  let dndSpriteDoc = null;
  try {
    fetch('./icons.svg').then((r) => r.text()).then((t) => {
      dndSpriteDoc = new DOMParser().parseFromString(t, 'image/svg+xml');
    }).catch(() => {});
  } catch { /* best effort */ }
  const dndInlineGhostIcons = (ghost) => {
    if (!dndSpriteDoc) return;
    ghost.querySelectorAll('svg').forEach((svg) => {
      const use = svg.querySelector('use');
      if (!use) return;
      const href = use.getAttribute('href') || use.getAttribute('xlink:href') || '';
      const id = href.split('#')[1];
      if (!id) return;
      const sym = dndSpriteDoc.getElementById(id);
      if (!sym) return;
      svg.setAttribute('viewBox', sym.getAttribute('viewBox') || '0 0 16 16');
      svg.innerHTML = sym.innerHTML;
    });
  };
  list.addEventListener('dragstart', (e) => {
    // Inner rich-editor drags bubble here: ignore anything originating
    // inside .rich-container (previously preventDefault() vetoed them).
    if (e.target.closest?.('.rich-container')) return;
    const card = e.target.closest?.('.box-card');
    if (!card || !handleArmedId || card.dataset.boxId !== handleArmedId) { e.preventDefault(); return; }
    dragId = card.dataset.boxId;
    if (dndDebug) dndLog('start', { id: dragId });
    e.dataTransfer.effectAllowed = 'move';
    try { e.dataTransfer.setData('text/plain', dragId); } catch { /* ignore */ }
    // Ghost mirrors the collapsed skeleton: clone the card shell with its
    // body hidden (same .hidden seam as Recolher), so the cursor carries
    // an identical title+toolbar chip instead of the full expanded body.
    if (e.dataTransfer?.setDragImage) {
      try {
        const rect = card.getBoundingClientRect();
        const ghost = card.cloneNode(true);
        ghost.removeAttribute('id');
        ghost.querySelectorAll('[id]').forEach((n) => n.removeAttribute('id'));
        ghost.classList.remove('is-dragging', 'drop-before', 'drop-after');
        ghost.classList.add('dnd-ghost');
        ghost.setAttribute('aria-hidden', 'true');
        ghost.querySelector('.box-body')?.remove();
        dndInlineGhostIcons(ghost);
        const ghostBar = ghost.querySelector('.box-header-actions');
        if (ghostBar) {
          ghostBar.style.setProperty('display', 'flex', 'important');
          ghostBar.style.setProperty('opacity', '1', 'important');
          ghostBar.style.setProperty('visibility', 'visible', 'important');
        }
        ghost.style.cssText += `;position:fixed;top:0;left:-9999px;width:${Math.round(rect.width)}px;margin:0;pointer-events:none;opacity:1;`;
        document.body.appendChild(ghost);
        void ghost.offsetHeight;
        card._dndGhost = ghost;
        const offsetX = Math.max(0, Math.min(rect.width, (e.clientX || 0) - rect.left));
        const offsetY = Math.max(0, Math.min(rect.height, (e.clientY || 0) - rect.top));
        e.dataTransfer.setDragImage(ghost, offsetX, Math.min(offsetY, 80));
      } catch { /* best effort */ }
    }
    card.classList.add('is-dragging');
    // Blind form controls mid-flight: textareas/inputs swallow dragover+drop
    // over themselves, so releases parked over an editor surface never
    // dispatch drop. Same technique as the inner row-drag path.
    list.classList.add('box-drag-active');
    // Omnidirectional collapse AFTER the native drag ghost is captured:
    // rAF-deferred so setData/dragimage snapshot lands on the full layout,
    // then every card (including the dragged one) shrinks to title+toolbar
    // via the toolbar Recolher seam (.hidden). Direction-independent —
    // UP and DOWN drags see the same compact list. Synchronous hide here
    // would shift layout mid-gesture and abort the native drag (see
    // scripts/smoke-card-dnd.mjs root cause), hence the deferral.
    const collapseAllTmp = () => {
      if (!dragId) return;
      $$('.box-card', list).forEach((c) => {
        const bd = $('.box-body', c);
        if (bd && !bd.classList.contains('hidden')) { bd.classList.add('hidden'); bd.dataset.tmpHide = '1'; }
      });
    };
    if (typeof requestAnimationFrame === 'function') requestAnimationFrame(collapseAllTmp);
    else setTimeout(collapseAllTmp, 0);
  });
  const endDrag = () => {
    dragId = null;
    handleArmedId = null;
    hintKey = null;
    list.classList.remove('box-drag-active');
    restoreTmpCollapse();
    resetDraggable();
    $$('.box-card', list).forEach((c) => c.classList.remove('is-dragging', 'drop-before', 'drop-after'));
    try { document.querySelectorAll('.dnd-ghost').forEach((g) => g.remove()); } catch { /* best effort */ }
  };
  list.addEventListener('dragend', (e) => {
    if (dndDebug) dndLog('end', { dropped: !dragId, y: Math.round(e.clientY) });
    endDrag();
  });
  list.addEventListener('dragover', (e) => {
    if (!dragId) return;
    // No rich-container bail: in rich mode the editor surface covers ~90%
    // of the card, and drop only fires where dragover was preventDefaulted.
    // Inner row-drags never set dragId (dragstart bails), so they can't
    // reach here. Target card resolves from coordinates, not e.target.
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    const res = dndResolve(list, dragId, e.clientY);
    if (!res) return;
    const { target, isBefore } = res;
    // Hint matches drop math: top half = insert before, bottom = after.
    const key = `${target.dataset.boxId}${isBefore ? ':before' : ':after'}`;
    if (key !== hintKey) {
      hintKey = key;
      clearDropHints();
      target.classList.add(isBefore ? 'drop-before' : 'drop-after');
    }
    if (dndDebug && dndOverCount++ % 25 === 0) dndLog('over', { y: Math.round(e.clientY), after: key });
  });
  list.addEventListener('dragleave', (e) => {
    if (e.target === list) clearDropHints();
  });
  list.addEventListener('drop', (e) => {
    // Same as dragover above: resolve from coordinates so rich-mode
    // surfaces are valid drop targets. dragId guard excludes row-drags.
    if (!dragId) { if (dndDebug) dndLog('dropmiss', { reason: 'no-dragId' }); return; }
    e.preventDefault();
    // Direction-independent: closest card + top/bottom half resolves the
    // insertion slot identically for UP and DOWN drags (see dndResolve).
    // Same-half hover over the dragged card's own slot is a no-op.
    const res = dndResolve(list, dragId, e.clientY);
    if (!res) { if (dndDebug) dndLog('dropmiss', { reason: 'no-target' }); return; }
    const { fromIdx, toIdx } = res;
    const droppedId = dragId;
    if (dndDebug) dndLog('drop', { id: droppedId, toIdx, y: Math.round(e.clientY) });
    try {
      flushAdaptersToStore();
    } catch (err) { if (dndDebug) dndLog('drop-flush-threw', { err: String(err && err.message || err) }); }
    dragId = null;
    clearDropHints();
    list.classList.remove('box-drag-active');
    try {
      store.moveBoxTo(droppedId, toIdx);
    } catch (err) { if (dndDebug) dndLog('drop-move-threw', { err: String(err && err.message || err) }); }
    handleArmedId = null;
    resetDraggable();
  });
  // Enable draggable only while pressing the handle (prevents textarea drag conflicts).
  // Collapse intentionally does NOT land here: mousedown-time hide shifts
  // layout before dragstart and makes the gesture intermittent. All cards
  // collapse rAF-deferred inside dragstart instead (omnidirectional).
  list.addEventListener('mousedown', (e) => {
    const handle = e.target.closest?.('.drag-handle');
    const card = e.target.closest?.('.box-card');
    if (handle && card) {
      handleArmedId = card.dataset.boxId;
      card.setAttribute('draggable', 'true');
    }
  });
  const disarmHandle = () => {
    if (dragId) return; // keep armed for the in-flight dragstart/drop
    handleArmedId = null;
    restoreTmpCollapse();
    resetDraggable();
  };
  list.addEventListener('mouseup', disarmHandle);
  list.addEventListener('mouseleave', disarmHandle);
}
function dndResolve(list, dragId, y) {
  // Direction-independent drop resolution (UP and DOWN identical):
  // closest card to the pointer + top/bottom half -> insertion slot.
  // Same-slot hover is a no-op (standard Notion/Trello behavior).
  const cards = $$('.box-card', list);
  const fromIdx = cards.findIndex((c) => c.dataset.boxId === dragId);
  if (fromIdx < 0 || !cards.length) return null;
  let closest = null;
  let closestDist = Infinity;
  let targetIdx = -1;
  cards.forEach((card, i) => {
    if (card.dataset.boxId === dragId) return;
    const r = card.getBoundingClientRect();
    const mid = r.top + r.height / 2;
    const dist = Math.abs(y - mid);
    if (dist < closestDist) { closestDist = dist; closest = card; targetIdx = i; }
  });
  if (!closest) return null;
  const r = closest.getBoundingClientRect();
  const isBefore = y < (r.top + r.height / 2);
  const slot = isBefore ? targetIdx : targetIdx + 1;
  const toIdx = slot > fromIdx ? slot - 1 : slot;
  const clamped = Math.max(0, Math.min(cards.length - 1, toIdx));
  return { target: closest, targetIdx, isBefore, fromIdx, toIdx: clamped };
}

function bindCardActions(card, box) {
  const nameInput = $('.box-name', card);
  nameInput.addEventListener('input', () => { store.updateBox(box.id, { title: nameInput.value }); scheduleTocPreview(); });

  card.addEventListener('click', async (ev) => {
    const btn = ev.target.closest('[data-act]');
    if (!btn) return;
    const act = btn.dataset.act;
    flushSingleToStore(box.id);
    if (act === 'move-up' || act === 'move-down') {
      const dir = act === 'move-up' ? -1 : 1;
      // Flag BEFORE the mutation: the structural emit re-renders
      // synchronously and consumes it; trailing renderBoxes is skipped.
      moveNudgeId = { id: box.id, cls: dir < 0 ? 'card-nudge-up' : 'card-nudge-down' };
      store.moveBox(box.id, dir);
      return; // emit already re-rendered; trailing call would wipe the nudge
    }
    else if (act === 'ignore' || act === 'collapse') {
      // In-place toggle: falling through to renderBoxes() would rebuild
      // every card from template and wipe all editor state/focus.
      const key = act === 'ignore' ? 'ignored' : 'collapsed';
      store.updateBox(box.id, { [key]: !box[key] });
      const fresh = store.getBoxes().find((b) => b.id === box.id);
      btn.setAttribute('aria-pressed', String(!!fresh?.[key]));
      if (act === 'ignore') {
        card.classList.toggle('is-ignored', !!fresh?.ignored);
        scheduleTocPreview();
        syncEmptyState();
      } else {
        // M4 two-phase: display:none same-frame would snap (the old toggle).
        // Fade first via .is-closing, hide after; reopening cancels + fades in.
        const body = $('.box-body', card);
        if (card._bodyCloseT) { clearTimeout(card._bodyCloseT); card._bodyCloseT = null; }
        const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
        if (fresh?.collapsed) {
          body?.classList.add('is-closing');
          card._bodyCloseT = setTimeout(() => {
            body?.classList.add('hidden');
            body?.classList.remove('is-closing');
            card._bodyCloseT = null;
          }, reduce ? 0 : 220);
        } else {
          body?.classList.add('is-closing');
          body?.classList.remove('hidden');
          if (!reduce && body) void body.offsetHeight;
          body?.classList.remove('is-closing');
        }
      }
      return;
    }
    else if (act === 'undo' || act === 'redo') {
      // In-place like ignore/collapse: re-rendering would wipe editor state.
      try { adapters.get(box.id)?.[act]?.(); } catch { /* best effort */ }
      syncUndoButtons(card, box);
      return;
    }
    else if (act === 'dup') {
      const i = store.getBoxes().findIndex((b) => b.id === box.id);
      const copy = normalizeBox({ ...box, id: uid(), title: `${box.title} (cópia)` }, i + 1);
      newCardId = copy.id;
      store.boxes.splice(i + 1, 0, copy); store.save(); store.emit('boxes', { structural: true });
    } else if (act === 'del') {
      if (btn.dataset.armed) {
        // Red wash + slide before the store removal lands (~200ms = 1 frame).
        const doomed = btn.closest('.box-card');
        if (doomed) {
          doomed.classList.add('card-leaving');
          setTimeout(() => store.removeBox(box.id), 200);
          return;
        }
        store.removeBox(box.id);
      }
      // Two-step delete: arm (red) first, confirm within 2s. Class-based so
      // the SVG icon survives (textContent swaps would wipe it).
      else { btn.dataset.armed = '1'; btn.classList.add('armed'); setTimeout(() => { btn.dataset.armed = ''; btn.classList.remove('armed'); }, 2000); return; }
    } else if (act === 'image') openImageModal(box.id);
    // Search toggle must NOT fall through to renderBoxes(): a structural
    // re-render rebuilds the card from template (row hidden) and would
    // wipe the just-toggled row — the reported "button does nothing".
    else if (act === 'search') {
      const row = $('.search-row', card);
      const willOpen = row.classList.contains('hidden');
      row.classList.toggle('hidden');
      if (willOpen) {
        playMenuIn(row);
        // Prefill from current selection (markdown textarea or DOM selection).
        try {
          const ad = adapters.get(box.id);
          let selText = '';
          if (box.mode === 'markdown' && ad instanceof TextareaAdapter) {
            const ta = $('.box-md', card);
            selText = (ta.value || '').slice(ta.selectionStart ?? 0, ta.selectionEnd ?? 0);
          } else {
            selText = (window.getSelection()?.toString() || '').trim();
          }
          const input = $('.search-input', card);
          if (selText && !input.value) input.value = selText.slice(0, 80);
          input.focus();
          input.select?.();
          // Jump straight to first match so selection is followed.
          const evt = new Event('input', { bubbles: true });
          input.dispatchEvent(evt);
          const first = $('.search-next', card);
          first?.click();
        } catch { /* best-effort prefill */ }
      }
      return;
    }
    renderBoxes();
  });

  card.addEventListener('change', (ev) => {
    const kr = ev.target.closest?.('[data-kind-radio]');
    if (kr) {
      flushSingleToStore(box.id);
      store.updateBox(box.id, { kind: kr.value === 'table' ? 'table' : 'text' });
      const fresh = store.getBoxes().find((b) => b.id === box.id);
      if (!fresh) return;
      const cfg = $('.box-config', card);
      if (!cfg) { renderBoxes(); return; }
      const tpl = document.createElement('div');
      tpl.innerHTML = cardTemplate(fresh, 0).innerHTML;
      const next = $('.box-config', tpl);
      if (next) {
        cfg.replaceWith(next);
        card._rebindConfigToggle?.();
      }
      return;
    }

    const rotSelect = ev.target.closest(`[data-rot-select="${box.id}"]`);
    if (rotSelect) {
      const dir = rotSelect.value;
      store.updateBox(box.id, {
        tableLayout: dir === 'ccw' ? 'rotated_ccw' : 'rotated_cw',
        tableRotationDirection: dir,
      });
      return;
    }
    const rotRadio = ev.target.closest(`input[name="card-table-rot-${box.id}"]`);
    if (rotRadio) {
      const dir = rotRadio.value;
      store.updateBox(box.id, {
        tableLayout: dir === 'ccw' ? 'rotated_ccw' : 'rotated_cw',
        tableRotationDirection: dir,
      });
      return;
    }

    const cfg = ev.target.closest('[data-cfg]');
    if (!cfg) return;
    const key = cfg.dataset.cfg;
    let val = cfg.type === 'checkbox' ? cfg.checked : cfg.value;
    if (key === 'tableLayout') {
      const rotSub = $('.card-table-rot-container', card);
      const isRot = (val === 'rotated');
      if (rotSub) rotSub.classList.toggle('hidden', !isRot);
      if (isRot) {
        const rotSel = card.querySelector(`[data-rot-select="${box.id}"]`);
        const rotRad = card.querySelector(`input[name="card-table-rot-${box.id}"]:checked`);
        const dir = rotSel?.value || rotRad?.value || 'cw';
        val = dir === 'ccw' ? 'rotated_ccw' : 'rotated_cw';
        store.updateBox(box.id, {
          tableLayout: val,
          tableRotationDirection: dir,
        });
        return;
      }
    }
    if (key.includes('.')) {
      const [head, tail] = key.split('.');
      store.updateBoxDeep(box.id, [head, tail], head === 'masthead' && tail === 'enabled' ? !!val : val);
    } else store.updateBox(box.id, { [key]: val });
    // Config edits feed the TOC preview + topbar document slot (masthead
    // course/topic of the first block) and pagination, like globals do.
    scheduleTocPreview();
    schedulePaginate();
  });

  // Masthead text fields update the topbar document slot live, without
  // waiting for blur (change covers checkboxes/selects/blur-commits).
  card.addEventListener('input', (ev) => {
    const t = ev.target.closest?.('[data-cfg]');
    if (!t || !t.closest('.masthead-grid')) return;
    if (t.type === 'checkbox' || t.tagName === 'SELECT') return;
    const parts = (t.dataset.cfg || '').split('.');
    if (parts.length !== 2) return;
    store.updateBoxDeep(box.id, parts, t.value);
    scheduleTocPreview();
  });

  // Per-card find/replace over adapter text (both modes). All mutations go
  // through getContent/setContent + explicit store sync: no keystrokes lost,
  // no silent divergence. Markdown mode selects natively with scroll follow;
  // Rich mode highlights via DOM Range + flash + scroll.
  const searchInput = $('.search-input', card);
  const replaceInput = $('.replace-input', card);
  const countLabel = $('.search-count', card);
  const sr = { matches: [], idx: -1, q: '' };
  const currentText = () => {
    flushSingleToStore(box.id);
    return store.getBoxes().find((b) => b.id === box.id)?.markdown || '';
  };
  const recompute = () => {
    const q = searchInput.value;
    if (q !== sr.q) { sr.q = q; sr.idx = -1; sr.matches = []; }
    if (!q) { sr.matches = []; sr.idx = -1; countLabel.textContent = ''; return false; }
    const text = currentText().toLowerCase();
    const needle = q.toLowerCase();
    sr.matches = [];
    let from = 0;
    while (true) {
      const at = text.indexOf(needle, from);
      if (at < 0) break;
      sr.matches.push({ start: at, end: at + needle.length });
      from = at + Math.max(1, needle.length);
    }
    if (sr.idx < 0 && sr.matches.length > 0) sr.idx = 0;
    if (sr.idx >= sr.matches.length) sr.idx = sr.matches.length - 1;
    countLabel.textContent = sr.matches.length === 0 ? '0' : `${sr.idx + 1} de ${sr.matches.length}`;
    return sr.matches.length > 0;
  };
  const showCurrent = (dir = 1) => {
    if (sr.idx < 0 || sr.idx >= sr.matches.length) return;
    const m = sr.matches[sr.idx];
    countLabel.textContent = `${sr.idx + 1} de ${sr.matches.length}`;
    // Rolling digit tick, direction-aware.
    countLabel.classList.remove('search-rolling-next', 'search-rolling-prev');
    void countLabel.offsetWidth;
    countLabel.classList.add(dir >= 0 ? 'search-rolling-next' : 'search-rolling-prev');
    const ad = adapters.get(box.id);
    if (box.mode === 'markdown' && ad instanceof TextareaAdapter) {
      ad.highlight(m.start, m.end);
    } else if (ad && typeof ad.highlight === 'function') {
      // Rich mode: DOM Range highlight + flash + scroll.
      try { ad.highlight(m.start, m.end, sr.q); } catch { /* flash only */ }
    } else {
      const root = $('.rich-container', card);
      root.classList.remove('rich-flash');
      void root.offsetWidth; // restart animation
      root.classList.add('rich-flash');
    }
    card.classList.remove('search-hit-pulse');
    void card.offsetWidth;
    card.classList.add('search-hit-pulse');
    card.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  };
  const step = (dir) => {
    if (!recompute()) return;
    sr.idx = (sr.idx + dir + sr.matches.length) % sr.matches.length;
    showCurrent(dir);
  };
  const persistText = (next) => {
    const ad = adapters.get(box.id);
    if (box.mode === 'markdown' && ad instanceof TextareaAdapter) {
      ad.setContent(next);
    } else if (ad && typeof ad.setContent === 'function') {
      ad.setContent(next); // remounts inside the fixed shell; no card shift
    }
    box.markdown = next;
    store.save();
    updateCharCount(card, box.id);
    scheduleTocPreview();
  };
  const doReplace = (all) => {
    const q = searchInput.value;
    if (!q || !recompute()) return;
    const rep = replaceInput.value ?? '';
    const text = currentText();
    let next;
    if (all) {
      next = text.split(new RegExp(escapeRegExp(q), 'gi')).join(rep);
      sr.matches = []; sr.idx = -1;
      countLabel.textContent = '0';
    } else {
      const m = sr.matches[sr.idx];
      if (!m) return;
      // Re-find defensively: text may have changed since matches computed.
      const at = text.toLowerCase().indexOf(q.toLowerCase(), Math.max(0, m.start - q.length));
      if (at < 0) { recompute(); return; }
      next = text.slice(0, at) + rep + text.slice(at + q.length);
      sr.matches = []; sr.idx = -1;
    }
    persistText(next);
    if (recompute()) showCurrent();
  };
  const escapeRegExp = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  searchInput.addEventListener('input', () => { sr.idx = -1; recompute(); });
  searchInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); step(e.shiftKey ? -1 : 1); } });
  $('.search-next', card).addEventListener('click', () => step(1));
  $('.search-prev', card).addEventListener('click', () => step(-1));
  $('.replace-one', card).addEventListener('click', () => doReplace(false));
  $('.replace-all', card).addEventListener('click', () => doReplace(true));

  // Per-card config collapse: inline accordion, flag persisted, content kept.
  // Rebindable after kind-switch section refresh (listener lives on the button).
  const bindConfigToggle = () => {
    const configToggle = $('[data-config-toggle]', card);
    configToggle?.addEventListener('click', () => {
      const body = $('.config-body', card);
      const nowOpen = body.classList.contains('hidden') || body.classList.contains('is-closing');
      // A pending close must never hide a re-opened panel.
      if (card._configCloseT) { clearTimeout(card._configCloseT); card._configCloseT = null; }
      if (nowOpen) {
        body.classList.remove('hidden', 'is-closing');
        void body.offsetHeight; // reflow: 0fr->1fr must transition, not snap
        playMenuIn(body);
      } else {
        // Two-phase close: display:none in the same frame would kill the
        // 1fr->0fr transition (the reported snap) — animate first, hide after.
        body.classList.add('is-closing');
        const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
        card._configCloseT = setTimeout(() => {
          body.classList.add('hidden');
          body.classList.remove('is-closing');
          card._configCloseT = null;
        }, reduce ? 0 : 300);
      }
      configToggle.setAttribute('aria-expanded', String(nowOpen));
      store.updateBox(box.id, { configOpen: nowOpen });
    });
  };
  bindConfigToggle();
  card._rebindConfigToggle = bindConfigToggle;
}

/* M5 global find: document-wide match index over adapter text (both modes),
 * mirroring the per-card engine (recompute/step/show/persist). Steps jump
 * card-to-card through the highlight() seam; per-card rows stay untouched. */
const gsr = { list: [], idx: -1, q: '' };
const escapeRx = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
function globalSearchText(boxId) {
  flushSingleToStore(boxId);
  return store.getBoxes().find((b) => b.id === boxId)?.markdown || '';
}
function globalSearchCount() {
  const count = $('#gsearch-count');
  if (!count) return;
  if (gsr.list.length === 0) { count.textContent = gsr.q ? '0' : ''; return; }
  const m = gsr.list[gsr.idx];
  const bi = store.getBoxes().findIndex((b) => b.id === m.boxId);
  const inBlock = gsr.list.filter((x) => x.boxId === m.boxId).length;
  count.textContent = `${gsr.idx + 1} de ${gsr.list.length} · B${bi + 1} (${inBlock})`;
}
function globalSearchRecompute() {
  const input = $('#gsearch-input');
  const q = input ? input.value : '';
  if (q !== gsr.q) { gsr.q = q; gsr.idx = -1; gsr.list = []; }
  if (!q) { gsr.list = []; gsr.idx = -1; globalSearchCount(); return false; }
  flushAdaptersToStore();
  gsr.list = [];
  const needle = q.toLowerCase();
  for (const box of store.getBoxes()) {
    const text = (box.markdown || '').toLowerCase();
    let from = 0;
    while (true) {
      const at = text.indexOf(needle, from);
      if (at < 0) break;
      gsr.list.push({ boxId: box.id, start: at, end: at + needle.length });
      from = at + Math.max(1, needle.length);
    }
  }
  if (gsr.idx < 0 && gsr.list.length > 0) gsr.idx = 0;
  if (gsr.idx >= gsr.list.length) gsr.idx = gsr.list.length - 1;
  globalSearchCount();
  return gsr.list.length > 0;
}
function globalSearchShow(dir = 1) {
  const m = gsr.list[gsr.idx];
  if (!m) return;
  globalSearchCount();
  const box = store.getBoxes().find((b) => b.id === m.boxId);
  const card = document.querySelector(`[data-box-id="${m.boxId}"]`);
  // Collapsed hosts reveal view-only so the match is visible; the stored
  // collapsed flag is untouched and the next toggle re-hides.
  if (box?.collapsed && card) $('.box-body', card)?.classList.remove('hidden', 'is-closing');
  if (card) {
    const label = $('#gsearch-count');
    if (label) {
      label.classList.remove('search-rolling-next', 'search-rolling-prev');
      void label.offsetWidth;
      label.classList.add(dir >= 0 ? 'search-rolling-next' : 'search-rolling-prev');
    }
    card.classList.remove('search-hit-pulse');
    void card.offsetWidth;
    card.classList.add('search-hit-pulse');
    card.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }
  const ad = adapters.get(m.boxId);
  if (box && box.mode === 'markdown' && ad instanceof TextareaAdapter) {
    ad.highlight(m.start, m.end);
  } else if (ad && typeof ad.highlight === 'function') {
    try { ad.highlight(m.start, m.end, gsr.q); } catch { /* flash only */ }
  }
}
function globalSearchStep(dir) {
  if (!globalSearchRecompute()) return;
  gsr.idx = (gsr.idx + dir + gsr.list.length) % gsr.list.length;
  globalSearchShow(dir);
}
function globalSearchPersist(boxId, next) {
  const box = store.getBoxes().find((b) => b.id === boxId);
  if (!box) return;
  const card = document.querySelector(`[data-box-id="${boxId}"]`);
  const ad = adapters.get(boxId);
  if (ad && typeof ad.setContent === 'function') {
    try { ad.setContent(next); } catch { /* remounts inside the fixed shell */ }
  }
  box.markdown = next;
  store.save();
  if (card) { updateCharCount(card, boxId); syncUndoButtons(card, box); }
  scheduleTocPreview();
}
function globalSearchReplace(all) {
  const q = $('#gsearch-input')?.value || '';
  if (!q || !globalSearchRecompute()) return;
  const rep = $('#greplace-input')?.value ?? '';
  if (all) {
    const rx = new RegExp(escapeRx(q), 'gi');
    for (const box of store.getBoxes()) {
      const text = globalSearchText(box.id);
      if (!text.toLowerCase().includes(q.toLowerCase())) continue;
      globalSearchPersist(box.id, text.split(rx).join(rep));
    }
  } else {
    const m = gsr.list[gsr.idx];
    if (!m) return;
    const text = globalSearchText(m.boxId);
    const at = text.toLowerCase().indexOf(q.toLowerCase(), Math.max(0, m.start - q.length));
    if (at < 0) { globalSearchRecompute(); return; }
    globalSearchPersist(m.boxId, text.slice(0, at) + rep + text.slice(at + q.length));
  }
  gsr.idx = -1;
  if (globalSearchRecompute()) globalSearchShow(1);
}
function toggleGlobalSearch(force) {
  const row = $('#gsearch-row');
  if (!row) return;
  const willOpen = force !== undefined ? force : row.classList.contains('hidden');
  row.classList.toggle('hidden', !willOpen);
  if (willOpen) {
    playMenuIn(row);
    gsr.idx = -1;
    if (globalSearchRecompute()) { gsr.idx = 0; globalSearchShow(1); }
    const input = $('#gsearch-input');
    input?.focus();
    input?.select?.();
  }
}
function bindGlobalSearch() {
  $('#gsearch-input')?.addEventListener('input', () => { gsr.idx = -1; globalSearchRecompute(); });
  $('#gsearch-input')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); globalSearchStep(e.shiftKey ? -1 : 1); }
  });
  $('#gsearch-prev')?.addEventListener('click', () => globalSearchStep(-1));
  $('#gsearch-next')?.addEventListener('click', () => globalSearchStep(1));
  $('#greplace-one')?.addEventListener('click', () => globalSearchReplace(false));
  $('#greplace-all')?.addEventListener('click', () => globalSearchReplace(true));
  $('#gsearch-close')?.addEventListener('click', () => toggleGlobalSearch(false));
  // Quiet trigger with two homes: topbar button on desktop, moved into the
  // Mais sheet on mobile (see bindMobileBar's move list). From the sheet,
  // close it first through the public control, then open the bar.
  $('#global-search-btn')?.addEventListener('click', () => {
    if (!$('#sheet-more')?.classList.contains('hidden')) $('#sheet-close')?.click();
    toggleGlobalSearch(true);
  });
}

/* ------------------------- global controls ------------------------ */
function readGlobalsFromUI() {
  const g = store.getGlobals();
  const radio = (name) => document.querySelector(`input[name="${name}"]:checked`)?.value;
  g.template = radio('template') || g.template;
  try {
    const ws = document.querySelector('.workspace') || document.body;
    if (ws) ws.setAttribute('data-template', g.template || 'base');
  } catch { /* cosmetic */ }
  g.lang = $('#doc-lang-select').value;
  g.headerCustomEnabled = $('#custom-header-checkbox').checked;
  g.headerText = $('#custom-header-input').value;
  g.headerPosition = radio('header-position') || 'top';
  g.headerDateEnabled = $('#header-date-checkbox').checked;
  g.dateFormat = $('#date-format-select').value;
  g.dateCustom = $('#custom-date-input').value;
  g.chaptersToc = $('#chapters-toc-checkbox').checked;
  g.tocTitle = $('#toc-title-input').value;
  g.tocHeadings = $('#toc-headings-checkbox').checked;
  g.docTitlesEnabled = $('#doc-titles-enabled-checkbox').checked;
  g.docTitle = $('#doc-title-input').value;
  g.docSubtitle = $('#doc-subtitle-input').value;
  g.columnLayout = radio('column-layout') || '2';
  const rawTableMode = radio('table-layout-mode') || 'auto';
  if (rawTableMode === 'rotated' || rawTableMode === 'rotated_cw' || rawTableMode === 'rotated_ccw') {
    const rotDir = radio('table-rotation-direction') || 'cw';
    g.tableLayoutMode = rotDir === 'ccw' ? 'rotated_ccw' : 'rotated_cw';
    g.tableRotationDirection = rotDir;
  } else {
    g.tableLayoutMode = rawTableMode;
  }
  g.alignment = radio('page-alignment') || 'justify';
  g.flushColumns = $('#flush-bottom-checkbox')?.checked !== false;
  g.balanceColumns = $('#column-balance-checkbox')?.checked === true;
  g.splitListItems = $('#split-lists-checkbox').checked;
  g.imageCaptions = $('#image-captions-checkbox').checked;
  store.save();
}

function writeGlobalsToUI() {
  const g = store.getGlobals();
  const check = (name, val) => $$(`input[name="${name}"]`).forEach((r) => { r.checked = r.value === val; });
  const isRot = (g.tableLayoutMode === 'rotated' || g.tableLayoutMode === 'rotated_cw' || g.tableLayoutMode === 'rotated_ccw' || g.tableLayoutMode === 'rotated_d1' || g.tableLayoutMode === 'rotated_d2');
  const targetMode = isRot ? 'rotated' : g.tableLayoutMode;
  check('template', g.template); check('header-position', g.headerPosition);
  check('column-layout', g.columnLayout);
  check('table-layout-mode', targetMode);
  const isCCW = (g.tableLayoutMode === 'rotated_ccw' || g.tableLayoutMode === 'rotated_d2' || g.tableRotationDirection === 'ccw');
  check('table-rotation-direction', isCCW ? 'ccw' : 'cw');
  const rotContainer = $('#table-rotation-direction-container');
  if (rotContainer) rotContainer.classList.toggle('hidden', !isRot);
  check('page-alignment', g.alignment);
  $('#doc-lang-select').value = g.lang;
  $('#custom-header-checkbox').checked = g.headerCustomEnabled;
  $('#custom-header-input').value = g.headerText;
  $('#custom-header-inputs').classList.toggle('hidden', !g.headerCustomEnabled);
  $('#header-date-checkbox').checked = g.headerDateEnabled;
  $('#header-date-inputs').classList.toggle('hidden', !g.headerDateEnabled);
  $('#date-format-select').value = g.dateFormat;
  $('#custom-date-row').classList.toggle('hidden', g.dateFormat !== 'custom');
  $('#custom-date-input').value = g.dateCustom;
  $('#chapters-toc-checkbox').checked = g.chaptersToc;
  $('#toc-title-input').value = g.tocTitle;
  $('#toc-headings-checkbox').checked = g.tocHeadings;
  const allBoxes = store.getBoxes();
  const firstActiveMh = allBoxes.find((b) => !b.ignored && b.masthead?.enabled && (b.masthead?.course || b.masthead?.topic));
  const adaptedDocTitle = firstActiveMh ? (firstActiveMh.masthead.course || firstActiveMh.masthead.topic || '') : '';
  const adaptedDocSubtitle = (firstActiveMh && firstActiveMh.masthead.course && firstActiveMh.masthead.topic) ? firstActiveMh.masthead.topic : '';

  $('#doc-titles-container').classList.toggle('hidden', !g.chaptersToc || !g.docTitlesEnabled);
  $('#doc-title-input').value = g.docTitle;
  $('#doc-title-input').placeholder = adaptedDocTitle || 'ex: Relatório Técnico';
  $('#doc-subtitle-input').value = g.docSubtitle;
  $('#doc-subtitle-input').placeholder = adaptedDocSubtitle || 'ex: Subtítulo ou Descrição Breve';
  $('#flush-bottom-checkbox').checked = g.flushColumns !== false;
  $('#column-balance-checkbox').checked = g.balanceColumns === true;
  $('#split-lists-checkbox').checked = g.splitListItems;
  $('#image-captions-checkbox').checked = g.imageCaptions;
  updateAccSummaries();
}

function bindGlobals() {
  updateAccSummaries();
  document.querySelector('.settings-pane').addEventListener('change', (e) => {
    if (e.target.matches('input, select')) {
      if (e.target.name === 'table-layout-mode' || e.target.name === 'table-rotation-direction') {
        const isRot = (document.querySelector('input[name="table-layout-mode"]:checked')?.value === 'rotated');
        const rotEl = $('#table-rotation-direction-container');
        rotEl?.classList.toggle('hidden', !isRot);
        if (isRot && rotEl) playMenuIn(rotEl);
      }
      readGlobalsFromUI(); scheduleTocPreview(); schedulePaginate();
    }
  });
  document.querySelector('.settings-pane').addEventListener('input', (e) => {
    if (e.target.matches('input[type="text"], select')) { readGlobalsFromUI(); scheduleTocPreview(); schedulePaginate(); updateAccSummaries(); }
  });
  document.querySelector('.settings-pane').addEventListener('change', () => { try { updateAccSummaries(); } catch { /* cosmetic */ } });
  $('#custom-header-checkbox').addEventListener('change', (e) => { const el = $('#custom-header-inputs'); const willOpen = e.target.checked; el.classList.toggle('hidden', !willOpen); if (willOpen) playMenuIn(el); });
  $('#header-date-checkbox').addEventListener('change', (e) => { const el = $('#header-date-inputs'); const willOpen = e.target.checked; el.classList.toggle('hidden', !willOpen); if (willOpen) playMenuIn(el); });
  $('#date-format-select').addEventListener('change', (e) => { const el = $('#custom-date-row'); const willOpen = e.target.value === 'custom'; el.classList.toggle('hidden', !willOpen); if (willOpen) playMenuIn(el); });
  $('#chapters-toc-checkbox').addEventListener('change', (e) => {
    const el = $('#doc-titles-container'); const willOpen = e.target.checked && $('#doc-titles-enabled-checkbox').checked; el.classList.toggle('hidden', !willOpen); if (willOpen) playMenuIn(el);
  });
  $('#doc-titles-enabled-checkbox').addEventListener('change', (e) => {
    const el = $('#doc-titles-container'); const willOpen = e.target.checked && $('#chapters-toc-checkbox').checked; el.classList.toggle('hidden', !willOpen); if (willOpen) playMenuIn(el);
  });
}

/* ------------------------- TOC + pagination ----------------------- */
let lastPaginationData = null;

function scheduleTocPreview() {
  const list = $('#toc-preview-list');
  if (!list) return;

  const g = store.getGlobals();
  const allBoxes = store.getBoxes();
  const firstBox = allBoxes.find((b) => !b.ignored && ((b.title || '').trim() || (b.markdown || '').trim())) || allBoxes[0];
  const firstMh = firstBox?.masthead;
  const isFirstMhOn = firstBox && (firstMh?.enabled === true || firstBox.enable_masthead === true || firstBox.masthead_enabled === true);
  const adaptedDocTitle = (isFirstMhOn && (firstMh?.course || firstMh?.topic)) ? (firstMh.course || firstMh.topic).trim() : '';
  const adaptedDocSubtitle = (isFirstMhOn && firstMh?.course && firstMh?.topic) ? firstMh.topic.trim() : '';

  const docTitlesActive = !!(g.chaptersToc && g.docTitlesEnabled);
  let docTitleVal = docTitlesActive ? (g.docTitle || '').trim() : '';
  let docSubtitleVal = docTitlesActive ? (g.docSubtitle || '').trim() : '';
  if (!docTitleVal && adaptedDocTitle) {
    docTitleVal = adaptedDocTitle;
    if (!docSubtitleVal && adaptedDocSubtitle && adaptedDocSubtitle !== docTitleVal) {
      docSubtitleVal = adaptedDocSubtitle;
    }
  }

  const docHeaderPreview = $('#toc-doc-header-preview');
  const docTitlePreview = $('#toc-doc-title-preview');
  const docSubtitlePreview = $('#toc-doc-subtitle-preview');

  const titleSlot = $('#doc-title-slot');
  if (titleSlot) {
    const label = docTitleVal || adaptedDocTitle || 'Documento sem título';
    titleSlot.textContent = docSubtitleVal && docSubtitleVal !== label ? `${label} — ${docSubtitleVal}` : label;
    titleSlot.title = titleSlot.textContent;
  }

  if (docHeaderPreview) {
    if (docTitleVal || docSubtitleVal) {
      docHeaderPreview.classList.remove('hidden');
      if (docTitlePreview) {
        docTitlePreview.textContent = docTitleVal;
        docTitlePreview.classList.toggle('hidden', !docTitleVal);
      }
      if (docSubtitlePreview) {
        docSubtitlePreview.textContent = docSubtitleVal;
        docSubtitlePreview.classList.toggle('hidden', !docSubtitleVal);
      }
    } else {
      docHeaderPreview.classList.add('hidden');
    }
  }

  const activeBoxes = allBoxes.filter((b) => !b.ignored && ((b.title || '').trim() || (b.markdown || '').trim()));
  const totalChapters = allBoxes.length;
  const activeChapters = activeBoxes.length;

  const countTag = $('#toc-count-tag');
  if (countTag) {
    const ignored = totalChapters - activeChapters;
    countTag.textContent = g.chaptersToc
      ? (ignored > 0
        ? `${activeChapters} de ${totalChapters} ${activeChapters === 1 ? 'capítulo ativo' : 'capítulos ativos'}`
        : `${activeChapters} ${activeChapters === 1 ? 'capítulo' : 'capítulos'}`)
      : 'Sem sumário';
  }
  updateAccSummaries();

  const includeHeadings = g.tocHeadings !== false;
  let estimatedBodyPage = 1;
  let activeSectionIdx = 0;

  const itemsHtml = [];
  allBoxes.forEach((b, idx) => {
    const rawName = (b.title || '').trim() || `Capítulo ${idx + 1}`;
    const topic = (b.masthead?.topic || '').trim();
    const displayTitle = (topic && topic !== rawName) ? `${rawName} — ${topic}` : rawName;

    if (b.ignored) {
      itemsHtml.push(`
        <li class="toc-preview-item is-ignored" data-id="${b.id}">
          <span class="toc-preview-num">${String(idx + 1).padStart(2, '0')}</span>
          <span class="toc-preview-name" title="${escapeHtml(displayTitle)}">${escapeHtml(displayTitle)}</span>
          <span class="toc-preview-page">(ignorado)</span>
        </li>
      `);
      return;
    }

    activeSectionIdx++;
    let chapterPage = estimatedBodyPage;
    let secPagination = null;
    if (lastPaginationData?.sections) {
      secPagination = lastPaginationData.sections.find((s) => s.index === activeSectionIdx || s.name === rawName);
      if (secPagination) {
        const tocPageOffset = lastPaginationData?.tocPages || 1;
        chapterPage = secPagination.bodyPage || (g.chaptersToc ? Math.max(1, (secPagination.startPage || (1 + tocPageOffset)) - tocPageOffset) : (secPagination.startPage || 1));
      }
    }

    itemsHtml.push(`
      <li class="toc-preview-item" data-id="${b.id}">
        <span class="toc-preview-num">${String(idx + 1).padStart(2, '0')}</span>
        <span class="toc-preview-name" title="${escapeHtml(displayTitle)}">${escapeHtml(displayTitle)}</span>
        <span class="toc-preview-page" data-page-target="${b.id}">pág. ${chapterPage}</span>
      </li>
    `);

    if (includeHeadings) {
      const lines = (b.markdown || '').split('\n');
      let subCount = 0;
      for (const line of lines) {
        const hMatch = line.match(/^(#{1,2})\s+(.+)$/);
        if (hMatch && subCount < 4) {
          subCount++;
          const cleanHeading = hMatch[2].replace(/[#*`_]/g, '').trim();
          if (cleanHeading) {
            let headingPage = chapterPage;
            if (secPagination?.headings) {
              const hEntry = secPagination.headings.find((h) => (h.text || '').trim().toLowerCase() === cleanHeading.toLowerCase());
              if (hEntry) {
                const tocPageOffset = lastPaginationData?.tocPages || 1;
                headingPage = hEntry.bodyPage || (g.chaptersToc ? Math.max(1, (hEntry.page || chapterPage + tocPageOffset) - tocPageOffset) : (hEntry.page || chapterPage));
              }
            }
            itemsHtml.push(`
              <li class="toc-preview-item toc-preview-subheading" data-id="${b.id}" data-heading="${escapeHtml(cleanHeading)}">
                <span class="toc-preview-sub-bullet">›</span>
                <span class="toc-preview-name" title="${escapeHtml(cleanHeading)}">${escapeHtml(cleanHeading)}</span>
                <span class="toc-preview-page">pág. ${headingPage}</span>
              </li>
            `);
          }
        }
      }
    }

    estimatedBodyPage = chapterPage + 1;
  });

  list.innerHTML = itemsHtml.join('') || '<li class="toc-preview-empty">Nenhum bloco para exibir</li>';

  $$('#toc-preview-list li[data-id]').forEach((li) => {
    li.setAttribute('tabindex', '0');
    li.setAttribute('role', 'button');
    const jump = () => {
      const target = document.querySelector(`[data-box-id="${li.dataset.id}"]`);
      if (!target) return;
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      target.classList.remove('card-jump-active');
      void target.offsetWidth;
      target.classList.add('card-jump-active');
      setTimeout(() => target.classList.remove('card-jump-active'), 1200);
      // Subheading rows teleport inside the block: focus the matching line
      // in the markdown textarea, else the rich adapter's text search.
      const heading = li.dataset.heading;
      if (!heading) return;
      try {
        const boxId = li.dataset.id;
        const box = store.getBoxes().find((b) => String(b.id) === String(boxId));
        const boxKey = box ? box.id : boxId;
        const ta = target.querySelector('textarea.box-md');
        if (ta && box && box.mode !== 'rich') {
          const lines = String(ta.value || '').split('\n');
          const at = lines.findIndex((l) => l.replace(/^[#>\s*`_]+/, '').replace(/[#*`_]/g, '').trim().toLowerCase() === heading.toLowerCase());
          if (at >= 0) {
            const pos = lines.slice(0, at).join('\n').length + (at > 0 ? 1 : 0);
            ta.focus({ preventScroll: true });
            ta.setSelectionRange(pos, pos + lines[at].length);
            ta.scrollTop = Math.max(0, (at + 1) * 21 - ta.clientHeight / 2);
          }
          return;
        }
        const ad = adapters.get(boxKey);
        if (ad && typeof ad.highlight === 'function') {
          try { ad.highlight(0, 0, heading); } catch { /* cosmetic */ }
        }
      } catch { /* scroll already landed on the card */ }
    };
    li.addEventListener('click', jump);
    li.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); jump(); }
    });
  });
}

let paginateT = null;
let paginateController = null;
function schedulePaginate() {
  clearTimeout(paginateT);
  paginateT = setTimeout(async () => {
    try {
      flushAdaptersToStore();
      // D: abort superseded estimates (out-of-order completion) and strip
      // image payloads — server estimates are post-strip, so TOC numbers
      // are unchanged while MB data URIs never hit the wire/isolate.
      // Over-budget payloads skip silently (best-effort preview).
      if (paginateController) {
        try { paginateController.abort(); } catch { /* superseded */ }
      }
      paginateController = new AbortController();
      const payload = ExportPayloadBuilder.build(store, { preview: true });
      const scan = stripPayloadImages(payload);
      if (checkPayloadBudget(payload, scan)) return;
      const data = await ExportService.paginate(payload, paginateController.signal);
      if (data?.sections) {
        lastPaginationData = data;
        scheduleTocPreview();
      }
    } catch { /* pagination is best-effort */ }
  }, 350);
}

/* ------------------------- image modal ---------------------------- */
let imageTargetBox = null;
let imageTargetBlockIndex = null;
let imageInsertIndex = null;
/* Per-image scale contract (handoff §2): title suffix `{width=N}`, clamped
 * 0.1–1.0. Mirrors parseScaleTitle in src/v2/ingest/from-markdown.js. */
function clampImageScale(n) {
  const v = Number(n);
  if (!Number.isFinite(v)) return 1;
  return Math.min(1, Math.max(0.05, v));
}
function readImageScale() {
  const raw = $('#img-scale-input')?.value ?? $('#img-scale-range')?.value ?? 1;
  return clampImageScale(raw);
}
function writeImageScale(v) {
  const clamped = clampImageScale(v);
  const range = $('#img-scale-range');
  const num = $('#img-scale-input');
  const label = $('#img-scale-label');
  if (range) range.value = String(clamped);
  if (num) num.value = String(clamped);
  if (label) label.textContent = `${Math.round(clamped * 100)}%`;
  return clamped;
}
function openImageModal(boxId, prefill = null, blockIndex = null) {
  imageTargetBox = boxId;
  imageTargetBlockIndex = blockIndex;
  $('#image-modal').classList.remove('hidden');
  if (prefill) {
    $('#img-source-input').value = prefill.src || '';
    $('#img-alt-input').value = prefill.alt || '';
    $('#img-caption-input').value = prefill.caption || '';
    $('#img-caption-toggle').checked = Boolean(prefill.caption);
    writeImageScale(prefill.scale || 1);
    if ($('#img-place-select')) $('#img-place-select').value = prefill.place || 'column';
  } else {
    $('#img-source-input').value = '';
    $('#img-alt-input').value = '';
    $('#img-caption-input').value = '';
    writeImageScale(1);
    if ($('#img-place-select')) $('#img-place-select').value = 'column';
  }
  updateImagePreview();
}
function closeImageModal() {
  $('#image-modal').classList.add('hidden');
  imageTargetBox = null;
  imageTargetBlockIndex = null;
  imageInsertIndex = null;
}
function updateImagePreview() {
  const src = $('#img-source-input').value.trim();
  const capOn = $('#img-caption-toggle').checked;
  const cap = $('#img-caption-input').value.trim();
  const scale = readImageScale();
  const label = $('#img-scale-label');
  if (label) label.textContent = `${Math.round(scale * 100)}%`;
  const show = !!src;
  $('#img-preview-box').classList.toggle('hidden', !show);
  if (show) {
    const tag = $('#img-preview-tag');
    // CLS guard: reserve space before bytes arrive; aspect updates on load.
    tag.style.aspectRatio = '16 / 9';
    tag.src = src;
    tag.onload = () => {
      try {
        const w = tag.naturalWidth || 0;
        const h = tag.naturalHeight || 0;
        if (w > 0 && h > 0) tag.style.aspectRatio = `${w} / ${h}`;
      } catch { /* keep fallback ratio */ }
    };
    $('#img-preview-caption-text').textContent = capOn && cap ? `Figura: ${cap}` : '';
  }
}
/* Canonical image markdown (single source of truth for insert +
   toggle round-trips). Emits the canonical ref-11 attr block:
   `![alt](src "caption") {#slug width=W place=P ratio=R}`.
   Omits width when 1, place when column, ratio when default 1.5. */
function formatImageMarkdown(alt, src, cap, scale = 1, place = 'column', ratio = 1.5) {
  return serializeFigureLine({ alt, src, caption: cap, scale, place, ratio });
}

async function confirmImage() {
  try {
    let src = $('#img-source-input').value.trim();
    const file = $('#img-file-picker').files?.[0];
    if (file) src = await ExportService.uploadImage(file);
    else if (/^data:image\//.test(src)) src = await ExportService.uploadImage(src, $('#img-alt-input').value || 'figura.png');
    if (!src) { showError('Informe URL ou escolha um arquivo.'); return; }
    const alt = $('#img-alt-input').value.trim() || 'Figura';
    const capOn = $('#img-caption-toggle').checked;
    const cap = $('#img-caption-input').value.trim();
    const scale = readImageScale();
    const place = $('#img-place-select')?.value === 'full-width' ? 'full-width' : 'column';
    const tag = $('#img-preview-tag');
    let ratio = 1.5;
    if (tag && tag.naturalWidth && tag.naturalHeight) {
      ratio = Math.round((tag.naturalWidth / tag.naturalHeight) * 100) / 100;
    }
    const md = formatImageMarkdown(alt, src, capOn ? cap : '', scale, place, ratio);
    const box = store.getBoxes().find((b) => b.id === imageTargetBox) ?? store.getBoxes()[0];
    if (!box) { showError('Nenhum bloco para inserir a imagem.'); return; }
    const ad = adapters.get(box.id);
    flushSingleToStore(box.id);

    if (imageTargetBlockIndex !== null && imageTargetBlockIndex !== undefined && ad && ad.store && Array.isArray(ad.store.blocks)) {
      // In-place update of target figure block
      ad.store.updateFigure(imageTargetBlockIndex, {
        alt,
        src,
        caption: capOn ? cap : '',
        scale,
        place,
        ratio,
      });
      box.markdown = ad.store.getMarkdown();
      store.save();
      ad.render();
      ad.emit();
    } else if (imageInsertIndex !== null && imageInsertIndex !== undefined && box.mode === 'rich' && ad && ad.store && typeof ad.store.insertBlockAt === 'function') {
      // Positional insert from the "+" gutter menu.
      ad.store.insertBlockAt(imageInsertIndex, `${md}\n`);
      box.markdown = ad.store.getMarkdown();
      store.save();
      ad.render();
      ad.emit();
    } else {
      // Normal insertion path
      box.markdown = `${box.markdown || ''}${box.markdown?.endsWith('\n') || !box.markdown ? '' : '\n'}\n${md}\n`;
      store.save();
      if (box.mode === 'rich' && ad && typeof ad.setContent === 'function') {
        await ad.setContent(box.markdown);
      } else {
        const card = document.querySelector(`[data-box-id="${box.id}"]`);
        if (card) { $('.box-md', card).value = box.markdown; }
      }
    }
    const card = document.querySelector(`[data-box-id="${box.id}"]`);
    if (card) updateCharCount(card, box.id);
    closeImageModal();
    $('#img-source-input').value = ''; $('#img-file-picker').value = '';
    writeImageScale(1);
    if ($('#img-place-select')) $('#img-place-select').value = 'column';
  } catch (e) { showError(errText(e, 'Falha ao inserir imagem')); }
}

/* ------------------------- theme / tabs / drawer ------------------ */
function initTopbarOverflow() {
  const btn = $('#topbar-overflow-btn');
  const panel = $('#topbar-overflow-panel');
  if (!btn || !panel) return;
  const setOpen = (open) => {
    panel.classList.toggle('hidden', !open);
    btn.setAttribute('aria-expanded', String(open));
    if (open) playMenuIn(panel);
  };
  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    setOpen(panel.classList.contains('hidden'));
  });
  panel.addEventListener('click', (e) => { if (e.target.closest('button')) setOpen(false); });
  document.addEventListener('click', (e) => {
    if (!panel.classList.contains('hidden') && !e.target.closest('.topbar-overflow')) setOpen(false);
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !panel.classList.contains('hidden')) { setOpen(false); btn.focus(); }
  });
}

function initTheme() {
  const get = (k) => { try { return typeof localStorage === 'undefined' ? null : localStorage.getItem(k); } catch { return null; } };
  const set = (k, v) => { try { if (typeof localStorage !== 'undefined') localStorage.setItem(k, v); } catch { /* ignore */ } };
  const applyTheme = (mode) => {
    document.documentElement.dataset.theme = mode;
    $('#theme-toggle')?.setAttribute('aria-pressed', String(mode === 'dark'));
  };
  const saved = get('doe-v2-new-theme');
  const initial = saved || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
  applyTheme(initial);
  $('#theme-toggle')?.addEventListener('click', () => {
    const next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    set('doe-v2-new-theme', next);
  });
}

const TAB_KEY = 'doe-v2-active-tab';
function initTabs() {
  initAccordion();
}

/* Canonical accordion settings panel: 4 semantic groups, one open by
   default (Documento). Toggling never touches the store. */
const ACC_KEY = 'doe-v2-acc-open';
function initAccordion() {
  const items = $$('.settings-pane .acc-item');
  if (!items.length) return;
  let open = null;
  try {
    const raw = typeof localStorage === 'undefined' ? null : localStorage.getItem(ACC_KEY);
    if (raw) open = JSON.parse(raw);
  } catch { /* defaults */ }
  const set = (v) => { try { if (typeof localStorage !== 'undefined') localStorage.setItem(ACC_KEY, JSON.stringify(v)); } catch { /* ignore */ } };
  const apply = (item, isOpen) => {
    item.classList.toggle('open', isOpen);
    $('.acc-head', item)?.setAttribute('aria-expanded', String(isOpen));
  };
  items.forEach((item) => {
    const head = $('.acc-head', item);
    const body = $('.acc-body', item);
    if (!head || !body) return;
    const key = item.dataset.acc || head.textContent.trim();
    const shouldOpen = Array.isArray(open) ? open.includes(key) : item.classList.contains('open');
    apply(item, shouldOpen);
    head.addEventListener('click', (e) => {
      if (e.target.closest('input, select, textarea, a')) return;
      if (e.target.closest('[data-sub]')) return;
      const nowOpen = !item.classList.contains('open');
      apply(item, nowOpen);
      if (nowOpen) { try { playMenuIn(body); } catch { /* cosmetic */ } }
      try {
        const keys = items.filter((it) => it.classList.contains('open')).map((it) => it.dataset.acc || it.textContent.trim());
        set(keys);
      } catch { /* ignore */ }
    });
  });
  updateAccSummaries();
  // Deep-menu sub-rows: tap a field-row to reveal its detail controls.
  const pane = document.querySelector('.settings-pane');
  if (pane && !pane._subRowsBound) {
    pane._subRowsBound = true;
    pane.addEventListener('click', (e) => {
      const btn = e.target.closest?.('[data-sub]');
      if (!btn || !pane.contains(btn)) return;
      if (e.target.closest('input, select, textarea, a')) return;
      const nowOpen = btn.getAttribute('aria-expanded') !== 'true';
      btn.setAttribute('aria-expanded', String(nowOpen));
      const body = btn.nextElementSibling;
      if (nowOpen && body) { try { playMenuIn(body); } catch { /* cosmetic */ } }
    });
  }
}

function updateAccSummaries() {
  try {
    const set = (key, text) => {
      const el = document.querySelector(`[data-acc-summary="${key}"]`);
      if (el) el.textContent = text;
    };
    const setSub = (key, text) => {
      const el = document.querySelector(`[data-sub-summary="${key}"]`);
      if (el) el.textContent = text;
    };
    const tpl = document.querySelector('input[name="template"]:checked')?.value;
    const tplLabel = { base: 'Minimalist', bauhaus: 'Modern', bauhaus_minimalist: 'Compact' }[tpl] || 'Minimalist';
    set('template', tplLabel);
    setSub('tpl-tema', tplLabel);
    const lang = $('#doc-lang-select')?.value;
    const langLabel = { auto: 'Automático', pt: 'Português', es: 'Español', en: 'English' }[lang] || 'Automático';
    set('lang', langLabel);
    setSub('tpl-idioma', langLabel);
    const chapters = $('#chapters-toc-checkbox')?.checked;
    const boxes = store.getBoxes();
    const active = boxes.filter((b) => !b.ignored && ((b.title || '').trim() || (b.markdown || '').trim())).length;
    set('documento', chapters ? `${active} capítulo${active === 1 ? '' : 's'}` : 'Sem sumário');
    setSub('doc-sumario', chapters ? `${active} capítulo${active === 1 ? '' : 's'}` : 'Off');
    const titlesOn = $('#doc-titles-enabled-checkbox')?.checked;
    setSub('doc-titulo', titlesOn ? 'On' : 'Off');
    const cols = document.querySelector('input[name="column-layout"]:checked')?.value;
    const align = document.querySelector('input[name="page-alignment"]:checked')?.value;
    const colsLabel = cols === '1' ? '1 coluna' : '2 colunas';
    const alignLabel = align === 'left' ? 'Esquerda' : align === 'right' ? 'Direita' : 'Justificado';
    set('tipografia', `${colsLabel} · ${alignLabel}`);
    setSub('tipo-colunas', colsLabel);
    setSub('tipo-alinha', alignLabel);
    const tbl = document.querySelector('input[name="table-layout-mode"]:checked')?.value;
    const tblLabel = { compact: 'Compacta', panoramic: 'Panorâmica', auto: 'Auto', rotated: 'Girada' }[tbl] || 'Auto';
    setSub('tipo-tabelas', tblLabel);
    const pos = document.querySelector('input[name="header-position"]:checked')?.value;
    set('cabecalho', pos === 'footer' ? 'No rodapé' : 'No topo');
    setSub('cab-texto', $('#custom-header-checkbox')?.checked ? 'Personalizado' : 'Padrão');
    const headerDate = $('#header-date-checkbox')?.checked;
    const dateFmt = $('#date-format-select')?.selectedOptions?.[0]?.textContent?.split(' (')[0]
      || $('#date-format-select')?.value || '';
    setSub('cab-data', headerDate ? (dateFmt || 'On') : 'Off');
  } catch { /* best effort */ }
}

/* Collapsible settings cards: legacy disclosure hook now delegates to the
   canonical accordion. Kept as a named gate for boot compatibility. */
function initDisclosures() {
  return;
}

/* Focus trap for bottom sheets and overlay drawers: Tab cycles inside the
 * open container, Esc layering is owned by the global keydown handler. */
function trapFocus(container, e) {
  if (!container || e.key !== 'Tab') return;
  const items = Array.from(container.querySelectorAll(
    'button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
  )).filter((el) => el.offsetParent !== null || el === document.activeElement);
  if (!items.length) { e.preventDefault(); return; }
  const first = items[0];
  const last = items[items.length - 1];
  if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
  else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
}

/* Docked accordion panel (desktop) vs bottom-sheet overlay (mobile <860px,
 * focus-trapped, Esc closes, scrim dismisses). */
function initDrawer() {
  const mq = window.matchMedia?.('(max-width: 860px)');
  const scrim = $('#drawer-scrim');
  const pane = $('#settings-pane');
  let lastFocus = null;
  const isOverlay = () => !!mq?.matches;
  const apply = (collapsed) => {
    const ws = $('.workspace');
    ws?.classList.toggle('settings-collapsed', collapsed);
    $('#toggle-settings-pane')?.setAttribute('aria-expanded', String(!collapsed));
    pane?.setAttribute('aria-hidden', String(collapsed && isOverlay()));
    scrim?.classList.toggle('hidden', collapsed || !isOverlay());
    if (!collapsed && isOverlay()) {
      lastFocus = document.activeElement;
      $('#close-settings-pane')?.focus();
    } else if (collapsed && lastFocus?.focus) {
      lastFocus.focus();
      lastFocus = null;
    }
  };
  const RAIL_KEY = 'doe-v2-rail-open';
  const railGet = () => { try { return typeof localStorage === 'undefined' ? null : localStorage.getItem(RAIL_KEY); } catch { return null; } };
  const railSet = (v) => { try { if (typeof localStorage !== 'undefined') localStorage.setItem(RAIL_KEY, v); } catch { /* ignore */ } };
  const applyAndPersist = (collapsed) => { apply(collapsed); railSet(collapsed ? '0' : '1'); };
  const toggle = () => applyAndPersist(!$('.workspace')?.classList.contains('settings-collapsed'));
  $('#toggle-settings-pane')?.addEventListener('click', toggle);
  $('#close-settings-pane')?.addEventListener('click', () => applyAndPersist(true));
  scrim?.addEventListener('click', () => applyAndPersist(true));
  pane?.addEventListener('keydown', (e) => {
    if (isOverlay() && !$('.workspace')?.classList.contains('settings-collapsed')) trapFocus(pane, e);
  });
  addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === '\\') { e.preventDefault(); toggle(); }
  });
  mq?.addEventListener?.('change', () => { if (isOverlay()) apply(true); });
  if (!isOverlay() && railGet() === '0') apply(true);
  else if (!isOverlay()) apply(false);
  else apply(true);
}

/* Mobile thumb-zone bar + secondary-action bottom-sheet.
   Moves existing nodes (no logic duplication); restores on close. */
function bindMobileBar() {
  const bar = $('#m-convert-btn')?.closest('.mobile-action-bar');
  const sheet = $('#sheet-more');
  const body = $('#sheet-body');
  if (!bar || !sheet || !body) return;
  const moved = [];
  const remember = (el) => {
    const anchor = document.createComment(`sheet-anchor:${el.id}`);
    el.before(anchor);
    moved.push({ el, anchor });
  };
  const restore = () => {
    while (moved.length) {
      const { el, anchor } = moved.pop();
      anchor.before(el);
      anchor.remove();
    }
  };
  let lastMoreFocus = null;
  const openSheet = () => {
    if (!moved.length) {
      ['clean-tags-btn', 'theme-toggle', 'add-box-btn', 'global-search-btn'].forEach((id) => {
        const el = document.getElementById(id);
        if (el && el.parentElement !== body) { remember(el); body.appendChild(el); }
      });
    }
    lastMoreFocus = document.activeElement;
    sheet.classList.remove('hidden');
    $('#sheet-close')?.focus();
  };
  const closeSheet = () => {
    sheet.classList.add('hidden');
    restore();
    if (lastMoreFocus?.focus) { lastMoreFocus.focus(); lastMoreFocus = null; }
  };
  const syncBusy = (src, dst) => {
    if (!src || !dst) return;
    dst.classList.toggle('is-busy', src.classList.contains('is-busy'));
    dst.disabled = src.disabled;
  };
  $('#m-convert-btn').addEventListener('click', () => $('#convert-btn').click());
  $('#m-preview-btn').addEventListener('click', () => $('#preview-btn').click());
  $('#m-more-btn').addEventListener('click', openSheet);
  $('#sheet-close').addEventListener('click', closeSheet);
  sheet.addEventListener('click', (e) => { if (e.target === sheet) closeSheet(); });
  sheet.addEventListener('keydown', (e) => { if (!sheet.classList.contains('hidden')) trapFocus(sheet, e); });
  new MutationObserver(() => {
    syncBusy($('#convert-btn'), $('#m-convert-btn'));
    syncBusy($('#preview-btn'), $('#m-preview-btn'));
  }).observe($('#convert-btn'), { attributes: true, attributeFilter: ['class', 'disabled'] });
}

/* ------------------------- convert / preview ---------------------- */
/* Busy spinner toggles the .is-busy class (stylesheet owns visibility):
   idle holds under any CSS cache staleness via .spinner{visibility:hidden}. */
async function withBusy(btn, fn) {
  btn.disabled = true;
  btn.classList.add('is-busy', 'busy-pulse');
  try { return await fn(); } finally {
    btn.disabled = false;
    btn.classList.remove('is-busy', 'busy-pulse');
  }
}

// D: re-entrant guard — Ctrl+Enter, preview-download and mobile-bar paths
// all funnel into doConvert outside withBusy's button disable, so a logic
// flag (not just UI state) guarantees 1 user action = 1 request max.
let convertBusy = false;
async function doConvert() {
  if (convertBusy) return;
  convertBusy = true;
  try {
    flushAdaptersToStore();
    const payload = ExportPayloadBuilder.build(store, { preview: false });
    if (!payload.sections.length) { showError('Nada para converter: blocos vazios ou ignorados.'); return; }
    // D: measure (do NOT strip — real pixels render server-side) + client
    // budget gate (see PreviewManager.open).
    const scan = stripPayloadImages(payload, { strip: false });
    const over = checkPayloadBudget(payload, scan);
    if (over) { showError(over); return; }
    const { blob, engineUsed, toc } = await ExportService.convert(payload);
    if (toc?.sections) {
      lastPaginationData = toc;
      scheduleTocPreview();
    }
    ExportService.download(blob, `document-${engineUsed}.pdf`);
  } finally {
    convertBusy = false;
  }
}

/* M2: persistence feedback + loss-window close. Wraps the store instance's
 * save() — the single choke point, so the store file stays DOM-free — to
 * tick the topbar pill, and flushes on pagehide so a fast tab close keeps
 * the last keystrokes instead of losing the 250ms debounce window. */
function updateSaveStatus() {
  const el = $('#save-status');
  if (!el) return;
  try {
    const t = new Date();
    const hh = String(t.getHours()).padStart(2, '0');
    const mm = String(t.getMinutes()).padStart(2, '0');
    el.textContent = `Salvo ${hh}:${mm}`;
  } catch { /* cosmetic */ }
}
function initSaveStatus() {
  try {
    const rawSave = store.save.bind(store);
    store.save = () => { rawSave(); updateSaveStatus(); };
  } catch { /* persistence stays silent */ }
  updateSaveStatus();
  window.addEventListener('pagehide', () => {
    try { flushAdaptersToStore(); store.save(); } catch { /* last-ditch */ }
  });
}

async function boot() {
  initTheme(); initSaveStatus(); initTopbarOverflow(); initTabs(); initDrawer(); initDisclosures(); bindGlobals(); bindMobileBar(); bindGlobalSearch();
  writeGlobalsToUI();
  try {
    const ws = document.querySelector('.workspace') || document.body;
    if (ws) initializeEditorialPagination(ws, store.getGlobals().template || 'base');
  } catch { /* headless fallback */ }
  renderBoxes();

  $('#add-box-btn').addEventListener('click', (e) => {
    if ($('#convert-btn').disabled || $('#preview-btn').disabled) return; // busy guard
    flushAdaptersToStore(); newCardId = store.addBox().id; renderBoxes();
  });
  $('#empty-add-btn')?.addEventListener('click', () => {
    flushAdaptersToStore(); newCardId = store.addBox().id; renderBoxes();
  });
  $('#convert-btn').addEventListener('click', () => withBusy($('#convert-btn'), doConvert).catch((e) => showError(errText(e, 'Falha inesperada'))));
  $('#preview-btn').addEventListener('click', () => withBusy($('#preview-btn'), () => PreviewManager.open(store, { full: false })).catch((e) => showError(errText(e, 'Falha inesperada'))));
  $('#clean-tags-btn').addEventListener('click', () => { try { cleanAllTags(); } catch (e) { showError(errText(e, 'Falha ao limpar tags')); } });
  $('#preview-toggle-full-btn').addEventListener('click', (e) => PreviewManager.open(store, { full: !PreviewManager.full }).catch((err) => showError(errText(err, 'Falha inesperada'))));
  $('#preview-download-btn').addEventListener('click', () => doConvert().catch((e) => showError(errText(e, 'Falha inesperada'))));  $('#preview-close-btn').addEventListener('click', () => PreviewManager.close());
  $('#preview-modal').addEventListener('click', (e) => { if (e.target.id === 'preview-modal') PreviewManager.close(); });

  $('#close-image-modal').addEventListener('click', closeImageModal);
  $('#cancel-image-btn').addEventListener('click', closeImageModal);
  $('#confirm-image-btn').addEventListener('click', confirmImage);
  ['img-source-input', 'img-caption-input'].forEach((id) => $(`#${id}`).addEventListener('input', updateImagePreview));
  $('#img-caption-toggle').addEventListener('change', updateImagePreview);
  $('#img-file-picker').addEventListener('change', async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    $('#img-preview-box').classList.remove('hidden');
    const tag = $('#img-preview-tag');
    try { if (tag.dataset.objectUrl) URL.revokeObjectURL(tag.dataset.objectUrl); } catch { /* ignore */ }
    const objUrl = URL.createObjectURL(f);
    tag.dataset.objectUrl = objUrl;
    tag.style.aspectRatio = '16 / 9';
    tag.src = objUrl;
    tag.onload = () => {
      try {
        const w = tag.naturalWidth || 0;
        const h = tag.naturalHeight || 0;
        if (w > 0 && h > 0) tag.style.aspectRatio = `${w} / ${h}`;
      } catch { /* keep fallback ratio */ }
    };
  });
  // Scale slider ↔ number input two-way sync (clamped 0.1–1.0).
  $('#img-scale-range')?.addEventListener('input', (e) => writeImageScale(e.target.value));
  $('#img-scale-input')?.addEventListener('input', (e) => writeImageScale(e.target.value));

  addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); doConvert().catch((err) => showError(errText(err, 'Falha inesperada'))); }
    // M5: document-wide find (Linear-style); per-card Ctrl+F rows untouched.
    if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey && (e.key === 'k' || e.key === 'K')) { e.preventDefault(); toggleGlobalSearch(); }
    // Unified Esc layering (F-G3): sheet > overlay drawer > preview > image modal.
    if (e.key === 'Escape') {
      const sheet = $('#sheet-more');
      if (sheet && !sheet.classList.contains('hidden')) { e.preventDefault(); $('#sheet-close')?.click(); return; }
      const paneOpen = !$('.workspace')?.classList.contains('settings-collapsed')
        && window.matchMedia?.('(max-width: 860px)').matches;
      if (paneOpen) { e.preventDefault(); $('#close-settings-pane')?.click(); return; }
      const previewOpen = !$('#preview-modal')?.classList.contains('hidden');
      if (previewOpen) { e.preventDefault(); PreviewManager.close(); return; }
      if (!$('#image-modal')?.classList.contains('hidden')) { e.preventDefault(); closeImageModal(); }
      if (!$('#gsearch-row')?.classList.contains('hidden')) { toggleGlobalSearch(false); }
    }
  });

  store.subscribe((evt, data) => {
    // Field edits (title, config, content) only touch the TOC preview.
    // Full card re-render is reserved for structural changes (add/remove/move/dup),
    // otherwise focus, editor state, and scroll position would be destroyed.
    if (evt === 'boxes' && data?.structural) renderBoxes();
  });
  schedulePaginate();
}

if (typeof document !== 'undefined') {
  document.addEventListener('DOMContentLoaded', () => boot().catch((e) => showError(errText(e, 'Falha ao iniciar'))));
}

// Test seam (D): pure helpers + service for node smoke tests. Ignored by
// the browser bundle (no importer). Keep this list side-effect free.
// DocumentStore/normalizeForEditor/ExportPayloadBuilder/TextareaAdapter are
// re-exported from ./document-store.js, ./export-payload.js and
// ./editor-adapters.js (CC1) — same names, same shape.
export {
  ExportService,
  ExportPayloadBuilder,
  DocumentStore,
  normalizeBox,
  TextareaAdapter,
  isEditorAdapter,
  stripPayloadImages,
  checkPayloadBudget,
  downscaleImageToDataUrl,
  blobToDataUrl,
  formatImageMarkdown,
  clampImageScale,
  readImageScale,
  writeImageScale,
  normalizeForEditor,
  BUDGET_MAX_SECTIONS,
  BUDGET_MAX_CHARS,
  BUDGET_MAX_IMAGE_BYTES,
  initializeEditorialPagination,
  normalizeEditorialGeometry,
  verifyTemplateEditorialGeometry,
};
