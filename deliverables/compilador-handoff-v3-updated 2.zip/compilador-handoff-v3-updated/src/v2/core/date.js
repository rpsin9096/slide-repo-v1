/**
 * Shared document-date formatter (single source of truth for V2 modular pipeline).
 */

/**
 * @param {object|null} dateOpts { enabled, format, custom_value }
 * @param {Date} [now=new Date()] current date (inject for determinism)
 * @returns {string|null} formatted date or null when disabled
 */
export function formatDocumentDate(dateOpts, now = new Date()) {
  if (dateOpts && dateOpts.enabled === false) return null;
  if (dateOpts && dateOpts.custom_value && typeof dateOpts.custom_value === 'string' && dateOpts.custom_value.trim()) {
    return dateOpts.custom_value.trim();
  }
  const d = now instanceof Date ? now : new Date(now);
  const format = (dateOpts && dateOpts.format) || 'dd_mm_yyyy';
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = String(d.getFullYear());

  const monthsPt = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro',
  ];
  const monthName = monthsPt[d.getMonth()];

  switch (format) {
    case 'dd_month_yyyy':
      return `${day} de ${monthName} de ${year}`;
    case 'month_yyyy':
      return `${monthName} de ${year}`;
    case 'yyyy_mm_dd':
      return `${year}-${month}-${day}`;
    case 'year':
      return year;
    case 'dd_mm_yyyy':
    default:
      return `${day}/${month}/${year}`;
  }
}
