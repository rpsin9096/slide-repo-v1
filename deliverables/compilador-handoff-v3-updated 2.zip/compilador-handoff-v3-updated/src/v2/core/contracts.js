/**
 * FocusGate / PDF Engine V2: Core Contracts & Invariants
 * Strict type guards and normalized builders ensuring modular intercommunication.
 */

export const VALID_TEMPLATES = ['base', 'bauhaus', 'bauhaus_minimalist'];
export const VALID_TABLE_LAYOUTS = [
  'compact',
  'panoramic',
  'auto',
  'rotated',
  'rotated_cw',
  'rotated_ccw',
  'rotated_d1',
  'rotated_d2',
];
export const VALID_COLUMN_LAYOUTS = [1, 2];
export const VALID_ALIGNMENTS = ['justify', 'left', 'right'];
export const VALID_LANGS = ['pt', 'es', 'en'];
const VALID_FLAG_KEYS = ['autofix', 'optimize_tables', 'split_equations', 'balance_columns'];

/**
 * Normalize a column layout selection to 1 or 2.
 * @param {number|string|null|undefined} value
 * @param {number|null} fallback returned when value is null/undefined/unknown
 * @returns {number|null}
 */
export function normalizeColumnLayout(value, fallback = 2) {
  if (value === 1 || value === '1') return 1;
  if (value === 2 || value === '2') return 2;
  return fallback;
}

/**
 * Validates a DocumentIR object strictly — the single validator for the
 * whole V2 pipeline (unified from ingest/schema.js: strictest coherent
 * union of both predecessors).
 * Zero external dependencies, fast (<0.1ms).
 * @param {any} doc
 * @returns {{ ok: boolean, errors: string[] }}
 */
export function validateDocIR(doc) {
  const errors = [];
  if (!doc || typeof doc !== 'object') {
    return { ok: false, errors: ['doc must be a non-null object'] };
  }

  if (typeof doc.title !== 'string' || !doc.title) {
    errors.push('doc.title must be a non-empty string');
  }

  if (!Array.isArray(doc.blocks) || doc.blocks.length === 0) {
    errors.push('doc.blocks must be a non-empty array');
  } else {
    doc.blocks.forEach((b, idx) => {
      if (!b || typeof b !== 'object') {
        errors.push(`doc.blocks[${idx}] must be an object`);
        return;
      }
      if (typeof b.title !== 'string') {
        errors.push(`doc.blocks[${idx}].title must be a string`);
      }
      if (typeof b.markdown !== 'string') {
        errors.push(`doc.blocks[${idx}].markdown must be a string`);
      }
      if (b.masthead !== undefined) {
        if (typeof b.masthead !== 'object' || b.masthead === null) {
          errors.push(`doc.blocks[${idx}].masthead must be an object`);
        } else {
          for (const k of Object.keys(b.masthead)) {
            if (!['course', 'topic', 'enabled', 'prefix', 'header'].includes(k)) {
              errors.push(`doc.blocks[${idx}].masthead.${k} unknown (want course|topic|enabled|prefix|header)`);
            }
          }
          if (b.masthead.course !== undefined && typeof b.masthead.course !== 'string') {
            errors.push(`doc.blocks[${idx}].masthead.course must be string`);
          }
          if (b.masthead.topic !== undefined && typeof b.masthead.topic !== 'string') {
            errors.push(`doc.blocks[${idx}].masthead.topic must be string`);
          }
          if (b.masthead.prefix !== undefined && typeof b.masthead.prefix !== 'string') {
            errors.push(`doc.blocks[${idx}].masthead.prefix must be string`);
          }
          if (b.masthead.header !== undefined && typeof b.masthead.header !== 'boolean') {
            errors.push(`doc.blocks[${idx}].masthead.header must be boolean`);
          }
          if (b.masthead.enabled !== undefined && typeof b.masthead.enabled !== 'boolean') {
            errors.push(`doc.blocks[${idx}].masthead.enabled must be boolean`);
          }
        }
      }
      if (b.columns !== undefined && b.columns !== null && !VALID_COLUMN_LAYOUTS.includes(b.columns)) {
        errors.push(`doc.blocks[${idx}].columns must be 1, 2, or null`);
      }
      if (b.flags !== undefined) {
        if (typeof b.flags !== 'object' || b.flags === null) {
          errors.push(`doc.blocks[${idx}].flags must be an object`);
        } else {
          for (const k of Object.keys(b.flags)) {
            if (!VALID_FLAG_KEYS.includes(k)) {
              errors.push(`doc.blocks[${idx}].flags.${k} unknown (want ${VALID_FLAG_KEYS.join('|')})`);
            } else if (typeof b.flags[k] !== 'boolean') {
              errors.push(`doc.blocks[${idx}].flags.${k} must be boolean`);
            }
          }
        }
      }
    });
  }

  if (doc.columnLayout !== undefined && !VALID_COLUMN_LAYOUTS.includes(doc.columnLayout)) {
    errors.push(`doc.columnLayout must be one of: ${VALID_COLUMN_LAYOUTS.join(', ')}`);
  }

  if (doc.template !== undefined && !VALID_TEMPLATES.includes(doc.template)) {
    errors.push(`doc.template must be one of: ${VALID_TEMPLATES.join(', ')}`);
  }

  if (doc.alignment !== undefined && !VALID_ALIGNMENTS.includes(doc.alignment)) {
    errors.push(`doc.alignment must be one of: ${VALID_ALIGNMENTS.join(', ')}`);
  }

  if (doc.lang !== undefined && !VALID_LANGS.includes(doc.lang)) {
    errors.push(`doc.lang must be one of: ${VALID_LANGS.join(', ')}`);
  }

  if (doc.headerFooter !== undefined && (typeof doc.headerFooter !== 'object' || doc.headerFooter === null)) {
    errors.push('doc.headerFooter must be an object');
  }

  if (doc.toc !== undefined && (typeof doc.toc !== 'object' || doc.toc === null)) {
    errors.push('doc.toc must be an object');
  }

  return { ok: errors.length === 0, errors };
}

/**
 * Normalize a table layout selection to the canonical 4-option matrix.
 * Legacy 'full_width' migrates to 'panoramic'; unknown values fall back.
 * @param {string|null|undefined} value
 * @param {string|null} fallback returned when value is null/undefined/unknown
 * @returns {string|null}
 */
export function normalizeTableLayout(value, fallback = 'auto') {
  if (value === 'full_width') return 'panoramic'; // legacy migration
  if (VALID_TABLE_LAYOUTS.includes(value)) return value;
  return fallback;
}

/**
 * Normalizes an arbitrary request payload into a canonical, immutable DocumentIR.
 * @param {object} payload 
 * @returns {object} Canonical DocumentIR
 */
export function normalizeToDocIR(payload = {}) {
  const {
    title,
    doc_title,
    sections,
    markdown,
    template,
    header_text,
    headerText,
    header_date,
    headerDate,
    show_header_top,
    header_position,
    alignment,
    raggedright,
    lang,
    toc,
    enable_toc,
    table_layout_mode,
    tableLayoutMode,
    column_layout,
    columnLayout,
    columns,
    loose_line_guard,
    balance_columns,
    balanceColumns,
    flush_columns,
    flushColumns,
  } = payload;

  const explicitTitle = typeof title === 'string'
    ? title.trim()
    : (title !== undefined ? title : (typeof doc_title === 'string' ? doc_title.trim() : (doc_title !== undefined ? doc_title : '')));
  let mastheadTitle = '';
  const incomingBlocks = (Array.isArray(payload.blocks) && payload.blocks.length > 0)
    ? payload.blocks
    : (Array.isArray(sections) && sections.length > 0 ? sections : null);

  if (incomingBlocks && incomingBlocks.length > 0) {
    const firstBlock = incomingBlocks[0];
    const isFirstMhOn = firstBlock && (
      firstBlock.masthead?.enabled === true ||
      firstBlock.enable_masthead === true ||
      firstBlock.masthead_enabled === true ||
      (firstBlock.masthead && firstBlock.masthead.enabled !== false && (firstBlock.masthead.course || firstBlock.masthead.topic)) ||
      (firstBlock.enable_masthead !== false && firstBlock.masthead_enabled !== false && (firstBlock.masthead_course || firstBlock.masthead_topic))
    );

    if (isFirstMhOn) {
      const firstMh = incomingBlocks.find(s => s &&
        (s.masthead?.enabled !== false && s.enable_masthead !== false && s.masthead_enabled !== false) &&
        (s.masthead?.course || s.masthead_course || s.masthead?.topic || s.masthead_topic)
      );
      if (firstMh) {
        mastheadTitle = (firstMh.masthead?.course || firstMh.masthead_course || firstMh.masthead?.topic || firstMh.masthead_topic || '');
        if (typeof mastheadTitle === 'string') mastheadTitle = mastheadTitle.trim();
      }
    }
  }

  let resolvedTitle;
  if (typeof explicitTitle !== 'string' && explicitTitle !== undefined) {
    resolvedTitle = explicitTitle;
  } else {
    resolvedTitle = (explicitTitle && explicitTitle !== 'Document')
      ? explicitTitle
      : (mastheadTitle || (explicitTitle === 'Document' ? 'Document' : '') || 'Document');
  }
  const resolvedTemplate = template || 'base';

  let resolvedAlignment = alignment;
  if (!resolvedAlignment) {
    resolvedAlignment = raggedright ? 'left' : 'justify';
  }

  let blocks = [];
  // Column-break opt-in ("Quebrar colunas para acomodar"): the document-level
  // control is each block's default, a section's own value wins, and absent on
  // both leaves the engine's continuous default (coluna corrida). The layout
  // engine reads the decision per block, so without this hop the document
  // toggle would never reach it.
  const docBalanceColumns = balance_columns ?? balanceColumns ?? null;
  const balanceFlag = (v) => (v == null ? {} : { balance_columns: v !== false });

  if (incomingBlocks) {
    blocks = incomingBlocks
      .filter(s => s && ((typeof s.markdown === 'string' && s.markdown.trim().length > 0) || s.title))
      .map(s => {
        const rawLayout = s.table_layout ?? s.tableLayout ?? s.table_layout_mode ?? s.tableLayoutMode ?? null;
        const rawRotDir = s.table_rotation_direction ?? s.tableRotationDirection ?? null;
        let normalizedBlockTableLayout = normalizeTableLayout(rawLayout, null);
        if (normalizedBlockTableLayout === 'rotated' && rawRotDir) {
          normalizedBlockTableLayout = rawRotDir === 'ccw' ? 'rotated_ccw' : 'rotated_cw';
        }
        const rawColumns = s.columns ?? s.column_layout ?? s.columnLayout ?? null;
        return {
          title: s.title || s.name || '',
          markdown: s.markdown || '',
          masthead: {
            enabled: s.masthead?.enabled !== false && (s.enable_masthead !== false && !!(s.masthead_course || s.masthead_topic || s.masthead?.course || s.masthead?.topic)),
            course: s.masthead?.course || s.masthead_course || '',
            topic: s.masthead?.topic || s.masthead_topic || '',
            prefix: s.masthead?.prefix ?? s.masthead_prefix ?? '',
            header: s.masthead?.header === true || s.masthead_header === true,
          },
          flags: {
            autofix: s.flags?.autofix !== false && s.autofix !== false,
            optimize_tables: s.flags?.optimize_tables !== false && s.optimize_tables !== false,
            split_equations: s.flags?.split_equations !== false && s.split_equations !== false,
            ...balanceFlag(s.flags?.balance_columns ?? s.balance_columns ?? docBalanceColumns),
          },
          // Per-block table layout override (null = inherit document default).
          tableLayout: normalizedBlockTableLayout,
          tableRotationDirection: rawRotDir || (normalizedBlockTableLayout === 'rotated_ccw' ? 'ccw' : 'cw'),
          // Per-block column layout override (null = inherit document default).
          columns: normalizeColumnLayout(rawColumns, null),
        };
      });
  } else if (typeof markdown === 'string') {
    blocks = [{
      title: '',
      markdown,
      masthead: { enabled: false, course: '', topic: '', prefix: '', header: false },
      flags: { autofix: true, optimize_tables: true, split_equations: true, ...balanceFlag(docBalanceColumns) },
      columns: null,
    }];
  }

  const rawDocTableMode = tableLayoutMode ?? table_layout_mode ?? payload.table_layout ?? payload.tableLayout;
  let normalizedDocTableMode = normalizeTableLayout(rawDocTableMode, 'auto');
  const docRotDir = payload.table_rotation_direction ?? payload.tableRotationDirection ?? null;
  if (normalizedDocTableMode === 'rotated' && docRotDir) {
    normalizedDocTableMode = docRotDir === 'ccw' ? 'rotated_ccw' : 'rotated_cw';
  }

  return {
    title: resolvedTitle,
    template: resolvedTemplate,
    blocks,
    headerText: headerText || header_text || '',
    headerDate: headerDate || header_date || null,
    headerOnTop: show_header_top !== false && header_position !== 'footer',
    footerText: (doc_title && doc_title !== 'Document') ? doc_title : ((title && title !== 'Document') ? title : (resolvedTitle !== 'Document' ? resolvedTitle : '')),
    alignment: resolvedAlignment,
    lang: VALID_LANGS.includes(lang) ? lang : 'pt',
    toc: enable_toc !== false ? (toc || { enabled: false }) : { enabled: false },
    tableLayoutMode: normalizedDocTableMode,
    tableRotationDirection: docRotDir || (normalizedDocTableMode === 'rotated_ccw' ? 'ccw' : 'cw'),
    columnLayout: normalizeColumnLayout(columnLayout ?? column_layout ?? columns, 2),
    looseLineGuard: loose_line_guard !== false,
    // Flush-bottom control ("Encaixar pé da página"): on by default; off leaves
    // page feet honestly ragged (the 3b pass skips every page with reason
    // 'flush-off'). Snake-first, DocIR-camel — same convention as the rest.
    flushColumns: (flush_columns ?? flushColumns) !== false,
    ast: payload.ast || null,
  };
}

/**
 * Asserts that an element conforms to the LayoutBox interface.
 * @param {object} box 
 */
export function assertLayoutBox(box) {
  if (!box || typeof box !== 'object') {
    throw new TypeError('LayoutBox must be an object');
  }
  if (typeof box.kind !== 'string') {
    throw new TypeError('LayoutBox.kind must be a string');
  }
  if (typeof box.height !== 'number' || Number.isNaN(box.height)) {
    throw new TypeError('LayoutBox.height must be a valid number');
  }
}
