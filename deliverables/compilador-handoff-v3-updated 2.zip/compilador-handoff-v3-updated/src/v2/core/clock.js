/**
 * ClockPort — injectable time source for the pipeline.
 *
 * Library code must never call `new Date()` directly: output dates would
 * depend on the wall clock, breaking deterministic tests and the parity
 * harness. Accept a clock (default: system clock), call `clock.now()`.
 */

export function createClock({ now } = {}) {
  const nowFn = typeof now === 'function' ? now : () => new Date();
  return Object.freeze({ now: () => nowFn() });
}

/** Default live clock. Stateless (delegates to Date per call). */
export const systemClock = createClock();

/** Fixed clock for tests and the parity harness. */
export function fixedClock(isoString) {
  const at = new Date(isoString);
  return createClock({ now: () => new Date(at) });
}
