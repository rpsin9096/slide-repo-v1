/**
 * FocusGate / PDF Engine V2: DisplayList IR Seam
 *
 * Single public seam between layout (GeometryCompiler) and drivers
 * (PDFKit blaster, Typst emitter). Port of reference-11
 * `core/display-list.ts` + `drivers/pdfkit-driver.ts:239-247`.
 *
 * Invariants:
 * - Driver may consume ONLY this IR. Never EditorialAST / DocumentIR
 *   (`blocks[].markdown`), never layout closures (`paint`, `measure`).
 * - IR is immutable after `freezeIR()` (deep-freeze). Mutation throws
 *   instead of silently corrupting bytes.
 * - Coordinates are verbatim. Driver performs zero measuring,
 *   zero line-breaking, zero re-layout.
 */

import { DriverError } from '../drivers/interface.js';

export const IR_VERSION = '2.1.0';

/**
 * Returns true when value looks like a compiled DisplayList.
 * @param {any} ir
 * @returns {boolean}
 */
export function isDisplayList(ir) {
  return !!ir
    && typeof ir === 'object'
    && Array.isArray(ir.pages)
    && typeof ir.totalPages === 'number';
}

function deepFreeze(value) {
  if (!value || typeof value !== 'object' || Object.isFrozen(value)) return value;
  // Never freeze binary views/buffers: V8 throws
  // "Cannot freeze array buffer views with elements" on
  // Object.freeze(Buffer/TypedArray) with elements.
  if (typeof ArrayBuffer !== 'undefined') {
    if (ArrayBuffer.isView(value)) return value;
    if (value instanceof ArrayBuffer) return value;
  }
  if (typeof SharedArrayBuffer !== 'undefined' && value instanceof SharedArrayBuffer) return value;
  Object.freeze(value);
  if (Array.isArray(value)) {
    for (let i = 0; i < value.length; i++) {
      const item = value[i];
      if (item && typeof item === 'object') deepFreeze(item);
    }
  } else {
    for (const key in value) {
      if (Object.prototype.hasOwnProperty.call(value, key)) {
        const child = value[key];
        if (child && typeof child === 'object') deepFreeze(child);
      }
    }
  }
  return value;
}

/**
 * Freezes a compiled DisplayList in place and stamps version metadata.
 * Idempotent: already-frozen IR passes through untouched.
 * @param {object} displayList
 * @returns {object} Same reference, frozen.
 */
export function freezeIR(displayList) {
  if (!displayList || typeof displayList !== 'object') {
    throw new TypeError('freezeIR: displayList must be an object');
  }
  if (Object.isFrozen(displayList) && displayList.irVersion) return displayList;
  if (!displayList.irVersion) {
    try {
      displayList.irVersion = IR_VERSION;
    } catch { /* frozen by caller — keep existing */ }
  }
  return deepFreeze(displayList);
}

/**
 * Rejects anything that is not a pure DisplayList.
 * Catches the exact leak v2 has today: driver receiving `blocks`/`markdown`
 * or live `measure`/`paint` closures smuggled through compile options.
 * @param {any} ir
 * @param {string} [driverName='driver']
 */
export function assertDriverPurity(ir, driverName = 'driver') {
  const fail = (code, detail) => {
    throw new DriverError(`${code}: ${detail}`, driverName);
  };
  if (!ir || typeof ir !== 'object') fail('IR_REJECTED', 'expected DisplayList object');
  if (Array.isArray(ir.blocks) || typeof ir.markdown === 'string') {
    fail('AST_LEAK', 'driver received EditorialAST/DocumentIR (blocks/markdown); pass compiled DisplayList instead');
  }
  if (!Array.isArray(ir.pages)) fail('IR_REJECTED', 'DisplayList.pages must be an array');
  for (let p = 0; p < ir.pages.length; p++) {
    const page = ir.pages[p];
    if (!page || !Array.isArray(page.elements)) {
      fail('IR_REJECTED', `pages[${p}].elements must be an array`);
    }
    for (let e = 0; e < page.elements.length; e++) {
      const el = page.elements[e];
      if (!el || typeof el !== 'object') fail('IR_REJECTED', `pages[${p}].elements[${e}] must be an object`);
      if (typeof el.paint === 'function' || typeof el.measure === 'function') {
        fail('CLOSURE_LEAK', `pages[${p}].elements[${e}] carries live layout closure; drivers must not measure`);
      }
      if (typeof el.type !== 'string') fail('IR_REJECTED', `pages[${p}].elements[${e}].type must be a string`);
    }
  }
  return true;
}

/**
 * Counts DisplayList commands by element type for diagnostics/tests.
 * @param {object} ir
 * @returns {{ total: number, byType: Record<string, number> }}
 */
const COMMAND_COUNT_CACHE = new WeakMap();

export function countCommands(ir) {
  if (!ir || !Array.isArray(ir.pages)) return { total: 0, byType: {} };
  const isFrozen = Object.isFrozen(ir);
  if (isFrozen) {
    const cached = COMMAND_COUNT_CACHE.get(ir);
    if (cached !== undefined) return cached;
  }
  const byType = {};
  let total = 0;
  for (let p = 0; p < ir.pages.length; p++) {
    const page = ir.pages[p];
    if (!page || !Array.isArray(page.elements)) continue;
    const els = page.elements;
    for (let e = 0; e < els.length; e++) {
      const el = els[e];
      const t = (el && el.type) || 'unknown';
      byType[t] = (byType[t] || 0) + 1;
      total++;
    }
  }
  const res = { total, byType };
  if (isFrozen) COMMAND_COUNT_CACHE.set(ir, res);
  return res;
}
