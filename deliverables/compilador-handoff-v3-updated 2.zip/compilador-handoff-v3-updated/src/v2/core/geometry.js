/**
 * FocusGate / PDF Engine V2: Deterministic Geometry Primitives
 * 
 * Clean, plain JSON-serializable geometric primitives.
 * Implements deterministic quantization q(val, precision) to eliminate
 * IEEE 754 -0 and floating-point precision dust for cross-platform SHA256 reproducibility.
 */

/**
 * Deterministic rounding — eliminates -0 and float dust in emitted geometry.
 * @param {number} value
 * @param {number} [precision=4]
 * @returns {number}
 */
export function q(value, precision = 4) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return 0;
  const factor = 10 ** precision;
  const rounded = Math.round(value * factor) / factor;
  return Object.is(rounded, -0) ? 0 : rounded;
}

/**
 * Creates a rectangle bounding box.
 * @param {number} x
 * @param {number} y
 * @param {number} width
 * @param {number} height
 * @returns {{ x: number, y: number, width: number, height: number }}
 */
export function rect(x, y, width, height) {
  const qW = q(width);
  const qH = q(height);
  return {
    x: q(x),
    y: q(y),
    width: qW,
    height: qH,
    w: qW,
    h: qH,
  };
}

export const PAGE_SIZES = Object.freeze({
  A3: { width: 841.89, height: 1190.55 },
  A4: { width: 595.28, height: 841.89 },
  A5: { width: 419.53, height: 595.28 },
  LETTER: { width: 612.0, height: 792.0 },
  LEGAL: { width: 612.0, height: 1008.0 },
  TABLOID: { width: 792.0, height: 1224.0 },
});
