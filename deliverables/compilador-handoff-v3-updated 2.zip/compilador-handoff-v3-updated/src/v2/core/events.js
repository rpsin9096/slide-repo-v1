/**
 * FocusGate / PDF Engine V2: Decoupled Event Bus
 * Zero external dependencies. Provides synchronous and asynchronous lifecycle hooks
 * for telemetry, performance auditing, and pipeline coordination.
 */

export class EngineEventBus {
  constructor(options = {}) {
    this._listeners = new Map();
    this._startAt = Date.now();
    this._trackMemory = Boolean(options && options.trackMemory);
    this._lastHeap = this._trackMemory && typeof process !== 'undefined' && typeof process.memoryUsage === 'function'
      ? process.memoryUsage().heapUsed
      : 0;
  }

  /**
   * Subscribe a listener to an event.
   * @param {string} event 
   * @param {Function} handler 
   * @returns {() => void} Unsubscribe function
   */
  on(event, handler) {
    if (!this._listeners.has(event)) {
      this._listeners.set(event, new Set());
    }
    this._listeners.get(event).add(handler);
    return () => this.off(event, handler);
  }

  /**
   * Subscribe a listener to fire only once.
   * @param {string} event 
   * @param {Function} handler 
   */
  once(event, handler) {
    const wrapper = (...args) => {
      this.off(event, wrapper);
      return handler(...args);
    };
    return this.on(event, wrapper);
  }

  /**
   * Unsubscribe a listener.
   * @param {string} event 
   * @param {Function} handler 
   */
  off(event, handler) {
    const handlers = this._listeners.get(event);
    if (handlers) {
      handlers.delete(handler);
      if (handlers.size === 0) {
        this._listeners.delete(event);
      }
    }
  }

  /**
   * Emit an event synchronously with telemetry enrichment.
   * @param {string} event 
   * @param  {...any} args 
   */
  emit(event, ...args) {
    const handlers = this._listeners.get(event);
    const hasHandlers = Boolean(handlers && handlers.size > 0);
    if (args.length > 0 && args[0] && typeof args[0] === 'object' && !Array.isArray(args[0])) {
      if (this._trackMemory && typeof process !== 'undefined' && typeof process.memoryUsage === 'function') {
        const currentHeap = process.memoryUsage().heapUsed;
        args[0].memoryDeltaBytes = currentHeap - this._lastHeap;
        this._lastHeap = currentHeap;
      } else if (args[0].memoryDeltaBytes === undefined) {
        args[0].memoryDeltaBytes = 0;
      }
      if (args[0].atMs === undefined) {
        args[0].atMs = Date.now() - this._startAt;
      }
    }

    if (!hasHandlers) return false;
    for (const handler of Array.from(handlers)) {
      try {
        handler(...args);
      } catch (err) {
        if (event !== 'error') {
          this.emit('error', err);
        } else {
          throw err;
        }
      }
    }
    return true;
  }

  /**
   * Emit an event asynchronously, awaiting handlers.
   * @param {string} event 
   * @param  {...any} args 
   */
  async emitAsync(event, ...args) {
    const handlers = this._listeners.get(event);
    if (!handlers || handlers.size === 0) return false;
    for (const handler of Array.from(handlers)) {
      try {
        await handler(...args);
      } catch (err) {
        if (event !== 'error') {
          await this.emitAsync('error', err);
        } else {
          throw err;
        }
      }
    }
    return true;
  }

  /**
   * Remove all listeners.
   */
  clear() {
    this._listeners.clear();
  }
}

export function createEngineEventBus(options = {}) {
  return new EngineEventBus(options);
}
