/**
 * FocusGate / PDF Engine V2: Centralized Semantic Design Tokens
 * 
 * Single source of truth for color roles, typographical scale, stroke widths,
 * and point-based spatial rhythm across the V2 modular compiler.
 */

export const V2_COLOR_TOKENS = Object.freeze({
  textMain: '#111827',
  textMuted: '#4B5563',
  textGray: '#6B7280',
  accent: '#2563EB',
  accentMuted: '#0F766E',
  surface: '#F9FAFB',
  surfaceMuted: '#F8FAFC',
  border: '#E5E7EB',
  borderMuted: '#E2E8F0',
  ruleBlack: '#111827',
  ruleGray: '#9CA3AF',
  columnSepRule: '#E5E7EB',
  headerLine: '#E5E7EB',
  white: '#FFFFFF',
});

export const V2_SPACING_TOKENS = Object.freeze({
  micro: 1.5,
  xs: 4.0,
  sm: 6.0,
  md: 8.0,
  lg: 12.0,
  xl: 16.0,
  gutter: 14.17,
});

export const V2_STROKE_TOKENS = Object.freeze({
  hairline: 0.25,
  light: 0.35,
  standard: 0.40,
  heavy: 0.70,
  accentWest: 2.0,
  pillWest: 2.5,
});

export const V2_TYPE_SCALE = Object.freeze({
  caption: 6.5,
  footnote: 8.0,
  body: 9.5,
  subheading: 11.0,
  heading: 13.0,
  title: 16.0,
  lineHeightMultiplierBase: 1.1499,
  lineHeightMultiplierCompact: 1.20996,
});

/**
 * Resolves a semantic color token from active template definition,
 * falling back to the centralized semantic design tokens.
 * @param {object} tmpl - Active template definition
 * @param {string} tokenKey - Key in tmpl.colors or V2_COLOR_TOKENS
 * @returns {string} Hex color string
 */
export function resolveColor(tmpl, tokenKey) {
  if (tmpl && tmpl.colors) {
    if (tmpl.colors[tokenKey]) return tmpl.colors[tokenKey];
    const lowerKey = tokenKey.toLowerCase();
    if (tmpl.colors[lowerKey]) return tmpl.colors[lowerKey];
  }
  return V2_COLOR_TOKENS[tokenKey] || V2_COLOR_TOKENS.textMain;
}
