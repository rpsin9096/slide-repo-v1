/**
 * FocusGate / PDF Engine V2: Canonical Semantic AST Schema & Node Factories
 * Zero geometric awareness. Defines semantic editorial nodes and inline runs.
 */

export const INLINE_RUN_KINDS = ['text', 'math', 'footnoteRef', 'xref'];
export const BLOCK_NODE_TYPES = [
  'heading',
  'paragraph',
  'table',
  'mathBlock',
  'figure',
  'callout',
  'rule',
  'pageBreak',
];

export function slugify(text, fallback = 'section') {
  const s = String(text || '')
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 64);
  return s.length > 0 ? s : fallback;
}

let nodeCounter = 0;
export function stableId(prefix = 'node', ordinal = null) {
  const ord = ordinal !== null ? ordinal : ++nodeCounter;
  return `${prefix}-${ord.toString(36).padStart(4, '0')}`;
}

export function createTextRun(text, marks = {}, href = null) {
  return {
    kind: 'text',
    text: String(text || ''),
    marks: {
      bold: Boolean(marks.bold),
      italic: Boolean(marks.italic),
      code: Boolean(marks.code),
      underline: Boolean(marks.underline),
      strike: Boolean(marks.strike),
    },
    ...(href ? { href: String(href) } : {}),
  };
}

export function createMathRun(latex, display = false) {
  return {
    kind: 'math',
    latex: String(latex || ''),
    display: Boolean(display),
  };
}

export function createHeadingNode(level, runs, options = {}) {
  const titleText = runsToPlainText(runs);
  return {
    type: 'heading',
    id: options.id || stableId('h'),
    level: Math.min(Math.max(Number(level) || 1, 1), 6),
    slug: options.slug || slugify(titleText, 'heading'),
    runs: Array.isArray(runs) ? runs : [createTextRun(titleText)],
    keepWithNextBudget: options.keepWithNextBudget !== undefined ? options.keepWithNextBudget : 3,
    numbered: Boolean(options.numbered),
  };
}

export function createParagraphNode(runs, options = {}) {
  return {
    type: 'paragraph',
    id: options.id || stableId('p'),
    runs: Array.isArray(runs) ? runs : [createTextRun(runs)],
    indentRule: options.indentRule || 'auto',
    marker: options.marker || undefined,
    depth: options.depth || 0,
    role: options.role || 'body', // 'body' | 'lead' | 'quote' | 'listItem' | 'caption'
  };
}

export function createTableNode(headers, rows, options = {}) {
  return {
    type: 'table',
    id: options.id || stableId('tbl'),
    slug: options.slug || stableId('tbl-slug'),
    headers: headers || [],
    rows: rows || [],
    alignments: options.alignments || [],
    columnWidthPreferences: options.columnWidthPreferences || [],
    caption: options.caption || [],
    repeatHeader: options.repeatHeader !== false,
    fullWidth: Boolean(options.fullWidth),
    repairs: Number(options.repairs) || 0,
  };
}

export function createMathBlockNode(latex, options = {}) {
  return {
    type: 'mathBlock',
    id: options.id || stableId('math'),
    slug: options.slug || stableId('math-slug'),
    latex: String(latex || ''),
    numbered: options.numbered !== false,
  };
}

export function createFigureNode(assetRef, options = {}) {
  return {
    type: 'figure',
    id: options.id || stableId('fig'),
    slug: options.slug || stableId('fig-slug'),
    assetRef: String(assetRef || ''),
    caption: options.caption || [],
    placementPreference: options.placementPreference || 'column', // 'column' | 'full-width' | 'inline' | 'page-top'
    widthRatio: options.widthRatio || 1,
    aspectRatio: options.aspectRatio || 1.5,
    altText: options.altText || '',
  };
}

export function createCalloutBoxNode(content, options = {}) {
  return {
    type: 'callout',
    id: options.id || stableId('callout'),
    accentStyle: options.accentStyle || 'info', // 'info' | 'warning' | 'danger' | 'success' | 'neutral' | 'code'
    title: options.title || '',
    content: Array.isArray(content) ? content : [],
    fullWidth: Boolean(options.fullWidth),
  };
}

export function createRuleNode(options = {}) {
  return {
    type: 'rule',
    id: options.id || stableId('rule'),
  };
}

export function createPageBreakNode(options = {}) {
  return {
    type: 'pageBreak',
    id: options.id || stableId('pb'),
  };
}

export function runsToPlainText(runs = []) {
  if (!Array.isArray(runs)) return String(runs || '');
  return runs
    .map(r => {
      if (!r) return '';
      if (r.kind === 'text') return r.text;
      if (r.kind === 'math') return r.latex;
      if (r.kind === 'footnoteRef') return `[${r.id}]`;
      if (r.kind === 'xref') return r.label;
      return '';
    })
    .join('');
}

export function validateAST(ast) {
  if (!ast || typeof ast !== 'object') {
    return { ok: false, errors: ['AST must be an object'] };
  }
  if (!Array.isArray(ast.blocks)) {
    return { ok: false, errors: ['AST.blocks must be an array'] };
  }
  const errors = [];
  const seenIds = new Set();
  ast.blocks.forEach((b, idx) => {
    if (!b || !BLOCK_NODE_TYPES.includes(b.type)) {
      errors.push(`Block at index ${idx} has invalid type: ${b?.type}`);
      return;
    }
    if (typeof b.id !== 'string' || !b.id) {
      errors.push(`Block at index ${idx} (${b.type}) missing id`);
    } else if (seenIds.has(b.id)) {
      errors.push(`Block at index ${idx} duplicate id: ${b.id}`);
    } else {
      seenIds.add(b.id);
    }
    if (b.type === 'heading') {
      if (!Number.isInteger(b.level) || b.level < 1 || b.level > 6) {
        errors.push(`Heading at index ${idx} has invalid level: ${b.level}`);
      }
      if (!Array.isArray(b.runs) || b.runs.length === 0) {
        errors.push(`Heading at index ${idx} must carry non-empty runs`);
      }
      if (b.keepWithNextBudget !== undefined
        && (!Number.isInteger(b.keepWithNextBudget) || b.keepWithNextBudget < 0 || b.keepWithNextBudget > 8)) {
        errors.push(`Heading at index ${idx} keepWithNextBudget out of range 0-8`);
      }
      if (typeof b.slug !== 'string' || !b.slug) {
        errors.push(`Heading at index ${idx} missing slug`);
      }
    }
    if (b.type === 'paragraph' && !Array.isArray(b.runs)) {
      errors.push(`Paragraph at index ${idx} must carry runs array`);
    }
    if (b.type === 'table') {
      // Shape: headers = [headerRow], rows = [row...], each row = [cellRuns...].
      const headerRows = Array.isArray(b.headers) ? b.headers : [];
      const bodyRows = Array.isArray(b.rows) ? b.rows : [];
      const headerCols = headerRows.length > 0 && Array.isArray(headerRows[0])
        ? headerRows[0].length
        : headerRows.length;
      if (headerCols === 0 && bodyRows.length === 0) {
        errors.push(`Table at index ${idx} has no columns`);
      }
      const ncols = Math.max(headerCols, ...bodyRows.map(r => (Array.isArray(r) ? r.length : 0)), 0);
      headerRows.forEach((row, rIdx) => {
        if (!Array.isArray(row) || row.length !== ncols) {
          errors.push(`Table at index ${idx} header ${rIdx} ragged: got ${row?.length}, want ${ncols}`);
        }
      });
      bodyRows.forEach((row, rIdx) => {
        if (!Array.isArray(row) || row.length !== ncols) {
          errors.push(`Table at index ${idx} row ${rIdx} ragged: got ${row?.length}, want ${ncols}`);
        }
      });
      if (Array.isArray(b.alignments) && b.alignments.length > 0 && b.alignments.length !== ncols) {
        errors.push(`Table at index ${idx} alignments length ${b.alignments.length} != ${ncols}`);
      }
    }
  });
  return { ok: errors.length === 0, errors };
}

/**
 * Normalizes parsed blocks: drops empty body paragraphs, dedupes slugs.
 * Pure + deterministic (ref-11 ingest/index.ts:74-93).
 * @param {object[]} blocks
 * @returns {{ blocks: object[], dropped: number, deduped: number }}
 */
export function normalizeBlocks(blocks = []) {
  const seenSlugs = new Map();
  const out = [];
  let dropped = 0;
  let deduped = 0;
  for (const b of blocks) {
    if (!b || typeof b !== 'object') { dropped++; continue; }
    if (b.type === 'paragraph' && Array.isArray(b.runs)) {
      const text = runsToPlainText(b.runs).trim();
      const role = b.role || 'body';
      if (!text && (role === 'body' || role === 'lead')) { dropped++; continue; }
    }
    if (typeof b.slug === 'string' && b.slug) {
      const base = b.slug;
      const count = seenSlugs.get(base) || 0;
      if (count > 0) {
        b.slug = `${base}-${count + 1}`;
        deduped++;
      }
      seenSlugs.set(base, count + 1);
    }
    out.push(b);
  }
  return { blocks: out, dropped, deduped };
}
