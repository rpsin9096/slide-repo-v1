/**
 * FocusGate / PDF Engine V2: Markdown Ingestion Inverse Serializer
 * Exact inverse of parseMarkdownToAST (ref-11 ingest/serialize.ts:14-128).
 * Enables Markdown<->AST roundtrip proof: parse(serialize(parse(md)))
 * must validate with zero node loss.
 *
 * CONTRACT (ADR-PROD-0003, verified 2026-09-22): roundtrip is lossless over
 * the ingest-produced subset — block type sequence, table alignments, inline
 * marks (bold/italic/code/strike/link/math), headings, lists, quotes, figures,
 * callouts, rules. Programmatic NON-DEFAULT AST fields are NOT serialized
 * (table caption/repeatHeader=false/fullWidth=true, figure
 * placementPreference/widthRatio/aspectRatio≠defaults, heading
 * keepWithNextBudget≠3/numbered=true, callout fullWidth) because pipe-markdown
 * ingest never produces them. See verify-suite roundtrip-types/aligns gates.
 */
import { runsToPlainText } from '../core/ast-schema.js';

function escapeCell(text) {
  return String(text || '').replace(/\\/g, '\\\\').replace(/\|/g, '\\|').replace(/\n/g, '<br>');
}

export function serializeRuns(runs = []) {
  if (!Array.isArray(runs)) return String(runs || '');
  return runs.map((r) => {
    if (!r) return '';
    if (r.kind === 'math') return `$${r.latex}$`;
    if (r.kind === 'footnoteRef') return `[^${r.id}]`;
    if (r.kind === 'xref') return r.label || '';
    const text = r.text || '';
    const m = r.marks || {};
    if (m.code) return `\`${text}\``;
    if (m.bold && m.italic) return `***${text}***`;
    if (m.bold) return `**${text}**`;
    if (m.italic) return `*${text}*`;
    if (m.strike) return `~~${text}~~`;
    return r.href ? `[${text}](${r.href})` : text;
  }).join('');
}

function cellToText(cell) {
  if (Array.isArray(cell)) return serializeRuns(cell);
  if (cell && Array.isArray(cell.runs)) return serializeRuns(cell.runs);
  if (typeof cell === 'string') return cell;
  if (cell && typeof cell.text === 'string') return cell.text;
  return runsToPlainText(cell);
}

export function serializeBlock(block) {
  if (!block || typeof block !== 'object') return '';
  switch (block.type) {
    case 'heading': {
      const level = Math.min(Math.max(block.level || 1, 1), 6);
      return `${'#'.repeat(level)} ${serializeRuns(block.runs)}`;
    }
    case 'paragraph': {
      const prefix = block.role === 'quote' ? '> '
        : block.role === 'listItem' ? `${'  '.repeat(block.depth || 0)}${block.marker || '-'} ` : '';
      return `${prefix}${serializeRuns(block.runs)}`;
    }
    case 'table': {
      const headerRows = Array.isArray(block.headers) ? block.headers : [];
      const head = Array.isArray(headerRows[0]) ? headerRows[0] : headerRows;
      const aligns = Array.isArray(block.alignments) ? block.alignments : [];
      const ncols = Math.max(head.length, ...(block.rows || []).map(r => r.length));
      const alignCell = (a) => (a === 'center' ? ':---:' : a === 'right' ? '---:' : '---');
      const lines = [];
      lines.push(`| ${head.map(cellToText).map(escapeCell).join(' | ')} |`);
      lines.push(`| ${Array.from({ length: ncols }, (_, i) => alignCell(aligns[i])).join(' | ')} |`);
      for (const row of block.rows || []) {
        lines.push(`| ${row.map(cellToText).map(escapeCell).join(' | ')} |`);
      }
      return lines.join('\n');
    }
    case 'mathBlock':
      return `$$${block.latex || ''}$$`;
    case 'figure': {
      // Canonical attr block (Phase 1 §3): `![alt](ref) {#slug width=W place=P ratio=R}`.
      // width omitted when 1, place omitted when column; legacy readers ignore
      // the trailing block and still resolve `![alt](ref)`.
      const scale = Number(block.widthRatio);
      const hasScale = Number.isFinite(scale) && Math.abs(scale - 1) > 1e-9;
      const place = block.placementPreference === 'full-width' ? 'full-width' : 'column';
      const ratio = Number(block.aspectRatio);
      const hasRatio = Number.isFinite(ratio) && ratio > 0 && Math.abs(ratio - 1.5) > 1e-9;
      let caption = '';
      if (Array.isArray(block.caption)) caption = runsToPlainText(block.caption).trim();
      else if (typeof block.caption === 'string') caption = block.caption.trim();
      const alt = String(block.altText || '').replace(/[\[\]]/g, '');
      const ref = String(block.assetRef || '');
      if (!caption && !hasScale && place === 'column' && !hasRatio && !block.slug) {
        return `![${alt}](${ref})`;
      }
      const parts = [];
      // Auto-generated `fig-slug-*` ids carry no user information — omit them
      // so bare legacy lines round-trip byte-identically; user slugs persist.
      const slug = String(block.slug || '');
      if (slug && !/^fig-slug-[0-9a-z]+$/.test(slug)) parts.push(`#${slug.replace(/[^A-Za-z0-9_-]/g, '')}`);
      if (hasScale) parts.push(`width=${Math.min(1, Math.max(0.05, scale))}`);
      if (place !== 'column') parts.push(`place=${place}`);
      if (hasRatio) parts.push(`ratio=${Math.round(ratio * 100) / 100}`);
      const attrBlock = parts.length > 0 ? ` {${parts.join(' ')}}` : '';
      if (!caption) return `![${alt}](${ref})${attrBlock}`;
      const safeCap = caption.replace(/"/g, '');
      return `![${alt}](${ref} "${safeCap}")${attrBlock}`;
    }
    case 'callout': {
      const inner = (block.content || []).map(serializeBlock).join('\n');
      return `::: ${block.accentStyle || 'info'} ${block.title || ''}\n${inner}\n:::`;
    }
    case 'rule':
      return '---';
    case 'pageBreak':
      return '<div class="page-break"></div>';
    default:
      return '';
  }
}

export function serializeMarkdown(ast) {
  if (!ast || !Array.isArray(ast.blocks)) return '';
  return ast.blocks.map(serializeBlock).filter(s => s !== '').join('\n\n');
}
