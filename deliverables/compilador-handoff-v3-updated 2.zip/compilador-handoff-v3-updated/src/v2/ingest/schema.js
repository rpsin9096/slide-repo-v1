// Deprecated: validation lives in exactly one module now —
// src/v2/core/contracts.js validateDocIR (strictest coherent union of both
// predecessors). This file remains only so existing imports keep working;
// new code must import from ../core/contracts.js directly.
export { validateDocIR, VALID_TEMPLATES as TEMPLATES } from '../core/contracts.js';
