import { normalizeSpecialCharacters } from '../../utils/parser.js';
import {
  createTextRun,
  createMathRun,
  createHeadingNode,
  createParagraphNode,
  createTableNode,
  createMathBlockNode,
  createFigureNode,
  createCalloutBoxNode,
  createRuleNode,
  createPageBreakNode,
  runsToPlainText,
  normalizeBlocks,
  validateAST,
} from '../core/ast-schema.js';

/**
 * Parses inline styled text into structured InlineRun objects.
 * Handles **bold**, *italic*, `code`, ~~strike~~, $math$.
 * @param {string} text 
 * @param {object} [inheritedMarks={}]
 * @returns {Array<object>} Array of InlineRuns
 */
export function parseInlineToRuns(text = '', inheritedMarks = {}) {
  const runs = [];
  const patterns = [
    { re: /^\*\*\*([^*]+)\*\*\*/, marks: { bold: true, italic: true } },
    { re: /^\*\*(.+?)\*\*/, marks: { bold: true } },
    { re: /^__(.+?)__/, marks: { bold: true } },
    { re: /^`([^`]+)`/, marks: { code: true } },
    { re: /^~~(.+?)~~/, marks: { strike: true } },
    { re: /^\*([^*]+?)\*/, marks: { italic: true } },
    { re: /^_([^_]+?)_/, marks: { italic: true } },
    { re: /^\$([^\$\n]+?)\$/, isMath: true },
    { re: /^\[([^\]]+)\]\(([^)]+)\)/, isLink: true },
  ];

  let rest = String(text || '');
  let buf = '';

  const flush = () => {
    if (buf) {
      runs.push(createTextRun(buf, inheritedMarks));
      buf = '';
    }
  };

  while (rest.length > 0) {
    let matched = false;
    for (const p of patterns) {
      const m = rest.match(p.re);
      if (m) {
        flush();
        if (p.isMath) {
          runs.push(createMathRun(m[1]));
        } else if (p.isLink) {
          runs.push(createTextRun(m[1], inheritedMarks, m[2]));
        } else {
          const mergedMarks = { ...inheritedMarks, ...p.marks };
          const subRuns = parseInlineToRuns(m[1], mergedMarks);
          runs.push(...subRuns);
        }
        rest = rest.slice(m[0].length);
        matched = true;
        break;
      }
    }
    if (!matched) {
      buf += rest[0];
      rest = rest.slice(1);
    }
  }
  flush();

  return runs.length > 0 ? runs : [createTextRun('')];
}

/**
 * Canonical figure contract (Phase 1 §3, ref-11 markdown.ts:152-161,344-367):
 * `![Alt](src) {#slug width=0.6 place=column ratio=1.78}`.
 * width 0.05–1 (default 1); place whitelisted to column|full-width
 * (default column); ratio > 0 (default 1.5). Legacy title suffix
 * `{width=N}` (clamped 0.05–1) still parses when no attr block is present.
 * Shared semantics with serialize.js, geometry-compiler.js, typst/md.js.
 */
export const FIGURE_PLACEMENTS = ['column', 'full-width'];
export const FIGURE_WIDTH_MIN = 0.05;
export const FIGURE_WIDTH_MAX = 1;
export const FIGURE_RATIO_DEFAULT = 1.5;

export function clampImageScale(n) {
  const v = Number(n);
  if (!Number.isFinite(v)) return 1;
  return Math.min(FIGURE_WIDTH_MAX, Math.max(FIGURE_WIDTH_MIN, v));
}

export function parseScaleTitle(title = '') {
  const t = String(title ?? '');
  const m = t.match(/\{\s*width\s*=\s*([0-9]*\.?[0-9]+)\s*\}\s*$/);
  if (!m) return { caption: t.trim(), scale: 1 };
  return { caption: t.slice(0, m.index).trim(), scale: clampImageScale(m[1]) };
}

export function parseFigureAttrs(attrStr = '') {
  const out = { slug: '', width: 1, place: 'column', ratio: FIGURE_RATIO_DEFAULT };
  const s = String(attrStr ?? '').trim();
  if (!s) return out;
  const idM = s.match(/#([A-Za-z0-9_-]+)/);
  if (idM) out.slug = idM[1];
  for (const m of s.matchAll(/(\w+)\s*=\s*"?([^"\s}]+)"?/g)) {
    const key = m[1].toLowerCase();
    const val = m[2];
    if (key === 'width') out.width = clampImageScale(val);
    else if (key === 'place' || key === 'placement') {
      out.place = FIGURE_PLACEMENTS.includes(val) ? val : 'column';
    } else if (key === 'ratio' || key === 'aspect') {
      const r = Number(val);
      out.ratio = Number.isFinite(r) && r > 0 ? r : FIGURE_RATIO_DEFAULT;
    }
  }
  return out;
}

export function splitFigureRef(ref = '') {
  const s = String(ref ?? '').trim();
  const m = s.match(/^(\S+)\s+["'](.*)["']$/);
  if (m) return { src: m[1], title: m[2] };
  return { src: s, title: '' };
}

/**
 * Parses raw Markdown into a canonical semantic Editorial AST.
 * @param {string} markdown
 * @param {object} [options={}]
 * @returns {object} Canonical Editorial AST
 */
export function parseMarkdownToAST(markdown = '', options = {}) {
  const rawMd = String(markdown || '');
  const md = (options.escapeSpecialChars || options.normalizeChars)
    ? normalizeSpecialCharacters(rawMd, options.normalizeOptions)
    : rawMd;

  const lines = md.split(/\r\n|\r|\n/);
  const blocks = [];
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];
    const trimmed = line.trim();

    if (!trimmed) {
      i++;
      continue;
    }

    // 1. Horizontal rule
    if (/^(---|___|\*\*\*)\s*$/.test(trimmed)) {
      blocks.push(createRuleNode());
      i++;
      continue;
    }

    // 2. Headings
    const headingMatch = line.match(/^(#{1,6})\s+(.*)$/);
    if (headingMatch) {
      const level = headingMatch[1].length;
      const text = headingMatch[2].trim();
      const runs = parseInlineToRuns(text);
      blocks.push(createHeadingNode(level, runs));
      i++;
      continue;
    }

    // 3. Callout blocks (::: info Title \n content \n :::)
    const calloutMatch = line.match(/^:::\s*(\w+)?(?:\s+(.*))?$/);
    if (calloutMatch) {
      const accentStyle = calloutMatch[1] || 'info';
      const title = calloutMatch[2] || '';
      i++;
      const calloutLines = [];
      while (i < lines.length && !lines[i].trim().startsWith(':::')) {
        calloutLines.push(lines[i++]);
      }
      if (i < lines.length) i++; // skip closing :::
      const calloutText = calloutLines.join('\n').trim();
      const pRuns = parseInlineToRuns(calloutText);
      blocks.push(createCalloutBoxNode([createParagraphNode(pRuns)], { accentStyle, title }));
      continue;
    }

    // 4. Standalone Image: `![alt](src "caption")` with legacy `{width=N}`
    // title suffix, or canonical `![alt](src) {#slug width place ratio}`.
    // Attr block wins when present; legacy title fills gaps.
    const imgMatch = trimmed.match(/^!\[([^\]]*)\]\(([^)]+)\)\s*(\{([^}]*)\})?\s*$/);
    if (imgMatch) {
      const altText = imgMatch[1];
      const { src, title } = splitFigureRef(imgMatch[2]);
      const legacy = parseScaleTitle(title);
      const attrs = parseFigureAttrs(imgMatch[4] || '');
      const hasAttrWidth = /width\s*=/i.test(imgMatch[4] || '');
      const scale = hasAttrWidth ? attrs.width : legacy.scale;
      const captionText = legacy.caption;
      const captionRuns = captionText ? parseInlineToRuns(captionText) : [];
      blocks.push(createFigureNode(src, {
        altText,
        caption: captionRuns,
        widthRatio: scale,
        placementPreference: attrs.place,
        aspectRatio: attrs.ratio,
        ...(attrs.slug ? { slug: attrs.slug } : {}),
      }));
      i++;
      continue;
    }

    // 5. Standalone Math Block ($$ ... $$)
    if (trimmed.startsWith('$$')) {
      let latex = '';
      if (trimmed.endsWith('$$') && trimmed.length > 4) {
        latex = trimmed.slice(2, -2).trim();
        i++;
      } else {
        const mathLines = [trimmed.slice(2)];
        i++;
        while (i < lines.length && !lines[i].trim().endsWith('$$')) {
          mathLines.push(lines[i++]);
        }
        if (i < lines.length) {
          mathLines.push(lines[i++].replace(/\$\$\s*$/, ''));
        }
        latex = mathLines.join('\n').trim();
      }
      blocks.push(createMathBlockNode(latex));
      continue;
    }

    // 6. Markdown Table (ref-11 ingest/tables.ts:40-79,149-158:
    // escaped-pipe split, delimiter guard, ragged/overflow repair).
    if (/^\s*\|/.test(line)) {
      const tableLines = [];
      while (i < lines.length && /^\s*\|/.test(lines[i])) {
        tableLines.push(lines[i++]);
      }

      if (tableLines.length >= 1) {
        // Escaped-pipe aware split: `\|` stays literal, `\\` unescapes.
        const splitRow = (r) => {
          const cells = [];
          let cur = '';
          let escaped = false;
          const inner = r.trim().replace(/^\||\|$/g, '');
          for (let k = 0; k < inner.length; k++) {
            const ch = inner[k];
            if (escaped) {
              cur += (ch === '|' ? '|' : `\\${ch}`);
              escaped = false;
            } else if (ch === '\\') {
              escaped = true;
            } else if (ch === '|') {
              cells.push(cur.trim());
              cur = '';
            } else {
              cur += ch;
            }
          }
          cells.push(cur.trim());
          return cells;
        };
        const isDelimiterCell = (c) => /^:?-+:?$/.test(c.trim()) && c.trim().length >= 3 - 2 * (c.trim().startsWith(':') ? 1 : 0) - 2 * (c.trim().endsWith(':') ? 1 : 0);
        const isDelimiterRow = (cells) => cells.length > 0 && cells.every(isDelimiterCell);
        const parseAlign = (c) => {
          const t = c.trim();
          if (t.startsWith(':') && t.endsWith(':') && t.length > 1) return 'center';
          if (t.endsWith(':') && t.length > 1) return 'right';
          return 'left';
        };

        const firstCells = splitRow(tableLines[0]);
        let headerTexts = firstCells;
        let aligns = firstCells.map(() => 'left');
        let bodyStart = 1;
        if (tableLines.length >= 2 && isDelimiterRow(splitRow(tableLines[1]))) {
          aligns = splitRow(tableLines[1]).map(parseAlign);
          bodyStart = 2;
        }
        const rawBody = [];
        for (let rIdx = bodyStart; rIdx < tableLines.length; rIdx++) {
          if (isDelimiterRow(splitRow(tableLines[rIdx]))) continue;
          rawBody.push(splitRow(tableLines[rIdx]));
        }
        // Rectangularize against the header width (ref-11): pad short rows
        // with "", merge overflow trailing with a single space. Body rows
        // never widen the grid — overflow merges (overflow-row repair).
        const ncols = Math.max(headerTexts.length, aligns.length, 1);
        while (headerTexts.length < ncols) headerTexts.push('');
        while (aligns.length < ncols) aligns.push('left');
        const rows = rawBody.map(cells => {
          const next = cells.slice(0, ncols);
          while (next.length < ncols) next.push('');
          if (cells.length > ncols) next[ncols - 1] = `${next[ncols - 1]} ${cells.slice(ncols).join(' ')}`.trim();
          return next.map(c => parseInlineToRuns(c));
        });
        // Track ragged repairs for QA parity with TABLE_REPAIRED.
        const repaired = rawBody.filter(r => r.length !== ncols).length
          + (headerTexts.length !== firstCells.length ? 1 : 0);

        blocks.push(createTableNode(
          [headerTexts.map(c => parseInlineToRuns(c))],
          rows,
          { alignments: aligns.slice(0, ncols), repairs: repaired }
        ));
        continue;
      }
    }

    // 7. Lists
    const listMatch = line.match(/^(\s*)([-*]|\d+[.)])\s+(.*)$/);
    if (listMatch) {
      const depth = Math.floor(listMatch[1].length / 2);
      const marker = listMatch[2];
      const text = listMatch[3];
      const runs = parseInlineToRuns(text);
      blocks.push(createParagraphNode(runs, { role: 'listItem', marker, depth }));
      i++;
      continue;
    }

    // 8. Blockquote
    const quoteMatch = line.match(/^>\s?(.*)$/);
    if (quoteMatch) {
      const runs = parseInlineToRuns(quoteMatch[1]);
      blocks.push(createParagraphNode(runs, { role: 'quote' }));
      i++;
      continue;
    }

    // 9. Regular Paragraph
    const paraLines = [line];
    i++;
    while (
      i < lines.length &&
      lines[i].trim() &&
      !/^#{1,6}\s/.test(lines[i]) &&
      !/^\s*\|/.test(lines[i]) &&
      !/^(\s*)([-*]|\d+[.)])\s+/.test(lines[i]) &&
      !/^>\s?/.test(lines[i]) &&
      !lines[i].trim().startsWith(':::') &&
      !lines[i].trim().startsWith('$$')
    ) {
      paraLines.push(lines[i++]);
    }
    const paraText = paraLines.join(' ');
    const runs = parseInlineToRuns(paraText);
    blocks.push(createParagraphNode(runs, { role: 'body' }));
  }

  const firstHeading = blocks.find(b => b.type === 'heading');
  const title = options.title || (firstHeading ? runsToPlainText(firstHeading.runs) : 'Untitled Document');

  // Ingestion gate (ref-11 ingest/index.ts:74-93,180-190): normalize then
  // strictly validate. Throw INGEST_SCHEMA_REJECTED on structural drift so
  // Markdown<->RichText divergence is catchable, never silent.
  const normalized = normalizeBlocks(blocks);
  const gate = validateAST({ blocks: normalized.blocks });
  if (!gate.ok && options.strict !== false && options.validate !== false) {
    // Non-throwing by default for legacy callers: attach diagnostics.
    // Strict callers (tests, pipeline) pass { strict: true } to throw.
    if (options.strict === true) {
      throw new Error(`INGEST_SCHEMA_REJECTED: ${gate.errors.slice(0, 3).join('; ')}`);
    }
  }

  return {
    astVersion: '2.0.0',
    metadata: {
      title,
      templateId: options.template || 'base',
      gridUnit: options.gridUnit || 14,
      locale: options.locale || 'en-US',
    },
    blocks: normalized.blocks,
    diagnostics: {
      dropped: normalized.dropped,
      deduped: normalized.deduped,
      errors: gate.errors,
    },
  };
}

// V2 loader: raw markdown -> DocIR (with embedded semantic AST)
export function fromMarkdown(markdown, opts = {}) {
  const rawMd = String(markdown ?? '');
  const md = (opts.escapeSpecialChars || opts.normalizeChars)
    ? normalizeSpecialCharacters(rawMd, opts.normalizeOptions)
    : rawMd;
  const m = md.match(/^#{1}\s+(.+)$/m);
  const ast = parseMarkdownToAST(md, opts);

  return {
    title: opts.title ?? (m ? m[1].trim() : (ast.metadata.title || 'Untitled')),
    template: opts.template ?? 'base',
    ast,
    blocks: [{ title: opts.blockTitle ?? '', markdown: md, flags: opts.flags ?? {}, astBlocks: ast.blocks }],
  };
}
