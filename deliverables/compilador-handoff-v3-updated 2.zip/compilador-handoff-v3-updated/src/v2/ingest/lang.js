// V2 language detection (per-document hyphenation). Scores distinctive
// markers; shared Romance words (de, para, con/no) are excluded by design.
// Chain: explicit docIR.lang > payload lang > detect(blocks) > 'pt'.
const MARKERS = {
  pt: ['ão', 'ã', 'ç', 'lh', 'nh', 'não', 'são', 'uma', 'com', 'em', 'é ', ' ê', ' à ', 'ões', 'mente'],
  es: ['ñ', 'll', 'ción', 'sión', ' la ', ' el ', ' los ', ' las ', 'una', 'con', 'está', 'qué', 'más', 'para '],
  en: [' the ', ' and ', ' of ', ' to ', ' in ', ' is ', ' are ', ' with ', 'tion', 'ing '],
};

export function detectLang(text) {
  const s = ` ${String(text ?? '').toLowerCase()} `;
  if (!s.trim()) return 'pt';
  const scores = {};
  for (const [lang, words] of Object.entries(MARKERS)) {
    scores[lang] = words.reduce((n, w) => n + (s.split(w).length - 1), 0);
  }
  const best = Object.entries(scores).sort((a, b) => b[1] - a[1])[0];
  if (best[1] === 0) return 'pt';
  return best[0];
}

export function resolveLang(docIR) {
  if (docIR && typeof docIR.lang === 'string' && ['pt', 'es', 'en'].includes(docIR.lang)) return docIR.lang;
  const text = (docIR?.blocks ?? []).map((b) => `${b.title ?? ''}\n${b.markdown ?? ''}`).join('\n');
  return detectLang(text);
}
