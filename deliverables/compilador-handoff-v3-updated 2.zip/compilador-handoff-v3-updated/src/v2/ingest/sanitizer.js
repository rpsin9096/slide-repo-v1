import { marked } from 'marked';
import { unescapeSpecialChars, normalizeSpecialCharacters, escapeSpecialChars } from '../../utils/parser.js';
// NOTE: ingest ↔ math-module form a deferred-use import cycle (math-module
// already imports TypographicAutofix from here). Both modules only touch the
// other's bindings inside static method bodies — never at evaluation time —
// so the cycle is safe. The gate below keeps TokenResolver's `$…$`
// currency behavior identical to the render path's looksLikeMath rule.
import { InlineMath } from '../modules/math-module.js';

export { unescapeSpecialChars, normalizeSpecialCharacters, escapeSpecialChars };

// Grounding tag cleaner patterns
const GROUNDING_TAG_PATTERNS = [
  /\[span_\d+\]/g,
  /\(start_span\)/g,
  /\(end_span\)/g,
  /\[cite_?[^\]]*\]/g,
];
const GROUNDING_FAST_RE = /\[(?:span_\d+|cite_?[^\]]*)\]|\((?:start|end)_span\)/;

/**
 * TagSanitizer: Responsible for stripping grounding tags, HTML entities,
 * and normalizing Toast UI WYSIWYG HTML constructs into canonical Markdown.
 */
export class TagSanitizer {
  static stripGroundingTags(text) {
    if (!text || !GROUNDING_FAST_RE.test(text)) return text || '';
    let cleaned = text;
    for (const pattern of GROUNDING_TAG_PATTERNS) {
      cleaned = cleaned.replace(pattern, '');
    }
    return cleaned;
  }

  static sanitizeToastUiHtml(md) {
    if (!md) return '';
    const cleaned = md
      .replace(/<strong\b[^>]*>(.*?)<\/strong>/gis, '**$1**')
      .replace(/<b\b[^>]*>(.*?)<\/b>/gis, '**$1**')
      .replace(/<em\b[^>]*>(.*?)<\/em>/gis, '*$1*')
      .replace(/<i\b[^>]*>(.*?)<\/i>/gis, '*$1*')
      .replace(/<(del|s|strike)\b[^>]*>(.*?)<\/\1>/gis, '~~$2~~')
      .replace(/<code\b[^>]*>(.*?)<\/code>/gis, '`$1`');
    return unescapeSpecialChars(cleaned);
  }

  static normalizeHtmlImages(md) {
    if (!md) return '';
    return md.replace(/<img\s+[^>]*>/gi, (match) => {
      const srcMatch = match.match(/src=["']([^"']+)["']/i);
      if (!srcMatch) return match;
      const src = srcMatch[1];
      const altMatch = match.match(/alt=["']([^"']*)["']/i);
      const alt = altMatch ? altMatch[1] : '';
      return `![${alt}](${src})`;
    });
  }

  static sanitize(text, options = {}) {
    if (!text) return '';
    let out = text;
    if (options.cleanSpans !== false) {
      out = TagSanitizer.stripGroundingTags(out);
    }
    out = TagSanitizer.sanitizeToastUiHtml(out);
    out = TagSanitizer.normalizeHtmlImages(out);
    return out;
  }
}

/**
 * BulletNormalizer: Normalizes Unicode bullets and composite bullet markers
 * into standard Markdown hyphen list items while precisely preserving indentation.
 */
export class BulletNormalizer {
  static normalize(md) {
    if (!md) return '';
    const lines = md.split('\n');
    const out = [];
    for (const rawLine of lines) {
      const indentMatch = rawLine.match(/^([\s\u00A0\u2000-\u200B\u202F\u205F\u3000]*)/);
      const rawIndent = indentMatch ? indentMatch[1] : '';
      const indent = rawIndent
        .replace(/\t/g, '  ')
        .replace(/[\u00A0\u2000-\u200B\u202F\u205F\u3000]/g, '  ');
      let content = rawLine.slice(rawIndent.length);

      while (/^[•◦○●–—\*\+-]\s+(?=[•◦○●–—\*\+-]\s+|\d+[\.\)]\s+)/.test(content)) {
        content = content.replace(/^[•◦○●–—\*\+-]\s+/, '');
      }

      const m = content.match(/^([•◦○●–—\*\+]|\d+[\.\)])\s+(.*)$/);
      if (m) {
        const marker = m[1];
        const rest = m[2];
        if (/^\d+[\.\)]/.test(marker)) {
          out.push(`${indent}${marker} ${rest}`);
        } else {
          out.push(`${indent}- ${rest}`);
        }
      } else if (/^-\s+(.*)$/.test(content)) {
        out.push(`${indent}${content}`);
      } else if (content) {
        out.push(`${indent}${content}`);
      } else {
        out.push('');
      }
    }
    return out.join('\n');
  }
}

/**
 * TableNormalizer: Strips leading indentation/tabs from markdown tables and guarantees
 * clean double-newline boundaries when tables succeed list items or paragraphs.
 */
export class TableNormalizer {
  static normalize(md) {
    if (!md) return '';
    const lines = md.split('\n');
    const out = [];

    let i = 0;
    while (i < lines.length) {
      if (/^\s*\|/.test(lines[i])) {
        const start = i;
        while (i < lines.length && /^\s*\|/.test(lines[i])) {
          i++;
        }
        let tableLines = lines.slice(start, i);
        const hasDelimiter = tableLines.some(l => /^\s*\|?\s*:?-{2,}:?\s*(\||\+)/.test(l));
        if (hasDelimiter && tableLines.length >= 1) {
          if (/^\s*\|?\s*:?-{2,}:?\s*(\||\+)/.test(tableLines[0])) {
            const rawCells = tableLines[0].split('|').map(c => c.trim()).filter(c => c.length > 0);
            const numCols = Math.max(rawCells.length, 1);
            const dummyHeader = '|' + new Array(numCols).fill(' ').join('|') + '|';
            tableLines.unshift(dummyHeader);
          }
          let prevIdx = out.length - 1;
          while (prevIdx >= 0 && out[prevIdx].trim().length === 0) prevIdx--;
          if (prevIdx >= 0) {
            const prevLine = out[prevIdx];
            const introMatch = prevLine.match(/^(\s*)[•◦○●–—\*\+-]\s+(\*\*[^*]+\*\*:\s*)$/);
            if (introMatch) {
              out.splice(prevIdx, 1, '', introMatch[2]);
            }
          }

          if (out.length > 0 && out[out.length - 1].trim().length > 0) {
            out.push('');
          }
          for (const tl of tableLines) {
            out.push(tl.trim());
          }
          if (i < lines.length && lines[i].trim().length > 0) {
            out.push('');
          }
        } else {
          for (const tl of tableLines) {
            out.push(tl);
          }
        }
      } else {
        out.push(lines[i]);
        i++;
      }
    }
    return out.join('\n');
  }
}

/**
 * TeX Symbol & Typography Autofix dictionary
 */
export const TEX_SYMBOL_MAP = [
  // LaTeX escapes: `\%` is a literal percent (never a leak); `\begin` /
  // `\end` wrappers strip (content kept). Both before brace unwraps below.
  [/\\%/g, '%'],
  [/\\begin\{[^}]*\}/g, ''], [/\\end\{[^}]*\}/g, ''],
  // Greek Lowercase
  [/\\alpha\b/g, 'α'], [/\\beta\b/g, 'β'], [/\\gamma\b/g, 'γ'], [/\\delta\b/g, 'δ'],
  [/\\epsilon\b/g, 'ε'], [/\\varepsilon\b/g, 'ε'], [/\\zeta\b/g, 'ζ'], [/\\eta\b/g, 'η'],
  [/\\theta\b/g, 'θ'], [/\\vartheta\b/g, 'θ'], [/\\iota\b/g, 'ι'], [/\\kappa\b/g, 'κ'],
  [/\\lambda\b/g, 'λ'], [/\\mu\b/g, 'μ'], [/\\nu\b/g, 'ν'], [/\\xi\b/g, 'ξ'],
  [/\\pi\b/g, 'π'], [/\\rho\b/g, 'ρ'], [/\\sigma\b/g, 'σ'], [/\\tau\b/g, 'τ'],
  [/\\upsilon\b/g, 'υ'], [/\\phi\b/g, 'φ'], [/\\varphi\b/g, 'φ'], [/\\chi\b/g, 'χ'],
  [/\\psi\b/g, 'ψ'], [/\\omega\b/g, 'ω'],
  // Greek Uppercase
  [/\\Gamma\b/g, 'Γ'], [/\\Delta\b/g, 'Δ'], [/\\Theta\b/g, 'Θ'], [/\\Lambda\b/g, 'Λ'],
  [/\\Xi\b/g, 'Ξ'], [/\\Pi\b/g, 'Π'], [/\\Sigma\b/g, 'Σ'], [/\\Upsilon\b/g, 'Υ'],
  [/\\Phi\b/g, 'Φ'], [/\\Psi\b/g, 'Ψ'], [/\\Omega\b/g, 'Ω'],
  // Arrows
  [/\\rightarrow\b/g, '→'], [/\\to\b/g, '→'], [/-->/g, '→'], [/->/g, '→'],
  [/\\Rightarrow\b/g, '⇒'], [/==>/g, '⇒'], [/=>/g, '⇒'],
  [/\\leftarrow\b/g, '←'], [/<--/g, '←'], [/<-/g, '←'],
  [/\\Leftarrow\b/g, '⇐'], [/<==/g, '⇐'],
  [/\\leftrightarrow\b/g, '↔'], [/<->/g, '↔'],
  [/\\Leftrightarrow\b/g, '⇔'], [/<=>/g, '⇔'],
  [/\\uparrow\b/g, '↑'], [/\\downarrow\b/g, '↓'],
  // Relations & Math Symbols
  [/\\pm\b/g, '±'], [/\\mp\b/g, '∓'], [/\\times\b/g, '×'], [/\\div\b/g, '÷'],
  [/\\cdot\b/g, '·'], [/\\bullet\b/g, '•'], [/\\circ\b/g, '○'],
  [/\\leq\b/g, '≤'], [/\\le\b/g, '≤'], [/<=/g, '≤'],
  [/\\geq\b/g, '≥'], [/\\ge\b/g, '≥'], [/>=/g, '≥'],
  [/\\neq\b/g, '≠'], [/!=/g, '≠'],
  [/\\approx\b/g, '≈'], [/\\sim\b/g, '∼'], [/\\equiv\b/g, '≡'],
  [/\\infty\b/g, '∞'], [/\\partial\b/g, '∂'], [/\\nabla\b/g, '∇'],
  [/\\forall\b/g, '∀'], [/\\exists\b/g, '∃'],
  [/\\in\b/g, '∈'], [/\\notin\b/g, '∉'],
  [/\\subset\b/g, '⊂'], [/\\subseteq\b/g, '⊆'],
  [/\\cup\b/g, '∪'], [/\\cap\b/g, '∩'],
  [/\\sum\b/g, '∑'], [/\\prod\b/g, '∏'], [/\\int\b/g, '∫'],
  [/\\sqrt\{([^}]+)\}/g, '√($1)'], [/\\sqrt\b/g, '√'],
  [/\\frac\{([^}]+)\}\{([^}]+)\}/g, '($1)/($2)'],
  [/\\text\{([^}]+)\}/g, '$1'],
  [/\\mathbf\{([^}]+)\}/g, '$1'],
  [/\\mathit\{([^}]+)\}/g, '$1'],
  [/\\texttt\{([^}]+)\}/g, '$1'],
  [/\\left\(/g, '('], [/\\right\)/g, ')'],
  [/\\left\[/g, '['], [/\\right\]/g, ']'],
  [/\\left\\\{/g, '{'], [/\\right\\\}/g, '}'],
  [/\\quad\b/g, '  '], [/\\qquad\b/g, '    '],
  // Common Chemistry Subscripts
  [/H_2O\b/g, 'H₂O'], [/CO_2\b/g, 'CO₂'], [/O_2\b/g, 'O₂'], [/N_2\b/g, 'N₂'],
  [/CH_4\b/g, 'CH₄'], [/NH_3\b/g, 'NH₃'], [/H_2SO_4\b/g, 'H₂SO₄'],
  // Micro / Micron symbol
  [/\\mu\s*([A-Za-z])/g, 'µ$1'],
  [/\\micro([A-Za-z])/g, 'µ$1'],
  // Multiplication sign
  [/\\times\b/g, '×'],
  // Multicharacter & single character superscripts and subscripts
  [/\^{([0-9+\-]+)}/g, (_, p1) => p1.split('').map(c => '⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻'['0123456789+-'.indexOf(c)] || c).join('')],
  [/_{([0-9+\-]+)}/g, (_, p1) => p1.split('').map(c => '₀₁₂₃₄₅₆₇₈₉₊₋'['0123456789+-'.indexOf(c)] || c).join('')],
  [/\^([0-9+\-])/g, (_, c) => '⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻'['0123456789+-'.indexOf(c)] || c],
  [/_([0-9+\-])/g, (_, c) => '₀₁₂₃₄₅₆₇₈₉₊₋'['0123456789+-'.indexOf(c)] || c],
];

// Pre-compile TEX_SYMBOL_MAP into trigger-gated steps:
// Consecutive simple /\\word\b/g rules are collapsed into a single alternation
// regex with O(1) dictionary lookup, and backslash/caret/underscore steps are
// skipped entirely when the input string lacks their trigger character.
const SIMPLE_TEX_WORD_RE = /^\\\\([A-Za-z]+)\\b$/;
const COMPILED_TEX_STEPS = (() => {
  const steps = [];
  let wordMap = null;
  let words = [];
  const flushWords = () => {
    if (words.length > 0) {
      const map = wordMap;
      const alt = [...words].sort((a, b) => b.length - a.length).join('|');
      const re = new RegExp(`\\\\(${alt})\\b`, 'g');
      steps.push({ kind: 'backslash', re, fn: (_, w) => map[w] });
      wordMap = null;
      words = [];
    }
  };
  for (const [re, rep] of TEX_SYMBOL_MAP) {
    const m = typeof rep === 'string' && !rep.includes('$') ? re.source.match(SIMPLE_TEX_WORD_RE) : null;
    if (m) {
      if (!wordMap) wordMap = Object.create(null);
      const w = m[1];
      if (!(w in wordMap)) {
        wordMap[w] = rep;
        words.push(w);
      }
    } else {
      flushWords();
      const src = re.source;
      const kind = src.startsWith('\\\\') ? 'backslash'
        : src.startsWith('\\^') ? 'caret'
        : src.includes('_') ? 'underscore'
        : 'op';
      steps.push({ kind, re, fn: rep });
    }
  }
  flushWords();
  return steps;
})();

const FENCE_TRIGGER_RE = /[`$]|https?:\/\//;
const OP_TRIGGER_RE = /[<>=!-]/;

/**
 * TypographicAutofix: Deterministic mathematical, directional,
 * and chemical glyph normalization.
 */
export class TypographicAutofix {
  /**
   * Fences spans autofix must never rewrite (inline code, fenced code
   * blocks, absolute URLs) behind PUA placeholders; restored verbatim by
   * `unfenceSpans`. The blanket string rewrite below has no code/URL
   * awareness, so without this `` `a -> b` `` and `?a<=b` come out mangled.
   */
  static fenceSpans(text) {
    let out = String(text ?? '');
    if (!out || !FENCE_TRIGGER_RE.test(out)) {
      return { text: out, slots: [] };
    }
    const slots = [];
    const stash = (match, kind = 'code') => {
      slots.push({ text: match, kind });
      return `\uE000${slots.length - 1}\uE001`;
    };
    if (out.includes('`')) {
      if (out.includes('```')) {
        out = out.replace(/```[\s\S]*?```/g, (m) => stash(m));
      }
      out = out.replace(/`[^`\n]+`/g, (m) => stash(m));
    }
    if (out.includes('http')) {
      out = out.replace(/https?:\/\/\S+/g, (m) => {
        const tail = m.match(/[.,;:!?)\]}'"]+$/);
        if (!tail) return stash(m);
        return stash(m.slice(0, m.length - tail[0].length)) + tail[0];
      });
    }
    if (out.includes('$')) {
      const skipRanges = [];
      if (out.includes('$$')) {
        const lines = out.split('\n');
        let pos = 0;
        const starts = [];
        for (const ln of lines) {
          starts.push(pos);
          pos += ln.length + 1;
        }
        for (let i = 0; i < lines.length; i++) {
          const t = lines[i].trim();
          if (!/^\$\$/.test(t)) continue;
          if (t.endsWith('$$') && t.length > 4) {
            skipRanges.push([starts[i], starts[i] + lines[i].length]);
            continue;
          }
          let j = i + 1;
          while (j < lines.length && !/^\s*\$\$/.test(lines[j].trim())) j++;
          if (j < lines.length) {
            skipRanges.push([starts[i], starts[j] + lines[j].length]);
            i = j;
          }
        }
      }
      const inSkip = skipRanges.length > 0
        ? (idx) => skipRanges.some(([a, b]) => idx >= a && idx < b)
        : () => false;
      out = out.replace(/(?<!\$)\$([^$\n]+?)\$(?!\$)/g, (m, inner, offset) => {
        if (inSkip(offset)) return m;
        return InlineMath.looksLikeMath(inner) ? stash(m, 'math') : m;
      });
    }
    return { text: out, slots };
  }

  static unfenceSpans(text, slots) {
    let out = String(text ?? '');
    if (!slots || slots.length === 0) return out;
    for (let i = 0; i < slots.length; i++) {
      const slot = slots[i];
      const raw = slot && typeof slot === 'object' ? slot.text : slot;
      out = out.split(`\uE000${i}\uE001`).join(raw);
    }
    return out;
  }

  /** Restores only `kind` slots (math), leaving code/URL fenced. */
  static unfenceKind(text, slots, kind) {
    let out = String(text ?? '');
    if (!slots || slots.length === 0) return out;
    for (let i = 0; i < slots.length; i++) {
      const slot = slots[i];
      if (slot && typeof slot === 'object' && slot.kind === kind) {
        out = out.split(`\uE000${i}\uE001`).join(slot.text);
      }
    }
    return out;
  }

  static tieParticles(text) {
    if (!text) return '';
    let result = text;
    result = result.replace(/\b(Art\.|art\.|Seção|seção|Capítulo|capítulo|Figura|figura|Fig\.|Tabela|tabela|Tab\.|Item|item|pág\.|pp\.|R\$|US\$|€)[^\S\r\n]+(\d+)/g, '$1\u00A0$2');
    result = result.replace(/(\d+)[^\S\r\n]+(kg|g|mg|m|cm|mm|km|km\/h|m²|m³|L|mL|%|°C|º|ª)\b/g, '$1\u00A0$2');
    result = result.replace(/\b([oaieuOAIEU])[^\S\r\n]+(?=[A-Za-zÀ-ÿ0-9])/g, '$1\u00A0');
    result = result.replace(/\b(de|da|do|em|na|no|por|pelo|pela|um|uma|os|as|De|Da|Do|Em|Na|No|Por|Pelo|Pela|Um|Uma|Os|As)[^\S\r\n]+(?=[A-Za-zÀ-ÿ0-9])/g, '$1\u00A0');
    return result;
  }

  static apply(text, hasCustomFonts = true, options = {}) {
    if (!text) return '';
    const fenced = TypographicAutofix.fenceSpans(text);
    let result = fenced.text;
    const hasBackslash = result.includes('\\');
    if (hasBackslash) {
      result = result.replace(/\\_/g, '\uE002');
      result = result.replace(/\\mu\b/g, 'µ');
    }
    if (result.includes('\u03BC')) {
      result = result.replace(/\u03BC/g, 'µ');
    }
    const hasOpChars = OP_TRIGGER_RE.test(result);
    if (hasCustomFonts) {
      if (hasOpChars) {
        result = result.replace(/<->/g, '↔').replace(/<=>/g, '⇔').replace(/-->/g, '→').replace(/->/g, '→').replace(/==>/g, '⇒').replace(/=>/g, '⇒');
      }
    } else {
      result = result.replace(/-->/g, '->').replace(/→/g, '->').replace(/==>/g, '=>').replace(/=>/g, '=>').replace(/⇒/g, '=>').replace(/←/g, '<-');
    }
    const hasCaret = result.includes('^');
    if (hasCaret) {
      result = result.replace(/(\d+)\^([0-9+\-]+)/g, (match, base, exp) => {
        const sup = exp.split('').map(c => '⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻'['0123456789+-'.indexOf(c)] || c).join('');
        return base + sup;
      });
    }
    const stillHasBackslash = hasBackslash && result.includes('\\');
    const stillHasCaret = hasCaret && result.includes('^');
    const hasUnderscore = result.includes('_');
    for (let i = 0; i < COMPILED_TEX_STEPS.length; i++) {
      const step = COMPILED_TEX_STEPS[i];
      if (step.kind === 'backslash' && !stillHasBackslash) continue;
      if (step.kind === 'caret' && !stillHasCaret) continue;
      if (step.kind === 'underscore' && !hasUnderscore) continue;
      if (step.kind === 'op' && !hasOpChars) continue;
      result = result.replace(step.re, step.fn);
    }
    if (!hasCustomFonts) {
      result = result.replace(/[→➝➜]/g, '->').replace(/[⇒]/g, '=>').replace(/[←]/g, '<-').replace(/[↔]/g, '<->');
    }
    if (fenced.slots.length > 0) {
      result = TypographicAutofix.unfenceKind(result, fenced.slots, 'math');
    }
    if (options.tieParticles !== false) {
      result = TypographicAutofix.tieParticles(result);
    }
    if (fenced.slots.length > 0) {
      result = TypographicAutofix.unfenceSpans(result, fenced.slots);
    }
    if (hasBackslash) {
      result = result.replace(/\uE002/g, '_');
    }
    return result;
  }
}

/**
 * TokenResolver: Bridges marked lexer, image extraction, and inline run analysis.
 */
export class TokenResolver {
  static tokenize(markdown) {
    if (!markdown) return [];
    return marked.lexer(markdown);
  }

  static collectImageSources(tokens, list = []) {
    if (!tokens || !Array.isArray(tokens)) return list;
    for (const t of tokens) {
      if (t.type === 'image' && t.href) {
        list.push(t.href);
      }
      if (t.tokens) TokenResolver.collectImageSources(t.tokens, list);
      if (t.items) {
        for (const it of t.items) {
          if (it.tokens) TokenResolver.collectImageSources(it.tokens, list);
        }
      }
    }
    return Array.from(new Set(list));
  }

  static parseInlineRuns(rawText, tmpl = {}, autofix = true, hasCustomFonts = true) {
    let text = autofix ? TypographicAutofix.apply(rawText, hasCustomFonts) : rawText;
    if (!hasCustomFonts && text) {
      text = text.replace(/→/g, '->').replace(/⇒/g, '=>').replace(/←/g, '<-');
    }
    const runs = [];
    if (!text) return runs;

    const regex = /(`([^`]+)`|\*\*\*([^*]+)\*\*\*|\*\*([^*]+)\*\*|__([^_]+)__|\*([^*]+)\*|_([^_]+)_|~~([^~]+)~~|\[([^\]]+)\]\(([^)]+)\)|\$([^$]+)\$)/g;

    let lastIndex = 0;
    let match;

    while ((match = regex.exec(text)) !== null) {
      if (match.index > lastIndex) {
        runs.push({
          text: text.slice(lastIndex, match.index),
          style: 'normal',
        });
      }

      if (match[2] !== undefined) {
        runs.push({ text: match[2], style: 'code' });
      } else if (match[3] !== undefined) {
        runs.push({ text: match[3], style: 'bold_italic' });
      } else if (match[4] !== undefined || match[5] !== undefined) {
        runs.push({ text: match[4] || match[5], style: 'bold' });
      } else if (match[6] !== undefined || match[7] !== undefined) {
        runs.push({ text: match[6] || match[7], style: 'italic' });
      } else if (match[8] !== undefined) {
        runs.push({ text: match[8], style: 'strike' });
      } else if (match[9] !== undefined) {
        runs.push({ text: match[9], style: 'link', link: match[10] });
      } else if (match[11] !== undefined) {
        // Gate: currency pairs stay literal (dollars kept), exactly like the
        // render path — an ungated `$5 and $` used to math-style the interior.
        if (InlineMath.looksLikeMath(match[11])) {
          runs.push({ text: match[11], style: 'math' });
        } else {
          runs.push({ text: match[0], style: 'normal' });
        }
      }

      lastIndex = regex.lastIndex;
    }

    if (lastIndex < text.length) {
      runs.push({
        text: text.slice(lastIndex),
        style: 'normal',
      });
    }

    const UNICODE_SUP_SUB_REGEX = /([⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻₀₁₂₃₄₅₆₇₈₉₊₋]+)/g;
    const finalRuns = [];
    for (const r of runs) {
      if (UNICODE_SUP_SUB_REGEX.test(r.text)) {
        const parts = r.text.split(UNICODE_SUP_SUB_REGEX);
        for (const part of parts) {
          if (!part) continue;
          if (/^[⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻₀₁₂₃₄₅₆₇₈₉₊₋]+$/.test(part)) {
            finalRuns.push({ text: part, style: 'unicode' });
          } else {
            finalRuns.push({ ...r, text: part });
          }
        }
      } else {
        finalRuns.push(r);
      }
    }

    return finalRuns;
  }
}

const EN_MONTHS_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export function formatEditorialDate(d) {
  return `${d.getDate()} ${EN_MONTHS_SHORT[d.getMonth()]} ${d.getFullYear()}`;
}

function parseCalendarDate(y, m, day) {
  const d = new Date(y, m - 1, day);
  return (d.getFullYear() === y && d.getMonth() === m - 1 && d.getDate() === day) ? d : null;
}

export class DateTokenResolver {
  static resolve(text, options = {}) {
    if (!text || typeof text !== 'string') return text ?? '';
    const today = options.today instanceof Date ? options.today : new Date();
    const parts = text.split(/(```[\s\S]*?```|`[^`\n]*`)/g);
    for (let i = 0; i < parts.length; i += 2) {
      parts[i] = DateTokenResolver.resolveProse(parts[i], today);
    }
    return parts.join('');
  }

  static resolveProse(segment, today) {
    return segment
      .replace(/\[(\d{4})-(\d{2})-(\d{2})\](?!\()/g, (_, y, m, d) => {
        const dt = parseCalendarDate(+y, +m, +d);
        return dt ? formatEditorialDate(dt) : _;
      })
      .replace(/\[(\d{2})[\/-](\d{2})[\/-](\d{4})\](?!\()/g, (_, d, m, y) => {
        const dt = parseCalendarDate(+y, +m, +d);
        return dt ? formatEditorialDate(dt) : _;
      })
      .replace(/\[(date)\](?!\()/gi, () => formatEditorialDate(today));
  }
}

export class MarkdownIngestionPipeline {
  constructor(options = {}) {
    this.defaultOptions = {
      cleanSpans: true,
      autofix: true,
      hasCustomFonts: true,
      ...options,
    };
  }

  process(rawMarkdown, options = {}) {
    const opts = { ...this.defaultOptions, ...options };
    if (!rawMarkdown || typeof rawMarkdown !== 'string') {
      return {
        normalizedMarkdown: '',
        tokens: [],
        imageSources: [],
        metadata: { lineCount: 0, charCount: 0 },
      };
    }

    let sanitized = TagSanitizer.sanitize(rawMarkdown, { cleanSpans: opts.cleanSpans });
    let normalizedBullets = BulletNormalizer.normalize(sanitized);
    let normalizedTables = TableNormalizer.normalize(normalizedBullets);
    let datedMarkdown = DateTokenResolver.resolve(normalizedTables);
    const finalMarkdown = datedMarkdown.trim();
    const tokens = TokenResolver.tokenize(finalMarkdown);
    const imageSources = TokenResolver.collectImageSources(tokens);

    return {
      normalizedMarkdown: finalMarkdown,
      tokens,
      imageSources,
      metadata: {
        lineCount: finalMarkdown ? finalMarkdown.split('\n').length : 0,
        charCount: finalMarkdown.length,
      },
    };
  }
}

export const stripGroundingTags = TagSanitizer.stripGroundingTags;
export const sanitizeToastUiHtml = TagSanitizer.sanitizeToastUiHtml;
export const normalizeHtmlImages = TagSanitizer.normalizeHtmlImages;
export const normalizeMarkdownBullets = BulletNormalizer.normalize;
export const normalizeMarkdownTables = TableNormalizer.normalize;
export const applyAutofix = TypographicAutofix.apply;
export const parseInlineRuns = TokenResolver.parseInlineRuns;
