// V2 document chrome: running header (title left + date right) and footer
// (divider rule, text left, page number RIGHT). Mirrors legacy semantics:
// default title 'Material de Raul de Oliveira Pasin', formatDocumentDate
// shapes, per-template sizes. Pure string builders — no PDFKit.
import { systemClock } from '../core/clock.js';
import { formatDocumentDate as formatSharedDocDate } from '../core/date.js';

export const DEFAULT_HEADER = 'Material de Raul de Oliveira Pasin';

// Delegates to the shared single source of truth (doc-date.js). Note the
// unified null-on-disabled semantics (was '' here, null in legacy); both
// are falsy and every consumer branches on truthiness.
export function formatDocDate(dateOpts, clock = systemClock) {
  return formatSharedDocDate(dateOpts, clock.now());
}

const esc = (s) => String(s ?? '').replace(/\\/g, '\\\\').replace(/"/g, '\\"');

export function headerContent(theme, { title = '', date = '' } = {}) {
  const t = theme;
  const size = t.id === 'bauhaus_minimalist' ? '6.5pt' : t.id === 'bauhaus' ? '7.5pt' : '8pt';
  const weight = t.id === 'base' ? '"regular"' : '"bold"';
  const gray = `rgb("${t.muted}")`;
  const rule = `rgb("${t.rule}")`;
  const stroke = t.ruleStroke || '0.4pt';
  const cell = (body) => `[#text(size: ${size}, weight: ${weight}, fill: ${gray})[${body}]]`;
  const meta = date
    ? `#grid(columns: (1fr, auto), gutter: 8pt, ${cell(title)}, align(right)[${cell(date)}])`
    : cell(title);
  // Header divider rule with >= 4pt clearance beneath header text baseline
  return `[${meta}#v(4pt)#line(length: 100%, stroke: ${stroke} + ${rule})]`;
}

export function footerContent(theme, { left = '', } = {}) {
  const t = theme;
  const size = t.id === 'bauhaus_minimalist' ? '6.5pt' : t.id === 'bauhaus' ? '7.5pt' : '8pt';
  const numSize = size;
  const weight = t.id === 'base' ? '"regular"' : '"bold"';
  const gray = `rgb("${t.muted}")`;
  const rule = `rgb("${t.rule}")`;
  const stroke = t.ruleStroke || '0.4pt';
  // Footer divider rule with explicit 6pt vertical gap before page numbers
  return `[#line(length: 100%, stroke: ${stroke} + ${rule})` +
    `#v(6pt)` +
    `#grid(columns: (1fr, auto), [#text(size: ${size}, weight: ${weight}, fill: ${gray})[${esc(left)}]]` +
    `, align(right)[#text(size: ${numSize}, weight: ${weight}, fill: ${gray})[#context counter(page).display()]])]`;
}

