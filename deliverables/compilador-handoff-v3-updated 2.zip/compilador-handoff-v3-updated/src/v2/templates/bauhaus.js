// V2 template: bauhaus. Sapphire studio identity (see themes.js).
import { renderWithTheme } from './base.js';

export const name = 'bauhaus';

export function render(docIR, opts = {}) {
  return renderWithTheme(docIR, 'bauhaus', opts);
}
