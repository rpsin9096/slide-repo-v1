/**
 * FocusGate / PDF Engine V2: Canonical Template Definitions
 * Pure data structures describing geometric bounds, colors, margins,
 * Layer-2 vertical grid rhythm (`vertical`), and Layer-3 component tokens (`tokens`).
 * Decoupled from PDFKit canvas or generators to eliminate circular dependencies.
 */

export const TEMPLATES = {
  // ── Template 1: Minimalist (Swiss Editorial Clean) ──
  base: {
    id: 'base',
    name: 'Minimalist',
    subtitle: 'Swiss Editorial Clean',
    fontSize: 9.5,
    lineStretch: 1.15,
    parskip: 2.2,
    gridUnit: 12, // Slot-quantization unit G (ColumnBand capacity math)
    margins: {
      left: 28.35,  // 1.0cm
      right: 28.35, // 1.0cm
      top: 26.93,   // 0.95cm
      bottom: 28.35,// 1.0cm
    },
    headheight: 12,
    headsep: 6.5,   // 0.23cm
    footskip: 12.5, // 0.44cm
    columnsep: 14.17,// 0.50cm
    columnseprule: 0.25,
    headsepline: 0.4,
    footsepline: 0.4,
    vertical: {
      bodySizePt: 9.5,
      lineStretch: 1.15,
      topskipFactor: 0.72,
      maxdepthFactor: 0.28,
      parskipU: 0.25,
      h1AboveU: 1.0,
      h1BelowU: 0.5,
      h2AboveU: 0.75,
      h2BelowU: 0.25,
      h3AboveU: 0.5,
      h3BelowU: 0.25,
      h4AboveU: 0.5,
      h4BelowU: 0.25,
      listTopU: 0.25,
      listBottomU: 0.25,
      calloutMarginU: 0.5,
      tableMarginU: 0.5,
      codeMarginU: 0.5,
      ruleMarginU: 0.5,
      figureMarginU: 0.5,
      scalePt: { s0: 0.40, sH1: 1.40, sH2: 0.80, s1: 2.20, s2: 4.36, s3: 6.20, s4: 8.20, s5: 8.00 },
    },
    tokens: {
      fontFamily: 'arimo',
      bodyFontName: 'arimo',
      headFontName: 'arimo-bold',
      fontRatio: 1.1499,
      lineHeightMultiplier: 1.15,
      paraGapPt: 1.5,
      listGapPt: 1.2,
      mathFontSize: 10,
      captionFontSize: 7.4,
      chrome: {
        fontSize: 8.0,
        bold: false,
      },
      masthead: {
        style: 'classic',
        padX: 0,
        padY: 8,
        titleGap: 2,
        colGap: 16,
        titleSize: 13,
        subSize: 9.5,
        metaSize: 7.5,
        accentW: 2,
      },
      list: {
        deepSizeScale: true,
        step: 9.0,
        markerWOrdered: 13,
        markerWUnordered: 9.5,
        labelSep: 3.0,
        labelIndent: 2.0,
        itemSep: [1.4, 0.8, 0.4],
        topSep: 1.2,
        bottomSep: 1.5,
        markerPreset: 'minimalist',
        orderedBoldAllLevels: false,
      },
      table: {
        densityPreset: 'standard',
        heavyRule: 0.7,
        lightRule: 0.35,
      },
    },
    colors: {
      pagebg: '#FFFFFF',
      textmain: '#111827',
      textmuted: '#4B5563',
      surface: '#F9FAFB',
      bordercolor: '#E5E7EB',
      accent: '#111827',
      ruleblack: '#111827',
      rulegray: '#9CA3AF',
      textgray: '#6B7280',
      accentblue: '#0D9488',
      codebg: '#F9FAFB',
      notebg: '#F9FAFB',
      noteborder: '#111827',
      columnseprule: '#E5E7EB',
      headerline: '#E5E7EB',
      cardBorder: '#E5E7EB',
      tocZebra: '#F9FAFB',
      tocLeader: '#9CA3AF',
      tocTitleRule: '#E5E7EB',
      tocBadgeBg: '#111827',
      tocBadgeText: '#FFFFFF',
      tocPageNum: '#111827',
      tocSubText: '#4B5563',
    },
    toc: {
      banner: {
        style: 'classic_rules',
        arc: 0,
        accentWidth: 0,
        paddingX: 0,
        paddingY: 0,
        titleSize: 13.5,
        subSize: 9.5,
        metaSize: 7.5,
        topRule: 0,
        bottomRule: 0.75,
        gapBottom: 14,
      },
      title: {
        fontSize: 13.0,
        prefix: '',
        accentBarWidth: 3.0,
        accentBarHeight: 16.0,
        ruleThickness: 0.4,
        gapBottom: 12.0,
      },
      item: {
        height: 24.0,
        fontSize: 9.5,
        fontWeight: 'bold',
        badgeWidth: 20.0,
        badgeHeight: 14.0,
        badgeArc: 0,
        badgeStyle: 'filled',
        labelOffset: 30.0,
        pageNumSize: 8.5,
        pageNumFont: 'bold',
        pageNumPrefix: 'Pág. ',
        pageNumSuffix: '',
        paddingBottom: 2.0,
      },
      subItem: {
        indent: 34.0,
        fontSize: 8.0,
        fontWeight: 'normal',
        connector: '— ',
        rowHeight: 13.0,
        groupGap: 3.0,
        pageNumSize: 8.0,
        pageNumFont: 'normal',
        pageNumPrefix: 'pág. ',
        pageNumSuffix: '',
      },
      leader: {
        char: '. ',
        fontSize: 7.5,
        minSpan: 16.0,
      },
    },
    cardFrame: { arc: 0, westWidth: 0, topRule: 0, bottomRule: 0.75 },
    noteboxFrame: { arc: 0, westWidth: 1.5, bg: '#F9FAFB', westColor: '#111827', strokeColor: '#E5E7EB', paddingH: 6, paddingV: 4 },
    headingDecorators: {
      1: { style: 'underline', underlineW: 0.4, underlineColor: '#9CA3AF', fontSize: 11.0, titleWOffset: 0, extraH: 8, spaceBefore: 6, isUppercase: false },
      2: { style: 'vertical_bar', barW: 2.0, barColor: '#111827', fontSize: 9.5, titleWOffset: 6, extraH: 7, spaceBefore: 4, isUppercase: false },
      3: { style: 'plain', textColor: '#4B5563', fontSize: 9.0, titleWOffset: 0, extraH: 6, spaceBefore: 2.5, isUppercase: false },
      4: { style: 'middle_dot', dotColor: '#9CA3AF', textColor: '#111827', fontSize: 8.5, titleWOffset: 10, extraH: 5, spaceBefore: 2.5, isUppercase: false },
    },
    bullets: { l1: 'dash', l2: 'dash_muted', l3: 'hollow_square' },
    tocBadge: { style: 'plain_num', color: '#4B5563' },
    mastheadStyle: 'classic',
    h1Style: 'hairline_underline',
    h2Style: 'bar_and_rule',
    h3Style: 'thin_gray_bar',
    h4Style: 'middle_dot',
    bulletL1: 'dash',
    bulletL2: 'endash',
    bulletL3: 'hollow_square',
    noteboxStyle: 'clean_graphite',
    codeblockRadius: 0,
  },

  // ── Template 2: Modern (Linear Studio Tech) ──
  bauhaus: {
    id: 'bauhaus',
    name: 'Modern',
    subtitle: 'Linear Studio Tech',
    fontSize: 9.0,
    lineStretch: 1.18,
    parskip: 2.8,
    gridUnit: 12, // Slot-quantization unit G (ColumnBand capacity math)
    margins: {
      left: 28.35,  // 1.0cm
      right: 28.35, // 1.0cm
      top: 22.68,   // 0.8cm
      bottom: 24.09,// 0.85cm
    },
    headheight: 12,
    headsep: 6.5,   // 0.23cm
    footskip: 12.0, // 0.42cm
    columnsep: 15.00,// 0.53cm
    columnseprule: 0.35,
    headsepline: 0.5,
    footsepline: 0.5,
    vertical: {
      bodySizePt: 9.0,
      lineStretch: 1.18,
      topskipFactor: 0.72,
      maxdepthFactor: 0.28,
      parskipU: 0.25,
      h1AboveU: 1.0,
      h1BelowU: 0.5,
      h2AboveU: 0.75,
      h2BelowU: 0.25,
      h3AboveU: 0.5,
      h3BelowU: 0.25,
      h4AboveU: 0.5,
      h4BelowU: 0.25,
      listTopU: 0.25,
      listBottomU: 0.25,
      calloutMarginU: 0.5,
      tableMarginU: 0.5,
      codeMarginU: 0.5,
      ruleMarginU: 0.5,
      figureMarginU: 0.5,
      scalePt: { s0: 0.80, sH1: 2.00, sH2: 1.40, s1: 2.80, s2: 4.49, s3: 6.00, s4: 8.80, s5: 8.00 },
    },
    tokens: {
      fontFamily: 'arimo',
      bodyFontName: 'arimo',
      headFontName: 'arimo-bold',
      fontRatio: 1.1499,
      lineHeightMultiplier: 1.15,
      paraGapPt: 1.5,
      listGapPt: 1.2,
      mathFontSize: 10,
      captionFontSize: 7.4,
      chrome: {
        fontSize: 7.5,
        bold: true,
      },
      masthead: {
        style: 'studio_card',
        padX: 14,
        padY: 10,
        titleGap: 2,
        colGap: 16,
        titleSize: 13,
        subSize: 9,
        metaSize: 7.5,
        accentW: 3,
      },
      list: {
        deepSizeScale: false,
        step: 8.5,
        markerWOrdered: 12,
        markerWUnordered: 9,
        labelSep: 2.5,
        labelIndent: 1.5,
        itemSep: [2.0, 1.4, 0.8],
        topSep: 2.5,
        bottomSep: 2.5,
        markerPreset: 'modern',
        orderedBoldAllLevels: true,
      },
      table: {
        densityPreset: 'standard',
        heavyRule: 0.9,
        lightRule: 0.45,
      },
    },
    colors: {
      pagebg: '#FFFFFF',
      textmain: '#0F172A',
      textmuted: '#475569',
      surface: '#F8FAFC',
      bordercolor: '#E2E8F0',
      accent: '#2563EB',    // Sapphire Blue
      accentlight: '#EFF6FF',
      ruleblack: '#0F172A',
      rulegray: '#94A3B8',
      textgray: '#64748B',
      accentblue: '#2563EB',
      codebg: '#F1F5F9',
      notebg: '#F8FAFC',
      noteborder: '#2563EB',
      columnseprule: '#E2E8F0',
      headerline: '#E2E8F0',
      cardBorder: '#E2E8F0',
      tocZebra: '#F1F5F9',
      tocLeader: '#94A3B8',
      tocTitleRule: '#E2E8F0',
      tocBadgeBg: '#2563EB',
      tocBadgeText: '#FFFFFF',
      tocPageNum: '#2563EB',
      tocSubText: '#475569',
    },
    toc: {
      banner: {
        style: 'card',
        arc: 4.0,
        accentWidth: 3.5,
        paddingX: 14.0,
        paddingY: 10.0,
        titleSize: 13.5,
        subSize: 9.5,
        metaSize: 7.5,
        topRule: 0,
        bottomRule: 0,
        gapBottom: 14,
      },
      title: {
        fontSize: 14.0,
        prefix: '',
        accentBarWidth: 3.5,
        accentBarHeight: 18.0,
        ruleThickness: 0.5,
        gapBottom: 12.0,
      },
      item: {
        height: 26.0,
        fontSize: 9.5,
        fontWeight: 'bold',
        badgeWidth: 20.0,
        badgeHeight: 14.0,
        badgeArc: 2.0,
        badgeStyle: 'pill',
        labelOffset: 30.0,
        pageNumSize: 8.5,
        pageNumFont: 'bold',
        pageNumPrefix: 'Pág. ',
        pageNumSuffix: '',
        paddingBottom: 2.0,
      },
      subItem: {
        indent: 34.0,
        fontSize: 8.0,
        fontWeight: 'normal',
        connector: '– ',
        rowHeight: 14.0,
        groupGap: 3.0,
        pageNumSize: 8.0,
        pageNumFont: 'normal',
        pageNumPrefix: 'pág. ',
        pageNumSuffix: '',
      },
      leader: {
        char: '. ',
        fontSize: 7.5,
        minSpan: 16.0,
      },
    },
    cardFrame: { arc: 4, westWidth: 2.5, westColor: '#2563EB', bg: '#F8FAFC', strokeColor: '#E2E8F0', paddingH: 10, paddingV: 6 },
    noteboxFrame: { arc: 4, westWidth: 2.5, bg: '#F8FAFC', westColor: '#2563EB', strokeColor: '#E2E8F0', paddingH: 8, paddingV: 4 },
    headingDecorators: {
      1: { style: 'vertical_pill', pillW: 3.0, pillColor: '#2563EB', pillRadius: 1.5, fontSize: 11.5, titleWOffset: 9, extraH: 10, spaceBefore: 6, isUppercase: false },
      2: { style: 'vertical_bar', barW: 2.5, barColor: '#2563EB', fontSize: 10.0, titleWOffset: 7, extraH: 8, spaceBefore: 4, isUppercase: false },
      3: { style: 'plain', textColor: '#64748B', fontSize: 9.0, titleWOffset: 0, extraH: 6, spaceBefore: 2.5, isUppercase: false },
      4: { style: 'plain', textColor: '#0F172A', fontSize: 8.5, titleWOffset: 0, extraH: 5, spaceBefore: 2.5, isUppercase: false },
    },
    bullets: { l1: 'circle_sapphire', l2: 'dash', l3: 'hollow_circle' },
    tocBadge: { style: 'pill_badge', color: '#2563EB', bg: '#EFF6FF' },
    mastheadStyle: 'tcolorbox_soft',
    mastheadArc: 4,
    h1Style: 'rounded_pill_accent',
    h2Style: 'clean_hierarchy',
    h3Style: 'muted_hierarchy',
    h4Style: 'bold_runin',
    bulletL1: 'circle_sapphire',
    bulletL2: 'endash',
    bulletL3: 'hollow_circle',
    noteboxStyle: 'studio_card',
    noteboxArc: 4,
    codeblockRadius: 4,
  },

  // ── Template 3: Compact (High-Density Engineering) ──
  bauhaus_minimalist: {
    id: 'bauhaus_minimalist',
    name: 'Compact',
    subtitle: 'High-Density Engineering',
    fontSize: 8.0,
    lineStretch: 1.04,
    parskip: 1.2,
    gridUnit: 12, // Slot-quantization unit G (ColumnBand capacity math)
    margins: {
      left: 22.68,  // 0.8cm
      right: 22.68, // 0.8cm
      top: 19.84,   // 0.7cm
      bottom: 19.84,// 0.7cm
    },
    headheight: 10,
    headsep: 5.0,   // ~0.18cm
    footskip: 9.0,  // ~0.32cm
    columnsep: 12.00,// 0.42cm
    columnseprule: 0.25,
    headsepline: 0.3,
    footsepline: 0.3,
    vertical: {
      bodySizePt: 8.0,
      lineStretch: 1.04,
      topskipFactor: 0.72,
      maxdepthFactor: 0.28,
      parskipU: 0.20,
      h1AboveU: 1.0,
      h1BelowU: 0.5,
      h2AboveU: 0.75,
      h2BelowU: 0.25,
      h3AboveU: 0.5,
      h3BelowU: 0.25,
      h4AboveU: 0.5,
      h4BelowU: 0.25,
      listTopU: 0.20,
      listBottomU: 0.20,
      calloutMarginU: 0.5,
      tableMarginU: 0.5,
      codeMarginU: 0.5,
      ruleMarginU: 0.5,
      figureMarginU: 0.5,
      scalePt: { s0: 0.40, sH1: 1.00, sH2: 0.70, s1: 1.20, s2: 3.70, s3: 5.20, s4: 7.20, s5: 8.00 },
    },
    tokens: {
      fontFamily: 'inter',
      bodyFontName: 'inter',
      headFontName: 'inter-bold',
      fontRatio: 1.20996,
      lineHeightMultiplier: 1.04,
      paraGapPt: 1.0,
      listGapPt: 1.0,
      mathFontSize: 9.5,
      captionFontSize: 6.8,
      chrome: {
        fontSize: 6.5,
        bold: true,
      },
      masthead: {
        style: 'compact_card',
        padX: 10,
        padY: 7,
        titleGap: 1.5,
        colGap: 12,
        titleSize: 11,
        subSize: 8,
        metaSize: 7,
        accentW: 2,
      },
      list: {
        deepSizeScale: false,
        step: 7.5,
        markerWOrdered: 12,
        markerWUnordered: 8,
        labelSep: 2.5,
        labelIndent: 1.5,
        itemSep: [1.0, 0.7, 0.4],
        topSep: 1.2,
        bottomSep: 1.5,
        markerPreset: 'compact',
        orderedBoldAllLevels: true,
      },
      table: {
        densityPreset: 'compact',
        heavyRule: 0.7,
        lightRule: 0.35,
      },
    },
    colors: {
      pagebg: '#FFFFFF',
      textmain: '#18181B',
      textmuted: '#52525B',
      surface: '#F4F4F5',
      bordercolor: '#E4E4E7',
      accent: '#0F766E',    // Deep Teal
      textlabel: '#3F3F46',
      ruleblack: '#18181B',
      rulegray: '#71717A',
      textgray: '#6B6B76',
      accentblue: '#0F766E',
      codebg: '#F4F4F5',
      notebg: '#F4F4F5',
      noteborder: '#0F766E',
      columnseprule: '#E4E4E7',
      headerline: '#E4E4E7',
      cardBorder: '#E4E4E7',
      tocZebra: '#F4F4F5',
      tocLeader: '#71717A',
      tocTitleRule: '#E4E4E7',
      tocBadgeBg: 'transparent',
      tocBadgeText: '#18181B',
      tocPageNum: '#18181B',
      tocSubText: '#52525B',
    },
    toc: {
      banner: {
        style: 'compact_card',
        arc: 2.0,
        accentWidth: 2.5,
        paddingX: 10.0,
        paddingY: 8.0,
        titleSize: 11.5,
        subSize: 8.5,
        metaSize: 7.0,
        topRule: 0,
        bottomRule: 0,
        gapBottom: 12,
      },
      title: {
        fontSize: 12.0,
        prefix: 'INDEX // ',
        accentBarWidth: 2.5,
        accentBarHeight: 14.0,
        ruleThickness: 0.35,
        gapBottom: 10.0,
      },
      item: {
        height: 22.0,
        fontSize: 8.5,
        fontWeight: 'bold',
        badgeWidth: 22.0,
        badgeHeight: 14.0,
        badgeArc: 0,
        badgeStyle: 'bracket',
        labelOffset: 28.0,
        pageNumSize: 8.0,
        pageNumFont: 'bold',
        pageNumPrefix: '[P. ',
        pageNumSuffix: ']',
        paddingBottom: 2.0,
      },
      subItem: {
        indent: 32.0,
        fontSize: 7.5,
        fontWeight: 'normal',
        connector: '> ',
        rowHeight: 12.0,
        groupGap: 2.0,
        pageNumSize: 7.5,
        pageNumFont: 'normal',
        pageNumPrefix: '[p. ',
        pageNumSuffix: ']',
      },
      leader: {
        char: '. ',
        fontSize: 7.0,
        minSpan: 14.0,
      },
    },
    cardFrame: { arc: 1.5, westWidth: 2.0, westColor: '#0F766E', bg: '#F4F4F5', strokeColor: '#E4E4E7', paddingH: 8, paddingV: 4 },
    noteboxFrame: { arc: 1.5, westWidth: 1.5, bg: '#F4F4F5', westColor: '#0F766E', strokeColor: '#E4E4E7', paddingH: 6, paddingV: 3 },
    headingDecorators: {
      1: { style: 'vertical_bar', barW: 2.5, barColor: '#0F766E', fontSize: 10.5, titleWOffset: 7.5, extraH: 7, spaceBefore: 6, isUppercase: false },
      2: { style: 'vertical_bar', barW: 1.8, barColor: '#71717A', fontSize: 9.0, titleWOffset: 6, extraH: 6, spaceBefore: 4, isUppercase: false },
      3: { style: 'small_caps', textColor: '#3F3F46', fontSize: 8.0, titleWOffset: 0, extraH: 5, spaceBefore: 2.5, isUppercase: true },
      4: { style: 'plain', textColor: '#18181B', fontSize: 7.8, titleWOffset: 0, extraH: 4, spaceBefore: 2.5, isUppercase: false },
    },
    bullets: { l1: 'diamond_teal', l2: 'dash', l3: 'hollow_circle' },
    tocBadge: { style: 'bracket_badge', color: '#18181B' },
    mastheadStyle: 'tcolorbox_crisp',
    mastheadArc: 1.5,
    h1Style: 'vertical_bar_teal',
    h2Style: 'vertical_bar_muted',
    h3Style: 'small_caps_tracking',
    h4Style: 'bold_runin',
    bulletL1: 'diamond_teal',
    bulletL2: 'endash',
    bulletL3: 'hollow_circle',
    noteboxStyle: 'crisp_teal',
    noteboxArc: 1.5,
    codeblockRadius: 1.5,
  },
};

/**
 * Vertical rhythm derivation (ref-11 core/template.ts:30-47 shape).
 * Single source of truth for leading + inter-block gaps: the compiler's
 * pitch closures must come from here so estimate and render can never
 * drift apart.
 *
 * Reads explicit Layer-3 `tmpl.tokens` (`fontRatio`, `paraGapPt`, `listGapPt`)
 * without inspecting template names or dead float-equality checks.
 *
 * @param {object} [tmpl={}] template definition
 * @returns {{ gridUnit: number, fontRatio: number, bodySize: number, bodyPitchPt: number, listGapPt: number, paraGapPt: number, parskipPt: number }}
 */
export function rhythmForTemplate(tmpl = {}) {
  const tok = tmpl.tokens || {};
  const fontRatio = tok.fontRatio !== undefined ? tok.fontRatio : (tmpl.lineStretch === 1.04 ? 1.20996 : 1.1499);
  const listGapPt = tok.listGapPt !== undefined ? tok.listGapPt : (tmpl.lineStretch === 1.04 ? 1.0 : 1.2);
  const paraGapPt = tok.paraGapPt !== undefined ? tok.paraGapPt : (tmpl.lineStretch === 1.04 ? 1.0 : 1.5);
  const bodySize = tmpl.fontSize || 9.5;
  return {
    gridUnit: tmpl.gridUnit || 12,
    fontRatio,
    bodySize,
    bodyPitchPt: bodySize * fontRatio + paraGapPt,
    listGapPt,
    paraGapPt,
    parskipPt: tmpl.parskip !== undefined ? tmpl.parskip : 2.2,
  };
}

/**
 * Heading space-before resolver (rhythm token seam). Reads the per-level
 * `spaceBefore` token from a template's headingDecorators with legacy
 * 6/4/2.5 fallback. Pure, node-testable: rhythm assertions must target
 * tokens through here, never hardcoded points in the compiler.
 *
 * @param {object} [decorators={}] headingDecorators map
 * @param {number} level heading level 1-6
 * @returns {number} space-before in points
 */
export function headingSpaceBefore(decorators = {}, level = 1) {
  const decor = (decorators && decorators[level]) || {};
  const v = Number(decor.spaceBefore);
  if (Number.isFinite(v)) return v;
  return level === 1 ? 6 : (level === 2 ? 4 : 2.5);
}
