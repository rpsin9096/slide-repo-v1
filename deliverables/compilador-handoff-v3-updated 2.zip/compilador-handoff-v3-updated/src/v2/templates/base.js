// V2 template: base. Pure function, no coordinate math, no drawing imports.
import { validateDocIR } from '../ingest/schema.js';
import { resolveLang } from '../ingest/lang.js';
import { measure, place, reclaimPass } from '../layout/coordinator.js';
import { emit } from '../drivers/typst/emitter.js';
import { THEMES } from './themes.js';

export const name = 'base';

// Doc-level chrome (header/footer/alignment) travels on the DocIR so every
// template honors it without touching coordinate math.
export function renderWithTheme(docIR, theme, { colHeightPt = 500 } = {}) {
  const v = validateDocIR(docIR);
  if (!v.ok) throw new Error(`Invalid DocIR: ${v.errors.join('; ')}`);
  const tree = measure(docIR.blocks);
  const cols = reclaimPass(place(tree, colHeightPt));
  const emitOpts = {
    theme,
    baseLeading: (THEMES[theme] ?? THEMES.base).leading,
    headerText: docIR.headerText ?? '',
    headerDate: docIR.headerDate ?? null,
    headerOnTop: docIR.headerOnTop ?? true,
    footerText: docIR.footerText ?? '',
    alignment: docIR.alignment ?? 'justify',
    lang: resolveLang(docIR),
  };
  const source = emit(tree, emitOpts);
  return { tree, cols, source, emitOpts };
}

export function render(docIR, opts = {}) {
  return renderWithTheme(docIR, 'base', opts);
}
