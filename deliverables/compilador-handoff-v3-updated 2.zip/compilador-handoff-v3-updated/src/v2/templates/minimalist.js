// V2 template: bauhaus_minimalist. Compact deep-teal identity (see themes.js).
import { renderWithTheme } from './base.js';

export const name = 'bauhaus_minimalist';

export function render(docIR, opts = {}) {
  return renderWithTheme(docIR, 'bauhaus_minimalist', opts);
}
