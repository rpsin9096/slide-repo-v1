// V2 template registry: per-template switch for phased cutover.
// V2_TEMPLATE=base|bauhaus|bauhaus_minimalist (default: base).
import { render as base, name as baseName } from './base.js';
import { render as bauhaus, name as bauhausName } from './bauhaus.js';
import { render as minimalist, name as miniName } from './minimalist.js';

const REGISTRY = { [baseName]: base, [bauhausName]: bauhaus, [miniName]: minimalist };

export function renderWithTemplate(docIR, templateName) {
  const name = templateName ?? process.env.V2_TEMPLATE ?? docIR?.template ?? 'base';
  const fn = REGISTRY[name];
  if (!fn) throw new Error(`Unknown template: ${name} (want ${Object.keys(REGISTRY).join('|')})`);
  return { template: name, ...fn(docIR) };
}

export const TEMPLATES = Object.keys(REGISTRY);
