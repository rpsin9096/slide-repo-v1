// V2 theme identities. Mirrors the legacy palette (pdf-generator.js TEMPLATES):
// base = near-black editorial, bauhaus = sapphire studio, minimalist = deep teal.
import { convertInline } from '../drivers/typst/md.js';
import { DEFAULT_HEADER, formatDocDate, headerContent, footerContent } from './chrome.js';

export const THEMES = {
  base: {
    id: 'base',
    text: '#111827', muted: '#4B5563', accent: '#111827', accentSoft: '#F9FAFB',
    codebg: '#F9FAFB', rule: '#9CA3AF', font: 'Arimo',
    bodySize: '9.5pt', leading: '0.46em', parskip: '2.2pt',
    h1: '13pt', h2: '11pt', h3: '9.5pt', headGap: { 1: '8pt', 2: '7pt', 3: '6pt' },
    margin: { x: '1.0cm', top: '0.95cm', bottom: '1.0cm' }, gutter: '0.50cm',
    masthead: 'rule', // typographic split + horizontal rule
  },
  bauhaus: {
    id: 'bauhaus',
    text: '#0F172A', muted: '#64748B', accent: '#2563EB', accentSoft: '#EFF6FF',
    codebg: '#F1F5F9', rule: '#E2E8F0', font: 'Arimo',
    bodySize: '9pt', leading: '0.49em', parskip: '2.8pt',
    h1: '13pt', h2: '11pt', h3: '9.5pt', headGap: { 1: '10pt', 2: '8pt', 3: '6pt' },
    margin: { x: '1.0cm', top: '0.8cm', bottom: '0.85cm' }, gutter: '0.53cm',
    masthead: 'card', cardRadius: '6pt', cardInset: '8pt', cardWest: '3pt',
  },
  bauhaus_minimalist: {
    id: 'bauhaus_minimalist',
    text: '#18181B', muted: '#52525B', accent: '#0F766E', accentSoft: '#F4F4F5',
    codebg: '#F4F4F5', rule: '#E4E4E7', font: 'Arimo',
    bodySize: '8pt', leading: '0.36em', parskip: '1.2pt',
    h1: '12pt', h2: '10pt', h3: '9pt', headGap: { 1: '7pt', 2: '6pt', 3: '5pt' },
    margin: { x: '0.8cm', top: '0.7cm', bottom: '0.7cm' }, gutter: '0.42cm',
    masthead: 'card', cardRadius: '2pt', cardInset: '4pt', cardWest: '3pt',
  },
};

const rgb = (hex) => `rgb("${hex}")`;

export function preamble(themeName, {
  headerText = '', headerDate = null, headerOnTop = true,
  footerText = '', alignment = 'justify', lang = 'pt',
} = {}) {
  const t = THEMES[themeName] ?? THEMES.base;
  const title = headerText.trim() || DEFAULT_HEADER;
  const date = formatDocDate(headerDate);
  const header = headerOnTop
    ? `#set page(header: ${headerContent(t, { title: convertInline(title), date: convertInline(date) })})`
    : '';
  // Footer-left mirrors legacy: header title when the header lives on the
  // footer, otherwise the document title. Page number is always RIGHT.
  const left = headerOnTop ? convertInline(footerText) : convertInline(title);
  const footer = `#set page(footer: ${footerContent(t, { left })})`;
  return [
    `#set page(columns: 2, paper: "a4", margin: (x: ${t.margin.x}, top: ${t.margin.top}, bottom: ${t.margin.bottom}))`,
    `#set columns(gutter: ${t.gutter})`,
    `#set text(font: "${t.font}", size: ${t.bodySize}, fill: ${rgb(t.text)}, lang: "${lang}", hyphenate: true)`,
    `#set par(justify: ${alignment === 'left' ? 'false' : 'true'}, leading: ${t.leading}, spacing: 0pt)`,
    `#set heading(numbering: none)`,
    `#show heading.where(level: 1): set text(fill: ${rgb(t.accent)}, size: ${t.h1}, weight: "bold")`,
    `#show heading.where(level: 2): set text(fill: ${rgb(t.text)}, size: ${t.h2}, weight: "bold")`,
    `#show heading.where(level: 3): set text(fill: ${rgb(t.muted)}, size: ${t.h3}, weight: "bold")`,
    `#set list(marker: ([■], [–], [◦]), indent: 0.8em)`,
    `#set enum(numbering: "1.", indent: 0.8em)`,
    `#show link: set text(fill: ${rgb(t.accent)})`,
    `#show raw.where(block: false): it => box(fill: ${rgb(t.codebg)}, inset: (x: 3pt, y: 1pt), radius: 2pt)[#it]`,
    `#show quote.where(block: true): it => block(stroke: (left: 2pt + ${rgb(t.accent)}), inset: (left: 10pt, y: 4pt))[#it.body]`,
    header,
    footer,
  ].filter(Boolean).join('\n');
}

// Per-block masthead banner. Rendered only when masthead.enabled (or course/topic set).
export function masthead(box, themeName) {
  const m = box.masthead;
  if (!m || m.enabled === false) return '';
  const course = m.course || '', topic = m.topic || '';
  if (!course && !topic) return '';
  const t = THEMES[themeName] ?? THEMES.base;
  const inner = `#grid(columns: (1fr, 1fr), [#text(weight: "bold")[${convertInline(course)}]] , align(right)[${convertInline(topic)}])`;
  if (t.masthead === 'card') {
    return `#block(fill: ${rgb(t.accentSoft)}, stroke: (left: ${t.cardWest} + ${rgb(t.accent)}), radius: ${t.cardRadius}, inset: ${t.cardInset})[${inner}]`;
  }
  return `${inner}\n#line(length: 100%, stroke: 0.5pt + ${rgb(t.rule)})`;
}
