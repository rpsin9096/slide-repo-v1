/**
 * FocusGate / PDF Engine V2: Non-Blocking Compilation Job Pool
 * Executes CPU-intensive PDF layout and rendering jobs cooperatively via a
 * setImmediate-drained queue (single-threaded; NOT worker threads),
 * preventing event-loop starvation under high concurrency.
 */

import { runPipeline } from './pipeline.js';

class CooperativeCompilationPool {
  constructor(maxConcurrency = 4) {
    this.maxConcurrency = maxConcurrency;
    this.active = 0;
    this.queue = [];
    this.completed = 0;
    this.failed = 0;
  }

  /**
   * Dispatches a compile job, yielding to the Node event loop before execution.
   * @param {object} payload 
   * @param {object} [options={}]
   * @returns {Promise<Buffer>}
   */
  async runCompileJob(payload, options = {}) {
    return new Promise((resolve, reject) => {
      this.queue.push({ payload, options, resolve, reject });
      this._drain();
    });
  }

  _drain() {
    if (this.active >= this.maxConcurrency || this.queue.length === 0) {
      return;
    }

    const { payload, options, resolve, reject } = this.queue.shift();
    this.active++;

    // Yield to the event loop with setImmediate so other I/O is not starved
    setImmediate(async () => {
      try {
        // Single orchestrator: ingest gate → frozen IR → blast, with
        // stage telemetry and [CODE]-preserved errors. Returns the same
        // Buffer shape legacy emitPdf callers expect (buffer.pagination).
        const out = await runPipeline({
          payload,
          mode: 'pdf',
          seed: options.seed ?? options.correlationId ?? `pool-${this.completed + this.failed}`,
          timestamp: options.timestamp,
          template: options.template,
          options,
        });
        this.completed++;
        resolve(out.buffer);
      } catch (err) {
        this.failed++;
        reject(err);
      } finally {
        this.active--;
        this._drain();
      }
    });
  }

  status() {
    return {
      mode: 'cooperative-queue',
      maxConcurrency: this.maxConcurrency,
      active: this.active,
      queued: this.queue.length,
      completed: this.completed,
      failed: this.failed,
    };
  }
}

export const compilationPool = new CooperativeCompilationPool();
export const runCompileJob = (payload, options) => compilationPool.runCompileJob(payload, options);
export const poolStatus = () => compilationPool.status();
