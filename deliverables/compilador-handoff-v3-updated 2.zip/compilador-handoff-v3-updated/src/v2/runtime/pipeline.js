/**
 * FocusGate / PDF Engine V2: Single Pipeline Orchestrator
 *
 * The ONLY legal wiring order (ref-11 runtime/pipeline.ts:1-6):
 *   ingest (normalize + validate) → layout → paginate/pageMap vs renderPdf,
 *   with the pdfkit-vs-typst fork living here and nowhere else.
 *
 * Depth: thin orchestration only. All geometry stays in GeometryCompiler,
 * all bytes stay in drivers. Stages are timed via TelemetryBus (stage /
 * stageAsync / recordBlock / snapshot) with a deterministic correlationId
 * derived from the caller seed, so logs are reproducible.
 */

import { normalizeToDocIR, validateDocIR } from '../core/contracts.js';
import { createEngineEventBus } from '../core/events.js';
import { systemClock } from '../core/clock.js';
import { measure } from '../layout/coordinator.js';
import { resolveCalOpts } from '../layout/measure-calibration.js';
import { GeometryCompiler } from '../compiler/geometry-compiler.js';
import { PDFKitVectorBlaster, createMeasureContext } from '../drivers/pdfkit/blaster.js';
import { emit as emitTypst } from '../drivers/typst/emitter.js';
import { countCommands } from '../core/display-list.js';
import { shaper } from '../fonts/shaping.js';

export const PIPELINE_MODES = ['pdf', 'paginate', 'typst-source'];

/**
 * Typed pipeline failure preserving [CODE] across boundaries
 * (ref-11 runtime/pool.ts:153-160 restorePipelineError).
 */
export class PipelineError extends Error {
  constructor(code, message, detail = null) {
    super(`[${code}] ${message}`);
    this.name = 'PipelineError';
    this.code = code;
    this.detail = detail;
  }
}

export function restorePipelineError(err) {
  if (err instanceof PipelineError) return err;
  const text = String((err && err.message) || err || '');
  const m = text.match(/^\[([A-Z0-9_]+)\]\s*/);
  if (m) return new PipelineError(m[1], text.slice(m[0].length), err);
  return new PipelineError('PIPELINE_FAILED', text || 'pipeline failed', err);
}

/**
 * Deterministic correlation id from a seed (FNV-1a hex, zero-dep).
 * Same seed → same id, so stage logs are reproducible.
 */
export function createCorrelationId(seed = 'pipeline') {
  const s = String(seed ?? 'pipeline');
  let h = 0x811c9dc5;
  for (let k = 0; k < s.length; k++) {
    h ^= s.charCodeAt(k);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return `pipe-${h.toString(16).padStart(8, '0')}`;
}

/**
 * Stage telemetry bus: records per-stage durationMs + optional memory delta.
 * Backed by EngineEventBus for lifecycle fan-out.
 * Avoids synchronous V8 heap-space walks (`process.memoryUsage()`) by default
 * to keep Cloudflare Worker isolate CPU time minimal.
 */
export class TelemetryBus {
  constructor(eventBus = null, correlationId = null, trackMemory = false) {
    this.bus = eventBus || createEngineEventBus({ trackMemory });
    this.correlationId = correlationId || createCorrelationId();
    this.trackMemory = Boolean(trackMemory);
    this.stages = [];
    this.blocks = [];
  }

  _mem() {
    if (!this.trackMemory) return 0;
    try {
      return typeof process !== 'undefined' && typeof process.memoryUsage === 'function'
        ? process.memoryUsage().heapUsed
        : 0;
    } catch { return 0; }
  }

  stage(name, fn) {
    const start = Date.now();
    const mem0 = this._mem();
    try {
      const out = fn();
      this._record(name, start, mem0);
      return out;
    } catch (err) {
      this._record(name, start, mem0, err);
      throw err;
    }
  }

  async stageAsync(name, fn) {
    const start = Date.now();
    const mem0 = this._mem();
    try {
      const out = await fn();
      this._record(name, start, mem0);
      return out;
    } catch (err) {
      this._record(name, start, mem0, err);
      throw err;
    }
  }

  recordBlock(blockId, durationMs, meta = {}) {
    this.blocks.push({ blockId, durationMs, ...meta });
  }

  _record(name, start, mem0, err = null) {
    const rec = {
      name,
      correlationId: this.correlationId,
      durationMs: Date.now() - start,
      memoryDeltaBytes: this.trackMemory ? (this._mem() - mem0) : 0,
      ...(err ? { failed: true, error: String((err && err.message) || err) } : {}),
    };
    this.stages.push(rec);
    this.bus.emit('pipeline:stage', rec);
  }

  snapshot() {
    const totalMs = this.stages.reduce((a, s) => a + (s.durationMs || 0), 0);
    return { correlationId: this.correlationId, stages: [...this.stages], blocks: [...this.blocks], totalMs };
  }
}

/**
 * Fast page estimator for sync-vs-queued routing (no layout).
 * @param {object} payload raw payload or DocumentIR-ish
 * @returns {{ estimatedPages: number, route: 'sync'|'queued', chars: number, tables: number }}
 */
export function estimatePages(payload = {}, opts = {}) {
  const blocks = Array.isArray(payload.blocks) ? payload.blocks : [];
  let chars = 0;
  let tables = 0;
  if (blocks.length > 0) {
    for (const b of blocks) {
      const md = (b && b.markdown) || '';
      chars += md.length;
      const rows = (md.match(/^\s*\|/gm) || []).length;
      tables += rows;
    }
  } else if (typeof payload.markdown === 'string') {
    chars = payload.markdown.length;
    tables = (payload.markdown.match(/^\s*\|/gm) || []).length;
  } else if (payload.ast && Array.isArray(payload.ast.blocks)) {
    tables = payload.ast.blocks.filter(b => b.type === 'table').length;
    chars = blocks.length * 750;
  }
  const pages = Math.max(1, Math.ceil((chars + tables * 100) / (opts.charsPerPage || 7500)));
  return {
    estimatedPages: pages,
    route: pages > (opts.queueAbovePages || 50) ? 'queued' : 'sync',
    chars,
    tables,
  };
}

const compiler = new GeometryCompiler();

function resolveDocIR(input = {}) {
  // Accept raw payload, { payload }, { source }, or pre-normalized { docIR }.
  const payload = input.docIR || input.payload || input.source || input;
  return normalizeToDocIR(payload);
}

/**
 * Runs the canonical pipeline.
 *
 * @param {object} request
 * @param {object} [request.payload|source|docIR] document input
 * @param {'pdf'|'paginate'|'typst-source'} [request.mode='pdf']
 * @param {string} [request.template] overrides docIR.template
 * @param {string|number} [request.seed] correlation id seed
 * @param {object} [request.clock] ClockPort (default systemClock)
 * @param {number} [request.timestamp] pinned epoch-ms for deterministic bytes
 * @param {Function} [request.measure] injected word measurer (DI seam)
 * @param {object} [request.options] forwarded compile/emit options
 * @param {object} [request.eventBus] external EngineEventBus
 * @returns {Promise<object>} { mode, docIR, displayList?, buffer?, pagination?, source?, telemetry }
 */
export async function runPipeline(request = {}) {
  const mode = request.mode || 'pdf';
  if (!PIPELINE_MODES.includes(mode)) {
    throw new PipelineError('UNKNOWN_MODE', `mode must be one of ${PIPELINE_MODES.join(', ')}`);
  }
  const clock = request.clock || systemClock;
  const telemetry = new TelemetryBus(
    request.eventBus || null,
    createCorrelationId(request.seed ?? request.correlationId ?? mode),
    Boolean(request.trackMemory)
  );
  const compileOpts = { ...(request.options || {}) };
  if (request.template) compileOpts.template = request.template;
  if (request.geometry) compileOpts.geometry = request.geometry;
  const rawInput = request.payload || request.source || request.docIR || request;
  if (rawInput && typeof rawInput === 'object') {
    if (rawInput.geometry && !compileOpts.geometry) compileOpts.geometry = rawInput.geometry;
    if (rawInput.chapters_toc !== undefined && compileOpts.chapters_toc === undefined) compileOpts.chapters_toc = rawInput.chapters_toc;
    if (rawInput.chaptersToc !== undefined && compileOpts.chaptersToc === undefined) compileOpts.chaptersToc = rawInput.chaptersToc;
    if (rawInput.toc_include_headings !== undefined && compileOpts.toc_include_headings === undefined) compileOpts.toc_include_headings = rawInput.toc_include_headings;
  }
  if (request.timestamp !== undefined) compileOpts.timestamp = request.timestamp;
  else if (compileOpts.timestamp === undefined) {
    try { compileOpts.timestamp = clock.now().getTime(); } catch { /* leave unset */ }
  }

  try {
    // Stage 1 — ingest gate: normalize + strict validate.
    const docIR = telemetry.stage('ingest', () => {
      const doc = resolveDocIR(request);
      const v = validateDocIR(doc);
      if (!v.ok) throw new PipelineError('INGEST_SCHEMA_REJECTED', v.errors.slice(0, 3).join('; '), v.errors);
      return doc;
    });
    const template = compileOpts.template || docIR.template || 'base';

    if (mode === 'typst-source') {
      // Typst fork: pure transpile from measured boxes. Never touches PDFKit
      // and never falls back to it (ref-11 typst-transpiler fatal TYPST_*).
      const source = await telemetry.stageAsync('transpile-typst', async () => {
        const calOpts = resolveCalOpts(compileOpts);
        if (calOpts.mode === 'real' && typeof calOpts.measure !== 'function') {
          calOpts.measure = (w, f, s) => shaper.measure(w, f, s, compileOpts.fontAssets || null);
        }
        const tree = measure(docIR.blocks, calOpts);
        return emitTypst(tree, { ...compileOpts, docIR, template });
      });
      return { mode, docIR, source, telemetry: telemetry.snapshot() };
    }

    // Canonical fork: compile to frozen DisplayList (exact pagination).
    // Live word measurer (DI): same fonts the blaster renders with.
    let dispose = null;
    if (typeof compileOpts.measure !== 'function' && typeof request.measure === 'function') {
      compileOpts.measure = request.measure;
    }
    if (typeof compileOpts.measure !== 'function') {
      try {
        const ctx = createMeasureContext(template, compileOpts.fontAssets || request.fontAssets || null);
        dispose = ctx.dispose;
        compileOpts.measure = ctx.measure;
        if (!compileOpts.measureImage && ctx.measureImage) compileOpts.measureImage = ctx.measureImage;
      } catch {
        compileOpts.measure = (w, f, s) => shaper.measure(w, f, s, compileOpts.fontAssets || null);
      }
    }

    try {
      const displayList = await telemetry.stageAsync('layout', async () => compiler.compile(docIR, compileOpts));
      const commands = countCommands(displayList);
      const pagination = displayList.pagination || {
        totalPages: displayList.totalPages || displayList.pages.length,
        hasToC: Boolean(displayList.toc && displayList.toc.enabled),
        chaptersToc: Boolean(displayList.toc && displayList.toc.enabled),
        tocPage: (displayList.toc && displayList.toc.enabled) ? 1 : null,
        sections: displayList.toc ? displayList.toc.sections : [],
      };

      const fitGate = {
        maxOverflows: 0, maxOverflowPt: 0.5, warnOnly: true,
        ...((request.fitGate || compileOpts.fitGate) || {}),
      };
      const warnings = [];
      const fit = displayList.diagnostics && displayList.diagnostics.fit;
      if (fit && !fit.skipped) {
        const breached = fit.overflows > fitGate.maxOverflows || fit.maxOverflowPt > fitGate.maxOverflowPt;
        if (breached) {
          const detail = `estimate-render drift: ${fit.overflows} overflows (max ${fitGate.maxOverflows}), `
            + `worst +${fit.maxOverflowPt}pt (max +${fitGate.maxOverflowPt}pt) over ${fit.checked} text elements`
            + (fit.worst && fit.worst.length ? `: ${fit.worst.map(w => `"${w.text}" +${w.overflowPt}pt`).join('; ')}` : '');
          if (fitGate.warnOnly) {
            warnings.push(detail);
            telemetry.stage('fit-gate:warn', () => detail);
          } else {
            throw new PipelineError('FIT_GATE', detail, fit);
          }
        }
      }

      if (mode === 'paginate') {
        return {
          mode, docIR, displayList, pagination, commands, warnings,
          totalPages: pagination.totalPages,
          telemetry: telemetry.snapshot(),
        };
      }

      // mode === 'pdf'
      const buffer = await telemetry.stageAsync('render-pdf', async () =>
        PDFKitVectorBlaster.blast(displayList, compileOpts));
      buffer.pagination = buffer.pagination || pagination;
      return {
        mode, docIR, displayList, pagination, commands, buffer, warnings,
        totalPages: pagination.totalPages,
        telemetry: telemetry.snapshot(),
      };
    } finally {
      if (dispose) { try { dispose(); } catch { /* already closed */ } }
    }
  } catch (err) {
    throw restorePipelineError(err);
  }
}

export default { runPipeline, estimatePages, TelemetryBus, PipelineError, createCorrelationId };
