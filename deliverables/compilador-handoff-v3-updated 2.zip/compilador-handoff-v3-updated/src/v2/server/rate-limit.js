/**
 * Dependency-free fixed-window rate limiter (CC4 step 2).
 *
 * Stopgap until `express-rate-limit` is adopted: bounds expensive endpoints
 * (PDF converts, uploads) per client key with 429 + Retry-After. Pure logic
 * with injectable `now`/`keyOf` so lean tests need no HTTP server.
 */

const SWEEP_LIMIT = 5000;

/**
 * @param {object} [opts]
 * @param {number} [opts.windowMs] fixed window length (default 60s)
 * @param {number} [opts.max] max requests per window per key
 * @param {Function} [opts.keyOf] `(req) => string` client key (default req.ip)
 * @param {Function} [opts.now] clock for tests (default Date.now)
 * @param {string} [opts.message] 429 detail message
 * @returns express middleware with `.reset()` / `.stats()` test hooks
 */
export function createRateLimiter({
  windowMs = 60000,
  max = 60,
  keyOf = (req) => (req && (req.ip || req.socket?.remoteAddress)) || 'unknown',
  now = () => Date.now(),
  message = 'Muitas requisições — tente novamente em instantes',
} = {}) {
  const hits = new Map(); // key -> { count, resetAt }

  const sweep = (t) => {
    for (const [k, slot] of hits) {
      if (slot.resetAt <= t) hits.delete(k);
    }
  };

  function rateLimiter(req, res, next) {
    const t = now();
    const key = keyOf(req);
    let slot = hits.get(key);
    if (!slot || slot.resetAt <= t) {
      slot = { count: 0, resetAt: t + windowMs };
      hits.set(key, slot);
      if (hits.size > SWEEP_LIMIT) sweep(t);
    }
    slot.count += 1;
    if (slot.count > max) {
      const retryAfter = Math.max(1, Math.ceil((slot.resetAt - t) / 1000));
      try { res.set?.('Retry-After', String(retryAfter)); } catch { /* header-only */ }
      return res.status(429).json({ detail: message });
    }
    next();
  }

  rateLimiter.reset = () => hits.clear();
  rateLimiter.stats = () => ({ keys: hits.size, windowMs, max });
  return rateLimiter;
}

/** Env-tunable int with fallback (ops knob, e.g. RATE_LIMIT_CONVERT). */
export function envInt(name, fallback) {
  const raw = Number(process.env[name]);
  return Number.isFinite(raw) && raw > 0 ? Math.floor(raw) : fallback;
}
