import { decorateDisplayListV3, resolveFrameAndTokens, computeMultiPageTocLayout } from './v3/index.js';
/**
 * FocusGate / PDF Engine V2: Pure Geometry Compiler
 * 
 * Compiles DocumentIR + Template into an immutable DisplayList (Vector AST).
 * 100% pure mathematical layout calculation:
 * - Solves two-pass LaTeX multicol column balancing (col2 <= col1).
 * - Solves optical cap-height decorator centering (within 0.15pt).
 * - Enforces anti-orphan heading headroom (>= 24pt).
 * - Distributes elastic rubber glue (slack <= 36pt).
 * - Emits zero canvas/PDFKit dependencies.
 */

import { TEMPLATES } from '../templates/definitions.js';
import { rhythmForTemplate, headingSpaceBefore } from '../templates/definitions.js';
import { DEFAULT_HEADER } from '../templates/chrome.js';
import { getFontMetrics, calculateStringWidth } from '../fonts/metrics.js';
import { GalleyEngine, AntiOrphanGuard } from '../layout/galley-engine.js';
import { normalizeToDocIR, validateDocIR } from '../core/contracts.js';
import { TypographicAutofix, TagSanitizer } from '../ingest/sanitizer.js';
import { systemClock } from '../core/clock.js';
import { formatDocumentDate as formatSharedDocDate } from '../core/date.js';
import { TableLayoutEngine, wrapTableCellText, stripInlineMetrics, cachedHyphenPoints, longestFittingPrefix, estimateFitLen, LONG_TOKEN_CHARS, MAX_HYPHEN_PTS_LEN } from '../modules/table-module.js';
import { InlineMath } from '../modules/math-module.js';
import { V2_COLOR_TOKENS, V2_SPACING_TOKENS, V2_STROKE_TOKENS, V2_TYPE_SCALE, resolveColor } from '../core/tokens.js';
import { q } from '../core/geometry.js';
import { freezeIR } from '../core/display-list.js';
import { decideTableSpan as coordDecideTableSpan, decideImageSpan as coordDecideImageSpan, isSpan as coordIsSpan, isRuleSpan as coordIsRuleSpan } from '../layout/span-coordinator.js';
import { makeSeam, capacityForClass, classForItemKind, elementExtent, SEAM_CLASS } from '../layout/stretch-seam.js';
import { resolveSeams, computeElementShifts, capShiftsToFoot, accumulateAtY, accumulateMaxAtY, boundedLift, STRETCH_CEILING_PITCH_RATIO } from '../layout/glue-allocator.js';

const A4_WIDTH = 595.28;
const A4_HEIGHT = 841.89;

/**
 * Header date formatter: delegates to the shared single source of truth
 * (doc-date.js), keeping the ClockPort seam for deterministic tests.
 */
function formatV2HeaderDate(dateOpts, clock = systemClock) {
  return formatSharedDocDate(dateOpts, clock.now());
}

/**
 * Minimal inline-markdown scanner → styled runs.
 * Handles **bold**, __bold__, *italic*, _italic_, `code`, ~~strike~~.
 * Unmatched markers stay literal so no content is ever lost.
 * @param {string} text
 * @returns {{ text: string, style: string }[]}
 */
const INLINE_TRIGGER_RE = /[*_~`$]/;
const INLINE_PATTERNS_BY_CHAR = {
  '*': [
    { re: /^\*\*\*([^*]+)\*\*\*/, style: 'bold_italic', isContainer: true },
    { re: /^\*\*(.+?)\*\*/, style: 'bold', isContainer: true },
    { re: /^\*([^*]+?)\*/, style: 'italic', isContainer: true },
  ],
  '_': [
    { re: /^__(.+?)__/, style: 'bold', isContainer: true },
    { re: /^_([^_]+?)_/, style: 'italic', isContainer: true },
  ],
  '~': [
    { re: /^~~(.+?)~~/, style: 'normal', isContainer: true },
  ],
  '`': [
    { re: /^`(.+?)`/, style: 'code', isContainer: false },
  ],
  '$': [
    { re: /^\$([^\$\n]+?)\$/, style: 'math', isContainer: false },
  ],
};

export function parseInlineRuns(text, inheritedStyle = 'normal') {
  const src = text || '';
  if (!src || !INLINE_TRIGGER_RE.test(src)) {
    return [{ text: src, style: inheritedStyle }];
  }
  const runs = [];
  let rest = src;
  let buf = '';
  const flush = () => {
    if (buf) {
      const last = runs[runs.length - 1];
      if (last && last.style === inheritedStyle) last.text += buf;
      else runs.push({ text: buf, style: inheritedStyle });
      buf = '';
    }
  };
  while (rest.length > 0) {
    const nextIdx = rest.search(INLINE_TRIGGER_RE);
    if (nextIdx === -1) {
      buf += rest;
      break;
    }
    if (nextIdx > 0) {
      buf += rest.slice(0, nextIdx);
      rest = rest.slice(nextIdx);
    }
    const candidates = INLINE_PATTERNS_BY_CHAR[rest[0]];
    let matched = false;
    if (candidates) {
      for (let i = 0; i < candidates.length; i++) {
        const p = candidates[i];
        const m = rest.match(p.re);
        if (m) {
          flush();
          if (p.isContainer) {
            let mergedStyle = p.style;
            if (inheritedStyle === 'bold' && p.style === 'italic') mergedStyle = 'bold_italic';
            else if (inheritedStyle === 'italic' && p.style === 'bold') mergedStyle = 'bold_italic';
            else if (inheritedStyle === 'bold' || inheritedStyle === 'italic' || inheritedStyle === 'bold_italic') mergedStyle = inheritedStyle;

            const innerRuns = parseInlineRuns(m[1], mergedStyle);
            for (const ir of innerRuns) {
              const last = runs[runs.length - 1];
              if (last && last.style === ir.style) last.text += ir.text;
              else runs.push(ir);
            }
          } else if (p.style === 'math') {
            if (InlineMath.looksLikeMath(m[1])) {
              flush();
              for (const mr of InlineMath.expand(m[1])) {
                const last = runs[runs.length - 1];
                if (last && last.style === mr.style) last.text += mr.text;
                else runs.push({ text: mr.text, style: mr.style });
              }
            } else {
              buf += m[0];
            }
          } else {
            const last = runs[runs.length - 1];
            if (last && last.style === p.style) last.text += m[1];
            else runs.push({ text: m[1], style: p.style });
          }
          rest = rest.slice(m[0].length);
          matched = true;
          break;
        }
      }
    }
    if (!matched) {
      buf += rest[0];
      rest = rest.slice(1);
    }
  }
  flush();
  if (runs.length === 0) runs.push({ text: '', style: inheritedStyle });
  return runs;
}

// Relative width factors vs the base Helvetica AFM table (bold/code run
// wider in Arimo reality; without this, wrapped bold lines overflow).
const FONT_WIDTH_FACTOR = {
  'helvetica': 1,
  'helvetica-bold': 1.07,
  'helvetica-oblique': 1.0,
  'courier': 1.08,
  'times': 0.9,
};

function runFontOf(baseFont, style) {
  if (style === 'code') return 'courier';
  if (style === 'bold' || style === 'bold_italic') return 'helvetica-bold';
  if (style === 'italic' || style === 'math' || style === 'math-sub' || style === 'math-super') return (baseFont === 'helvetica-bold') ? 'helvetica-bold' : 'helvetica-oblique';
  return baseFont;
}

// Sub/superscript fallback runs render at 0.72× (same factor in the blaster,
// so estimated width == rendered width by construction).
function runSizeFactor(style) {
  if (style === 'math-sub' || style === 'math-super') return 0.72;
  return 1;
}

function wordWidth(word, font, size) {
  return calculateStringWidth(word, 'helvetica', size) * (FONT_WIDTH_FACTOR[font] || 1);
}

// v1 list metrics (pdf-generator.js renderList parity: base body sizes,
// per-template indent/marker geometry, item spacing, marker glyphs).
function listBodySize(tmpl, level) {
  const base = tmpl.fontSize === 8 ? 8 : tmpl.fontSize === 9 ? 8.5 : 9.2;
  const deepScale = tmpl.tokens?.list?.deepSizeScale ?? (tmpl.fontSize === 9.5);
  if (!deepScale) return base;
  if (level === 3) return 9.0;
  if (level === 4 || level === 5) return 8.5;
  if (level >= 6) return 8.0;
  return base;
}

function listGeometry(tmpl, level, ordered) {
  const lt = tmpl.tokens?.list || {};
  const step = lt.step ?? (tmpl.fontSize === 8 ? 7.5 : (tmpl.fontSize === 9 ? 8.5 : 9.0));
  const markerW = ordered
    ? (lt.markerWOrdered ?? (tmpl.fontSize === 9.5 ? 13 : 12))
    : (lt.markerWUnordered ?? (tmpl.fontSize === 8 ? 8 : (tmpl.fontSize === 9 ? 9 : 9.5)));
  const labelSep = lt.labelSep ?? (tmpl.fontSize === 9.5 ? 3.0 : 2.5);
  const labelIndent = lt.labelIndent ?? (tmpl.fontSize === 9.5 ? 2.0 : 1.5);
  const baseIndent = (level - 1) * step;
  return {
    baseIndent,
    markerW,
    labelSep,
    labelIndent,
    textOff: baseIndent + labelIndent + markerW + labelSep,
    markerXOff: baseIndent + labelIndent,
  };
}

function listItemSep(tmpl, level) {
  const seps = tmpl.tokens?.list?.itemSep;
  if (Array.isArray(seps) && seps.length >= 3) {
    return level === 1 ? seps[0] : (level === 2 ? seps[1] : seps[2]);
  }
  return level === 1 ? 1.4 : (level === 2 ? 0.8 : 0.4);
}

function listTopSep(tmpl) {
  return tmpl.tokens?.list?.topSep ?? 1.2;
}

function listBottomSep(tmpl) {
  return tmpl.tokens?.list?.bottomSep ?? 1.5;
}

function toRomanV1(num) {
  const roman = ['i', 'ii', 'iii', 'iv', 'v', 'vi', 'vii', 'viii', 'ix', 'x'];
  return roman[(num - 1) % roman.length] || `${num}`;
}

function unorderedMarker(tmpl, level) {
  const C = tmpl.colors || {};
  const preset = tmpl.tokens?.list?.markerPreset || (tmpl.bulletL1 === 'dash' ? 'minimalist' : (tmpl.bulletL1 === 'circle_sapphire' ? 'modern' : 'compact'));
  if (preset === 'minimalist') {
    if (level === 1) return { kind: 'text', text: '–', color: resolveColor(tmpl, 'textMain') };
    if (level === 2) return { kind: 'text', text: '–', color: resolveColor(tmpl, 'textMuted') };
    if (level === 3) return { kind: 'vector', style: 'hollow_square', r: 1.4, color: resolveColor(tmpl, 'textMuted') };
    if (level % 2 === 0) return { kind: 'text', text: '-', color: resolveColor(tmpl, 'textGray') };
    return { kind: 'vector', style: 'square', r: 1.0, color: resolveColor(tmpl, 'textGray') };
  }
  if (preset === 'modern') {
    if (level === 1) return { kind: 'vector', style: 'circle_sapphire', r: 1.8, color: resolveColor(tmpl, 'accent') };
    if (level === 2) return { kind: 'text', text: '–', color: C.textmuted || '#475569' };
    if (level === 3) return { kind: 'vector', style: 'hollow_circle', r: 1.6, color: C.textmuted || '#475569' };
    if (level % 2 === 0) return { kind: 'text', text: '–', color: C.textgray || C.textmuted || '#64748B' };
    return { kind: 'vector', style: 'circle', r: 1.3, color: C.textgray || C.textmuted || '#64748B' };
  }
  if (level === 1) return { kind: 'vector', style: 'diamond_teal', r: 1.5, color: resolveColor(tmpl, 'accent') };
  if (level === 2) return { kind: 'text', text: '–', color: C.textmuted || '#52525B' };
  if (level === 3) return { kind: 'vector', style: 'hollow_circle', r: 1.4, color: C.textmuted || '#52525B' };
  if (level % 2 === 0) return { kind: 'text', text: '-', color: C.textgray || C.textmuted || '#6B6B76' };
  return { kind: 'vector', style: 'circle', r: 1.1, color: C.textgray || C.textmuted || '#6B6B76' };
}

function orderedMarkerProps(tmpl, level) {
  const C = tmpl.colors || {};
  const boldAll = tmpl.tokens?.list?.orderedBoldAllLevels ?? (tmpl.fontSize !== 9.5);
  if (!boldAll) {
    return {
      color: level === 1 ? (C.ruleblack || C.textmain || resolveColor(tmpl, 'ruleBlack')) : (level === 2 ? resolveColor(tmpl, 'textMuted') : resolveColor(tmpl, 'textGray')),
      bold: level === 1,
    };
  }
  return {
    color: level === 1 ? (C.textmain || resolveColor(tmpl, 'textMain')) : (level === 2 ? (C.textmuted || '#475569') : (C.textgray || C.textmuted || '#64748B')),
    bold: true,
  };
}

/**
 * Greedy word-wrap styled runs into exact lines. The renderer draws these
 * verbatim (no re-wrap), so estimated height == rendered height by
 * construction and vertical rhythm can never cascade out of sync.
 * @param {{ text: string, style: string }[]} runs
 * @param {string} baseFont
 * @param {number} size
 * @param {number} availW
 * @param {(word: string, fontName: string, size: number) => number|null} [measure]
 *   Live measurer (same fonts the blaster renders with). When omitted or
 *   when it returns null, falls back to AFM tables with width factors.
 * @returns {{ runs: { text: string, style: string }[], width: number }[]}
 */
const NBSP_FAMILY_GLOBAL_RE = /[\u00A0\u2007\u202F]/g;
const NBSP_FAMILY_TEST_RE = /[\u00A0\u2007\u202F]/;
const BREAKABLE_WS_RE = /([^\S\u00A0\u2007\u202F]+)/;
const LEAD_PUNCT_RE = /^[,.;:!?)\]}%‰'…»"“”‘’]+/u;

export function wrapRunsToLines(runs, baseFont, size, availW, measure = null, opts = {}) {
  const breakNbsp = opts && opts.breakNbsp === true;
  const srcRuns = breakNbsp
    ? (runs || []).map((r) => (r && typeof r.text === 'string' && NBSP_FAMILY_TEST_RE.test(r.text)
      ? { ...r, text: r.text.replace(NBSP_FAMILY_GLOBAL_RE, ' ') }
      : r))
    : runs;
  const tableMeasure = (word, font, style) =>
    calculateStringWidth(word, 'helvetica', size * runSizeFactor(style)) * (FONT_WIDTH_FACTOR[font] || 1);
  const M = (word, font, style = 'normal') => {
    const effSize = size * runSizeFactor(style);
    if (typeof measure === 'function') {
      try {
        const w = measure(word, font, effSize);
        if (typeof w === 'number' && isFinite(w)) return w;
      } catch { /* fall through to tables */ }
    }
    return tableMeasure(word, font, style);
  };
  const safeW = Math.max(10, availW - (measure ? 3 : 6));
  const spaceWCache = Object.create(null);
  const spaceWFor = (style) => {
    const s = style || 'normal';
    let w = spaceWCache[s];
    if (w === undefined) {
      w = M(' ', runFontOf(baseFont, s), s);
      spaceWCache[s] = w;
    }
    return w;
  };
  const words = [];
  const splitLongWord = (text, style) => {
    const parts = [];
    const font = runFontOf(baseFont, style);
    if (text.length > LONG_TOKEN_CHARS) {
      const estLen = estimateFitLen(M(text.slice(0, 32), font, style), 32, safeW);
      let idx = 0;
      while (idx < text.length) {
        const chunk = text.slice(idx, idx + estLen);
        idx += estLen;
        const last = idx >= text.length;
        const hasTrailHyphen = chunk.endsWith('-') || chunk.endsWith('–') || chunk.endsWith('/');
        const pieceText = chunk + (!last && !hasTrailHyphen ? '-' : '');
        parts.push({ text: pieceText, style, space: false, width: M(pieceText, font, style) });
      }
      return parts.length > 0 ? parts : [{ text, style, space: false, width: M(text, font, style) }];
    }
    let remaining = text;

    while (remaining.length > 0) {
      const wClean = M(remaining, font, style);
      if (wClean <= safeW) {
        parts.push({ text: remaining, style, space: false, width: wClean });
        break;
      }

      let splitIdx = -1;
      let needHyphen = true;
      let fittedPieceW = -1;
      if (remaining.length < 6) {
        parts.push({ text: remaining, style, space: false, width: wClean });
        break;
      }
      const curPts = remaining.length > MAX_HYPHEN_PTS_LEN ? [] : cachedHyphenPoints(remaining);

      // 1. Syllable / pre-existing hyphen/slash points (minima-filtered)
      for (let pi = curPts.length - 1; pi >= 0; pi--) {
        const pt = curPts[pi];
        if (!pt.hasHyphen) {
          const leftLen = pt.index + 1;
          const rightLen = remaining.length - leftLen;
          if (leftLen < 2 || rightLen < 3) continue;
        }
        const piece = remaining.slice(0, pt.index + 1);
        const pieceW = M(piece + (pt.hasHyphen ? '' : '-'), font, style);
        if (pieceW <= safeW) {
          splitIdx = pt.index + 1;
          needHyphen = !pt.hasHyphen;
          fittedPieceW = pieceW;
          break;
        }
      }

      // 2. Character-by-character fallback if no syllable point fits
      if (splitIdx === -1) {
        splitIdx = longestFittingPrefix(
          remaining,
          (piece) => piece.length >= 2
            && (remaining.length - piece.length === 0 || remaining.length - piece.length >= 3)
            && M(piece + '-', font, style) <= safeW,
          2,
        );
        needHyphen = true;
      }

      if (splitIdx === -1) {
        parts.push({ text: remaining, style, space: false, width: wClean });
        break;
      }

      const part = remaining.slice(0, splitIdx);
      const hasTrailHyphen = part.endsWith('-') || part.endsWith('–') || part.endsWith('/');
      const emittedText = part + (needHyphen && !hasTrailHyphen ? '-' : '');
      const emittedW = fittedPieceW >= 0 ? fittedPieceW : M(emittedText, font, style);
      parts.push({ text: emittedText, style, space: false, width: emittedW });
      remaining = remaining.slice(splitIdx);
    }

    return parts.length > 0 ? parts : [{ text, style, space: false, width: M(text, font, style) }];
  };

  for (let ri = 0; ri < (srcRuns ? srcRuns.length : 0); ri++) {
    const run = srcRuns[ri];
    if (!run || !run.text) continue;
    const rStyle = run.style || 'normal';
    const rFont = runFontOf(baseFont, rStyle);
    const parts = run.text.split(BREAKABLE_WS_RE);
    for (let pi = 0; pi < parts.length; pi++) {
      const p = parts[pi];
      if (!p) continue;
      if ((pi & 1) === 1 && !NBSP_FAMILY_TEST_RE.test(p)) {
        words.push({ text: p, style: rStyle, space: true, width: spaceWFor(rStyle) });
      } else {
        const ww = M(p, rFont, rStyle);
        if (ww > safeW) {
          words.push(...splitLongWord(p, rStyle));
        } else {
          words.push({ text: p, style: rStyle, space: false, width: ww });
        }
      }
    }
  }
  const lines = [];
  let cur = [];
  let curW = 0;
  const isGlueLeading = (w) => !w.space
    && ((w.style === 'math-sub' || w.style === 'math-super')
      || LEAD_PUNCT_RE.test(w.text || ''));
  const tokenW = (t) => t.width !== undefined
    ? t.width
    : (t.space ? spaceWFor(t.style) : M(t.text, runFontOf(baseFont, t.style), t.style));
  const pushLine = () => {
    while (cur.length > 0 && cur[0].space) cur.shift();
    while (cur.length > 0 && cur[cur.length - 1].space) cur.pop();
    if (cur.length === 0) return;
    const lineRuns = [];
    for (let i = 0; i < cur.length; i++) {
      const t = cur[i];
      const last = lineRuns[lineRuns.length - 1];
      if (last && last.style === t.style) last.text += t.text;
      else lineRuns.push({ text: t.text, style: t.style });
    }
    lines.push({ runs: lineRuns, width: curW });
    cur = [];
    curW = 0;
  };
  for (let wi = 0; wi < words.length; wi++) {
    const w = words[wi];
    if (w.space) {
      cur.push(w);
      curW += w.width;
      continue;
    }
    const ww = w.width;
    if (cur.length > 0 && curW + ww > safeW) {
      if (isGlueLeading(w)) {
        let gj = cur.length - 1;
        while (gj >= 0 && (cur[gj].space || isGlueLeading(cur[gj]))) gj--;
        if (gj >= 0) {
          const tail = cur.splice(gj);
          for (let ti = 0; ti < tail.length; ti++) curW -= tokenW(tail[ti]);
          pushLine();
          for (let ti = 0; ti < tail.length; ti++) { cur.push(tail[ti]); curW += tokenW(tail[ti]); }
          cur.push(w);
          curW += ww;
          continue;
        }
      }
      pushLine();
    }
    cur.push(w);
    curW += ww;
  }
  pushLine();
  if (lines.length === 0) lines.push({ runs: [{ text: '', style: 'normal' }], width: 0 });
  return lines;
}

/**
 * Builds an editorial masthead lockup: strong title + subtitle on the left,
 * metadata stack on the right, template-specific accent treatment.
 * Returns { elements, height } with the height measured from live text.
 */
function buildMastheadElements(tmpl, masthead, docTitle, dateText, headerTitle, leftM, printableW, measureFn) {
  const course = (masthead.course || '').trim();
  const topic = (masthead.topic || '').trim();
  const prefix = (masthead.prefix || '').trim().replace(/[:\-–—\s]+$/, '');
  const rawDocTitle = docTitle ? String(docTitle).trim() : '';
  const validDocTitle = rawDocTitle === 'Document' ? '' : rawDocTitle;

  // Placeholder Correction: Ensure the "Document" placeholder is replaced by adapted Masthead logic.
  // When course is missing, adapt the true document title (or section title) as the primary title.
  const title = course
    ? course.toUpperCase()
    : (validDocTitle ? validDocTitle.toUpperCase() : (masthead.title ? masthead.title.toUpperCase() : ''));
  const subtitle = topic;

  // In the metadata stack on the right:
  // If validDocTitle duplicates the masthead title or subtitle, do not repeat it.
  const isDuplicateInMeta = !validDocTitle ||
    validDocTitle.toUpperCase() === title ||
    validDocTitle.toUpperCase() === subtitle.toUpperCase();
  const metaTitle = isDuplicateInMeta ? '' : validDocTitle;

  const date = (dateText || '').trim();
  const header = (headerTitle || '').trim();

  // Template-specific layout metrics & padding (Layer-3 masthead tokens)
  const mt = tmpl.tokens?.masthead || {};
  const padX = mt.padX ?? 0;
  const padY = mt.padY ?? 8;
  const titleGap = mt.titleGap ?? 2;
  const colGap = mt.colGap ?? 16;

  const mutedColor = resolveColor(tmpl, 'textMuted');
  const textMain = resolveColor(tmpl, 'textMain');
  const accentColor = resolveColor(tmpl, 'accent');
  const surfaceColor = resolveColor(tmpl, 'surface');

  // Type scale per template from masthead tokens
  const titleSize = mt.titleSize ?? 13;
  const subSize = mt.subSize ?? 9.5;
  const metaSize = mt.metaSize ?? 7.5;
  const accentW = mt.accentW ?? 2;
  // Calibrated leading shares the body's fontRatio (Arimo 1.1499 /
  // Inter 1.21): PDFKit positions text by TOP, so each line's top plus its
  // full leading is the rendered extent — the container budget must cover
  // it, otherwise trailing lines collide with the accent/panel bottom.
  const lineRatio = tmpl.tokens?.fontRatio ?? 1.1499;
  const titleLH = titleSize * lineRatio;
  const subLH = subSize * lineRatio;
  const metaLH = metaSize * lineRatio;

  const naturalWidthOf = (text, font, size) => {
    if (!text) return 0;
    const style = font === 'helvetica-bold' ? 'bold' : 'normal';
    const lines = wrapRunsToLines([{ text, style }], 'helvetica', size, 2000, measureFn);
    return lines.reduce((m, ln) => Math.max(m, ln.width || 0), 0);
  };

  // Metadata owns the right stack, top to bottom: moved running-header
  // title (opt-in per block), then the date, then `[prefix: ]document
  // title`. Date-first keeps the short tertiary line anchored at the top
  // beside the title cap-height; the longer identifier sits beneath it.
  // Empty slots are omitted — never blank lines, never the placeholder.
  const metaRaw = [];
  if (header) metaRaw.push(header);
  if (date) metaRaw.push(date);
  if (prefix && metaTitle) metaRaw.push(`${prefix}: ${metaTitle}`);
  else if (prefix) metaRaw.push(prefix);
  else if (metaTitle) metaRaw.push(metaTitle);

  let metaColW = 0;
  if (metaRaw.length > 0) {
    const need = Math.max(...metaRaw.map((t) => naturalWidthOf(t, 'helvetica', metaSize)), 80) + 8;
    metaColW = Math.min(need, printableW * 0.38);
  }

  let leftW = printableW - padX * 2 - (metaRaw.length > 0 ? colGap + metaColW : 0);
  let stacked = false;
  if (metaRaw.length > 0 && leftW < 140) {
    // Narrow fallback: keep title readable, metadata right-aligned below it.
    stacked = true;
    leftW = printableW - padX * 2;
    metaColW = printableW - padX * 2;
  }

  const titleLines = title
    ? wrapRunsToLines([{ text: title, style: 'bold' }], 'helvetica', titleSize, leftW, measureFn)
    : [];
  const subLines = subtitle
    ? wrapRunsToLines([{ text: subtitle, style: 'normal' }], 'helvetica', subSize, leftW, measureFn)
    : [];
  const metaLineGroups = metaRaw.map((t) =>
    wrapRunsToLines([{ text: t, style: 'normal' }], 'helvetica', metaSize, stacked ? metaColW : metaColW, measureFn),
  );

  const elements = [];
  // Top-based stacking: PDFKit draws text from y downward, so each line's
  // recorded top plus its full leading is the true rendered extent.
  let leftCursor = padY;
  const leftTops = [];
  for (const ln of titleLines) {
    leftTops.push({ line: ln, top: leftCursor, size: titleSize, font: 'helvetica-bold', color: textMain });
    leftCursor += titleLH;
  }
  if (titleLines.length > 0 && subLines.length > 0) {
    // All-caps titles leave the descent zone empty: reclaim the last title
    // line's descent (~0.24em) so titleGap reads as the true visual gap.
    leftCursor += titleGap - titleSize * 0.24;
  }
  for (const ln of subLines) {
    leftTops.push({ line: ln, top: leftCursor, size: subSize, font: 'helvetica', color: mutedColor });
    leftCursor += subLH;
  }

  const metaTops = [];
  let metaCursor;
  if (!stacked) metaCursor = padY;
  else metaCursor = Math.max(leftCursor, padY) + 4;
  for (const group of metaLineGroups) {
    for (const ln of group) {
      metaTops.push({ line: ln, top: metaCursor });
      metaCursor += metaLH;
    }
  }

  const contentBottom = Math.max(leftCursor, metaCursor, padY);
  const height = contentBottom + padY;

  // Template-specific container treatment: polished editorial cards & framing
  const mastStyle = mt.style || (tmpl.mastheadStyle === 'tcolorbox_soft' ? 'studio_card' : (tmpl.mastheadStyle === 'tcolorbox_crisp' ? 'compact_card' : 'classic'));
  if (mastStyle === 'studio_card') {
    // Polished studio card: rounded surface with subtle stroke + vertical accent bar
    elements.push({
      type: 'rect',
      x: leftM,
      y: 0,
      w: printableW,
      h: height,
      radius: 4,
      fill: surfaceColor,
      stroke: tmpl.colors.bordercolor || '#E2E8F0',
      lineWidth: 0.5,
    });
    elements.push({
      type: 'rect',
      x: leftM,
      y: 0,
      w: accentW,
      h: height,
      radius: 1.5,
      fill: accentColor,
    });
  } else if (mastStyle === 'compact_card') {
    // High-density technical card: compact rounded surface with stroke + slim accent
    elements.push({
      type: 'rect',
      x: leftM,
      y: 0,
      w: printableW,
      h: height,
      radius: 2,
      fill: surfaceColor,
      stroke: tmpl.colors.bordercolor || '#E4E4E7',
      lineWidth: 0.5,
    });
    elements.push({
      type: 'rect',
      x: leftM,
      y: 0,
      w: accentW,
      h: height,
      radius: 1,
      fill: accentColor,
    });
  } else {
    // Minimalist theme: Grounded masthead separator — heavy stroke below title/metadata block
    elements.push({
      type: 'rule',
      x1: leftM,
      y1: height - 0.75,
      x2: leftM + printableW,
      y2: height - 0.75,
      width: 0.75,
      color: tmpl.colors.ruleblack || '#111827',
    });
  }

  for (const item of leftTops) {
    elements.push({
      type: 'text',
      text: (item.line.runs || []).map((r) => r.text).join(''),
      runs: item.line.runs,
      x: leftM + padX,
      y: item.top,
      font: item.font,
      size: item.size,
      color: item.color,
      prewrapped: true,
    });
  }

  const metaBoxX = stacked ? leftM + padX : leftM + printableW - padX - metaColW;
  for (const item of metaTops) {
    elements.push({
      type: 'text',
      text: (item.line.runs || []).map((r) => r.text).join(''),
      runs: item.line.runs,
      x: metaBoxX,
      y: item.top,
      width: metaColW,
      align: 'right',
      font: 'helvetica',
      size: metaSize,
      color: mutedColor,
      prewrapped: true,
    });
  }

  return { elements, height };
}

/**
 * Splits a pipe-table row into cells without breaking `$…$` math: a `|`
 * inside paired dollars is cell content, not a column break. An unpaired
 * `$` (currency like `price $5`) stays literal so ordinary rows split
 * exactly as before.
 * @param {string} line row text with outer pipes already stripped
 * @returns {string[]}
 */
function splitTableRow(line) {
  const src = String(line ?? '');
  const cells = [];
  let cur = '';
  let inMath = false;
  const hasCloser = (from) => {
    for (let j = from; j < src.length; j++) {
      if (src[j] === '$' && src[j - 1] !== '\\') return true;
    }
    return false;
  };
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (ch === '\\' && i + 1 < src.length && (src[i + 1] === '$' || src[i + 1] === '|')) {
      cur += ch + src[i + 1];
      i++;
      continue;
    }
    if (ch === '$') {
      if (!inMath && !hasCloser(i + 1)) {
        cur += ch; // unpaired: literal (currency), never opens math
        continue;
      }
      inMath = !inMath;
      cur += ch;
      continue;
    }
    if (ch === '|' && !inMath) {
      cells.push(cur);
      cur = '';
      continue;
    }
    cur += ch;
  }
  cells.push(cur);
  return cells;
}

/**
 * Caption-like single item: an L1 list-item or a paragraph whose runs are
 * all bold and whose text ends with ':' — the lead-in shapes authors use
 * for table captions (`- **Matriz …:**`). Only the single item directly
 * before the span qualifies (never a run), so a list ending in a bold
 * lead-in keeps its flow and only the lead-in spans.
 */
function isCaptionSingle(it) {
  if (!it || (it.kind !== 'list-item' && it.kind !== 'paragraph')) return false;
  if (it.kind === 'list-item' && it.level !== 1) return false;
  const runs = it.runs || [];
  if (runs.length === 0) return false;
  if (!runs.every((r) => r && (r.style === 'bold' || r.style === 'bold_italic'))) return false;
  return runs.map((r) => r.text).join('').trim().endsWith(':');
}

/**
 * Caption run ending immediately before items[spanIdx] (which must be a
 * span): a trailing heading run, else one caption-like single. The run may
 * not start before `low`. Returns { start, end } or null.
 */
function captionRunBefore(items, isSpanFn, spanIdx, low) {
  if (spanIdx < 0 || spanIdx >= items.length || !isSpanFn(items[spanIdx])) return null;
  let s = spanIdx;
  while (s > low && items[s - 1] && items[s - 1].kind === 'heading') s--;
  if (s < spanIdx) return { start: s, end: spanIdx };
  if (s - 1 >= low && isCaptionSingle(items[s - 1])) return { start: s - 1, end: spanIdx };
  return null;
}

// Isolate-level bounded LRU caches for Cloudflare Worker & incremental live preview efficiency:
// 1. BLOCK_ITEMS_CACHE caches parsed & wrapped block items[] per section so editing 1 section
//    in a multi-section document reuses all unchanged sections in < 0.05ms.
// 2. DISPLAY_LIST_CACHE caches frozen DisplayLists so /api/paginate -> /api/convert (and repeat
//    pagination ticks) reuse the exact compiled DisplayList with zero layout re-computation.
const BLOCK_ITEMS_CACHE = new Map();
const MAX_BLOCK_ITEMS_CACHE = 64;
const DISPLAY_LIST_CACHE = new Map();
const MAX_DISPLAY_LIST_CACHE = 16;
const BLOCK_FLOW_CACHE = new Map();
const MAX_BLOCK_FLOW_CACHE = 64;

function cloneBlockPages(pageList) {
  const out = new Array(pageList.length);
  for (let i = 0; i < pageList.length; i++) {
    const p = pageList[i];
    const srcEls = p.elements || [];
    const els = new Array(srcEls.length);
    for (let j = 0; j < srcEls.length; j++) {
      const el = srcEls[j];
      els[j] = el && el.type === 'rotated' && Array.isArray(el.children)
        ? { ...el, children: el.children.map((c) => ({ ...c })) }
        : { ...el };
    }
    const pageCopy = {
      pageNumber: p.pageNumber,
      elements: els,
    };
    if (Array.isArray(p._stretchSeams)) {
      pageCopy._stretchSeams = p._stretchSeams.map((s) => ({ ...s }));
    }
    if (Array.isArray(p._flowCues)) {
      pageCopy._flowCues = p._flowCues.map((c) => ({ ...c }));
    }
    if (p._regionTail) {
      pageCopy._regionTail = { ...p._regionTail };
    }
    out[i] = pageCopy;
  }
  return out;
}

function blockFlowCacheSet(key, record) {
  if (BLOCK_FLOW_CACHE.size >= MAX_BLOCK_FLOW_CACHE && !BLOCK_FLOW_CACHE.has(key)) {
    const oldest = BLOCK_FLOW_CACHE.keys().next().value;
    if (oldest !== undefined) BLOCK_FLOW_CACHE.delete(oldest);
  }
  BLOCK_FLOW_CACHE.set(key, record);
}

function fastHashStr(str) {
  let h1 = 0x811c9dc5;
  let h2 = 0xdeadbeef;
  const len = str.length;
  for (let i = 0; i < len; i++) {
    const c = str.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 0x01000193) >>> 0;
    h2 = Math.imul(h2 ^ c, 0x9e3779b1) >>> 0;
  }
  return `${h1.toString(16)}-${h2.toString(16)}-${len}`;
}

function cloneBlockItems(items) {
  const out = new Array(items.length);
  for (let i = 0; i < items.length; i++) {
    out[i] = { ...items[i] };
  }
  return out;
}

function blockCacheSet(key, items) {
  if (BLOCK_ITEMS_CACHE.size >= MAX_BLOCK_ITEMS_CACHE && !BLOCK_ITEMS_CACHE.has(key)) {
    const oldest = BLOCK_ITEMS_CACHE.keys().next().value;
    if (oldest !== undefined) BLOCK_ITEMS_CACHE.delete(oldest);
  }
  BLOCK_ITEMS_CACHE.set(key, cloneBlockItems(items));
}

function dlCacheSet(key, dl) {
  if (DISPLAY_LIST_CACHE.size >= MAX_DISPLAY_LIST_CACHE && !DISPLAY_LIST_CACHE.has(key)) {
    const oldest = DISPLAY_LIST_CACHE.keys().next().value;
    if (oldest !== undefined) DISPLAY_LIST_CACHE.delete(oldest);
  }
  DISPLAY_LIST_CACHE.set(key, dl);
}

export class GeometryCompiler {
  constructor(options = {}) {
    this.options = options;
    this.antiOrphan = new AntiOrphanGuard(options);
    this.galleyEngine = new GalleyEngine(options);
  }

  buildAccentContainer({ x, y, width, height, fill, stroke, westWidth = V2_STROKE_TOKENS.accentWest }) {
    return {
      type: 'rect',
      x,
      y,
      w: width,
      h: height,
      fill,
      stroke,
      westWidth,
    };
  }

  buildDividerRule({ x1, y1, x2, y2, width = V2_STROKE_TOKENS.standard, color }) {
    return {
      type: 'rule',
      x1,
      y1,
      x2,
      y2,
      width,
      color,
    };
  }

  buildOpticalMarker({ x, y, level = 1, style = 'circle', r = 1.3, color }) {
    return {
      type: 'bullet',
      x,
      y,
      level,
      style,
      r,
      color,
    };
  }

  prepareLayoutContext(payload, compileOpts = {}) {
    const docIR = normalizeToDocIR(payload);
    const templateKey = compileOpts.template || docIR.template || 'base';
    const tmpl = TEMPLATES[templateKey] || TEMPLATES.base;
    const runningTitle = (docIR.headerText || '').trim() || DEFAULT_HEADER;
    const leftM = tmpl.margins.left;
    const rightM = tmpl.margins.right;
    const topM = tmpl.margins.top;
    const bottomM = tmpl.margins.bottom;
    const printableW = A4_WIDTH - leftM - rightM;
    const colSep = tmpl.columnsep || V2_SPACING_TOKENS.gutter;
    const twoColW = (printableW - colSep) / 2;
    const contentTopY = topM + tmpl.headheight + tmpl.headsep;
    const contentBottomY = A4_HEIGHT - bottomM - tmpl.footskip;
    return {
      docIR,
      templateKey,
      tmpl,
      runningTitle,
      leftM,
      rightM,
      topM,
      bottomM,
      printableW,
      colSep,
      twoColW,
      contentTopY,
      contentBottomY,
      availableColH: contentBottomY - contentTopY,
      compileOpts,
    };
  }

  /**
   * Compiles DocumentIR into an immutable DisplayList.
   * @param {object} payload - DocumentIR or raw payload
   * @param {object} [compileOpts={}]
   * @returns {object} Immutable DisplayList
   */
  compile(payload, compileOpts = {}) {
    const docIR = normalizeToDocIR(payload);
    const templateKey = compileOpts.template || docIR.template || 'base';
    // Flush-bottom toggle ("Encaixar pé da página"): when off, the 3b pass
    // reports every page as honestly ragged (`flush-off`) and moves nothing.
    const flushBottom = docIR.flushColumns !== false;
    // List-item atomicity ("Dividir itens longos" in the editor). v2/v3 used
    // to forward this control without reading it, so a `false` request still
    // cut list items at column/page boundaries. Mark the parsed items once and
    // let `_splitParagraph` enforce it at every call site.
    const splitListItems = compileOpts.split_list_items !== false
      && compileOpts.splitListItems !== false;
    const tmpl = TEMPLATES[templateKey] || TEMPLATES.base;
    // Running header title with legacy fallback: v1 always prints
    // 'Material de Raul de Oliveira Pasin' when no custom header is set
    // (pdf-generator.js generatePdf); the V2 compiler must do the same.
    const runningTitle = (docIR.headerText || '').trim() || DEFAULT_HEADER;
    // Live word measurer (DI): same fonts the blaster renders with, so wrap
    // breaks match rendered breaks. Null → AFM-table estimates (tests,
    // direct compile() callers without a driver context).
    const measureOpt = typeof compileOpts.measure === 'function' ? compileOpts.measure : null;
    const measureImageOpt = typeof compileOpts.measureImage === 'function' ? compileOpts.measureImage : null;
    // Fase 1b: fiação do SpanCoordinator atrás de flag (default off = bytes idênticos).
    const useSpanCoord = compileOpts.useSpanCoordinator === true || compileOpts.USE_SPAN_COORDINATOR === true;
    const imagesSource = compileOpts.images || compileOpts.imageBufferMap || null;
    const getImageBuffer = (src) => {
      if (!imagesSource || !src) return null;
      if (typeof imagesSource.get === 'function') return imagesSource.get(src) || null;
      return imagesSource[src] || null;
    };

    const leftM = tmpl.margins.left;
    const rightM = tmpl.margins.right;
    const topM = tmpl.margins.top;
    const bottomM = tmpl.margins.bottom;

    const printableW = A4_WIDTH - leftM - rightM;
    const colSep = tmpl.columnsep || 14.17;
    const twoColW = (printableW - colSep) / 2;
    const twoCol0X = leftM;
    const twoCol1X = leftM + twoColW + colSep;

    const contentTopY = topM + tmpl.headheight + tmpl.headsep;
    const contentBottomY = A4_HEIGHT - bottomM - tmpl.footskip;
    const availableColH = contentBottomY - contentTopY;

    const chaptersToc = Boolean(
      compileOpts.chapters_toc ||
      compileOpts.chaptersToc ||
      (docIR.toc && docIR.toc.enabled === true)
    );

    const pages = [];
    let currentPageIndex = 0;

    function getOrCreatePage(pageIdx) {
      while (pages.length <= pageIdx) {
        pages.push({
          pageNumber: pages.length + 1,
          elements: [],
        });
      }
      return pages[pageIdx];
    }

    const isV3 = Boolean(compileOpts.geometry === 'v3' || docIR.geometry === 'v3');
    const hasImages = Boolean(
      imagesSource && (
        (imagesSource instanceof Map && imagesSource.size > 0) ||
        (typeof imagesSource === 'object' && !(imagesSource instanceof Map) && Object.keys(imagesSource).length > 0)
      )
    );
    const measureCacheTag = measureOpt === null
      ? 'afm'
      : (measureOpt._isStandardLiveMeasure ? `live:${measureOpt._tmplId || templateKey}` : null);
    const canStoreCache = Boolean(
      !hasImages &&
      measureCacheTag !== null &&
      !process.env.V2_KEEP_SEAMS
    );
    const canUseCache = Boolean(canStoreCache && compileOpts.bypassCache !== true);
    let dlCacheKey = null;
    if (canStoreCache) {
      const blocksBasis = (docIR.blocks || []).map((b) =>
        `${b.title || ''}\x1f${b.name || ''}\x1f${b.columns ?? b.column_layout ?? b.columnLayout ?? ''}\x1f${b.tableLayout || ''}\x1f${b.tableRotationDirection || ''}\x1f${JSON.stringify(b.masthead || {})}\x1f${b.enable_masthead ?? ''}\x1f${b.masthead_enabled ?? ''}\x1f${b.masthead_header ?? ''}\x1f${b.masthead_course ?? ''}\x1f${b.masthead_topic ?? ''}\x1f${b.masthead_prefix ?? ''}\x1f${JSON.stringify(b.flags || {})}\x1f${fastHashStr(b.markdown || '')}`
      ).join('\x1e');
      const docBasis = [
        templateKey,
        isV3 ? 'v3' : 'v2',
        measureCacheTag,
        flushBottom ? '1' : '0',
        runningTitle,
        formatV2HeaderDate(docIR.headerDate),
        docIR.title || '',
        docIR.headerOnTop !== false ? '1' : '0',
        docIR.showFooterText ? '1' : '0',
        docIR.footerText || '',
        docIR.columnLayout || 2,
        docIR.alignment || 'justify',
        docIR.looseLineGuard !== false ? '1' : '0',
        docIR.tableLayoutMode || 'auto',
        docIR.tableRotationDirection || 'cw',
        chaptersToc ? '1' : '0',
        compileOpts.toc_title ?? compileOpts.tocTitle ?? (docIR.toc && docIR.toc.title) ?? '',
        compileOpts.toc_include_headings !== false ? '1' : '0',
        compileOpts.doc_title ?? compileOpts.docTitle ?? compileOpts.document_title ?? '',
        compileOpts.doc_subtitle ?? compileOpts.docSubtitle ?? compileOpts.document_subtitle ?? '',
        compileOpts.balance_columns ?? compileOpts.balanceColumns ?? '',
        splitListItems ? '1' : '0',
        compileOpts.clean_spans !== false && compileOpts.cleanSpans !== false ? '1' : '0',
        compileOpts.imageCaptionsEnabled !== false && compileOpts.image_captions_enabled !== false ? '1' : '0',
        compileOpts.table_layout_mode ?? compileOpts.tableLayoutMode ?? '',
        compileOpts.table_rotation_direction ?? compileOpts.tableRotationDirection ?? '',
        compileOpts.skip_fit_audit ? '1' : '0',
        useSpanCoord ? '1' : '0',
        blocksBasis,
      ].join('|');
      dlCacheKey = fastHashStr(docBasis);
      const cachedDl = canUseCache ? DISPLAY_LIST_CACHE.get(dlCacheKey) : undefined;
      if (cachedDl !== undefined) {
        // Refresh LRU order
        DISPLAY_LIST_CACHE.delete(dlCacheKey);
        DISPLAY_LIST_CACHE.set(dlCacheKey, cachedDl);
        return cachedDl;
      }
    }
    let tocReservedPages = 0;
    if (chaptersToc) {
      if (isV3 && Array.isArray(docIR.blocks) && docIR.blocks.length > 0) {
        const roughSecs = docIR.blocks.map((b) => {
          const md = String(b?.markdown || '');
          const hCount = (md.match(/^#{1,4}\s+/gm) || []).length;
          return { title: b?.title || '', headings: new Array(Math.min(4, hCount)).fill({}) };
        });
        tocReservedPages = computeMultiPageTocLayout(roughSecs, tmpl, compileOpts.toc_include_headings !== false).tocPages;
      } else {
        tocReservedPages = 1;
      }
      for (let tp = 0; tp < tocReservedPages; tp++) {
        getOrCreatePage(tp);
      }
      currentPageIndex = tocReservedPages;
    }

    const blockStartPages = [];
    const blockHeadings = [];
    const anchorMap = new Map();
    // Pages whose first page carries an enabled masthead: the running header
    // date moves into the masthead and is suppressed from the chrome.
    const mastheadPages = new Set();
    const mastheadHeaderPages = new Set();
    // Ref-11 LayoutDiagnostics tracer gates (display-list.ts:70-85),
    // accumulated across all blocks. Zero layout effect.
    let tableSlices = 0;
    let panoramicTransitions = 0;
    let overfullColumns = 0;
    // Adapted-port tracer gates (ADR-ADAPT-02): heading carries + row-level
    // orphan/widow guards. Zero layout effect.
    let keepWithNextBreaks = 0;
    let orphanSuppressions = 0;
    let widowSuppressions = 0;

    // Seam substrate (VGA §3.1–3.2): every inter-item boundary is a
    // StretchSeam record — position, scope, class, capacity. It is the single
    // gap representation (M5 removed the parallel legacy Y-list). Element
    // ownership tagging rides alongside via _placeWithSeam.
    let seamSeqCounter = 0;
    const lastSeamSeq = (page) => ((page._stretchSeams && page._stretchSeams.length)
      ? page._stretchSeams[page._stretchSeams.length - 1].seq : -1);
    const recordSeam = (page, y, scope, klass) => {
      if (!page._stretchSeams) page._stretchSeams = [];
      const seq = seamSeqCounter++;
      page._stretchSeams.push(makeSeam({
        seq, page: page.pageNumber, region: null, scope, y, klass,
        capacity: capacityForClass(klass, tmpl),
      }));
      return seq;
    };

    const pendingBlockFlows = [];
    // Process blocks (each block starts on a fresh page)
    for (let bIdx = 0; bIdx < docIR.blocks.length; bIdx++) {
      const block = docIR.blocks[bIdx];
      const rawBlockColumns = block.columns ?? block.column_layout ?? block.columnLayout;
      const blockCols = (rawBlockColumns === 1 || rawBlockColumns === '1')
        ? 1
        : (rawBlockColumns === 2 || rawBlockColumns === '2')
          ? 2
          : (docIR.columnLayout === 1 ? 1 : 2);
      const colW = (blockCols === 1) ? printableW : twoColW;
      const col0X = (blockCols === 1) ? leftM : twoCol0X;
      const col1X = (blockCols === 1) ? leftM : twoCol1X;
      if (bIdx > 0 || (chaptersToc ? pages.length === 1 : pages.length === 0)) {
        currentPageIndex = pages.length; // Fresh page for new block
      }

      const blockStartPageIdx = currentPageIndex;
      const cleanSpansOnEarly = compileOpts.clean_spans !== false && compileOpts.cleanSpans !== false;
      const autofixOnEarly = block.flags?.autofix !== false;
      const optTablesOnEarly = block.flags?.optimize_tables !== false;
      const splitEqOnEarly = block.flags?.split_equations !== false;
      const imgCapOnEarly = compileOpts.imageCaptionsEnabled !== false && compileOpts.image_captions_enabled !== false;
      const effDocTableModeEarly = (compileOpts.table_layout_mode && compileOpts.table_layout_mode !== 'auto')
        ? compileOpts.table_layout_mode
        : (compileOpts.tableLayoutMode && compileOpts.tableLayoutMode !== 'auto')
          ? compileOpts.tableLayoutMode
          : (docIR.tableLayoutMode || 'auto');
      const effTableModeEarly = block.tableLayout || effDocTableModeEarly || 'auto';
      const effRotDirEarly = block.tableRotationDirection || docIR.tableRotationDirection || compileOpts.table_rotation_direction || compileOpts.tableRotationDirection || 'cw';
      const balanceOnEarly = (block.flags?.balance_columns ?? compileOpts.balance_columns ?? compileOpts.balanceColumns ?? false) === true;
      const isLastBlock = bIdx === docIR.blocks.length - 1;
      const blockFlowKey = canStoreCache
        ? fastHashStr(`${templateKey}|${isV3 ? 1 : 0}|${measureCacheTag}|${bIdx}|${isLastBlock ? 1 : 0}|${blockStartPageIdx}|${seamSeqCounter}|${colW}|${printableW}|${availableColH}|${flushBottom ? 1 : 0}|${chaptersToc ? 1 : 0}|${tocReservedPages}|${docIR.headerOnTop !== false ? 1 : 0}|${docIR.showFooterText ? 1 : 0}|${docIR.footerText || ''}|${docIR.alignment || 'justify'}|${docIR.looseLineGuard !== false ? 1 : 0}|${cleanSpansOnEarly ? 1 : 0}|${autofixOnEarly ? 1 : 0}|${optTablesOnEarly ? 1 : 0}|${splitEqOnEarly ? 1 : 0}|${imgCapOnEarly ? 1 : 0}|${useSpanCoord ? 1 : 0}|${effTableModeEarly}|${effRotDirEarly}|${balanceOnEarly ? 1 : 0}|${splitListItems ? 1 : 0}|${docIR.title || ''}|${runningTitle}|${formatV2HeaderDate(docIR.headerDate)}|${JSON.stringify(block.masthead || {})}|${block.markdown || ''}`)
        : null;
      const cachedFlow = (canUseCache && blockFlowKey) ? BLOCK_FLOW_CACHE.get(blockFlowKey) : undefined;
      if (cachedFlow !== undefined) {
        BLOCK_FLOW_CACHE.delete(blockFlowKey);
        BLOCK_FLOW_CACHE.set(blockFlowKey, cachedFlow);
        for (let pi = 0; pi < cachedFlow.pages.length; pi++) {
          pages.push(cachedFlow.pages[pi]);
        }
        currentPageIndex = pages.length;
        blockStartPages.push(cachedFlow.startPage);
        const clonedHeadings = cachedFlow.headings.map((h) => ({ ...h }));
        blockHeadings.push(clonedHeadings);
        for (let hi = 0; hi < clonedHeadings.length; hi++) {
          const h = clonedHeadings[hi];
          const slug = String(h.text || '').toLowerCase().replace(/[^\w\s-]/g, '').replace(/\s+/g, '-');
          anchorMap.set(slug, { page: h.page, dest: h.dest });
          anchorMap.set(h.dest, { page: h.page, dest: h.dest });
        }
        if (cachedFlow.hasMasthead) mastheadPages.add(blockStartPageIdx);
        if (cachedFlow.hasMastheadHeader) mastheadHeaderPages.add(blockStartPageIdx);
        seamSeqCounter = cachedFlow.seamSeqEnd;
        tableSlices += cachedFlow.dTableSlices;
        panoramicTransitions += cachedFlow.dPanoramicTransitions;
        overfullColumns += cachedFlow.dOverfullColumns;
        keepWithNextBreaks += cachedFlow.dKeepWithNextBreaks;
        orphanSuppressions += cachedFlow.dOrphanSuppressions;
        widowSuppressions += cachedFlow.dWidowSuppressions;
        continue;
      }

      const preTableSlices = tableSlices;
      const prePanoramicTransitions = panoramicTransitions;
      const preOverfullColumns = overfullColumns;
      const preKeepWithNextBreaks = keepWithNextBreaks;
      const preOrphanSuppressions = orphanSuppressions;
      const preWidowSuppressions = widowSuppressions;

      let activePage = getOrCreatePage(currentPageIndex);
      blockStartPages.push(activePage.pageNumber);
      blockHeadings.push([]);

      const secDest = `section-${bIdx + 1}`;
      activePage.elements.push({
        type: 'destination',
        name: secDest,
      });

      const onHeading = (hItem, pageNum) => {
        if (hItem && hItem.level <= 2 && hItem.text) {
          const hDest = `heading-${bIdx + 1}-${blockHeadings[bIdx].length + 1}`;
          const slug = String(hItem.text || '').toLowerCase().replace(/[^\w\s-]/g, '').replace(/\s+/g, '-');
          blockHeadings[bIdx].push({
            text: hItem.text,
            level: hItem.level || 1,
            page: pageNum,
            dest: hDest,
          });
          anchorMap.set(slug, { page: pageNum, dest: hDest });
          anchorMap.set(hDest, { page: pageNum, dest: hDest });
          const targetPage = getOrCreatePage(pageNum - 1);
          targetPage.elements.push({
            type: 'destination',
            name: hDest,
          });
        }
      };

      let currentY = contentTopY;

      // 1. Block Masthead if enabled — measured editorial lockup
      // (title + subtitle on the left, metadata on the right)
      // with template-specific accent treatment. No fixed 26pt box.
      let mastheadActualH = 0;
      if (block.masthead && block.masthead.enabled) {
        const formattedDate = formatV2HeaderDate(docIR.headerDate);
        // Opt-in per block: the running-header title moves into this
        // masthead's metadata stack and is suppressed from the chrome of
        // this page only — same ownership rule as the date.
        const moveHeader = block.masthead.header === true;
        const masthead = buildMastheadElements(
          tmpl, block.masthead, docIR.title, formattedDate,
          moveHeader ? runningTitle : '', leftM, printableW, measureOpt,
        );
        mastheadActualH = masthead.height;
        // Track masthead pages to suppress running-header date on them.
        mastheadPages.add(currentPageIndex);
        if (moveHeader) mastheadHeaderPages.add(currentPageIndex);
        for (const el of masthead.elements) {
          // Position masthead elements relative to currentY.
          const positioned = { ...el };
          if (positioned.y !== undefined) positioned.y = currentY + positioned.y;
          if (positioned.y1 !== undefined) positioned.y1 = currentY + positioned.y1;
          if (positioned.y2 !== undefined) positioned.y2 = currentY + positioned.y2;
          positioned.seamSeq = -1;
          positioned.scope = 'span';
          activePage.elements.push(positioned);
        }
        currentY += mastheadActualH + 8;
      }

      // 2. Parse block markdown into layout items (v1-parity subset:
      // headings, nested/ordered lists, blockquotes, tables, code fences,
      // images, rules, math, paragraphs — all with wrapping widths and
      // inline runs so no raw markdown ever reaches the page).
      const bodySize = tmpl.fontSize || 9.5;
      // Vertical rhythm: single source of truth in rhythmForTemplate()
      // (templates/definitions.js). Estimate and render share these values,
      // so the estimate==render invariant holds for any pitch.
      const rhythm = rhythmForTemplate(tmpl);
      const v3Frame = isV3 ? resolveFrameAndTokens(tmpl) : null;
      const fontRatio = rhythm.fontRatio;
      const listGap = rhythm.listGapPt;
      const paraGap = rhythm.paraGapPt;
      const pitch = (size) => (isV3 ? v3Frame.uPt : size * fontRatio + listGap);
      const paraPitch = (size) => (isV3 ? v3Frame.uPt : size * fontRatio + paraGap);
      const bodyLineH = isV3 ? v3Frame.uPt : rhythm.bodyPitchPt;
      const parskip = rhythm.parskipPt;
      const docAlign = (docIR.alignment === 'left' || docIR.alignment === 'right') ? docIR.alignment : 'justify';

      // NOTE (ADR-PROD-0004): the render path consumes block.markdown directly
      // via this compiler-internal line parser. The EditorialAST builders in
      // src/v2/ingest/from-markdown.js are a parallel implementation used by
      // the roundtrip QA proof and (potentially) frontend tooling — NOT by
      // this loop. Do not assume AST shape fixes alter rendered output; keep
      // both paths' fixtures green (npm test + npm run parity).
      // Server-side grounding cleanup (v1 ingestion parity): strip pasted
      // artifact tags ([span_*]/[cite_*]) before measurement. Gated by the
      // clean_spans control (default on), exactly like legacy ingestion.
      const cleanSpansOn = compileOpts.clean_spans !== false && compileOpts.cleanSpans !== false;
      const autofixOn = block.flags?.autofix !== false;
      const optTablesOn = block.flags?.optimize_tables !== false;
      const splitEqOn = block.flags?.split_equations !== false;
      const imgCapOn = compileOpts.imageCaptionsEnabled !== false && compileOpts.image_captions_enabled !== false;
      const effDocTableMode = (compileOpts.table_layout_mode && compileOpts.table_layout_mode !== 'auto')
        ? compileOpts.table_layout_mode
        : (compileOpts.tableLayoutMode && compileOpts.tableLayoutMode !== 'auto')
          ? compileOpts.tableLayoutMode
          : (docIR.tableLayoutMode || 'auto');
      const effTableMode = block.tableLayout || effDocTableMode || 'auto';
      const effRotDir = block.tableRotationDirection || docIR.tableRotationDirection || compileOpts.table_rotation_direction || compileOpts.tableRotationDirection || 'cw';
      const looseGuard = docIR.looseLineGuard !== false;
      const blockCacheKey = canStoreCache
        ? fastHashStr(`${templateKey}|${isV3 ? 1 : 0}|${measureCacheTag}|${colW}|${printableW}|${availableColH}|${docAlign}|${looseGuard ? 1 : 0}|${cleanSpansOn ? 1 : 0}|${autofixOn ? 1 : 0}|${optTablesOn ? 1 : 0}|${splitEqOn ? 1 : 0}|${imgCapOn ? 1 : 0}|${useSpanCoord ? 1 : 0}|${effTableMode}|${effRotDir}|${splitListItems ? 1 : 0}|${block.markdown || ''}`)
        : null;
      const cachedBlockItems = (canUseCache && blockCacheKey) ? BLOCK_ITEMS_CACHE.get(blockCacheKey) : undefined;
      let items;
      if (cachedBlockItems !== undefined) {
        BLOCK_ITEMS_CACHE.delete(blockCacheKey);
        BLOCK_ITEMS_CACHE.set(blockCacheKey, cachedBlockItems);
        items = cloneBlockItems(cachedBlockItems);
      } else {
      const cleanedMarkdown = cleanSpansOn
        ? TagSanitizer.stripGroundingTags(block.markdown || '')
        : (block.markdown || '');
      // Server-side typographic autofix (v1 ingestion parity): arrows,
      // TeX symbols, super/subscripts, and NBSP particle ties. Gated by
      // block.flags.autofix (default on), exactly like legacy ingestion.
      // Must run BEFORE line splitting so glued phrases wrap as units.
      const srcMarkdown = block.flags?.autofix !== false
        ? TypographicAutofix.apply(cleanedMarkdown, true)
        : cleanedMarkdown;
      const rawLines = srcMarkdown.split('\n');
      // Autofix rewrites URL-unsafe sequences (e.g. `img_1…` → subscript
      // `img₁…`), corrupting local image paths. Keep the pre-autofix lines
      // side by side so image sources resolve verbatim (alt/title text
      // still uses the autofixed line for typographic parity).
      const origLines = cleanedMarkdown.split('\n');
      const origAligned = origLines.length === rawLines.length;
      items = [];
      let indentStack = [0];
      let ordCounters = [0];

      const pushParagraph = (text) => {
        const runs = parseInlineRuns(text);
        const plain = runs.map(r => r.text).join('');
        const lines = wrapRunsToLines(runs, 'helvetica', bodySize, colW, measureOpt);
          items.push({
            kind: 'paragraph',
            text: plain,
            runs,
            lines,
            height: lines.length * bodyLineH + parskip,
            fontSize: bodySize,
            lineHeight: bodyLineH,
            align: docAlign,
            wordCount: plain.split(/\s+/).filter(Boolean).length,
            naturalWidth: calculateStringWidth(plain, 'helvetica', bodySize),
            looseGuard,
          });
      };

      let lIdx = 0;
      while (lIdx < rawLines.length) {
        const raw = rawLines[lIdx];
        const line = raw.trim();
        if (!line) { lIdx++; continue; }

        // Fenced code block
        if (/^```/.test(line)) {
          const buf = [];
          lIdx++;
          while (lIdx < rawLines.length && !/^\s*```/.test(rawLines[lIdx])) {
            buf.push(rawLines[lIdx]);
            lIdx++;
          }
          lIdx++; // consume closing fence
          const code = buf.join('\n');
          const codeLines = [];
          for (const ln of code.split('\n')) {
            codeLines.push(...wrapRunsToLines([{ text: ln || ' ', style: 'code' }], 'courier', bodySize, colW - 16, measureOpt));
          }
          const codeBoxH = codeLines.length * bodyLineH + 10;
          const codeAfterGap = isV3 ? (tmpl.vertical?.scalePt?.s2 ?? 4.36) : 0;
          items.push({
            kind: 'code',
            text: code,
            lines: codeLines,
            height: codeBoxH + codeAfterGap,
            boxHeight: codeBoxH,
            afterGap: codeAfterGap,
            fontSize: bodySize,
            lineHeight: bodyLineH,
            align: 'left',
          });
          indentStack = [0];
          ordCounters = [0];
          continue;
        }

        // Pipe table run (header + separator + body rows) — full booktabs
        // parity: proportional widths, panoramic decision, numeric align,
        // density sizes. Row-splitting happens at placement (needs availH).
        if (/^\|/.test(line)) {
          const tblLines = [];
          while (lIdx < rawLines.length && /^\s*\|/.test(rawLines[lIdx])) {
            tblLines.push(rawLines[lIdx].trim());
            lIdx++;
          }
          const allRows = tblLines.map(r => splitTableRow(r.replace(/^\||\|$/g, '')).map(c => c.trim()));
          const isSepRow = (cells) => cells.length > 0 && cells.every(c => /^[:\-|\s]*$/.test(c) && c.length > 0);
          let explicitAligns = null;
          const sepIdx = allRows.findIndex(isSepRow);
          if (sepIdx >= 0) {
            explicitAligns = allRows[sepIdx].map(c => {
              const t = c.trim();
              const l = t.startsWith(':');
              const r = t.endsWith(':') && t.length > 1;
              if (l && r) return 'center';
              if (r) return 'right';
              if (l) return 'left';
              return null;
            });
          }
          const rows = allRows.filter(cells => !isSepRow(cells));
          if (rows.length > 0) {
            const ncols = Math.max(...rows.map(r => r.length));
            for (const r of rows) while (r.length < ncols) r.push('');
            const aligns = explicitAligns && explicitAligns.length === ncols ? explicitAligns : [];
            // Selection matrix: per-block override wins, else document default.
            // compact → never span; panoramic → always span; auto → density
            // heuristics; rotated / rotated_cw (D1) or rotated_ccw (D2) → rendered landscape downstream.
            const docTableMode = (compileOpts.table_layout_mode && compileOpts.table_layout_mode !== 'auto')
              ? compileOpts.table_layout_mode
              : (compileOpts.tableLayoutMode && compileOpts.tableLayoutMode !== 'auto')
                ? compileOpts.tableLayoutMode
                : (docIR.tableLayoutMode || 'auto');
            const blockTableMode = block.tableLayout || null;
            let layoutMode = blockTableMode || docTableMode || 'auto';
            const rotDir = block.tableRotationDirection || docIR.tableRotationDirection || compileOpts.table_rotation_direction || compileOpts.tableRotationDirection || 'cw';
            if (layoutMode === 'rotated') {
              layoutMode = rotDir === 'ccw' ? 'rotated_ccw' : 'rotated_cw';
            }
            const legacyMode = layoutMode === 'compact' ? 'compact'
              : layoutMode === 'panoramic' ? 'full_width' : 'compact';
            const optimize = block.flags?.optimize_tables !== false;
            const panoToken = {
              header: rows[0].map(t => ({ text: t })),
              rows: rows.slice(1).map(r => r.map(t => ({ text: t }))),
            };
            const isRotatedD2 = (layoutMode === 'rotated_ccw' || layoutMode === 'rotated_d2');
            const isRotatedD1 = (layoutMode === 'rotated' || layoutMode === 'rotated_cw' || layoutMode === 'rotated_d1');
            const isRotated = isRotatedD1 || isRotatedD2;
            const rotationAngle = isRotatedD2 ? -90 : 90;
            const rotationMode = isRotatedD2 ? 'd2' : 'd1';

            const panoramic = useSpanCoord
              ? coordDecideTableSpan({ layoutMode, rotDir, panoToken, colW, tmpl, legacyMode }).span
              : isRotated
                ? true
                : (layoutMode === 'panoramic'
                  ? true
                  : layoutMode === 'compact'
                    ? false
                    : TableLayoutEngine.isPanoramic(panoToken, colW, tmpl, legacyMode));
            const rotated = isRotated;
            const tableW = rotated ? availableColH : (panoramic ? printableW : colW);
            // Density scale (v1 renderTableToken parity).
            let headerFontSize, bodyFontSize, paddingH, paddingV;
            const isCompactTable = (tmpl.tokens?.table?.densityPreset === 'compact') || tmpl.fontSize === 8;
            if (isCompactTable) {
              if (ncols >= 6) { headerFontSize = 5.8; bodyFontSize = 5.4; paddingH = 1.6; paddingV = 1.8; }
              else if (ncols >= 4) { headerFontSize = 6.4; bodyFontSize = 6.0; paddingH = 2.0; paddingV = 2.0; }
              else { headerFontSize = 7.2; bodyFontSize = 6.8; paddingH = 3.0; paddingV = 2.5; }
            } else {
              if (ncols >= 6) { headerFontSize = 6.4; bodyFontSize = 5.8; paddingH = 2.0; paddingV = 2.0; }
              else if (ncols >= 4) { headerFontSize = 7.0; bodyFontSize = 6.6; paddingH = 2.5; paddingV = 2.2; }
              else { headerFontSize = 7.8; bodyFontSize = 7.2; paddingH = 3.5; paddingV = 2.8; }
            }
            // Proportional widths from markup-stripped lengths (ref-11
            // ingest/tables.ts:178-191: intrinsic ratios on plain text, never
            // raw `**`/`$`/link markup). Floor follows ref-11
            // minRatio=min(0.12, 1/(n*1.6)) so narrow cols stay legible.
            const widths = new Array(ncols).fill(0);
            if (optimize) {
              const refMinRatio = Math.min(0.12, 1 / (ncols * 1.6));
              const minColWidth = Math.max((tableW / ncols) * 0.4, 18, tableW * refMinRatio);
              // Conservative header auto-widen: header cells render in bold at
              // a larger size (~7% wider advances × ~1.08 size ratio), so raw
              // char counts understate header demand. Weight the header row
              // ×1.15 when solving proportional widths. Bounded by construction:
              // same floor, same renormalize-to-tableW, no panoramic change.
              const HEADER_DEMAND_WEIGHT = 1.15;
              const headerLens = rows[0].map((h) => stripInlineMetrics((h !== undefined ? h : '') || '').length * HEADER_DEMAND_WEIGHT);
              const demands = rows[0].map((_, c) => Math.max(3, headerLens[c],
                ...rows.map(r => stripInlineMetrics((r[c] !== undefined ? r[c] : '') || '').length)));
              // Header-word floor (compact-table shard guard): a column
              // narrower than its longest header word FORCES intra-word
              // hyphenation ("Pa-"/"drão de d-"). Floor each column at
              // longest-header-word bold width + cell padding + the wrap
              // slack (safeW = avail-3 live / -6 headless) + 1pt, so header
              // words always fit whole. Bounded: applied only when the
              // floors jointly fit tableW, otherwise falls back to the
              // legacy uniform floor (minima-guarded hyphenation remains
              // the last resort). Never changes tableW or panoramic state.
              const wrapSlack = (typeof measureOpt === 'function') ? 3 : 6;
              const headerFloors = rows[0].map((h) => {
                const words = stripInlineMetrics((h !== undefined ? h : '') || '').split(/\s+/).filter(Boolean);
                let wMax = 0;
                for (const w of words) {
                  let ww = null;
                  if (typeof measureOpt === 'function') {
                    try { ww = measureOpt(w, 'helvetica-bold', headerFontSize); } catch { ww = null; }
                  }
                  if (typeof ww !== 'number' || !isFinite(ww)) {
                    ww = wordWidth(w, 'helvetica-bold', headerFontSize);
                  }
                  if (ww > wMax) wMax = ww;
                }
                return wMax > 0 ? wMax + paddingH * 2 + wrapSlack + 1 : 0;
              });
              const colFloors = rows[0].map((_, c) => Math.max(minColWidth, headerFloors[c]));
              // First-col floor (vertical category guard, compact + auto-decided-column): bold
              // row-headers in column 0 ("**Descompensação**") wrap through the
              // body style, so the header-word floor above never sees them.
              // Measure each body col-0 word in its real run style
              // (helvetica-bold for bold runs) at bodyFontSize and pin col 0
              // to the longest word + padding + slack. Never changes tableW
              // or panoramic state (auto+panoramic excluded); affordability
              // fallback below keeps the legacy floor when floors don't fit.
              if (layoutMode === 'compact' || (layoutMode === 'auto' && !panoramic)) {
                let firstMax = 0;
                for (const r of rows.slice(1)) {
                  for (const run of parseInlineRuns((r[0] !== undefined ? r[0] : '') || '')) {
                    const font = run.style === 'bold' || run.style === 'bold_italic' ? 'helvetica-bold' : 'helvetica';
                    for (const w of String(run.text || '').split(/\s+/).filter(Boolean)) {
                      let ww = null;
                      if (typeof measureOpt === 'function') {
                        try { ww = measureOpt(w, font, bodyFontSize); } catch { ww = null; }
                      }
                      if (typeof ww !== 'number' || !isFinite(ww)) {
                        ww = wordWidth(w, font, bodyFontSize);
                      }
                      if (ww > firstMax) firstMax = ww;
                    }
                  }
                }
                if (firstMax > 0) colFloors[0] = Math.max(colFloors[0], firstMax + paddingH * 2 + wrapSlack + 1);
              }
              let firstColFloor = colFloors[0];
              const floorsAffordable = colFloors.reduce((a, b) => a + b, 0) <= tableW;
              const colMins = rows[0].map((_, c) => floorsAffordable ? colFloors[c] : minColWidth);
              // Crowded-table guard: when the full floor set doesn't fit
              // tableW, legacy falls back to a uniform floor and col 0 shards
              // again ("Descompen-"/"sação"). Re-pin ONLY col 0 to its floor
              // (never above it — widths stay within tableW by construction
              // of the loop below) so vertical categories still fit whole
              // while sibling columns absorb the squeeze.
              const crowdedGuard = !floorsAffordable && firstColFloor > minColWidth
                && (layoutMode === 'compact' || (layoutMode === 'auto' && !panoramic));
              if (crowdedGuard) colMins[0] = Math.min(firstColFloor, tableW - minColWidth * Math.max(0, ncols - 1));
              // Pin-and-redistribute: proportional shares first; columns
              // below their floor are pinned (never rescaled away — a plain
              // global rescale would shrink a floored column back under its
              // longest header word). The remainder goes to unpinned columns
              // proportionally; repeat until stable (≤ ncols passes).
              const totalChars = demands.reduce((a, b) => a + b, 0) || 1;
              const pinned = new Array(ncols).fill(false);
              for (let pass = 0; pass <= ncols; pass++) {
                let pinnedTotal = 0;
                let freeDemand = 0;
                for (let c = 0; c < ncols; c++) {
                  if (pinned[c]) pinnedTotal += widths[c];
                  else freeDemand += demands[c];
                }
                const leftover = tableW - pinnedTotal;
                let changed = false;
                for (let c = 0; c < ncols; c++) {
                  if (pinned[c]) continue;
                  widths[c] = freeDemand > 0 ? (demands[c] / freeDemand) * leftover : leftover / ncols;
                  if (widths[c] < colMins[c]) {
                    widths[c] = colMins[c];
                    pinned[c] = true;
                    changed = true;
                  }
                }
                if (!changed) break;
              }
            } else {
              const even = tableW / Math.max(1, ncols);
              for (let c = 0; c < ncols; c++) widths[c] = even;
            }
            const tblLineH = bodyFontSize * fontRatio + 0.8;
            const tblHeadLineH = headerFontSize * fontRatio + 0.8;
            const resolveAlign = (colIdx, text, isHeader) => {
              const explicit = aligns[colIdx];
              if (explicit === 'right' || explicit === 'center' || explicit === 'left') return explicit;
              if (isHeader) return 'left';
              if (/^[+-]?(?:R\$|US\$|€|\$)?\s*\d+(?:[.,]\d+)?%?$/.test((text || '').trim())) return 'right';
              return 'left';
            };
            const wrapCell = (text, colIdx, isHeader) => {
              const avail = Math.max(10, widths[colIdx] - paddingH * 2);
              const font = isHeader ? 'helvetica-bold' : 'helvetica';
              const size = isHeader ? headerFontSize : bodyFontSize;
              // Tables break at every space (breakNbsp): NBSP particle glue
              // would otherwise fuse "Padrão de dominância" into one
              // unbreakable token inside narrow cells.
              const lines = wrapRunsToLines(parseInlineRuns(text), font, size, avail, measureOpt, { breakNbsp: true });
              return { lines, align: resolveAlign(colIdx, text, isHeader), text };
            };
            const isHeadless = rows[0].every(h => !(h || '').trim());
            const heavyRule = tmpl.tokens?.table?.heavyRule ?? 0.7;
            let header = null;
            let headerH = heavyRule + 2; // headless collapse: top rule + gap
            if (!isHeadless) {
              const headerCells = rows[0].map((c, ci) => wrapCell(c, ci, true));
              const headLines = Math.max(1, ...headerCells.map(c => c.lines.length));
              headerH = Math.max(12, headLines * tblHeadLineH + paddingV * 2 + 3);
              header = { cells: headerCells, height: headerH, texts: rows[0].slice() };
            }
            const bodyRows = rows.slice(1).map(cells => {
              const wrapped = cells.map((c, ci) => wrapCell(c, ci, false));
              const rowLines = Math.max(1, ...wrapped.map(w => w.lines.length));
              return { cells: wrapped, height: rowLines * tblLineH + paddingV * 2 + 1 };
            });
            const bodyH = bodyRows.reduce((a, r) => a + r.height, 0);
            // Symmetric table rhythm: space-before == space-after (6pt).
            // The top gap collapses when the table opens the block flow
            // (same rule as heading topMargin zeroing); continuation
            // slices never carry it. The bottom gap rides only on the
            // final slice, so split tables don't stack phantom air.
            const TABLE_TOP_GAP = 6;
            const TABLE_BOTTOM_GAP = 6;
            const tableTopGap = items.length === 0 ? 0 : TABLE_TOP_GAP;
            items.push({
              kind: 'table',
              header,
              rows: bodyRows,
              colWidths: widths,
              tableW,
              panoramic,
              rotated,
              rotationAngle,
              rotationMode,
              continued: false,
              closesTable: true,
              topGap: tableTopGap,
              bottomGap: TABLE_BOTTOM_GAP,
              height: tableTopGap + headerH + bodyH + heavyRule + TABLE_BOTTOM_GAP,
              fontSize: bodyFontSize,
              headerSize: headerFontSize,
              lineHeight: tblLineH,
              headLineH: tblHeadLineH,
              paddingH,
              paddingV,
              heavyRule,
              lightRule: tmpl.tokens?.table?.lightRule ?? 0.35,
              align: 'left',
            });
            indentStack = [0];
            ordCounters = [0];
            continue;
          }
          // Fell through: treat collected lines as paragraphs
          for (const tl of tblLines) pushParagraph(tl);
          indentStack = [0];
          ordCounters = [0];
          continue;
        }

        // ATX headings (v1 renderHeading parity): per-template decorator
        // metrics (fontSize/titleWOffset/extraH/uppercase) and spaceBefore
        // rhythm tokens (L1 6 / L2 4 / L3+ 2.5 baseline, skipped for
        // block-opening headings — column-top zeroing is
        // position-dependent, documented approximation).
        const hm = line.match(/^(#{1,6})\s+(.*)$/);
        if (hm) {
          const level = Math.min(6, hm[1].length);
          const decor = (tmpl.headingDecorators && tmpl.headingDecorators[level]) || {};
          const fs = decor.fontSize || ({ 1: 12, 2: 10.5, 3: 9.5, 4: 9.5, 5: 9, 6: 8.5 }[level] || 9.5);
          const rawExtraH = decor.extraH !== undefined ? decor.extraH : 6;
          const extraH = isV3 ? (decor.style === 'underline' ? 3.5 + parskip : parskip) : rawExtraH;
          const topMargin = items.length === 0 ? 0 : headingSpaceBefore(tmpl.headingDecorators, level);
          let runs = parseInlineRuns(hm[2].trim());
          if (decor.isUppercase) runs = runs.map(r => ({ text: (r.text || '').toUpperCase(), style: r.style }));
          const hLineH = fs * fontRatio + 0.8;
          const titleW = colW - (decor.titleWOffset || 0);
          const hLines = wrapRunsToLines(runs, 'helvetica-bold', fs, titleW, measureOpt);
          items.push({
            kind: 'heading',
            level,
            text: runs.map(r => r.text).join(''),
            runs,
            lines: hLines,
            height: topMargin + hLines.length * hLineH + extraH,
            topMargin,
            fontSize: fs,
            lineHeight: hLineH,
            titleWOffset: decor.titleWOffset || 0,
            decor,
            isV3,
            color: decor.textColor || (level <= 2
              ? (tmpl.colors.textmain || '#111827')
              : (tmpl.colors.textmuted || '#4B5563')),
            align: 'left',
          });
          indentStack = [0];
          ordCounters = [0];
          lIdx++;
          continue;
        }

        // Horizontal rule
        if (/^(-{3,}|\*{3,}|_{3,})$/.test(line)) {
          items.push({ kind: 'rule', height: 8 });
          indentStack = [0];
          ordCounters = [0];
          lIdx++;
          continue;
        }

        // Blockquote (strip all leading > markers)
        if (/^>+\s?/.test(line)) {
          const text = line.replace(/^>+\s?/, '');
          const runs = parseInlineRuns(text);
          const bLines = wrapRunsToLines(runs, 'helvetica', bodySize, colW - 16, measureOpt);
          const quoteBoxH = bLines.length * bodyLineH + (isV3 ? 8 : 10);
          const quoteAfterGap = isV3 ? (tmpl.vertical?.scalePt?.s2 ?? 4.36) : 0;
          items.push({
            kind: 'blockquote',
            text: runs.map(r => r.text).join(''),
            runs,
            lines: bLines,
            height: quoteBoxH + quoteAfterGap,
            boxHeight: quoteBoxH,
            afterGap: quoteAfterGap,
            fontSize: bodySize,
            lineHeight: bodyLineH,
            align: docAlign,
          });
          indentStack = [0];
          ordCounters = [0];
          lIdx++;
          continue;
        }

        // Image-only line: rendered image or fallback placeholder box + caption
        const imgM = line.match(/^!\[([^\]]*)\]\(([^)]+)\)/);
        if (imgM) {
          const alt = (imgM[1] || '').trim();
          let src = (imgM[2] || '').trim();
          // Recover the verbatim pre-autofix URL when autofix rewrote it
          // (e.g. subscript substitutions inside `img_<timestamp>_…` paths).
          if (origAligned && origLines[lIdx] !== undefined) {
            const origM = origLines[lIdx].match(/^!\[([^\]]*)\]\(([^)]+)\)/);
            if (origM && origM[2] !== undefined) {
              const fixedTitle = src.match(/^(\S+)\s+["'](.*)["']$/);
              const origSrc = origM[2].trim();
              const origTitle = origSrc.match(/^(\S+)\s+["'](.*)["']$/);
              if (origTitle) {
                src = fixedTitle ? `${origTitle[1]} "${fixedTitle[2]}"` : origSrc;
              } else {
                src = origSrc;
              }
            }
          }
          let title = '';
          const titleM = src.match(/^(\S+)\s+["'](.*)["']$/);
          if (titleM) {
            src = titleM[1];
            title = titleM[2];
          }
          // Per-image scale contract (Phase 1 §3, ref-11): trailing
          // `{width=N}` in the title (legacy) or `{#slug width place ratio}`
          // attr block after `)`. Attr width wins when present.
          let userScale = 1;
          let place = 'column';
          let attrRatio = 0;
          const scaleM = title.match(/\{\s*width\s*=\s*([0-9]*\.?[0-9]+)\s*\}\s*$/);
          if (scaleM) {
            const v = Number(scaleM[1]);
            userScale = Number.isFinite(v) ? Math.min(1, Math.max(0.05, v)) : 1;
            title = title.slice(0, scaleM.index).trim();
          }
          let rest = line.slice(imgM[0].length).trim();
          const attrM = rest.match(/^\{([^}]*)\}\s*$/);
          if (attrM) {
            for (const m of attrM[1].matchAll(/(\w+)\s*=\s*"?([^"\s}]+)"?/g)) {
              const key = m[1].toLowerCase();
              if (key === 'width') {
                const v = Number(m[2]);
                if (Number.isFinite(v)) userScale = Math.min(1, Math.max(0.05, v));
              } else if (key === 'place' || key === 'placement') {
                if (m[2] === 'full-width' || m[2] === 'column') place = m[2];
              } else if (key === 'ratio' || key === 'aspect') {
                const r = Number(m[2]);
                if (Number.isFinite(r) && r > 0) attrRatio = r;
              }
            }
            rest = '';
          }
          const panoramic = useSpanCoord ? coordDecideImageSpan(place).span : place === 'full-width';
          const imgBuf = getImageBuffer(src);
          const captionRaw = (title || alt || '').trim();
          const hasCaption = compileOpts.imageCaptionsEnabled !== false && compileOpts.image_captions_enabled !== false && Boolean(captionRaw);
          let captionFormatted = captionRaw;
          if (hasCaption && !/^figura|^fig\.|^imagem/i.test(captionRaw)) {
            captionFormatted = `Figura: ${captionRaw}`;
          }
          const captionFontSize = tmpl.tokens?.captionFontSize ?? 7.4;

          if (imgBuf) {
            const dims = measureImageOpt ? measureImageOpt(imgBuf) : null;
            // Attr ratio is the intrinsic-aspect fallback when no probe runs
            // (tests, direct compile callers); probed dims always win.
            const origW = dims?.width || (attrRatio > 0 ? 100 * attrRatio : 100);
            const origH = dims?.height || 100;
            const maxAllowedH = (A4_HEIGHT - topM - bottomM) * 0.45;
            const baseW = panoramic ? printableW : colW;
            // Column flow never upscales past natural size; panoramic spans
            // (opt-in via place=full-width) fill baseW * userScale like ref-11.
            const fitScale = panoramic
              ? Math.min((baseW * userScale) / origW, maxAllowedH / origH)
              : Math.min(baseW / origW, maxAllowedH / origH, 1.0) * userScale;
            const targetW = origW * fitScale;
            const targetH = origH * fitScale;

            let captionH = 0;
            let captionLines = [];
            if (hasCaption) {
              captionLines = wrapRunsToLines([{ text: captionFormatted, style: 'italic' }], 'helvetica-oblique', captionFontSize, Math.max(20, baseW - 8), measureOpt);
              captionH = (captionLines.length * (captionFontSize * fontRatio + 1)) + 6;
            }
            const totalBlockH = targetH + captionH + 10;
            items.push({
              kind: 'image',
              src,
              alt,
              title,
              buffer: imgBuf,
              widthRatio: userScale,
              panoramic,
              targetW,
              targetH,
              hasCaption,
              captionLines,
              captionFontSize,
              height: totalBlockH,
              fontSize: captionFontSize,
              align: 'center',
            });
          } else {
            items.push({
              kind: 'image',
              src,
              alt: alt || 'Figura',
              height: 34,
              fontSize: 7.5,
              align: 'center',
            });
          }
          lIdx++;
          // Attr-block-only remainder was consumed above (rest reset to '').
          if (rest && !/^\{[^}]*\}\s*$/.test(rest)) pushParagraph(rest);
          indentStack = [0];
          ordCounters = [0];
          continue;
        }

        // Display math $$…$$ (single line or multi-line block)
        if (/^\$\$/.test(line)) {
          let formula = '';
          if (line.endsWith('$$') && line.length > 4) {
            formula = line.slice(2, -2).trim();
            lIdx++;
          } else if (/^\$\$([\s\S]*?)\$\$([\s\S]*)$/.test(line)) {
            // Same-line closer with trailing prose (`$$x$$ trailing text`):
            // the math box carries only the formula; the tail is re-queued
            // so it parses as a normal line (paragraph, list, …).
            const m = line.match(/^\$\$([\s\S]*?)\$\$([\s\S]*)$/);
            const tail = (m[2] || '').trim();
            if (tail) rawLines.splice(lIdx + 1, 0, tail);
            formula = (m[1] || '').trim();
            lIdx++;
          } else {
            const mBuf = [];
            const startIdx = lIdx;
            const first = line.slice(2).trim();
            if (first) mBuf.push(first);
            lIdx++;
            let closed = false;
            while (lIdx < rawLines.length && !/^\s*\$\$/.test(rawLines[lIdx])) {
              mBuf.push(rawLines[lIdx].trim());
              lIdx++;
            }
            if (lIdx < rawLines.length && /^\s*\$\$/.test(rawLines[lIdx])) {
              closed = true;
              const lastLine = rawLines[lIdx].trim().replace(/^\$\$/, '').trim();
              if (lastLine) {
                // Closer-line tail (`$$ world after`) is prose, not formula:
                // re-queue it so it parses as a normal line.
                rawLines.splice(lIdx + 1, 0, lastLine);
              }
              lIdx++;
            }
            if (!closed) {
              // Unterminated opener: never swallow the block into a math
              // box. Fall back to paragraphs (markers kept visible).
              for (let k = startIdx; k < rawLines.length; k++) {
                const t = (rawLines[k] || '').trim();
                if (t) pushParagraph(t);
              }
              lIdx = rawLines.length;
              indentStack = [0];
              ordCounters = [0];
              continue;
            }
            formula = mBuf.join('\n');
          }
          const mLines = [];
          // Equation splitting honors the block toggle: `\\` breaks open a
          // new equation line when split_equations is on (default); off keeps
          // one line with `\\` folded to a space (never a backslash leak).
          const splitEq = block.flags?.split_equations !== false;
          const rawForms = splitEq
            ? formula.split(/\\\\|\n/)
            : [formula.replace(/\\\\/g, ' ')];
          for (const fl of rawForms.flatMap((s) => s.split('\n'))) {
            const converted = InlineMath.convertSymbols(fl);
            mLines.push(...wrapRunsToLines([{ text: converted || ' ', style: 'code' }], 'courier', 9, colW - 24, measureOpt));
          }
          const mLineH = 9 * fontRatio + 0.8;
          const mathBoxH = mLines.length * mLineH + (isV3 ? 12 : 14);
          const mathAfterGap = isV3 ? (tmpl.vertical?.scalePt?.s3 ?? 6.00) : 0;
          items.push({
            kind: 'math',
            formula,
            lines: mLines,
            height: mathBoxH + mathAfterGap,
            boxHeight: mathBoxH,
            afterGap: mathAfterGap,
            fontSize: 9,
            lineHeight: mLineH,
            align: 'left',
          });
          indentStack = [0];
          ordCounters = [0];
          continue;
        }

        // List items: indent (tabs / spaces) → hierarchy level via indentStack;
        // bullets, renumbered ordered markers, task checkboxes.
        const rawIndent = (raw.match(/^([\s\u00A0\u2000-\u200B\u202F\u205F\u3000]*)/) || ['', ''])[1];
        const normIndent = rawIndent
          .replace(/\t/g, '  ')
          .replace(/[\u00A0\u2000-\u200B\u202F\u205F\u3000]/g, '  ')
          .length;
        const bulletM = line.match(/^([•◦○●–—*+\-])\s+(.*)$/);
        const orderedM = line.match(/^(\d+[.)]|[a-zA-Z][.)])\s+(.*)$/);
        if (bulletM || orderedM) {
          let mText = (bulletM ? bulletM[2] : orderedM[2]) || '';
          const ordered = !!orderedM;
          const prev = items.length > 0 ? items[items.length - 1] : null;
          const prevIsList = !!prev && prev.kind === 'list-item';
          // Task checkbox: `- [ ]` / `- [x]` (v1 task lists).
          let task = null;
          if (!ordered) {
            const taskM = mText.match(/^\[([ xX])\]\s+(.*)$/);
            if (taskM) {
              task = { checked: taskM[1].toLowerCase() === 'x' };
              mText = taskM[2];
            }
          }

          if (!prevIsList) {
            indentStack = [normIndent];
            ordCounters = [0];
          } else if (normIndent >= indentStack[indentStack.length - 1] + 2) {
            indentStack.push(normIndent);
            ordCounters.push(0);
          } else {
            while (indentStack.length > 1 && normIndent <= indentStack[indentStack.length - 1] - 2) {
              indentStack.pop();
              ordCounters.pop();
            }
          }

          const level = indentStack.length;
          let ordNum = 0;
          if (ordered) {
            if (prevIsList && !prev.ordered && prev.level === level) {
              ordCounters[level - 1] = 1;
            } else {
              ordCounters[level - 1] = (ordCounters[level - 1] || 0) + 1;
            }
            ordNum = ordCounters[level - 1];
          }

          const geo = listGeometry(tmpl, level, ordered);
          const liSize = listBodySize(tmpl, level);
          const liLineH = pitch(liSize);
          const liSep = listItemSep(tmpl, level);
          let markerDesc;
          if (task) {
            markerDesc = { kind: 'task', checked: task.checked };
          } else if (ordered) {
            const cycle = (level - 1) % 3;
            let numStr;
            if (cycle === 0) numStr = `${ordNum}.`;
            else if (cycle === 1) numStr = `${String.fromCharCode(97 + ((ordNum - 1) % 26))})`;
            else numStr = `${toRomanV1(ordNum)}.`;
            const props = orderedMarkerProps(tmpl, level);
            markerDesc = { kind: 'ordered', text: numStr, color: props.color, bold: props.bold };
          } else {
            markerDesc = unorderedMarker(tmpl, level);
          }
          const runs = parseInlineRuns(mText);
          const plain = runs.map(r => r.text).join('');
          const availW = colW - geo.textOff;
          const liLines = wrapRunsToLines(runs, 'helvetica', liSize, availW, measureOpt);
          items.push({
            kind: 'list-item',
            level,
            ordered,
            ordNum,
            text: plain,
            runs,
            lines: liLines,
            markerDesc,
            geo,
            height: liLines.length * liLineH + liSep,
            fontSize: liSize,
            lineHeight: liLineH,
            align: docAlign,
            wordCount: plain.split(/\s+/).filter(Boolean).length,
            naturalWidth: calculateStringWidth(plain, 'helvetica', liSize),
            looseGuard,
          });
          lIdx++;
          continue;
        }

        // Standard paragraph
        pushParagraph(line);
        indentStack = [0];
        ordCounters = [0];
        lIdx++;
      }

      // List-group spacing (v1 topSep/bottomSep parity): an L1 item that
      // opens a list run gains topSep, one that closes it gains bottomSep.
      // Column-top nuance (v1 zeroes topSep there) is position-dependent and
      // handled best-effort: a ≤2.5pt occasional overcount at column tops.
      for (let ii = 0; ii < items.length; ii++) {
        const it = items[ii];
        if (it.kind !== 'list-item' || it.level !== 1) continue;
        const prevList = ii > 0 && items[ii - 1].kind === 'list-item';
        const nextList = ii + 1 < items.length && items[ii + 1].kind === 'list-item';
        if (!prevList) it.height += listTopSep(tmpl);
        if (!nextList) it.height += listBottomSep(tmpl);
      }
      if (blockCacheKey) {
        blockCacheSet(blockCacheKey, items);
      }
      }

      // Atomic-list policy rides on the parsed items so every split call site
      // (continuous fill, boundary refinement, tail parity) sees the same
      // answer without threading a flag through the whole flow loop.
      for (const it of items) {
        if (it.kind === 'list-item') it.splitAllowed = splitListItems;
      }

      // 3. Flow items across pages: each page alternates balanced 2-column
      // regions and full-width panoramic spans at running column tops
      // (v1 startFullWidthSpan semantics). Kept output is always a doc-order
      // PREFIX of the remaining stream, so every page terminates and nothing
      // ever crosses the content bottom: if a balanced column exceeds the
      // region, the bite's last item returns to the stream and the region
      // rebalances, until it fits or one atomic item remains. Over-tall
      // tables are row-split with repeated headers instead of overflowing.
      // Never ends a region on a heading (keep-with-next, v1 parity).
      // Per-block override wins; otherwise the global balance_columns
      // control applies (default false / opt-in).
      const balanceOn = (block.flags?.balance_columns ?? compileOpts.balance_columns ?? compileOpts.balanceColumns ?? false) === true;
      // Atomic list items cannot be line-split to fill a column, so use the
      // whole-item balanced partition for those regions. The default split
      // path stays continuous and untouched.
      const atomicListBalance = !splitListItems;
      // Strict footer slop: rounding only. Anything taller must break to the
      // next page/column (or line-split below) — never bleed past
      // contentBottomY into the footer zone.
      const OVER_TOL = 1;
      const MIN_REGION = bodyLineH; // don't start a region that fits nothing

      const colHeight = (list) => list.reduce((a, it) => a + (it.height || 14), 0);
      const isSpanInline = (it) => it && (it.kind === 'table' || it.kind === 'image') && it.panoramic === true;
      const isSpan = useSpanCoord ? coordIsSpan : isSpanInline;
      // Full-width divider: a `---` rule directly above/below a panoramic
      // table or figure spans the page (printableW), never a single column.
      const isRuleSpanInline = (it, idx) => {
        if (!it || it.kind !== 'rule') return false;
        const panoTbl = (x) => x && (x.kind === 'table' || x.kind === 'image') && x.panoramic === true;
        const prev = idx > 0 ? items[idx - 1] : null;
        const next = idx + 1 < items.length ? items[idx + 1] : null;
        if (panoTbl(prev) || panoTbl(next)) return true;
        if (prev && prev.kind === 'rule' && prev.fullWidth) return true;
        return false;
      };
      const isRuleSpan = useSpanCoord ? coordIsRuleSpan : isRuleSpanInline;
      // Tracer-gate helper closing over the document totals above.
      const trackSplit = (slice, rest, maxH) => {
        if (rest) tableSlices++;
        else if (slice && slice.height > maxH + OVER_TOL) overfullColumns++;
        const guards = slice && slice.splitGuards;
        if (guards && rest) {
          if (guards.orphan) orphanSuppressions++;
          if (guards.widow) widowSuppressions++;
        }
      };

      let cursor = 0;
      let firstPageOfBlock = true;
      let chunkIdx = 0;
      // Guard: an empty block still yields no pages here; the header/footer
      // pass below guarantees at least one page per document.
      while (cursor < items.length) {
        const pageAvailH = firstPageOfBlock ? availableColH - (currentY - contentTopY) : availableColH;
        const pageTopY = firstPageOfBlock ? currentY : contentTopY;
        activePage = getOrCreatePage(currentPageIndex);
        currentPageIndex++;
        let resumeTop = pageTopY; // invariant: both columns resume here
        // Stacked-sliver kinship (see lone-sliver guard below): how many
        // items the previous same-page region placed in plan-col2 (visual
        // right column). A full-width span/rule/caption between regions
        // resets the reading flow, so those paths reset this to 0.
        let prevRegionC2Len = 0;

        if (blockCols === 1) {
          while (cursor < items.length) {
            const remaining = contentBottomY - resumeTop;
            if (remaining < MIN_REGION) break; // fresh page needed
          const head = items[cursor];

          // Rotated table (Option D1/D2): dedicated portrait page carrying one landscape table
            if (head.kind === 'table' && head.rotated === true) {
              if (resumeTop > pageTopY) break; // fresh dedicated page
              let placee = head;
              let rest = null;
              if (head.height > printableW + OVER_TOL) {
                [placee, rest] = this._splitTable(head, printableW);
                trackSplit(placee, rest, printableW);
              }
              const sub = { elements: [] };
              this._compileItem(sub, placee, 0, 0, placee.tableW, tmpl);
              activePage.elements.push({
                type: 'rotated',
                seamSeq: lastSeamSeq(activePage),
                scope: 'span',
                angle: placee.rotationAngle ?? 90,
                mode: placee.rotationMode ?? 'd1',
                x: leftM,
                y: contentTopY,
                w: placee.tableW,
                h: placee.height,
                boxW: printableW,
                boxH: availableColH,
                children: sub.elements,
              });
              items.splice(cursor, 1, ...(rest ? [rest] : []));
              break;
            }

            // Headings: anti-orphan protection
            if (head.kind === 'heading' && resumeTop > pageTopY) {
              const subItems = items.slice(cursor + 1);
              const reqClearance = this.antiOrphan.calculateRequiredClearance(head, subItems);
              if (remaining < reqClearance && subItems.length > 0) {
                // Orphan heading at bottom of page: move whole heading to fresh page
                keepWithNextBreaks++;
                break;
              }
            }

            // Tables: check fit or split
            if (head.kind === 'table') {
              if (head.height <= remaining) {
                let seamA = null;
                if (resumeTop > pageTopY) {
                  seamA = recordSeam(activePage, resumeTop, 'span', classForItemKind(items[cursor - 1]));
                }
                this._placeWithSeam(activePage, head, leftM, resumeTop, printableW, tmpl, onHeading, seamA, 'span');
                resumeTop += head.height;
                cursor++;
                continue;
              }
              if (resumeTop > pageTopY && head.height <= availableColH + OVER_TOL) {
                // Table fits on a fresh page: break to next page
                break;
              }
              // Oversized table: split
              const [slice, rest] = this._splitTable(head, remaining, measureOpt);
              trackSplit(slice, rest, remaining);
              this._placeWithSeam(activePage, slice, leftM, resumeTop, printableW, tmpl, onHeading, null, 'span');
              resumeTop += slice.height;
              items.splice(cursor, 1, ...(rest ? [rest] : []));
              if (!rest) cursor++;
              continue;
            }

            // General item (paragraph, code, list-item, quote, rule, math, image).
            // Footer clamp: an item taller than the remaining space moves whole
            // to the next page; at page top, multi-line text splits by lines so
            // nothing ever crosses contentBottomY. Only truly atomic oversize
            // items (images) are accepted and counted as overfull.
            const itemH = head.height || 14;
            if (itemH <= remaining + OVER_TOL) {
              let seamB = null;
              if (resumeTop > pageTopY) {
                seamB = recordSeam(activePage, resumeTop, 'span', classForItemKind(items[cursor - 1]));
              }
              this._placeWithSeam(activePage, head, leftM, resumeTop, printableW, tmpl, onHeading, seamB, 'span');
              resumeTop += itemH;
              cursor++;
            } else if (resumeTop > pageTopY) {
              break; // Break to next page
            } else {
              const [slice, rest] = this._splitParagraph(head, remaining);
              if (rest) {
                trackSplit(slice, rest, remaining);
                this._placeWithSeam(activePage, slice, leftM, resumeTop, printableW, tmpl, onHeading, null, 'span');
                resumeTop += slice.height;
                items.splice(cursor, 1, slice, rest);
                cursor++;
              } else {
                trackSplit(head, null, remaining);
                this._placeWithSeam(activePage, head, leftM, resumeTop, printableW, tmpl, onHeading, null, 'span');
                resumeTop += itemH;
                cursor++;
              }
            }
          }
          chunkIdx++;
          firstPageOfBlock = false;
          continue;
        }

        regions: for (;;) { // regions + spans within the page
          const remaining = contentBottomY - resumeTop;
          if (cursor >= items.length || remaining < MIN_REGION) break;
          const head = items[cursor];

          // Caption builders (shared by region-opening promotion below and
          // the mid-bite peel after the bite loop).
          const buildCaptionPromo = (rs, re) => {
            const promo = [];
            let promoH = 0;
            for (let hi = rs; hi < re; hi++) {
              const h = items[hi];
              if (h.kind === 'heading') {
                const spanTitleW = Math.max(10, printableW - (h.titleWOffset || 0));
                const spanLines = wrapRunsToLines(h.runs, 'helvetica-bold', h.fontSize, spanTitleW, measureOpt);
                const spanExtraH = (h.decor && h.decor.extraH !== undefined) ? h.decor.extraH : 6;
                const spanH = (h.topMargin || 0) + spanLines.length * h.lineHeight + spanExtraH;
                promo.push({ ...h, lines: spanLines, height: spanH });
                promoH += spanH;
              } else {
                // Single → level-3 heading shape (parse-time H3 metrics).
                const decor3 = (tmpl.headingDecorators && tmpl.headingDecorators[3]) || {};
                const fs3 = decor3.fontSize || 9.5;
                const lh3 = fs3 * fontRatio + 0.8;
                const tw = Math.max(10, printableW - (decor3.titleWOffset || 0));
                const lines = wrapRunsToLines(h.runs, 'helvetica-bold', fs3, tw, measureOpt);
                const extra = decor3.extraH !== undefined ? decor3.extraH : 6;
                const tm = resumeTop > pageTopY ? headingSpaceBefore(tmpl.headingDecorators, 3) : 0;
                const C = tmpl.colors || {};
                const spanH = tm + lines.length * lh3 + extra;
                promo.push({
                  kind: 'heading', level: 3,
                  text: h.runs.map((r) => r.text).join(''), runs: h.runs, lines,
                  height: spanH, topMargin: tm, fontSize: fs3, lineHeight: lh3,
                  titleWOffset: decor3.titleWOffset || 0, decor: decor3,
                  color: decor3.textColor || (C.textmuted || '#4B5563'), align: 'left',
                });
                promoH += spanH;
              }
            }
            return { promo, promoH };
          };
          const placeCaptionPromo = (built) => {
            let seamP = null;
            if (resumeTop > pageTopY) {
              seamP = recordSeam(activePage, resumeTop, 'span', SEAM_CLASS.SPAN_EDGE);
            }
            let firstPromo = true;
            for (const ph of built.promo) {
              this._placeWithSeam(activePage, ph, leftM, resumeTop, printableW, tmpl, onHeading, firstPromo ? seamP : lastSeamSeq(activePage), 'span');
              resumeTop += ph.height;
              firstPromo = false;
              recordSeam(activePage, resumeTop, 'span', classForItemKind(ph));
            }
            prevRegionC2Len = 0; // full-width caption resets the reading flow
          };
          // Keep caption with its table: promote only when the span still
          // fits whole below the run, or at page top where a split is
          // inevitable and the caption must ride the opening slice.
          // Otherwise fall through — the keep-with-next path travels both
          // to a fresh page together.
          const tryPromoteAt = (rs, re) => {
            const built = buildCaptionPromo(rs, re);
            const spanH = (items[re].height || 14);
            if (!(built.promoH <= remaining + OVER_TOL)) return false;
            if (!(spanH <= (remaining - built.promoH) + OVER_TOL) && resumeTop > pageTopY) return false;
            placeCaptionPromo(built);
            cursor = re;
            return true;
          };

  
          // Rotated table (Option D1/D2): dedicated portrait page carrying one
          // landscape table. Page-break before AND after: break first when
          // mid-page, then place at top (slicing pre-rotation to the
          // landscape horizontal fit) and always break after.
          if (head.kind === 'table' && head.rotated === true) {
            if (resumeTop > pageTopY) break; // fresh dedicated page
            let placee = head;
            let rest = null;
            if (head.height > printableW + OVER_TOL) {
              [placee, rest] = this._splitTable(head, printableW);
              trackSplit(placee, rest, printableW);
            }
            const sub = { elements: [] };
            this._compileItem(sub, placee, 0, 0, placee.tableW, tmpl);
            activePage.elements.push({
              type: 'rotated',
              angle: placee.rotationAngle ?? 90,
              mode: placee.rotationMode ?? 'd1',
              // Landscape box (placee.tableW × placee.height) mapped onto the
              // portrait page; chrome stays portrait outside the transform.
              x: leftM,
              y: contentTopY,
              w: placee.tableW,
              h: placee.height,
              boxW: printableW,
              boxH: availableColH,
              children: sub.elements,
            });
            // Splice replaces the table with rest (or removes it); cursor
            // already aims at the next unconsumed item — do NOT advance.
            items.splice(cursor, 1, ...(rest ? [rest] : []));
            break; // dedicated page: content always resumes next page
          }

          // Caption promotion: a caption run directly followed by a
          // panoramic span introduces that span (table/figure caption), so
          // the run renders full-width — one column, not two — with its
          // table instead of stranding in the two-column flow. A caption run
          // is a heading run, or one caption-like single (L1 bold bullet or
          // bold paragraph ending in ':', converted to a level-3 heading:
          // no marker, no TOC entry).
          if (blockCols === 2 && !isSpan(head)) {
            let j = cursor;
            while (j < items.length && items[j].kind === 'heading') j++;
            if (j > cursor && j < items.length && isSpan(items[j])) {
              if (tryPromoteAt(cursor, j)) continue;
            } else if (j === cursor && cursor + 1 < items.length && isSpan(items[cursor + 1])
              && isCaptionSingle(items[cursor])) {
              if (tryPromoteAt(cursor, cursor + 1)) continue;
            }
          }

          // Panoramic span: full printable width at the running top.
          if (isSpan(head)) {
            // Caption adjacency: a span placed directly under its promoted
            // caption sheds its topGap — the caption's own trailing space
            // already provides the air, so top and bottom rhythm match
            // instead of stacking. Detected by ownership, not Y proximity:
            // the last seam is a span-scope headingBond sitting exactly at
            // this top (only caption promotion records that shape).
            if ((head.topGap || 0) > 0) {
              const _seams = activePage._stretchSeams || [];
              const _last = _seams[_seams.length - 1];
              if (_last && _last.klass === SEAM_CLASS.HEADING_BOND && _last.scope === 'span'
                && Math.abs(_last.y - resumeTop) < 1e-6) {
                head.height = (head.height || 0) - head.topGap;
                head.topGap = 0;
              }
            }
            if (head.height <= remaining) {
              panoramicTransitions++;
              let seamC = null;
              if (resumeTop > pageTopY) {
                seamC = recordSeam(activePage, resumeTop, 'span', SEAM_CLASS.SPAN_EDGE);
              }
              this._placeWithSeam(activePage, head, leftM, resumeTop, printableW, tmpl, onHeading, seamC, 'span');
              resumeTop += head.height;
              prevRegionC2Len = 0; // full-width span resets the reading flow
              cursor++;
              continue;
            }
            if (resumeTop > pageTopY) break; // retry at top of next page
            if (head.kind === 'image') break; // unsplittable: fits at top by maxAllowedH cap
            const [slice, rest] = this._splitTable(head, remaining, measureOpt);
            trackSplit(slice, rest, remaining);
            panoramicTransitions++;
            this._placeWithSeam(activePage, slice, leftM, resumeTop, printableW, tmpl, onHeading, null, 'span');
            resumeTop += slice.height;
            items.splice(cursor, 1, ...(rest ? [rest] : []));
            if (!rest) cursor++;
            continue; // rest (if any) is panoramic → breaks page next check
          }

          // Full-width divider: `---` adjacent to a panoramic table spans the
          // page at the running top, then 2-column flow resumes below it.
          if (head.kind === 'rule' && isRuleSpan(head, cursor)) {
            if (head.height <= remaining + OVER_TOL) {
              head.fullWidth = true;
              let seamD = null;
              if (resumeTop > pageTopY) {
                seamD = recordSeam(activePage, resumeTop, 'span', SEAM_CLASS.SPAN_EDGE);
              }
              this._placeWithSeam(activePage, head, leftM, resumeTop, printableW, tmpl, onHeading, seamD, 'span');
              resumeTop += head.height;
              prevRegionC2Len = 0; // full-width rule resets the reading flow
              cursor++;
              continue;
            }
            if (resumeTop > pageTopY) break; // retry at top of next page
            head.fullWidth = true;
            this._placeWithSeam(activePage, head, leftM, resumeTop, printableW, tmpl, onHeading, null, 'span');
            resumeTop += head.height;
            cursor++;
            continue;
          }

          // Normal region: greedy bite of non-span items, balanced.
          // Replan loop (sample4 G7): balance + boundary search retry on a
          // shrunken bite when col1 would end stranded on a heading (the
          // fit-capped search cannot move off it without footer bleed).
          const cap = remaining * 2;
          const biteStart = cursor;
          let biteH = 0;
          while (cursor < items.length && !isSpan(items[cursor]) && !isRuleSpan(items[cursor], cursor) && biteH + (items[cursor].height || 14) <= cap) {
            biteH += (items[cursor].height || 14);
            cursor++;
          }
          // Caption peel (atomic): a bite ending in a caption run directly
          // before a panoramic span keeps its non-caption prefix as the
          // column region — but ONLY when caption + span provably still fit
          // in what the prefix leaves behind. Room is measured from the
          // PLANNED prefix foot (balanced columns overlap in Y, so the
          // height sum wildly overstates the foot and would refuse room
          // that exists), and only when the prefix fits remaining even
          // unbalanced (so the replan below takes the same balanced split
          // the probe priced — otherwise the bite stays whole: peeling a
          // col1-filling prefix while deferring the run voids col2).
          // Strictly interior only (an all-caption bite keeps the legacy
          // keep-with-next path, which travels it with its span).
          if (blockCols === 2 && cursor < items.length && isSpan(items[cursor]) && cursor > biteStart) {
            const run = captionRunBefore(items, isSpan, cursor, biteStart);
            if (run && run.start > biteStart) {
              const prefix = items.slice(biteStart, run.start);
              const probeLoose = this.galleyEngine.planColumns(prefix, {
                availableHeight: remaining, balance: false,
              });
              const probeEven = this.galleyEngine.planColumns(prefix, {
                availableHeight: remaining, balance: true,
              });
              const placedAll = (probeLoose.unplaced || []).length === 0
                && (probeEven.unplaced || []).length === 0;
              const foot = Math.max(colHeight(probeEven.col1), colHeight(probeEven.col2));
              const built = buildCaptionPromo(run.start, run.end);
              const peelSpanH = (items[cursor].height || 14);
              if (placedAll && built.promoH + peelSpanH <= remaining - foot + OVER_TOL) cursor = run.start;
            }
          }
          if (cursor === biteStart) {
            // Single oversized item: move whole to a fresh page when it fits
            // there (v1 ensureSpace parity); at page top, split multi-line
            // text by lines so columns never cross the footer. Only truly
            // atomic items are accepted and counted as overfull downstream.
            const singleH = items[cursor].height || 14;
            if (singleH > remaining + OVER_TOL && resumeTop > pageTopY) {
              break regions;
            }
            if (singleH > remaining + OVER_TOL) {
              const [slice, rest] = this._splitParagraph(items[cursor], remaining);
              if (rest) {
                trackSplit(slice, rest, remaining);
                items.splice(cursor, 1, slice, rest);
              }
            }
            biteH += (items[cursor].height || 14);
            cursor++;
          }
          replan: for (;;) {
          let bite = items.slice(biteStart, cursor);

          // Iterative shrink: balance, and while a column overflows (or the
          // bite ends on a heading), return the last item and rebalance.
          // A lone over-tall table moves whole to a fresh column when it
          // fits there (v1 keep-with-next adhesion); only taller-than-column
          // tables are row-split instead of overflowing.
          // `regionBalance` is the partition strategy for THIS region: the
          // user's column-break opt-in, widened to a run that ends at a
          // full-width span. Such a run must share its height across both
          // columns so the span lands flush under them; run it continuous and
          // col1 fills to the page foot, the span no longer fits below, and the
          // page keeps one used column with the span alone on the next one —
          // a false column break.
          let regionBalance = balanceOn;
          let balancePlan = null;
          let pageBreak = false;
          // Tail status of the plan the shrink loop accepts; read after the
          // loop by the terminal disparity fine-tune below.
          let isDocTailRegion = false;
          for (;;) {
            // Span lookahead: when the bite stops at a heading run (cap-gated
            // exactly on a heading run, or a caption run the promotion above
            // will consume), the span behind the run still governs this
            // region — the widening must see past the run, or the prefix
            // fills col1 alone and voids col2 for the page. Equivalent to the
            // direct test in every other shape (cursor at a span, or at a
            // non-heading non-span, answers identically).
            let spanAheadIdx = cursor;
            while (spanAheadIdx < items.length && items[spanAheadIdx].kind === 'heading') spanAheadIdx++;
            const isFollowedBySpan = spanAheadIdx < items.length && isSpan(items[spanAheadIdx]);
            balancePlan = this.galleyEngine.planColumns(bite, {
              availableHeight: remaining,
              balance: regionBalance,
            });
            if (isFollowedBySpan && !regionBalance && (balancePlan.unplaced || []).length === 0) {
              regionBalance = true;
              balancePlan = this.galleyEngine.planColumns(bite, {
                availableHeight: remaining,
                balance: true,
              });
            }
            // Atomic-list repair: continuous fill can stop one column early
            // when the next whole item (or a peeled parent chain) does not
            // fit. If that leaves a material disparity, re-partition the same
            // bite by whole items. Full continuous pages stay untouched, so a
            // page that is already flush does not become symmetrically short.
            if (atomicListBalance && !regionBalance && (balancePlan.unplaced || []).length === 0) {
              const h1 = colHeight(balancePlan.col1);
              const h2 = colHeight(balancePlan.col2);
              if (Math.abs(h1 - h2) > 2 * bodyLineH) {
                regionBalance = true;
                balancePlan = this.galleyEngine.planColumns(bite, {
                  availableHeight: remaining,
                  balance: true,
                });
              }
            }
            // Terminal column balancing (gate-4 doctrine, extended to the
            // default flow): every block's final region — stream exhausted,
            // nothing queued after it — widens to the balanced partition so
            // both columns terminate at the same vertical position on that
            // block's last page, even in coluna corrida mode (v1 multicols
            // parity: each block is its own multicols environment, and LaTeX
            // multicol always balances an environment's final page). Mid-
            // block regions keep the honest continuous full-foot fill — a
            // balance void there reads as a broken column, but at a section
            // end the even ending is what the reader expects. Adoption is
            // guarded like the span widening above (the continuous fill
            // already placed the whole remaining stream), plus a fit check:
            // item granularity can push the balancer's split past the
            // continuous fill, and the returned item would stagger the tail
            // columns below an already-short col2 — worse than the honest
            // ragged end — so in that case the continuous split stands.
            const isDocTailRegionNow = cursor >= items.length
              && (balancePlan.unplaced || []).length === 0;
            isDocTailRegion = isDocTailRegionNow;
            if (isDocTailRegionNow && !regionBalance) {
              const tailBalanced = this.galleyEngine.planColumns(bite, {
                availableHeight: remaining,
                balance: true,
              });
              // Caption-pair guard: the balanced tail split may not separate
              // a heading from its atomic follower (table, image, math) at
              // the column seam. The heading is the table's caption — split
              // across columns it reads broken, and on a nearly-empty last
              // page it leaves one column with a lone heading and the other
              // with the orphaned table (taskfiles/2 sampletext p6,
              // 2026-10-03: "Matriz diagnóstica" heading | its table). The
              // continuous split keeps the pair stacked in col1 even with a
              // void col2: the reader sees heading above table, which is the
              // only honest way to end.
              const isAtomItem = (it) => !!it
                && (it.kind === 'table' || it.kind === 'image' || it.kind === 'math');
              const tailSplitsPair = tailBalanced.col1.length > 0
                && tailBalanced.col2.length > 0
                && tailBalanced.col1[tailBalanced.col1.length - 1].kind === 'heading'
                && isAtomItem(tailBalanced.col2[0]);
              if (!tailSplitsPair
                && colHeight(tailBalanced.col1) <= remaining + OVER_TOL
                && colHeight(tailBalanced.col2) <= remaining + OVER_TOL) {
                regionBalance = true;
                balancePlan = tailBalanced;
              }
            }
            // Zero-placement guard: the continuous fill's opening-heading
            // deferral returns col1=[] AND col2=[] with the bite handed back
            // in `unplaced` — a plan that passes the acceptance fit test
            // vacuously (0 <= remaining) and re-enters the regions loop on
            // the same page forever (the spin hazard
            // tests/lean/stranded-replan-bound.lean.js pins; measured
            // 2026-09-30 on sampletext2/bauhaus_minimalist p3: a 31.9pt
            // leftover with [heading, list-item] queued spun until the
            // stack died). Nothing fits here; the bite must travel to a
            // fresh page, where the heading opens with room for its body.
            // At page top the deferral cannot fire (a full page fits any
            // heading's clearance), so the break always makes progress.
            if (balancePlan.col1.length === 0 && balancePlan.col2.length === 0
              && bite.length > 0) {
              // The bite consumed the whole remaining stream, so `cursor`
              // already sits at `items.length`; the old `cursor < items.length`
              // test read that as "nothing queued" and accepted a plan that
              // placed NOTHING. The continuous branch then reset `cursor` to
              // `biteStart` and re-entered the same region forever (measured
              // 2026-10-26: a 16-row table after two other tables on a
              // 298.7pt region spun 490k trace lines in 3s). The real queue is
              // `bite.length` / `unplaced`, not the post-bite cursor.
              if (resumeTop > pageTopY) {
                cursor = biteStart;
                pageBreak = true;
                break;
              }
              // Fresh page and still zero placements: the all-unplaced shape
              // can only be an atomic item taller than the page (normally a
              // table). Split that table so the page makes progress; anything
              // else is placed alone. Either way the region cannot spin.
              const forced = bite[0];
              if (forced && forced.kind === 'table'
                && (forced.height || 14) > remaining + OVER_TOL) {
                const [slice, rest] = this._splitTable(forced, remaining, measureOpt);
                trackSplit(slice, rest, remaining);
                items.splice(biteStart, 1, slice, ...(rest ? [rest] : []));
                balancePlan = { ...balancePlan, col1: [slice], col2: [], unplaced: [] };
                cursor = biteStart + 1;
                break;
              }
              balancePlan = { ...balancePlan, col1: [forced], col2: [], unplaced: [] };
              cursor = biteStart + 1;
              break;
            }
            const h1 = colHeight(balancePlan.col1);
            const h2 = colHeight(balancePlan.col2);
            const tail = bite[bite.length - 1];
            const nextItem = cursor < items.length ? items[cursor] : null;
            const tailIsHeading = bite.length > 1 && tail.kind === 'heading';
            // When list items are atomic, a parent at the column foot is a
            // legal whole-item boundary: the balanced partition already chose
            // the closest even split, and peeling the parent chain would only
            // recreate the short-column void this policy exists to avoid.
            const tailIsParentList = splitListItems
              && bite.length > 1 && tail.kind === 'list-item'
              && nextItem && nextItem.kind === 'list-item' && nextItem.level > tail.level;
            // Run-aware keep-with-next: a trailing heading followed by another
            // heading keeps company (the run travels together), so it never
            // strands — stop shrinking. Before body content (or a panoramic
            // span), keep it only when the follower still fits the leftover
            // page space; otherwise strip it so it travels with its body to a
            // fresh page/column. Doc end: nothing to strand from — keep.
            const tailFollower = tailIsHeading ? nextItem : null;
            //
            // A heading child is a different case from any other follower, and
            // the exemption above is not enough for it. `##` then `###` are two
            // items; a column edge may fall between them, and then the `###`
            // renders at the TOP of the next column while the `##` sits at the
            // BOTTOM of this one — the reader meets the child before the
            // section it belongs to (G19c: sample2/bauhaus p4, and
            // sample2/bauhaus_minimalist p1). Exempting the run as a unit
            // prevents the strand but not the inversion: the run fits
            // vertically yet still splits across the boundary.
            //
            // So: a heading whose IMMEDIATE successor is a deeper heading must
            // not be left at the foot of a region. Depth, not mere
            // isHeading(), is what makes it the child — a sibling H2 following
            // an H2 is a new section, and splitting before it is normal
            // typesetting. The deeper child carries the parent's meaning, so
            // the pair travels together or not at all.
            const tailChildIsHeading = !!(tailFollower && tailFollower.kind === 'heading'
              && (tailFollower.level || 0) > (tail.level || 0));
            let tailStranded = false;
            // The split is handled downstream, in the column-boundary
            // keep-with-next block: it moves the parent across to open col2 in
            // front of its child, reordering without emptying the column, so it
            // costs no foot void. Ungating that block (it was wrongly gated on
            // `regionBalance`) is what took the corpus from 5 stranded to 2;
            // bypassing the shift loop's evenness guard for a deep-child pair
            // took it 2 -> 1.
            //
            // An exemption for this case used to sit HERE, keyed on the plan's
            // own columns (`planCol1Tail`/`planCol2Head`/
            // `planSplitsParentFromChild`). It was removed on 2026-09-29 after
            // mutation: deleting the condition changes no gate and no flush
            // metric — census 1 with and without it — so it was carrying
            // nothing. Do not re-add it; re-measure if you do.
            if (tailIsHeading && tailFollower) {
              const placedH = Math.max(h1, h2);
              if (tailChildIsHeading) {
                // The child is the parent's first content: keep the parent only
                // when the child can be placed in what is left of this column.
                // Otherwise the parent is stripped and both travel on.
                const childH = tailFollower.height || 14;
                tailStranded = childH > (remaining - placedH + OVER_TOL);
              } else if (tailFollower.kind !== 'heading') {
                tailStranded = (tailFollower.height || 14) > (remaining - placedH + OVER_TOL);
              }
              // A same-level or shallower heading follower is a sibling: the run
              // keeps company unconditionally, exactly as before (G19b).
            }
            if ((h1 <= remaining + OVER_TOL && h2 <= remaining + OVER_TOL && !tailStranded && !tailIsParentList) || bite.length <= 1) {
              if (bite.length === 1 && bite[0].kind === 'heading' && resumeTop > pageTopY) {
                // Lone heading mid-page: defer only when its keep-with-next
                // clearance fails (heading + following lines must fit). When
                // clearance passes the heading is placed and the run
                // accumulates — the next heading satisfies keep-with-next, so
                // heading runs stay together instead of cascading one per
                // page. (At page top the engine places it: progress
                // guarantee, and the body follows on the same page.)
                const subItems = items.slice(biteStart + 1);
                if (subItems.length > 0) {
                  const reqClearance = this.antiOrphan.calculateRequiredClearance(bite[0], subItems);
                  const follower = subItems[0];
                  // Panoramic spans never split mid-page: a lone heading
                  // before one is placed only when the whole span still fits
                  // the leftover space, else both travel to a fresh page.
                  const spanNeedsFit = follower && (follower.kind === 'table' || follower.kind === 'image') && follower.panoramic === true
                    ? (follower.height || 14) > (remaining - (bite[0].height || 14) + OVER_TOL)
                    : false;
                  if (remaining < reqClearance || spanNeedsFit) {
                    keepWithNextBreaks++;
                    cursor = biteStart;
                    pageBreak = true;
                    break;
                  }
                }
              }
              if (bite.length === 1 && bite[0].height > remaining + OVER_TOL && resumeTop > pageTopY
                && bite[0].kind !== 'table') {
                // Lone over-tall non-table item: whole thing goes next page
                // (tables have their own split/adhesion path below).
                cursor = biteStart;
                pageBreak = true;
                break;
              }
              // Stacked-sliver kinship: a lone CHILD bullet stacking at the
              // foot of the shorter column while its parent sits in the
              // other (taller) column of the same page reads BEFORE that
              // parent (column-major order) — detaching the child from its
              // parent and wedging it inside any column-boundary sentence
              // split (bauhaus: "Valor de referencia" lvl-2 sliver at col0
              // y=797 vs parent "Porcentaje" lvl-1 at col1 y=786). The bite
              // is a prefix/suffix partition, so a non-empty previous c2
              // always holds the predecessor: the inversion is by
              // construction, and the bite travels whole to a fresh page,
              // where it opens with its kin. At page top the guard cannot
              // fire (progress guarantee). Full-width spans/rules/captions
              // reset prevRegionC2Len — they read in order between regions.
              // Scoped to list-item child-after-parent (sliver.level >
              // pred.level): sibling/new-section slivers are the same
              // physical shape but trip no gate and cascade pagination
              // corpus-wide when deferred; they stay a known remainder
              // (see tests/lean/stacked-sliver-order). Paragraph/blockquote
              // slivers carry no level and are out of scope likewise.
              if (bite.length === 1 && resumeTop > pageTopY && prevRegionC2Len > 0
                && bite[0].kind === 'list-item'
                && biteStart > 0 && items[biteStart - 1]
                && items[biteStart - 1].kind === 'list-item'
                && (bite[0].level || 0) > (items[biteStart - 1].level || 0)) {
                cursor = biteStart;
                pageBreak = true;
                break;
              }
              if (bite.length === 1 && bite[0].kind === 'table' && bite[0].height > remaining + OVER_TOL) {
                if (bite[0].height <= pageAvailH + OVER_TOL && remaining < pageAvailH - OVER_TOL) {
                  cursor = biteStart; // un-consume: whole table goes next page
                  pageBreak = true;
                  break;
                }
                const [slice, rest] = this._splitTable(bite[0], remaining, measureOpt);
                trackSplit(slice, rest, remaining);
                items.splice(biteStart, 1, slice, ...(rest ? [rest] : []));
                cursor = biteStart + 1;
                bite = [slice];
                balancePlan = this.galleyEngine.planColumns(bite, {
                  availableHeight: remaining,
                  balance: balanceOn,
                });
              }
              break;
            }
            // Keep-with-next adhesion: the bite fits but would split a parent
            // list item — shrink and re-plan rather than stranding it at the
            // region end. (Trailing headings are handled run-aware above via
            // tailStranded: heading runs stay together, and a heading before
            // fitting body content keeps its place.)
            if (h1 <= remaining + OVER_TOL && h2 <= remaining + OVER_TOL
                && (tailStranded || tailIsParentList)) {
              keepWithNextBreaks++;
            }
            cursor--;
            bite = items.slice(biteStart, cursor);
          }
          if (pageBreak) break regions;

          // Boundary search (column-break mode only): col1 is always a
          // doc-order prefix of the bite, so shifting the boundary by ±k items
          // keeps global reading order. Bounded local search over split
          // positions (k in [-3, +3] around the balancer's split): pick the
          // min-disparity split that never moves a heading and never leaves a
          // column ending on one.
          // In continuous mode there is nothing to refine — the fill already
          // put everything each column could hold in it, and re-balancing would
          // shorten both columns to make them symmetric (the void the reader
          // reads as a broken column).
          const isHeading = (it) => !!it && it.kind === 'heading';
          const endsHeading = (list) => list.length > 0 && isHeading(list[list.length - 1]);
          let c1;
          let c2;
          if (regionBalance) {
            // Reconstruct bite order: balancer preserves relative order, so
            // concatenation recovers the sequence (col1 items precede col2's).
            // (Duplicate item refs across columns would corrupt this; the
            // balancer never duplicates — prefix/suffix partition.)
            const base1 = balancePlan.col1.slice();
            const base2 = balancePlan.col2.slice();
            const seq = [...base1, ...base2];
            const baseK = base1.length;
            let bestK = baseK;
            let bestDisp = Math.abs(colHeight(base1) - colHeight(base2));
            const canSearch = base1.length > 0 && base2.length > 0;
            // Pure heading runs bisect evenly (editorial balance over strand
            // doctrine): a run split 1+(n-1) leaves a lopsided void; ceil(n/2)
            // keeps both columns alive with reading order preserved.
            // Fit-gated: falls through to the normal search when a half would
            // overflow the region.
            let forcedEven = false;
            if (seq.length > 1 && seq.every((it) => it && it.kind === 'heading')) {
              const evenK = Math.ceil(seq.length / 2);
              if (colHeight(seq.slice(0, evenK)) <= remaining + OVER_TOL
                && colHeight(seq.slice(evenK)) <= remaining + OVER_TOL) {
                bestK = evenK;
                bestDisp = Math.abs(colHeight(seq.slice(0, evenK)) - colHeight(seq.slice(evenK)));
                forcedEven = true;
              }
            }
            for (let k = Math.max(0, baseK - 3); canSearch && !forcedEven && k <= Math.min(seq.length, baseK + 3); k++) {
              if (k === baseK) continue;
              const t1 = seq.slice(0, k);
              const t2 = seq.slice(k);
              // Never empty a non-empty column (single-column regions are a
              // layout decision, not a balancing refinement).
              if (t1.length === 0 || t2.length === 0) continue;
              // Fit constraint (sample4 H2): the shrink loop guarantees both
              // columns ≤ remaining + OVER_TOL — never let the ±3 search
              // re-introduce a ~12–30pt footer bleed for min disparity.
              if (colHeight(t1) > remaining + OVER_TOL || colHeight(t2) > remaining + OVER_TOL) continue;
              // Keep-with-next: a moved heading must keep following content,
              // and no column may end stranded on a heading.
              const moved = k < baseK ? base1.slice(k) : base2.slice(0, k - baseK);
              if (moved.some(isHeading)) { keepWithNextBreaks++; continue; }
              if (endsHeading(t1)) { keepWithNextBreaks++; continue; }
              const disp = Math.abs(colHeight(t1) - colHeight(t2));
              if (disp < bestDisp - 1e-9) {
                bestDisp = disp;
                bestK = k;
              }
            }
            // Col1 heading guard: a column boundary directly after a heading
            // leaves the heading at the bottom of col1. When col2 carries
            // following content the heading still flows (acceptable) — so only
            // shift the boundary while BOTH columns stay within the verified
            // fit (sample4 H2: the unconstrained shift pushed col2 ~21pt past
            // contentBottomY into the footer). Never strand: c2 is non-empty
            // throughout (bestK only decrements), so stopping early cannot
            // leave a heading without following content.
            //
            // Degeneracy skip: when the balancer's own col1 is ALL headings
            // and col2 opens with body content, every k the guard could walk
            // to also ends col1 on a heading — the walk cannot satisfy the
            // doctrine, it can only bottom out at bestK=1: a lone heading
            // over a void, its body in the other column. That is the
            // degenerate band this guard produced on
            // sampletext2/bauhaus p3 ([30pt | 107.8pt], 2026-09-30) — the
            // shape it exists to prevent, reproduced worse. In that
            // unsatisfiable case the balancer's split stands: the heading
            // run at col1's foot introduces col2's body across the seam,
            // the least-bad legal split.
            const guardUnsatisfiable = base1.length > 0
              && base1.every((it) => it && it.kind === 'heading')
              && base2.length > 0 && base2[0].kind !== 'heading';
            while (!forcedEven && !guardUnsatisfiable && bestK > 1
              && endsHeading(seq.slice(0, bestK))) {
              const nk = bestK - 1;
              if (colHeight(seq.slice(0, nk)) > remaining + OVER_TOL
                || colHeight(seq.slice(nk)) > remaining + OVER_TOL) break;
              bestK = nk;
              keepWithNextBreaks++;
            }
            c1 = seq.slice(0, bestK);
            c2 = seq.slice(bestK);
          } else {
            // Continuous fill owns the split: the region consumed exactly what
            // the two columns could hold and everything else returns to the
            // stream, so the page never ends with a column still full of room.
            c1 = balancePlan.col1.slice();
            c2 = balancePlan.col2.slice();
            cursor = biteStart + c1.length + c2.length;
            // The col1→col2 boundary obeys the same doctrine as the page foot
            // below: continuous flow runs to the column foot, so the item
            // opening col2 breaks by lines and its head-slice fills col1's
            // remaining space. Without this split the fill stops col1 short at
            // the first item that does not fit whole, and when that stop
            // leaves a heading-run at col1's foot the column-boundary
            // keep-with-next block below has only bad moves left — its
            // truncate-and-replan fallback re-plans a shorter bite, and in
            // continuous mode a shorter bite empties col2 instead of
            // rebalancing (each peel removes one item from the region tail
            // while the fill still consumes the whole bite in col1). That is
            // the sampletext/base p2 collapse: a healthy [701pt + 710pt]
            // page peeled itself down to [647pt + void], and the following
            // band then pinned its col2 content at the dead band's col1
            // depth. Splitting the boundary item here keeps col1 flush AND
            // puts body lines under any trailing heading-run in the same
            // column, so keep-with-next never needs the fallback.
            // Atoms (headings, tables, images, math) never split: those are
            // the reading order's atoms, and a short col1 rag is the honest
            // price of keeping one intact.
            if (c2.length > 0) {
              const boundary = c2[0];
              const col1Leftover = remaining - colHeight(c1);
              const boundarySplittable = boundary
                && (boundary.kind === 'paragraph' || boundary.kind === 'list-item' || boundary.kind === 'blockquote')
                && Array.isArray(boundary.lines) && boundary.lines.length >= 4;
              if (boundarySplittable && col1Leftover >= 2 * (boundary.lineHeight || bodyLineH)) {
                const [slice, rest] = this._splitParagraph(boundary, col1Leftover);
                if (rest && slice.lines && slice.lines.length >= 2 && rest.lines.length >= 2) {
                  items.splice(biteStart + c1.length, 1, slice, rest);
                  c1.push(slice);
                  c2[0] = rest;
                  cursor += 1;
                }
              }
            }
            // Continuous flow runs to the column foot: the item opening the next
            // column breaks by lines and keeps this one full. That is what makes
            // "coluna corrida" continuous, and it is why no glue or feathering
            // is needed to fake an even page bottom — the void it would have
            // filled is now carrying text the reader actually wants.
            // Never split for a single line at the foot, and never a heading,
            // table, image or math box: those are atoms of the reading order.
            const lastCol = c2.length > 0 ? c2 : c1;
            const tailItem = items[cursor];
            const colLeftover = remaining - colHeight(lastCol);
            if (tailItem && tailItem.kind !== 'heading'
              && colLeftover >= 2 * (tailItem.lineHeight || bodyLineH)) {
              const [slice, rest] = this._splitParagraph(tailItem, colLeftover);
              if (rest && slice.lines && slice.lines.length >= 2) {
                items.splice(cursor, 1, slice, rest);
                lastCol.push(slice);
                cursor += 1;
              }
            }
          }

          // Column-boundary keep-with-next (sample4 G7): no column may end
          // stranded on a heading while content is queued (defect #2 in
          // IMG_1086: lone heading at the bottom of the left column).
          // Resolution order: (1) shift trailing run-headings across to open
          // col2 while it still fits — the heading lands atop following body
          // instead of stranding col1's foot (perfect keep-with-next);
          // (2) a single heading opening col1 flows while col2 carries
          // content — accept; (3) otherwise truncate before the heading
          // (replan) so it travels with following content, or defer the
          // whole bite to a fresh page when it opens an empty column.
          // Terminates: shifts strictly shrink col1 (never empty); the
          // fallback strictly shrinks the bite.
          // NOT gated on regionBalance. The column-boundary keep-with-next
          // mechanism is about the reading order at a column foot, not about
          // which partition strategy produced the split; gating it on
          // regionBalance left continuous-mode regions with no strand
          // prevention at all (measured 2026-09-29: on
          // sampletext2/bauhaus_minimalist p1 the plan "Adaptación celular:"
          // / "Mecanismos adaptativos basales:" has bal=false, and both
          // this block and the col1-heading guard inside the balance search
          // are skipped, so the heading strands at the column foot).
          //
          // Terminates as documented above: the shift loop strictly shrinks c1
          // without emptying it, and each fallback either strictly shrinks the
          // bite (continue replan) or ends the region (break regions).
          if (endsHeading(c1) && bite.length > 1) {
            keepWithNextBreaks++;
            // Shift trailing run-headings across to open col2 while it still
            // fits — but stop at the even split: shifting past balance trades
            // one strand for a lopsided void. A further shift that still fits
            // yet unbalances means evenness is reached (accept below).
            // Evenness-exempt shifts: a heading-run whose own body OPENS col2
            // keeps company regardless of the balance delta — moving it is a
            // keep-with-next correction, not a balancing refinement. This
            // covers a deeper heading child (childIsOwnChild) and any body
            // follower (bodyFollows), including atoms the line-split cannot
            // absorb (a compact table opening col2 — taskfiles/2 sampletext
            // 2026-10-03: the H4 lead-in at col1's foot, its table in col2).
            while (c2.length > 0 && c1.length > 1 && endsHeading(c1)
                && colHeight(c2) + (c1[c1.length - 1].height || 14) <= remaining + OVER_TOL) {
              const h = c1[c1.length - 1];
              const hh = h.height || 14;
              const before = Math.abs(colHeight(c1) - colHeight(c2));
              const after = Math.abs((colHeight(c1) - hh) - (colHeight(c2) + hh));
              const childIsOwnChild = c2[0] && c2[0].kind === 'heading'
                && (c2[0].level || 0) > (h.level || 0);
              // Continuous-mode only: in balanced mode the boundary search
              // has already placed the split deliberately (its degeneracy
              // skip keeps [H,H,H | body] intact on heading-run-led runs —
              // sampletext2/bauhaus p3), and an evenness-exempt shift here
              // would walk every heading across and rebuild the lone-heading
              // lopsided band that skip exists to prevent.
              const bodyFollows = !regionBalance && c2[0] && c2[0].kind !== 'heading';
              if (after >= before - 1e-9 && !childIsOwnChild && !bodyFollows) break;
              c1 = c1.slice(0, -1);
              c2 = [h, ...c2];
              keepWithNextBreaks++;
            }
            if (endsHeading(c1)) {
              const furtherShiftFits = c2.length > 0 && c1.length > 1 && endsHeading(c1)
                && colHeight(c2) + (c1[c1.length - 1].height || 14) <= remaining + OVER_TOL;
              // A lone heading opening col1 while col2 carries content was
              // accepted unconditionally. That accept is a genuine keep-with-next
              // only when col2 opens with that heading's BODY: the heading then
              // keeps company, flowing onto the same spread as the content
              // that follows it. It is NOT a keep-with-next when col2 opens
              // with something else while the heading's own body is still
              // queued: the heading sits alone at the column foot and its body
              // starts a later column, which is the strand.
              //
              // Measured 2026-09-29 on sampletext2/bauhaus_minimalist p1, the
              // plans `Adaptación celular:` (col1, lone) and
              // `Mecanismos adaptativos basales:` (col2, lone) are exactly the
              // stranding pair: c2 opens with a DIFFERENT heading, so c1's lone
              // heading keeps nobody. The same shape appears at
              // `RESPUESTAS ADAPTATIVAS BASALES:` whose successor is a list
              // item. c2[0] — not items[cursor] — is the item that actually
              // follows c1's tail, because the columns are contiguous.
              const col2KeepsCompany = c1.length === 1 && c2.length > 0
                && c2[0] && c2[0].kind !== 'heading';
              // Continuous mode accepts the heading-run at col1's foot when
              // col2 opens with its body. The peel below exists for balanced
              // mode, where a truncated bite REBALANCES across both columns.
              // In continuous mode the re-planned shorter bite just empties
              // col2 — the fill consumes the whole bite in col1 — so each
              // peel strips a heading off the region and finally places a
              // col1-only band with a void col2. Measured twice:
              //   2026-09-30 sampletext/base p2: [701+710] -> [647+void]
              //   2026-10-03 taskfiles/2 sampletext (compact tables,
              //   bauhaus) p4: [584+760] -> [566+void] + a lone H4 band +
              //   the table pushed to p5, leaving col2 100% empty.
              // When the shift cannot fit (col2 already near-full) the
              // heading-at-foot-introducing-col2 is the least-bad legal
              // layout: reading order is preserved and the heading's body
              // is the very next thing the reader meets, across the seam.
              const continuousBodyFollower = !regionBalance && c2.length > 0
                && c2[0] && c2[0].kind !== 'heading';
              if (furtherShiftFits || continuousBodyFollower
                || (c1.length <= 1 && c2.length > 0 && col2KeepsCompany)) {
                // Even split reached (or a single heading opening the column
                // whose body immediately follows it in col2, or in continuous
                // mode a heading-run introducing col2's body): the run flows.
              } else if (c1.length <= 1) {
                if (resumeTop > pageTopY) {
                  cursor = biteStart;
                  break regions;
                }
                // Fresh page: cannot defer (progress guarantee) — place as-is.
              } else if (isV3 && c2.length > 0 && c1.length > 1) {
                cursor -= 1;
                continue replan;
              } else {
                cursor = biteStart + c1.length - 1;
                continue replan;
              }
            }
          }

          // Keep-with-next at column bottoms: never strand a heading as the
          // last placed item while queued content still waits (a heading must
          // always carry following lines with it) — unless the follower still
          // fits the leftover page space and lands on this page via the next
          // region or span path, in which case the heading keeps company.
          let strandedBreak = false;
          const queuedAfter = cursor < items.length;
          if (queuedAfter && (c1.length + c2.length) > 1) {
            const strandFollower = cursor < items.length ? items[cursor] : null;
            const placedH = Math.max(colHeight(c1), colHeight(c2));
            // A heading child is a special case, and it is NOT about height.
            // `##` then `###` are two items; a column edge can fall between
            // them, so the `###` renders at the top of the next column while
            // the `##` sits at the foot of this one, and the reader meets the
            // child before the section it belongs to (G19c — sample2/bauhaus
            // p4 and sample2/bauhaus_minimalist p1).
            //
            // The comparison that matters is c1's TAIL against c2's HEAD: the
            // child is already inside the region, sitting at the front of col2.
            // Measuring against `items[cursor]` (the follower after the whole
            // region) misses it entirely — that item is a list-item, so two
            // earlier guards at that spot fired on nothing. Verified directly:
            //   c1 last: heading/L2 "Hematologia e hemostasia:"
            //   c2 first: heading/L3 "Elementos figurado..."   <- its own child
            //
            // Depth is the discriminator, not isHeading(): a same-level heading
            // opening col2 is the next SECTION, and breaking there is ordinary
            // typesetting that this rule must not touch.
            // The parent-move branch that used to sit here is REMOVED. It moved a
            // parent heading from col1's tail into col2's head, then did
            // `cursor -= 1` to re-queue it. The decrement was WRONG: the heading had
            // already been consumed from `items` when it was placed in c1, so
            // re-queueing it planned and rendered the same paragraph a SECOND time.
            // Measured on an identical corpus, same-page duplicate lines >= 20 chars:
            // copy 34 (reference) 20, HEAD (pre-change) 20, with this branch 27 --
            // exactly 7 new cases and 0 repaired. The paragraph "Limite adaptativo: Si
            // la agresion supera el umbral ... sobreviene la lesion celular" appears
            // ONCE in taskfiles/sampletext2.md and TWICE on rendered page 2, once per
            // column (col0 x=42.9 y=291.6, col1 x=319.2 y=267.8). Found by an
            // independent reviewer and reproduced with a separate probe; both located
            // the same coordinates.
            //
            // Two smaller patches both measured WORSE, so no minimal edit repairs it:
            // dropping `cursor -= 1` alone gave 23 dups, disabling the spill sub-branch
            // alone gave 24. Removing the branch whole returns the corpus to 20,
            // exactly HEAD and the reference.
            //
            // It bought 4 stranded-heading gates, and it also made the flush WORSE
            // (max 100.87 vs 54.57, >40pt 3 vs 1). With it gone the flush is the best of
            // any arm measured (mean 2.60, p90 0.37, max 54.57, >12pt 4, >40pt 1) and
            // duplication is back at parity. The stranded-heading cost is real and
            // accepted deliberately: a duplicated sentence is worse than a section title
            // at a column foot, and the heading-order defect it targeted is one the
            // REFERENCE shares (3 inversions either side).
            // See COLUMN-FOOT-EVENNESS-ROADMAP.md.
            const followerFits = !strandFollower
              || (strandFollower.height || 14) <= (remaining - placedH + OVER_TOL);
            // The remaining case: col2 ends on a heading whose OWN deeper child
            // is inside the bite but was not placed — the partition is a
            // prefix/suffix split, so the items after col2's end simply flow to
            // the next region, and the `###` opens the next page while the `##`
            // closes this one.
            //
            // Measured 2026-09-29, sampletext2/bauhaus_minimalist p2:
            //   c1n=25 c2n=22  h1=558 h2=572  c2tail=heading/L2
            //   follower `###` at items index 104, bite 57..106, cursor=104,
            //   so folInBite=true and inC1/inC2 are both -1 — the follower was
            //   never offered to either column, it was left to the next region.
            //   Meanwhile col2 had 24pt of slack for an 18pt heading.
            //
            // So `followerFits` is the wrong gate for this shape: the follower
            // is available and it fits, but nothing offers it. Pull it in, and
            // while it is a deeper heading, pull in what follows it too — the
            // pair travels together, which is the same invariant the
            // `childIsOwnChild` bypass enforces across the column seam.
            const c2TailChild = c2.length > 0 && isHeading(c2[c2.length - 1])
              && strandFollower && strandFollower.kind === 'heading'
              && (strandFollower.level || 0) > (c2[c2.length - 1].level || 0)
              && c1.indexOf(strandFollower) < 0 && c2.indexOf(strandFollower) < 0
              && (strandFollower.height || 14) <= (remaining - colHeight(c2) + OVER_TOL);
            if (c2TailChild) {
              const extra = [];
              // Take the child, plus anything that only fits alongside it.
              while (cursor < items.length) {
                const cand = items[cursor];
                const nextH = (extra.length ? colHeight(c2) + colHeight(extra) : colHeight(c2))
                  + (cand.height || 14);
                if (nextH > remaining + OVER_TOL) break;
                extra.push(cand);
                cursor += 1;
                if (extra.length >= 4) break;
              }
              if (extra.length > 0) {
                c2.push(...extra);
                keepWithNextBreaks++;
              }
            }
            if (!followerFits) {
              if (c2.length > 0 && isHeading(c2[c2.length - 1])) {
                cursor -= 1;
                keepWithNextBreaks++;
                c2.pop();
              } else if (c2.length === 0 && c1.length > 1 && isHeading(c1[c1.length - 1])) {
                cursor -= 1;
                keepWithNextBreaks++;
                c1.pop();
              } else if (c2.length === 0 && c1.length === 1 && isHeading(c1[0]) && resumeTop > pageTopY) {
                const subItems = items.slice(cursor);
                const reqClearance = this.antiOrphan.calculateRequiredClearance(c1[0], subItems);
                if (remaining < reqClearance && subItems.length > 0) {
                  keepWithNextBreaks++;
                  cursor = biteStart;
                  strandedBreak = true;
                }
              }
            }
          }
          if (strandedBreak) break regions;
          if (isV3 && blockCols === 2 && c2.length === 0 && c1.length >= 2) {
            const rebal = this.galleyEngine.planColumns(c1, {
              availableHeight: remaining,
              balance: true,
            });
            if (rebal.col1.length > 0 && rebal.col2.length > 0
                && colHeight(rebal.col1) <= remaining + OVER_TOL
                && colHeight(rebal.col2) <= remaining + OVER_TOL) {
              c1 = rebal.col1;
              c2 = rebal.col2;
            }
          }
          balancePlan = { ...balancePlan, col1: c1, col2: c2 };
          // Continuous fill counts its own adhesion events: a heading deferred
          // out of a column is the same editorial decision the balance path
          // records when it shifts a boundary, and the corpus gate
          // (`keep-with-next-fires`) must stay meaningful in the default mode.
          keepWithNextBreaks += balancePlan.keepWithNextDeferrals || 0;

          // Terminal disparity fine-tuning (block tails only): item granularity
          // can leave the balanced tail split with a residual gap the
          // elastic glue below cannot mask — one long paragraph over one
          // short, or a lone item that never leaves col1 (galley.length ===
          // 1 → col2 empty). Close both the way multicol does: split the
          // boundary item across the column seam so both feet land together.
          // Line-quantized at the split closest to the balance point
          // (rounded, never past it — a split larger than the disparity
          // would overshoot and worsen); a slice under two lines never lands
          // at a column foot (orphan); the widow guard is tail-relaxed (a
          // tail rest has nothing after it to strand from — the section
          // ends here); atomic boundary items (tables, images, math,
          // headings) keep their integrity — the residual then stands as
          // the honest granularity limit, exactly as on interior balanced
          // regions. c1/c2 are always a doc-order prefix/suffix partition
          // of the bite, so the boundary item sits at a known stream index
          // and the splice preserves reading order. The cursor recheck keeps
          // a shrunk (non-tail) replan iteration from splicing an interior
          // region off a stale tail flag.
          if ((isDocTailRegion && cursor >= items.length) || (isV3 && regionBalance)) {
            if (c2.length === 0 && c1.length === 1) {
              // Lone-item tail: the single item keeps col1 and col2 void.
              // Split it across the seam (LaTeX multicol parity for a final
              // lone paragraph): both columns end alive, feet line-quantized
              // to the even split.
              const lone = c1[0];
              const splittable = lone
                && (lone.kind === 'paragraph' || lone.kind === 'list-item' || lone.kind === 'blockquote')
                && Array.isArray(lone.lines) && lone.lines.length >= 3;
              if (splittable) {
                const blh = lone.lineHeight || (lone.fontSize ? lone.fontSize * 1.15 : 12);
                const btotal = lone.lines.length;
                const n = Math.max(2, Math.min(Math.floor(btotal / 2), btotal - 1));
                const [slice, rest] = this._splitParagraph(lone, n * blh + 1, { skipWidow: true });
                if (rest && slice.lines.length >= 2) {
                  items.splice(biteStart, 1, slice, rest);
                  c1 = [slice];
                  c2 = [rest];
                  cursor += 1;
                }
              }
            } else if (c1.length > 0 && c2.length > 0) {
              const th1 = colHeight(c1);
              const th2 = colHeight(c2);
              // Attempt the split for any tail disparity beyond one line
              // pitch — the band where the elastic glue's per-gap cap starts
              // leaving visible residue (a 35pt box disparity with a 37pt
              // glyph delta sat exactly between the split's old >36pt gate
              // and the glue's ≤36pt ceiling, and neither fired). The
              // improvement guard below rejects every split that would
              // overshoot the balance point, so the attempt is free.
              if (Math.abs(th1 - th2) > bodyLineH) {
                const half = (th1 + th2) / 2;
                if (th1 > th2) {
                  // Col1 overhangs: its last item splits, the tail moves to
                  // col2. The move is X = boundary − k·lh (the rest's height)
                  // from col1 to col2; the balance point is X = d/2.
                  // Candidates: the closest line to it (clamped to a ≥2-line
                  // slice), and — only when it wins by ≥1.5 line pitches —
                  // the 1-line slice: an orphan by the strict definition,
                  // accepted at a tail where the alternative is a ≥2-line
                  // visible foot delta the glue's per-gap cap cannot close.
                  const boundary = c1[c1.length - 1];
                  const blh = boundary.lineHeight || (boundary.fontSize ? boundary.fontSize * 1.15 : 12);
                  const btotal = Array.isArray(boundary.lines) ? boundary.lines.length : 0;
                  if (btotal >= 3) {
                    const keepBefore = th1 - (boundary.height || 14);
                    const d = th1 - th2;
                    const evalK = (k) => {
                      const x = (boundary.height || 14) - k * blh;
                      return { k, after: Math.abs((th1 - x) - (th2 + x)) };
                    };
                    let best = evalK(Math.max(2, Math.min(Math.round((half - keepBefore) / blh), btotal - 1)));
                    const one = evalK(1);
                    if (one.after < best.after - 1.5 * blh) best = one;
                    const [slice, rest] = this._splitParagraph(boundary, best.k * blh + 1, { skipWidow: true });
                    const moved = (boundary.height || 14) - (slice.height || 0);
                    const after = Math.abs((th1 - moved) - (th2 + moved));
                    const minSlice = best.k === 1 ? 1 : 2;
                    if (rest && slice.lines.length >= minSlice && after < d - 0.5) {
                      items.splice(biteStart + c1.length - 1, 1, slice, rest);
                      c1[c1.length - 1] = slice;
                      c2 = [rest, ...c2];
                      cursor += 1;
                    }
                  }
                } else {
                  // Col2 overhangs: its first item splits, the head moves to
                  // col1. The move is X = k·lh (the slice's height) from col2
                  // to col1; the balance point is X = d/2. Same candidate
                  // ladder as the col1 branch above.
                  const boundary = c2[0];
                  const blh = boundary.lineHeight || (boundary.fontSize ? boundary.fontSize * 1.15 : 12);
                  const btotal = Array.isArray(boundary.lines) ? boundary.lines.length : 0;
                  if (btotal >= 3) {
                    const d = th2 - th1;
                    const evalK = (k) => {
                      const x = k * blh;
                      return { k, after: Math.abs((th1 + x) - (th2 - x)) };
                    };
                    let best = evalK(Math.max(2, Math.min(Math.round((half - th1) / blh), btotal - 1)));
                    const one = evalK(1);
                    if (one.after < best.after - 1.5 * blh) best = one;
                    const [slice, rest] = this._splitParagraph(boundary, best.k * blh + 1, { skipWidow: true });
                    const moved = slice.height || 0;
                    const after = Math.abs((th1 + moved) - (th2 - moved));
                    const minSlice = best.k === 1 ? 1 : 2;
                    if (rest && slice.lines.length >= minSlice && after < d - 0.5) {
                      items.splice(biteStart + c1.length, 1, slice, rest);
                      c1 = [...c1, slice];
                      c2[0] = rest;
                      cursor += 1;
                    }
                  }
                }
              }
            }
          }

          // Seam recording (VGA M3): inter-item boundary positions, each scoped
          // to the column band it opens. Spans/atomic tables are single items
          // — gaps never split them. Tier 1 is retired: no pad is reserved at
          // placement, so `resumeTop` carries no slack and pages can only
          // tighten (D-1); the allocator spends the real slack post-pass.
          // The seam record is the ONLY gap writer: the parallel legacy
          // Y-list of gap positions was written here and deleted unread
          // after the pass (removed at M5).
          if (isV3) {
            const stripTopGap = (it) => {
              if (!it) return it;
              if (it.kind === 'heading' && (it.topMargin || 0) > 0) {
                return { ...it, height: it.height - it.topMargin, topMargin: 0 };
              }
              if (it.kind === 'table' && (it.topGap || 0) > 0) {
                return { ...it, height: it.height - it.topGap, topGap: 0 };
              }
              return it;
            };
            if (c1.length > 0) c1[0] = stripTopGap(c1[0]);
            if (c2.length > 0) c2[0] = stripTopGap(c2[0]);
          }
          const regionSeqFallback = lastSeamSeq(activePage);
          const colSeq0 = new Array(c1.length).fill(regionSeqFallback);
          const colSeq1 = new Array(c2.length).fill(regionSeqFallback);
          {
            let gy0 = resumeTop;
            for (let gi = 0; gi < c1.length; gi++) {
              gy0 += (c1[gi].height || 14);
              if (gi < c1.length - 1) {
                colSeq0[gi + 1] = recordSeam(activePage, gy0, 'col:0', classForItemKind(c1[gi]));
              }
            }
            let gy1 = resumeTop;
            for (let gi = 0; gi < c2.length; gi++) {
              gy1 += (c2[gi].height || 14);
              if (gi < c2.length - 1) {
                colSeq1[gi + 1] = recordSeam(activePage, gy1, 'col:1', classForItemKind(c2[gi]));
              }
            }
          }

          if (process.env.V2_TRACE_PLACE) {
            // eslint-disable-next-line no-console
            console.log(`[V2_TRACE_PLACE] page=${currentPageIndex} mode=${regionBalance ? 'break' : 'run'} resumeTop=${resumeTop.toFixed(1)} remaining=${remaining.toFixed(1)} col1n=${c1.length} h1=${colHeight(c1).toFixed(1)} col2n=${c2.length} h2=${colHeight(c2).toFixed(1)} kinds=${bite.slice(0, 8).map((it) => it.kind).join(',')} c1tail=${c1.length ? c1[c1.length - 1].kind : '-'} c2tail=${c2.length ? c2[c2.length - 1].kind : '-'} queued=${cursor < items.length}`);
          }

          // Place Col 0 / Col 1 at the running top.
          let col0Y = resumeTop;
          for (let ci0 = 0; ci0 < c1.length; ci0++) {
            const item = c1[ci0];
            this._placeWithSeam(activePage, item, col0X, col0Y, colW, tmpl, onHeading, colSeq0[ci0], 'col:0');
            col0Y += (item.height || 14);
          }
          let col1Y = resumeTop;
          for (let ci1 = 0; ci1 < c2.length; ci1++) {
            const item = c2[ci1];
            this._placeWithSeam(activePage, item, col1X, col1Y, colW, tmpl, onHeading, colSeq1[ci1], 'col:1');
            col1Y += (item.height || 14);
          }

          // Column-flow cue anchors (balance mode only). Placement only
          // proposes; _stampFlowCues draws the marks after the flush post-pass
          // and drops any mark whose space is not clean, so no mark is ever
          // written over live text (later regions, panoramic spans and rotated
          // tables all land here after these anchors exist).
          //   column-cross: proposed for every region whose left column hands
          //     text to the right one. The old cue keyed on the height delta,
          //     so it appeared over a balance artifact and stayed silent on
          //     genuine breaks; the break itself, not the delta, is the trigger.
          //   region-tail: anchored to the reading terminus — col2's foot, the
          //     last thing the reader sees — and owned by the LAST region of the
          //     page, since each region overwrites the anchor. Dropped when the
          //     block ends here, because nothing runs on.
          if (balanceOn && c1.length > 0 && c2.length > 0) {
            if (!activePage._flowCues) activePage._flowCues = [];
            activePage._flowCues.push({ y: col0Y, x0: col0X + colW, x1: col1X });
            activePage._regionTail = cursor < items.length
              ? { y: col1Y, cx: col1X + (colW / 2), x0: col1X, scope: 'col:1' }
              : null;
          } else {
            activePage._regionTail = null;
          }

          // Column separation vertical rule if template requires. Skipped
          // across pure-heading regions: the rule separates text columns,
          // and a heading zone is one visual block rather than two columns.
          const regionIsHeadings = (c1.length + c2.length) > 0
            && c1.every((it) => it && it.kind === 'heading')
            && c2.every((it) => it && it.kind === 'heading');
          if (tmpl.columnseprule && (c2.length > 0) && !regionIsHeadings) {
            const dividerX = leftM + colW + (colSep / 2);
            // The divider spans the columns' fill extent, but never past the
            // region foot: colY is a cursor that can sit a fraction past
            // contentBottomY (trailing descender/rounding), and a rule drawn
            // to it reads as a bottom-margin violation even when the text
            // itself bottoms exactly at the foot. Clamp to the foot and keep
            // half the stroke inside, so the drawn edge never crosses it.
            const halfStroke = (tmpl.columnseprule || 0) / 2;
            const maxColY = Math.min(
              Math.max(col0Y, col1Y),
              contentBottomY - halfStroke,
            );
            const dividerEl = this.buildDividerRule({
              x1: dividerX,
              y1: resumeTop,
              x2: dividerX,
              y2: maxColY,
              width: tmpl.columnseprule,
              color: tmpl.colors.columnseprule || resolveColor(tmpl, 'columnSepRule'),
            });
            dividerEl.seamSeq = lastSeamSeq(activePage);
            dividerEl.scope = 'span';
            activePage.elements.push(dividerEl);
          }
          resumeTop = Math.max(col0Y, col1Y);
          // Record this region's right-column occupancy for the next
          // iteration's stacked-sliver kinship guard (see above). c2 is the
          // bite's suffix partition, so a non-empty c2 always holds the
          // bite tail — the next region head's predecessor.
          prevRegionC2Len = c2.length;
          break replan;
          }
        }
        chunkIdx++;
        firstPageOfBlock = false;
      }
      if (blockFlowKey) {
        pendingBlockFlows.push({
          key: blockFlowKey,
          startPageIdx: blockStartPageIdx,
          endPageIdx: pages.length,
          startPage: blockStartPages[bIdx],
          headings: (blockHeadings[bIdx] || []).map((h) => ({ ...h })),
          hasMasthead: mastheadPages.has(blockStartPageIdx),
          hasMastheadHeader: mastheadHeaderPages.has(blockStartPageIdx),
          seamSeqEnd: seamSeqCounter,
          dTableSlices: tableSlices - preTableSlices,
          dPanoramicTransitions: panoramicTransitions - prePanoramicTransitions,
          dOverfullColumns: overfullColumns - preOverfullColumns,
          dKeepWithNextBreaks: keepWithNextBreaks - preKeepWithNextBreaks,
          dOrphanSuppressions: orphanSuppressions - preOrphanSuppressions,
          dWidowSuppressions: widowSuppressions - preWidowSuppressions,
        });
      }
    }

    // Block-final page set (VGA F-9, spec §3.4). Each block starts a fresh
    // page, so the page immediately before the next block's first page is
    // that block's last page; its void below the final item is structural,
    // not accidental. The document's own last page is likewise final.
    // Only the LAST page of each block qualifies — a block spanning many
    // pages leaves its interior pages flushable. Built from
    // `blockStartPages` AFTER placement, so it reflects the pages the blocks
    // actually occupy.
    const blockFinalPages = new Set();
    for (let i = 0; i < blockStartPages.length; i++) {
      const nextStart = (i + 1 < blockStartPages.length) ? blockStartPages[i + 1] : (pages.length + 1);
      const last = nextStart - 1;
      if (last >= 1 && last <= pages.length) blockFinalPages.add(last);
    }

    // 3b. Page flush post-pass (VGA M3): the residual slack a page is left
    // with after the fill is resolved by the VerticalGlueAllocator into
    // per-seam offsets and applied by ownership (seamSeq/scope), not by Y
    // proximity — a col:0 seam never displaces col:1 content (spec F-4), and
    // the ratio bound replaces the absolute per-page cap (spec F-3).
    // Tier 1 pad reservation is gone: pad1/pad2 are identically zero, so
    // `resumeTop` carries no reserved slack and pages can only tighten (D-1).
    let justifyApplied = 0;
    let justifyMaxRatio = 0;
    let justifyMaxSeamShift = 0;
    let justifyMaxTotal = 0;
    const justifyPages = [];
    const justifySkipped = [];
    const justifyNotes = [];
    const justifyLifted = [];
    // F-6 evidence: how many headingBond seams the pass resolved, and any
    // that moved despite capacity 0 (must stay empty for G14 to pass).
    const justifyBondShifts = [];
    let justifyBondCount = 0;
    for (let pIdx = 0; pIdx < pages.length; pIdx++) {
      const page = pages[pIdx];
      if (Object.isFrozen(page) && page._justifyMeta) {
        const jm = page._justifyMeta;
        justifyApplied += jm.applied;
        if (jm.appliedPage !== null) justifyPages.push(jm.appliedPage);
        justifyMaxRatio = Math.max(justifyMaxRatio, jm.pageRatio);
        justifyMaxSeamShift = Math.max(justifyMaxSeamShift, jm.pageMaxShift);
        justifyMaxTotal = Math.max(justifyMaxTotal, jm.pageSlack);
        for (let i = 0; i < jm.skipped.length; i++) justifySkipped.push(jm.skipped[i]);
        for (let i = 0; i < jm.notes.length; i++) justifyNotes.push(jm.notes[i]);
        for (let i = 0; i < jm.lifted.length; i++) justifyLifted.push(jm.lifted[i]);
        justifyBondCount += jm.bondCount;
        for (let i = 0; i < jm.bondShifts.length; i++) justifyBondShifts.push(jm.bondShifts[i]);
        continue;
      }
      const preJustifyApplied = justifyApplied;
      const preSkippedLen = justifySkipped.length;
      const preNotesLen = justifyNotes.length;
      const preLiftedLen = justifyLifted.length;
      const preBondCount = justifyBondCount;
      const preBondShiftsLen = justifyBondShifts.length;
      let recordedPageRatio = 0;
      let recordedPageMaxShift = 0;
      let recordedPageSlack = 0;
      try {
      if (!flushBottom) {
        // User opted out of flush: the page foot stays exactly where the fill
        // put it. Still counted as skipped-with-reason so applied + skipped
        // keeps covering every page (G11).
        justifySkipped.push({ page: pIdx + 1, reason: 'flush-off' });
        continue;
      }
      if (chaptersToc && pIdx < tocReservedPages) { justifySkipped.push({ page: pIdx + 1, reason: 'toc' }); continue; }
      if ((page.elements || []).some((e) => e && e.type === 'rotated')) { justifySkipped.push({ page: pIdx + 1, reason: 'rotated' }); continue; }
      // Block-final / document-final (VGA F-9, spec §3.4): a page that ends
      // a block has a SEMANTIC void — the next block starts a fresh page, so
      // the space below the last item is a structural end, not an accidental
      // one. The flush target is null: capacity 0 → permanently ragged,
      // reason 'block-end'. This is what the old 36pt cap was hiding by
      // accident (probe: sampletext2/bauhaus+bal p4 slack 430pt). Checked
      // BEFORE any seam resolution so a huge semantic void never even
      // reaches the ratio ladder as 'over-cap'.
      if (blockFinalPages.has(pIdx + 1)) { justifySkipped.push({ page: pIdx + 1, reason: 'block-end' }); continue; }
      const seams = Array.isArray(page._stretchSeams) ? page._stretchSeams : [];
      if (seams.length === 0) { justifySkipped.push({ page: pIdx + 1, reason: 'no-gaps' }); continue; }
      // Page foot (VGA §3.5): the deepest content edge above the region
      // foot, its scope, and per-scope feet. Vertical rules are excluded —
      // dividers stretch to the flushed foot rather than defining it.
      let bottomMost = -Infinity;
      let footScope = 'span';
      const scopeFoot = new Map();
      for (const el of (page.elements || [])) {
        const ext = elementExtent(el);
        if (!ext || ext.top >= contentBottomY + 0.5) continue;
        if (el.type === 'rule' && (el.y1 || 0) !== (el.y2 || 0)) continue;
        const sc = (el && typeof el.scope === 'string') ? el.scope : 'span';
        if (ext.bottom > bottomMost) { bottomMost = ext.bottom; footScope = sc; }
        if (sc !== 'span') scopeFoot.set(sc, Math.max(scopeFoot.get(sc) ?? -Infinity, ext.bottom));
      }
      if (!Number.isFinite(bottomMost)) { justifySkipped.push({ page: pIdx + 1, reason: 'empty' }); continue; }
      const pageSlack = contentBottomY - bottomMost;
      const maxScopeSlack = scopeFoot.size > 0
        ? Math.max(pageSlack, ...Array.from(scopeFoot.values()).map((f) => contentBottomY - f))
        : pageSlack;
      if (!((isV3 ? maxScopeSlack : pageSlack) > 0.5)) { justifySkipped.push({ page: pIdx + 1, reason: pageSlack <= 0 ? 'full' : 'negligible' }); continue; }
      // Verdict ladder (VGA §3.5 + spec §7 honest-ragged):
      // 1. APPLIED — the funding scope's seams (+ shared span) deliver the
      //    full pageSlack at ratio ≤ 1: the foot lands on the region foot.
      //    Funding scope = foot scope, or (span foot over columns) the
      //    BINDING column (deeper column foot, whose accumulation the span
      //    foot rides via maxColAcc). Pooled acceptance cannot promise a
      //    flush — a foot only rides its own scope's share (proven: 12.79pt
      //    slack pooled, foot rose 6.57, void stayed 6.21).
      // 2. LIFTED — funding over-cap but the POOLED page ratio accepts: all
      //    seams stretch uniformly at the pooled ratio (TeX uniform glue,
      //    every offset ≤ its nominal). Feet improve but the foot does not
      //    land; recorded as skipped:partial-lift + lifted[] + notes.
      // 3. RAGGED — pooled over-cap: zero movement, skipped:over-cap.
      // G15's guarantee comes from the *application* below being
      // scope-tagged (computeElementShifts moves each element only with
      // seams in its own scope + span), so one column's stretch never
      // displaces its neighbour under any verdict.
      const skipOf = (res, gaps) => (res.reason === 'over-ratio'
        ? {
          page: pIdx + 1, reason: 'over-cap',
          slackPt: Math.round(pageSlack * 100) / 100, gaps,
          ratio: Number.isFinite(res.ratio) ? Math.round(res.ratio * 1000) / 1000 : res.ratio,
        }
        : { page: pIdx + 1, reason: res.reason, slackPt: Math.round(pageSlack * 100) / 100, gaps });
      const offsetsBySeq = new Map();
      let pageRatio = 0;
      const colScopes = [...new Set(seams.filter((s) => s && s.scope !== 'span').map((s) => s.scope))];
      let verdict = 'applied';
      // Per-column independent funding (R1, spec §2.1/§4).
      //
      // The seam substrate exists so each column can reach the region foot
      // from its own seams (FEATHERING-PADDING-SPEC §3.2/§3.5: "each flushes
      // to the region foot"). The previous ladder instead picked ONE funding
      // scope — the binding column — resolved it against the full page slack,
      // and handed every other column that same ratio. A column whose own
      // void exceeded its own capacity at the neighbour's ratio was recorded
      // `partial-lift` and left where it was.
      //
      // The measured cost, sample2/bauhaus p2: col:0 sat at the foot (void 0,
      // so the broadcast ratio was 0) while col:1 was 31.9pt above it with
      // 30.0pt of its own capacity. col:1 inherited ratio 0, moved nothing,
      // and the page stayed visibly uneven on every one of its 6 pages.
      //
      // Each column now funds its OWN void from its OWN seams at its OWN
      // ratio. A column that cannot fund the whole void does not refuse — it
      // lifts, spending as much of its capacity budget as the perceptibility
      // ceiling allows, and the residue is reported honest via `partial-lift`
      // + a per-scope note.
      //
      // The ceiling, not raw capacity, is the real bound: every seam gets
      // `min(capacity, bodyPitchPt * 0.30)`. On all three templates that
      // ceiling measures strictly BELOW capacity (base 3.73 vs 4.35, bauhaus
      // 3.56 vs 4.15, bauhaus_minimalist 3.20 vs 3.74pt), so a lift spends
      // ~0.774 of nominal capacity, not all of it. The `ratio: 1` below
      // therefore records "a lift was applied", NOT the movement ratio of the
      // seams; the real per-seam movement is in `lift`. An earlier comment
      // here claimed the lift spent "exactly its capacity budget" and was wrong.
      //
      // G15 is untouched: application
      // below is scope-tagged, so one column's movement never displaces its
      // neighbour. G13 is untouched: no seam ever exceeds its own capacity.
      const fundColumn = (cs) => {
        const ownSeams = seams.filter((s) => s && s.scope === cs);
        const foot = scopeFoot.get(cs);
        const colTargetY = (isV3 && footScope === 'span' && scopeFoot.size > 0)
          ? Math.min(contentBottomY, Math.max(...scopeFoot.values()) + pageSlack)
          : contentBottomY;
        const slack = Number.isFinite(foot) ? colTargetY - foot : 0;
        if (!(slack > 0.5)) {
          for (const s of ownSeams) offsetsBySeq.set(s.seq, 0);
          return { ratio: 0, over: false, slack: Math.max(0, slack) };
        }
        const res = resolveSeams(ownSeams, slack, isV3 ? 1.45 : undefined);
        if (res.verdict === 'applied') {
          for (const s of res.perSeam) offsetsBySeq.set(s.seq, s.offset);
          return { ratio: res.ratio || 0, over: false, slack };
        }
        // Bounded lift: spend as much of the budget as fits, distributed as a
        // ramp inside the perceptibility ceiling — never a uniform step to
        // every seam's raw capacity, which is what made this read as abrupt.
        //
        // The pitch is re-derived here rather than read from a captured
        // `rhythm`: that binding lives in a different function's scope, so
        // referencing it here threw `rhythm is not defined` at pipeline time.
        //
        // `slack` is passed as the total budget: a lift that spends the
        // ceiling on every seam can sum far past the column's actual void
        // (the 3-line list item at the foot of doc 87 rode 38.5pt of lift into
        // a 9.7pt void), and the application pass then clamped its lines onto
        // one baseline. No distribution may move content further than the
        // void it is closing.
        const liftPitch = (rhythmForTemplate(tmpl) || {}).bodyPitchPt || 0;
        const ceilingPt = liftPitch * STRETCH_CEILING_PITCH_RATIO;
        const lift = boundedLift(ownSeams, ceilingPt, slack);
        ownSeams.forEach((s, i) => offsetsBySeq.set(s.seq, lift[i] || 0));
        return { ratio: 1, over: true, slack };
      };
      if (footScope === 'span' && colScopes.length === 0) {
        // 1-col span page: everything rides all seams — pooled is exact.
        const res = resolveSeams(seams, pageSlack);
        if (res.verdict !== 'applied') { justifySkipped.push(skipOf(res, seams.length)); continue; }
        for (const s of res.perSeam) offsetsBySeq.set(s.seq, s.offset);
        pageRatio = res.ratio || 0;
      } else if (footScope === 'span') {
        // A span foot rides maxColAcc + spanAcc, so pooled funding can never
        // flush it (proven: 12.79pt pooled, foot rose 6.57, void stayed 6.21).
        // Columns still fund their own voids independently; the span rides the
        // deeper of them plus its own seams, which is what the scope-tagged
        // application already guarantees.
        let anyOver = false;
        let maxR = 0;
        for (const cs of colScopes) {
          const r = fundColumn(cs);
          anyOver = anyOver || r.over;
          maxR = Math.max(maxR, r.ratio);
        }
        const spanSeams = seams.filter((s) => s && s.scope === 'span');
        if (spanSeams.length && !(isV3 && !anyOver && colScopes.length > 0)) {
          const spanFootSlack = pageSlack;
          const resSpan = resolveSeams(spanSeams, spanFootSlack);
          if (resSpan.verdict === 'applied') {
            for (const s of resSpan.perSeam) offsetsBySeq.set(s.seq, s.offset);
            maxR = Math.max(maxR, resSpan.ratio || 0);
          } else {
            for (const s of spanSeams) offsetsBySeq.set(s.seq, s.capacity || 0);
            anyOver = true;
            maxR = Math.max(maxR, 1);
          }
        }
        for (const s of seams) if (!offsetsBySeq.has(s.seq)) offsetsBySeq.set(s.seq, 0);
        pageRatio = maxR;
        if (anyOver) verdict = 'lifted';
      } else {
        // Column foot is the page foot: every column funds its own void.
        let anyOver = false;
        let maxR = 0;
        const colResults = new Map();
        for (const cs of colScopes) {
          const r = fundColumn(cs);
          colResults.set(cs, r);
          anyOver = anyOver || r.over;
          maxR = Math.max(maxR, r.ratio);
        }
        if (isV3 && anyOver && colScopes.length > 1) {
          // V3 coupled pre-span lift: if one column of a 2-column band cannot
          // reach the floor (over-cap before a deferred span), do not let its
          // sibling column tear away to the floor alone; apply boundedLift to
          // both columns so their feet stay balanced within <= 1 line pitch.
          const liftPitch = (rhythmForTemplate(tmpl) || {}).bodyPitchPt || 0;
          const ceilingPt = liftPitch * STRETCH_CEILING_PITCH_RATIO;
          for (const cs of colScopes) {
            const r = colResults.get(cs);
            if (r && !r.over) {
              const ownSeams = seams.filter((s) => s && s.scope === cs);
              const lift = boundedLift(ownSeams, ceilingPt, r.slack);
              ownSeams.forEach((s, i) => offsetsBySeq.set(s.seq, lift[i] || 0));
            }
          }
        }
        for (const s of seams) if (!offsetsBySeq.has(s.seq)) offsetsBySeq.set(s.seq, 0);
        pageRatio = maxR;
        if (anyOver) verdict = 'lifted';
      }
      // F-6 audit: a headingBond seam has capacity 0, so its resolved offset
      // must be exactly 0 — that is the whole guarantee that a heading never
      // drifts off its body (spec §4.4). Recorded as a diagnostic so the
      // gate can read the allocator's own arithmetic instead of
      // re-deriving heading geometry from font sizes (which cannot tell a
      // heading from a same-size list line on a table page).
      const bondSeams = seams.filter((s) => s && s.klass === SEAM_CLASS.HEADING_BOND);
      justifyBondCount += bondSeams.length;
      for (const bs of bondSeams) {
        const off = offsetsBySeq.get(bs.seq) || 0;
        if (off > 0) {
          justifyBondShifts.push({ page: pIdx + 1, seq: bs.seq, scope: bs.scope, offsetPt: Math.round(off * 1000) / 1000 });
        }
      }
      // Cue anchors follow their column foot: same scope-aware accumulation
      // the pass applies to the content below the same seams. Column-cross
      // cues live in the gutter (span scope: max foot + span seams); the
      // region tail claims its own column's foot.
      for (const anchor of (page._flowCues || [])) {
        anchor.y += accumulateMaxAtY(seams, offsetsBySeq, anchor.y);
      }
      if (page._regionTail) {
        const tailScope = page._regionTail.scope || 'col:1';
        page._regionTail.y += accumulateAtY(seams, offsetsBySeq, page._regionTail.y, tailScope);
      }
      // Scope-tagged application: each element moves only with seams in its
      // own scope at or above its own seam (computeElementShifts). Vertical
      // column separators stretch top < bottom to the flushed foot, never
      // past it; horizontal rules translate as a unit. No element may cross
      // the region foot: neighbour content riding shared span offsets above
      // a nearly-full column is capped to the foot (overshoot guard), and the
      // cap is shared by the atom's ownership group so its lines never
      // collapse onto one baseline.
      const shifts = capShiftsToFoot(
        page.elements,
        computeElementShifts(page.elements, seams, offsetsBySeq),
        contentBottomY,
        elementExtent,
      );
      const els = page.elements || [];
      for (let ei = 0; ei < els.length; ei++) {
        const el = els[ei];
        if (!el || typeof el !== 'object') continue;
        const t = el.type;
        if (t === 'destination' || t === 'tag_struct_start' || t === 'tag_struct_end' || t === 'rotated') continue;
        if (t === 'rule') {
          if (Math.abs((el.y1 || 0) - (el.y2 || 0)) < 1e-9) {
            const s = shifts.get(ei) || 0;
            el.y1 = (el.y1 || 0) + s;
            el.y2 = (el.y2 || 0) + s;
          } else {
            // Vertical divider (dividerEl carries scope 'span'): stretch by
            // the max-scope accumulation split at top/bottom. The cap is
            // measured on the STROKE's outer edge: bottomMarginViolations
            // checks the outer edge, so a divider stopped exactly at
            // contentBottomY reads 0.09pt over (half of the 0.25pt rule).
            // Subtracting half the stroke width makes the flush exact.
            const topY = Math.min(el.y1 || 0, el.y2 || 0);
            const bottomY = Math.max(el.y1 || 0, el.y2 || 0);
            const halfStroke = (el.width || 0) / 2;
            const s1 = accumulateMaxAtY(seams, offsetsBySeq, topY);
            const s2 = Math.min(
              accumulateMaxAtY(seams, offsetsBySeq, bottomY),
              Math.max(0, contentBottomY - halfStroke - bottomY),
            );
            if (el.y1 <= el.y2) { el.y1 += s1; el.y2 += s2; }
            else { el.y1 += s2; el.y2 += s1; }
          }
        } else if (typeof el.y === 'number') {
          el.y += shifts.get(ei) || 0;
        }
      }
      // Post-application truth: measure the feet the page ACTUALLY landed,
      // after the scope-tagged shifts above. The pre-move `scopeFoot` is a
      // seam-top estimate and is the wrong instrument — on sample2/bauhaus p2
      // it read col:1 at 732.4pt while the real lowest ink sat at 792.9pt, so
      // a delivery ledger built on it reported a page as fully funded when it
      // was still 12.9pt short. The M1 gate asserts on real geometry, so the
      // ledger has to report real geometry.
      const landedFoot = (cs) => {
        let foot = -Infinity;
        for (const el of els) {
          if (!el || el.type === 'rule' || typeof el.y !== 'number') continue;
          const ext = elementExtent(el);
          if (!ext) continue;
          // Only content tagged to this column counts, and only ink that
          // stayed inside the region.
          const owner = el.scope || (el.seamSeq !== undefined
            && seams.find((s) => s && s.seq === el.seamSeq)?.scope);
          if (owner && owner !== cs) continue;
          if (ext.bottom > contentBottomY + 0.5) continue;
          if (ext.bottom > foot) foot = ext.bottom;
        }
        return foot;
      };
      let pageMaxShift = 0;
      for (const v of offsetsBySeq.values()) pageMaxShift = Math.max(pageMaxShift, v || 0);
      // Lifted pages contribute to the movement maxima (real offsets, real
      // ratio) but not to the applied/foot ledgers: the foot did not land.
      recordedPageRatio = pageRatio || 0;
      recordedPageMaxShift = pageMaxShift;
      recordedPageSlack = pageSlack;
      justifyMaxRatio = Math.max(justifyMaxRatio, recordedPageRatio);
      justifyMaxSeamShift = Math.max(justifyMaxSeamShift, recordedPageMaxShift);
      justifyMaxTotal = Math.max(justifyMaxTotal, recordedPageSlack);
      // The ragged ledger is built here, from landed feet, for every page —
      // not only for pages the resolver called `lifted`. A column can be
      // reported `applied` (ratio < 1, no overrun) and still land short of
      // the foot; those pages used to carry no note at all.
      const landedRagged = [];
      for (const cs of colScopes) {
        const foot = landedFoot(cs);
        if (!Number.isFinite(foot)) continue;
        const voidPt = contentBottomY - foot;
        if (voidPt <= 1.0) continue;
        const pre = scopeFoot.get(cs);
        const beforePt = Number.isFinite(pre) ? contentBottomY - pre : null;
        const deliveredPt = beforePt === null ? null : beforePt - voidPt;
        landedRagged.push({
          page: pIdx + 1, scope: cs,
          reason: `${deliveredPt === null ? 'unknown' : (deliveredPt > 0.05 ? 'capacity' : 'unlifted')}-ragged`,
          voidPt: Math.round(voidPt * 100) / 100,
          deliveredPt: deliveredPt === null ? null : Math.round(deliveredPt * 100) / 100,
          residuePt: Math.round(voidPt * 100) / 100,
          gaps: seams.length,
        });
      }
      if (verdict === 'lifted') {
        justifyLifted.push(pIdx + 1);
        // One ledger, one entry. The page is skipped (its foot did not land),
        // so it must NOT also appear in `notes` — G16 requires every page to
        // be accounted exactly once, and a page listed in both ledgers is
        // double-counted. `lifted[]` already carries the informational
        // signal, and `notes` stays reserved for pages that ARE applied but
        // carry a caveat (ragged neighbour).
        justifySkipped.push({
          page: pIdx + 1, reason: 'partial-lift',
          slackPt: Math.round(pageSlack * 100) / 100, gaps: seams.length,
          ratio: Math.round((pageRatio || 0) * 1000) / 1000,
        });
          continue;
      }
      justifyApplied++;
      justifyPages.push(pIdx + 1);
      for (const n of landedRagged) justifyNotes.push(n);
      } finally {
        if (!Object.isFrozen(page)) {
          Object.defineProperty(page, '_justifyMeta', {
            value: {
              applied: justifyApplied - preJustifyApplied,
              appliedPage: justifyApplied > preJustifyApplied ? (pIdx + 1) : null,
              pageRatio: recordedPageRatio,
              pageMaxShift: recordedPageMaxShift,
              pageSlack: recordedPageSlack,
              skipped: justifySkipped.slice(preSkippedLen),
              notes: justifyNotes.slice(preNotesLen),
              lifted: justifyLifted.slice(preLiftedLen),
              bondCount: justifyBondCount - preBondCount,
              bondShifts: justifyBondShifts.slice(preBondShiftsLen),
            },
            enumerable: false,
            configurable: true,
          });
        }
      }
    }
    // Seams are placement-time scaffolding: dropped from the frozen IR so
    // the display list carries no per-page slack bookkeeping. Opt back in
    // with V2_KEEP_SEAMS=1 for probes and the M1 seam-record gate.
    for (const page of pages) { if (!process.env.V2_KEEP_SEAMS && !Object.isFrozen(page)) delete page._stretchSeams; }

    // 3c. Column-flow cue stamping: vector marks built from the final
    // (justified) geometry, before page chrome so chrome never reorders them.
    this._stampFlowCues(pages, tmpl, contentBottomY);

    // 4. Running Headers & Footers across all pages
    const totalPages = Math.max(1, pages.length);
    for (let pIdx = 0; pIdx < totalPages; pIdx++) {
      const page = getOrCreatePage(pIdx);
      if (Object.isFrozen(page)) continue;
      const pageNum = pIdx + 1;

      // Unified running header & footer styling tokens (shared design standard)
      const chromeTok = tmpl.tokens?.chrome || {};
      const isBold = chromeTok.bold !== undefined ? chromeTok.bold : (tmpl.fontSize !== 9.5);
      const chromeFont = isBold ? 'helvetica-bold' : 'helvetica';
      const chromeFontSize = chromeTok.fontSize || V2_TYPE_SCALE.footnote;
      const chromeTextColor = resolveColor(tmpl, 'textMuted');
      const chromeRuleColor = tmpl.colors.headerline || tmpl.colors.columnseprule || resolveColor(tmpl, 'headerLine');
      const headRuleW = tmpl.headsepline || V2_STROKE_TOKENS.standard;
      const footRuleW = tmpl.footsepline || tmpl.headsepline || V2_STROKE_TOKENS.standard;

      // Running header rule & text (legacy default title when no custom header).
      // When chaptersToc is active, Page 0 running header is drawn by renderChaptersTOC
      // to avoid double-striking text/rules on Page 0.
      const isTocPage0 = (chaptersToc && pIdx < tocReservedPages);
      const headerY = topM;
      if (!isTocPage0) {
        const hasHeaderTitle = Boolean(runningTitle && !mastheadHeaderPages.has(pIdx));
        const headerDateText = formatV2HeaderDate(docIR.headerDate);
        const hasHeaderDate = Boolean(headerDateText && !mastheadPages.has(pIdx));

        if (hasHeaderTitle) {
          page.elements.push({
            type: 'text',
            text: runningTitle,
            x: leftM,
            y: headerY,
            font: chromeFont,
            size: chromeFontSize,
            color: chromeTextColor,
          });
        }

        if (hasHeaderDate) {
          page.elements.push({
            type: 'text',
            text: headerDateText,
            x: leftM,
            y: headerY,
            font: chromeFont,
            size: chromeFontSize,
            color: chromeTextColor,
            width: printableW,
            align: 'right',
          });
        }

        if (hasHeaderTitle || hasHeaderDate) {
          page.elements.push(this.buildDividerRule({
            x1: leftM,
            y1: headerY + tmpl.headheight,
            x2: A4_WIDTH - rightM,
            y2: headerY + tmpl.headheight,
            width: headRuleW,
            color: chromeRuleColor,
          }));
        }
      }

      // Footer rule & text (v1 parity: left footer shows the running
      // header ONLY when the header lives in the footer; right shows the
      // plain page number, never "n / total").
      const footerY = A4_HEIGHT - bottomM;
      page.elements.push(this.buildDividerRule({
        x1: leftM,
        y1: footerY,
        x2: A4_WIDTH - rightM,
        y2: footerY,
        width: footRuleW,
        color: chromeRuleColor,
      }));

      const footerLeftText = (!docIR.headerOnTop && runningTitle && !mastheadHeaderPages.has(pIdx))
        ? runningTitle
        : (docIR.showFooterText ? (docIR.footerText || runningTitle) : '');
      if (footerLeftText) {
        page.elements.push({
          type: 'text',
          text: footerLeftText,
          x: leftM,
          y: footerY + 6,
          font: chromeFont,
          size: chromeFontSize,
          color: chromeTextColor,
          width: printableW * 0.7,
          align: 'left',
        });
      }

      // Page counter right aligned (plain number, v1 parity: omitted on TOC page)
      if (!chaptersToc || pIdx > 0) {
        const displayPageNum = chaptersToc ? pIdx : pageNum;
        page.elements.push({
          type: 'text',
          text: `${displayPageNum}`,
          x: leftM + printableW * 0.6,
          y: footerY + 6,
          font: chromeFont,
          size: chromeFontSize,
          color: chromeTextColor,
          width: printableW * 0.4,
          align: 'right',
        });
      }
    }

    const explicitDocTitle = compileOpts.doc_title !== undefined ? compileOpts.doc_title
      : (compileOpts.docTitle !== undefined ? compileOpts.docTitle
      : (compileOpts.document_title !== undefined ? compileOpts.document_title : null));
    const firstSec = docIR.blocks && docIR.blocks[0];
    const firstSecMh = firstSec?.masthead || {};
    const isFirstMhOn = Boolean(
      firstSec && (
        firstSecMh.enabled === true ||
        firstSec?.enable_masthead === true ||
        firstSec?.masthead_enabled === true
      )
    );
    const isFirstMhOff = !isFirstMhOn;
    const adaptedFromMh = (isFirstMhOn && (firstSecMh.course || firstSec?.masthead_course || firstSecMh.topic || firstSec?.masthead_topic))
      ? (firstSecMh.course || firstSec?.masthead_course || firstSecMh.topic || firstSec?.masthead_topic).trim()
      : '';
    const adaptedSubFromMh = (isFirstMhOn && (firstSecMh.course || firstSec?.masthead_course) && (firstSecMh.topic || firstSec?.masthead_topic))
      ? (firstSecMh.topic || firstSec?.masthead_topic || '').trim()
      : '';

    // Collect all section names and titles
    const allSecTitles = new Set();
    if (Array.isArray(docIR.blocks)) {
      for (const b of docIR.blocks) {
        if (b?.name) allSecTitles.add(String(b.name).trim().toUpperCase());
        if (b?.title) allSecTitles.add(String(b.title).trim().toUpperCase());
      }
    }

    let resolvedDocTitle = '';
    if (explicitDocTitle !== null && explicitDocTitle !== '') {
      const raw = String(explicitDocTitle).trim();
      if (!allSecTitles.has(raw.toUpperCase()) && !/^(SEÇÃO|BLOCO|CAPÍTULO)\s*\d+$/i.test(raw)) {
        resolvedDocTitle = raw;
      }
    } else if (isFirstMhOn && adaptedFromMh) {
      resolvedDocTitle = adaptedFromMh;
    }
    const finalDocTitle = resolvedDocTitle === 'Document' ? '' : resolvedDocTitle;

    const explicitDocSubtitle = compileOpts.doc_subtitle !== undefined ? compileOpts.doc_subtitle
      : (compileOpts.docSubtitle !== undefined ? compileOpts.docSubtitle
      : (compileOpts.document_subtitle !== undefined ? compileOpts.document_subtitle : ''));
    const finalDocSubtitle = (explicitDocSubtitle !== null && explicitDocSubtitle !== '')
      ? String(explicitDocSubtitle).trim()
      : (isFirstMhOn && adaptedSubFromMh && adaptedSubFromMh !== finalDocTitle ? adaptedSubFromMh : '');

    const sectionsMetadata = docIR.blocks.map((b, idx) => {
      const isMhOn = Boolean(b.enable_masthead === true || b.masthead_enabled === true || b.masthead?.enabled === true);
      return {
        index: idx + 1,
        name: b.name || b.title || `Capítulo ${idx + 1}`,
        title: b.title || b.name || `Capítulo ${idx + 1}`,
        startPage: blockStartPages[idx] || (chaptersToc ? idx + 1 + tocReservedPages : idx + 1),
        bodyPage: chaptersToc ? Math.max(1, (blockStartPages[idx] || (idx + 1 + tocReservedPages)) - tocReservedPages) : (blockStartPages[idx] || (idx + 1)),
        dest: `section-${idx + 1}`,
        enable_masthead: isMhOn,
        masthead: isMhOn ? (b.masthead || { enabled: true }) : { enabled: false },
        masthead_header: isMhOn && (b.masthead?.header === true || b.masthead_header === true),
        masthead_course: isMhOn ? (b.masthead?.course || b.masthead_course || null) : null,
        masthead_topic: isMhOn ? (b.masthead?.topic || b.masthead_topic || null) : null,
        masthead_prefix: isMhOn ? (b.masthead?.prefix || b.masthead_prefix || null) : null,
        headings: (blockHeadings[idx] || []).map(h => ({
          text: h.text,
          level: h.level || 1,
          page: h.page,
          bodyPage: chaptersToc ? Math.max(1, h.page - tocReservedPages) : h.page,
          dest: h.dest,
        })),
      };
    });

    const docRhythm = rhythmForTemplate(tmpl);
    const bottomMarginAudit = auditBottomMargin(pages, contentBottomY);
    const diagnostics = {
      ...auditDisplayListBaselines(pages, tmpl.gridUnit || 12, topM),
      tableSlices,
      panoramicTransitions,
      overfullColumns,
      spanCoordinated: useSpanCoord === true,
      bottomMarginViolations: bottomMarginAudit.violations,
      bottomMarginWorst: bottomMarginAudit.worst,
      keepWithNextBreaks,
      orphanSuppressions,
      widowSuppressions,
      justify: {
        applied: justifyApplied,
        pages: justifyPages,
        maxRatio: Math.round(justifyMaxRatio * 1000) / 1000,
        maxSeamShiftPt: Math.round(justifyMaxSeamShift * 100) / 100,
        maxTotalPt: Math.round(justifyMaxTotal * 100) / 100,
        skipped: justifySkipped,
        notes: justifyNotes,
        lifted: justifyLifted,
        // F-6 evidence for G14: `bondCount` headingBond seams were resolved,
        // `bondShifts` is the (must-be-empty) list of any that moved despite
        // capacity 0. A heading's distance to its body can only change if one
        // of these is non-zero.
        bondCount: justifyBondCount,
        bondShifts: justifyBondShifts,
      },
      rhythm: {
        gridUnit: docRhythm.gridUnit,
        fontRatio: docRhythm.fontRatio,
        bodyPitchPt: Math.round(docRhythm.bodyPitchPt * 100) / 100,
        parskipPt: docRhythm.parskipPt,
      },
      // A1: fit audit is a full re-measure of every emitted text line.
      // Production driver paths (server/worker) never read diagnostics.fit
      // — only pipeline warn-gates and QA do — so the driver sets
      // skip_fit_audit and this resolves to the { skipped: true } shape
      // via the non-function-measure early return below.
      fit: auditEstimateRenderFit(pages, compileOpts.skip_fit_audit ? null : measureOpt),
    };
    const anchors = Object.fromEntries(anchorMap.entries());

    const dlObj = {
      totalPages,
      template: templateKey,
      pages,
      anchors,
      diagnostics,
      toc: chaptersToc ? {
        enabled: true,
        title: compileOpts.toc_title || compileOpts.tocTitle || (docIR.toc && docIR.toc.title) || '',
        includeHeadings: compileOpts.toc_include_headings !== false,
        sections: sectionsMetadata,
        docTitle: finalDocTitle,
        docSubtitle: finalDocSubtitle,
        runningHeader: runningTitle,
        headerOptions: {
          showHeaderTop: docIR.headerOnTop !== false,
          customHeader: docIR.headerText || null,
          headerDate: formatV2HeaderDate(docIR.headerDate),
        },
      } : null,
      pagination: {
        totalPages,
        hasToC: chaptersToc,
        chaptersToc,
        tocPage: chaptersToc ? 1 : null,
        tocPages: chaptersToc ? tocReservedPages : 0,
        geometry: isV3 ? 'v3' : 'v2',
        sections: sectionsMetadata,
      },
      metadata: {
        template: templateKey,
        docTitle: docIR.title,
        elementCount: pages.reduce((acc, p) => acc + p.elements.length, 0),
      },
    };
    if (compileOpts.geometry === 'v3' || docIR.geometry === 'v3') {
      decorateDisplayListV3(dlObj, tmpl, compileOpts);
    }
    const frozenDl = freezeIR(dlObj);
    for (let i = 0; i < pendingBlockFlows.length; i++) {
      const pf = pendingBlockFlows[i];
      blockFlowCacheSet(pf.key, {
        pages: pages.slice(pf.startPageIdx, pf.endPageIdx),
        startPage: pf.startPage,
        headings: pf.headings,
        hasMasthead: pf.hasMasthead,
        hasMastheadHeader: pf.hasMastheadHeader,
        seamSeqEnd: pf.seamSeqEnd,
        dTableSlices: pf.dTableSlices,
        dPanoramicTransitions: pf.dPanoramicTransitions,
        dOverfullColumns: pf.dOverfullColumns,
        dKeepWithNextBreaks: pf.dKeepWithNextBreaks,
        dOrphanSuppressions: pf.dOrphanSuppressions,
        dWidowSuppressions: pf.dWidowSuppressions,
      });
    }
    if (dlCacheKey) {
      dlCacheSet(dlCacheKey, frozenDl);
    }
    return frozenDl;
  }

  /**
   * Stamps the column-flow anchors recorded during placement. Two hairline
   * vector marks (0.6pt, muted) so they read as editorial marks, never glyphs:
   *   column-cross  right-pointing arrow drawn inside the gutter, at the left
   *     column's foot, tip entering the right column: "this column breaks here
   *     and resumes at the top of the next one." Living in the gutter channel —
   *     the no-man's-land that holds no text — it can never be mistaken for
   *     content, and its tip points at exactly where the eye goes next. It
   *     crosses the light column separator rule on purpose: the flow passes
   *     that rule on its way into the next column.
   *   region-tail   down chevron centred under the column where the reading
   *     ends: "what you just read is not finished — it runs on." Centred on its
   *     column rather than parked at the text edge, so it reads as a property
   *     of the column's flow and never as a bullet, a dash, or a mark claiming
   *     the margin.
   * A mark is dropped when its box is not clean — occupied by text, a table, an
   * image, a bullet or a checkbox, or short of the footer zone — because a cue
   * that lands on content is worse than no cue. Rules are excluded from the
   * occupancy test: hairlines crossing hairlines is the whole idiom here.
   * Both marks carry `cue: 'continuation'` (display-list contract) plus
   * `cueRole` for geometry assertions.
   */
  _stampFlowCues(pages, tmpl, contentBottomY) {
    const color = (tmpl.colors && tmpl.colors.textmuted) || resolveColor(tmpl, 'textMuted');
    const occupancyBox = (el) => {
      const t = el && el.type;
      if (t === 'text') {
        return { x0: el.x || 0, x1: (el.x || 0) + (el.width ?? el.w ?? 0), y0: el.y || 0, y1: (el.y || 0) + (el.size || 10) };
      }
      if (t === 'rect' || t === 'image') {
        return { x0: el.x || 0, x1: (el.x || 0) + (el.w ?? el.width ?? 0), y0: el.y || 0, y1: (el.y || 0) + (el.h || 0) };
      }
      if (t === 'bullet') {
        return { x0: (el.x || 0) - (el.r || 1.5), x1: (el.x || 0) + (el.r || 1.5), y0: (el.y || 0) - (el.r || 1.5), y1: (el.y || 0) + (el.r || 1.5) };
      }
      if (t === 'checkbox') return { x0: el.x || 0, x1: (el.x || 0) + 7.5, y0: el.y || 0, y1: (el.y || 0) + 7.5 };
      return null;
    };
    for (const page of pages) {
      if (Object.isFrozen(page)) continue;
      const hasAnchors = Array.isArray(page._flowCues) && page._flowCues.length > 0;
      if (!hasAnchors && !page._regionTail) {
        delete page._flowCues;
        delete page._regionTail;
        continue;
      }
      const occupied = (page.elements || []).map(occupancyBox).filter(Boolean);
      const clean = (x0, y0, x1, y1) => {
        if (y1 > contentBottomY + 0.01) return false;
        return !occupied.some((b) => (
          Math.min(x1, b.x1) - Math.max(x0, b.x0) > 0 && Math.min(y1, b.y1) - Math.max(y0, b.y0) > 0
        ));
      };
      // Lowest rendered content bottom within a horizontal band, at or above a
      // limit. Anchors sit on item-box bottoms, which carry trailing gap, so a
      // mark measured from them floats mid-void instead of sitting on the break.
      const lowestBottomAtOrAbove = (bandLeft, bandRight, limitY) => {
        let bottom = -1;
        for (const b of occupied) {
          if (b.x0 >= bandLeft - 0.5 && b.x1 <= bandRight + 0.5 && b.y1 <= limitY + 0.5 && b.y1 > bottom) bottom = b.y1;
        }
        return bottom;
      };
      const anchors = Array.isArray(page._flowCues) ? page._flowCues : [];
      for (const anchor of anchors) {
        const tipX = anchor.x1 - 1;
        const shaftX = anchor.x0 + 1.5;
        const shaftEnd = tipX - 4;
        if (shaftEnd <= shaftX + 1) continue;
        const leftBottom = lowestBottomAtOrAbove(-1e9, anchor.x0, anchor.y);
        const y = leftBottom > 0 ? Math.min(anchor.y + 4, leftBottom + 4.5) : anchor.y + 4;
        if (!clean(shaftX, y - 2.1, tipX, y + 2.1)) continue;
        const mark = (x1, y1, x2, y2) => page.elements.push({
          ...this.buildDividerRule({ x1, y1, x2, y2, width: 0.6, color }),
          cue: 'continuation',
          cueRole: 'column-cross',
        });
        mark(shaftX, y, shaftEnd, y);
        mark(shaftEnd, y - 2.1, tipX, y);
        mark(shaftEnd, y + 2.1, tipX, y);
      }
      const tail = page._regionTail;
      if (tail) {
        const rightBottom = lowestBottomAtOrAbove(tail.x0, 1e9, tail.y);
        const y = rightBottom > 0 ? Math.min(tail.y + 4, rightBottom + 4.5) : tail.y + 4;
        // The tail claims "what you read runs on", so it must be the page's
        // last word: a panoramic span or later region sitting lower on the
        // page makes that claim false, and the mark is dropped.
        const pageBottom = occupied.reduce(
          (a, b) => (b.y1 <= contentBottomY + 0.01 && b.y1 > a ? b.y1 : a), 0,
        );
        if (y >= pageBottom - 0.5
          && clean(tail.cx - 2.8, y, tail.cx + 2.8, y + 3.5)) {
          const mark = (x1, y1, x2, y2) => page.elements.push({
            ...this.buildDividerRule({ x1, y1, x2, y2, width: 0.6, color }),
            cue: 'continuation',
            cueRole: 'region-tail',
          });
          mark(tail.cx - 2.8, y, tail.cx, y + 3.5);
          mark(tail.cx + 2.8, y, tail.cx, y + 3.5);
        }
      }
      delete page._flowCues;
      delete page._regionTail;
    }
  }

  /**
   * Emits pre-wrapped lines as verbatim single-line elements. The blaster
   * draws them without re-wrapping, so rendered height == estimated height
   * by construction. v1 parity: justified blocks justify every line except
   * the last, which stays left-aligned.
   */
  emitLines(page, lines, x, y, w, opts = {}) {
    const {
      font = 'helvetica',
      size = 9.5,
      color = '#111827',
      align = 'left',
      lineHeight = 12,
      exactWidth = false,
    } = opts;
    const list = (lines && lines.length > 0) ? lines : [{ runs: [{ text: '', style: 'normal' }] }];
    list.forEach((ln, idx) => {
      const last = idx === list.length - 1;
      page.elements.push({
        type: 'text',
        text: (ln.runs || []).map(r => r.text).join(''),
        runs: ln.runs,
        x: q(x),
        y: q(y + idx * lineHeight),
        font,
        size,
        color,
        width: q(exactWidth ? w : Math.max(10, w)),
        align: (align === 'justify' && !last && list.length > 1) ? 'justify' : (align === 'justify' ? 'left' : align),
        prewrapped: true,
      });
    });
  }

  /**
   * Row-split a table item so the first slice fits maxH (header + leading
   * body rows). Continuation slices repeat the header with a '
   * (continuação)' suffix on its first cell (v1 repeatedHeader semantics).
   * Returns [slice, rest|null]. Progress guaranteed: header-only tables and
   * header+1-row are returned whole even when exceeding maxH; an orphan
   * single trailing row is never left alone (v1 orphan-tail guard).
   */
  _splitTable(item, maxH, measure = null, slopTol = 12) {
    const headerH = item.header ? item.header.height : item.heavyRule + 2;
    const sliceGap = item.continued ? 0 : (item.topGap || 0);
    const bottomGap = item.bottomGap || 0;
    const roomForRows = maxH - sliceGap - headerH - item.heavyRule - bottomGap;
    const taken = [];
    let takenH = 0;
    for (const row of item.rows) {
      if (taken.length === 0 || takenH + row.height <= roomForRows) {
        taken.push(row);
        takenH += row.height;
      } else break;
    }
    if (taken.length >= item.rows.length) return [item, null];
    // Adapted-port row guards (ADR-ADAPT-02). Coarse items are atomic so
    // paragraph lines cannot strand; rows are the splittable unit.
    const splitGuards = { orphan: false, widow: false };
    // Widow-leader guard: never strand a single leading row. When exactly
    // one body row fits but several remain, absorb grid slop to take a
    // friend; otherwise accept (progress guarantee wins).
    if (taken.length === 1 && item.rows.length >= 3
        && takenH + item.rows[1].height <= roomForRows + slopTol) {
      taken.push(item.rows[1]);
      takenH += item.rows[1].height;
      splitGuards.widow = true;
    }
    // Orphan-tail guard: never strand a single trailing row.
    if (item.rows.length - taken.length === 1 && taken.length > 1) {
      const last = taken.pop();
      takenH -= last.height;
      splitGuards.orphan = true;
    }
    const restRows = item.rows.slice(taken.length);
    // Bottom gap only on the closing slice: continuing slices end at
    // their light rule with no trailing air.
    const sliceCloses = restRows.length === 0;
    const slice = { ...item, rows: taken, height: sliceGap + headerH + takenH + item.heavyRule + (sliceCloses ? bottomGap : 0), closesTable: sliceCloses, splitGuards };
    let contHeader = null;
    let contHeadH = item.heavyRule + 2;
    if (item.header) {
      const contTexts = item.header.texts.slice();
      if (!item.continued) contTexts[0] = (contTexts[0] || '') + ' (continuação)';
      const contCells = contTexts.map((t, ci) => {
        const avail = Math.max(10, item.colWidths[ci] - item.paddingH * 2);
        const lines = wrapRunsToLines(parseInlineRuns(t), 'helvetica-bold', item.headerSize, avail, measure, { breakNbsp: true });
        const prev = item.header.cells[ci];
        return { lines, align: prev ? prev.align : 'left', text: t };
      });
      const contLines = Math.max(1, ...contCells.map(c => c.lines.length));
      contHeadH = Math.max(12, contLines * item.headLineH + item.paddingV * 2 + 3);
      contHeader = { cells: contCells, height: contHeadH, texts: contTexts };
    }
    const restH = restRows.reduce((a, r) => a + r.height, 0);
    const rest = {
      ...item,
      header: contHeader,
      rows: restRows,
      height: contHeadH + restH + item.heavyRule + bottomGap,
      continued: true,
      topGap: 0,
    };
    return [slice, rest];
  }

  /**
   * Line-split a multi-line text item (paragraph, list-item, blockquote) so
   * the first slice fits maxH. The first slice keeps the marker/seps; the
   * continuation carries the leftover height plus all trailing gaps, so the
   * estimate==render invariant holds and totals are preserved exactly.
   * Returns [slice, rest|null]. Progress guaranteed: single-line or
   * sub-line-height budgets return whole (caller moves them to a fresh page).
   */
  _splitParagraph(item, maxH, opts = null) {
    // Atomic list item ("Dividir itens longos" off): move the whole item to
    // the next column/page. The caller's progress guard handles an item that
    // is taller than a full column.
    if (item && item.kind === 'list-item' && item.splitAllowed === false) return [item, null];
    const splittable = item
      && (item.kind === 'paragraph' || item.kind === 'list-item' || item.kind === 'blockquote');
    if (!splittable || !Array.isArray(item.lines) || item.lines.length <= 1) return [item, null];
    const lh = item.lineHeight || (item.fontSize ? item.fontSize * 1.15 : 12);
    const total = item.lines.length;
    let n = Math.floor((maxH - 1) / lh);
    if (n < 1 || n >= total) return [item, null];
    // Widow guard: never strand a single trailing line. Tail callers may
    // skip it — a tail rest has nothing after it to strand from (the
    // section ends there; the next block opens a fresh page).
    if (!(opts && opts.skipWidow) && total - n === 1 && n > 1) n -= 1;
    const slice = { ...item, lines: item.lines.slice(0, n), height: n * lh };
    const rest = {
      ...item,
      lines: item.lines.slice(n),
      height: (item.height || total * lh) - slice.height,
      continued: true,
      topMargin: 0,
    };
    return [slice, rest];
  }

  /**
   * M1 seam-substrate placement wrapper: brackets `_compileItem` by
   * `elements.length` and stamps every newly emitted element with the
   * owning seam `{ seamSeq, scope }`. Zero geometry effect — positions,
   * breaks and splits are untouched.
   */
  _placeWithSeam(page, item, x, y, width, tmpl, onHeading, seq, scope) {
    const before = page.elements.length;
    this._compileItem(page, item, x, y, width, tmpl, onHeading);
    const s = (typeof seq === 'number') ? seq : lastSeamSeqFallback(page);
    function lastSeamSeqFallback(pg) {
      return (pg._stretchSeams && pg._stretchSeams.length)
        ? pg._stretchSeams[pg._stretchSeams.length - 1].seq : -1;
    }
    for (let i = before; i < page.elements.length; i++) {
      const el = page.elements[i];
      if (el && typeof el === 'object') { el.seamSeq = s; el.scope = scope; }
    }
  }

  _compileItem(page, item, x, y, width, tmpl, onHeading = null) {
    if (item.kind === 'rule') {
      page.elements.push(this.buildDividerRule({
        x1: x,
        y1: y + 4,
        x2: x + width,
        y2: y + 4,
        width: V2_STROKE_TOKENS.standard,
        color: resolveColor(tmpl, 'ruleGray'),
      }));
      return;
    }
    if (item.kind === 'heading') {
      if (typeof onHeading === 'function') {
        onHeading(item, page.pageNumber);
      }
      const topPad = item.topMargin || 0;
      const textY = y + topPad;
      const headFont = tmpl.tokens?.headFontName || 'arimo-bold';
      const metrics = getFontMetrics(headFont, item.fontSize);
      const opticalCapY = textY + metrics.capCenterOffset;
      const ascPt = (metrics.ascender / metrics.unitsPerEm) * item.fontSize;
      const capPt = (metrics.capHeight / metrics.unitsPerEm) * item.fontSize;
      const barTop = textY + Math.max(0, ascPt - capPt);
      const barH = capPt;

      const decor = item.decor || (tmpl.headingDecorators && tmpl.headingDecorators[item.level]) || {};
      const decorStyle = decor.style;

      // Optical decorator dot/bar/rule: only render for decorated levels (H1/H2).
      // H3+ with 'plain' or 'small_caps' or titleWOffset === 0 emit no decorator glyph,
      // eliminating glyph overlap on the heading text at root cause.
      if (decorStyle === 'vertical_pill') {
        page.elements.push({
          type: 'rect',
          x: x,
          y: barTop,
          w: V2_STROKE_TOKENS.pillWest,
          h: barH,
          radius: decor.pillRadius || 1.5,
          fill: decor.pillColor || resolveColor(tmpl, 'accent'),
        });
      } else if (decorStyle === 'vertical_bar') {
        page.elements.push({
          type: 'rect',
          x: x,
          y: barTop,
          w: V2_STROKE_TOKENS.pillWest,
          h: barH,
          fill: decor.barColor || resolveColor(tmpl, 'accent'),
        });
      } else if (decorStyle === 'dot_prefix') {
        page.elements.push(this.buildOpticalMarker({
          x: x + 1.0,
          y: opticalCapY,
          r: 1.8,
          style: 'circle',
          color: decor.dotColor || resolveColor(tmpl, 'accent'),
        }));
      } else if (decorStyle === 'underline') {
        const ulY = item.isV3
          ? (textY + Math.max(0, item.lines.length - 1) * (item.lineHeight || item.fontSize) + ascPt + 3.5)
          : (y + item.height - 2);
        page.elements.push(this.buildDividerRule({
          x1: x,
          y1: ulY,
          x2: x + width,
          y2: ulY,
          width: decor.underlineW || V2_STROKE_TOKENS.standard,
          color: decor.underlineColor || resolveColor(tmpl, 'ruleGray'),
        }));
      }

      const textOffsetX = item.titleWOffset !== undefined
        ? item.titleWOffset
        : ((decorStyle && decorStyle !== 'plain' && decorStyle !== 'small_caps') ? 6 : 0);
      this.emitLines(page, item.lines, x + textOffsetX, textY, width - textOffsetX, {
        font: 'helvetica-bold',
        size: item.fontSize,
        color: item.color || resolveColor(tmpl, 'textMain'),
        align: 'left',
        lineHeight: item.lineHeight || item.fontSize * (tmpl.tokens?.lineHeightMultiplier ?? V2_TYPE_SCALE.lineHeightMultiplierBase) + 0.8,
      });
    } else if (item.kind === 'list-item') {
      const liSize = item.fontSize;
      const bodyFont = tmpl.tokens?.bodyFontName || 'arimo';
      const metrics = getFontMetrics(bodyFont, liSize);
      const bulletY = y + metrics.capCenterOffset;
      const geo = item.geo || { textOff: 14, markerXOff: 4, markerW: 9 };
      const bodyX = x + geo.textOff;
      const bodyW = Math.max(20, width - geo.textOff);
      const md = item.markerDesc || { kind: 'text', text: '–', color: resolveColor(tmpl, 'textMain') };
      const mx = x + geo.markerXOff;
      // Continuation slices of a line-split item carry no marker (same indent).
      if (!item.continued) {
      if (md.kind === 'task') {
        // Task checkbox, optically centered on cap height (v1 parity).
        page.elements.push({
          type: 'checkbox',
          x: mx,
          y: bulletY - 3.75,
          checked: !!md.checked,
          border: tmpl.colors.bordercolor || resolveColor(tmpl, 'borderMuted'),
          color: tmpl.colors.accent || resolveColor(tmpl, 'ruleBlack'),
        });
      } else if (md.kind === 'ordered') {
        // Right-aligned in markerW (v1 parity).
        this.emitLines(page, [{ runs: [{ text: md.text, style: md.bold ? 'bold' : 'normal' }] }], mx, y, geo.markerW, {
          font: md.bold ? 'helvetica-bold' : 'helvetica',
          size: liSize,
          color: md.color,
          align: 'right',
          lineHeight: liSize * 1.15,
          exactWidth: true,
        });
      } else if (md.kind === 'text') {
        this.emitLines(page, [{ runs: [{ text: md.text, style: 'normal' }] }], mx, y, geo.markerW, {
          font: 'helvetica',
          size: liSize,
          color: md.color,
          align: 'center',
          lineHeight: liSize * 1.15,
          exactWidth: true,
        });
      } else {
        // Vector marker, optically centered (v1 midX/midY parity).
        page.elements.push(this.buildOpticalMarker({
          x: mx + geo.markerW / 2 - 1.5,
          y: bulletY,
          level: item.level,
          style: md.style,
          r: md.r,
          color: md.color,
        }));
      }
      }

      // v1 loose-line-guard parity for lists: short/narrow/sparse items
      // are never justified (prevents stretched rivers).
      let liAlign = item.align || 'left';
      if (liAlign === 'justify' && item.looseGuard !== false) {
        const lineGapLi = tmpl.tokens?.listGapPt ?? (tmpl.lineStretch === 1.04 ? 1.0 : 1.2);
        const short = item.lines.length * (item.lineHeight || liSize) <= (liSize + lineGapLi) * 2.4
          || (item.naturalWidth || 0) < bodyW * 0.88
          || (item.wordCount || 0) < 18;
        if (short) liAlign = 'left';
      }
      this.emitLines(page, item.lines, bodyX, y, bodyW, {
        font: 'helvetica',
        size: liSize,
        color: resolveColor(tmpl, 'textMain'),
        align: liAlign,
        lineHeight: item.lineHeight || liSize * 1.15,
      });
    } else if (item.kind === 'blockquote') {
      // Callout card
      page.elements.push(this.buildAccentContainer({
        x,
        y,
        width,
        height: item.boxHeight !== undefined ? item.boxHeight : item.height,
        fill: resolveColor(tmpl, 'surface'),
        stroke: resolveColor(tmpl, 'ruleBlack'),
        westWidth: V2_STROKE_TOKENS.accentWest,
      }));

      this.emitLines(page, item.lines, x + 8, y + 4, Math.max(20, width - 12), {
        font: 'helvetica-oblique',
        size: item.fontSize,
        color: resolveColor(tmpl, 'textMain'),
        align: item.align || 'left',
        lineHeight: item.lineHeight || item.fontSize * 1.15,
      });
    } else if (item.kind === 'math') {
      // Math formula box
      page.elements.push(this.buildAccentContainer({
        x,
        y,
        width,
        height: item.boxHeight !== undefined ? item.boxHeight : item.height,
        fill: resolveColor(tmpl, 'surfaceMuted'),
        stroke: resolveColor(tmpl, 'borderMuted'),
        westWidth: V2_STROKE_TOKENS.accentWest,
      }));

      this.emitLines(page, item.lines, x + 12, y + 8, Math.max(20, width - 16), {
        font: 'courier',
        size: 9,
        color: resolveColor(tmpl, 'textMain'),
        align: 'left',
        lineHeight: item.lineHeight || 9 * (tmpl.tokens?.lineHeightMultiplier ?? V2_TYPE_SCALE.lineHeightMultiplierBase) + 0.8,
      });
    } else if (item.kind === 'code') {
      page.elements.push(this.buildAccentContainer({
        x,
        y,
        width,
        height: item.boxHeight !== undefined ? item.boxHeight : item.height,
        fill: resolveColor(tmpl, 'surfaceMuted'),
        stroke: resolveColor(tmpl, 'borderMuted'),
        westWidth: 0,
      }));

      this.emitLines(page, item.lines, x + 8, y + 5, Math.max(20, width - 12), {
        font: 'courier',
        size: item.fontSize,
        color: resolveColor(tmpl, 'textMain'),
        align: 'left',
        lineHeight: item.lineHeight || item.fontSize * 1.15,
      });
    } else if (item.kind === 'table') {
      // Booktabs parity: heavy top rule, bold header, light midrule,
      // alternating body fills, per-cell align, heavy bottom rule.
      const heavyW = item.heavyRule || V2_STROKE_TOKENS.heavy;
      const lightW = item.lightRule || V2_STROKE_TOKENS.light;
      const ruleColor = tmpl.colors.ruleblack || tmpl.colors.textmain || resolveColor(tmpl, 'ruleBlack');
      const cellColor = tmpl.colors.ruleblack || tmpl.colors.textmain || resolveColor(tmpl, 'textMain');
      const drawRule = (ry, w) => page.elements.push(this.buildDividerRule({
        x1: x, y1: ry, x2: x + width, y2: ry, width: w, color: ruleColor,
      }));
      const cellX = (cIdx) => x + item.paddingH + item.colWidths.slice(0, cIdx).reduce((a, b) => a + b, 0);
      const cellW = (cIdx) => Math.max(8, item.colWidths[cIdx] - item.paddingH * 2);
      // Symmetric rhythm: the table body starts below topGap (zero on
      // continuations and block-opening tables); bottomGap trails only
      // the closing slice. Both are accounted in item height.
      let rowY = y + (item.topGap || 0);
      drawRule(rowY, heavyW); // toprule
      if (item.header) {
        item.header.cells.forEach((cell, cIdx) => {
          this.emitLines(page, cell.lines, cellX(cIdx), rowY, cellW(cIdx), {
            font: 'helvetica-bold',
            size: item.headerSize,
            color: cellColor,
            align: cell.align || 'left',
            lineHeight: item.headLineH,
          });
        });
        rowY += item.header.height;
        drawRule(rowY - 2, lightW); // midrule
      }
      item.rows.forEach((row, bIdx) => {
        if (bIdx % 2 === 1) {
          page.elements.push({
            type: 'rect', x, y: rowY, w: width, h: row.height,
            fill: tmpl.colors.surface || '#FAFAFA',
          });
        }
        row.cells.forEach((cell, cIdx) => {
          this.emitLines(page, cell.lines, cellX(cIdx), rowY, cellW(cIdx), {
            font: 'helvetica',
            size: item.fontSize,
            color: cellColor,
            align: cell.align || 'left',
            lineHeight: item.lineHeight,
          });
        });
        rowY += row.height;
      });
      // v1 parity: non-final slices close with a light rule (table continues);
      // only the final slice gets the heavy bottomrule.
      drawRule(rowY, item.closesTable === false ? lightW : heavyW);
    } else if (item.kind === 'image') {
      if (item.buffer) {
        const imgX = x + ((width - item.targetW) / 2);
        const imgY = y + 3;
        page.elements.push({
          type: 'image',
          buffer: item.buffer,
          x: imgX,
          y: imgY,
          w: item.targetW,
          h: item.targetH,
          stroke: tmpl.colors.bordercolor || '#E4E4E7',
        });
        if (item.hasCaption && item.captionLines && item.captionLines.length > 0) {
          const captionY = imgY + item.targetH + 4;
          this.emitLines(page, item.captionLines, x + 4, captionY, Math.max(20, width - 8), {
            font: 'helvetica-oblique',
            size: item.captionFontSize,
            color: tmpl.colors.textmuted,
            align: 'center',
            lineHeight: item.captionFontSize * 1.15,
          });
        }
      } else {
        // Fallback placeholder box
        page.elements.push({
          type: 'rect',
          x: x,
          y: y,
          w: width,
          h: 30,
          radius: 3,
          fill: tmpl.colors.surface || '#FAFAFA',
          stroke: tmpl.colors.bordercolor || '#E4E4E7',
        });
        this.emitLines(page, [{ runs: [{ text: `[Imagem não disponível: ${item.alt || item.src || 'arquivo'}]`, style: 'italic' }] }], x + 6, y + 10, Math.max(20, width - 12), {
          font: 'helvetica-oblique',
          size: 7.5,
          color: tmpl.colors.textmuted,
          align: 'center',
          lineHeight: 7.5 * 1.15,
        });
      }
    } else {
      // Paragraph (pre-wrapped exact lines). v1 loose-line-guard parity:
      // short (<14 words) or narrow (<85% of column) paragraphs stay left.
      let pgAlign = item.align || 'left';
      if (pgAlign === 'justify' && item.looseGuard !== false) {
        if ((item.wordCount || 0) < 14 || (item.naturalWidth || 0) < width * 0.85) {
          pgAlign = 'left';
        }
      }
      this.emitLines(page, item.lines, x, y, width, {
        font: 'helvetica',
        size: item.fontSize,
        color: tmpl.colors.textmain || '#111827',
        align: pgAlign,
        lineHeight: item.lineHeight || item.fontSize * 1.15,
      });
    }
  }
}

/**
 * Resolves cross-references and destination links against the compiler's anchorMap.
 * Supports Markdown reference format: [label](#slug) => label (p. X)
 * @param {{ text: string, style?: string }[]} runs
 * @param {Map<string, { page: number, dest: string }>|Record<string, { page: number, dest: string }>} anchorMap
 * @returns {{ text: string, style?: string }[]}
 */
export function replaceReferences(runs, anchorMap) {
  if (!runs || !Array.isArray(runs) || !anchorMap) return runs;
  const getAnchor = (key) => {
    if (anchorMap instanceof Map) return anchorMap.get(key);
    return anchorMap[key];
  };

  return runs.map((run) => {
    if (!run || typeof run.text !== 'string') return run;
    let text = run.text;
    text = text.replace(/\[([^\]]+)\]\(#([^)]+)\)/g, (match, label, slug) => {
      const target = getAnchor(slug);
      if (target && target.page) {
        return `${label} (p. ${target.page})`;
      }
      return label;
    });
    return { ...run, text };
  });
}

/**
 * Audits the estimate==render invariant: every emitted text element is
 * re-measured with the renderer's measurer and flagged when it overflows
 * its allocated width. Run-aware (sample4 H1): styled runs are measured in
 * their own font/size (bold ~7% wider, scripts at 0.72×) so bold-heavy
 * drift is observable — the legacy whole-text single-font pass was blind
 * to it. Zero layout effect — pure observation.
 * Headless callers without a measure fn get `{ skipped: true }`.
 * @param {object[]|object} pagesOrDisplayList
 * @param {Function|null} [measureFn=null] - (text, font, size) => widthPt
 * @param {number} [tolPt=0.5] - Overflow tolerance in points
 * @returns {{ skipped: boolean, checked: number, overflows: number, maxOverflowPt: number, p95OverflowPt: number, tolPt: number, worst: object[] }}
 */
export function auditEstimateRenderFit(pagesOrDisplayList, measureFn = null, tolPt = 0.5) {
  const pages = Array.isArray(pagesOrDisplayList)
    ? pagesOrDisplayList
    : (pagesOrDisplayList?.pages || []);
  const empty = { skipped: true, checked: 0, overflows: 0, maxOverflowPt: 0, p95OverflowPt: 0, tolPt, worst: [] };
  if (typeof measureFn !== 'function') return empty;
  const r2 = (v) => Math.round((Number(v) || 0) * 100) / 100;
  // Per-run width: same font/size resolution the wrapper and blaster share.
  const runWidth = (text, baseFont, runStyle, baseSize) => {
    const effSize = baseSize * runSizeFactor(runStyle || 'normal');
    const font = runFontOf(baseFont || 'helvetica', runStyle || 'normal');
    try {
      const w = measureFn(text, font, effSize);
      if (typeof w === 'number' && Number.isFinite(w)) return w;
    } catch { /* fall through */ }
    return null;
  };
  let checked = 0;
  let overflows = 0;
  let maxOverflowPt = 0;
  const positives = [];
  const worst = [];
  for (const page of pages) {
    for (const el of (page.elements || [])) {
      if (el.type !== 'text' || typeof el.width !== 'number'
        || typeof el.text !== 'string' || !el.text.trim()) continue;
      let w = null;
      try {
        const runs = Array.isArray(el.runs) && el.runs.length > 0 ? el.runs : null;
        if (runs) {
          let sum = 0;
          let okAll = true;
          for (const r of runs) {
            const rw = runWidth(r.text || '', el.font || 'helvetica', r.style || 'normal', el.size || 9.5);
            if (rw === null) { okAll = false; break; }
            sum += rw;
          }
          if (okAll) w = sum;
        }
        if (w === null) w = measureFn(el.text, el.font || 'helvetica', el.size || 9.5);
      } catch { continue; }
      if (typeof w !== 'number' || !Number.isFinite(w)) continue;
      checked++;
      const d = w - el.width;
      if (d > 0) positives.push(d);
      if (d > maxOverflowPt) maxOverflowPt = d;
      if (d > tolPt) {
        overflows++;
        worst.push({ text: el.text.slice(0, 48), overflowPt: r2(d), font: el.font || 'helvetica', size: el.size || 9.5 });
      }
    }
  }
  positives.sort((a, b) => a - b);
  worst.sort((a, b) => b.overflowPt - a.overflowPt);
  return {
    skipped: false,
    checked,
    overflows,
    maxOverflowPt: r2(maxOverflowPt),
    p95OverflowPt: positives.length ? r2(positives[Math.min(positives.length - 1, Math.floor(positives.length * 0.95))]) : 0,
    tolPt,
    worst: worst.slice(0, 3),
  };
}

/**
 * Audits display list element baselines against the vertical grid unit G.
 * Honest-lenient (ADR-ADAPT-03): measures EVERY text element's residual with
 * ref-11 tolerance (1e-6) and reports — never gated on an opt-in flag, never
 * failing. Strict quantized placement is future work (see Knuth-Plass stretch).
 */
export function auditDisplayListBaselines(pagesOrDisplayList, gridUnit = 12, topMargin = 0) {
  const pages = Array.isArray(pagesOrDisplayList)
    ? pagesOrDisplayList
    : (pagesOrDisplayList?.pages || []);
  const G = gridUnit > 0 ? gridUnit : 12;
  let baselineSnapViolations = 0;
  let totalTextElements = 0;

  for (const page of pages) {
    if (page && page._blMeta && page._blMeta.G === G && page._blMeta.topMargin === topMargin) {
      baselineSnapViolations += page._blMeta.v;
      totalTextElements += page._blMeta.t;
      continue;
    }
    let pv = 0;
    let pt = 0;
    for (const el of (page.elements || [])) {
      if (el.type === 'text') {
        pt++;
        const y = typeof el.y === 'number' ? el.y : 0;
        const offset = Math.abs(y - topMargin);
        const normalized = offset / G;
        const residual = Math.abs(normalized - Math.round(normalized));
        if (residual > 1e-6) {
          pv++;
        }
      }
    }
    baselineSnapViolations += pv;
    totalTextElements += pt;
    if (page && typeof page === 'object' && !Object.isFrozen(page)) {
      Object.defineProperty(page, '_blMeta', {
        value: { G, topMargin, v: pv, t: pt },
        enumerable: false,
        configurable: true,
      });
    }
  }

  return {
    baselineSnapViolations,
    pageCount: pages.length,
    totalTextElements,
    compliantRatio: totalTextElements > 0 ? (totalTextElements - baselineSnapViolations) / totalTextElements : 1,
  };
}

/**
 * Audits the bottom-margin invariant: no content element may extend past
 * contentBottomY into the footer zone. Running chrome (header/footer text
 * and rules at/after the footer rule) is excluded — pure observation.
 * @param {object[]|object} pagesOrDisplayList
 * @param {number} contentBottomY - printable content limit in points
 * @param {number} [tolPt=0.5]
 * @returns {{ violations: number, worst: object[] }}
 */
export function auditBottomMargin(pagesOrDisplayList, contentBottomY, tolPt = 0.5) {
  const pages = Array.isArray(pagesOrDisplayList)
    ? pagesOrDisplayList
    : (pagesOrDisplayList?.pages || []);
  const limit = (Number(contentBottomY) || 0) + tolPt;
  let violations = 0;
  const worst = [];
  const r2 = (v) => Math.round((Number(v) || 0) * 100) / 100;
  for (const page of pages) {
    if (page && page._bmMeta && page._bmMeta.limit === limit) {
      violations += page._bmMeta.v;
      for (let wi = 0; wi < page._bmMeta.w.length; wi++) {
        if (worst.length < 5) worst.push(page._bmMeta.w[wi]);
      }
      continue;
    }
    let pv = 0;
    const pw = [];
    for (const el of (page.elements || [])) {
      if (!el || typeof el !== 'object') continue;
      const t = el.type;
      if (t === 'destination' || t === 'tag_struct_start' || t === 'tag_struct_end') continue;
      if (t === 'rotated') continue;
      let top = null;
      let bottom = null;
      if (t === 'text') {
        top = el.y || 0;
        bottom = (el.y || 0) + (el.size || 10);
      } else if (t === 'rect' || t === 'image') {
        top = el.y || 0;
        bottom = (el.y || 0) + (el.h || 0);
      } else if (t === 'rule') {
        top = Math.min(el.y1 || 0, el.y2 || 0);
        bottom = Math.max(el.y1 || 0, el.y2 || 0);
      } else if (t === 'bullet') {
        top = (el.y || 0) - (el.r || 1.5);
        bottom = (el.y || 0) + (el.r || 1.5);
      } else if (t === 'checkbox') {
        top = el.y || 0;
        bottom = (el.y || 0) + 7.5;
      } else {
        continue;
      }
      if (top >= limit) continue;
      if (bottom > limit) {
        pv++;
        if (pw.length < 5) {
          pw.push({
            type: t,
            overPt: r2(bottom - limit),
            text: typeof el.text === 'string' ? el.text.slice(0, 48) : undefined,
          });
        }
      }
    }
    violations += pv;
    for (let wi = 0; wi < pw.length; wi++) {
      if (worst.length < 5) worst.push(pw[wi]);
    }
    if (page && typeof page === 'object' && !Object.isFrozen(page)) {
      Object.defineProperty(page, '_bmMeta', {
        value: { limit, v: pv, w: pw },
        enumerable: false,
        configurable: true,
      });
    }
  }
  return { violations, worst };
}

