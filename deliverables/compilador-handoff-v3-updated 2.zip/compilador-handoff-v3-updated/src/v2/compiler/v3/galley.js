/**
 * Layout & Geometry V3 — Container Splitting & Galley Normalization (M2/M3)
 *
 * Implements exact per-fragment geometry for split containers (`callout`, `code`, `table`),
 * enforcing:
 *   - VG-9: Zero 0-line container shells; each fragment's box height equals its exact
 *     own line/row count + padding.
 *   - VG-10: Split tables clone their header row at the top of every continuation
 *     fragment; split callouts emit a `(continuação)` title bar.
 *   - VG-11: Every table column width is >= minColWidthPt (> 0) and sum <= tableW + 0.01.
 */
import { createBlockAtom, PENALTIES } from './atoms.js';

/**
 * Validates and clamps table column widths so no column is ever <= 0 or NaN (VG-11).
 *
 * @param {number[]} widthsPt proposed column widths in pt
 * @param {number} tableWidthPt total available table width in pt
 * @param {number} [minFloorPt=18] minimum column width floor in pt
 * @returns {number[]} normalized positive widths summing to `tableWidthPt`
 */
export function enforceTableColumnFloors(widthsPt = [], tableWidthPt = 200, minFloorPt = 18) {
  const n = widthsPt.length;
  if (n === 0) return [];
  const safeTableW = Math.max(n * 4, Number(tableWidthPt) || 200);
  const floor = Math.min(minFloorPt, safeTableW / n);
  const out = widthsPt.map((w) => {
    const v = Number(w);
    return Number.isFinite(v) && v > floor ? v : floor;
  });
  // Water-filling normalization keeping every column >= floor
  for (let iter = 0; iter < n + 2; iter++) {
    const sum = out.reduce((a, b) => a + b, 0);
    if (Math.abs(sum - safeTableW) <= 1e-6) break;
    const freeIdx = [];
    let pinnedSum = 0;
    let freeSum = 0;
    for (let i = 0; i < n; i++) {
      if (sum > safeTableW && out[i] <= floor + 1e-9) {
        out[i] = floor;
        pinnedSum += floor;
      } else {
        freeIdx.push(i);
        freeSum += out[i];
      }
    }
    if (freeIdx.length === 0 || freeSum <= 0) break;
    const targetFree = Math.max(0, safeTableW - pinnedSum);
    const scale = targetFree / freeSum;
    let clampedAny = false;
    for (const i of freeIdx) {
      const nextW = out[i] * scale;
      if (nextW < floor) {
        out[i] = floor;
        clampedAny = true;
      } else {
        out[i] = nextW;
      }
    }
    if (!clampedAny) break;
  }
  return out;
}

/**
 * Splits a breakable BlockAtom (`callout`, `code`, or `table`) across an available
 * vertical budget `availHeightMpt`.
 *
 * Returns `{ canSplit: false }` when the available space cannot fit at least 2 lines
 * (for callout/code) or header + 1 data row (for table), or when the remainder would
 * have fewer than 2 lines (callout/code) or 1 data row (table). This guarantees zero
 * 0-line or 1-line orphan container shells (VG-9, VG-10).
 *
 * @param {object} atom BlockAtom
 * @param {number} availHeightMpt remaining height in current column/band in mpt
 * @returns {{ canSplit: boolean, head?: object, tail?: object, penalty?: number }}
 */
export function splitContainerAtom(atom, availHeightMpt) {
  if (!atom || atom.kind !== 'block' || !atom.breakable) {
    return { canSplit: false };
  }

  if (atom.blockType === 'callout' || atom.blockType === 'code') {
    const totalLines = Array.isArray(atom.lines) ? atom.lines : [];
    if (totalLines.length < 4) {
      // Need at least 2 lines in head and 2 lines in tail
      return { canSplit: false };
    }
    const padTop = atom.paddingTopMpt || 4000;
    const padBot = atom.paddingBottomMpt || 4000;
    const pitch = Math.max(1000, atom.linePitchMpt || 11000);
    const titleH = atom.title ? pitch : 0;
    const usableForLines = availHeightMpt - padTop - padBot - titleH;
    const fitCount = Math.floor(usableForLines / pitch);
    const maxHeadLines = Math.min(totalLines.length - 2, fitCount);
    if (maxHeadLines < 2) {
      return { canSplit: false };
    }

    const headLines = totalLines.slice(0, maxHeadLines);
    const tailLines = totalLines.slice(maxHeadLines);
    const contHeader = atom.blockType === 'callout'
      ? `${atom.title ? `${atom.title} ` : ''}(continuação)`
      : '';
    const contTitleH = contHeader ? pitch : 0;

    const headHeightMpt = padTop + titleH + headLines.length * pitch + padBot;
    const tailHeightMpt = padTop + contTitleH + tailLines.length * pitch + padBot;

    const head = createBlockAtom({
      ...atom,
      lines: headLines,
      heightMpt: headHeightMpt,
      marginBelowMpt: 0,
      payload: {
        ...(atom.payload || {}),
        isSplitHead: true,
        lineCount: headLines.length,
      },
    });

    const tail = createBlockAtom({
      ...atom,
      title: contHeader,
      lines: tailLines,
      heightMpt: tailHeightMpt,
      marginAboveMpt: 0,
      payload: {
        ...(atom.payload || {}),
        isContinuation: true,
        continuationTitle: contHeader || null,
        lineCount: tailLines.length,
      },
    });

    return {
      canSplit: true,
      head,
      tail,
      penalty: atom.blockType === 'callout' ? PENALTIES.SPLIT_CALLOUT : PENALTIES.SPLIT_CODE,
    };
  }

  if (atom.blockType === 'table') {
    const rows = Array.isArray(atom.rows) ? atom.rows : [];
    if (rows.length < 2) {
      return { canSplit: false };
    }
    const headerH = atom.header?.heightMpt ?? (atom.linePitchMpt || 14000);
    const rulePad = (atom.paddingTopMpt || 1000) + (atom.paddingBottomMpt || 1000);
    let accMpt = headerH + rulePad;
    let fitRows = 0;
    for (let i = 0; i < rows.length - 1; i++) {
      const rH = rows[i].heightMpt || atom.linePitchMpt || 12000;
      if (accMpt + rH > availHeightMpt) break;
      accMpt += rH;
      fitRows += 1;
    }
    if (fitRows < 1) {
      return { canSplit: false };
    }
    const headRows = rows.slice(0, fitRows);
    const tailRows = rows.slice(fitRows);
    const tailRowsH = tailRows.reduce((s, r) => s + (r.heightMpt || atom.linePitchMpt || 12000), 0);

    const head = createBlockAtom({
      ...atom,
      rows: headRows,
      heightMpt: accMpt,
      marginBelowMpt: 0,
      payload: {
        ...(atom.payload || {}),
        isSplitHead: true,
        headerCloned: Boolean(atom.header),
      },
    });

    const tail = createBlockAtom({
      ...atom,
      header: atom.header ? { ...atom.header, isClonedContinuation: true } : null,
      rows: tailRows,
      heightMpt: headerH + rulePad + tailRowsH,
      marginAboveMpt: 0,
      payload: {
        ...(atom.payload || {}),
        isContinuation: true,
        headerCloned: Boolean(atom.header),
      },
    });

    return {
      canSplit: true,
      head,
      tail,
      penalty: PENALTIES.SPLIT_TABLE,
    };
  }

  return { canSplit: false };
}
