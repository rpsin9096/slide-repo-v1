/**
 * Layout & Geometry V3 — Single-Authority Vertical Glue Distributor (M4)
 *
 * Replaces V2's dual post-hoc stretch passes when `geometry === 'v3'`.
 * Operates in integer millipoints (`1 pt = 1000 mpt`) using Hamilton
 * largest-remainder distribution (`distributeMpt`, VG-15), shifting every
 * element and its attached markers/callouts/cells in lockstep (`VG-13`)
 * so that `justified` columns end with `0 <= voidPt <= 0.5` (`VG-5`).
 */
import { distributeMpt } from './frame.js';

export const GLUE_CAP_FACTORS = Object.freeze({
  INTER_PARAGRAPH: 0.35, // <= 0.35 * u
  ABOVE_HEADING: 0.50,   // <= 0.50 * u
  AROUND_BLOCK: 0.50,    // <= 0.50 * u
  LIST_BOUNDARY: 0.25,   // <= 0.25 * u
  INTER_LINE: 0.06,      // <= 0.06 * u (only when slack > 0.5*u and >= 15 lines)
});

/**
 * Distributes vertical slack across a column's atom positions in integer millipoints.
 *
 * @param {object[]} atoms column atoms
 * @param {number[]} positionsMpt initial baseline/bottom coordinates in mpt
 * @param {object} frame resolved frame from `resolveFrameAndTokens`
 * @param {string} initialState initial `TerminalState` ('justified' | 'balanced' | 'ragged-last' | 'ragged-short')
 * @returns {{ positionsMpt: number[], TerminalState: string, slackMpt: number, appliedMpt: number, voidMpt: number }}
 */
export function distributeColumnGlueMpt(atoms = [], positionsMpt = [], frame = {}, initialState = 'justified') {
  const uMpt = frame.uMpt || 12451;
  const targetBottomMpt = frame.lastGridBaselineMpt || frame.frameBottomMpt || 786610;

  if (initialState !== 'justified' || atoms.length < 2 || positionsMpt.length !== atoms.length) {
    const lastMpt = positionsMpt.length ? positionsMpt[positionsMpt.length - 1] : (frame.frameTopMpt || 0);
    return {
      positionsMpt: [...positionsMpt],
      TerminalState: initialState,
      slackMpt: Math.max(0, targetBottomMpt - lastMpt),
      appliedMpt: 0,
      voidMpt: Math.max(0, targetBottomMpt - lastMpt),
    };
  }

  const lastMpt = positionsMpt[positionsMpt.length - 1];
  const slackMpt = targetBottomMpt - lastMpt;
  if (slackMpt <= 0) {
    return {
      positionsMpt: [...positionsMpt],
      TerminalState: 'justified',
      slackMpt: 0,
      appliedMpt: 0,
      voidMpt: 0,
    };
  }

  // Build stretch slots for each transition i - 1 -> i
  const slots = [];
  const allowInterLine = slackMpt > Math.round(0.5 * uMpt) && atoms.length >= 15;

  for (let i = 1; i < atoms.length; i++) {
    const prev = atoms[i - 1];
    const curr = atoms[i];
    let capFactor = 0;
    let weight = 0;

    if (curr.groupRole === 'heading') {
      capFactor = GLUE_CAP_FACTORS.ABOVE_HEADING;
      weight = 3.0;
    } else if (prev.kind === 'block' || curr.kind === 'block') {
      capFactor = GLUE_CAP_FACTORS.AROUND_BLOCK;
      weight = 3.0;
    } else if (
      (prev.groupRole === 'list-item' && curr.groupRole !== 'list-item') ||
      (prev.groupRole !== 'list-item' && curr.groupRole === 'list-item')
    ) {
      capFactor = GLUE_CAP_FACTORS.LIST_BOUNDARY;
      weight = 1.5;
    } else if (curr.groupRole === 'para-start' || curr.groupRole === 'para-single') {
      capFactor = GLUE_CAP_FACTORS.INTER_PARAGRAPH;
      weight = 2.0;
    } else if (allowInterLine && prev.groupRole !== 'heading') {
      capFactor = GLUE_CAP_FACTORS.INTER_LINE;
      weight = 0.5;
    }

    if (capFactor > 0) {
      slots.push({
        index: i,
        maxMpt: Math.round(capFactor * uMpt),
        weight,
      });
    }
  }

  const maxStretchMpt = slots.reduce((s, slot) => s + slot.maxMpt, 0);
  const usedHeightMpt = lastMpt - (frame.frameTopMpt || 0);
  const fillRatio = (frame.frameHeightMpt || 1) > 0 ? usedHeightMpt / frame.frameHeightMpt : 0;

  if (slots.length < 2 || fillRatio < 0.82 || slackMpt > maxStretchMpt) {
    return {
      positionsMpt: [...positionsMpt],
      TerminalState: 'ragged-short',
      slackMpt,
      appliedMpt: 0,
      voidMpt: slackMpt,
    };
  }

  // Distribute slackMpt across slots respecting per-slot caps via iterative largest-remainder
  const deltas = new Array(atoms.length).fill(0);
  let remainingMpt = slackMpt;
  let activeSlots = slots.map((s) => ({ ...s, allocated: 0 }));

  while (remainingMpt > 0 && activeSlots.length > 0) {
    const shares = distributeMpt(remainingMpt, activeSlots.map((s) => s.weight));
    let progressed = false;
    const nextActive = [];

    for (let k = 0; k < activeSlots.length; k++) {
      const slot = activeSlots[k];
      const room = slot.maxMpt - slot.allocated;
      const add = Math.min(room, shares[k]);
      if (add > 0) {
        slot.allocated += add;
        deltas[slot.index] += add;
        remainingMpt -= add;
        progressed = true;
      }
      if (slot.allocated < slot.maxMpt) {
        nextActive.push(slot);
      }
    }
    if (!progressed) break;
    activeSlots = nextActive;
  }

  const outPositions = [...positionsMpt];
  let accShiftMpt = 0;
  for (let i = 0; i < outPositions.length; i++) {
    accShiftMpt += deltas[i];
    outPositions[i] += accShiftMpt;
  }

  const finalLastMpt = outPositions[outPositions.length - 1];
  return {
    positionsMpt: outPositions,
    TerminalState: 'justified',
    slackMpt,
    appliedMpt: accShiftMpt,
    voidMpt: Math.max(0, targetBottomMpt - finalLastMpt),
  };
}
