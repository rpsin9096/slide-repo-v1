/**
 * Layout & Geometry V3 — Windowed Vertical Cost Solver & Band Balancer (M3)
 *
 * Implements:
 *   - Windowed column break cost evaluation with strict widow/orphan/keepWithNext penalties
 *   - Two-column band balancing (`balanceBandColumns`, VG-6) so balanced columns end within <= 1 u
 *   - Full-page re-solve when a span (`wide-table`, `figure`, `h1`) is deferred to the next page
 *     so `col: 1` is never left empty when `col: 0` has >= 4 atoms (`resolveBandWithDeferredSpans`, VG-7)
 *   - Deterministic `TerminalState` state machine per column (`VG-5`).
 */
import { collapsedGapMpt, PENALTIES } from './atoms.js';
import { splitContainerAtom } from './galley.js';

/**
 * Measures the exact vertical extent (in mpt) of a sequence of atoms placed in a single column.
 *
 * @param {object[]} atoms
 * @param {object} frame resolved frame from `resolveFrameAndTokens`
 * @returns {{ usedHeightMpt: number, lastBaselineMpt: number, positionsMpt: number[] }}
 */
export function measureColumnAtomsMpt(atoms = [], frame = {}) {
  const frameTopMpt = frame.frameTopMpt ?? 0;
  const topskipMpt = frame.topskipMpt ?? 6840;
  if (!atoms || atoms.length === 0) {
    return { usedHeightMpt: 0, lastBaselineMpt: frameTopMpt, positionsMpt: [] };
  }

  const positionsMpt = [];
  let cursorMpt = frameTopMpt;
  let prevMarginBelowMpt = 0;

  for (let i = 0; i < atoms.length; i++) {
    const a = atoms[i];
    const isFirst = i === 0;
    const gapMpt = collapsedGapMpt(prevMarginBelowMpt, a.marginAboveMpt || 0, isFirst);

    if (a.kind === 'line') {
      if (isFirst) {
        cursorMpt = frameTopMpt + Math.max(topskipMpt, a.heightMpt || topskipMpt);
      } else {
        cursorMpt += gapMpt + (a.leadingMpt || frame.uMpt || 12451);
      }
      positionsMpt.push(cursorMpt);
      prevMarginBelowMpt = a.marginBelowMpt || 0;
    } else {
      // BlockAtom or SpanAtom
      if (isFirst) {
        cursorMpt = frameTopMpt + (a.heightMpt || 0);
      } else {
        cursorMpt += gapMpt + (a.heightMpt || 0);
      }
      positionsMpt.push(cursorMpt);
      prevMarginBelowMpt = a.marginBelowMpt || 0;
    }
  }

  return {
    usedHeightMpt: Math.max(0, cursorMpt - frameTopMpt),
    lastBaselineMpt: cursorMpt,
    positionsMpt,
  };
}

/**
 * Evaluates break penalty after index `breakIdx` (inclusive) in `atoms`.
 */
export function evaluateBreakPenalty(atoms, breakIdx) {
  if (breakIdx < 0 || breakIdx >= atoms.length - 1) return 0;
  const curr = atoms[breakIdx];
  const next = atoms[breakIdx + 1];
  let penalty = curr.penaltyAfter || 0;

  if (curr.keepWithNext || curr.groupRole === 'heading') {
    return PENALTIES.HEADING_ORPHAN;
  }
  if (curr.groupRole === 'para-start') {
    // 1-line orphan at bottom of column
    penalty += PENALTIES.ORPHAN;
  }
  if (next && next.groupRole === 'para-end') {
    // 1-line widow at top of next column
    penalty += PENALTIES.WIDOW;
  }
  if (
    curr.groupRole === 'para-start' &&
    breakIdx >= 1 &&
    atoms[breakIdx - 1].groupRole === 'heading'
  ) {
    // Heading + only 1 body line before break
    penalty += PENALTIES.HEADING_ONE_LINE;
  }
  return penalty;
}

/**
 * Balances an atom stream across 2 columns in a band (`VG-6`).
 * Minimizes `|H(col0) - H(col1)| + penalty(splitIdx)` so that for uniform line streams
 * `|lastBaseline(col0) - lastBaseline(col1)| <= uMpt`.
 *
 * @param {object[]} atoms
 * @param {object} frame
 * @param {number} [availHeightMpt=frame.frameHeightMpt]
 * @returns {{ col0: object[], col1: object[], overflow: object[], col0HeightMpt: number, col1HeightMpt: number, skewMpt: number, TerminalState: string }}
 */
export function balanceBandColumns(atoms = [], frame = {}, availHeightMpt = null) {
  const maxH = availHeightMpt ?? frame.frameHeightMpt ?? 756000;
  if (atoms.length === 0) {
    return {
      col0: [],
      col1: [],
      overflow: [],
      col0HeightMpt: 0,
      col1HeightMpt: 0,
      skewMpt: 0,
      TerminalState: 'ragged-last',
    };
  }
  if (atoms.length === 1) {
    const m0 = measureColumnAtomsMpt(atoms, frame);
    return {
      col0: atoms,
      col1: [],
      overflow: [],
      col0HeightMpt: m0.usedHeightMpt,
      col1HeightMpt: 0,
      skewMpt: m0.usedHeightMpt,
      TerminalState: 'ragged-short',
    };
  }

  // First select the prefix of atoms that fits in 2 columns of height maxH
  let fitPrefixLen = atoms.length;
  for (let len = 2; len <= atoms.length; len++) {
    const half = Math.ceil(len / 2);
    const m0 = measureColumnAtomsMpt(atoms.slice(0, half), frame);
    const m1 = measureColumnAtomsMpt(atoms.slice(half, len), frame);
    if (m0.usedHeightMpt > maxH || m1.usedHeightMpt > maxH) {
      fitPrefixLen = Math.max(2, len - 1);
      break;
    }
  }

  const working = atoms.slice(0, fitPrefixLen);
  const overflow = atoms.slice(fitPrefixLen);

  let bestIdx = Math.ceil(working.length / 2);
  let bestCost = Infinity;
  let bestM0 = null;
  let bestM1 = null;

  for (let split = 1; split < working.length; split++) {
    const left = working.slice(0, split);
    const right = working.slice(split);
    const m0 = measureColumnAtomsMpt(left, frame);
    const m1 = measureColumnAtomsMpt(right, frame);
    if (m0.usedHeightMpt > maxH || m1.usedHeightMpt > maxH) continue;

    const pen = evaluateBreakPenalty(working, split - 1);
    // Prefer left column >= right column slightly on ties (editorial convention)
    const skew = Math.abs(m0.usedHeightMpt - m1.usedHeightMpt);
    const rightHeavierBias = m1.usedHeightMpt > m0.usedHeightMpt ? 250 : 0;
    const cost = skew + rightHeavierBias + pen * 1000;
    if (cost < bestCost) {
      bestCost = cost;
      bestIdx = split;
      bestM0 = m0;
      bestM1 = m1;
    }
  }

  // Fallback if all splits were penalized or exceeded maxH
  if (!bestM0 || !bestM1) {
    bestIdx = Math.ceil(working.length / 2);
    bestM0 = measureColumnAtomsMpt(working.slice(0, bestIdx), frame);
    bestM1 = measureColumnAtomsMpt(working.slice(bestIdx), frame);
  }

  const skewMpt = Math.abs(bestM0.usedHeightMpt - bestM1.usedHeightMpt);
  return {
    col0: working.slice(0, bestIdx),
    col1: working.slice(bestIdx),
    overflow,
    col0HeightMpt: bestM0.usedHeightMpt,
    col1HeightMpt: bestM1.usedHeightMpt,
    skewMpt,
    TerminalState: 'balanced',
  };
}

/**
 * Resolves a 2-column band that is interrupted by a full-width `SpanAtom` (`wide-table`,
 * `figure`, or `h1`).
 *
 * Implements the Deferred Span Re-Solve invariant (`VG-7`):
 *   - If the pre-span 2-column band + `span.heightMpt` fits in `availHeightMpt`, the
 *     pre-span atoms are balanced above the span and the span is placed on the current page.
 *   - If the span does NOT fit below the pre-span band (`remainingMpt < spanRequiredMpt`)
 *     and `span.deferrable` is true, the span is pushed to `deferredSpans` for the top of
 *     the next page, and the solver pulls post-span column atoms into the current band
 *     and re-balances across **both** `col0` and `col1` for the full `availHeightMpt`.
 *     Thus `col1` is never stranded empty while `col0` holds >= 4 atoms!
 *
 * @param {object[]} preSpanAtoms
 * @param {object} spanAtom
 * @param {object[]} postSpanAtoms
 * @param {object} frame
 * @param {number} [availHeightMpt=frame.frameHeightMpt]
 */
export function resolveBandWithDeferredSpans(
  preSpanAtoms = [],
  spanAtom = null,
  postSpanAtoms = [],
  frame = {},
  availHeightMpt = null,
) {
  const maxH = availHeightMpt ?? frame.frameHeightMpt ?? 756000;
  if (!spanAtom) {
    const bal = balanceBandColumns([...preSpanAtoms, ...postSpanAtoms], frame, maxH);
    return {
      ...bal,
      placedSpan: null,
      deferredSpans: [],
      reSolvedAfterDefer: false,
    };
  }

  const preBal = balanceBandColumns(preSpanAtoms, frame, maxH);
  const bandUsedMpt = Math.max(preBal.col0HeightMpt, preBal.col1HeightMpt);
  const spanGapMpt = collapsedGapMpt(0, spanAtom.marginAboveMpt || 0, bandUsedMpt === 0);
  const spanRequiredMpt = spanGapMpt + (spanAtom.heightMpt || 0);

  if (bandUsedMpt + spanRequiredMpt <= maxH) {
    // Span fits on current page right below the balanced pre-span band!
    return {
      ...preBal,
      placedSpan: {
        ...spanAtom,
        yTopMpt: (frame.frameTopMpt || 0) + bandUsedMpt + spanGapMpt,
      },
      deferredSpans: [],
      remainingPostAtoms: postSpanAtoms,
      reSolvedAfterDefer: false,
    };
  }

  // Span does NOT fit on current page: defer span to next page and re-solve
  // the current page's 2-column band using preSpanAtoms + postSpanAtoms (if deferrable)
  // or balance preSpanAtoms across both columns so col1 is never empty!
  const combinedAtoms = spanAtom.deferrable !== false
    ? [...preSpanAtoms, ...postSpanAtoms]
    : [...preSpanAtoms];
  const reBal = balanceBandColumns(combinedAtoms, frame, maxH);

  return {
    ...reBal,
    placedSpan: null,
    deferredSpans: [spanAtom],
    remainingPostAtoms: spanAtom.deferrable !== false ? reBal.overflow : postSpanAtoms,
    reSolvedAfterDefer: true,
  };
}

/**
 * Packs a stream of atoms into a single column of height `availHeightMpt`,
 * invoking `splitContainerAtom` when a breakable container crosses the bottom boundary.
 */
export function packSingleColumn(atoms = [], frame = {}, availHeightMpt = null, isLastColumn = false) {
  const maxH = availHeightMpt ?? frame.frameHeightMpt ?? 756000;
  const placed = [];
  const rest = [...atoms];

  while (rest.length > 0) {
    const next = rest[0];
    const candidate = [...placed, next];
    const m = measureColumnAtomsMpt(candidate, frame);
    if (m.usedHeightMpt <= maxH) {
      placed.push(rest.shift());
      continue;
    }

    // Try splitting if it is a breakable BlockAtom
    if (next.kind === 'block' && next.breakable) {
      const currM = measureColumnAtomsMpt(placed, frame);
      const remH = maxH - currM.usedHeightMpt;
      const splitRes = splitContainerAtom(next, remH);
      if (splitRes.canSplit) {
        placed.push(splitRes.head);
        rest[0] = splitRes.tail;
      }
    }
    break;
  }

  // Enforce heading keepWithNext / orphan prevention at end of column
  if (placed.length >= 2 && rest.length > 0) {
    const last = placed[placed.length - 1];
    if (last.keepWithNext || last.groupRole === 'heading') {
      rest.unshift(placed.pop());
    } else if (last.groupRole === 'para-start' && placed.length >= 2) {
      // Avoid 1-line orphan at bottom of column
      rest.unshift(placed.pop());
    }
  }

  const finalM = measureColumnAtomsMpt(placed, frame);
  const fillRatio = maxH > 0 ? finalM.usedHeightMpt / maxH : 0;
  const TerminalState = rest.length === 0 || isLastColumn
    ? 'ragged-last'
    : (fillRatio >= 0.82 ? 'justified' : 'ragged-short');

  return {
    placed,
    overflow: rest,
    usedHeightMpt: finalM.usedHeightMpt,
    lastBaselineMpt: finalM.lastBaselineMpt,
    positionsMpt: finalM.positionsMpt,
    fillRatio,
    TerminalState,
  };
}
