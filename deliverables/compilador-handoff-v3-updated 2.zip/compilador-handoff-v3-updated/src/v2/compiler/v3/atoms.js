/**
 * Layout & Geometry V3 — Vertical Atom Grammar & Margin Collapse (M2)
 *
 * Defines the three vertical atom types (`LineAtom`, `BlockAtom`, `SpanAtom`),
 * max-collapsed vertical margins (VG-3), and heading proximity enforcement (VG-12)
 * in integer millipoints (`1 pt = 1000 mpt`).
 */
import { ptToMpt } from './frame.js';
import { getFontMetrics } from '../../fonts/metrics.js';

export const PENALTIES = Object.freeze({
  WIDOW: 10000,
  ORPHAN: 10000,
  HEADING_ORPHAN: Infinity,
  HEADING_ONE_LINE: 10000,
  CALLOUT_ONE_LINE: 10000,
  TABLE_HEADER_ORPHAN: Infinity,
  SPLIT_CALLOUT: 150,
  SPLIT_CODE: 120,
  SPLIT_TABLE: 80,
  OVERFULL: Infinity,
});

/**
 * Invariant I3 (VG-3): Vertical gaps between adjacent blocks collapse via `max`,
 * never via addition. At the start of a column or band, the leading margin collapses to 0.
 *
 * @param {number} prevMarginBelowMpt
 * @param {number} nextMarginAboveMpt
 * @param {boolean} [isBandStart=false]
 * @returns {number} collapsed gap in integer mpt
 */
export function collapsedGapMpt(prevMarginBelowMpt = 0, nextMarginAboveMpt = 0, isBandStart = false) {
  if (isBandStart) return 0;
  return Math.max(Math.round(prevMarginBelowMpt || 0), Math.round(nextMarginAboveMpt || 0));
}

/**
 * Heading Proximity Invariant (VG-12):
 * Every non-band-initial heading must satisfy `gapAboveMpt / gapBelowMpt >= 1.5`
 * so the heading visually binds to the body text it introduces rather than the
 * preceding paragraph.
 *
 * @param {number} gapAboveMpt
 * @param {number} gapBelowMpt
 * @param {number} uMpt grid unit in mpt
 * @param {boolean} [isBandStart=false]
 * @returns {{ gapAboveMpt: number, gapBelowMpt: number, ratio: number }}
 */
export function enforceHeadingProximity(gapAboveMpt, gapBelowMpt, uMpt, isBandStart = false) {
  const minBelow = Math.max(1, Math.round(0.25 * uMpt));
  const below = Math.max(minBelow, Math.round(gapBelowMpt || minBelow));
  if (isBandStart) {
    return { gapAboveMpt: 0, gapBelowMpt: below, ratio: Infinity };
  }
  const minAbove = Math.ceil(below * 1.5);
  const above = Math.max(minAbove, Math.round(gapAboveMpt || minAbove));
  return {
    gapAboveMpt: above,
    gapBelowMpt: below,
    ratio: above / below,
  };
}

/**
 * Creates a LineAtom representing a single shaped line of text or list item.
 */
export function createLineAtom({
  text = '',
  runs = [],
  fontName = 'arimo',
  fontSizePt = 9.5,
  leadingMpt = 12451,
  groupRole = 'body', // 'para-start' | 'para-mid' | 'para-end' | 'para-single' | 'heading' | 'list-item'
  level = 0,
  penaltyAfter = 0,
  marginAboveMpt = 0,
  marginBelowMpt = 0,
  marker = null,
  sourceBlockId = null,
} = {}) {
  const m = getFontMetrics(fontName, fontSizePt);
  const heightMpt = ptToMpt(m.baselineOffset);
  const depthMpt = ptToMpt(m.descenderDepth);
  return {
    kind: 'line',
    text,
    runs,
    fontName,
    fontSizePt,
    heightMpt,
    depthMpt,
    leadingMpt: Math.round(leadingMpt),
    baselineOffsetMpt: heightMpt,
    groupRole,
    level,
    penaltyAfter,
    marginAboveMpt: Math.round(marginAboveMpt),
    marginBelowMpt: Math.round(marginBelowMpt),
    marker,
    sourceBlockId,
  };
}

/**
 * Creates a BlockAtom representing a container block (callout, code, table, math, image, hr).
 */
export function createBlockAtom({
  blockType = 'callout', // 'callout' | 'code' | 'table' | 'math' | 'image' | 'hr'
  heightMpt = 0,
  depthMpt = 0,
  breakable = true,
  keepWithNext = false,
  penaltyAfter = 0,
  marginAboveMpt = 0,
  marginBelowMpt = 0,
  lines = [],
  rows = [],
  header = null,
  colWidthsPt = [],
  paddingTopMpt = 4000,
  paddingBottomMpt = 4000,
  linePitchMpt = 11000,
  title = '',
  payload = null,
} = {}) {
  return {
    kind: 'block',
    blockType,
    heightMpt: Math.round(heightMpt),
    depthMpt: Math.round(depthMpt),
    breakable: Boolean(breakable),
    keepWithNext: Boolean(keepWithNext),
    penaltyAfter,
    marginAboveMpt: Math.round(marginAboveMpt),
    marginBelowMpt: Math.round(marginBelowMpt),
    lines,
    rows,
    header,
    colWidthsPt,
    paddingTopMpt: Math.round(paddingTopMpt),
    paddingBottomMpt: Math.round(paddingBottomMpt),
    linePitchMpt: Math.round(linePitchMpt),
    title,
    payload,
  };
}

/**
 * Creates a SpanAtom representing a full-width page span (masthead, h1, wide-table, figure).
 */
export function createSpanAtom({
  spanType = 'wide-table', // 'masthead' | 'h1' | 'wide-table' | 'panoramic-table' | 'figure'
  heightMpt = 0,
  marginAboveMpt = 0,
  marginBelowMpt = 0,
  deferrable = true,
  keepWithNext = false,
  payload = null,
} = {}) {
  return {
    kind: 'span',
    spanType,
    heightMpt: Math.round(heightMpt),
    marginAboveMpt: Math.round(marginAboveMpt),
    marginBelowMpt: Math.round(marginBelowMpt),
    deferrable: Boolean(deferrable),
    keepWithNext: Boolean(keepWithNext),
    payload,
  };
}
