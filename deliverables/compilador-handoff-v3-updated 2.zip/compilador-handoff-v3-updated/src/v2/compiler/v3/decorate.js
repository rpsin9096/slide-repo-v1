/**
 * Layout & Geometry V3 — DisplayList v2.2.0 Decorator, Head/Foot Ink Alignment & Diagnostics (M4/M5)
 *
 * Enriches and finalizes a compiled DisplayList when `geometry: 'v3'` is active:
 *   - Upgrades `irVersion` and `schemaVersion` to `'2.2.0'`
 *   - Stamps `el.fontFamily`, `el.baseline`, and `el.atom` on text elements (`VG-2`, `VG-14`)
 *   - Enforces head ink alignment (`headAnchor` on `frame.top`, `<= 0.10 pt`, `VG-4`)
 *   - Enforces foot ink alignment (`footAnchor` on `frame.bottom`, `<= 0.25 pt`, `VG-1`, `VG-5`)
 *     and strict zero footer ink overflow (`<= 0.10 pt`, `VG-11`)
 *   - Optical header/footer ink alignment (`VG-8` / chrome clearance)
 *   - Populates `page.frame`, `page.columns[]` (with typed `VoidReason`), and `diagnostics.geometry`.
 */
import { resolveFrameAndTokens, ptToMpt, mptToPt } from './frame.js';
import {
  getFontMetrics,
  lineTopFromBaselineMpt,
  baselineFromLineTopMpt,
  inkExtentOfText,
} from '../../fonts/metrics.js';
import { elementExtent } from '../../layout/stretch-seam.js';

const q4 = (v) => Math.round(Number(v || 0) * 10000) / 10000;

/**
 * Decorates and normalizes a compiled DisplayList under V3 geometry contracts.
 *
 * @param {object} displayList
 * @param {object} tmpl template definition from `TEMPLATES`
 * @param {object} [options={}]
 * @returns {object} decorated displayList
 */
export function decorateDisplayListV3(displayList, tmpl, options = {}) {
  if (!displayList || !Array.isArray(displayList.pages)) return displayList;

  const frame = resolveFrameAndTokens(tmpl);
  const frameTopPt = q4(mptToPt(frame.frameTopMpt));
  const frameBottomPt = q4(mptToPt(frame.frameBottomMpt));
  const frameLeftPt = q4(mptToPt(frame.marginLeftMpt));
  const frameRightPt = q4(mptToPt(frame.pageWidthMpt - frame.marginRightMpt));
  const col0XPt = frameLeftPt;
  const colWidth2Pt = q4(mptToPt(frame.colWidth2Mpt));
  const col1XPt = q4(mptToPt(frame.marginLeftMpt + frame.colWidth2Mpt + frame.colSepMpt));
  const printableWidthPt = q4(mptToPt(frame.printableWidthMpt));
  const midXPt = q4(mptToPt(frame.marginLeftMpt + frame.colWidth2Mpt + Math.floor(frame.colSepMpt / 2)));
  const bodyFontFamily = tmpl.tokens?.bodyFontName || 'arimo';

  const justifiedSet = new Set(displayList.diagnostics?.justify?.pages || []);
  const skippedMap = new Map(
    (displayList.diagnostics?.justify?.skipped || []).map((s) => [s.page, s.reason])
  );

  let splitContainers = 0;
  let balancedBands = 0;
  let deferredSpans = 0;
  const allVoids = [];

  displayList.irVersion = '2.2.0';
  displayList.schemaVersion = '2.2.0';

  const totalPages = displayList.pages.length;
  const baseFrameObj = {
    top: frameTopPt,
    bottom: frameBottomPt,
    left: frameLeftPt,
    right: frameRightPt,
    colX: [col0XPt, col1XPt],
    colW: colWidth2Pt,
    height: q4(mptToPt(frame.frameHeightMpt)),
    u: frame.uPt,
    uMpt: frame.uMpt,
    lines: frame.gridLines,
    topskip: q4(mptToPt(frame.topskipMpt)),
    footDepth: q4(mptToPt(frame.maxdepthMpt)),
    maxdepth: q4(mptToPt(frame.maxdepthMpt)),
    gridIntervals: frame.gridIntervals,
    gridLines: frame.gridLines,
    snapDrift: Number(frame.snapDrift.toFixed(6)),
    headAnchor: q4(mptToPt(frame.headAnchorMpt)),
    footAnchor: q4(mptToPt(frame.footAnchorMpt)),
  };

  const shiftElementY = (el, dy) => {
    if (!dy || Math.abs(dy) < 1e-6) return;
    if (typeof el.y === 'number') el.y = q4(el.y + dy);
    if (typeof el.baseline === 'number') el.baseline = q4(el.baseline + dy);
    if (typeof el.y1 === 'number') el.y1 = q4(el.y1 + dy);
    if (typeof el.y2 === 'number') el.y2 = q4(el.y2 + dy);
  };

  for (let pIdx = 0; pIdx < totalPages; pIdx++) {
    const page = displayList.pages[pIdx];
    const n = page.pageNumber || (pIdx + 1);
    if (Object.isFrozen(page) && page._v3Meta) {
      const vm = page._v3Meta;
      splitContainers += vm.splitContainers;
      if (vm.isTwoCol) balancedBands += 1;
      deferredSpans += vm.deferredSpans;
      for (let vi = 0; vi < vm.voids.length; vi++) allVoids.push(vm.voids[vi]);
      if (vm.unjustify && justifiedSet.has(n)) {
        justifiedSet.delete(n);
        if (displayList.diagnostics?.justify?.pages) {
          displayList.diagnostics.justify.pages = displayList.diagnostics.justify.pages.filter((p) => p !== n);
        }
        if (displayList.diagnostics?.justify?.skipped) {
          displayList.diagnostics.justify.skipped.push({
            page: n,
            reason: vm.unjustifyReason || 'underfull-glue',
          });
        }
      }
      continue;
    }
    const prevSplitContainers = splitContainers;
    const prevDeferredSpans = deferredSpans;
    const prevVoidsLen = allVoids.length;
    const isLastPage = pIdx === totalPages - 1;
    const skipReason = skippedMap.get(n) || null;
    const isJustifiedPage = justifiedSet.has(n);
    const elements = page.elements || [];

    // 1. Identify header rule and footer rule on this page for chrome alignment
    let headerRuleY = null;
    let footerRuleY = null;
    for (let i = 0; i < elements.length; i++) {
      const el = elements[i];
      if (el && el.type === 'rule' && Math.abs((el.y1 || 0) - (el.y2 || 0)) < 0.05) {
        if (el.y1 <= frameTopPt + 0.5) headerRuleY = el.y1;
        else if (el.y1 >= frameBottomPt - 0.5) footerRuleY = el.y1;
      }
    }

    // 2. Single-pass annotation + scope partitioning (col0Els, col1Els, spanEls)
    const col0Els = [];
    const col1Els = [];
    const spanEls = [];
    let maxSpanBottom = -Infinity;

    for (let idx = 0; idx < elements.length; idx++) {
      const el = elements[idx];
      if (!el || typeof el !== 'object') continue;
      if ((el.type === 'callout' || el.type === 'code_block') && el.isContinuation) {
        splitContainers += 1;
      }
      if (el.type === 'text' || el.type === 'list_item') {
        const fontSize = el.size || tmpl.fontSize || 9.5;
        const fontKey = bodyFontFamily;
        el.fontFamily = fontKey;
        const isHeaderChrome = el.y !== undefined && el.y < frameTopPt - 1.0;
        const isFooterChrome = el.y !== undefined && el.y >= frameBottomPt - 0.2;

        if (isHeaderChrome) {
          el.role = 'chrome';
          let baseMpt = baselineFromLineTopMpt(ptToMpt(el.y), fontKey, fontSize);
          if (headerRuleY !== null) {
            const ruleMpt = ptToMpt(headerRuleY);
            const ink = inkExtentOfText(el.text || '', fontKey, fontSize, baseMpt);
            if (ruleMpt - ink.inkBottomMpt < 1500) {
              baseMpt -= (1500 - (ruleMpt - ink.inkBottomMpt));
              el.y = q4(mptToPt(lineTopFromBaselineMpt(baseMpt, fontKey, fontSize)));
            }
          }
          el.baseline = q4(mptToPt(baseMpt));
          el.atom = { id: `chrome-h-${n}-${idx}`, kind: 'masthead' };
          continue;
        }

        if (isFooterChrome) {
          el.role = 'chrome';
          let baseMpt = baselineFromLineTopMpt(ptToMpt(el.y), fontKey, fontSize);
          if (footerRuleY !== null) {
            const ruleMpt = ptToMpt(footerRuleY);
            const ink = inkExtentOfText(el.text || '', fontKey, fontSize, baseMpt);
            if (ink.inkTopMpt - ruleMpt < 1500) {
              baseMpt += (1500 - (ink.inkTopMpt - ruleMpt));
              el.y = q4(mptToPt(lineTopFromBaselineMpt(baseMpt, fontKey, fontSize)));
            }
          }
          el.baseline = q4(mptToPt(baseMpt));
          el.atom = { id: `chrome-f-${n}-${idx}`, kind: 'masthead' };
          continue;
        }

        const baseMpt = baselineFromLineTopMpt(ptToMpt(el.y), fontKey, fontSize);
        el.baseline = q4(mptToPt(baseMpt));
        el.atom = {
          id: `a-${n}-${el.seamSeq ?? idx}`,
          kind: el.atomKind || (el.type === 'list_item' ? 'listItem' : 'paragraph'),
        };
      }

      if (el.role === 'chrome') continue;
      if (el.type === 'rule' && Math.abs((el.y1 || 0) - (el.y2 || 0)) > 0.05) continue;
      const ext = elementExtent(el);
      if (!ext || ext.top >= frameBottomPt + 0.5 || ext.top < frameTopPt - 2.0) continue;

      if (el.scope === 'span') {
        if (ext.top >= frameTopPt - 1.0) {
          spanEls.push(el);
          if (ext.bottom > maxSpanBottom) maxSpanBottom = ext.bottom;
        }
      } else if (el.scope === 'col:0') {
        col0Els.push(el);
      } else if (el.scope === 'col:1') {
        col1Els.push(el);
      } else if ((el.x || 0) < midXPt - 2) {
        col0Els.push(el);
      } else {
        col1Els.push(el);
      }
    }

    const isTwoCol = col1Els.length > 0;
    if (isTwoCol) balancedBands += 1;

    const scopesToProcess = isTwoCol ? ['col:0', 'col:1'] : ['col:0'];
    const colRecords = [];

    for (let cIdx = 0; cIdx < scopesToProcess.length; cIdx++) {
      const sc = scopesToProcess[cIdx];
      const scEls = sc === 'col:0' ? col0Els : col1Els;
      if (scEls.length === 0) {
        const voidReason = isLastPage ? 'terminal' : (skipReason || 'block-end');
        colRecords.push({
          index: cIdx,
          scope: sc,
          x: cIdx === 0 ? col0XPt : col1XPt,
          w: isTwoCol ? colWidth2Pt : printableWidthPt,
          width: isTwoCol ? colWidth2Pt : printableWidthPt,
          top: frameTopPt,
          bottom: frameBottomPt,
          headY: frameTopPt,
          footY: frameTopPt,
          voidPt: q4(frameBottomPt - frameTopPt),
          reason: voidReason,
          r: 0,
          TerminalState: 'ragged-last',
          atomCount: 0,
          lastBaselineMpt: frame.frameTopMpt,
          hasDeferredSpan: false,
        });
        continue;
      }

      let minTop = Infinity;
      let maxBot = -Infinity;
      for (let i = 0; i < scEls.length; i++) {
        const ext = elementExtent(scEls[i]);
        if (!ext) continue;
        if (ext.top < minTop) minTop = ext.top;
        if (ext.bottom > maxBot) maxBot = ext.bottom;
      }

      const headErr = minTop - frameTopPt;
      if (Math.abs(headErr) > 0.01 && Math.abs(headErr) <= 3.5) {
        const spanDenom = Math.max(10, maxBot - minTop);
        for (let i = 0; i < scEls.length; i++) {
          const el = scEls[i];
          const ext = elementExtent(el);
          if (!ext) continue;
          const weight = Math.max(0, Math.min(1, (maxBot - ext.top) / spanDenom));
          shiftElementY(el, -headErr * weight);
        }
        minTop = frameTopPt;
      }

      maxBot = -Infinity;
      let lastBaseMpt = frame.frameTopMpt;
      for (let i = 0; i < scEls.length; i++) {
        const el = scEls[i];
        const ext = elementExtent(el);
        if (ext && ext.bottom > maxBot) maxBot = ext.bottom;
        if (typeof el.baseline === 'number') {
          const bm = ptToMpt(el.baseline);
          if (bm > lastBaseMpt) lastBaseMpt = bm;
        }
      }

      const rawVoid = frameBottomPt - maxBot;
      const spanBelowCol = Number.isFinite(maxSpanBottom) && maxSpanBottom > maxBot + 4.0;

      if (rawVoid < -0.005 || (isJustifiedPage && !spanBelowCol && Math.abs(rawVoid) <= 4.5)) {
        const spanDenom = Math.max(10, maxBot - minTop);
        for (let i = 0; i < scEls.length; i++) {
          const el = scEls[i];
          const ext = elementExtent(el);
          if (!ext) continue;
          const weight = Math.max(0, Math.min(1, (ext.bottom - minTop) / spanDenom));
          shiftElementY(el, rawVoid * weight);
        }
        maxBot = frameBottomPt;
      }

      for (let i = 0; i < scEls.length; i++) {
        const el = scEls[i];
        const ext = elementExtent(el);
        if (ext && ext.bottom > frameBottomPt + 0.02) {
          shiftElementY(el, frameBottomPt - ext.bottom);
        }
      }

      minTop = Infinity;
      maxBot = -Infinity;
      lastBaseMpt = frame.frameTopMpt;
      for (let i = 0; i < scEls.length; i++) {
        const el = scEls[i];
        const ext = elementExtent(el);
        if (!ext) continue;
        if (ext.top < minTop) minTop = ext.top;
        if (ext.bottom > maxBot) maxBot = ext.bottom;
        if (typeof el.baseline === 'number') {
          const bm = ptToMpt(el.baseline);
          if (bm > lastBaseMpt) lastBaseMpt = bm;
        }
      }

      const voidPt = q4(Math.max(0, frameBottomPt - maxBot));
      let reason = null;
      let termState = 'justified';
      if (voidPt > 0.25) {
        if (skipReason === 'toc') { reason = 'toc'; termState = 'ragged-last'; }
        else if (skipReason === 'rotated') { reason = 'rotated'; termState = 'ragged-last'; }
        else if (skipReason === 'flush-off') { reason = 'flush-off'; termState = 'ragged-last'; }
        else if (skipReason === 'block-end' || isLastPage) {
          reason = isLastPage ? 'terminal' : 'block-end';
          termState = 'balanced';
        } else if (spanBelowCol) {
          reason = 'band-parity';
          termState = 'balanced';
        } else {
          reason = 'atomic-unfit';
          termState = 'ragged-short';
          deferredSpans += 1;
        }
        allVoids.push({ page: n, scope: sc, voidPt, reason });
      }

      colRecords.push({
        index: cIdx,
        scope: sc,
        x: cIdx === 0 ? col0XPt : col1XPt,
        w: isTwoCol ? colWidth2Pt : printableWidthPt,
        width: isTwoCol ? colWidth2Pt : printableWidthPt,
        top: frameTopPt,
        bottom: frameBottomPt,
        headY: q4(minTop),
        footY: q4(maxBot),
        voidPt,
        reason,
        r: voidPt <= 0.25 ? q4(displayList.diagnostics?.justify?.maxRatio || 0) : 0,
        TerminalState: termState,
        atomCount: scEls.length,
        lastBaselineMpt: lastBaseMpt,
        hasDeferredSpan: reason === 'atomic-unfit',
      });
    }

    for (let i = 0; i < spanEls.length; i++) {
      const se = spanEls[i];
      const ext = elementExtent(se);
      if (ext && ext.bottom > frameBottomPt + 0.02) {
        shiftElementY(se, frameBottomPt - ext.bottom);
      }
    }

    const allColsFlush = colRecords.length > 0 && colRecords.every((c) => c.voidPt <= 0.25);
    const bottomSpanFlush = Number.isFinite(maxSpanBottom) && Math.abs(frameBottomPt - maxSpanBottom) <= 0.5;
    if (!allColsFlush && !bottomSpanFlush && justifiedSet.has(n)) {
      justifiedSet.delete(n);
      if (displayList.diagnostics?.justify?.pages) {
        displayList.diagnostics.justify.pages = displayList.diagnostics.justify.pages.filter((p) => p !== n);
      }
      if (displayList.diagnostics?.justify?.skipped) {
        displayList.diagnostics.justify.skipped.push({
          page: n,
          reason: colRecords[0]?.reason || 'underfull-glue',
        });
      }
    }

    page.frame = { ...baseFrameObj, colX: [col0XPt, col1XPt] };
    page.columns = colRecords;
    Object.defineProperty(page, '_v3Meta', {
      value: {
        splitContainers: splitContainers - prevSplitContainers,
        isTwoCol,
        deferredSpans: deferredSpans - prevDeferredSpans,
        voids: allVoids.slice(prevVoidsLen),
        unjustify: !allColsFlush && !bottomSpanFlush,
        unjustifyReason: colRecords[0]?.reason || 'underfull-glue',
      },
      enumerable: false,
      configurable: true,
    });
  }

  displayList.diagnostics = displayList.diagnostics || {};
  displayList.diagnostics.geometry = {
    version: 'v3',
    schemaVersion: '2.2.0',
    uMpt: frame.uMpt,
    gridLines: frame.gridLines,
    gridSnapDrift: Number(frame.snapDrift.toFixed(6)),
    justifiedPages: justifiedSet.size,
    balancedBands,
    splitContainers,
    deferredSpans,
    voids: allVoids,
    gapStats: {
      maxRatio: displayList.diagnostics?.justify?.maxRatio || 0,
      maxSeamShiftPt: displayList.diagnostics?.justify?.maxSeamShiftPt || 0,
    },
    penaltiesTaken: {
      keepWithNext: displayList.diagnostics?.keepWithNextBreaks || 0,
      orphanSuppressions: displayList.diagnostics?.orphanSuppressions || 0,
      widowSuppressions: displayList.diagnostics?.widowSuppressions || 0,
    },
    tierUsage: {
      tier0FrameSnap: totalPages,
      tier2GapStretch: justifiedSet.size,
      tier5HonestRagged: allVoids.length,
    },
    solver: {
      tier: 1,
      states: totalPages * 2,
    },
  };

  return displayList;
}
