import { getFontMetrics } from '../../fonts/metrics.js';
/**
 * Layout & Geometry V3 — Frame & 3-Layer Token Math (Integer Millipoints)
 *
 * All vertical geometry in V3 operates in integer millipoints (1 pt = 1000 mpt).
 * Enforces Grid Integrality (VG-0), Largest-Remainder distribution (VG-15),
 * and three-layer token resolution (Layer 1 Frame -> Layer 2 Vertical Grid -> Layer 3 Component).
 */
import { PAGE_SIZES } from '../../core/geometry.js';
import { rhythmForTemplate } from '../../templates/definitions.js';

export const MPT_PER_PT = 1000;

export function ptToMpt(pt) {
  return Math.round(Number(pt || 0) * MPT_PER_PT);
}

export function mptToPt(mpt) {
  return Number(mpt || 0) / MPT_PER_PT;
}

/**
 * Largest-remainder (Hamilton) integer distribution of `totalMpt` across
 * `weights`. Guarantees:
 *   1. Every returned share is an integer.
 *   2. The sum of returned shares equals `Math.round(totalMpt)` exactly.
 *   3. No two equal-weight slots ever differ by more than 1 mpt.
 *
 * @param {number} totalMpt integer millipoints to distribute
 * @param {number[]} weights positive weight per slot
 * @returns {number[]} integer millipoint share per slot
 */
export function distributeMpt(totalMpt, weights = []) {
  const n = weights.length;
  if (n === 0) return [];
  const total = Math.round(totalMpt);
  const cleanWeights = weights.map((w) => Math.max(0, Number(w) || 0));
  const weightSum = cleanWeights.reduce((a, b) => a + b, 0);
  if (weightSum <= 0) {
    const base = Math.trunc(total / n);
    let rem = total - base * n;
    return cleanWeights.map(() => {
      if (rem > 0) { rem--; return base + 1; }
      if (rem < 0) { rem++; return base - 1; }
      return base;
    });
  }

  const sign = total < 0 ? -1 : 1;
  const absTotal = Math.abs(total);
  const exact = cleanWeights.map((w) => (absTotal * w) / weightSum);
  const floors = exact.map((v) => Math.floor(v));
  let remainder = absTotal - floors.reduce((a, b) => a + b, 0);

  const order = exact
    .map((v, idx) => ({ idx, frac: v - floors[idx] }))
    .sort((a, b) => (b.frac !== a.frac ? b.frac - a.frac : a.idx - b.idx));

  for (let i = 0; i < remainder; i++) {
    floors[order[i % n].idx] += 1;
  }

  return floors.map((v) => v * sign);
}

/**
 * Resolves the 3-layer token hierarchy and snapped baseline grid for a template.
 *
 * Layer 1 (Page Frame):
 *   frameTopMpt = margins.top + headsep
 *   frameBottomMpt = pageHeight - margins.bottom - footskip
 *   frameHeightMpt = frameBottomMpt - frameTopMpt
 *   headAnchorMpt = frameTopMpt - headsep
 *   footAnchorMpt = frameBottomMpt + footskip
 *
 * Layer 2 (Vertical Grid & Rhythm):
 *   topskipMpt = round(0.72 * bodySize * 1000)
 *   maxdepthMpt = round(0.28 * bodySize * 1000)
 *   N = max(1, round((frameHeightMpt - topskipMpt) / u0Mpt))
 *   uMpt = floor((frameHeightMpt - topskipMpt) / N)
 *
 * @param {object} tmpl template definition from TEMPLATES
 * @param {{ width: number, height: number }} [pageSize=PAGE_SIZES.A4]
 */
export function resolveFrameAndTokens(tmpl = {}, pageSize = PAGE_SIZES.A4) {
  const v = tmpl.vertical || {};
  const tok = tmpl.tokens || {};
  const rhythm = rhythmForTemplate(tmpl);

  const pageWidthMpt = ptToMpt(pageSize.width);
  const pageHeightMpt = ptToMpt(pageSize.height);
  const marginLeftMpt = ptToMpt(tmpl.margins?.left ?? 28.35);
  const marginRightMpt = ptToMpt(tmpl.margins?.right ?? 28.35);
  const marginTopMpt = ptToMpt(tmpl.margins?.top ?? 26.93);
  const marginBottomMpt = ptToMpt(tmpl.margins?.bottom ?? 28.35);
  const headheightMpt = ptToMpt(tmpl.headheight ?? 12);
  const headsepMpt = ptToMpt(tmpl.headsep ?? 6.5);
  const footskipMpt = ptToMpt(tmpl.footskip ?? 12.5);
  const colSepMpt = ptToMpt(tmpl.columnsep ?? 14.17);

  const frameTopMpt = marginTopMpt + headheightMpt + headsepMpt;
  const frameBottomMpt = pageHeightMpt - marginBottomMpt - footskipMpt;
  const frameHeightMpt = frameBottomMpt - frameTopMpt;
  const headAnchorMpt = frameTopMpt - headsepMpt;
  const footAnchorMpt = frameBottomMpt + footskipMpt;

  const printableWidthMpt = pageWidthMpt - marginLeftMpt - marginRightMpt;
  const colWidth2Mpt = Math.floor((printableWidthMpt - colSepMpt) / 2);

  const bodySizePt = v.bodySizePt ?? tmpl.fontSize ?? 9.5;
  const bodySizeMpt = ptToMpt(bodySizePt);
  const lineStretch = v.lineStretch ?? tmpl.lineStretch ?? 1.15;
  const bodyFont = tok.bodyFontName || 'arimo';
  const fm = getFontMetrics(bodyFont, bodySizePt);

  const topskipMpt = Math.round((bodySizeMpt * fm.capHeight) / fm.unitsPerEm);
  const maxdepthMpt = Math.round((bodySizeMpt * Math.abs(fm.descender)) / fm.unitsPerEm);
  const u0Mpt = ptToMpt(rhythm.bodyPitchPt);
  const usableSpanMpt = frameHeightMpt - topskipMpt - maxdepthMpt;
  const gridIntervals = Math.max(1, Math.round(usableSpanMpt / u0Mpt));
  const uMpt = Math.round(usableSpanMpt / gridIntervals);
  const gridLines = gridIntervals + 1;
  const snapDrift = Math.abs(uMpt - u0Mpt) / u0Mpt;

  // First and last nominal grid baselines inside the frame
  const firstBaselineMpt = frameTopMpt + topskipMpt;
  const lastGridBaselineMpt = firstBaselineMpt + gridIntervals * uMpt;

  const scaleU = (mult, fallbackU = 0.25) => Math.round((mult ?? fallbackU) * uMpt);

  return {
    pageWidthMpt,
    pageHeightMpt,
    marginLeftMpt,
    marginRightMpt,
    marginTopMpt,
    marginBottomMpt,
    headsepMpt,
    footskipMpt,
    colSepMpt,
    printableWidthMpt,
    colWidth2Mpt,
    frameTopMpt,
    frameBottomMpt,
    frameHeightMpt,
    headAnchorMpt,
    footAnchorMpt,
    bodySizePt,
    lineStretch,
    topskipMpt,
    maxdepthMpt,
    u0Mpt,
    uMpt,
    uPt: mptToPt(uMpt),
    gridIntervals,
    gridLines,
    snapDrift,
    firstBaselineMpt,
    lastGridBaselineMpt,
    bodyPitchMpt: ptToMpt(rhythm.bodyPitchPt),
    listPitchMpt: ptToMpt(bodySizePt * rhythm.fontRatio + rhythm.listGapPt),
    gapsMpt: {
      parskip: scaleU(v.parskipU, 0.25),
      h1Above: scaleU(v.h1AboveU, 1.0),
      h1Below: scaleU(v.h1BelowU, 0.5),
      h2Above: scaleU(v.h2AboveU, 0.75),
      h2Below: scaleU(v.h2BelowU, 0.25),
      h3Above: scaleU(v.h3AboveU, 0.5),
      h3Below: scaleU(v.h3BelowU, 0.25),
      h4Above: scaleU(v.h4AboveU, 0.5),
      h4Below: scaleU(v.h4BelowU, 0.25),
      listTop: scaleU(v.listTopU, 0.25),
      listBottom: scaleU(v.listBottomU, 0.25),
      calloutMargin: scaleU(v.calloutMarginU, 0.5),
      tableMargin: scaleU(v.tableMarginU, 0.5),
      codeMargin: scaleU(v.codeMarginU, 0.5),
      ruleMargin: scaleU(v.ruleMarginU, 0.5),
      figureMargin: scaleU(v.figureMarginU, 0.5),
    },
    tokens: tok,
  };
}
