/**
 * FocusGate / PDF Engine V2: Executable Verify Matrix
 *
 * Nine hard-number acceptance suites (ref-11 verify/suite.ts + ref-4
 * tests/editorial-engine.test.cjs). Lean, no images, deterministic.
 * Run: `node src/v2/qa/verify-suite.js`
 */

import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { runPipeline, PipelineError } from '../runtime/pipeline.js';
import { rhythmForTemplate, TEMPLATES } from '../templates/definitions.js';
import {
  isPrivateHost, parseIpv4Variant, detectImageType, probeImageDimensions,
  validateImageBuffer, resolveImageSource, SUPPORTED_IMAGE_TYPES,
} from '../modules/image-module.js';
import { assertDriverPurity, countCommands, freezeIR } from '../core/display-list.js';
import { checkColumnOrder, checkDisparity, checkDiagnostics } from './span-gates.js';
import { V2MulticolGalleyBalancer } from '../layout/multicol.js';
import { makeBox } from '../layout/box.js';
import { parseMarkdownToAST } from '../ingest/from-markdown.js';
import { serializeMarkdown } from '../ingest/serialize.js';
import { validateAST } from '../core/ast-schema.js';
import { runCompileJob, poolStatus } from '../runtime/pool.js';
import { runBoth as runDualBoth } from '../compat/dual-run.js';
import { GeometryCompiler } from '../compiler/geometry-compiler.js';
import { readCorpus } from '../../../tests/corpus/index.js';

const sha16 = (buf) => createHash('sha256').update(buf).digest('hex').slice(0, 16);

function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const FIX = { timestamp: 1700000000000, seed: 'verify' };
const docOf = (markdown, extra = {}) => ({
  title: 'Verify', template: 'base',
  blocks: [{ title: 'A', markdown, masthead: { enabled: false }, flags: { autofix: true, optimize_tables: true, split_equations: true }, columns: null }],
  ...extra,
});

function check(name, pass, detail = '') {
  return { name, pass: Boolean(pass), detail: String(detail) };
}

// Suite 1 — baseline grid: multi-page corpus with headings + long table.
async function suiteGrid() {
  const checks = [];
  const rows = Array.from({ length: 80 }, (_, i) => `| row ${i} alpha | ${i} |`).join('\n');
  const dl = (await runPipeline({
    payload: docOf(`# Alpha\n\nBody one two three four five.\n\n## Beta\n\nMore body text here for wrap.\n\n| h1 | h2 |\n|---|---:|\n${rows}\n`),
    mode: 'paginate', ...FIX,
  })).displayList;
  checks.push(check('pages-exist', dl.totalPages >= 2, `pages=${dl.totalPages}`));
  checks.push(check('all-pages-nonempty', dl.pages.every(p => p.elements.length > 0), `pages=${dl.pages.length}`));
  checks.push(check('frozen-ir', Object.isFrozen(dl) && Object.isFrozen(dl.pages[0]), 'deep-frozen'));
  checks.push(check('table-sliced', (dl.diagnostics.tableSlices || 0) >= 1, `slices=${dl.diagnostics.tableSlices}`));
  checks.push(check('tracer-gates-present',
    ['panoramicTransitions', 'overfullColumns'].every(k => typeof dl.diagnostics[k] === 'number'),
    JSON.stringify({ t: dl.diagnostics.tableSlices, p: dl.diagnostics.panoramicTransitions, o: dl.diagnostics.overfullColumns })));
  // Adapted-port gates 2-4: counters present, baseline audit non-vacuous,
  // row-guard unit probes deterministic (direct _splitTable, no layout flakiness).
  const d = dl.diagnostics;
  checks.push(check('tracer-counters-present',
    ['keepWithNextBreaks', 'orphanSuppressions', 'widowSuppressions'].every(k => typeof d[k] === 'number'),
    JSON.stringify({ k: d.keepWithNextBreaks, o: d.orphanSuppressions, w: d.widowSuppressions })));
  checks.push(check('baseline-audited',
    typeof d.baselineSnapViolations === 'number' && (d.totalTextElements || 0) > 0,
    `violations=${d.baselineSnapViolations} elements=${d.totalTextElements} ratio=${Number(d.compliantRatio || 0).toFixed(3)}`));
  // Keep-with-next trigger: heading-dense corpus must force adhesion events.
  const hBody = Array.from({ length: 12 }, () => 'Body line one two three four five six seven.').join('\n\n');
  const hSec = Array.from({ length: 25 }, (_, i) => `# Heading ${i}\n\n${hBody}\n`).join('\n');
  const hDl = (await runPipeline({ payload: docOf(hSec), mode: 'paginate', ...FIX })).displayList;
  checks.push(check('keep-with-next-fires', hDl.diagnostics.keepWithNextBreaks >= 1,
    `breaks=${hDl.diagnostics.keepWithNextBreaks} pages=${hDl.totalPages}`));
  const gc = new GeometryCompiler();
  const rowItem = (n, h) => ({ header: null, rows: Array.from({ length: n }, () => ({ height: h })), heavyRule: 0, topGap: 0, bottomGap: 0, continued: false });
  // Orphan-tail: 5 rows, room for 4 → pop one so the closing pair travels together.
  const [oSlice, oRest] = gc._splitTable(rowItem(5, 14), 60);
  checks.push(check('orphan-guard-unit',
    oSlice.rows.length === 3 && oRest.rows.length === 2 && oSlice.splitGuards?.orphan === true,
    `slice=${oSlice.rows.length} rest=${oRest.rows.length}`));
  // Widow-leader: 4 rows, room for ~1.4 → slop-take a friend instead of stranding one.
  const [wSlice, wRest] = gc._splitTable(rowItem(4, 14), 22);
  checks.push(check('widow-guard-unit',
    wSlice.rows.length === 2 && wRest.rows.length === 2 && wSlice.splitGuards?.widow === true,
    `slice=${wSlice.rows.length} rest=${wRest.rows.length}`));
  checks.push(check('commands-counted', countCommands(dl).total > 0, `total=${countCommands(dl).total}`));
  return { name: 'grid', checks };
}

// Suite 2 — determinism: same seed+ts → same SHA; shifted clock → differs.
async function suiteDeterminism() {
  const checks = [];
  const payload = docOf('# Hi\n\nPara one two.\n\n| a | b |\n|---|---|\n| 1 | 2 |\n');
  const a = await runPipeline({ payload, mode: 'pdf', seed: 'det', timestamp: FIX.timestamp });
  const b = await runPipeline({ payload, mode: 'pdf', seed: 'det', timestamp: FIX.timestamp });
  const c = await runPipeline({ payload, mode: 'pdf', seed: 'det', timestamp: FIX.timestamp + 1000 });
  checks.push(check('stable-hash', sha16(a.buffer) === sha16(b.buffer), `${sha16(a.buffer)}`));
  checks.push(check('clock-sensitive', sha16(a.buffer) !== sha16(c.buffer), `${sha16(a.buffer)} vs ${sha16(c.buffer)}`));
  return { name: 'determinism', checks };
}

// Suite 3 — driver isolation: AST/closure rejected, frozen IR accepted,
// renderer source free of layout imports.
async function suiteIsolation() {
  const checks = [];
  try { assertDriverPurity({ blocks: [{ markdown: 'x' }] }, 'pdfkit'); checks.push(check('ast-rejected', false, 'not thrown')); }
  catch (e) { checks.push(check('ast-rejected', /AST_LEAK/.test(e.message), e.message.slice(0, 60))); }
  try {
    assertDriverPurity({ totalPages: 1, pages: [{ elements: [{ type: 'text', paint() {} }] }] }, 'pdfkit');
    checks.push(check('closure-rejected', false, 'not thrown'));
  } catch (e) { checks.push(check('closure-rejected', /CLOSURE_LEAK/.test(e.message), e.message.slice(0, 60))); }
  const dl = (await runPipeline({ payload: docOf('# H\n\nBody.\n'), mode: 'paginate', ...FIX })).displayList;
  try { assertDriverPurity(dl, 'pdfkit'); checks.push(check('frozen-ir-accepted', true, `cmds=${countCommands(dl).total}`)); }
  catch (e) { checks.push(check('frozen-ir-accepted', false, e.message.slice(0, 80))); }
  // Renderer import audit: blaster (pure renderer) must not reach into
  // layout/coordinator or compiler; driver.js stays the wired composer.
  try {
    const here = dirname(fileURLToPath(import.meta.url));
    const blasterSrc = readFileSync(join(here, '../drivers/pdfkit/blaster.js'), 'utf8');
    const forbidden = ['layout/coordinator', 'layout/knuth-plass', 'layout/hyphenation', 'compiler/geometry-compiler', 'ingest/from-markdown'];
    const hits = forbidden.filter(f => blasterSrc.includes(f));
    checks.push(check('renderer-import-audit', hits.length === 0, hits.length ? `hits=${hits.join(',')}` : 'clean'));
  } catch (e) { checks.push(check('renderer-import-audit', false, e.message.slice(0, 60))); }
  // freezeIR idempotent + mutation blocked
  const again = freezeIR(dl);
  let blocked = false;
  try { again.totalPages = 999; } catch { blocked = true; }
  checks.push(check('freeze-idempotent', again === dl && blocked && dl.totalPages !== 999, 'mutation throws'));
  // freeze-with-buffer: image bytes ride the IR as el.buffer (owned by the
  // imageMap, never mutated). V8 throws "Cannot freeze array buffer views
  // with elements" on Object.freeze(Buffer) — deepFreeze must skip views.
  try {
    const withBuf = freezeIR({ totalPages: 1, pages: [{ elements: [{ type: 'image', buffer: Buffer.from([1, 2, 3]) }] }] });
    const el = withBuf.pages[0].elements[0];
    const bytesIntact = el.buffer && el.buffer[0] === 1 && el.buffer.length === 3;
    const parentFrozen = Object.isFrozen(withBuf) && Object.isFrozen(withBuf.pages[0]);
    checks.push(check('freeze-with-buffer', bytesIntact && parentFrozen, bytesIntact ? 'buffer passes through, parents frozen' : 'buffer mangled'));
  } catch (e) { checks.push(check('freeze-with-buffer', false, e.message.slice(0, 80))); }
  return { name: 'isolation', checks };
}

// Suite 4 — randomized AST roundtrip: parse→serialize→parse preserves blocks.
async function suiteRoundtrip() {
  const checks = [];
  const rand = mulberry32(0xC0FFEE);
  const words = ['alpha', 'beta', 'gamma', 'delta', 'R$ 12,50', '42%', '**bold**', '*it*', '`code`'];
  const pick = (arr) => arr[Math.floor(rand() * arr.length)];
  const N = 200;
  let preserved = 0;
  let valid = 0;
  let typeStable = 0;
  let alignStable = 0;
  let firstErr = '';
  for (let k = 0; k < N; k++) {
    const ncols = 1 + Math.floor(rand() * 4);
    const head = Array.from({ length: ncols }, () => pick(words)).join(' | ');
    const sep = Array.from({ length: ncols }, () => (rand() < 0.5 ? '---' : '---:')).join(' | ');
    const nrows = Math.floor(rand() * 4);
    const body = Array.from({ length: nrows }, () =>
      Array.from({ length: ncols }, () => pick(words)).join(' | ')).join('\n');
    const md = `# H${k} ${pick(words)}\n\nPara ${pick(words)} ${pick(words)}.\n\n| ${head} |\n| ${sep} |\n${body ? body.split('\n').map(r => `| ${r} |`).join('\n') + '\n' : ''}`;
    try {
      const a1 = parseMarkdownToAST(md);
      const s1 = serializeMarkdown(a1);
      const a2 = parseMarkdownToAST(s1);
      const v1 = validateAST(a1);
      const v2 = validateAST(a2);
      if (v1.ok && v2.ok) valid++;
      if (a1.blocks.length === a2.blocks.length) preserved++;
      else if (!firstErr) firstErr = `iter ${k}: ${a1.blocks.length}->${a2.blocks.length}`;
      const t1 = a1.blocks.map(b => b.type).join(',');
      const t2 = a2.blocks.map(b => b.type).join(',');
      if (t1 === t2) typeStable++;
      else if (!firstErr) firstErr = `iter ${k} types: ${t1} vs ${t2}`;
      const al1 = JSON.stringify(a1.blocks.filter(b => b.type === 'table').map(t => t.alignments));
      const al2 = JSON.stringify(a2.blocks.filter(b => b.type === 'table').map(t => t.alignments));
      if (al1 === al2) alignStable++;
      else if (!firstErr) firstErr = `iter ${k} aligns: ${al1} vs ${al2}`;
    } catch (e) {
      if (!firstErr) firstErr = `iter ${k} threw: ${e.message.slice(0, 60)}`;
    }
  }
  checks.push(check('roundtrip-preserved', preserved === N, `${preserved}/${N} ${firstErr}`));
  checks.push(check('roundtrip-valid', valid === N, `${valid}/${N}`));
  checks.push(check('roundtrip-types', typeStable === N, `${typeStable}/${N} ${firstErr}`));
  checks.push(check('roundtrip-aligns', alignStable === N, `${alignStable}/${N} ${firstErr}`));
  return { name: 'roundtrip', checks };
}

// Suite 6 — rhythm + estimate==render fit: template rhythm is declared and
// numerically identical to the legacy inline constants; every emitted text
// element fits its allocated width; the strict gate fires on demand.
async function suiteFit() {
  const checks = [];
  const base = rhythmForTemplate(TEMPLATES.base);
  checks.push(check('rhythm-base', Math.abs(base.bodyPitchPt - (9.5 * 1.1499 + 1.5)) < 1e-9
    && base.gridUnit === 12 && base.parskipPt === 2.2, `pitch=${base.bodyPitchPt.toFixed(3)}pt`));
  const mini = rhythmForTemplate(TEMPLATES.bauhaus_minimalist);
  checks.push(check('rhythm-mini', Math.abs(mini.bodyPitchPt - (8 * 1.20996 + 1.0)) < 1e-9
    && mini.listGapPt === 1.0, `pitch=${mini.bodyPitchPt.toFixed(3)}pt`));
  const payload = docOf('# Fit\n\nBody with **bold words** and enough text to wrap lines across columns.\n\n| h1 | h2 |\n|---|---:|\n| alpha beta gamma | 42 |\n');
  const pag = await runPipeline({ payload, mode: 'paginate', ...FIX });
  const fit = pag.displayList.diagnostics.fit;
  checks.push(check('fit-audited', fit && !fit.skipped && fit.checked > 0, `checked=${fit && fit.checked}`));
  checks.push(check('fit-clean', fit.overflows === 0, `overflows=${fit.overflows} max=+${fit.maxOverflowPt}pt`));
  checks.push(check('fit-warn-quiet', (pag.warnings || []).length === 0, `${(pag.warnings || []).length} warnings`));
  // Gate mechanics: impossible threshold in strict mode must throw FIT_GATE.
  try {
    await runPipeline({ payload, mode: 'paginate', ...FIX, fitGate: { maxOverflows: -1, warnOnly: false } });
    checks.push(check('fit-gate-fires', false, 'not thrown'));
  } catch (e) {
    checks.push(check('fit-gate-fires', e.code === 'FIT_GATE', (e.code || '') + ' ' + e.message.slice(0, 60)));
  }
  return { name: 'fit', checks };
}

// Suite 5 — concurrency: N jobs through the pool, all succeed, and the event
// loop is never held for longer than the starvation budget.
//
// The previous version sampled setImmediate latency on a 5ms interval and
// reported a p95. That was broken twice over:
//
//   1. It captured ONE sample for a ~250ms window (a sampler interval cannot
//      fire while a synchronous compile holds the loop), so "p95" was a single
//      number wearing a percentile's name. It passed 8/8 runs, then failed at
//      283ms on a slow machine — it measured the host, not the code.
//   2. What it measured was one job's DURATION, not loop starvation. The
//      cooperative pool yields only BETWEEN jobs (pool.js setImmediate), so a
//      job blocks the loop for its whole run: sample1.md = 204ms.
//
// Two candidate replacements were measured against an injected 250ms stall and
// both were rejected for being blind to it:
//   - perf_hooks.monitorEventLoopDelay: its histogram advances on a libuv timer
//     the blocked loop never runs. It reported max=5.7ms during a 250ms stall.
//   - a chained setImmediate sampler: 0.3ms. Each tick re-bases on the previous
//     tick, so a long delay never appears as a gap.
// A self-re-arming timer that records its own lateness DOES see it (measured
// 149.4 / 298.5 / 599.6ms for 150 / 300 / 600ms stalls) and reads real compiles
// accurately (92.0ms of a 96ms job), so that is what this gate uses.
async function suiteConcurrency() {
  const checks = [];
  const N = 10;
  // Longest synchronous block the server may impose on a live request handler.
  // Measured worst case today is ~130ms for a 10-job burst; the budget leaves
  // headroom for slower hardware without encoding one machine's speed.
  const STARVATION_BUDGET_MS = 400;
  const MIN_SAMPLES = 2;

  const lateness = [];
  let running = true;
  let nextAt = performance.now() + 4;
  const arm = () => setTimeout(() => {
    const now = performance.now();
    lateness.push(Math.max(0, now - nextAt));
    nextAt = now + 4;              // absolute schedule: no drift accumulation
    if (running) arm();
  }, Math.max(0, nextAt - performance.now()));
  arm();

  const start = Date.now();
  const jobs = Array.from({ length: N }, (_, k) =>
    runCompileJob(docOf(`# Job ${k}\n\nBody text for job ${k} with words words words.\n`), { seed: `conc-${k}`, timestamp: FIX.timestamp }));
  let bufs = [];
  let err = null;
  try { bufs = await Promise.all(jobs); } catch (e) { err = e; }
  const wallMs = Date.now() - start;
  // Drain before stopping: the blocked period has not been observed by any tick
  // until the loop gets a turn after the work resolves.
  await new Promise((r) => setTimeout(r, 12));
  running = false;

  const sorted = lateness.slice().sort((a, b) => a - b);
  const maxMs = sorted[sorted.length - 1] || 0;
  const p95Ms = sorted[Math.floor(sorted.length * 0.95)] || 0;
  const st = poolStatus();
  checks.push(check('all-succeed', !err && bufs.length === N, err ? err.message.slice(0, 80) : `${N}/${N}`));
  checks.push(check('buffers-valid', bufs.every(b => b && b.length > 1000), `min=${Math.min(...bufs.map(b => b?.length || 0))}`));
  checks.push(check('pool-accounted', st.completed >= N, JSON.stringify({ completed: st.completed, failed: st.failed })));
  // Non-vacuous measurement: the old gate returned a verdict from n=1. Anything
  // at or below 1 is a single data point again, so refuse to judge it.
  checks.push(check('loop-samples-sufficient', sorted.length >= MIN_SAMPLES, `samples=${sorted.length} (need >=${MIN_SAMPLES})`));
  checks.push(check('event-loop-stall', maxMs < STARVATION_BUDGET_MS,
    `maxBlock=${maxMs.toFixed(1)}ms p95=${p95Ms.toFixed(1)}ms samples=${sorted.length} wall=${wallMs}ms budget=${STARVATION_BUDGET_MS}ms`));
  return { name: 'concurrency', checks };
}

// Suite 7 — assets: SSRF guard, magic-byte gate, dimension probe, data-URI resolve.
async function suiteAssets() {
  const checks = [];
  checks.push(check('ssrf-private', isPrivateHost('127.0.0.1') && isPrivateHost('10.0.0.1') && isPrivateHost('localhost'), 'loopback+private blocked'));
  checks.push(check('ssrf-public', !isPrivateHost('example.com'), 'public allowed'));
  checks.push(check('ipv4-obfuscated', parseIpv4Variant('2130706433') === '127.0.0.1', `${parseIpv4Variant('2130706433')}`));
  checks.push(check('supported-types', SUPPORTED_IMAGE_TYPES.includes('png') && SUPPORTED_IMAGE_TYPES.includes('jpeg'), SUPPORTED_IMAGE_TYPES.join(',')));
  // Minimal 1x1 PNG: signature + IHDR with width/height = 1 (offsets 16/20).
  const png = Buffer.alloc(32, 0);
  png.set([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a], 0);
  png.writeUInt32BE(13, 8);
  png.write('IHDR', 12);
  png.writeUInt32BE(1, 16);
  png.writeUInt32BE(1, 20);
  checks.push(check('detect-png', detectImageType(png) === 'png', `${detectImageType(png)}`));
  checks.push(check('detect-unknown', detectImageType(Buffer.from('hello world!')) === null, 'null'));
  const probe = probeImageDimensions(png);
  checks.push(check('probe-1x1', probe && probe.width === 1 && probe.height === 1, JSON.stringify(probe)));
  checks.push(check('validate-png', !!validateImageBuffer(png), 'accepted'));
  checks.push(check('validate-junk', validateImageBuffer(Buffer.from('not-an-image-bytes!!')) === null, 'rejected'));
  const uri = `data:image/png;base64,${png.toString('base64')}`;
  const resolved = await resolveImageSource(uri);
  checks.push(check('resolve-data-uri', resolved && resolved.length === png.length, `len=${resolved?.length}`));
  checks.push(check('resolve-traversal', await resolveImageSource('../../etc/passwd').then((r) => r === null), 'blocked'));
  checks.push(check('resolve-empty', await resolveImageSource('').then((r) => r === null), 'null'));
  return { name: 'assets', checks };
}

// Suite 8 — dual-run: typst vs pdfkit parity behind V2_DUAL_RUN flag (compat/dual-run.js).
async function suiteDualRun() {
  const checks = [];
  const docIR = docOf('# Dual\n\nBody for dual-run parity with a small table.\n\n| h1 | h2 |\n|---|---|\n| a | b |\n');
  let out = null;
  let err = null;
  try { out = runDualBoth(docIR, { dual: true }); } catch (e) { err = e; }
  checks.push(check('dual-runs', !err && !!out, err ? String(err.message).slice(0, 80) : 'ok'));
  checks.push(check('dual-parity', !!out && out.parity === true, out ? `parity=${out.parity}` : 'no-output'));
  checks.push(check('dual-typst-emitted', !!out && String(out.typst || '').length > 100, out ? `len=${String(out.typst || '').length}` : 'no-output'));
  checks.push(check('dual-pdfkit-boxes', !!out && out.pdfkit && out.pdfkit.boxes > 0, out ? `boxes=${out?.pdfkit?.boxes}` : 'no-output'));
  return { name: 'dualrun', checks };
}

// Suite 9 — spangates: Fase 2 span gates. Frozen rhythm from
// tests/fixtures/span-baseline.json over the 4 real fixtures (deterministic
// seed+timestamp) + balancer invariants on a synthetic region-sized galley.
// No images, no network.
async function suiteSpanGates() {
  const checks = [];
  const here = dirname(fileURLToPath(import.meta.url));
  const repo = join(here, '..', '..', '..');
  const saved = JSON.parse(readFileSync(join(repo, 'tests', 'fixtures', 'span-baseline.json'), 'utf-8'));
  const docOfFixture = (markdown) => ({
    title: 'Baseline', template: 'base',
    blocks: [{ title: 'A', markdown, masthead: { enabled: false }, flags: { autofix: true, optimize_tables: true, split_equations: true }, columns: null }],
  });
  for (const name of ['sample1.md', 'sample2.md', 'sample3.md', 'text-test.md']) {
    const markdown = readCorpus(name);
    const dl = (await runPipeline({ payload: docOfFixture(markdown), mode: 'paginate', seed: saved.seed, timestamp: saved.timestamp })).displayList;
    const g = checkDiagnostics(dl, saved.fixtures[name]);
    checks.push(check(`frozen-${name}`, g.pass, g.detail));
    checks.push(check(`overfull-${name}`, dl.diagnostics.overfullColumns === 0, `overfull=${dl.diagnostics.overfullColumns}`));
  }
  const mk = (h) => makeBox('para', { heightPt: h, lines: 1, text: 'x' });
  const even = new V2MulticolGalleyBalancer({}).balance(Array.from({ length: 10 }, () => mk(12)));
  checks.push(check('order-even', checkColumnOrder(even).pass, `h1=${even.height1} h2=${even.height2}`));
  checks.push(check('disparity-even', checkDisparity(even, 12).pass, `disp=${even.disparity}`));
  return { name: 'spangates', checks };
}

export async function runVerifySuite(opts = {}) {
  const only = opts.only ? new Set([opts.only].flat()) : null;
  const suites = { grid: suiteGrid, determinism: suiteDeterminism, isolation: suiteIsolation, roundtrip: suiteRoundtrip, concurrency: suiteConcurrency, fit: suiteFit, assets: suiteAssets, dualrun: suiteDualRun, spangates: suiteSpanGates };
  const results = [];
  const start = Date.now();
  for (const [name, fn] of Object.entries(suites)) {
    if (only && !only.has(name)) continue;
    const t0 = Date.now();
    try {
      const r = await fn();
      results.push({ ...r, ms: Date.now() - t0, pass: r.checks.every(c => c.pass) });
    } catch (e) {
      const code = e instanceof PipelineError ? e.code : 'SUITE_CRASH';
      results.push({ name, ms: Date.now() - t0, pass: false, checks: [check('suite-threw', false, `[${code}] ${String((e && e.message) || e).slice(0, 120)}`)] });
    }
  }
  const pass = results.every(r => r.pass);
  return { pass, suites: results, ms: Date.now() - start };
}

// CLI: `node src/v2/qa/verify-suite.js [suite]`
if (process.argv[1] && process.argv[1].endsWith('verify-suite.js')) {
  const only = process.argv[2] || null;
  runVerifySuite({ only }).then((res) => {
    for (const s of res.suites) {
      console.log(`${s.pass ? 'PASS' : 'FAIL'} ${s.name} (${s.ms}ms)`);
      for (const c of s.checks) console.log(`  ${c.pass ? 'ok' : 'XX'} ${c.name}${c.detail ? ` — ${c.detail}` : ''}`);
    }
    console.log(res.pass ? `\nVERIFY: PASS (${res.ms}ms)` : `\nVERIFY: FAIL (${res.ms}ms)`);
    process.exit(res.pass ? 0 : 1);
  }).catch((e) => { console.error('VERIFY CRASH:', e); process.exit(2); });
}
