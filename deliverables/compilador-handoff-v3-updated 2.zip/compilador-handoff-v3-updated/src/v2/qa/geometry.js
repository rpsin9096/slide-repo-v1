// V2 QA geometry asserts (lean, no images). Mirrors verify-pdf-geometry pattern.
export function balanceWithinPct(aPt, bPt, pct = 2) {
  if (aPt === 0 && bPt === 0) return true;
  return (Math.abs(aPt - bPt) / Math.max(aPt, bPt)) * 100 <= pct;
}

// pages: array of line-counts per page. No trailing single-line page allowed.
export function noSingleLineTail(pages) {
  if (pages.length <= 1) return true;
  return pages[pages.length - 1] > 1;
}
