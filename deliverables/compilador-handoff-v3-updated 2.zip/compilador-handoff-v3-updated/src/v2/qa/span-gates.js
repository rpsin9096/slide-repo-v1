/**
 * Span gates (Fase 2): pure, deterministic checks over balancer results and
 * compiled diagnostics. No I/O, no clock, no PDFKit/Typst.
 */

export function checkColumnOrder(result) {
  const h1 = result?.height1 ?? result?.col1Height ?? 0;
  const h2 = result?.height2 ?? result?.col2Height ?? 0;
  return { pass: h2 <= h1, detail: `h1=${h1} h2=${h2}` };
}

export function checkDisparity(result, lineHeight = 12) {
  const d = typeof result?.disparity === 'number'
    ? result.disparity
    : Math.abs((result?.height1 ?? 0) - (result?.height2 ?? 0));
  return { pass: d <= lineHeight, detail: `disparity=${d} lineHeight=${lineHeight}` };
}

export function checkDiagnostics(displayList, frozen) {
  const core = (d) => ({
    totalPages: d?.totalPages ?? null,
    tableSlices: d?.diagnostics?.tableSlices ?? null,
    panoramicTransitions: d?.diagnostics?.panoramicTransitions ?? null,
    overfullColumns: d?.diagnostics?.overfullColumns ?? null,
  });
  const a = core(displayList);
  const e = {
    totalPages: frozen?.totalPages ?? null,
    tableSlices: frozen?.diagnostics?.tableSlices ?? null,
    panoramicTransitions: frozen?.diagnostics?.panoramicTransitions ?? null,
    overfullColumns: frozen?.diagnostics?.overfullColumns ?? null,
  };
  const pass = a.totalPages === e.totalPages
    && a.tableSlices === e.tableSlices
    && a.panoramicTransitions === e.panoramicTransitions
    && a.overfullColumns === e.overfullColumns;
  return { pass, detail: JSON.stringify({ got: a, want: e }) };
}
