/**
 * FocusGate / PDF Engine V2: Font Catalog & Transliteration Tables
 * Provides canonical font mappings, glyph bridges, and WinAnsi transliteration.
 */

export const FONT_CATALOG = {
  serif: 'Times-Roman',
  'serif-bold': 'Times-Bold',
  'serif-italic': 'Times-Italic',
  'serif-bold-italic': 'Times-BoldItalic',
  sans: 'Helvetica',
  'sans-bold': 'Helvetica-Bold',
  'sans-italic': 'Helvetica-Oblique',
  'sans-bold-italic': 'Helvetica-BoldOblique',
  mono: 'Courier',
  'mono-bold': 'Courier-Bold',
  'mono-italic': 'Courier-Oblique',
  'mono-bold-italic': 'Courier-BoldOblique',
  // Direct postscript aliases
  helvetica: 'Helvetica',
  'helvetica-bold': 'Helvetica-Bold',
  'helvetica-oblique': 'Helvetica-Oblique',
  'helvetica-boldoblique': 'Helvetica-BoldOblique',
  times: 'Times-Roman',
  'times-roman': 'Times-Roman',
  'times-bold': 'Times-Bold',
  'times-italic': 'Times-Italic',
  'times-bolditalic': 'Times-BoldItalic',
  courier: 'Courier',
  'courier-bold': 'Courier-Bold',
  'courier-oblique': 'Courier-Oblique',
  'courier-boldoblique': 'Courier-BoldOblique',
};

export const UNICODE_TO_NAME = {
  32: 'space', 33: 'exclam', 34: 'quotedbl', 35: 'numbersign', 36: 'dollar', 37: 'percent',
  38: 'ampersand', 39: 'quotesingle', 40: 'parenleft', 41: 'parenright', 42: 'asterisk',
  43: 'plus', 44: 'comma', 45: 'hyphen', 46: 'period', 47: 'slash', 58: 'colon',
  59: 'semicolon', 60: 'less', 61: 'equal', 62: 'greater', 63: 'question', 64: 'at',
  91: 'bracketleft', 92: 'backslash', 93: 'bracketright', 94: 'asciicircum', 95: 'underscore',
  96: 'grave', 123: 'braceleft', 124: 'bar', 125: 'braceright', 126: 'asciitilde',
  0x2018: 'quoteleft', 0x2019: 'quoteright', 0x201c: 'quotedblleft', 0x201d: 'quotedblright',
  0x2013: 'endash', 0x2014: 'emdash', 0x2022: 'bullet', 0x2026: 'ellipsis', 0x2020: 'dagger',
  0x2021: 'daggerdbl', 0x00a7: 'section', 0x00b6: 'paragraph', 0x00b0: 'degree',
  0x00ab: 'guillemotleft', 0x00bb: 'guillemotright', 0x2039: 'guilsinglleft', 0x203a: 'guilsinglright',
  0x00a9: 'copyright', 0x00ae: 'registered', 0x2122: 'trademark', 0x00e9: 'eacute',
  0x00e8: 'egrave', 0x00ea: 'ecircumflex', 0x00e0: 'agrave', 0x00e7: 'ccedilla',
  0x00fc: 'udieresis', 0x00f6: 'odieresis', 0x00e4: 'adieresis', 0x00df: 'germandbls',
  0x00f1: 'ntilde', 0x00ed: 'iacute', 0x00f3: 'oacute', 0x00fa: 'uacute', 0x00e1: 'aacute',
  0x00a3: 'sterling', 0x00a5: 'yen', 0x20ac: 'Euro', 0x00d7: 'multiply', 0x00f7: 'divide',
  0x00b1: 'plusminus', 0x00bd: 'onehalf', 0x00bc: 'onequarter', 0x00be: 'threequarters',
  0x2212: 'minus', 0x00b7: 'periodcentered', 0x2032: 'quotesingle', 0x00a0: 'space',
};

const DIGIT_NAMES = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine'];

export function glyphNameFor(codePoint) {
  if (codePoint >= 0x41 && codePoint <= 0x5a) return String.fromCharCode(codePoint);
  if (codePoint >= 0x61 && codePoint <= 0x7a) return String.fromCharCode(codePoint);
  if (codePoint >= 0x30 && codePoint <= 0x39) return DIGIT_NAMES[codePoint - 0x30];
  return UNICODE_TO_NAME[codePoint] ?? 'question';
}

/** Transliteration fallbacks for WinAnsi / non-Unicode PDFKit fonts */
export const UNSUPPORTED_FALLBACK = {
  '\u2192': '->', '\u2190': '<-', '\u2194': '<->', '\u21d2': '=>', '\u21d0': '<=',
  '\u2264': '<=', '\u2265': '>=', '\u2260': '!=', '\u2248': '~', '\u221e': 'inf',
  '\u2211': 'Sum', '\u220f': 'Prod', '\u222b': 'Int', '\u2208': 'in', '\u2286': 'subseteq',
  '\u2225': '||', '\u22c5': '*', '\u2032': "'", '\u00d7': '\u00d7',
  '\u03b1': 'alpha', '\u03b2': 'beta', '\u03b3': 'gamma', '\u03b4': 'delta',
  '\u03b5': 'epsilon', '\u03b8': 'theta', '\u03bb': 'lambda', '\u03bc': 'mu',
  '\u03c0': 'pi', '\u03c3': 'sigma', '\u03c6': 'phi', '\u03c9': 'omega',
  '\u0393': 'Gamma', '\u0394': 'Delta', '\u0398': 'Theta', '\u039b': 'Lambda',
  '\u03a3': 'Sigma', '\u03a6': 'Phi', '\u03a9': 'Omega', '\u2202': 'd',
  '\u2207': 'grad', '\u221a': 'sqrt', '\u2245': '~=', '\u2261': '==',
  '\u2282': 'subset', '\u222a': 'union', '\u2229': 'intersect', '\u2200': 'forall',
  '\u2203': 'exists', '\u00ac': 'not', '\u2227': 'and', '\u2228': 'or',
  '\u2308': '[', '\u2309': ']', '\u230a': '[', '\u230b': ']',
};

export function getFontName(hasCustomFonts, style = 'normal', tmplOrFamily = null, hasModern = false) {
  const family = (tmplOrFamily && typeof tmplOrFamily === 'object') ? tmplOrFamily.tokens?.fontFamily : tmplOrFamily;
  if ((family === 'inter' || family === 'bauhaus_minimalist') && hasModern) {
    switch (style) {
      case 'bold': return 'AppModernSemiBold';
      case 'medium': return 'AppModernMedium';
      case 'italic':
      case 'oblique': return 'AppModernItalic';
      case 'bold_italic': return 'AppModernSemiBoldItalic';
      case 'code':
      case 'mono': return hasCustomFonts ? 'AppMono' : 'Courier';
      case 'math': return hasCustomFonts ? 'AppSerifItalic' : 'Times-Italic';
      case 'unicode': return hasCustomFonts ? 'AppUnicode' : 'Helvetica';
      default: return 'AppModern';
    }
  }
  if (hasCustomFonts) {
    switch (style) {
      case 'bold': return 'AppSansBold';
      case 'italic':
      case 'oblique': return 'AppSansOblique';
      case 'bold_italic': return 'AppSansBoldOblique';
      case 'code':
      case 'mono': return 'AppMono';
      case 'math': return 'AppSerifItalic';
      case 'unicode': return 'AppUnicode';
      default: return 'AppSans';
    }
  }
  switch (style) {
    case 'bold': return 'Helvetica-Bold';
    case 'italic':
    case 'oblique': return 'Helvetica-Oblique';
    case 'bold_italic': return 'Helvetica-BoldOblique';
    case 'code':
    case 'mono': return 'Courier';
    case 'math': return 'Times-Italic';
    default: return 'Helvetica';
  }
}
