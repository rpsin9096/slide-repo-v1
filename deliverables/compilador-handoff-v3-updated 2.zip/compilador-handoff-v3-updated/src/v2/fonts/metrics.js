/**
 * FocusGate / PDF Engine V2: Pure Font Metrics Engine
 * Isomorphic, zero-dependency font metric tables and optical alignment solver.
 * Works identically in Node.js, Cloudflare Workers, and unit tests without a canvas.
 */

export const STANDARD_FONT_METRICS = {
  helvetica: {
    unitsPerEm: 1000,
    ascender: 718,
    descender: -207,
    capHeight: 718,
    xHeight: 523,
    avgCharWidth: 556,
  },
  'helvetica-bold': {
    unitsPerEm: 1000,
    ascender: 718,
    descender: -207,
    capHeight: 718,
    xHeight: 532,
    avgCharWidth: 600,
  },
  times: {
    unitsPerEm: 1000,
    ascender: 683,
    descender: -217,
    capHeight: 662,
    xHeight: 450,
    avgCharWidth: 500,
  },
  courier: {
    unitsPerEm: 1000,
    ascender: 629,
    descender: -157,
    capHeight: 562,
    xHeight: 426,
    avgCharWidth: 600,
  },
  arimo: {
    unitsPerEm: 2048,
    ascender: 1854,
    descender: -434,
    capHeight: 1409,
    xHeight: 1082,
    avgCharWidth: 1138,
  },
  'arimo-bold': {
    unitsPerEm: 2048,
    ascender: 1854,
    descender: -434,
    capHeight: 1409,
    xHeight: 1082,
    avgCharWidth: 1138,
  },
  inter: {
    unitsPerEm: 2048,
    ascender: 1984,
    descender: -494,
    capHeight: 1490,
    xHeight: 1118,
    avgCharWidth: 1100,
  },
  'inter-bold': {
    unitsPerEm: 2048,
    ascender: 1984,
    descender: -494,
    capHeight: 1490,
    xHeight: 1118,
    avgCharWidth: 1100,
  },
};

const FONT_METRIC_ALIASES = {
  v2sans: 'arimo',
  v2sansbold: 'arimo-bold',
  v2sansoblique: 'arimo',
  v2sansboldoblique: 'arimo-bold',
  appsans: 'arimo',
  appsansbold: 'arimo-bold',
  v2modern: 'inter',
  v2modernbold: 'inter-bold',
  v2modernitalic: 'inter',
  v2modernbolditalic: 'inter-bold',
  appmodern: 'inter',
  appmodernsemibold: 'inter-bold',
};

// Standard character widths for Helvetica at 1000 units per em
const HELVETICA_CHAR_WIDTHS = {
  ' ': 278, '!': 278, '"': 355, '#': 556, '$': 556, '%': 889, '&': 667, '\'': 191,
  '(': 333, ')': 333, '*': 389, '+': 584, ',': 278, '-': 333, '.': 278, '/': 278,
  '0': 556, '1': 556, '2': 556, '3': 556, '4': 556, '5': 556, '6': 556, '7': 556,
  '8': 556, '9': 556, ':': 278, ';': 278, '<': 584, '=': 584, '>': 584, '?': 556,
  '@': 1015, 'A': 667, 'B': 667, 'C': 722, 'D': 722, 'E': 667, 'F': 611, 'G': 778,
  'H': 722, 'I': 278, 'J': 500, 'K': 667, 'L': 556, 'M': 833, 'N': 722, 'O': 778,
  'P': 667, 'Q': 778, 'R': 722, 'S': 667, 'T': 611, 'U': 722, 'V': 667, 'W': 944,
  'X': 667, 'Y': 667, 'Z': 611, '[': 278, '\\': 278, ']': 278, '^': 469, '_': 556,
  '`': 222, 'a': 556, 'b': 556, 'c': 500, 'd': 556, 'e': 556, 'f': 278, 'g': 556,
  'h': 556, 'i': 222, 'j': 222, 'k': 500, 'l': 222, 'm': 833, 'n': 556, 'o': 556,
  'p': 556, 'q': 556, 'r': 333, 's': 500, 't': 278, 'u': 556, 'v': 500, 'w': 722,
  'x': 500, 'y': 500, 'z': 500, '{': 334, '|': 260, '}': 334, '~': 584,
  '•': 350, '–': 556, '—': 1000, '“': 500, '”': 500, '‘': 250, '’': 250,
};

// Pre-computed Uint16Array lookup table for O(1) charCodeAt width accumulation
// with zero per-character string allocation.
const HELVETICA_ASCII_LUT = (() => {
  const lut = new Uint16Array(128);
  lut.fill(556);
  for (let cp = 0; cp < 128; cp++) {
    const ch = String.fromCharCode(cp);
    if (HELVETICA_CHAR_WIDTHS[ch] !== undefined) {
      lut[cp] = HELVETICA_CHAR_WIDTHS[ch];
    }
  }
  return lut;
})();

const FONT_METRICS_CACHE = new Map();

/**
 * Resolves font metrics either from pure tables or live PDFKit doc if present.
 * @param {string|object} fontOrDoc
 * @param {number} fontSize
 * @returns {object} Calculated font metrics
 */
export function getFontMetrics(fontOrDoc, fontSize = 10) {
  if (typeof fontOrDoc === 'string') {
    const cacheKey = `${fontOrDoc}\0${fontSize}`;
    const hit = FONT_METRICS_CACHE.get(cacheKey);
    if (hit !== undefined) return hit;

    const rawKey = fontOrDoc.toLowerCase();
    const key = FONT_METRIC_ALIASES[rawKey] || rawKey;
    const match = STANDARD_FONT_METRICS[key] || STANDARD_FONT_METRICS.helvetica;
    const unitsPerEm = match.unitsPerEm;
    const ascender = match.ascender;
    const descender = match.descender;
    const capHeight = match.capHeight;
    const xHeight = match.xHeight;

    const baselineOffset = (ascender / unitsPerEm) * fontSize;
    const descenderDepth = (Math.abs(descender) / unitsPerEm) * fontSize;
    const capHeightPt = (capHeight / unitsPerEm) * fontSize;
    const xHeightPt = (xHeight / unitsPerEm) * fontSize;
    const capCenterOffset = baselineOffset - (capHeightPt / 2);
    const xHeightCenterOffset = baselineOffset - (xHeightPt / 2);

    const res = Object.freeze({
      unitsPerEm,
      ascender,
      descender,
      capHeight,
      xHeight,
      baselineOffset,
      descenderDepth,
      capHeightPt,
      xHeightPt,
      capCenterOffset,
      xHeightCenterOffset,
    });
    if (FONT_METRICS_CACHE.size < 512) {
      FONT_METRICS_CACHE.set(cacheKey, res);
    }
    return res;
  }

  let unitsPerEm = 1000;
  let ascender = 718;
  let descender = -207;
  let capHeight = 718;
  let xHeight = 523;

  if (fontOrDoc && typeof fontOrDoc === 'object') {
    const f = fontOrDoc._font;
    if (f) {
      unitsPerEm = (f.font && f.font.unitsPerEm) || 1000;
      ascender = (f.font && f.font.ascent !== undefined) ? f.font.ascent : (f.ascender || 718);
      capHeight = (f.font && f.font.capHeight !== undefined) ? f.font.capHeight : (f.capHeight || ascender);
      xHeight = (f.font && f.font.xHeight !== undefined) ? f.font.xHeight : (f.xHeight || ascender * 0.7);
      descender = (f.font && f.font.descent !== undefined) ? f.font.descent : (f.descender || -207);
    }
  }

  const baselineOffset = (ascender / unitsPerEm) * fontSize;
  const descenderDepth = (Math.abs(descender) / unitsPerEm) * fontSize;
  const capHeightPt = (capHeight / unitsPerEm) * fontSize;
  const xHeightPt = (xHeight / unitsPerEm) * fontSize;
  const capCenterOffset = baselineOffset - (capHeightPt / 2);
  const xHeightCenterOffset = baselineOffset - (xHeightPt / 2);

  return {
    unitsPerEm,
    ascender,
    descender,
    capHeight,
    xHeight,
    baselineOffset,
    descenderDepth,
    capHeightPt,
    xHeightPt,
    capCenterOffset,
    xHeightCenterOffset,
  };
}

/**
 * Converts a baseline coordinate (in integer millipoints) to the PDFKit top-anchor
 * y coordinate (in millipoints) using exact font ascender metrics.
 *
 * @param {number} baselineMpt
 * @param {string|object} [fontOrDoc='arimo']
 * @param {number} [fontSizePt=9.5]
 * @returns {number} yTopMpt (integer millipoints)
 */
export function lineTopFromBaselineMpt(baselineMpt, fontOrDoc = 'arimo', fontSizePt = 9.5) {
  const m = getFontMetrics(fontOrDoc, fontSizePt);
  return Math.round(baselineMpt - m.baselineOffset * 1000);
}

/**
 * Inverse of lineTopFromBaselineMpt: converts a PDFKit top-anchor y coordinate
 * (in millipoints) to its baseline coordinate (in millipoints).
 *
 * @param {number} yTopMpt
 * @param {string|object} [fontOrDoc='arimo']
 * @param {number} [fontSizePt=9.5]
 * @returns {number} baselineMpt (integer millipoints)
 */
export function baselineFromLineTopMpt(yTopMpt, fontOrDoc = 'arimo', fontSizePt = 9.5) {
  const m = getFontMetrics(fontOrDoc, fontSizePt);
  return Math.round(yTopMpt + m.baselineOffset * 1000);
}

/**
 * Computes optical ink extent around a baseline in integer millipoints.
 * Used for header/footer optical anchoring (VG-8) and maxdepth checks (VG-4).
 *
 * @param {string} text
 * @param {string|object} [fontOrDoc='arimo']
 * @param {number} [fontSizePt=8.0]
 * @param {number} [baselineMpt=0]
 * @returns {{ inkTopMpt: number, inkBottomMpt: number, capTopMpt: number, xTopMpt: number, baselineMpt: number, hasDescender: boolean }}
 */
export function inkExtentOfText(text = '', fontOrDoc = 'arimo', fontSizePt = 8.0, baselineMpt = 0) {
  const m = getFontMetrics(fontOrDoc, fontSizePt);
  const s = String(text || '');
  const hasDescender = /[gjpqyQ(),;_çÇ]/u.test(s);
  const hasCapOrAscender = /[A-Z0-9bdfhijkltÁÉÍÓÚÂÊÔÃÕÇ!?"'()[\]{}/\\|]/u.test(s);
  const capTopMpt = Math.round(baselineMpt - m.capHeightPt * 1000);
  const xTopMpt = Math.round(baselineMpt - m.xHeightPt * 1000);
  const inkTopMpt = hasCapOrAscender ? capTopMpt : xTopMpt;
  const inkBottomMpt = hasDescender
    ? Math.round(baselineMpt + m.descenderDepth * 1000)
    : baselineMpt;
  return {
    inkTopMpt,
    inkBottomMpt,
    capTopMpt,
    xTopMpt,
    baselineMpt,
    hasDescender,
  };
}

/**
 * Pure mathematical string width calculation using AFM metric tables.
 * Uses pre-computed Uint16Array ASCII LUT with zero string allocation.
 * @param {string} text
 * @param {string} [fontName='helvetica']
 * @param {number} [fontSize=10]
 * @returns {number} Width in points (pt)
 */
export function calculateStringWidth(text, fontName = 'helvetica', fontSize = 10) {
  if (!text) return 0;
  const lut = HELVETICA_ASCII_LUT;
  let units = 0;
  const len = text.length;

  for (let i = 0; i < len; i++) {
    const code = text.charCodeAt(i);
    if (code < 128) {
      units += lut[code];
    } else if (code === 8226) { // •
      units += 350;
    } else if (code === 8212) { // —
      units += 1000;
    } else if (code === 8220 || code === 8221) { // “ ”
      units += 500;
    } else if (code === 8216 || code === 8217) { // ‘ ’
      units += 250;
    } else {
      units += 556;
    }
  }

  return (units / 1000) * fontSize;
}
