/**
 * FocusGate / PDF Engine V2: Emoji Fallback Segmentation
 *
 * Pure, isomorphic, zero-dependency splitter that routes emoji runs to the
 * vendored monochrome fallback face (Noto Emoji) while body text stays on
 * the production faces (Arimo / Inter). Neither production face ships emoji
 * pictographs, so without this seam PDFKit embeds `.notdef` and the glyph
 * silently vanishes from the compiled PDF.
 *
 * Conservative by construction: every code point the production faces
 * already render (probed 2026-09-24 via fontTools cmap dump over Arimo +
 * Inter) stays on the base font, so metrics and layout are byte-identical
 * for non-emoji documents. Only code points missing from BOTH faces route
 * to the fallback.
 */

// Vendored fallback face (assets/fonts, Google Fonts OFL).
export const EMOJI_FONT_FILE = 'NotoEmoji-Regular.ttf';
// Registration alias in the PDFKit driver (see blaster registerV2Fonts).
export const EMOJI_FONT_ALIAS = 'V2Emoji';

// Union of U+2600–U+26FF code points covered by Arimo-Regular or
// Inter-Regular. These keep rendering on the base font (current metrics).
const BASE_COVERED = new Set([
  0x2600, 0x2605, 0x2606,
  0x263a, 0x263b, 0x263c,
  0x2640, 0x2642,
  0x2660, 0x2661, 0x2663, 0x2665, 0x2666, 0x266a, 0x266b, 0x266f,
  0x26a0,
]);

// Fast pre-check (hot word-measure path): may over-match base-covered
// symbols; splitEmojiSegments / isEmojiCodePoint refine.
const EMOJI_PROBE_RE = /[🀀-🫿☀-⛿✀-➿⬀-⯿‍️⃣]/u;

/**
 * True when the code point must render on the emoji fallback face
 * (missing from both production body faces).
 * @param {number} cp Unicode code point
 * @returns {boolean}
 */
export function isEmojiCodePoint(cp) {
  if (BASE_COVERED.has(cp)) return false;
  // Emoticons / pictographs / transport / regional indicators / modifiers.
  if (cp >= 0x1f000 && cp <= 0x1faff) return true;
  // Misc symbols (minus base-covered above), dingbats and supplemental
  // symbols: Arimo covers 0/192 dingbats and 0/256 supplementals, and the
  // remaining misc symbols are absent from both faces.
  if (cp >= 0x2600 && cp <= 0x26ff) return true;
  if (cp >= 0x2700 && cp <= 0x27bf) return true;
  if (cp >= 0x2b00 && cp <= 0x2bff) return true;
  // Format glue inside emoji sequences (ZWJ joins, VS16 selects emoji
  // presentation, U+20E3 closes keycaps). Zero-width on their own; the
  // fallback face ships them so multi-code-point sequences stay together.
  return cp === 0x200d || cp === 0xfe0f || cp === 0x20e3;
}

/**
 * Fast predicate for the measure hot path.
 * @param {string} text
 * @returns {boolean}
 */
export function hasEmojiCandidate(text) {
  return typeof text === 'string' && text.length > 0 && EMOJI_PROBE_RE.test(text);
}

const KEYCAP_BASE_RE = /^[0-9#*]$/;

/**
 * Splits text into `{ text, emoji }` runs. Multi-code-point sequences
 * (ZWJ families, skin-tone modifiers, flag pairs, keycaps like `1️⃣`)
 * stay in a single emoji run so the fallback face shapes them together.
 * Pure: no I/O, no font access.
 * @param {string} text
 * @returns {{ text: string, emoji: boolean }[]}
 */
export function splitEmojiSegments(text) {
  const src = String(text ?? '');
  if (!src) return [];
  if (!hasEmojiCandidate(src)) return [{ text: src, emoji: false }];
  const chars = Array.from(src);
  const marks = chars.map((ch) => isEmojiCodePoint(ch.codePointAt(0) || 0));
  // Keycap bases (`0-9`, `#`, `*`) are text chars on their own but part of
  // the emoji run when a U+20E3 keycap follows within two code points.
  for (let i = 0; i < chars.length; i++) {
    if (marks[i] || !KEYCAP_BASE_RE.test(chars[i])) continue;
    for (let j = i + 1; j <= i + 2 && j < chars.length; j++) {
      if ((chars[j].codePointAt(0) || 0) === 0x20e3) {
        marks[i] = true;
        break;
      }
    }
  }
  const out = [];
  let cur = null;
  for (let i = 0; i < chars.length; i++) {
    if (!cur || cur.emoji !== marks[i]) {
      cur = { text: chars[i], emoji: marks[i] };
      out.push(cur);
    } else {
      cur.text += chars[i];
    }
  }
  return out;
}
