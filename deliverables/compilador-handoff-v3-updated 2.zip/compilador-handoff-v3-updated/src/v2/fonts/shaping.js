/**
 * FocusGate / PDF Engine V2: Headless Text Shaping Service
 * Measures glyph advances, applies kerning pairs and OpenType ligatures entirely outside
 * of any rendering driver. Zero PDFKit document allocation. Isomorphic and pure.
 */

import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { FONT_CATALOG, UNSUPPORTED_FALLBACK, glyphNameFor, UNICODE_TO_NAME } from './catalog.js';

let fontkit = null;
try {
  if (typeof createRequire === 'function') {
    const metaUrl = (typeof import.meta !== 'undefined' && import.meta.url) ? import.meta.url : 'file:///virtual/shaping.js';
    fontkit = createRequire(metaUrl)('fontkit');
  }
} catch {
  fontkit = null;
}

let AFM_DATA = null;
try {
  const afmModule = await import('../../afm-data.js');
  AFM_DATA = afmModule.AFM_DATA || null;
} catch {
  AFM_DATA = null;
}

const fontCache = new Map();
const shapeCache = new Map();
// Bounded isolate-level shape cache: expanded to 16,384 entries so full-corpus
// and multi-section compilations never thrash mid-document while staying under
// ~1.5 MB inside Cloudflare Workers' 128 MB isolate limit.
const MAX_CACHE_SIZE = 16384;
const MAX_CACHED_TEXT_LEN = 128;

function shapeCacheTrim() {
  if (shapeCache.size < MAX_CACHE_SIZE) return;
  const it = shapeCache.keys();
  for (let i = 0; i < 4096; i++) {
    const k = it.next().value;
    if (k === undefined) break;
    shapeCache.delete(k);
  }
}

export function attachFkFontLayoutCache(fkFont) {
  if (!fkFont || fkFont._hasLayoutCache || typeof fkFont.layout !== 'function') return fkFont;
  const origLayout = fkFont.layout.bind(fkFont);
  const cache = new Map();
  const MAX_FK_LAYOUT = 16384;
  // PDFKit's EmbeddedFont.layoutRun normalizes positions IN PLACE
  // (position[key] *= scale, then sets advanceWidth). A cached run handed to a
  // second document would be scaled again, corrupting advances (~-0.3em per
  // glyph). Never expose the cached object: return a per-call copy so callers
  // can mutate freely. See tests/lean/shaping-layout-cache.lean.js.
  const cloneRun = (run) => {
    // Object.create keeps fontkit's prototype getters (advanceWidth,
    // advanceHeight, bbox); a spread would silently drop them and yield NaN
    // line widths.
    const copy = Object.create(Object.getPrototypeOf(run));
    Object.assign(copy, run);
    copy.positions = run.positions.map((p) => ({ ...p }));
    return copy;
  };
  fkFont.layout = function cachedFkLayout(str, features, script, language, direction) {
    if (
      features === undefined &&
      script === undefined &&
      typeof str === 'string' &&
      str.length <= MAX_CACHED_TEXT_LEN
    ) {
      let run = cache.get(str);
      if (run !== undefined) return cloneRun(run);
      run = origLayout(str);
      if (cache.size >= MAX_FK_LAYOUT) {
        const it = cache.keys();
        for (let i = 0; i < 4096; i++) {
          const k = it.next().value;
          if (k === undefined) break;
          cache.delete(k);
        }
      }
      cache.set(str, run);
      return cloneRun(run);
    }
    return origLayout(str, features, script, language, direction);
  };
  fkFont._hasLayoutCache = true;
  return fkFont;
}

const assetPathCache = new Map();

function findAssetFont(filename) {
  if (assetPathCache.has(filename)) return assetPathCache.get(filename);
  const candidates = [
    path.join(process.cwd(), 'assets', 'fonts', filename),
    path.join(path.dirname(fileURLToPath(import.meta.url)), '..', '..', '..', 'assets', 'fonts', filename),
  ];
  for (const c of candidates) {
    try {
      if (fs.existsSync(c)) {
        assetPathCache.set(filename, c);
        return c;
      }
    } catch { /* continue */ }
  }
  assetPathCache.set(filename, null);
  return null;
}

function resolveFontRecord(fontId = 'helvetica', fontAssets = null) {
  const normalizedId = (fontId || 'helvetica').toLowerCase();
  if (fontCache.has(normalizedId)) return fontCache.get(normalizedId);

  // 1. Check embedded TTF (Arimo, Inter, V2Sans, etc.)
  const ttfMap = {
    v2sans: 'Arimo-Regular.ttf',
    v2sansbold: 'Arimo-Bold.ttf',
    v2sansoblique: 'Arimo-Italic.ttf',
    v2sansboldoblique: 'Arimo-BoldItalic.ttf',
    v2modern: 'Inter-Regular.ttf',
    v2modernbold: 'Inter-Bold.ttf',
    v2modernitalic: 'Inter-Italic.ttf',
    v2modernbolditalic: 'Inter-SemiBoldItalic.ttf',
    arimo: 'Arimo-Regular.ttf',
    'arimo-bold': 'Arimo-Bold.ttf',
    'arimo-italic': 'Arimo-Italic.ttf',
    'arimo-bolditalic': 'Arimo-BoldItalic.ttf',
    inter: 'Inter-Regular.ttf',
    'inter-bold': 'Inter-Bold.ttf',
    'inter-italic': 'Inter-Italic.ttf',
    'inter-semibolditalic': 'Inter-SemiBoldItalic.ttf',
    // Emoji fallback face (monochrome Noto Emoji): selected per-run by the
    // pdfkit blaster via splitEmojiSegments, never as a body face.
    v2emoji: 'NotoEmoji-Regular.ttf',
    appemoji: 'NotoEmoji-Regular.ttf',
  };

  const ttfFile = ttfMap[normalizedId];
  if (ttfFile && fontkit) {
    let buf = null;
    if (fontAssets && typeof fontAssets.readBuffer === 'function') {
      try { buf = fontAssets.readBuffer(ttfFile); } catch { /* next */ }
    }
    const diskPath = !buf ? findAssetFont(ttfFile) : null;
    if (buf || diskPath) {
      try {
        const fkFont = attachFkFontLayoutCache(buf ? fontkit.create(buf) : fontkit.openSync(diskPath));
        const record = {
          fontId: normalizedId,
          postscriptName: fkFont.postscriptName || ttfFile,
          source: 'embedded',
          fkFont,
          metrics: {
            ascender: (fkFont.ascent || 0) * (1000 / fkFont.unitsPerEm),
            descender: (fkFont.descent || 0) * (1000 / fkFont.unitsPerEm),
            capHeight: (fkFont.capHeight || fkFont.ascent || 700) * (1000 / fkFont.unitsPerEm),
            xHeight: (fkFont.xHeight || 500) * (1000 / fkFont.unitsPerEm),
            lineGap: (fkFont.lineGap || 0) * (1000 / fkFont.unitsPerEm),
            unitsPerEm: 1000,
          },
        };
        fontCache.set(normalizedId, record);
        return record;
      } catch { /* fallback to AFM */ }
    }
  }

  const psName = FONT_CATALOG[normalizedId] || FONT_CATALOG[fontId] || fontId || 'Helvetica';
  if (fontCache.has(psName)) return fontCache.get(psName);

  // 2. Try AFM in-memory or on disk
  const afmFileName = `${psName}.afm`;
  let afmRaw = AFM_DATA ? AFM_DATA[afmFileName] : null;

  if (!afmRaw) {
    const candidates = [
      path.join(process.cwd(), 'node_modules', 'pdfkit', 'js', 'data', afmFileName),
    ];
    for (const c of candidates) {
      try {
        if (fs.existsSync(c)) {
          afmRaw = fs.readFileSync(c, 'latin1');
          break;
        }
      } catch { /* continue */ }
    }
  }

  if (afmRaw) {
    const parsed = parseAfmMetrics(psName, afmRaw);
    fontCache.set(psName, parsed);
    fontCache.set(normalizedId, parsed);
    return parsed;
  }

  // Fallback
  const fallbackRecord = createFallbackMetrics(psName);
  fontCache.set(psName, fallbackRecord);
  fontCache.set(normalizedId, fallbackRecord);
  return fallbackRecord;
}

function parseAfmMetrics(postscriptName, raw) {
  const byName = new Map();
  const byUnicode = new Map();
  const kerning = new Map();
  const metrics = {
    ascender: 718,
    descender: -207,
    capHeight: 700,
    xHeight: 500,
    lineGap: 0,
    unitsPerEm: 1000,
  };

  const lines = raw.split(/\r\n|\r|\n/);
  for (const line of lines) {
    if (line.startsWith('C ')) {
      const parts = line.split(';').map(p => p.trim());
      let code = -1;
      let width = 0;
      let name = '';
      let bbox = [0, 0, 0, 0];
      for (const part of parts) {
        if (part.startsWith('C ')) code = parseInt(part.slice(2), 10);
        else if (part.startsWith('WX ')) width = parseFloat(part.slice(3));
        else if (part.startsWith('N ')) name = part.slice(2);
        else if (part.startsWith('B ')) {
          const nums = part.slice(2).trim().split(/\s+/).map(Number);
          bbox = [nums[0] || 0, nums[1] || 0, nums[2] || 0, nums[3] || 0];
        }
      }
      if (name) {
        const metric = { code, name, width, bbox };
        byName.set(name, metric);
      }
    } else if (line.startsWith('KPX ')) {
      const [, left, right, value] = line.split(/\s+/);
      if (left && right && value !== undefined) {
        kerning.set(`${left}\u0000${right}`, parseFloat(value));
      }
    } else if (line.startsWith('Ascender ')) metrics.ascender = parseFloat(line.slice(9));
    else if (line.startsWith('Descender ')) metrics.descender = parseFloat(line.slice(10));
    else if (line.startsWith('CapHeight ')) metrics.capHeight = parseFloat(line.slice(10));
    else if (line.startsWith('XHeight ')) metrics.xHeight = parseFloat(line.slice(9));
  }

  // Populate Unicode index
  for (let cp = 32; cp <= 126; cp++) {
    const name = glyphNameFor(cp);
    const metric = byName.get(name);
    if (metric) byUnicode.set(cp, metric);
  }
  for (const [key, name] of Object.entries(UNICODE_TO_NAME)) {
    const cp = Number(key);
    const metric = byName.get(name);
    if (metric) byUnicode.set(cp, metric);
  }

  const ligatures = new Map();
  if (byName.has('fi')) ligatures.set('fi', 'fi');
  if (byName.has('fl')) ligatures.set('fl', 'fl');
  if (byName.has('ffi')) ligatures.set('ffi', 'ffi');
  if (byName.has('ffl')) ligatures.set('ffl', 'ffl');

  return {
    postscriptName,
    source: 'standard',
    metrics,
    byName,
    byUnicode,
    kerning,
    ligatures,
  };
}

function createFallbackMetrics(postscriptName) {
  const isBold = /bold/i.test(postscriptName);
  const isMono = /courier/i.test(postscriptName);
  const avgWidth = isMono ? 600 : (isBold ? 600 : 556);
  const byName = new Map();
  const byUnicode = new Map();

  return {
    postscriptName,
    source: 'standard',
    metrics: {
      ascender: 718,
      descender: -207,
      capHeight: 700,
      xHeight: 500,
      lineGap: 0,
      unitsPerEm: 1000,
    },
    byName,
    byUnicode,
    kerning: new Map(),
    ligatures: new Map(),
    fallbackAvgWidth: avgWidth,
  };
}

const HIGH_UNICODE_RE = /[^\u0000-\u02ff]/;

function transliterate(text = '') {
  const s = String(text);
  if (!HIGH_UNICODE_RE.test(s)) return s;
  let out = '';
  for (const char of s) {
    const cp = char.codePointAt(0) || 32;
    if (cp > 0x2ff && UNSUPPORTED_FALLBACK[char]) {
      out += UNSUPPORTED_FALLBACK[char];
    } else {
      out += char;
    }
  }
  return out;
}

// Non-breaking space family: unbreakable glue during layout (see
// TypographicAutofix.tieParticles + wrapRunsToLines NBSP handling) but
// space-width advances. The renderers emit a regular space GLYPH
// (blaster nbspToSpaces: fontkit CBox crash + v1 parity), so measuring
// NBSP at space width is exact by construction.
const NBSP_FAMILY = new Set([0x00a0, 0x2007, 0x202f]);
const SPACE_CP = 0x20;

// Standard-14 WinAnsi faces: shaping is kern-only. No ligature pass exists
// for AFM metrics — and none is needed: shaper+%@HookeU+0025 == live PDFKit
// widthOfString on kern pairs (AV/To/We/ffi/office) and bold, d=0.00.
const STANDARD_14 = new Set([
  'helvetica', 'helvetica-bold', 'helvetica-oblique', 'helvetica-boldoblique',
  'courier', 'courier-bold', 'courier-oblique', 'courier-boldoblique',
  'times', 'times-roman', 'times-bold', 'times-italic', 'times-bolditalic',
  'symbol', 'zapfdingbats',
]);

/**
 * Feature set for a font id (pure string algebra, no I/O).
 * Standard-14 → kern only; embedded OpenType (fontkit layout) → kern + liga.
 * @param {string} [fontId='helvetica']
 * @returns {string[]}
 */
export function featuresFor(fontId = 'helvetica') {
  const id = String(fontId || 'helvetica').toLowerCase();
  if (STANDARD_14.has(id)) return ['kern'];
  return ['kern', 'liga'];
}

export class TextShaper {
  /**
   * Headless string width measurement in points.
   * Replaces live PDFDocument.widthOfString without scratch document allocation.
   * @param {string} rawText 
   * @param {string} [fontId='helvetica'] 
   * @param {number} [fontSize=10] 
   * @param {object} [fontAssets=null]
   * @returns {number} Width in points (pt)
   */
  measure(rawText, fontId = 'helvetica', fontSize = 10, fontAssets = null) {
    if (!rawText) return 0;
    const shaped = this.shapeText(rawText, fontId, fontSize, featuresFor(fontId), fontAssets);
    return shaped.width;
  }

  /**
   * Performs glyph shaping with kerning and ligatures.
   * @param {string} rawText 
   * @param {string} fontId 
   * @param {number} fontSize 
   * @param {string[]} [features] 
   * @param {object} [fontAssets=null]
   * @returns {{ fontId: string, fontSize: number, width: number, glyphs: any[] }}
   */
  shapeText(rawText, fontId = 'helvetica', fontSize = 10, features = ['kern'], fontAssets = null) {
    // NBSP family is preserved in the returned text (layout glue) and only
    // aliased to space for WIDTH lookup (AFM has no NBSP glyph; space width
    // is exact per renderer parity). Never rewrite content to measure it.
    const text = transliterate(rawText);
    const cacheable = text.length <= MAX_CACHED_TEXT_LEN;
    const featKey = features.length === 1 ? features[0] : features.join(',');
    const cacheKey = cacheable ? `${fontId} ${fontSize} ${featKey} ${text}` : null;
    if (cacheable && shapeCache.has(cacheKey)) return shapeCache.get(cacheKey);

    const font = resolveFontRecord(fontId, fontAssets);
    const hasNbsp = text.indexOf('\u00A0') !== -1 || text.indexOf('\u2007') !== -1 || text.indexOf('\u202F') !== -1;
    const widthText = hasNbsp ? text.replace(/[\u00A0\u2007\u202F]/g, ' ') : text;

    // If fontkit embedded font is active
    if (font.source === 'embedded' && font.fkFont) {
      const run = font.fkFont.layout(widthText);
      const scale = fontSize / font.fkFont.unitsPerEm;
      let width = 0;
      const glyphs = [];
      for (const g of run.glyphs) {
        const adv = g.advanceWidth * scale;
        width += adv;
        glyphs.push({
          codePoint: g.id,
          glyphName: g.name || String(g.id),
          xAdvance: adv,
          width: adv,
        });
      }
      const result = { fontId, fontSize, text, width, glyphs };
      if (cacheable) { shapeCacheTrim(); shapeCache.set(cacheKey, result); }
      return result;
    }

    const scale = fontSize / font.metrics.unitsPerEm;
    const glyphs = [];
    let width = 0;
    let prevGlyphName = null;

    for (let i = 0; i < text.length; i++) {
      const codePoint = text.codePointAt(i) || 32;
      // NBSP family measures at space width (AFM has no NBSP glyph) while
      // the glyph record keeps the original code point (layout glue).
      const lookupCp = NBSP_FAMILY.has(codePoint) ? SPACE_CP : codePoint;
      let metric = font.byUnicode ? font.byUnicode.get(lookupCp) : null;

      if (!metric && font.byName) {
        const name = glyphNameFor(lookupCp);
        metric = font.byName.get(name);
      }

      const glyphWidth = metric ? metric.width : (font.fallbackAvgWidth || 556);
      let advance = glyphWidth * scale;

      if (features.includes('kern') && prevGlyphName && metric && font.kerning) {
        const kKey = `${prevGlyphName}\u0000${metric.name}`;
        const kernVal = font.kerning.get(kKey);
        if (kernVal) advance += kernVal * scale;
      }

      glyphs.push({
        codePoint,
        glyphName: metric ? metric.name : 'unknown',
        xAdvance: advance,
        width: advance,
      });

      width += advance;
      prevGlyphName = metric ? metric.name : null;
    }

    const result = {
      fontId,
      fontSize,
      text,
      width,
      glyphs,
    };

    if (cacheable) { shapeCacheTrim(); shapeCache.set(cacheKey, result); }
    return result;
  }

  /**
   * Returns vertical font metrics in points for a given font and size.
   */
  metricsFor(fontId = 'helvetica', fontSize = 10, fontAssets = null) {
    const font = resolveFontRecord(fontId, fontAssets);
    const scale = fontSize / font.metrics.unitsPerEm;
    return {
      ascender: font.metrics.ascender * scale,
      descender: font.metrics.descender * scale,
      capHeight: font.metrics.capHeight * scale,
      xHeight: font.metrics.xHeight * scale,
      lineGap: font.metrics.lineGap * scale,
    };
  }

  /**
   * Glyph-name optical protrusion hook (hanging punctuation).
   * @param {string} glyphChar
   * @param {string} [fontId='helvetica']
   * @param {number} [fontSize=10]
   * @param {number} [protrusionRatio=0.4]
   * @returns {number} Protrusion in points
   */
  protrusionFor(glyphChar, fontId = 'helvetica', fontSize = 10, protrusionRatio = 0.4) {
    if (!glyphChar) return 0;
    const c = String(glyphChar);
    const size = Number(fontSize) || 10;
    const ratio = protrusionRatio === undefined || protrusionRatio === null ? 0.4 : protrusionRatio;
    void fontId;
    const name = glyphNameFor(c.codePointAt(0) || 0);
    // Opening quotes/brackets on the left margin: 40% advance class.
    if (/^(quoteleft|quotedblleft|guillemotleft|guilsinglleft|parenleft|bracketleft|braceleft)$/.test(name)
      || /^["'([{‘“]/.test(c)) {
      return size * 0.3 * ratio;
    }
    // Hyphens/dashes on the right margin: up to 50% protrusion.
    if (/^(hyphen|endash|emdash)$/.test(name) || c === '-' || c === '–' || c === '—') {
      return size * 0.35 * (ratio * 1.25);
    }
    // Closing quotes + trailing punctuation on the right: 38% class.
    if (/^(quoteright|quotedblright|guillemotright|guilsinglright|parenright|bracketright|braceright|period|comma|colon|semicolon|exclam|question|percent)$/.test(name)
      || /^[.,:;!?"')\]}’”%]/.test(c)) {
      return size * 0.28 * ratio;
    }
    return 0;
  }
}

export const shaper = new TextShaper();
