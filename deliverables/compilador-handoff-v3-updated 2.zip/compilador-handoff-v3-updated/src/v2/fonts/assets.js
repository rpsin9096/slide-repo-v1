/**
 * FocusGate / PDF Engine V2: FontsPort — injectable font-asset provider.
 *
 * Library code must never touch the filesystem directly for fonts: Node
 * resolves TTF paths from disk while Cloudflare Workers (no disk) serve
 * base64-inlined buffers. Both adapters expose the same two methods:
 *   resolvePath(file) -> absolute path | null   (disk runtimes)
 *   readBuffer(file)  -> Buffer | null          (embedded runtimes)
 * Consumers try readBuffer first, then resolvePath, so behavior on Node
 * without a port is byte-identical to before.
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

/**
 * Node adapter: resolves vendored TTFs from the repo checkout (then CWD).
 * @param {{ roots?: string[] }} [opts={}]
 */
export function createNodeFontAssets({ roots } = {}) {
  const here = path.dirname(fileURLToPath(import.meta.url));
  const searchRoots = Array.isArray(roots) && roots.length > 0
    ? roots
    : [
        path.join(here, '..', '..', '..', 'assets', 'fonts'),
        path.join(process.cwd(), 'assets', 'fonts'),
      ];
  return {
    type: 'node',
    resolvePath(file) {
      for (const root of searchRoots) {
        try {
          const p = path.join(root, file);
          if (fs.existsSync(p)) return p;
        } catch { /* next root */ }
      }
      return null;
    },
    readBuffer() {
      return null;
    },
  };
}

/**
 * Embedded adapter: serves base64-inlined TTFs (Cloudflare Workers).
 * Buffers are decoded lazily once and cached per worker isolate.
 * @param {Record<string, string>} [base64Map={}] file -> base64 TTF
 */
export function createEmbeddedFontAssets(base64Map = {}) {
  const cache = new Map();
  return {
    type: 'embedded',
    resolvePath() {
      return null;
    },
    readBuffer(file) {
      const b64 = base64Map[file];
      if (!b64) return null;
      if (!cache.has(file)) {
        const buf = Buffer.from(b64, 'base64');
        buf._fontFile = file;
        cache.set(file, buf);
      }
      return cache.get(file);
    },
  };
}
