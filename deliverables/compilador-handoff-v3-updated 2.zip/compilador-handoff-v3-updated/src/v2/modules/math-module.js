/**
 * FocusGate / PDF Engine V2: Math Subsystem Module
 * Decoupled wrapper for LaTeX display math parsing and bounding box formatting.
 */

import { TypographicAutofix } from '../ingest/sanitizer.js';

export class MathParser {
  /**
   * Parse a display math block or raw LaTeX formula
   * @param {string} raw - The raw text (e.g. "$$ E = mc^2 $$")
   * @param {Object} options - Parser options ({ splitEquations: boolean })
   * @returns {{ isBlock: boolean, formula: string, lines: string[] }}
   */
  static parse(raw = '', options = {}) {
    // Defensive coercion: callers may pass an AST mathBlock node ({ latex })
    // instead of a raw string; extract or stringify rather than throwing
    // on `.trim is not a function`.
    if (raw && typeof raw === 'object') raw = raw.latex ?? raw.formula ?? '';
    let text = String(raw ?? '').trim();
    const isBlock = text.startsWith('$$') && text.endsWith('$$');

    if (isBlock) {
      text = text.slice(2, -2).trim();
    }

    const split = options.splitEquations !== false;
    const lines = split
      ? text.split(/\\\\|\n/).map(l => l.trim()).filter(Boolean)
      : [text].filter(Boolean);

    return {
      isBlock,
      formula: text,
      lines: lines.length > 0 ? lines : [''],
    };
  }
}

export class MathLayoutBox {
  /**
   * Measure vertical height requirements and layout bounding box for a formula
   */
  static measure(formula, colW, tmpl = {}, options = {}) {
    const parsed = MathParser.parse(formula, options);
    const fontSize = (tmpl.tokens && tmpl.tokens.mathFontSize) || (tmpl.fontSize === 8 ? 9.5 : 10);
    const hasComplexNotation = parsed.lines.some(l => /[\^_\\/]/.test(l) || /[⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻₀₁₂₃₄₅₆₇₈₉₊₋∑∫∏√]/.test(l));
    const lineHeight = fontSize + (hasComplexNotation ? 5 : 3.5);
    const paddingV = hasComplexNotation ? 6.5 : 5.5;
    const boxH = Math.ceil(parsed.lines.length * lineHeight + paddingV * 2);
    const totalH = boxH + 4;

    return {
      height: totalH,
      boxHeight: boxH,
      paddingV,
      width: colW,
      lineCount: parsed.lines.length,
      lines: parsed.lines,
      fontSize,
      lineHeight,
      keepWithNext: 0,
      fullWidth: false,
    };
  }

  /**
   * Render display math box into PDFKit document
   */
  static render(formula, mgr, tmpl, options = {}) {
    const doc = mgr.doc;
    const colW = mgr.availableWidth;
    const metrics = MathLayoutBox.measure(formula, colW, tmpl, options);

    mgr.ensureSpace(metrics.height + 2);
    const startY = doc.y;

    doc.save();

    const bg = tmpl.colors?.surface || '#FAFAFA';
    const border = tmpl.colors?.bordercolor || '#E4E4E7';
    doc.rect(mgr.currentX, startY, colW, metrics.boxHeight)
       .fillAndStroke(bg, border);

    doc.rect(mgr.currentX, startY, 2, metrics.boxHeight)
       .fill(tmpl.colors?.accent || '#000000');

    doc.font(mgr.getFont('math'))
       .fontSize(metrics.fontSize)
       .fillColor(tmpl.colors?.ruleblack || tmpl.colors?.textmain || '#000000');

    metrics.lines.forEach((line, idx) => {
      const fixed = TypographicAutofix.apply(line, mgr.hasCustomFonts);
      doc.text(fixed, mgr.currentX + 8, startY + (metrics.paddingV || 6) + (idx * metrics.lineHeight), {
        width: colW - 16,
        align: 'center',
        lineBreak: false,
      });
    });

    doc.restore();
    doc.y = startY + metrics.boxHeight + 4;
    mgr.markProgress();

    return metrics;
  }
}

const SUPER_UNICODE_MAP = {
  '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴',
  '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹',
  '+': '⁺', '-': '⁻', '=': '⁼', '(': '⁽', ')': '⁾',
  a: 'ᵃ', b: 'ᵇ', c: 'ᶜ', d: 'ᵈ', e: 'ᵉ', f: 'ᶠ', g: 'ᵍ', h: 'ʰ',
  i: 'ⁱ', j: 'ʲ', k: 'ᵏ', l: 'ˡ', m: 'ᵐ', n: 'ⁿ', o: 'ᵒ', p: 'ᵖ',
  r: 'ʳ', s: 'ˢ', t: 'ᵗ', u: 'ᵘ', v: 'ᵛ', w: 'ʷ', x: 'ˣ', y: 'ʸ', z: 'ᶻ',
  A: 'ᴬ', B: 'ᴮ', D: 'ᴰ', E: 'ᴱ', G: 'ᴳ', H: 'ᴴ', I: 'ᴵ', J: 'ᴶ',
  K: 'ᴷ', L: 'ᴸ', M: 'ᴹ', N: 'ᴺ', O: 'ᴼ', P: 'ᴾ', R: 'ᴿ', T: 'ᵀ',
  U: 'ᵁ', V: 'ⱽ', W: 'ᵂ',
};

const SUB_UNICODE_MAP = {
  '0': '₀', '1': '₁', '2': '₂', '3': '₃', '4': '₄',
  '5': '₅', '6': '₆', '7': '₇', '8': '₈', '9': '₉',
  '+': '₊', '-': '₋', '(': '₍', ')': '₎',
  a: 'ₐ', e: 'ₑ', h: 'ₕ', i: 'ᵢ', j: 'ⱼ', k: 'ₖ', l: 'ₗ',
  m: 'ₘ', n: 'ₙ', o: 'ₒ', p: 'ₚ', r: 'ᵣ', s: 'ₛ', t: 'ₜ',
  u: 'ᵤ', v: 'ᵥ', x: 'ₓ',
};

// Balanced-brace reader: s[i] must open with `{`; returns the inner body
// and the offset past the matching `}`, or null when unbalanced.
function readBraceGroup(s, i) {
  if (s[i] !== '{') return null;
  let depth = 0;
  for (let j = i; j < s.length; j++) {
    if (s[j] === '{') depth++;
    else if (s[j] === '}') {
      depth--;
      if (depth === 0) return { body: s.slice(i + 1, j), end: j + 1 };
    }
  }
  return null;
}

/**
 * Expands `\frac{A}{B}` → `(A')/(B')` with balanced braces, so nested
 * content (`\frac{\text{A}}{\text{B}}`, `\frac{\frac{a}{b}}{c}`) expands
 * inside-out. convertInner maps each argument (recursive convertSymbols).
 * Malformed occurrences are left for the legacy regex rules.
 */
function expandFrac(text, convertInner) {
  let out = String(text ?? '');
  let idx = out.indexOf('\\frac{');
  while (idx >= 0) {
    const a = readBraceGroup(out, idx + 5);
    const b = a ? readBraceGroup(out, a.end) : null;
    if (!a || !b) {
      idx = out.indexOf('\\frac{', idx + 1);
      continue;
    }
    out = out.slice(0, idx)
      + '(' + convertInner(a.body) + ')/(' + convertInner(b.body) + ')'
      + out.slice(b.end);
    idx = out.indexOf('\\frac{', idx + 1);
  }
  return out;
}

// Symbol macros valid inside inline math (subset of TEX_SYMBOL_MAP plus
// structural unwrappers). Ordered: multi-char forms before prefixes.
// Escapes + environments first: `\%` is literal, `\begin`/`\end` strip
// before the brace rules below would eat their braces.
const INLINE_MATH_SYMBOL_RULES = [
  [/\\%/g, '%'],
  [/\\begin\{[^}]*\}/g, ''], [/\\end\{[^}]*\}/g, ''],
  [/\\frac\{([^}]*)\}\{([^}]*)\}/g, '($1)/($2)'],
  [/\\sqrt\{([^}]*)\}/g, '√($1)'],
  [/\\sqrt\b/g, '√'],
  [/\\text\{([^}]*)\}/g, '$1'],
  [/\\mathbf\{([^}]*)\}/g, '$1'],
  [/\\mathit\{([^}]*)\}/g, '$1'],
  [/\\mathrm\{([^}]*)\}/g, '$1'],
  [/\\texttt\{([^}]*)\}/g, '$1'],
  [/\\left\(/g, '('], [/\\right\)/g, ')'],
  [/\\left\[/g, '['], [/\\right\]/g, ']'],
  [/\\left\\\{/g, '{'], [/\\right\\\}/g, '}'],
  [/\\left\./g, ''], [/\\right\./g, ''],
  [/\\alpha\b/g, 'α'], [/\\beta\b/g, 'β'], [/\\gamma\b/g, 'γ'], [/\\delta\b/g, 'δ'],
  [/\\epsilon\b/g, 'ε'], [/\\varepsilon\b/g, 'ε'], [/\\zeta\b/g, 'ζ'], [/\\eta\b/g, 'η'],
  [/\\theta\b/g, 'θ'], [/\\vartheta\b/g, 'θ'], [/\\iota\b/g, 'ι'], [/\\kappa\b/g, 'κ'],
  [/\\lambda\b/g, 'λ'], [/\\mu\b/g, 'µ'], [/\\nu\b/g, 'ν'], [/\\xi\b/g, 'ξ'],
  [/\\pi\b/g, 'π'], [/\\rho\b/g, 'ρ'], [/\\sigma\b/g, 'σ'], [/\\tau\b/g, 'τ'],
  [/\\upsilon\b/g, 'υ'], [/\\phi\b/g, 'φ'], [/\\varphi\b/g, 'φ'], [/\\chi\b/g, 'χ'],
  [/\\psi\b/g, 'ψ'], [/\\omega\b/g, 'ω'],
  [/\\Gamma\b/g, 'Γ'], [/\\Delta\b/g, 'Δ'], [/\\Theta\b/g, 'Θ'], [/\\Lambda\b/g, 'Λ'],
  [/\\Xi\b/g, 'Ξ'], [/\\Pi\b/g, 'Π'], [/\\Sigma\b/g, 'Σ'], [/\\Upsilon\b/g, 'Υ'],
  [/\\Phi\b/g, 'Φ'], [/\\Psi\b/g, 'Ψ'], [/\\Omega\b/g, 'Ω'],
  [/\\Rightarrow\b/g, '⇒'], [/\\rightarrow\b/g, '→'], [/\\to\b/g, '→'],
  [/\\Leftarrow\b/g, '⇐'], [/\\leftarrow\b/g, '←'],
  [/\\Leftrightarrow\b/g, '⇔'], [/\\leftrightarrow\b/g, '↔'],
  [/\\uparrow\b/g, '↑'], [/\\downarrow\b/g, '↓'],
  [/==>/g, '⇒'], [/=>/g, '⇒'], [/-->/g, '→'], [/->/g, '→'],
  [/<==/g, '⇐'], [/<--/g, '←'], [/<->/g, '↔'], [/<=>/g, '⇔'],
  [/\\pm\b/g, '±'], [/\\mp\b/g, '∓'], [/\\times\b/g, '×'], [/\\div\b/g, '÷'],
  [/\\cdot\b/g, '·'], [/\\leq\b/g, '≤'], [/\\le\b/g, '≤'], [/\\geq\b/g, '≥'],
  [/\\ge\b/g, '≥'], [/\\neq\b/g, '≠'], [/\\approx\b/g, '≈'], [/\\equiv\b/g, '≡'],
  [/\\infty\b/g, '∞'], [/\\partial\b/g, '∂'], [/\\sum\b/g, '∑'], [/\\prod\b/g, '∏'],
  [/\\int\b/g, '∫'], [/\\in\b/g, '∈'], [/\\notin\b/g, '∉'],
  [/\\quad\b/g, '  '], [/\\qquad\b/g, '    '], [/\\,/g, ' '], [/\\;/g, '  '],
  [/\\ /g, ' '], [/{/g, ''], [/}/g, ''],
];

/**
 * InlineMath: parses `$…$` interiors into renderable runs.
 * Symbols/macros become unicode glyphs; `_{…}/^{…}` and `_x/^x` become
 * unicode sub/superscripts where glyphs exist, else 0.72× styled runs.
 * Guarantees: no `$`, backslash-macros, `^{` or `}_` literals survive.
 */
export class InlineMath {
  static convertSymbols(text) {
    // Nested-capable frac first (the flat `[^}]*` rule below cannot span
    // `\text{…}` args); recursion inside converts arguments fully.
    let out = expandFrac(String(text ?? ''), (t) => InlineMath.convertSymbols(t));
    for (const [re, rep] of INLINE_MATH_SYMBOL_RULES) {
      // Fresh regex per call site would be ideal; rules hold /g flags so
      // reset lastIndex to keep repeated apply() calls deterministic.
      re.lastIndex = 0;
      out = out.replace(re, rep);
    }
    return out;
  }

  static toSuperScript(text) {
    let out = '';
    for (const ch of String(text ?? '')) {
      const mapped = SUPER_UNICODE_MAP[ch];
      if (!mapped) return null;
      out += mapped;
    }
    return out;
  }

  static toSubScript(text) {
    let out = '';
    for (const ch of String(text ?? '')) {
      const mapped = SUB_UNICODE_MAP[ch];
      if (!mapped) return null;
      out += mapped;
    }
    return out;
  }

  /**
   * Heuristic: is a `$…$` interior real math (vs currency like `US$100 and $`)?
   * True when it carries TeX markers (`\`, `^`, `_`), converts under the
   * symbol table, is a bare short token (`$x$`), or holds operators.
   */
  static looksLikeMath(inner) {
    const t = String(inner ?? '');
    if (/[\\^_]/.test(t)) return true;
    if (InlineMath.convertSymbols(t) !== t) return true;
    // Post-autofix interiors: TypographicAutofix already converted TeX into
    // unicode scripts/symbols before the `$…$` scan runs — still math.
    // Ranges: U+2070–U+208A superscripts, U+2090–U+209C subscripts,
    // U+1D2C–U+1D42 / U+1D43–U+1D65 modifier letters, Greek + symbols.
    // eslint-disable-next-line no-misleading-character-class
    if (/[⁰-₊ₐ-ₜᵃ-ᶻᴬ-ᵂ√∑∏∫∂∞∈∉±×÷·≤≥≠≈≡→⇒←⇔↑↓α-ωΓ-Ωµ]/.test(t)) return true;
    if (/^[A-Za-z0-9]{1,4}$/.test(t.trim())) return true;
    // Bracket intervals/sets (`$[CME, CMT]$`, coordinates): currency never
    // carries brackets, so they are a safe math signal.
    if (/[\[\]]/.test(t)) return true;
    if (/[=+\-*/<>≤≥≠→⇒←↔√∑∫∏∂∞±×÷·]/.test(t)) return true;
    return false;
  }

  /**
   * Expand a `$…$` interior (without the dollars) into runs.
   * @param {string} inner
   * @returns {{ text: string, style: string }[]}
   */
  static expand(inner) {
    const runs = [];
    const push = (text, style) => {
      if (!text) return;
      const last = runs[runs.length - 1];
      if (last && last.style === style) last.text += text;
      else runs.push({ text, style });
    };
    // Scripts split FIRST on the raw interior: the symbol table strips `{}`
    // (brace rules), which used to destroy `_{…}` grouping before the script
    // regex ever saw it (`$E_{\max}$` → `Eₘax`). Conversion applies per
    // segment afterwards, so macros outside AND inside bodies still convert.
    const convert = (t) => InlineMath.convertSymbols(t).replace(/\\([A-Za-z]+)/g, '$1');
    const raw = String(inner ?? '');
    const scriptRe = /(\^{([^{}]+)}|_{([^{}]+)}|\^([^\s^_{}])|_([^\s^_{}]))/g;
    let lastIdx = 0;
    let m;
    while ((m = scriptRe.exec(raw)) !== null) {
      if (m.index > lastIdx) push(convert(raw.slice(lastIdx, m.index)), 'math');
      const isSuper = m[0][0] === '^';
      const body = convert(m[2] ?? m[3] ?? m[4] ?? m[5]);
      const uni = isSuper ? InlineMath.toSuperScript(body) : InlineMath.toSubScript(body);
      if (uni !== null) push(uni, 'math');
      else push(body, isSuper ? 'math-super' : 'math-sub');
      lastIdx = scriptRe.lastIndex;
    }
    if (lastIdx < raw.length) push(convert(raw.slice(lastIdx)), 'math');
    if (runs.length === 0) runs.push({ text: '', style: 'math' });
    return runs;
  }

  /**
   * Expand all `$…$` spans in a plain string into runs.
   * Text outside spans keeps `fallbackStyle`.
   */
  static expandInText(text, fallbackStyle = 'normal') {
    const out = [];
    const src = String(text ?? '');
    const re = /\$([^$\n]+?)\$/g;
    let lastIdx = 0;
    let m;
    while ((m = re.exec(src)) !== null) {
      if (m.index > lastIdx) out.push({ text: src.slice(lastIdx, m.index), style: fallbackStyle });
      // Gate: currency pairs (`$5 and $`) stay literal with dollars kept.
      if (InlineMath.looksLikeMath(m[1])) {
        for (const r of InlineMath.expand(m[1])) out.push(r);
      } else {
        out.push({ text: m[0], style: fallbackStyle });
      }
      lastIdx = re.lastIndex;
    }
    if (lastIdx < src.length) out.push({ text: src.slice(lastIdx), style: fallbackStyle });
    return out;
  }
}

export class ModularMathEngine {
  measureFormula(rawMath, availableWidth = 260, tmpl = { id: 'base' }) {
    const parsed = MathParser.parse(rawMath);
    const metrics = MathLayoutBox.measure(rawMath, availableWidth, tmpl);

    return {
      parsed,
      metrics,
      height: metrics.height,
    };
  }
}
