/**
 * FocusGate / PDF Engine V2: Document Chrome Module
 * Declarative running header, footer vertical rhythm, and Table of Contents (TOC) metadata.
 */

export class TOCIndexBuilder {
  constructor(options = {}) {
    this.title = options.title || 'SUMÁRIO';
    this.includeHeadings = options.includeHeadings !== false;
    this.sections = [];
  }

  registerSection(sectionIndex, name, startPage, mastheadTopic = null) {
    const entry = {
      index: sectionIndex,
      name: name || `Capítulo ${sectionIndex}`,
      startPage: startPage || 1,
      dest: `chapter-${sectionIndex}`,
      masthead_topic: mastheadTopic,
      headings: [],
    };
    this.sections.push(entry);
    return entry;
  }

  addHeading(sectionIndex, text, page, dest = null) {
    const sec = this.sections.find(s => s.index === sectionIndex);
    if (!sec) return null;
    const headingEntry = {
      text: (text || '').trim(),
      page: page || sec.startPage,
      dest: dest || `heading-${sectionIndex}-${sec.headings.length + 1}`,
    };
    sec.headings.push(headingEntry);
    return headingEntry;
  }

  getStructureSummary() {
    return {
      title: this.title,
      sectionCount: this.sections.length,
      sections: this.sections.map(s => ({
        index: s.index,
        label: `${s.name}${(s.masthead_topic && s.masthead_topic !== s.name) ? ` — ${s.masthead_topic}` : ''}`,
        startPage: s.startPage,
        headingCount: s.headings.length,
      })),
    };
  }
}

export class ModularChromeEngine {
  constructor(options = {}) {
    this.tocBuilder = new TOCIndexBuilder();
    this.headerRuleClearance = options.headerRuleClearance || 4.0; // >=4pt rule clearance
    this.footerRuleGap = options.footerRuleGap || 6.0; // 6pt gap before page numbers
  }

  /**
   * Registers a section and heading for the TOC metadata index.
   * @param {string} title 
   * @param {number} pageNumber 
   */
  recordHeading(title, pageNumber) {
    this.tocBuilder.addHeading(1, title, pageNumber);
  }

  /**
   * Returns current TOC summary.
   */
  getTOCSummary() {
    return this.tocBuilder.getStructureSummary();
  }

  /**
   * Formats header string with optional date.
   * @param {string} customText 
   * @param {string|Date} [date] 
   * @param {string} [lang='pt'] 
   * @returns {string}
   */
  formatHeader(customText, date, lang = 'pt') {
    if (!customText && !date) return '';
    if (!date) return customText || '';
    return customText ? `${customText} • ${date}` : String(date);
  }
}
