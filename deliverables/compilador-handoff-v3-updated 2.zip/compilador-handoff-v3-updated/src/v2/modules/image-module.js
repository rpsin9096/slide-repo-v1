/**
 * FocusGate / PDF Engine V2: Image Subsystem Module
 * Secure image source resolver (anti-traversal, SSRF protected)
 * and aspect-ratio preserving bounding box calculator.
 */

import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import https from 'node:https';

/**
 * Checks if a hostname or IP is private or loopback (SSRF guard).
 * Normalizes obfuscated IPv4 forms (decimal/octal/hex, e.g. 2130706433
 * or 0x7f000001 for 127.0.0.1) before range checks so blocklists cannot
 * be bypassed textually.
 */
export function isPrivateHost(hostname) {
  if (!hostname) return true;
  let h = hostname.toLowerCase().trim();
  // Strip IPv6 brackets and zone ids: [::1], [fe80::1%eth0].
  if (h.startsWith('[') && h.endsWith(']')) h = h.slice(1, -1);
  h = h.split('%')[0];
  if (h === 'localhost' || h === '::1' || h === '0.0.0.0') return true;
  const asIpv4 = parseIpv4Variant(h);
  if (asIpv4 !== null) h = asIpv4;
  if (/^127\./.test(h)) return true;
  if (/^10\./.test(h)) return true;
  if (/^192\.168\./.test(h)) return true;
  if (/^169\.254\./.test(h)) return true;
  if (/^172\.(1[6-9]|2[0-9]|3[0-1])\./.test(h)) return true;
  if (/^0\.0\.0\.0$/.test(h)) return true;
  if (/^fe80:/i.test(h) || /^fc00:/i.test(h) || /^fd00:/i.test(h)) return true;
  if (h === '::' || h === '::ffff:127.0.0.1') return true;
  return false;
}

/**
 * Normalizes dotted-decimal, octal, hex, and single-number IPv4 textual
 * forms to canonical dotted decimal. Returns null when not IPv4-like.
 * @param {string} h lowercased hostname
 * @returns {string|null}
 */
export function parseIpv4Variant(h) {
  if (!h || h.includes(':')) return null;
  const parsePart = (p) => {
    if (!p) return null;
    if (/^0x[0-9a-f]+$/i.test(p)) return parseInt(p, 16);
    if (/^0[0-7]+$/.test(p) && p.length > 1) return parseInt(p, 8);
    if (/^\d+$/.test(p)) return parseInt(p, 10);
    return null;
  };
  if (/^[0-9a-fx.]+$/i.test(h) === false) return null;
  const parts = h.split('.');
  if (parts.length === 1) {
    const n = parsePart(parts[0]);
    if (n === null || n < 0 || n > 0xffffffff) return null;
    return [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255].join('.');
  }
  if (parts.length < 2 || parts.length > 4) return null;
  const nums = parts.map(parsePart);
  if (nums.some(n => n === null || n < 0 || n > 0xffffffff)) return null;
  let full;
  if (nums.length === 2) {
    if (nums[0] > 255 || nums[1] > 0xffffff) return null;
    full = (nums[0] << 24) | nums[1];
  } else if (nums.length === 3) {
    if (nums[0] > 255 || nums[1] > 255 || nums[2] > 0xffff) return null;
    full = (nums[0] << 24) | (nums[1] << 16) | nums[2];
  } else {
    if (nums.some(n => n > 255)) return null;
    full = (nums[0] << 24) | (nums[1] << 16) | (nums[2] << 8) | nums[3];
  }
  return [(full >>> 24) & 255, (full >>> 16) & 255, (full >>> 8) & 255, full & 255].join('.');
}

/**
 * Fetches remote image buffer with timeout, manual redirect chain (each hop
 * re-validated against the SSRF guard — native `redirect: follow` would let
 * a public URL bounce to 169.254.169.254), and best-effort DNS re-resolution
 * (closes the DNS-rebinding window when node:dns is available).
 * Uses native fetch with AbortSignal.timeout when available (Cloudflare Workers / workerd)
 * to ensure sockets are closed immediately without connection leaks.
 */
export async function fetchRemoteImageBuffer(url, redirectCount = 0) {
  if (redirectCount > 3) throw new Error('Too many redirects');
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    throw new Error('Invalid URL');
  }
  assertPublicHttpUrl(parsed);
  await assertDnsPublic(parsed.hostname);

  // Modern runtimes / Cloudflare Workers: native fetch with strict timeout.
  // Redirects are followed MANUALLY so every hop passes the SSRF guard.
  if (typeof globalThis.fetch === 'function') {
    const res = await globalThis.fetch(url, {
      signal: AbortSignal.timeout(5000),
      redirect: 'manual',
    });
    if (res.status >= 300 && res.status < 400 && res.headers.get('location')) {
      const next = new URL(res.headers.get('location'), url).toString();
      try { if (typeof res.body?.cancel === 'function') await res.body.cancel(); } catch { /* next */ }
      return fetchRemoteImageBuffer(next, redirectCount + 1);
    }
    if (!res.ok) {
      throw new Error('HTTP status ' + res.status);
    }
    const arrayBuf = await res.arrayBuffer();
    return Buffer.from(arrayBuf);
  }

  return new Promise((resolve, reject) => {
    const client = parsed.protocol === 'https:' ? https : http;
    const req = client.get(url, { timeout: 5000 }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume();
        const next = new URL(res.headers.location, url).toString();
        return fetchRemoteImageBuffer(next, redirectCount + 1).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) {
        res.resume();
        return reject(new Error('HTTP status ' + res.statusCode));
      }
      const chunks = [];
      let bytes = 0;
      res.on('data', d => {
        bytes += d.length;
        if (bytes > MAX_IMAGE_BYTES) {
          req.destroy();
          reject(new Error('Image exceeds size cap'));
          return;
        }
        chunks.push(d);
      });
      res.on('end', () => resolve(Buffer.concat(chunks)));
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Timeout')); });
  });
}

/**
 * Rejects non-http(s) schemes and private/loopback hosts.
 * @param {URL} parsed
 */
export function assertPublicHttpUrl(parsed) {
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new Error('Unsupported protocol: ' + parsed.protocol);
  }
  if (isPrivateHost(parsed.hostname)) {
    throw new Error('Access to private/local network address is forbidden');
  }
}

/**
 * Best-effort DNS re-resolution: every A/AAAA record for the host must be
 * public. Skipped silently where node:dns is unavailable (workerd) — the
 * hostname + per-hop redirect guards still apply.
 * @param {string} hostname
 */
export async function assertDnsPublic(hostname) {
  try {
    const mod = await import('node:dns').catch(() => null);
    const lookup = mod?.promises?.lookup;
    if (typeof lookup !== 'function') return;
    const records = await lookup(hostname, { all: true, verbatim: true });
    for (const r of records || []) {
      if (isPrivateHost(r.address)) {
        throw new Error('DNS resolves to private/local address');
      }
    }
  } catch (e) {
    if (e && /private\/local/.test(e.message)) throw e;
    // DNS unavailable or unresolvable here — fetch will surface errors.
  }
}

// --- Magic-byte type gate + dimension probe (pure, zero-dep) ---

export const MAX_IMAGE_BYTES = 15 * 1024 * 1024;
export const MAX_IMAGE_PIXELS = 25 * 1000 * 1000;
// PDFKit's rasterizer supports PNG and JPEG only.
export const SUPPORTED_IMAGE_TYPES = ['png', 'jpeg'];

/**
 * Detects raster type from magic bytes. Returns null when unknown.
 * @param {Buffer|Uint8Array} buf
 * @returns {'png'|'jpeg'|'gif'|'webp'|'bmp'|null}
 */
export function detectImageType(buf) {
  if (!buf || buf.length < 12) return null;
  const b = buf;
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return 'png';
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'jpeg';
  if (b[0] === 0x47 && b[1] === 0x49 && b[2] === 0x46) return 'gif';
  if (b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46
    && b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return 'webp';
  if (b[0] === 0x42 && b[1] === 0x4d) return 'bmp';
  return null;
}

/**
 * Probes intrinsic dimensions without decoding pixels (no PDFKit allocation,
 * so layout can know aspect ratios before placing figures).
 * @param {Buffer|Uint8Array} buf
 * @returns {{ type: string, width: number, height: number }|null}
 */
export function probeImageDimensions(buf) {
  const type = detectImageType(buf);
  if (!type) return null;
  if (typeof Buffer !== 'undefined' && !Buffer.isBuffer(buf)) {
    try { buf = Buffer.from(buf); } catch { return null; }
  }
  if (buf.length < 26) return type === 'gif' && buf.length >= 10 ? probeGif(buf, type) : null;
  try {
    if (type === 'png') {
      // IHDR width/height: BE u32 at offsets 16/20.
      const width = buf.readUInt32BE(16);
      const height = buf.readUInt32BE(20);
      if (!width || !height) return null;
      return { type, width, height };
    }
    if (type === 'jpeg') {
      const box = scanJpegSof(buf);
      if (!box) return null;
      return { type, ...box };
    }
    if (type === 'gif') return probeGif(buf, type);
    return { type, width: 0, height: 0 };
  } catch {
    return null;
  }
}

function probeGif(buf, type) {
  if (buf.length < 10) return null;
  const width = buf.readUInt16LE(6);
  const height = buf.readUInt16LE(8);
  if (!width || !height) return null;
  return { type, width, height };
}

function scanJpegSof(buf) {
  let i = 2;
  while (i + 8 < buf.length) {
    if (buf[i] !== 0xff) { i++; continue; }
    const marker = buf[i + 1];
    if (marker === 0x00 || marker === 0xd8 || marker === 0xd9
      || (marker >= 0xd0 && marker <= 0xd7)) { i += 2; continue; }
    if (marker === 0x01 || (marker >= 0xe0 && marker <= 0xef) || marker === 0xfe) {
      const len = buf.readUInt16BE(i + 2);
      i += 2 + len;
      continue;
    }
    // SOF0-SOF3, SOF5-SOF7, SOF9-SOF11, SOF13-SOF15 carry dimensions.
    if ((marker >= 0xc0 && marker <= 0xcf && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc)) {
      const height = buf.readUInt16BE(i + 5);
      const width = buf.readUInt16BE(i + 7);
      if (!width || !height) return null;
      return { width, height };
    }
    const len = buf.readUInt16BE(i + 2);
    if (len < 2) return null;
    i += 2 + len;
  }
  return null;
}

/**
 * Validates a decoded image buffer: known magic, PDFKit-supported type,
 * byte cap, and pixel cap (decompression-bomb guard).
 * @param {Buffer|Uint8Array|null} buf
 * @returns {{ type: string, width: number, height: number }|null} Probe or null when rejected
 */
export function validateImageBuffer(buf) {
  if (!buf || buf.length === 0 || buf.length > MAX_IMAGE_BYTES) return null;
  if (typeof Buffer !== 'undefined' && !Buffer.isBuffer(buf)) {
    try { buf = Buffer.from(buf); } catch { return null; }
  }
  const type = detectImageType(buf);
  if (!type || !SUPPORTED_IMAGE_TYPES.includes(type)) return null;
  const probe = probeImageDimensions(buf);
  if (!probe || !probe.width || !probe.height) return null;
  if (probe.width * probe.height > MAX_IMAGE_PIXELS) return null;
  return probe;
}

/**
 * Resolves an image source (data URI, remote URL, or sandboxed local file) to a binary Buffer.
 * Every path passes the magic-byte + dimension gate: corrupt, oversized, or
 * PDFKit-unsupported bytes resolve to null (graceful placeholder) instead of
 * crashing the renderer mid-blast.
 * @param {string} src
 * @param {object} [options={}]
 * @returns {Promise<Buffer|null>}
 */
export async function resolveImageSource(src, options = {}) {
  if (!src || typeof src !== 'string') return null;
  src = src.trim();

  const gated = (buf) => (validateImageBuffer(buf) ? buf : null);

  // 1. Data URI: data:image/png;base64,...
  if (src.startsWith('data:')) {
    const commaIdx = src.indexOf(',');
    if (commaIdx !== -1) {
      try {
        return gated(Buffer.from(src.slice(commaIdx + 1), 'base64'));
      } catch {
        return null;
      }
    }
    return null;
  }

  // 2. HTTP/HTTPS URL
  if (src.startsWith('http://') || src.startsWith('https://')) {
    try {
      return gated(await fetchRemoteImageBuffer(src));
    } catch (e) {
      console.warn('Failed to fetch remote image:', src, e.message);
      return null;
    }
  }

  // 3. Local filesystem path: strictly confined within static directory (path traversal guard)
  try {
    if (src.includes('..') || src.includes('\0')) {
      return null;
    }
    const staticBase = path.resolve(options.staticDir || path.join(process.cwd(), 'static'));
    const cleanRelative = src.replace(/^\/+/, '');
    const candidatePaths = [
      path.resolve(staticBase, 'uploads', path.basename(src)),
      path.resolve(staticBase, cleanRelative),
    ];
    for (const p of candidatePaths) {
      if (p.startsWith(staticBase) && fs.existsSync(p) && fs.statSync(p).isFile()) {
        try {
          return gated(fs.readFileSync(p));
        } catch {
          return null;
        }
      }
    }
  } catch (e) {
    // Ignore local fs read error
  }

  return null;
}

export class ModularImageResolver {
  constructor(options = {}) {
    this.staticDir = options.staticDir || path.join(process.cwd(), 'static');
  }

  /**
   * Resolves a local or uploaded image path safely within staticDir.
   * Prevents path traversal vulnerabilities.
   * @param {string} src 
   * @returns {string|null} Absolute safe path or null if invalid
   */
  resolveLocalPath(src) {
    if (!src || typeof src !== 'string') return null;
    
    // Normalize and strip query parameters or hashes
    const cleanSrc = src.split('?')[0].split('#')[0];
    
    // Reject explicit remote protocols in pure local resolver
    if (/^https?:\/\//i.test(cleanSrc)) {
      return null;
    }

    if (cleanSrc.includes('..') || cleanSrc.includes('\0')) {
      return null;
    }

    // Relative to static uploads or assets
    const normalized = cleanSrc.replace(/^\/+/, '');
    const staticBase = path.resolve(this.staticDir);
    const candidatePaths = [
      path.resolve(staticBase, 'uploads', path.basename(cleanSrc)),
      path.resolve(staticBase, normalized),
    ];

    for (const p of candidatePaths) {
      if (p.startsWith(staticBase) && fs.existsSync(p)) {
        try {
          if (fs.statSync(p).isFile()) return p;
        } catch { /* next */ }
      }
    }

    return null;
  }

  /**
   * Resolves image source to binary Buffer.
   * @param {string} src
   * @returns {Promise<Buffer|null>}
   */
  async resolve(src) {
    return resolveImageSource(src, { staticDir: this.staticDir });
  }

  /**
   * Computes aspect-ratio preserving dimensions fitting within maxWidth and maxHeight.
   * @param {number} naturalWidth 
   * @param {number} naturalHeight 
   * @param {number} maxWidth 
   * @param {number} maxHeight 
   * @returns {{ width: number, height: number }}
   */
  calculateFittedDimensions(naturalWidth, naturalHeight, maxWidth, maxHeight) {
    if (!naturalWidth || !naturalHeight) {
      return { width: maxWidth, height: Math.min(maxWidth * 0.6, maxHeight) };
    }

    const aspect = naturalWidth / naturalHeight;
    let targetWidth = maxWidth;
    let targetHeight = targetWidth / aspect;

    if (targetHeight > maxHeight) {
      targetHeight = maxHeight;
      targetWidth = targetHeight * aspect;
    }

    return {
      width: Math.round(targetWidth * 100) / 100,
      height: Math.round(targetHeight * 100) / 100,
    };
  }
}
