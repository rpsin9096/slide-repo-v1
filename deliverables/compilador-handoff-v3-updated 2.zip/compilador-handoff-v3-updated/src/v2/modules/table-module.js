/**
 * FocusGate / PDF Engine V2: Table Subsystem Module
 * Decoupled wrapper for Booktabs table layout, column width solving, and pagination slicing.
 */

export function stripInlineMetrics(text) {
  if (!text) return '';
  return text
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/!\[([^\]]*)\]\([^)]*\)/g, '$1')
    .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
    .replace(/(\*\*\*|___)(.*?)\1/g, '$2')
    .replace(/(\*\*|__)(.*?)\1/g, '$2')
    .replace(/(\*|_)(.*?)\1/g, '$2')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/\$([^$]+)\$/g, '$1')
    .replace(/~~(.*?)~~/g, '$1')
    .replace(/<[^>]+>/g, '');
}

export class BooktabsGrid {
  constructor(options = {}) {
    this.columns = options.columns || [];
    this.header = options.header || { cells: [], height: 16 };
    this.rows = options.rows || [];
    this.headerHeight = this.header.height || 16;
    this.totalHeight = options.totalHeight || 0;
    this.width = options.width || 0;
    this.isPanoramic = !!options.isPanoramic;
    this.fullWidth = !!options.fullWidth;
  }
}

export class TableSlice {
  constructor(options = {}) {
    this.grid = options.grid;
    this.startRowIndex = options.startRowIndex || 0;
    this.endRowIndex = options.endRowIndex || 0;
    this.rows = options.rows || [];
    this.repeatedHeader = !!options.repeatedHeader;
    this.headerBudget = options.headerBudget || 0;
    this.height = options.height || 0;
    this.hasTopRule = options.hasTopRule !== false;
    this.hasMidRule = options.hasMidRule !== false;
    this.hasBottomRule = !!options.hasBottomRule;
    this.width = options.width || (this.grid ? this.grid.width : 0);
    this.fullWidth = !!(this.grid && this.grid.fullWidth);
  }
}

export class TableLayoutEngine {
  static isPanoramic(token, colW, tmpl, mode = 'compact') {
    if (!token) return false;
    const colCount = (token.header && token.header.length > 0)
      ? token.header.length
      : ((token.rows && token.rows[0]) ? token.rows[0].length : 0);
    if (colCount === 0) return false;
    if (mode === 'full_width') return true;
    if (colCount >= 5) return true;
    if (mode === 'option_b' && colCount >= 4) return true;

    const headerChars = (token.header || []).reduce((acc, h) => acc + (h.text || '').length, 0);
    const maxRowChars = (token.rows || []).reduce((max, row) => {
      const rowLen = row.reduce((sum, c) => sum + (c.text || '').length, 0);
      return Math.max(max, rowLen);
    }, 0);

    if (colCount >= 4 && (headerChars > 35 || maxRowChars > 70)) return true;
    if (colCount >= 3 && (headerChars > 60 || maxRowChars > 130)) return true;

    return false;
  }

  static calculateColumnWidths(token, targetWidth, tmpl, mode = 'compact') {
    const colCount = (token.header && token.header.length > 0)
      ? token.header.length
      : ((token.rows && token.rows[0]) ? token.rows[0].length : 1);
    if (colCount === 1) return [targetWidth];

    const maxChars = new Array(colCount).fill(4);
    // Conservative header auto-widen (parity with geometry-compiler):
    // bold header advances render ~15% wider than body char counts imply.
    token.header.forEach((h, i) => {
      const clean = stripInlineMetrics(h.text || '');
      const weighted = clean.length * 1.15;
      if (weighted > maxChars[i]) maxChars[i] = weighted;
    });

    if (token.rows && Array.isArray(token.rows)) {
      token.rows.forEach(row => {
        row.forEach((cell, i) => {
          if (i < colCount) {
            const clean = stripInlineMetrics(cell.text || '');
            if (clean.length > maxChars[i]) maxChars[i] = clean.length;
          }
        });
      });
    }

    const minColW = Math.max(28, Math.floor(targetWidth / (colCount * 2.5)));

    if (colCount * minColW > targetWidth + 0.5) {
      const even = targetWidth / colCount;
      return new Array(colCount).fill(even);
    }

    const widths = new Array(colCount).fill(0);
    const pinned = [];
    const free = new Set(maxChars.map((_, i) => i));

    for (let pass = 0; pass < colCount; pass++) {
      const pinnedTotal = pinned.reduce((a, i) => a + widths[i], 0);
      const leftover = targetWidth - pinnedTotal;

      let freeDemand = 0;
      for (const i of free) freeDemand += Math.max(maxChars[i], 0);

      if (freeDemand <= 0) {
        const even = leftover / free.size;
        for (const i of free) widths[i] = even;
      } else {
        for (const i of free) widths[i] = (Math.max(maxChars[i], 0) / freeDemand) * leftover;
      }

      let newlyPinned = -1, minVal = Infinity;
      for (const i of free) {
        if (widths[i] < minVal) { minVal = widths[i]; newlyPinned = i; }
      }
      if (newlyPinned === -1 || minVal >= minColW - 1e-9) break;

      widths[newlyPinned] = minColW;
      pinned.push(newlyPinned);
      free.delete(newlyPinned);
      if (free.size === 0) break;
    }

    for (let i = 0; i < colCount; i++) {
      if (widths[i] < minColW) widths[i] = minColW;
    }

    const diff = targetWidth - widths.reduce((a, b) => a + b, 0);
    if (Math.abs(diff) > 1e-6) {
      widths[widths.length - 1] += diff;
    }

    return widths;
  }

  static buildGrid(token, availableWidth, tmpl, options = {}) {
    const mode = options.tableLayoutMode || 'compact';
    const isPano = TableLayoutEngine.isPanoramic(token, availableWidth, tmpl, mode);
    const tableW = isPano && options.fullPrintWidth ? options.fullPrintWidth : availableWidth;
    const widths = TableLayoutEngine.calculateColumnWidths(token, tableW, tmpl, mode);

    const bodySize = tmpl?.fontSize === 8 ? 7 : (tmpl?.fontSize === 9 ? 7.5 : 8);
    const headerSize = bodySize + 0.5;
    const cellPaddingH = 5;
    const charWidth = bodySize * 0.5;
    // Injected font-metric measurer (ref-11 MeasureFn seam). When the caller
    // threads a live shaper (e.g. geometry-compiler measureOpt), cell wrapping
    // uses rendered widths so estimated == rendered line counts. Falls back to
    // the legacy charWidth estimate for headless/unit-test callers.
    const injected = typeof options.measure === 'function' ? options.measure : null;
    const headerMeasure = injected
      ? ((s) => injected(s, 'helvetica-bold', headerSize))
      : ((s) => s.length * (headerSize * 0.5 * 1.06));
    const bodyMeasure = injected
      ? ((s) => injected(s, 'helvetica', bodySize))
      : ((s) => s.length * charWidth);
    const colAligns = (token.align && Array.isArray(token.align)) ? token.align : [];

    const resolveAlign = (colIndex, text) => {
      const explicit = colAligns[colIndex];
      if (explicit && (explicit === 'right' || explicit === 'center' || explicit === 'left')) {
        return explicit;
      }
      const trimmed = (text || '').trim();
      if (/^[+-]?(?:R\$|US\$|€|\$)?\s*\d+(?:[.,]\d+)?%?$/.test(trimmed)) {
        return 'right';
      }
      return 'left';
    };

    let maxHeaderLines = 1;
    const headerCells = token.header.map((h, i) => {
      const text = stripInlineMetrics(h.text || '');
      const usableW = Math.max(10, widths[i] - cellPaddingH * 2);
      const lines = wrapTableCellText(text, usableW, headerMeasure);
      if (lines.length > maxHeaderLines) maxHeaderLines = lines.length;
      return { text, lines: lines.length, align: colAligns[i] || 'left' };
    });

    const headerHeight = Math.ceil(maxHeaderLines * (headerSize * 1.3) + 8);

    let rowsTotalHeight = 0;
    const gridRows = (token.rows || []).map((row, rIdx) => {
      let maxCellLines = 1;
      const cells = row.map((c, i) => {
        const text = stripInlineMetrics(c.text || '');
        const usableW = Math.max(10, (widths[i] || 30) - cellPaddingH * 2);
        const lines = wrapTableCellText(text, usableW, bodyMeasure);
        if (lines.length > maxCellLines) maxCellLines = lines.length;
        const align = resolveAlign(i, text);
        return { text, lines: lines.length, align, raw: c };
      });

      const rowHeight = Math.ceil(maxCellLines * (bodySize * 1.25) + 6);
      rowsTotalHeight += rowHeight;

      return {
        index: rIdx,
        cells,
        height: rowHeight,
      };
    });

    const rulesHeight = 1.5 + 0.75 + 1.5 + 10;
    const totalHeight = headerHeight + rowsTotalHeight + rulesHeight;

    return new BooktabsGrid({
      columns: widths,
      header: {
        cells: headerCells,
        height: headerHeight,
      },
      rows: gridRows,
      totalHeight,
      width: tableW,
      isPanoramic: isPano,
      fullWidth: isPano,
    });
  }

  static paginate(grid, constraints = {}) {
    const firstSpace = constraints.firstSliceAvailableHeight || grid.totalHeight;
    const nextSpace = constraints.subsequentSliceAvailableHeight || 600;

    const slices = [];
    const totalRows = grid.rows.length;

    if (totalRows === 0) {
      slices.push(new TableSlice({
        grid,
        startRowIndex: 0,
        endRowIndex: 0,
        rows: [],
        repeatedHeader: false,
        headerBudget: grid.headerHeight + 6,
        height: grid.headerHeight + 10,
        hasTopRule: true,
        hasMidRule: true,
        hasBottomRule: true,
      }));
      return slices;
    }

    let currentRowIdx = 0;
    let isFirstSlice = true;

    while (currentRowIdx < totalRows) {
      const availH = isFirstSlice ? firstSpace : nextSpace;
      const isRepeated = !isFirstSlice;
      const headerH = grid.headerHeight;
      const overheadH = headerH + 6;

      let sliceRowsH = 0;
      const sliceRows = [];
      const startIdx = currentRowIdx;

      while (currentRowIdx < totalRows) {
        const row = grid.rows[currentRowIdx];
        if (overheadH + sliceRowsH + row.height <= availH || sliceRows.length === 0) {
          sliceRows.push(row);
          sliceRowsH += row.height;
          currentRowIdx++;
        } else {
          break;
        }
      }

      const isFinalSlice = (currentRowIdx >= totalRows);

      slices.push(new TableSlice({
        grid,
        startRowIndex: startIdx,
        endRowIndex: currentRowIdx,
        rows: sliceRows,
        repeatedHeader: isRepeated,
        headerBudget: overheadH,
        height: overheadH + sliceRowsH + (isFinalSlice ? 6 : 0),
        hasTopRule: isFirstSlice,
        hasMidRule: true,
        hasBottomRule: isFinalSlice,
        width: grid.width,
        fullWidth: grid.fullWidth,
      }));

      isFirstSlice = false;
    }

    return slices;
  }
}

// A3: pathological-token guards. Spaceless mega-tokens (pasted base64,
// JWT/blob dumps) previously cost O(L²) live width measures in every
// char-fallback splitter — a single 273k-glyph "word" can exhaust the
// isolate (Cloudflare Error 1102 / HTTP 503). Tokens above
// LONG_TOKEN_CHARS take an arithmetic fast path (one sampled width, zero
// per-slice measures); everything below keeps exact legacy splitting.
export const LONG_TOKEN_CHARS = 2000;

// Capped + cached syllable points in raw {index,hasHyphen} shape.
// Analysis is O(L·P) internally, so tokens above the cap skip it and fall
// through to measured/arithmetic char splitting. Within the cap the
// result is exactly getHyphenationPoints(word), cached per isolate.
// (Lives here — not in layout/hyphenation.js — to avoid a
// table-module ⇄ hyphenation import cycle.)
const hyphenPtsCache = new Map();
const MAX_HYPHEN_PTS_CACHE = 1000;
export const MAX_HYPHEN_PTS_LEN = 512;
export function cachedHyphenPoints(word) {
  if (!word || typeof word !== 'string') return [];
  if (word.length > MAX_HYPHEN_PTS_LEN) return [];
  const hit = hyphenPtsCache.get(word);
  if (hit) return hit;
  const pts = getHyphenationPoints(word);
  if (hyphenPtsCache.size >= MAX_HYPHEN_PTS_CACHE) {
    const it = hyphenPtsCache.keys();
    for (let i = 0; i < MAX_HYPHEN_PTS_CACHE / 2; i++) {
      const k = it.next().value;
      if (k === undefined) break;
      hyphenPtsCache.delete(k);
    }
  }
  hyphenPtsCache.set(word, pts);
  return pts;
}

// Binary search for the longest prefix of `word` (length in
// [minLen, word.length - 1]) satisfying `fits(piece)`. Width measures
// here (fontkit advances, AFM sums) are monotone non-decreasing in prefix
// length, so this returns exactly what the legacy O(L) descending scan
// found, in O(log L) probes.
export function longestFittingPrefix(word, fits, minLen = 1) {
  const n = word.length;
  if (n <= minLen || !fits(word.slice(0, minLen))) return -1;
  if (fits(word.slice(0, n - 1))) return n - 1;
  let lo = minLen;
  let hi = n - 1;
  while (lo < hi) {
    const mid = (lo + hi + 1) >> 1;
    if (fits(word.slice(0, mid))) lo = mid;
    else hi = mid - 1;
  }
  return lo;
}

// Arithmetic slice length from a one-time sampled width: how many chars
// of similar advance fit targetW. Used only for giant-token fast paths.
export function estimateFitLen(sampleWidth, sampleLen, targetW) {
  const per = sampleWidth / Math.max(1, sampleLen);
  if (!Number.isFinite(per) || per <= 0) return 1;
  return Math.max(1, Math.floor(targetW / per));
}

export function getHyphenationPoints(word) {  if (!word || typeof word !== 'string') return [];
  const points = [];
  const lower = word.toLowerCase();
  const vowels = new Set(['a', 'e', 'i', 'o', 'u', 'á', 'é', 'í', 'ó', 'ú', 'â', 'ê', 'ô', 'ã', 'õ', 'à', 'ü']);
  const isVowel = (c) => vowels.has(c);
  const isConsonant = (c) => /[a-zç]/i.test(c) && !vowels.has(c);
  const inseparable = new Set([
    'ch', 'lh', 'nh', 'gu', 'qu',
    'bl', 'cl', 'fl', 'gl', 'pl', 'tl', 'vl',
    'br', 'cr', 'dr', 'fr', 'gr', 'pr', 'tr', 'vr'
  ]);

  for (let i = 0; i < word.length - 1; i++) {
    if (word[i] === '-' || word[i] === '–' || word[i] === '/') {
      points.push({ index: i, hasHyphen: true });
    }
  }

  for (let i = 1; i < word.length - 2; i++) {
    const c1 = lower[i - 1], c2 = lower[i], c3 = lower[i + 1], c4 = lower[i + 2];

    if ((c2 === 'r' && c3 === 'r') || (c2 === 's' && c3 === 's') || 
        (c2 === 's' && c3 === 'c') || (c2 === 's' && c3 === 'ç') ||
        (c2 === 'x' && c3 === 'c')) {
      if (!points.some(p => p.index === i)) {
        points.push({ index: i, hasHyphen: false });
      }
      continue;
    }

    if (isVowel(c1) && !isVowel(c2) && isVowel(c3) && !inseparable.has(c2 + c3)) {
      if (i - 1 >= 1 && !points.some(p => p.index === i - 1)) {
        points.push({ index: i - 1, hasHyphen: false });
      }
    }

    if (isVowel(c1) && isConsonant(c2) && isConsonant(c3) && isVowel(c4)) {
      if (inseparable.has(c2 + c3)) {
        if (i - 1 >= 1 && !points.some(p => p.index === i - 1)) {
          points.push({ index: i - 1, hasHyphen: false });
        }
      } else {
        if (!points.some(p => p.index === i)) {
          points.push({ index: i, hasHyphen: false });
        }
      }
    }
  }

  return points.sort((a, b) => a.index - b.index);
}

export function wrapTableCellText(text, maxWidth, measureFn = null) {
  if (!text) return [''];
  const measure = typeof measureFn === 'function' ? measureFn : (str => str.length * 4);
  const targetW = Math.max(8, maxWidth);
  const spaceW = measure(' ');
  const hyphenW = measure('-');

  const sublines = String(text).split('\n');
  const allLines = [];

  for (const sub of sublines) {
    const words = sub.split(/\s+/).filter(Boolean);
    if (words.length === 0) {
      allLines.push('');
      continue;
    }

    const lines = [];
    let currentLine = '';
    let currentW = 0;

    for (let tIdx = 0; tIdx < words.length; tIdx++) {
      let word = words[tIdx];

      while (word.length > 0) {
        // A3: giant-token fast path. Above LONG_TOKEN_CHARS the measured
        // splitters below cost O(L²) live measures (isolate death), so
        // flush any partial line and emit arithmetic chunks from a
        // one-time sampled width — zero per-slice measures. The final
        // chunk carries no hyphen, mirroring the measured path.
        if (word.length > LONG_TOKEN_CHARS) {
          if (currentLine.length > 0) {
            lines.push(currentLine);
            currentLine = '';
            currentW = 0;
          }
          const estLen = estimateFitLen(measure(word.slice(0, 32)), 32, targetW);
          let gi = 0;
          while (gi < word.length) {
            const chunk = word.slice(gi, gi + estLen);
            gi += estLen;
            const last = gi >= word.length;
            const hasTrail = chunk.endsWith('-') || chunk.endsWith('–') || chunk.endsWith('/');
            lines.push(chunk + (!last && !hasTrail ? '-' : ''));
          }
          word = '';
          break;
        }
        const leadSpace = currentLine.length > 0 ? ' ' : '';
        const leadW = currentLine.length > 0 ? spaceW : 0;
        const wFull = measure(leadSpace + word);

        if (currentW + wFull <= targetW + 0.1) {
          currentLine += leadSpace + word;
          currentW += wFull;
          break;
        }

        if (currentLine.length > 0) {
          const wClean = measure(word);
          if (wClean <= targetW + 0.1) {
            lines.push(currentLine);
            currentLine = '';
            currentW = 0;
            continue;
          }

          const avail = targetW - currentW - leadW;
          if (avail >= hyphenW + measure('xx')) {
            let splitIdx = -1;
            let needHyphen = true;
            const pts = word.length > MAX_HYPHEN_PTS_LEN ? [] : cachedHyphenPoints(word);
            for (let pi = pts.length - 1; pi >= 0; pi--) {
              const pt = pts[pi];
              if (!pt.hasHyphen) {
                const leftLen = pt.index + 1;
                const rightLen = word.length - leftLen;
                if (leftLen < 2 || rightLen < 3) continue;
              }
              const piece = word.slice(0, pt.index + 1);
              const pieceW = measure(leadSpace + piece + (pt.hasHyphen ? '' : '-'));
              if (currentW + pieceW <= targetW + 0.1) {
                splitIdx = pt.index + 1;
                needHyphen = !pt.hasHyphen;
                break;
              }
            }
            if (splitIdx === -1 && word.length >= 6) {
              // A3: binary search — exact under monotone measures (see
              // longestFittingPrefix), O(log L) probes instead of O(L).
              // leftMin=2/rightMin=3: never leave <3 chars for the tail.
              splitIdx = longestFittingPrefix(
                word,
                (piece) => piece.length >= 2
                  && (word.length - piece.length === 0 || word.length - piece.length >= 3)
                  && currentW + measure(leadSpace + piece + '-') <= targetW + 0.1,
                2,
              );
              needHyphen = true;
            }
            if (splitIdx > 0) {
              const part = word.slice(0, splitIdx);
              const hasTrailHyphen = part.endsWith('-') || part.endsWith('–') || part.endsWith('/');
              currentLine += leadSpace + part + (needHyphen && !hasTrailHyphen ? '-' : '');
              lines.push(currentLine);
              currentLine = '';
              currentW = 0;
              word = word.slice(splitIdx);
              continue;
            }
          }

          lines.push(currentLine);
          currentLine = '';
          currentW = 0;
          continue;
        }

        // Fresh line: short words (<6) are never force-split — emit whole
        // (clean overflow) instead of 1-char shards. Syllable points obey
        // leftMin=2/rightMin=3; explicit "-"/"/" breaks always honoured.
        let splitIdx = -1;
        let needHyphen = true;
        if (word.length < 6) {
          lines.push(word);
          word = '';
          continue;
        }
        const pts = word.length > MAX_HYPHEN_PTS_LEN ? [] : cachedHyphenPoints(word);
        for (let pi = pts.length - 1; pi >= 0; pi--) {
          const pt = pts[pi];
          if (!pt.hasHyphen) {
            const leftLen = pt.index + 1;
            const rightLen = word.length - leftLen;
            if (leftLen < 2 || rightLen < 3) continue;
          }
          const piece = word.slice(0, pt.index + 1);
          const pieceW = measure(piece + (pt.hasHyphen ? '' : '-'));
          if (pieceW <= targetW + 0.1) {
            splitIdx = pt.index + 1;
            needHyphen = !pt.hasHyphen;
            break;
          }
        }
        if (splitIdx === -1) {
          // A3: binary search — exact under monotone measures (see
          // longestFittingPrefix), O(log L) probes instead of O(L).
          splitIdx = longestFittingPrefix(
            word,
            (piece) => piece.length >= 2
              && (word.length - piece.length === 0 || word.length - piece.length >= 3)
              && measure(piece + '-') <= targetW + 0.1,
            2,
          );
          needHyphen = true;
        }
        // No legal split: emit whole (clean overflow, forward progress).
        if (splitIdx === -1) {
          lines.push(word);
          word = '';
          continue;
        }

        const part = word.slice(0, splitIdx);
        const hasTrailHyphen = part.endsWith('-') || part.endsWith('–') || part.endsWith('/');
        lines.push(part + (needHyphen && !hasTrailHyphen ? '-' : ''));
        word = word.slice(splitIdx);
      }
    }

    if (currentLine.length > 0) {
      lines.push(currentLine);
    }
    allLines.push(...lines);
  }

  return allLines.length > 0 ? allLines : [''];
}

export class ModularTableEngine {
  constructor(options = {}) {
    this.options = options;
  }

  planTable(token, availableWidth, availableHeight, tmpl = {}, options = {}) {
    const isPanoramic = TableLayoutEngine.isPanoramic(token, availableWidth, tmpl, options.tableLayoutMode);
    const effectiveWidth = isPanoramic ? (this.options.pageWidth || 500) : availableWidth;
    
    const colWidths = TableLayoutEngine.calculateColumnWidths(token, effectiveWidth, tmpl, options.tableLayoutMode);
    const grid = TableLayoutEngine.buildGrid(token, effectiveWidth, tmpl, { ...options, fullPrintWidth: effectiveWidth });
    const slices = TableLayoutEngine.paginate(grid, { firstSliceAvailableHeight: availableHeight });

    let totalHeight = 0;
    for (const slice of slices) {
      totalHeight += slice.height || 0;
    }

    return {
      slices,
      grid,
      isPanoramic,
      colWidths,
      totalHeight,
    };
  }

  streamTableRows(token, availableWidth, tmpl = {}, options = {}) {
    const gridUnit = options.gridUnit || tmpl.gridUnit || 12;
    const isPanoramic = TableLayoutEngine.isPanoramic(token, availableWidth, tmpl, options.tableLayoutMode);
    const effectiveWidth = isPanoramic ? (this.options.pageWidth || 500) : availableWidth;
    const colWidths = TableLayoutEngine.calculateColumnWidths(token, effectiveWidth, tmpl, options.tableLayoutMode);
    const tableId = options.tableId || `tbl_${Date.now().toString(36)}`;

    const headerRow = token.header || [];
    const rows = token.rows || [];

    const repeatHeaders = [
      {
        kind: 'tableRow',
        blockId: tableId,
        units: 1,
        cells: headerRow,
        isHeader: true,
        fullWidth: isPanoramic,
        table: { tableId, headers: [], isHeader: true, isContinuation: true },
      },
    ];

    const atoms = [];

    atoms.push({
      kind: 'tableRow',
      blockId: tableId,
      units: 1,
      cells: headerRow,
      isHeader: true,
      fullWidth: isPanoramic,
      table: { tableId, headers: repeatHeaders, isHeader: true },
    });

    for (let r = 0; r < rows.length; r++) {
      const row = rows[r];
      const rowH = 14;
      const units = Math.max(1, Math.ceil(rowH / gridUnit));

      atoms.push({
        kind: 'tableRow',
        blockId: tableId,
        units,
        cells: row,
        isHeader: false,
        fullWidth: isPanoramic,
        table: {
          tableId,
          headers: repeatHeaders,
          isHeader: false,
          rowIndex: r,
        },
      });
    }

    const totalUnits = atoms.reduce((sum, a) => sum + a.units, 0);

    return {
      atoms,
      isPanoramic,
      colWidths,
      totalUnits,
      effectiveWidth,
    };
  }
}

const NUMERIC_PATTERN = /^[-+(]?[\s$€£R$]*\d[\d\s,.']*%?\)?$/i;

export function splitTableRow(line) {
  let working = String(line || '').trim();
  if (working.startsWith('|')) working = working.slice(1);
  if (working.endsWith('|') && !working.endsWith('\\|')) working = working.slice(0, -1);
  const cells = [];
  let current = '';
  for (let i = 0; i < working.length; i++) {
    const char = working[i];
    if (char === '\\' && working[i + 1] === '|') {
      current += '|';
      i++;
      continue;
    }
    if (char === '|') {
      cells.push(current.trim());
      current = '';
      continue;
    }
    current += char;
  }
  cells.push(current.trim());
  return cells;
}

export function inferColumnAlignment(values) {
  const nonEmpty = (values || []).filter(v => typeof v === 'string' && v.trim().length > 0);
  if (nonEmpty.length === 0) return 'left';
  const numericCount = nonEmpty.filter(v => NUMERIC_PATTERN.test(v.trim())).length;
  if (numericCount / nonEmpty.length >= 0.7) {
    return nonEmpty.some(v => v.includes('.') || v.includes(',')) ? 'decimal' : 'right';
  }
  return 'left';
}

export function normalizeTableMarkdown(input) {
  const repairs = [];
  const lines = (Array.isArray(input) ? input : String(input || '').split('\n'))
    .map(l => l.trim())
    .filter(l => l.length > 0 && l.includes('|'));

  if (lines.length === 0) {
    return { headers: [], rows: [], alignments: [], columnCount: 0, repairs: ['empty-table'] };
  }

  let delimiterIndex = -1;
  for (let i = 0; i < Math.min(lines.length, 3); i++) {
    const trimmed = lines[i].replace(/^\|/, '').replace(/\|$/, '');
    const parts = trimmed.split('|');
    if (parts.length > 0 && parts.every(p => /^\s*:?-{1,}:?\s*$/.test(p))) {
      delimiterIndex = i;
      break;
    }
  }

  let headerLines = [];
  let bodyLines = [];
  let declaredAlignments = null;

  if (delimiterIndex >= 0) {
    headerLines = lines.slice(0, delimiterIndex);
    declaredAlignments = splitTableRow(lines[delimiterIndex]).map(cell => {
      const c = cell.trim();
      const left = c.startsWith(':');
      const right = c.endsWith(':');
      if (left && right) return 'center';
      if (right) return 'right';
      return 'left';
    });
    bodyLines = lines.slice(delimiterIndex + 1);
  } else {
    repairs.push('missing-delimiter-row: first row promoted to header');
    headerLines = lines.slice(0, 1);
    bodyLines = lines.slice(1);
  }

  const rawHeaders = headerLines.map(splitTableRow);
  const rawRows = bodyLines.map(splitTableRow);

  const headerCols = Math.max(0, ...rawHeaders.map(r => r.length));
  const declaredCols = declaredAlignments?.length || 0;
  const columnCount = headerCols > 0
    ? headerCols
    : (declaredCols > 0 ? declaredCols : Math.max(1, ...rawRows.map(r => r.length)));

  const padRow = (cells, where) => {
    if (cells.length === columnCount) return cells;
    if (cells.length < columnCount) {
      repairs.push(`ragged-row(${where}): padded ${columnCount - cells.length} cell(s)`);
      return [...cells, ...Array(columnCount - cells.length).fill('')];
    }
    repairs.push(`overflow-row(${where}): merged ${cells.length - columnCount} trailing cell(s)`);
    const head = cells.slice(0, columnCount - 1);
    return [...head, cells.slice(columnCount - 1).join(' ')];
  };

  const headers = rawHeaders.map((r, i) => padRow(r, `header:${i}`));
  const rows = rawRows.map((r, i) => padRow(r, `body:${i}`));

  const columnValues = Array.from({ length: columnCount }, (_, c) => rows.map(r => r[c] || ''));
  const alignments = Array.from({ length: columnCount }, (_, c) => {
    const declared = declaredAlignments?.[c];
    if (declared && declared !== 'left') return declared;
    const inferred = inferColumnAlignment(columnValues[c]);
    return declared && inferred === 'left' ? declared : inferred;
  });

  const delimRow = '| ' + alignments.map(a => a === 'center' ? ':---:' : (a === 'right' || a === 'decimal') ? '---:' : '---').join(' | ') + ' |';
  const mdHeader = headers.map(r => '| ' + r.join(' | ') + ' |').join('\n');
  const mdBody = rows.map(r => '| ' + r.join(' | ') + ' |').join('\n');
  const markdown = `${mdHeader}\n${delimRow}\n${mdBody}`;

  return {
    headers,
    rows,
    alignments,
    columnCount,
    repairs,
    markdown,
    toString() {
      return markdown;
    },
    split(separator, limit) {
      return markdown.split(separator, limit);
    },
  };
}
