/**
 * FocusGate / PDF Engine V2: Table of Contents (TOC) Module
 * Deterministic TOC chapter indexing, dot leaders, and running header/footer rules.
 */

import { getFontName } from '../fonts/catalog.js';

function nbspToSpaces(text) {
  return String(text ?? '').replace(/[\u00A0\u2007\u202F]/g, ' ');
}

/**
 * Normalizes and sanitizes strings destined for standard PDFKit fonts (WinAnsiEncoding)
 * to prevent missing glyph boxes ([?]) from unencodable Unicode symbols and fontkit NBSP crashes.
 */
export function sanitizePdfText(str) {
  if (!str || typeof str !== 'string') return '';
  return str
    .replace(/[\u00A0\u2007\u202F]/g, ' ')
    .replace(/[\u21B0-\u21B5\u27A1\u2794\u2192]/g, '->')
    .replace(/[\u2190]/g, '<-')
    .replace(/[\u2191]/g, '^')
    .replace(/[\u2193]/g, 'v')
    .replace(/[\u25AA\u25AB\u25AC\u25AD\u25A0\u25A1\u25C6\u25C7]/g, '-')
    .replace(/[\u2713\u2714]/g, '[x]')
    .replace(/[\u200B-\u200D\uFEFF]/g, '');
}

/**
 * Draws a unified, consistent running page header across ToC and body pages
 */
export function drawUnifiedPageHeader(doc, tmpl, options = {}) {
  const {
    showHeaderTop = true,
    customHeader = null,
    runningHeader = '',
    headerDate = null,
    hasCustomFonts = false,
  } = options;

  if (!showHeaderTop) return;

  const leftMargin = tmpl.margins.left;
  const rightMargin = tmpl.margins.right;
  const headerY = tmpl.margins.top;
  const headerWidth = doc.page.width - leftMargin - rightMargin;

  const titleText = nbspToSpaces((customHeader && customHeader.trim()) ? customHeader.trim() : runningHeader);
  const dateText = nbspToSpaces(headerDate || '');

  const chromeTok = (tmpl && tmpl.tokens && tmpl.tokens.chrome) || {};
  const headerFontSize = chromeTok.fontSize || (tmpl.fontSize === 8 ? 6.5 : tmpl.fontSize === 9 ? 7.5 : 8);
  const isBold = chromeTok.bold !== undefined ? chromeTok.bold : (tmpl.fontSize !== 9.5);

  doc.save();
  const fontName = getFontName(hasCustomFonts, isBold ? 'bold' : 'normal', tmpl && tmpl.tokens?.fontFamily, doc && doc._modernFonts === true);
  doc.font(fontName)
     .fontSize(headerFontSize)
     .fillColor(tmpl.colors.textmuted);

  // Left Header (truncate with ellipsis to prevent collision with right header/date)
  const maxTitleW = dateText ? headerWidth * 0.68 - 8 : headerWidth;
  let titleToDraw = titleText || '';
  if (titleToDraw && doc.widthOfString(titleToDraw) > maxTitleW) {
    while (titleToDraw.length > 0 && doc.widthOfString(titleToDraw + '…') > maxTitleW) {
      titleToDraw = titleToDraw.slice(0, -1);
    }
    titleToDraw += '…';
  }

  doc.text(titleToDraw, leftMargin, headerY, {
    width: maxTitleW,
    align: 'left',
    lineBreak: false,
  });

  // Right Header
  if (dateText) {
    doc.text(dateText, leftMargin + headerWidth * 0.68, headerY, {
      width: headerWidth * 0.32,
      align: 'right',
      lineBreak: false,
    });
  }

  // Rule below header (headsepline) with consolidated styling tokens and >=4pt baseline padding
  if (titleToDraw || dateText) {
    const ruleThickness = tmpl.headsepline || 0.4;
    const ruleColor = tmpl.colors.headerline || tmpl.colors.columnseprule || '#E5E7EB';
    const lineY = headerY + Math.max((tmpl.headheight || 12), headerFontSize + 4);
    doc.rect(leftMargin, lineY, headerWidth, ruleThickness)
       .fill(ruleColor);
  }

  doc.restore();
}

/**
 * Surface container primitive for mastheads, noteboxes, and ToC cards.
 */
export function drawCardFrame(doc, x, y, w, h, opts = {}) {
  const {
    arc = 0,
    bg = '#FFFFFF',
    strokeColor = null,
    strokeWidth = 0.5,
    westWidth = 0,
    westColor = null,
    topRule = 0,
    topRuleColor = null,
    bottomRule = 0,
    bottomRuleColor = null,
  } = opts;

  doc.save();
  if (arc > 0) {
    if (strokeColor) {
      doc.lineWidth(strokeWidth);
      doc.roundedRect(x, y, w, h, arc).fillAndStroke(bg, strokeColor);
    } else {
      doc.roundedRect(x, y, w, h, arc).fill(bg);
    }
  } else {
    if (strokeColor) {
      doc.lineWidth(strokeWidth);
      doc.rect(x, y, w, h).fillAndStroke(bg, strokeColor);
    } else {
      doc.rect(x, y, w, h).fill(bg);
    }
  }

  if (westWidth > 0 && westColor) {
    doc.rect(x, y, westWidth, h).fill(westColor);
  }
  if (topRule > 0 && topRuleColor) {
    doc.rect(x, y, w, topRule).fill(topRuleColor);
  }
  if (bottomRule > 0 && bottomRuleColor) {
    doc.rect(x, y + h - bottomRule, w, bottomRule).fill(bottomRuleColor);
  }
  doc.restore();
}

/**
 * Resolves semantic design tokens for the Table of Contents.
 * Falls back cleanly to template defaults if specific keys are omitted.
 */
export function getTocTokens(tmpl) {
  const isMinimalist = (tmpl.tokens && tmpl.tokens.fontFamily === 'inter') || tmpl.fontSize === 8;
  const isModern = (tmpl.tokens && tmpl.tokens.masthead && tmpl.tokens.masthead.style === 'studio_card') || tmpl.mastheadStyle === 'tcolorbox_soft';

  const defaultTokens = {
    banner: {
      style: isMinimalist ? 'compact_card' : (isModern ? 'card' : 'classic_rules'),
      arc: isModern ? 4.0 : (isMinimalist ? 2.0 : 0),
      accentWidth: isModern ? 3.5 : (isMinimalist ? 2.5 : 0),
      paddingX: isModern ? 14.0 : (isMinimalist ? 10.0 : 0),
      paddingY: isModern ? 10.0 : (isMinimalist ? 8.0 : 0),
      titleSize: isMinimalist ? 11.5 : 13.5,
      subSize: isMinimalist ? 8.5 : 9.5,
      metaSize: isMinimalist ? 7.0 : 7.5,
      topRule: 0,
      bottomRule: !isModern && !isMinimalist ? 0.75 : 0,
      gapBottom: isMinimalist ? 12.0 : 14.0,
    },
    title: {
      fontSize: isModern ? 14.0 : (isMinimalist ? 12.0 : 13.0),
      prefix: isMinimalist ? 'INDEX // ' : '',
      accentBarWidth: isModern ? 3.5 : (isMinimalist ? 2.5 : 3.0),
      accentBarHeight: isModern ? 18.0 : (isMinimalist ? 14.0 : 16.0),
      ruleThickness: isModern ? 0.5 : (isMinimalist ? 0.35 : 0.4),
      gapBottom: isMinimalist ? 10.0 : 12.0,
    },
    item: {
      height: isModern ? 26.0 : (isMinimalist ? 22.0 : 24.0),
      fontSize: isMinimalist ? 8.5 : 9.5,
      fontWeight: 'bold',
      badgeWidth: isMinimalist ? 22.0 : 20.0,
      badgeHeight: 14.0,
      badgeArc: isModern ? 2.0 : 0,
      badgeStyle: isModern ? 'pill' : (isMinimalist ? 'bracket' : 'filled'),
      labelOffset: isMinimalist ? 28.0 : 30.0,
      pageNumSize: isMinimalist ? 8.0 : 8.5,
      pageNumFont: 'bold',
      pageNumPrefix: isMinimalist ? '[P. ' : 'Pág. ',
      pageNumSuffix: isMinimalist ? ']' : '',
      paddingBottom: 2.0,
    },
    subItem: {
      indent: isMinimalist ? 32.0 : 34.0,
      fontSize: isMinimalist ? 7.5 : 8.0,
      fontWeight: 'normal',
      connector: isMinimalist ? '> ' : (isModern ? '– ' : '— '),
      rowHeight: isModern ? 14.0 : (isMinimalist ? 12.0 : 13.0),
      groupGap: isMinimalist ? 2.0 : 3.0,
      pageNumSize: isMinimalist ? 7.5 : 8.0,
      pageNumFont: 'normal',
      pageNumPrefix: isMinimalist ? '[p. ' : 'pág. ',
      pageNumSuffix: isMinimalist ? ']' : '',
    },
    leader: {
      char: '. ',
      fontSize: isMinimalist ? 7.0 : 7.5,
      minSpan: isMinimalist ? 14.0 : 16.0,
    },
  };

  return {
    banner: { ...defaultTokens.banner, ...(tmpl.toc?.banner || {}) },
    title: { ...defaultTokens.title, ...(tmpl.toc?.title || {}) },
    item: { ...defaultTokens.item, ...(tmpl.toc?.item || {}) },
    subItem: { ...defaultTokens.subItem, ...(tmpl.toc?.subItem || {}) },
    leader: { ...defaultTokens.leader, ...(tmpl.toc?.leader || {}) },
  };
}

/**
 * Normalized UI component: renders the document title masthead banner on Page 0.
 */
export function drawMastheadBanner(doc, tmpl, opts = {}) {
  const {
    cleanDocTitle,
    cleanDocSubtitle,
    metaLines = [],
    leftM,
    contentW,
    fontBold,
    fontNormal,
  } = opts;

  const t = getTocTokens(tmpl);
  const b = t.banner;
  const colors = tmpl.colors || {};

  const metaFontSize = b.metaSize;
  let metaColW = 0;
  if (metaLines.length > 0) {
    doc.font(fontNormal).fontSize(metaFontSize);
    metaColW = Math.max(...metaLines.map(line => doc.widthOfString(line)), 50) + 6;
  }

  const padX = b.paddingX || 0;
  const padY = b.paddingY || 0;
  const textIndent = leftM + padX;
  const textAvailW = contentW - padX * 2 - (metaColW > 0 ? metaColW + 12 : 0);

  let titleH = 0;
  let subH = 0;
  if (cleanDocTitle) {
    doc.font(fontBold).fontSize(b.titleSize);
    titleH = doc.heightOfString(cleanDocTitle, { width: textAvailW, lineGap: 1.5 });
  }
  if (cleanDocSubtitle) {
    doc.font(fontNormal).fontSize(b.subSize);
    subH = doc.heightOfString(cleanDocSubtitle, { width: textAvailW, lineGap: 1.2 });
  }

  const leftH = titleH + (titleH > 0 && subH > 0 ? 3 : 0) + subH;
  const metaH = metaLines.length * (metaFontSize * 1.3);

  if (b.style === 'classic_rules') {
    // Minimalist theme: Grounded masthead separator — heavy stroke below title/metadata block
    if (b.topRule > 0) {
      const topRuleY = doc.y;
      doc.rect(leftM, topRuleY, contentW, b.topRule).fill(colors.ruleblack || colors.textmain);
      doc.y += 8;
    }

    const bannerH = Math.max(leftH, metaH, 20);
    const textStartY = doc.y;
    let curY = textStartY;

    if (cleanDocTitle) {
      doc.font(fontBold).fontSize(b.titleSize).fillColor(colors.ruleblack || colors.textmain)
         .text(cleanDocTitle, leftM, curY, { width: textAvailW, lineGap: 1.5 });
      curY += titleH + 3;
    }
    if (cleanDocSubtitle) {
      doc.font(fontNormal).fontSize(b.subSize).fillColor(colors.tocSubText || colors.textmuted)
         .text(cleanDocSubtitle, leftM, curY, { width: textAvailW, lineGap: 1.2 });
    }

    if (metaLines.length > 0) {
      let mY = textStartY;
      const mX = leftM + contentW - metaColW;
      doc.font(fontNormal).fontSize(metaFontSize).fillColor(colors.tocLeader || colors.textmuted);
      for (const line of metaLines) {
        doc.text(line, mX, mY, { width: metaColW, align: 'right', lineGap: 1 });
        mY += metaFontSize * 1.3;
      }
    }

    doc.y = textStartY + bannerH + 6;
    const strokeW = (b.bottomRule !== undefined && b.bottomRule !== null) ? b.bottomRule : 0.75;
    if (strokeW > 0) {
      doc.rect(leftM, doc.y, contentW, strokeW).fill(colors.ruleblack || colors.textmain);
    }
    doc.y += b.gapBottom;
  } else {
    // Card styles (Modern & Compact)
    const blockStartY = doc.y;
    const minCardH = b.style === 'compact_card' ? 22 : 26;
    const cardHeight = Math.max(leftH, metaH, minCardH) + padY * 2;

    doc.save();
    if (b.arc > 0) {
      doc.roundedRect(leftM, blockStartY, contentW, cardHeight, b.arc)
         .lineWidth(0.5)
         .fillAndStroke(colors.surface, colors.bordercolor);
    } else {
      doc.rect(leftM, blockStartY, contentW, cardHeight)
         .lineWidth(0.5)
         .fillAndStroke(colors.surface, colors.bordercolor);
    }
    if (b.accentWidth > 0) {
      doc.rect(leftM, blockStartY, b.accentWidth, cardHeight)
         .fill(colors.accent);
    }
    doc.restore();

    const textStartY = blockStartY + padY;
    let curY = textStartY;
    if (cleanDocTitle) {
      doc.font(fontBold).fontSize(b.titleSize).fillColor(colors.textmain)
         .text(cleanDocTitle, textIndent, curY, { width: textAvailW, lineGap: 1.5 });
      curY += titleH + 3;
    }
    if (cleanDocSubtitle) {
      doc.font(fontNormal).fontSize(b.subSize).fillColor(colors.textmuted)
         .text(cleanDocSubtitle, textIndent, curY, { width: textAvailW, lineGap: 1.2 });
    }

    if (metaLines.length > 0) {
      let mY = textStartY;
      const mX = leftM + contentW - padX - metaColW;
      doc.font(fontNormal).fontSize(metaFontSize).fillColor(colors.textmuted);
      for (const line of metaLines) {
        doc.text(line, mX, mY, { width: metaColW, align: 'right', lineGap: 1 });
        mY += metaFontSize * 1.3;
      }
    }

    doc.y = blockStartY + cardHeight + b.gapBottom;
  }
}

/**
 * Normalized UI component: renders the TOC section header ("SUMÁRIO" / "INDEX // ...").
 */
export function drawTocSectionHeader(doc, tmpl, opts = {}) {
  const { tocTitle, leftM, contentW, fontBold } = opts;
  const t = getTocTokens(tmpl);
  const titleTokens = t.title;
  const colors = tmpl.colors || {};

  const headStartY = doc.y;
  const fullTitle = `${titleTokens.prefix || ''}${tocTitle}`;

  // Left accent bar
  if (titleTokens.accentBarWidth > 0) {
    const barColor = colors.accent || colors.ruleblack || colors.textmain;
    doc.rect(leftM, headStartY, titleTokens.accentBarWidth, titleTokens.accentBarHeight).fill(barColor);
  }

  const textX = leftM + (titleTokens.accentBarWidth > 0 ? titleTokens.accentBarWidth + 6.5 : 0);
  doc.font(fontBold)
     .fontSize(titleTokens.fontSize)
     .fillColor(colors.ruleblack || colors.textmain)
     .text(fullTitle, textX, headStartY + 1.5, { width: contentW - (textX - leftM) });

  doc.y = headStartY + titleTokens.accentBarHeight + 3;

  // Divider rule below section title
  if (titleTokens.ruleThickness > 0) {
    doc.rect(leftM, doc.y, contentW, titleTokens.ruleThickness).fill(colors.tocTitleRule || colors.bordercolor);
  }
  doc.y += titleTokens.gapBottom;
}

/**
 * Normalized UI component: renders precision dot leaders between labels and page numbers.
 */
export function drawDotLeader(doc, opts = {}) {
  const { startX, endX, y, tmpl, isSub = false } = opts;
  const t = getTocTokens(tmpl);
  const leaderTokens = t.leader;
  const colors = tmpl.colors || {};

  if (endX - startX < leaderTokens.minSpan) return;

  doc.save();
  const leaderFontSize = isSub ? leaderTokens.fontSize : leaderTokens.fontSize;
  doc.fontSize(leaderFontSize)
     .fillColor(colors.tocLeader || colors.rulegray || colors.textmuted);

  const dotUnitW = doc.widthOfString(leaderTokens.char || '. ');
  const dotCount = Math.floor((endX - startX) / dotUnitW);
  if (dotCount > 0) {
    let dotsStr = (leaderTokens.char || '. ').repeat(dotCount);
    if (endX - (startX + doc.widthOfString(dotsStr + '.')) >= 0) {
      dotsStr += '.';
    }
    doc.text(dotsStr, startX, y, { lineBreak: false });
  }
  doc.restore();
}

/**
 * Normalized UI component: renders chapter indicator badge.
 */
export function drawBadge(doc, tmpl, opts = {}) {
  const { numStr, leftM, itemY, fontBold } = opts;
  const t = getTocTokens(tmpl);
  const itemTokens = t.item;
  const colors = tmpl.colors || {};

  const badgeW = itemTokens.badgeWidth || 20;
  const badgeH = itemTokens.badgeHeight || 14;

  if (itemTokens.badgeStyle === 'bracket') {
    doc.font(fontBold)
       .fontSize(8)
       .fillColor(colors.tocBadgeText || colors.textmain)
       .text(`[${numStr}]`, leftM + 4, itemY + 3.5, { width: badgeW, align: 'left' });
  } else if (itemTokens.badgeStyle === 'pill' && itemTokens.badgeArc > 0) {
    doc.save();
    doc.roundedRect(leftM + 4, itemY + 2, badgeW, badgeH, itemTokens.badgeArc)
       .fill(colors.tocBadgeBg || colors.accent);
    doc.font(fontBold)
       .fontSize(8)
       .fillColor(colors.tocBadgeText || '#FFFFFF')
       .text(numStr, leftM + 4, itemY + 4, { width: badgeW, align: 'center' });
    doc.restore();
  } else {
    // Filled rectangle
    doc.save();
    doc.rect(leftM + 4, itemY + 2, badgeW, badgeH)
       .fill(colors.tocBadgeBg || colors.ruleblack || colors.accent);
    doc.font(fontBold)
       .fontSize(8)
       .fillColor(colors.tocBadgeText || '#FFFFFF')
       .text(numStr, leftM + 4, itemY + 4, { width: badgeW, align: 'center' });
    doc.restore();
  }
}

/**
 * Normalized UI component: renders a single chapter row.
 */
export function drawTocChapterRow(doc, tmpl, opts = {}) {
  const { sec, idx, leftM, contentW, fontBold, fontNormal } = opts;
  const t = getTocTokens(tmpl);
  const itemTokens = t.item;
  const colors = tmpl.colors || {};

  const numStr = String(idx + 1).padStart(2, '0');
  const cleanSecName = sanitizePdfText(sec.name || `Capítulo ${idx + 1}`);
  const isSecMhOff = sec.masthead?.enabled === false || sec.enable_masthead === false || sec.masthead_enabled === false;
  const cleanTopic = !isSecMhOff ? sanitizePdfText(sec.masthead_topic || '') : '';
  const topicStr = (cleanTopic && cleanTopic !== cleanSecName) ? ` — ${cleanTopic}` : '';
  const fullLabel = `${cleanSecName}${topicStr}`;

  // Exclusion Rule: Body pagination starts at 1 on the first primary content page
  const displayStartPage = Math.max(1, (sec.startPage || 2) - 1);
  const pageNumStr = `${itemTokens.pageNumPrefix || ''}${displayStartPage}${itemTokens.pageNumSuffix || ''}`;

  const itemY = doc.y;
  const rowHeight = itemTokens.height || 24;

  // Alternating zebra tint for visual balance and scanability
  if (idx % 2 === 0) {
    doc.rect(leftM, itemY - 2, contentW, rowHeight)
       .fill(colors.tocZebra || colors.surface);
  }

  // Chapter badge
  drawBadge(doc, tmpl, { numStr, leftM, itemY, fontBold });

  // Page number measurement for flush-right alignment
  doc.font(fontBold).fontSize(itemTokens.pageNumSize);
  const measuredPageNumW = doc.widthOfString(pageNumStr);
  const pageNumX = leftM + contentW - measuredPageNumW;

  // Chapter title
  doc.font(fontBold)
     .fontSize(itemTokens.fontSize)
     .fillColor(colors.ruleblack || colors.textmain);

  const labelX = leftM + (itemTokens.labelOffset || 30);
  const minLeaderSpan = t.leader.minSpan || 16;
  const labelMaxWidth = (pageNumX - labelX) - minLeaderSpan;
  let labelToDraw = fullLabel;
  if (doc.widthOfString(labelToDraw) > labelMaxWidth) {
    while (labelToDraw.length > 0 && doc.widthOfString(labelToDraw + '…') > labelMaxWidth) {
      labelToDraw = labelToDraw.slice(0, -1);
    }
    labelToDraw += '…';
  }
  const measuredW = doc.widthOfString(labelToDraw);
  doc.text(labelToDraw, labelX, itemY + 4, { width: labelMaxWidth, lineBreak: false });

  // Leader dots
  drawDotLeader(doc, {
    startX: labelX + measuredW + 5,
    endX: pageNumX - 4,
    y: itemY + 4,
    tmpl,
    isSub: false,
  });

  // Flush right page number
  doc.font(fontBold)
     .fontSize(itemTokens.pageNumSize)
     .fillColor(colors.tocPageNum || colors.accent || colors.ruleblack)
     .text(pageNumStr, pageNumX, itemY + 4, { width: measuredPageNumW, align: 'right' });

  const targetPage = typeof sec.startPage === 'number' && sec.startPage > 0 ? (sec.startPage - 1) : null;
  if (targetPage !== null) {
    doc.link(leftM, itemY - 2, contentW, rowHeight, targetPage);
  }

  doc.y = itemY + rowHeight + (itemTokens.paddingBottom || 2);
}

/**
 * Normalized UI component: renders a single subsection row.
 */
export function drawTocSubheadingRow(doc, tmpl, opts = {}) {
  const { h, sec, leftM, contentW, fontNormal } = opts;
  const t = getTocTokens(tmpl);
  const subTokens = t.subItem;
  const colors = tmpl.colors || {};

  const subY = doc.y;
  const cleanHeadText = sanitizePdfText(h.text || '');
  const subLabel = `${subTokens.connector || '— '}${cleanHeadText}`;

  const displayHeadPage = Math.max(1, (h.page || sec.startPage || 2) - 1);
  const subPageStr = `${subTokens.pageNumPrefix || ''}${displayHeadPage}${subTokens.pageNumSuffix || ''}`;

  doc.font(fontNormal).fontSize(subTokens.pageNumSize);
  const subPageW = doc.widthOfString(subPageStr);
  const subPageX = leftM + contentW - subPageW;

  const subX = leftM + (subTokens.indent || 34);
  const minLeaderSpan = t.leader.minSpan || 14;
  const subMaxW = (subPageX - subX) - minLeaderSpan;
  let subToDraw = subLabel;
  if (doc.widthOfString(subToDraw) > subMaxW) {
    while (subToDraw.length > 0 && doc.widthOfString(subToDraw + '…') > subMaxW) {
      subToDraw = subToDraw.slice(0, -1);
    }
    subToDraw += '…';
  }
  const measuredSubW = doc.widthOfString(subToDraw);

  doc.font(fontNormal)
     .fontSize(subTokens.fontSize)
     .fillColor(colors.tocSubText || colors.textmuted)
     .text(subToDraw, subX, subY, { width: subMaxW, lineBreak: false });

  // Subsection leader dots
  drawDotLeader(doc, {
    startX: subX + measuredSubW + 5,
    endX: subPageX - 4,
    y: subY,
    tmpl,
    isSub: true,
  });

  // Flush right subsection page number
  doc.font(fontNormal)
     .fontSize(subTokens.pageNumSize)
     .fillColor(colors.tocSubText || colors.textmuted)
     .text(subPageStr, subPageX, subY, { width: subPageW, align: 'right' });

  const targetHeadPage = typeof h.page === 'number' && h.page > 0
    ? (h.page - 1)
    : (typeof sec.startPage === 'number' && sec.startPage > 0 ? (sec.startPage - 1) : null);
  if (targetHeadPage !== null) {
    doc.link(subX, subY - 1, contentW - (subTokens.indent || 34), subTokens.rowHeight || 12, targetHeadPage);
  }

  doc.y = subY + (subTokens.rowHeight || 13);
}

/**
 * Renders Table of Contents on page 0 with optional document banner,
 * chapter rows, dots leaders, badges, and page numbers.
 */
export function renderChaptersTOC(doc, tmpl, sections, runningHeader, tocTitleInput, tocIncludeHeadings, hasCustomFonts = false, docTitle = '', docSubtitle = '', headerOptions = {}) {
  doc.switchToPage(0);
  const leftM = tmpl.margins.left;
  const rightM = tmpl.margins.right;
  const contentW = doc.page.width - leftM - rightM;

  const fontBold = getFontName(hasCustomFonts, 'bold', tmpl && tmpl.tokens?.fontFamily, doc && doc._modernFonts === true);
  const fontNormal = getFontName(hasCustomFonts, 'normal', tmpl && tmpl.tokens?.fontFamily, doc && doc._modernFonts === true);

  const tocTitle = sanitizePdfText((tocTitleInput && tocTitleInput.trim())
    ? tocTitleInput.trim().toUpperCase()
    : 'SUMÁRIO');

  const {
    showHeaderTop = true,
    customHeader = null,
    headerDate = null,
  } = headerOptions;

  // Document Title Banner: Adapted from the first block's masthead logic to function as the document title before the summary
  const firstSec = Array.isArray(sections) && sections.length > 0 ? sections[0] : null;
  const mh = firstSec?.masthead || {};
  // Invariant: Masthead is strictly opt-in. It is ON only if explicitly enabled.
  const isFirstMhOn = Boolean(
    firstSec && (
      mh.enabled === true ||
      firstSec.enable_masthead === true ||
      firstSec.masthead_enabled === true
    )
  );
  const isFirstMhOff = !isFirstMhOn;
  const mhCourse = (isFirstMhOn ? (mh.course || firstSec?.masthead_course || '') : '').trim();
  const mhTopic = (isFirstMhOn ? (mh.topic || firstSec?.masthead_topic || '') : '').trim();
  const mhPrefix = (isFirstMhOn ? (mh.prefix || firstSec?.masthead_prefix || '') : '').trim();
  const secName = (firstSec?.name || firstSec?.title || '').trim();
  const moveHeader = (isFirstMhOn && (mh.header === true || firstSec?.masthead_header === true));

  let effectiveTitle = (docTitle && docTitle !== 'Document') ? docTitle.trim() : '';
  let effectiveSubtitle = (docSubtitle || '').trim();

  // Gather all section names and titles to catch any block title fallback leaks (e.g. "Seção 1", "Bloco 1", "Capítulo 1")
  const allSecTitles = new Set();
  if (Array.isArray(sections)) {
    for (const s of sections) {
      if (s?.name) allSecTitles.add(String(s.name).trim().toUpperCase());
      if (s?.title) allSecTitles.add(String(s.title).trim().toUpperCase());
    }
  }

  // If docTitle is merely a block title (fallback) or matches generic pattern (e.g. "Seção 1", "Bloco 1"), suppress it
  if (effectiveTitle && (
    (secName && effectiveTitle.toUpperCase() === secName.toUpperCase()) ||
    allSecTitles.has(effectiveTitle.toUpperCase()) ||
    /^(SEÇÃO|BLOCO|CAPÍTULO)\s*\d+$/i.test(effectiveTitle)
  )) {
    effectiveTitle = '';
  }

  // Document Title Banner: Render if explicit docTitle/docSubtitle provided, or adapt from first block masthead if enabled
  if (!effectiveTitle) {
    if (isFirstMhOn) {
      if (mhCourse) {
        effectiveTitle = mhCourse.toUpperCase();
        if (!effectiveSubtitle && mhTopic) {
          effectiveSubtitle = mhTopic;
        }
      } else if (mhTopic) {
        effectiveTitle = mhTopic.toUpperCase();
      }
    }
  } else if (!effectiveSubtitle && isFirstMhOn && mhTopic && mhTopic.toUpperCase() !== effectiveTitle.toUpperCase()) {
    effectiveSubtitle = mhTopic;
  }

  const cleanDocTitle = sanitizePdfText(effectiveTitle);
  const cleanDocSubtitle = sanitizePdfText(effectiveSubtitle);
  const hasMastheadBanner = Boolean(cleanDocTitle || cleanDocSubtitle);

  const dateStr = (headerDate || headerOptions?.headerDate || '').trim();
  const rawHeaderTitle = (customHeader && customHeader.trim())
    ? customHeader.trim()
    : (runningHeader || '').trim();

  let headerInMasthead = false;
  let dateInMasthead = false;
  const metaLines = [];

  if (hasMastheadBanner) {
    if (moveHeader && rawHeaderTitle) {
      metaLines.push(rawHeaderTitle);
      headerInMasthead = true;
    } else if (rawHeaderTitle && (
      (cleanDocTitle && cleanDocTitle.toUpperCase() === rawHeaderTitle.toUpperCase()) ||
      (cleanDocSubtitle && cleanDocSubtitle.toUpperCase() === rawHeaderTitle.toUpperCase())
    )) {
      headerInMasthead = true;
    }

    if (dateStr) {
      metaLines.push(dateStr);
      dateInMasthead = true;
    }

    if (mhPrefix) {
      metaLines.push(mhPrefix);
    }
  }

  const pageCustomHeader = headerInMasthead ? '' : customHeader;
  const pageRunningHeader = headerInMasthead ? '' : runningHeader;
  const pageHeaderDate = dateInMasthead ? null : headerDate;

  // Unified Running Header on Page 0
  const hasPageHeaderContent = Boolean(pageCustomHeader || pageRunningHeader || pageHeaderDate);
  if (showHeaderTop && hasPageHeaderContent) {
    drawUnifiedPageHeader(doc, tmpl, {
      showHeaderTop: true,
      customHeader: pageCustomHeader,
      runningHeader: pageRunningHeader,
      headerDate: pageHeaderDate,
      hasCustomFonts,
    });
    doc.y = tmpl.margins.top + (tmpl.headheight || 14) + (tmpl.headsepline || 0.4) + 14;
  } else {
    doc.y = tmpl.margins.top;
  }
  doc.x = leftM;

  // Render Document Banner via normalized component
  if (hasMastheadBanner) {
    drawMastheadBanner(doc, tmpl, {
      cleanDocTitle,
      cleanDocSubtitle,
      metaLines,
      leftM,
      contentW,
      fontBold,
      fontNormal,
    });
  }

  // Render ToC Title Header via normalized component
  drawTocSectionHeader(doc, tmpl, {
    tocTitle,
    leftM,
    contentW,
    fontBold,
  });

  const t = getTocTokens(tmpl);
  const contentBottomY = ((doc.page && doc.page.height) || 841.89) - (tmpl.margins?.bottom || 28.35) - (tmpl.footskip || 12.5);
  const maxTocPages = Math.max(1, (firstSec && firstSec.startPage ? firstSec.startPage - 1 : 1));
  let curTocPage = 0;

  // Chapter Rows & Subheadings
  sections.forEach((sec, idx) => {
    const maxSubCount = (tocIncludeHeadings && sec.headings) ? Math.min(sec.headings.length, 4) : 0;
    const neededH = (t.item.height || 24) + (maxSubCount > 0 ? maxSubCount * (t.subItem.rowHeight || 13) + (t.subItem.groupGap || 3) : 0);
    if (doc.y + neededH > contentBottomY && curTocPage + 1 < maxTocPages) {
      curTocPage += 1;
      doc.switchToPage(curTocPage);
      if (showHeaderTop && hasPageHeaderContent) {
        drawUnifiedPageHeader(doc, tmpl, {
          showHeaderTop: true,
          customHeader: pageCustomHeader,
          runningHeader: pageRunningHeader,
          headerDate: pageHeaderDate,
          hasCustomFonts,
        });
        doc.y = tmpl.margins.top + (tmpl.headheight || 14) + (tmpl.headsepline || 0.4) + 14;
      } else {
        doc.y = tmpl.margins.top;
      }
      doc.x = leftM;
      drawTocSectionHeader(doc, tmpl, {
        tocTitle: `${tocTitle} (CONTINUAÇÃO)`,
        leftM,
        contentW,
        fontBold,
      });
    }
    drawTocChapterRow(doc, tmpl, {
      sec,
      idx,
      leftM,
      contentW,
      fontBold,
      fontNormal,
    });

    // Subheadings
    if (tocIncludeHeadings && sec.headings && sec.headings.length > 0) {
      const maxSub = Math.min(sec.headings.length, 4);
      for (let hIdx = 0; hIdx < maxSub; hIdx++) {
        drawTocSubheadingRow(doc, tmpl, {
          h: sec.headings[hIdx],
          sec,
          leftM,
          contentW,
          fontNormal,
        });
      }
      doc.y += (t.subItem.groupGap || 3.0);
    }
  });
}

