/**
 * FocusGate / PDF Engine V2: ColumnBand Architecture
 * 
 * Manages discrete multi-column vertical regions with quantized baseline grid ($G$)
 * tracking, lookahead keep-with-next budgeting, and integer partition balancing.
 * Guarantees lines in adjacent columns lock to the baseline grid across gutters.
 */

export class ColumnBand {
  /**
   * @param {object} options 
   * @param {number} [options.colCount=2]
   * @param {number} [options.gridUnit=12]
   * @param {number} [options.capacity=58] - Total slots available in this band
   * @param {number} [options.startSlot=0] - Initial vertical slot offset on page
   */
  constructor(options = {}) {
    this.colCount = Math.max(1, options.colCount || 2);
    this.G = Math.max(1, options.gridUnit || 12);
    this.capacity = Math.max(1, options.capacity || 58);
    this.startSlot = Math.max(0, options.startSlot || 0);

    this.placements = [];
    this.cursors = new Array(this.colCount).fill(0);
    this.currentColumn = 0;
    this.balanceable = true;
    this.activeTable = null; // { tableId: string, headers: object[] }
    // Ref-11 LayoutDiagnostics tracer gates (display-list.ts:70-85).
    this.panoramicTransitions = 0;
    this.tableSlices = 0;
    this.overfullColumns = 0;
  }

  /**
   * Slots remaining in the current (or specified) column.
   * @param {number} [col=this.currentColumn]
   * @returns {number}
   */
  remaining(col = this.currentColumn) {
    const used = this.cursors[col] || 0;
    return Math.max(0, this.capacity - used);
  }

  /**
   * Whether the current column is at slot 0 (fresh column).
   * @returns {boolean}
   */
  isFreshColumn() {
    return (this.cursors[this.currentColumn] || 0) === 0;
  }

  /**
   * Places an atom into the current column.
   * @param {object} atom - LayoutAtom
   * @returns {boolean} True if placed
   */
  place(atom) {
    if (!atom) return false;
    // Discard leading space atoms at the top of a column
    if (atom.discardable && this.isFreshColumn()) {
      return false;
    }

    const col = this.currentColumn;
    const slot = this.cursors[col];

    this.placements.push({
      atom,
      column: col,
      slot,
    });

    this.cursors[col] += atom.units;

    // Track active table state for automatic header re-injection
    this._trackTable(atom);

    return true;
  }

  /**
   * Notes a table-slice continuation (header re-injection across a column,
   * page, or panorama boundary). Sliced tables are never rebalanced.
   */
  _noteTableSlice() {
    this.balanceable = false;
    this.tableSlices += 1;
  }

  /**
   * Tracks active-table state for an atom about to be placed.
   * Shared by place() and placePanoramaRun() so header carry is identical
   * on column, panorama, and page boundaries.
   * @param {object} atom
   */
  _trackTable(atom) {
    if (atom.table) {
      if (atom.table.headers?.length > 0 || !this.activeTable) {
        this.activeTable = {
          tableId: atom.table.tableId,
          headers: atom.table.headers || [],
        };
      }
    } else if (atom.kind !== 'space') {
      this.activeTable = null;
    }
  }
  advanceColumn() {
    if (this.currentColumn < this.colCount - 1) {
      this.currentColumn += 1;
      // If slicing an active table across columns, re-inject repeat headers
      if (this.activeTable && this.activeTable.headers?.length > 0) {
        this._noteTableSlice();
        for (const header of this.activeTable.headers) {
          this.place(header);
        }
      }
      return true;
    }
    return false; // Reached end of columns in this band
  }

  /**
   * Balances the band using a bounded integer partition search.
   * Locks lines cleanly across column gutters without floating-point drift.
   * @param {boolean} [balance=true]
   * @returns {number} Height of the band in slots
   */
  closeBand(balance = true) {
    if (this.placements.length === 0) {
      return 0;
    }

    // Spans pin geometry: partition each maximal flow run between span
    // barriers independently (spans were balanced segment-by-segment at
    // each placePanoramaRun drain). Re-partitioning across a span would
    // drag full-width atoms back into columns.
    const hasSpans = this.placements.some(p => p.atom && p.atom.fullWidth === true);
    if (balance && this.colCount > 1 && this.balanceable) {
      if (!hasSpans) {
        const rebalanced = this._partition(this.placements, 0);
        if (rebalanced) {
          this.placements = rebalanced.placements;
          this.cursors = rebalanced.cursors;
        }
      } else {
        this._balanceFlowSegments();
      }
    }

    const heightInSlots = Math.max(...this.cursors, 0);
    return heightInSlots;
  }

  /**
   * Integer-partitions a flow run across columns from a base slot.
   * Bounded 12-try search identical to the legacy whole-band path.
   * @param {object[]} placements - Flow placements (no spans) in doc order
   * @param {number} base - Starting slot for column 0
   * @returns {{ placements: object[], cursors: number[] }|null} Null when no
   *   target fits capacity (caller keeps original geometry).
   */
  _partition(placements, base = 0) {
    const totalUnits = placements.reduce((sum, p) => sum + p.atom.units, 0);
    let target = Math.ceil(totalUnits / this.colCount);

    for (let attempt = 0; attempt < 12; attempt += 1) {
      const testCursors = new Array(this.colCount).fill(0);
      let col = 0;
      let fits = true;
      const rebalanced = [];

      for (const placement of placements) {
        // If placing this atom in current column exceeds target and column is non-empty,
        // advance to next column
        if (testCursors[col] > 0 && testCursors[col] + placement.atom.units > target) {
          col += 1;
          if (col >= this.colCount) {
            fits = false;
            break;
          }
        }

        rebalanced.push({
          atom: placement.atom,
          column: col,
          slot: base + testCursors[col],
        });
        testCursors[col] += placement.atom.units;
      }

      if (fits && base + Math.max(...testCursors) <= this.capacity) {
        return { placements: rebalanced, cursors: testCursors.map(c => base + c) };
      }

      target += 1;
    }
    return null;
  }

  /**
   * Rebalances each maximal flow run between span barriers, pinning spans
   * in doc order. Span slots anchor on the tallest column so far; flow
   * resumes below each span on all columns.
   */
  _balanceFlowSegments() {
    const rebuilt = [];
    const cursors = new Array(this.colCount).fill(0);
    let run = [];
    const flushRun = () => {
      if (run.length === 0) return;
      const base = Math.max(...cursors);
      const part = this._partition(run, base);
      if (part) {
        rebuilt.push(...part.placements);
        for (let c = 0; c < this.colCount; c++) cursors[c] = part.cursors[c];
      } else {
        // Overfull segment: keep doc-order packing on advancing columns.
        for (const p of run) {
          let col = cursors.indexOf(Math.min(...cursors));
          rebuilt.push({ atom: p.atom, column: col, slot: cursors[col] });
          cursors[col] += p.atom.units;
        }
      }
      run = [];
    };
    for (const p of this.placements) {
      if (p.atom && p.atom.fullWidth === true) {
        flushRun();
        const slot = Math.max(...cursors);
        rebuilt.push({ atom: p.atom, column: -1, slot });
        const end = slot + p.atom.units;
        for (let c = 0; c < this.colCount; c++) cursors[c] = end;
      } else {
        run.push(p);
      }
    }
    flushRun();
    this.placements = rebuilt;
    this.cursors = cursors;
  }

  /**
   * Whether the band holds no placements yet (fresh page/column top).
   * @returns {boolean}
   */
  isBandFresh() {
    return this.placements.length === 0 && this.cursors.every(c => c === 0);
  }

  /**
   * Places a full-width panoramic run (wide tables, figures) spanning the
   * entire printable width — ref-11 `placePanoramaRun` (coordinator.ts:901-938).
   *
   * 1. Balances preceding 2-column atoms (drain).
   * 2. Paints each span atom at full width below the balanced columns.
   * 3. Resumes 2-column flow below the span (all cursors advance, column 0).
   * 4. Carries repeat headers across page breaks; sliced tables freeze
   *    rebalancing; over-tall atoms on a fresh band place overfull instead
   *    of looping forever.
   *
   * @param {object[]} runAtoms - Consecutive `fullWidth === true` atoms
   * @returns {{ placed: object[], rest: object[], pendingHeaders: object[], pageBreak: boolean }}
   *   `pendingHeaders` must prefix the next band when `pageBreak` is true.
   */
  placePanoramaRun(runAtoms) {
    const run = Array.isArray(runAtoms) ? runAtoms : [];
    const empty = { placed: [], rest: run, pendingHeaders: [], pageBreak: false };
    if (run.length === 0) return empty;

    // 1. Balance preceding columns; span starts below them.
    this.drainBeforePanorama();
    this.panoramicTransitions += 1;
    let spanCursor = Math.max(0, ...this.cursors);

    const placed = [];
    for (let k = 0; k < run.length; k++) {
      const atom = run[k];
      const units = Math.max(1, atom.units || 1);
      if (spanCursor + units > this.capacity) {
        if (this.isBandFresh() && placed.length === 0) {
          // Over-tall span at page top: place atomically + diagnose
          // (ref-11 placeAll:1006-1015 overfullColumns++).
          this.overfullColumns += 1;
        } else {
          // 4. Page break: carry repeat headers to the next band when a
          // sliced table continues across the boundary.
          let pendingHeaders = [];
          if (this.activeTable && this.activeTable.headers?.length > 0) {
            this._noteTableSlice();
            pendingHeaders = [...this.activeTable.headers];
          }
          return { placed, rest: run.slice(k), pendingHeaders, pageBreak: true };
        }
      }
      this.placements.push({ atom, column: -1, slot: spanCursor });
      this._trackTable(atom);
      spanCursor += units;
      placed.push(atom);
    }

    // 3. Resume 2-column flow below the span.
    this.cursors = new Array(this.colCount).fill(spanCursor);
    this.currentColumn = 0;
    return { placed, rest: [], pendingHeaders: [], pageBreak: false };
  }

  /**
   * Drains the current band before a full-width panoramic span.
   * Balances the preceding multi-column atoms and returns the height consumed.
   * @returns {number} Height in slots consumed by the preceding balanced columns
   */
  drainBeforePanorama() {
    return this.closeBand(true);
  }
}
