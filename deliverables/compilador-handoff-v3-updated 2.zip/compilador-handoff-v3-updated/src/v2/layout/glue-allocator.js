/**
 * VerticalGlueAllocator (VGA M2) — pure seam resolver.
 *
 * Turns page slack plus seam capacities into per-seam offsets or an honest
 * ragged verdict. TeX semantics: ratio = slack / Σ capacity; accept when
 * slack is visible and no seam exceeds its own nominal stretch.
 *
 * Pure module: no layout state, no DOM, no PDFKit. Unwired (M3 wires it).
 *
 * Spec: FEATHERING-PADDING-SPEC.md §3.3. Roadmap M2.
 */

/**
 * Per-element shift application (VGA M3): ownership tagging, not Y-matching.
 * An element moves only with seams at or above its own seam (`s.seq <=
 * el.seamSeq`) in its own scope — a col:0 seam never displaces col:1 content
 * (F-4). Span-scope seams shift full-width content and everything below them
 * on the page, so they apply to every scope; span-scope elements accumulate
 * all scopes (a span below stretched columns must ride them down).
 *
 * Memoizes resolved shifts per `(scope, seq)` pair so pages with hundreds of
 * pre-wrapped text elements sharing the same seam sequence compute in O(S)
 * instead of O(E * S).
 *
 * @param {object[]} [elements=[]] display-list elements carrying {seamSeq, scope}
 * @param {object[]} [seams=[]] page seam records
 * @param {Map|object} [offsetsBySeq] seq → offset from resolveSeams()
 * @returns {Map} element index → shift in points (untagged → 0)
 */
export function computeElementShifts(elements = [], seams = [], offsetsBySeq = null) {
  const els = Array.isArray(elements) ? elements : [];
  const pageSeams = Array.isArray(seams) ? seams : [];
  const get = (seq) => {
    if (offsetsBySeq instanceof Map) return offsetsBySeq.get(seq) || 0;
    if (offsetsBySeq && typeof offsetsBySeq === 'object') return offsetsBySeq[seq] || 0;
    return 0;
  };
  const colScopes = new Set();
  for (let i = 0; i < pageSeams.length; i++) {
    const s = pageSeams[i];
    if (s && typeof s.scope === 'string' && s.scope !== 'span') colScopes.add(s.scope);
  }
  const shiftMemo = new Map();
  const resolveScopeSeqShift = (scope, seq) => {
    const key = `${scope}\0${seq}`;
    const hit = shiftMemo.get(key);
    if (hit !== undefined) return hit;

    if (scope === 'span') {
      let colMax = 0;
      for (const cs of colScopes) {
        let acc = 0;
        for (let i = 0; i < pageSeams.length; i++) {
          const s = pageSeams[i];
          if (!s || typeof s.seq !== 'number' || s.seq > seq) continue;
          if (s.scope === cs) acc += get(s.seq);
        }
        if (acc > colMax) colMax = acc;
      }
      let spanAcc = 0;
      for (let i = 0; i < pageSeams.length; i++) {
        const s = pageSeams[i];
        if (!s || typeof s.seq !== 'number' || s.seq > seq) continue;
        if (s.scope === 'span') spanAcc += get(s.seq);
      }
      const res = colMax + spanAcc;
      shiftMemo.set(key, res);
      return res;
    }

    let shift = 0;
    for (let i = 0; i < pageSeams.length; i++) {
      const s = pageSeams[i];
      if (!s || typeof s.seq !== 'number' || s.seq > seq) continue;
      if (s.scope === scope || s.scope === 'span') shift += get(s.seq);
    }
    shiftMemo.set(key, shift);
    return shift;
  };

  const shifts = new Map();
  for (let idx = 0; idx < els.length; idx++) {
    const el = els[idx];
    const seq = el && typeof el.seamSeq === 'number' ? el.seamSeq : null;
    const scope = el && typeof el.scope === 'string' ? el.scope : null;
    if (seq === null || scope === null) {
      shifts.set(idx, 0);
    } else {
      shifts.set(idx, resolveScopeSeqShift(scope, seq));
    }
  }
  return shifts;
}

/**
 * Max-scope accumulation for full-width vertical geometry (column dividers):
 * max over column scopes plus span seams. Mirrors the span branch of
 * computeElementShifts, split by Y so a divider top stretches less than its
 * bottom and ends at the flushed foot, never past it.
 */
export function accumulateMaxAtY(seams = [], offsetsBySeq = null, y = 0) {
  const pageSeams = Array.isArray(seams) ? seams : [];
  const scopes = new Set();
  for (const s of pageSeams) {
    if (s && typeof s.scope === 'string' && s.scope !== 'span') scopes.add(s.scope);
  }
  let best = 0;
  for (const cs of scopes) best = Math.max(best, accumulateAtY(pageSeams, offsetsBySeq, y, cs));
  return best + accumulateAtY(pageSeams, offsetsBySeq, y, 'span');
}

/**
 * Y-based scope-filtered accumulation for unsequenced anchors (flow-cue
 * anchors, region tails): Σ offsets of seams at or above `y` in the given
 * scope (span seams included).
 */
export function accumulateAtY(seams = [], offsetsBySeq = null, y = 0, scope = 'span') {
  const pageSeams = Array.isArray(seams) ? seams : [];
  const get = (seq) => {
    if (offsetsBySeq instanceof Map) return offsetsBySeq.get(seq) || 0;
    if (offsetsBySeq && typeof offsetsBySeq === 'object') return offsetsBySeq[seq] || 0;
    return 0;
  };
  const limit = (typeof y === 'number' && Number.isFinite(y)) ? y : 0;
  let total = 0;
  for (const s of pageSeams) {
    if (!s || typeof s.y !== 'number' || typeof s.seq !== 'number') continue;
    if (s.y > limit + 1e-9) continue;
    if (s.scope !== scope && s.scope !== 'span') continue;
    total += get(s.seq);
  }
  return total;
}

export const MIN_VISIBLE_PT = 0.5;
export const MAX_RATIO = 1.0;

const num = (v) => {
  const n = Number(v);
  return Number.isFinite(n) && n >= 0 ? n : 0;
};

export const STRETCH_CEILING_PITCH_RATIO = 0.30;

/**
 * Offsets for a column that cannot fund its whole void: the smoothest
 * distribution that stays inside the perceptibility ceiling, spending as much
 * of the ceiling as the column's seams allow.
 *
 * `budgetPt` is the total the offsets may spend. It is the column's actual
 * void: a lift is closing that void, so it must never move the column's
 * deepest element past the foot. Without this cap, `ceiling × seams` can sum
 * far past the void on a page with many seams, and the application pass has
 * to clamp the overshoot — which used to collapse multi-line atoms onto one
 * baseline.
 *
 * @param {object[]} seams seam records with numeric `capacity`
 * @param {number} [ceilingPt] per-seam ceiling in points
 * @param {number} [budgetPt] total spend ceiling in points (Infinity = uncapped)
 * @returns {number[]} offsets aligned to `seams`
 */
export function boundedLift(seams = [], ceilingPt = Infinity, budgetPt = Infinity) {
  const list = Array.isArray(seams) ? seams : [];
  const n = list.length;
  if (!n) return [];
  const RAMP_FLOOR = 0.55;
  const weights = list.map((_, i) => {
    if (n === 1) return 1;
    return RAMP_FLOOR + (1 - RAMP_FLOOR) * (i / (n - 1));
  });
  const wsum = weights.reduce((a, b) => a + b, 0) || 1;
  const allowed = list.map((s) => Math.min(num(s && s.capacity), ceilingPt));
  const weightedBudget = weights.reduce((acc, w, i) => acc + w * allowed[i], 0);
  const applied = weights.map((w, i) => {
    const share = wsum > 0 ? (weightedBudget * w) / wsum : 0;
    const raw = Math.min(allowed[i], share);
    return Math.min(ceilingPt, Math.floor(raw * 100) / 100);
  });
  const spent = applied.reduce((a, b) => a + b, 0);
  if (Number.isFinite(budgetPt) && budgetPt >= 0 && spent > budgetPt) {
    const scale = spent > 0 ? budgetPt / spent : 0;
    return applied.map((v) => Math.floor(v * scale * 100) / 100);
  }
  return applied;
}

/**
 * Foot guard for the flush application pass. Caps each element's requested
 * shift so no ink crosses `contentBottomY`, but does it BY OWNERSHIP GROUP:
 * `_placeWithSeam` stamps every element of one atom (all lines of a paragraph
 * or list item, a heading plus its decorator, a whole table) with the same
 * `(scope, seamSeq)`. Clamping each element against its OWN headroom used to
 * collapse such a group onto the foot — three lines of one list item all
 * landing on the last line's baseline. The group cap is the MINIMUM headroom
 * in the group, so the deepest element reaches the foot and every sibling
 * keeps its relative offset.
 *
 * Untagged elements (no numeric seamSeq/scope) keep the per-element guard.
 *
 * @param {object[]} [elements=[]] display-list elements
 * @param {Map|object} [shifts=null] element index → requested shift in points
 * @param {number} [contentBottomY=Infinity] region foot in page coordinates
 * @param {(el: object) => ({bottom: number}|null)} [extentOf=null] extent probe
 * @returns {Map<number, number>} element index → capped shift
 */
export function capShiftsToFoot(elements = [], shifts = null, contentBottomY = Infinity, extentOf = null) {
  const els = Array.isArray(elements) ? elements : [];
  const getShift = (i) => {
    if (shifts instanceof Map) return shifts.get(i) || 0;
    if (shifts && typeof shifts === 'object') return shifts[i] || 0;
    return 0;
  };
  const extent = typeof extentOf === 'function' ? extentOf : null;
  const headroomOf = (el) => {
    if (!extent) return undefined;
    const ext = extent(el);
    if (!ext) return undefined;
    const headroom = contentBottomY - ext.bottom;
    return Number.isFinite(headroom) ? headroom : undefined;
  };
  const groupKey = (el) => (el && typeof el.seamSeq === 'number' && typeof el.scope === 'string'
    ? `${el.scope}\0${el.seamSeq}` : null);

  const groupCap = new Map();
  for (let i = 0; i < els.length; i++) {
    const el = els[i];
    if (!el || typeof el !== 'object') continue;
    const key = groupKey(el);
    if (key === null) continue;
    if (typeof el.y !== 'number' && el.type !== 'rule') continue;
    const s = getShift(i);
    if (!(s > 0)) continue;
    const headroom = headroomOf(el);
    if (headroom === undefined) continue;
    const prev = groupCap.get(key);
    groupCap.set(key, prev === undefined ? headroom : Math.min(prev, headroom));
  }

  const out = new Map();
  for (let i = 0; i < els.length; i++) {
    const el = els[i];
    const s = getShift(i);
    if (!(s > 0)) { out.set(i, s); continue; }
    const key = groupKey(el);
    const cap = (key !== null && groupCap.has(key)) ? groupCap.get(key) : headroomOf(el);
    out.set(i, cap === undefined ? s : Math.max(0, Math.min(s, cap)));
  }
  return out;
}

/**
 * Resolves seam offsets for one page/region foot.
 * @param {object[]} [seams=[]] seam records carrying numeric `capacity`
 * @param {number} slack page slack in points
 * @param {number} [maxRatio=MAX_RATIO] acceptance ceiling
 * @returns {{ perSeam: object[], ratio: number, verdict: string, reason: string }}
 */
export function resolveSeams(seams = [], slack = 0, maxRatio = MAX_RATIO) {
  const list = Array.isArray(seams) ? seams : [];
  const caps = list.map((s) => num(s && s.capacity));
  const total = caps.reduce((a, c) => a + c, 0);
  const slackPt = typeof slack === 'number' && Number.isFinite(slack) ? slack : 0;
  const ceil = num(maxRatio) || MAX_RATIO;

  const zeroed = () => list.map((s, i) => ({
    seq: (s && s.seq !== undefined) ? s.seq : i,
    scope: (s && s.scope !== undefined) ? s.scope : null,
    capacity: caps[i],
    offset: 0,
  }));

  if (!(slackPt > MIN_VISIBLE_PT)) {
    return {
      perSeam: zeroed(),
      ratio: total > 0 ? slackPt / total : 0,
      verdict: 'ragged',
      reason: 'negligible',
    };
  }
  if (!(total > 0)) {
    return {
      perSeam: zeroed(),
      ratio: slackPt > 0 ? Infinity : 0,
      verdict: 'ragged',
      reason: 'no-capacity',
    };
  }
  const ratio = slackPt / total;
  if (ratio > ceil + 1e-9) {
    return {
      perSeam: zeroed(),
      ratio,
      verdict: 'ragged',
      reason: 'over-ratio',
    };
  }
  return {
    perSeam: list.map((s, i) => ({
      seq: (s && s.seq !== undefined) ? s.seq : i,
      scope: (s && s.scope !== undefined) ? s.scope : null,
      capacity: caps[i],
      offset: (slackPt * caps[i]) / total,
    })),
    ratio,
    verdict: 'applied',
    reason: 'applied',
  };
}
