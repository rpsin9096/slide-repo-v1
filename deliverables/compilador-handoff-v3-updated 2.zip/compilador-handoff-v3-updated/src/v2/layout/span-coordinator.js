import { TableLayoutEngine } from '../modules/table-module.js';

const ROT_D2 = new Set(['rotated_ccw', 'rotated_d2']);

export function decideTableSpan({ layoutMode = 'auto', rotDir = 'cw', panoToken = null, colW = 0, tmpl = null, legacyMode = 'compact' } = {}) {
  let mode = layoutMode || 'auto';
  if (mode === 'rotated') mode = rotDir === 'ccw' ? 'rotated_ccw' : 'rotated_cw';
  const isRotated = mode === 'rotated_cw' || mode === 'rotated_d1' || ROT_D2.has(mode);
  if (isRotated) return { span: true, motivo: 'tabela-rotacionada' };
  if (mode === 'panoramic') return { span: true, motivo: 'tabela-panoramica' };
  if (mode === 'compact') return { span: false, motivo: 'compacto' };
  const legacy = mode === 'panoramic' ? 'full_width' : (legacyMode || 'compact');
  return { span: TableLayoutEngine.isPanoramic(panoToken, colW, tmpl, legacy), motivo: 'tabela-densa' };
}

export function decideImageSpan(place) {
  return place === 'full-width'
    ? { span: true, motivo: 'imagem-full' }
    : { span: false, motivo: 'coluna' };
}

export const isSpan = (it) => !!it && (it.kind === 'table' || it.kind === 'image') && it.panoramic === true;

export function isRuleSpan(it, idx, items) {
  if (!it || it.kind !== 'rule') return false;
  const panoTbl = (x) => !!x && (x.kind === 'table' || x.kind === 'image') && x.panoramic === true;
  const prev = idx > 0 ? items[idx - 1] : null;
  const next = idx + 1 < items.length ? items[idx + 1] : null;
  if (panoTbl(prev) || panoTbl(next)) return true;
  if (prev && prev.kind === 'rule' && prev.fullWidth) return true;
  return false;
}
