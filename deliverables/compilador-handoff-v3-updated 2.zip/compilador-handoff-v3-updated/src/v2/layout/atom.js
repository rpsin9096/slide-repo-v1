/**
 * FocusGate / PDF Engine V2: Canonical Layout Atom Stream
 * 
 * Uniform, grid-quantized atomic primitive for all editorial elements
 * (lines, spaces, table rows, rules, images, and panoramic spans).
 * Enables seamless intercommunication between the text engine and embedded
 * structures, with lookahead clearance and widow/orphan suppression.
 */

export const StructRoles = Object.freeze({
  H1: 'H1',
  H2: 'H2',
  H3: 'H3',
  H4: 'H4',
  P: 'P',
  TABLE: 'Table',
  TR: 'TR',
  TH: 'TH',
  TD: 'TD',
  FIGURE: 'Figure',
  CAPTION: 'Caption',
  NOTE: 'Note',
  ARTIFACT: 'Artifact',
});

/**
 * Creates a text line atom.
 * @param {object} params
 * @returns {object} LayoutAtom
 */
export function createLineAtom(params = {}) {
  const {
    blockId = 'b0',
    units = 1,
    role = 'P',
    text = '',
    items = [],
    group = null, // { id: string, index: number, size: number }
    keepWithNext = 0,
    anchor = null, // { slug: string, title: string, level: number }
    marker = null, // { text: string, style: object }
    fullWidth = false,
    paint = null,
  } = params;

  return {
    kind: 'line',
    blockId,
    units: Math.max(1, Math.round(units)),
    role,
    text,
    items,
    group,
    keepWithNext: Math.max(0, keepWithNext || 0),
    anchor,
    marker,
    fullWidth: Boolean(fullWidth),
    discardable: false,
    paint: typeof paint === 'function' ? paint : (ctx) => [
      { type: 'tag_struct_start', role },
      { type: 'text', text, x: ctx.x, y: ctx.yTop + units * (ctx.gridUnit || 12) },
      { type: 'tag_struct_end' },
    ],
  };
}

/**
 * Creates an elastic or fixed vertical space atom.
 * @param {string} blockId 
 * @param {number} units 
 * @returns {object} LayoutAtom
 */
export function createSpaceAtom(blockId = 'b0', units = 1) {
  const u = Math.max(0, Math.round(units));
  return {
    kind: 'space',
    blockId,
    units: u,
    role: 'Artifact',
    discardable: true, // Dropped at the very top of a column/page
    fullWidth: false,
    paint: () => [],
  };
}

/**
 * Creates a horizontal rule atom.
 * @param {string} blockId 
 * @param {number} [units=1] 
 * @param {Function} [paint] 
 * @returns {object} LayoutAtom
 */
export function createRuleAtom(blockId = 'b0', units = 1, paint = null) {
  return {
    kind: 'rule',
    blockId,
    units: Math.max(1, Math.round(units)),
    role: 'Artifact',
    discardable: false,
    fullWidth: false,
    paint: typeof paint === 'function' ? paint : (ctx) => [
      {
        type: 'rule',
        x1: ctx.x,
        y1: ctx.yTop + (units * (ctx.gridUnit || 12)) / 2,
        x2: ctx.x + ctx.width,
        y2: ctx.yTop + (units * (ctx.gridUnit || 12)) / 2,
        width: 0.5,
        color: '#9CA3AF',
      },
    ],
  };
}

/**
 * Creates a row-level table atom for seamless continuation and slicing.
 * @param {object} params 
 * @returns {object} LayoutAtom
 */
export function createTableRowAtom(params = {}) {
  const {
    blockId = 'tbl0',
    tableId = 'tbl0',
    units = 1,
    cells = [],
    isHeader = false,
    repeatHeaders = [],
    fullWidth = false,
    paint = null,
  } = params;

  return {
    kind: 'tableRow',
    blockId,
    units: Math.max(1, Math.round(units)),
    role: isHeader ? 'TH' : 'TR',
    cells,
    fullWidth: Boolean(fullWidth),
    discardable: false,
    table: {
      tableId,
      headers: repeatHeaders,
      isHeader: Boolean(isHeader),
    },
    paint: typeof paint === 'function' ? paint : () => [],
  };
}

/**
 * Creates an image or figure atom.
 * @param {object} params 
 * @returns {object} LayoutAtom
 */
export function createImageAtom(params = {}) {
  const {
    blockId = 'fig0',
    assetRef = '',
    units = 10,
    fullWidth = false,
    altText = '',
    anchor = null,
    paint = null,
  } = params;

  return {
    kind: 'image',
    blockId,
    units: Math.max(1, Math.round(units)),
    role: 'Figure',
    assetRef,
    altText,
    anchor,
    fullWidth: Boolean(fullWidth),
    keepWithNext: 1, // Figures keep following captions
    discardable: false,
    paint: typeof paint === 'function' ? paint : () => [],
  };
}

/**
 * Creates a full-width panoramic span atom.
 * @param {object} params 
 * @returns {object} LayoutAtom
 */
export function createPanoramaAtom(params = {}) {
  const {
    blockId = 'span0',
    units = 2,
    role = 'P',
    paint = null,
  } = params;

  return {
    kind: 'panorama',
    blockId,
    units: Math.max(1, Math.round(units)),
    role,
    fullWidth: true,
    discardable: false,
    paint: typeof paint === 'function' ? paint : () => [],
  };
}

/**
 * Checks if placing an atom at the end of a column would create an orphan.
 * (e.g. first line of a multi-line paragraph stranded with no subsequent lines).
 * @param {object} atom 
 * @param {number} remainingSlots 
 * @param {number} [minLines=2] 
 * @returns {boolean} True if an orphan would be created
 */
export function checkOrphan(atom, remainingSlots, minLines = 2) {
  if (!atom || !atom.group) return false;
  const { index, size } = atom.group;
  if (index === 0 && size >= 2) {
    const required = Math.min(minLines, size) * atom.units;
    return remainingSlots < required;
  }
  return false;
}

/**
 * Checks if placing lines would leave a single widow line stranded for the next column.
 * @param {object} atom 
 * @param {number} remainingSlots 
 * @returns {boolean} True if a widow would be created
 */
export function checkWidow(atom, remainingSlots) {
  if (!atom || !atom.group) return false;
  const { index, size } = atom.group;
  if (size >= 3 && remainingSlots >= atom.units) {
    const fits = Math.floor(remainingSlots / Math.max(1, atom.units));
    const remainingInGroup = size - index;
    if (remainingInGroup - fits === 1 && fits >= 2) {
      return true;
    }
  }
  return false;
}
