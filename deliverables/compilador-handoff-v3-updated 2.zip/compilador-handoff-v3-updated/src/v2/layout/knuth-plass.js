/**
 * FocusGate / PDF Engine V2: Knuth-Plass Total-Fit Line Breaking Algorithm
 * Complete implementation of the 1981 Knuth & Plass breaking algorithm with:
 * - Box/glue/penalty stream generation
 * - Liang's hyphenation integration
 * - Fitness classes (tight, normal, loose, very loose)
 * - Demerits minimization with consecutive hyphen penalty
 * - Optical margin alignment / protrusion hook (hanging punctuation)
 * - Emergency feasibility pass
 */

import { hyphenPoints } from './hyphenation.js';
import { shaper } from '../fonts/shaping.js';

export const DEFAULT_KP_OPTIONS = {
  tolerance: 2.2,
  hyphenPenalty: 50,
  adjacentDemerits: 10000,
  doubleHyphenDemerits: 10000,
  finalHyphenDemerits: 5000,
  runtPenalty: 800,
  maxConsecutiveHyphens: 2,
  align: 'justify',
  protrusionRatio: 0.4,
};

const INFINITY = 10000;

function isForcedBreak(item) {
  return item && item.type === 'penalty' && item.penalty <= -INFINITY;
}

export const box = (width, text = '', value = null) => ({ type: 'box', width, text, value });
export const glue = (width, stretch = 0, shrink = 0) => ({ type: 'glue', width, stretch, shrink });
export const penalty = (width, penalty = 0, flagged = 0) => ({ type: 'penalty', width, penalty, flagged });

function isLegalBreak(items, index) {
  const item = items[index];
  if (!item) return false;
  if (item.type === 'penalty') return item.penalty < INFINITY;
  if (item.type === 'glue') return index > 0 && items[index - 1].type === 'box';
  return false;
}

function fitnessClass(ratio) {
  if (ratio < -0.5) return 0; // tight
  if (ratio <= 0.5) return 1;  // normal
  if (ratio <= 1.0) return 2;  // loose
  return 3;                    // very loose
}

function afterBreak(stream, index) {
  let i = index;
  if (stream[i]?.type === 'penalty') i += 1;
  while (i < stream.length && stream[i]?.type === 'glue') i += 1;
  return i;
}

/**
 * Optical protrusion hook: delegates to the shaper's glyph-name table
 * (TextShaper.protrusionFor) so hanging-punctuation classification stays
 * in the shaping seam. Magnitudes are identical to the legacy char-class
 * table for all previously-covered characters; guillemets («»‹›) gain
 * correct open/close classification.
 */
export function defaultProtrusion(glyphChar, fontSize = 10, protrusionRatio = 0.4, fontId = 'helvetica') {
  return shaper.protrusionFor(glyphChar, fontId, fontSize, protrusionRatio);
}

/**
 * Converts styled text runs into Knuth-Plass box/glue/penalty stream.
 * @param {Array<object>} runs 
 * @param {object} shaper 
 * @param {string} fontId 
 * @param {number} fontSize 
 * @param {object} [options={}]
 * @returns {Array<object>} KPItem stream
 */
export function buildKPItems(runs, shaper, fontId, fontSize, options = {}) {
  const items = [];
  const hyphenate = options.hyphenate !== false;
  const spaceWidth = shaper.measure(' ', fontId, fontSize);
  const hyphenWidth = shaper.measure('-', fontId, fontSize);

  runs.forEach(run => {
    const text = run.text || '';
    const marks = run.marks || {};
    const runFont = marks.code ? 'courier' : (marks.bold && marks.italic ? `${fontId}-bolditalic` : marks.bold ? `${fontId}-bold` : marks.italic ? `${fontId}-italic` : fontId);
    const runSize = marks.code ? fontSize * 0.92 : fontSize;
    const words = text.split(/(\s+)/);

    words.forEach(chunk => {
      if (!chunk) return;
      if (/^\s+$/.test(chunk)) {
        // Glue item representing whitespace
        const w = spaceWidth * chunk.length;
        items.push({
          type: 'glue',
          width: w,
          stretch: w * 0.5,
          shrink: w * 0.33,
        });
      } else {
        // Hyphenate word if eligible
        const points = hyphenate && chunk.length >= 6 ? hyphenPoints(chunk) : [];
        if (points.length === 0) {
          const w = shaper.measure(chunk, runFont, runSize);
          items.push({
            type: 'box',
            width: w,
            text: chunk,
            fontId: runFont,
            fontSize: runSize,
            lastChar: chunk[chunk.length - 1],
            firstChar: chunk[0],
            run,
          });
        } else {
          let last = 0;
          for (let pIdx = 0; pIdx < points.length; pIdx++) {
            const pt = points[pIdx];
            const syllable = chunk.slice(last, pt);
            const w = shaper.measure(syllable, runFont, runSize);
            items.push({
              type: 'box',
              width: w,
              text: syllable,
              fontId: runFont,
              fontSize: runSize,
              lastChar: syllable[syllable.length - 1],
              firstChar: syllable[0],
              run,
            });

            // Hyphen penalty opportunity
            items.push({
              type: 'penalty',
              width: hyphenWidth,
              penalty: options.hyphenPenalty || DEFAULT_KP_OPTIONS.hyphenPenalty,
              flagged: true,
              text: '-',
              fontId: runFont,
              fontSize: runSize,
            });

            last = pt;
          }
          const tail = chunk.slice(last);
          if (tail) {
            const w = shaper.measure(tail, runFont, runSize);
            items.push({
              type: 'box',
              width: w,
              text: tail,
              fontId: runFont,
              fontSize: runSize,
              lastChar: tail[tail.length - 1],
              firstChar: tail[0],
              run,
            });
          }
        }
      }
    });
  });

  return items;
}

/**
 * Knuth-Plass total-fit line breaker.
 * @param {Array<object>} items 
 * @param {number|Function} measureArg 
 * @param {object} [options={}]
 * @returns {Array<object>} Array of line objects
 */
export function breakParagraph(items, measureArg, options = {}) {
  const opts = { ...DEFAULT_KP_OPTIONS, ...options };
  if (!items || items.length === 0) return [];

  const measureFor = typeof measureArg === 'function' ? measureArg : (() => measureArg);

  // Terminate stream with glue(inf) + forced penalty
  const stream = [...items];
  const tail = stream[stream.length - 1];
  if (!isForcedBreak(tail)) {
    if (tail && tail.type === 'glue') stream.pop();
    stream.push({ type: 'glue', width: 0, stretch: 100000, shrink: 0 });
    stream.push({ type: 'penalty', width: 0, penalty: -INFINITY - 1, flagged: false });
  }

  const sumWidth = new Array(stream.length + 1).fill(0);
  const sumStretch = new Array(stream.length + 1).fill(0);
  const sumShrink = new Array(stream.length + 1).fill(0);

  for (let i = 0; i < stream.length; i++) {
    const it = stream[i];
    sumWidth[i + 1] = sumWidth[i] + (it.type === 'penalty' ? 0 : it.width);
    sumStretch[i + 1] = sumStretch[i] + (it.type === 'glue' ? it.stretch : 0);
    sumShrink[i + 1] = sumShrink[i] + (it.type === 'glue' ? it.shrink : 0);
  }

  const runPass = (tolerance, emergency) => {
    let active = [{
      position: 0,
      line: 0,
      fitness: 1,
      totalWidth: 0,
      totalStretch: 0,
      totalShrink: 0,
      totalDemerits: 0,
      previous: null,
      consecutiveHyphens: 0,
      ratio: 0,
    }];

    for (let b = 0; b < stream.length; b++) {
      if (!isLegalBreak(stream, b)) continue;
      const item = stream[b];
      const penalty = item.type === 'penalty' ? item.penalty : 0;
      const flagged = item.type === 'penalty' ? item.flagged : false;
      const candidates = [];
      const survivors = [];

      for (const node of active) {
        const lineIdx = node.line;
        const measure = measureFor(lineIdx);
        const extraWidth = item.type === 'penalty' ? item.width : 0;
        const width = sumWidth[b] - node.totalWidth + extraWidth;
        const stretch = sumStretch[b] - node.totalStretch;
        const shrink = sumShrink[b] - node.totalShrink;

        let ratio = 0;
        if (width < measure) ratio = stretch > 0 ? (measure - width) / stretch : emergency ? 0 : INFINITY;
        else if (width > measure) ratio = shrink > 0 ? (measure - width) / shrink : -INFINITY;

        const tooTight = ratio < -1;
        const feasible = !tooTight && ratio <= tolerance;
        const forced = penalty <= -INFINITY;

        if (!feasible && !forced) {
          if (!tooTight) survivors.push(node);
          continue;
        }

        if (!tooTight) survivors.push(node);
        const badness = 100 * Math.abs(ratio) ** 3;
        let demerits = 0;
        if (penalty >= 0) demerits = (1 + badness + penalty) ** 2;
        else if (penalty > -INFINITY) demerits = (1 + badness) ** 2 - penalty ** 2;
        else demerits = (1 + badness) ** 2;

        const previousFlagged = node.previous && stream[node.position]?.type === 'penalty' && stream[node.position].flagged;
        if (flagged && previousFlagged) {
          demerits += (opts.doubleHyphenDemerits || 10000) * 2;
        }

        const fitness = fitnessClass(ratio);
        if (Math.abs(fitness - node.fitness) > 1) demerits += opts.adjacentDemerits;

        const consecutive = flagged ? node.consecutiveHyphens + 1 : 0;
        if (consecutive > opts.maxConsecutiveHyphens) {
          demerits += (opts.doubleHyphenDemerits || 10000) * 4;
        }

        // Runt penalty: heavily penalize single-word trailing lines with length < 10
        const isFinal = b >= stream.length - 2;
        if (isFinal) {
          const startIdx = afterBreak(stream, node.position);
          let boxCount = 0;
          let lastBoxText = '';
          for (let sIdx = startIdx; sIdx < b; sIdx++) {
            if (stream[sIdx].type === 'box' && stream[sIdx].text) {
              boxCount += 1;
              lastBoxText = stream[sIdx].text;
            }
          }
          if (boxCount === 1 && lastBoxText.length < 10) {
            demerits += (opts.runtPenalty || 800) * 10;
          }
        }

        candidates.push({
          position: b,
          line: node.line + 1,
          fitness,
          totalWidth: sumWidth[afterBreak(stream, b)],
          totalStretch: sumStretch[afterBreak(stream, b)],
          totalShrink: sumShrink[afterBreak(stream, b)],
          totalDemerits: node.totalDemerits + demerits,
          previous: node,
          consecutiveHyphens: consecutive,
          ratio,
        });
      }

      const best = new Map();
      for (const cand of candidates) {
        const key = `${cand.line}:${cand.fitness}`;
        const ex = best.get(key);
        if (!ex || cand.totalDemerits < ex.totalDemerits) best.set(key, cand);
      }
      active = [...survivors, ...best.values()];
      if (active.length > 400) {
        active.sort((a, b2) => a.totalDemerits - b2.totalDemerits);
        active = active.slice(0, 200);
      }
      if (active.length === 0) return null;
    }

    const finished = active.filter(n => n.position === stream.length - 1);
    const pool = finished.length > 0 ? finished : active;
    if (pool.length === 0) return null;
    return pool.reduce((best, n) => (n.totalDemerits < best.totalDemerits ? n : best));
  };

  let winner = runPass(opts.tolerance, false);
  if (!winner) winner = runPass(opts.tolerance * 4, false);
  if (!winner) winner = runPass(Infinity, true);

  if (!winner) return [];

  const breaks = [];
  for (let n = winner; n && n.previous; n = n.previous) breaks.unshift(n);

  const lines = [];
  let start = 0;
  for (let i = 0; i < breaks.length; i++) {
    const node = breaks[i];
    const end = node.position;
    const measure = measureFor(i);
    const isLast = i === breaks.length - 1;
    lines.push(buildLine(stream, start, end, node.ratio, measure, isLast, opts, node.totalDemerits));
    start = afterBreak(stream, end);
  }

  return lines;
}

function buildLine(stream, start, end, ratio, measure, isLast, opts, demerits) {
  const items = [];
  let hyphenated = false;
  let textAccum = '';
  let naturalWidth = 0;

  for (let i = start; i <= end && i < stream.length; i++) {
    const it = stream[i];
    if (it.type === 'box') {
      items.push(it);
      textAccum += it.text;
      naturalWidth += it.width;
    } else if (it.type === 'glue' && i !== end) {
      items.push(it);
      textAccum += ' ';
      naturalWidth += it.width;
    } else if (it.type === 'penalty' && i === end && it.flagged) {
      items.push(it);
      textAccum += it.text || '-';
      naturalWidth += it.width;
      hyphenated = true;
    }
  }

  const lastBox = items.filter(it => it.type === 'box').pop();
  const firstBox = items.find(it => it.type === 'box');

  const rProtrusion = defaultProtrusion(hyphenated ? '-' : lastBox?.lastChar, lastBox?.fontSize || 10, opts.protrusionRatio, lastBox?.fontId);
  const lProtrusion = defaultProtrusion(firstBox?.firstChar, firstBox?.fontSize || 10, opts.protrusionRatio, firstBox?.fontId);

  return {
    items,
    text: textAccum,
    ratio,
    measure,
    naturalWidth,
    demerits,
    hyphenated,
    isLast,
    leftProtrusion: lProtrusion,
    rightProtrusion: rProtrusion,
  };
}
