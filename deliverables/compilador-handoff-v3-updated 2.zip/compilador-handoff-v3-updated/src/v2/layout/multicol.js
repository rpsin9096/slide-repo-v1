// V2 adaptation of LaTeX multicol iterative box-splitting algorithm (Frank Mittelbach)
// Measures an atomic galley, iterates target heights from ceil(total/2),
// enforces col2 <= col1 and minimizes disparity |col1 - col2|, and sets
// container height = max(col1, col2) for uniform bottom whitespace.

export class V2MulticolGalleyBalancer {
  constructor(options = {}) {
    this.lineHeight = options.lineHeight || 12;
    this.baselineGridStep = options.baselineGridStep || this.lineHeight;
    this.maxAvailableHeight = options.maxAvailableHeight || 700;
  }

  /**
   * Pre-pass: measure linear galley with margin collapsing
   */
  measureGalley(items) {
    const galley = [];
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const h = typeof item === 'number' ? item : (item.heightPt || item.height || item.h || 0);
      const mb = typeof item === 'object' && item.marginBottom !== undefined ? item.marginBottom : 0;
      const mt = typeof item === 'object' && item.marginTop !== undefined ? item.marginTop : 0;
      const breakInside = typeof item === 'object' && item.breakInside ? item.breakInside : 'auto';
      let gap = 0;
      if (i > 0) {
        const prevMb = typeof items[i - 1] === 'object' && items[i - 1].marginBottom !== undefined ? items[i - 1].marginBottom : 0;
        gap = Math.max(prevMb, mt);
      }
      galley.push({
        id: typeof item === 'object' ? (item.id || i) : i,
        rawHeight: h,
        gapBefore: gap,
        outerHeight: h + gap,
        marginBottom: mb,
        breakInside,
        item,
      });
    }
    return galley;
  }

  /**
   * Iterative target-height search and trial-splitting loop
   */
  balance(rawItems) {
    if (!rawItems || rawItems.length === 0) {
      return {
        col1: [],
        col2: [],
        height1: 0,
        height2: 0,
        col1Height: 0,
        col2Height: 0,
        containerHeight: 0,
        bottomWhitespace: this.maxAvailableHeight,
        disparity: 0,
      };
    }

    const galley = this.measureGalley(rawItems);
    if (galley.length === 1) {
      const h = Math.ceil(galley[0].rawHeight / this.lineHeight) * this.lineHeight;
      return {
        col1: [galley[0].item],
        col2: [],
        height1: h,
        height2: 0,
        col1Height: h,
        col2Height: 0,
        containerHeight: h,
        bottomWhitespace: Math.max(0, this.maxAvailableHeight - h),
        disparity: h,
      };
    }

    const totalGalleyHeight = galley.reduce((sum, g) => sum + g.outerHeight, 0);
    const lowerBoundTarget = Math.ceil(totalGalleyHeight / 2);
    let targetH = Math.ceil(lowerBoundTarget / this.lineHeight) * this.lineHeight;
    const maxSearchH = Math.min(this.maxAvailableHeight, totalGalleyHeight);

    let bestSplit = null;
    let minDisparity = Infinity;

    while (targetH <= maxSearchH + this.lineHeight) {
      let hCol1 = 0;
      const col1 = [];
      const col2 = [];

      let idx = 0;
      // 1. Fill Column 1 until next element exceeds target_height
      while (idx < galley.length) {
        const g = galley[idx];
        const nextOuter = (col1.length === 0) ? g.rawHeight : g.outerHeight;
        if (col1.length > 0 && hCol1 + nextOuter > targetH) {
          break;
        }
        col1.push(g);
        hCol1 += nextOuter;
        idx++;
      }

      // 2. Place remaining elements into Column 2
      let hCol2 = 0;
      while (idx < galley.length) {
        const g = galley[idx];
        const nextOuter = (col2.length === 0) ? g.rawHeight : g.outerHeight;
        col2.push(g);
        hCol2 += nextOuter;
        idx++;
      }

      // Degenerate-candidate guard: a target that swallowed the whole galley
      // empties col2 — an entire column of void the reader reads as a broken
      // page. Skip it: earlier targets in the search always carry col2 >= 1
      // item, and the least-lopsided fallback below never empties a column.
      if (galley.length > 1 && col2.length === 0) {
        targetH += this.lineHeight;
        continue;
      }

      // 3. Trailing margin normalization & baseline snapping
      const h1Snapped = Math.ceil(hCol1 / this.lineHeight) * this.lineHeight;
      const h2Snapped = Math.ceil(hCol2 / this.lineHeight) * this.lineHeight;
      const disparity = Math.abs(h1Snapped - h2Snapped);

      // Acceptance Criteria:
      // - height(col2) <= height(col1)
      // - |height(col1) - height(col2)| <= line_height
      if (h2Snapped <= h1Snapped) {
        if (disparity <= this.lineHeight) {
          bestSplit = {
            col1: col1.map(g => g.item),
            col2: col2.map(g => g.item),
            height1: h1Snapped,
            height2: h2Snapped,
          };
          break;
        } else if (!bestSplit || bestSplit.height2 > bestSplit.height1 || disparity < minDisparity) {
          minDisparity = disparity;
          bestSplit = {
            col1: col1.map(g => g.item),
            col2: col2.map(g => g.item),
            height1: h1Snapped,
            height2: h2Snapped,
          };
        }
      } else if (!bestSplit) {
        bestSplit = {
          col1: col1.map(g => g.item),
          col2: col2.map(g => g.item),
          height1: h1Snapped,
          height2: h2Snapped,
        };
      }

      targetH += this.lineHeight;
    }

    if (!bestSplit) {
      bestSplit = {
        col1: galley.map(g => g.item),
        col2: [],
        height1: Math.ceil(totalGalleyHeight / this.lineHeight) * this.lineHeight,
        height2: 0,
      };
    }

    const containerHeight = Math.max(bestSplit.height1, bestSplit.height2);
    const bottomWhitespace = Math.max(0, this.maxAvailableHeight - containerHeight);
    const disparity = Math.abs(bestSplit.height1 - bestSplit.height2);

    return {
      col1: bestSplit.col1,
      col2: bestSplit.col2,
      height1: bestSplit.height1,
      height2: bestSplit.height2,
      col1Height: bestSplit.height1,
      col2Height: bestSplit.height2,
      containerHeight,
      bottomWhitespace,
      disparity,
    };
  }
}
