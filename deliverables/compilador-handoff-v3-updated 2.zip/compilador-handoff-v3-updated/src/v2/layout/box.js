// V2 LayoutBox: single spatial unit. No drawing imports allowed here.
export const KEEP_WITH_NEXT_LINES = 2;

export function makeBox(kind, opts = {}) {
  const { heightPt, keepWithNextLines, breakInside, span, ...rest } = opts;
  return {
    kind,
    heightPt: heightPt ?? 0,
    keepWithNextLines: keepWithNextLines ?? (kind.startsWith('h') ? KEEP_WITH_NEXT_LINES : 0),
    breakInside: breakInside ?? 'auto',
    span: span ?? 'column',
    ...rest,
  };
}
