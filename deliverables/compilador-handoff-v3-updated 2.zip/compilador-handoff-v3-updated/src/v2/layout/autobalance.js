// V2 terminal column balancer. Typst cannot auto-balance page columns
// (official docs: place manual #colbreak(); #934 tracks native support).
// V2 does it by two-pass measurement: compile, read the tail geometry,
// binary-search a manual break over box boundaries, verify, ship.
import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { emit } from '../drivers/typst/emitter.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const REPO = path.resolve(HERE, '..', '..', '..');
const MEASURE = path.join(REPO, 'scripts', 'measure-v2-balance.mjs');

export function typstBin() {
  if (process.env.TYPST_BIN && fs.existsSync(process.env.TYPST_BIN)) return process.env.TYPST_BIN;
  const home = path.join(os.homedir(), '.local', 'bin', 'typst');
  if (fs.existsSync(home)) return home;
  return 'typst';
}

export function haveTypst() {
  try { execFileSync(typstBin(), ['--version'], { stdio: 'ignore' }); return true; }
  catch { return false; }
}

// Vendored body fonts (assets/fonts, see README). Exported through
// TYPST_FONT_PATHS (honored by every typst child process) so builds are
// hermetic across macOS/Linux/CI. TYPST_FONT_DIR overrides the directory.
const FONT_CANDIDATES = [process.env.TYPST_FONT_DIR, path.join(REPO, 'assets', 'fonts')].filter(Boolean);
export const V2_FONT_DIR = FONT_CANDIDATES.find((d) => { try { return fs.statSync(d).isDirectory(); } catch { return false; } }) ?? null;
if (V2_FONT_DIR && !process.env.TYPST_FONT_PATHS) process.env.TYPST_FONT_PATHS = V2_FONT_DIR;

function compileTo(source, dir, tag, resolveAssets) {
  const src = path.join(dir, `bal-${tag}.typ`);
  const pdf = path.join(dir, `bal-${tag}.pdf`);
  fs.writeFileSync(src, resolveAssets ? resolveAssets(source, dir) : source);
  try {
    execFileSync(typstBin(), ['compile', src, pdf], { stdio: 'pipe' });
  } catch { return null; } // invalid break site (e.g. inside table) — unusable
  return pdf;
}

function measurePdf(pdf) {
  try {
    return JSON.parse(execFileSync('node', [MEASURE, pdf, '12', '--json'], { encoding: 'utf8', stdio: 'pipe' }));
  } catch (e) {
    try { return JSON.parse((e.stdout ?? '').toString()); } catch { return null; }
  }
}

const tailOf = (m) => m.detail[m.detail.length - 1];
const TEXTISH = new Set(['para', 'list', 'quote']);
// Visual lines ≈ markdown lines, except long prose lines wrap: ~58 chars
// per 9pt column line. Rough, but the stretch pass is verified by measurement.
const CHARS_PER_LINE = 58;
function visualLines(b) {
  const textLen = (b.md ?? b.text ?? '').length; // md: full text (text is sliced to 80ch)
  return Math.max(b.lines || 1, Math.ceil(textLen / CHARS_PER_LINE));
}

// Map each box to its measured page by matching normalized text prefixes,
// monotonically (content flows forward). Spaceless matching survives Typst's
// arbitrary string splitting. Unmatchable boxes (images, math) inherit the
// previous box's page.
const normFlat = (s) => String(s ?? '').toLowerCase().normalize('NFC')
  .replace(/[ﬁﬂﬀﬃﬄﬅﬆ]/g, (c) => ({ 'ﬁ': 'fi', 'ﬂ': 'fl', 'ﬀ': 'ff', 'ﬃ': 'ffi', 'ﬄ': 'ffl', 'ﬅ': 'st', 'ﬆ': 'st' }[c]))
  .replace(/[^a-z0-9à-øā-žß]+/gi, '');
// Map each box to its measured page. Decoded PDF text has scattered
// single-glyph drops (fi ligatures, kern splits), so exact substring match
// fails; instead score pages by 8-char shingle hits (>=0.5 wins).
// Monotonic (content flows forward); unmatchable boxes (images, math)
// inherit the previous page.
function shingles(s) {
  const out = [];
  for (let i = 0; i + 8 <= s.length; i += 4) out.push(s.slice(i, i + 8));
  return out;
}
export function mapBoxesToPages(tree, detail) {
  const pageTexts = detail.map((p) => normFlat(p.text ?? ''));
  const assign = new Array(tree.length).fill(0);
  let ptr = 0;
  tree.forEach((b, i) => {
    let key = normFlat(b.text ?? '');
    if (key.length < 24) key = normFlat(`${b.text ?? ''} ${b.md ?? ''}`);
    const sh = shingles(key);
    let bestP = -1, bestS = 0;
    if (sh.length > 0) {
      for (let p = ptr; p < pageTexts.length; p++) {
        const t = pageTexts[p];
        let hit = 0;
        for (const g of sh) if (t.includes(g)) hit++;
        const s = hit / sh.length;
        if (s > bestS) { bestS = s; bestP = p; }
      }
    }
    if (bestP >= 0 && bestS >= 0.5) ptr = bestP;
    assign[i] = ptr;
  });
  return assign;
}
// Window of text boxes around the break on the short side, capped at ~350pt
// of estimated height and restricted to last-page boxes (stretching earlier
// pages would drift them). A scope boundary must not start mid-paragraph
// (para/quote cont fragments); between list items it is invisible.
const fragKind = (b) => (b.kind === 'para' || b.kind === 'quote') && b.cont;
function stretchWindow(tree, k, shortSide, valid) {
  const win = [];
  let height = 0;
  if (shortSide === 'left') {
    for (let i = k; i >= 0 && height < 350; i--) {
      const b = tree[i];
      if (!TEXTISH.has(b.kind) || (valid && !valid.has(i))) break;
      win.unshift(i);
      height += b.heightPt || 12;
    }
    while (win.length > 0 && fragKind(tree[win[0]])) win.shift();
  } else {
    let i = k + 1;
    while (i < tree.length && fragKind(tree[i])) i++;
    for (; i < tree.length && height < 350; i++) {
      const b = tree[i];
      if (!TEXTISH.has(b.kind) || (valid && !valid.has(i))) break;
      win.push(i);
      height += b.heightPt || 12;
    }
  }
  const lines = win.reduce((s, i) => s + visualLines(tree[i]), 0);
  if (win.length < 2 || lines < 3) return null;
  return { from: win[0], to: win[win.length - 1], lines };
}

function tryStretch(tree, emitOpts, dir, state, best, tolPt, valid) {
  const shortSide = best.gap > 0 ? 'left' : 'right';
  const win = stretchWindow(tree, best.k, shortSide, valid);
  const dbg = process.env.V2_BAL_DEBUG;
  if (!win) { if (dbg) console.error(`[bal] stretch: no window (k=${best.k} side=${shortSide})`); return null; }
  const extra = best.delta / win.lines;
  if (extra > 3.0) { if (dbg) console.error(`[bal] stretch: extra ${extra.toFixed(2)}pt/line too gappy`); return null; }
  if (dbg) console.error(`[bal] stretch: ${shortSide} [${win.from}..${win.to}] +${extra.toFixed(2)}pt/line`);
  state.compiles++;
  const baseLeading = emitOpts.baseLeading ?? '0.15em';
  const stretch = { ...win, leading: `${baseLeading} + ${extra.toFixed(2)}pt` };
  const source = emit(tree, { ...emitOpts, breakAfter: best.k, stretch });
  const pdf = compileTo(source, dir, state.compiles, state.resolveAssets);
  if (!pdf) return null;
  const m = measurePdf(pdf);
  if (!m || m.pages !== state.pages0) return null;
  const tail = tailOf(m);
  if (tail.skipped) return null;
  return { k: best.k, source, delta: tail.delta, gap: tail.leftBottom - tail.rightBottom, pages: m.pages, stretch };
}

// Score a break position: null when unusable (compile fail / page drift).
function tryBreak(tree, emitOpts, dir, state, k) {
  state.compiles++;
  const source = emit(tree, { ...emitOpts, breakAfter: k });
  const pdf = compileTo(source, dir, state.compiles, state.resolveAssets);
  if (!pdf) return null;
  const m = measurePdf(pdf);
  if (!m || m.pages !== state.pages0) return null;
  const tail = tailOf(m);
  if (tail.skipped) {
    if (process.env.V2_BAL_DEBUG) console.error(`[bal] k=${k} pages=${m.pages} skipped=${tail.skipped} L=${tail.left ?? 0} R=${tail.right ?? 0}`);
    return null;
  }
  if (process.env.V2_BAL_DEBUG) console.error(`[bal] k=${k} pages=${m.pages} L=${tail.left} R=${tail.right} delta=${tail.delta.toFixed(1)} gap=${(tail.leftBottom - tail.rightBottom).toFixed(1)}`);
  return { k, source, delta: tail.delta, gap: tail.leftBottom - tail.rightBottom, pages: m.pages };
}

export function autobalance(tree, emitOpts = {}, { tolPt = 12, maxCompiles = 12, resolveAssets = null } = {}) {
  const plain = () => emit(tree, emitOpts);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'v2bal-'));
  const state = { compiles: 0, pages0: 0, resolveAssets };
  try {
    const basePdf = compileTo(plain(), dir, 0, resolveAssets);
    if (!basePdf) return { source: plain(), balanced: false, reason: 'compile-failed', compiles: 0 };
    const base = measurePdf(basePdf);
    if (!base) return { source: plain(), balanced: false, reason: 'no-measure', compiles: 1 };
    state.pages0 = base.pages;
    state.compiles = 1;
    const tail = tailOf(base);
    const leftLines = tail.skipped === 'single-column' ? tail.left : 0;
    if (tail.skipped !== 'single-column' && tail.delta <= tolPt) {
      return { source: plain(), balanced: true, delta: tail.delta, pages: base.pages, compiles: 1, breakAfter: null };
    }
    if (tail.skipped === 'single-column' && leftLines <= 4) {
      return { source: plain(), balanced: true, delta: 0, pages: base.pages, compiles: 1, breakAfter: null, note: 'tiny-tail' };
    }
    // Candidate breaks: box boundaries on the MEASURED last page (never
    // directly after a heading — would orphan it at the column foot).
    // Mid-document breaks cascade chaotically, so the search is anchored on
    // geometry, not estimates. Falls back to the estimate window when text
    // mapping yields fewer than 2 last-page boxes.
    const N = tree.length;
    const lastPage = base.pages - 1;
    const assign = mapBoxesToPages(tree, base.detail);
    let lastBoxes = tree.map((_, i) => i).filter((i) => assign[i] === lastPage);
    if (lastBoxes.length < 2) {
      // Estimate fallback: walk back covering the tail's line count.
      const tailLines = tail.skipped === 'single-column' ? tail.left : tail.left + tail.right;
      let acc = 0, winStart = N - 1;
      for (let i = N - 1; i >= 0; i--) {
        acc += visualLines(tree[i]);
        winStart = i;
        if (acc >= tailLines) break;
      }
      lastBoxes = tree.map((_, i) => i).filter((i) => i >= winStart);
    }
    // Breaks may sit on the previous page too (shifting the page boundary),
    // so candidacy spans the last two measured pages.
    let twoPageStart = tree.findIndex((_, i) => assign[i] >= lastPage - 1);
    if (twoPageStart < 0) twoPageStart = 0;
    const isCand = (k) => k >= 0 && k < N - 1 && tree[k].kind !== 'heading' &&
      (k >= twoPageStart || lastBoxes.includes(k));
    // 50/50 split of the last page's visual lines as the opening guess.
    const vl = lastBoxes.map((i) => visualLines(tree[i]));
    const total = vl.reduce((s, v) => s + v, 0);
    let acc2 = 0, k0 = lastBoxes[lastBoxes.length - 1];
    for (let j = 0; j < lastBoxes.length; j++) {
      acc2 += vl[j];
      if (acc2 >= total / 2) { k0 = lastBoxes[j]; break; }
    }
    while (!isCand(k0) && k0 > lastBoxes[0]) k0--;
    let best = null;
    const consider = (k) => {
      if (!isCand(k) || state.compiles >= maxCompiles) return;
      const r = tryBreak(tree, emitOpts, dir, state, k);
      if (!r) return; // unusable (page drift): no update, keep walking
      if (!best || r.delta < best.delta) best = r;
    };
    consider(k0);
    // gap = leftBottom − rightBottom (bottom-left origin: larger y = higher).
    // gap > 0 → left column shorter → later break moves content left.
    // gap < 0 → left longer → earlier break moves content right.
    for (let step = 1; step <= 5 && state.compiles < maxCompiles && (!best || best.delta > tolPt); step++) {
      const dirn = best && best.gap > 0 ? 1 : -1;
      consider(k0 + dirn * step);
    }
    // Stretch pass (LaTeX-glue equivalent): when the best break still leaves
    // >tol, loosen leading on the short side's tail window by the measured
    // gap. Bounded (<=2.5pt/line) and verified — never shipped blind.
    if (best && best.delta > tolPt && state.compiles < maxCompiles) {
      const stretched = tryStretch(tree, emitOpts, dir, state, best, tolPt, new Set(lastBoxes));
      if (stretched && stretched.delta < best.delta - 1) best = stretched;
    }
    if (best && best.delta <= tolPt) {
      return { source: best.source, balanced: true, delta: best.delta, pages: best.pages, compiles: state.compiles, breakAfter: best.k, stretch: best.stretch ?? null };
    }
    if (best) {
      return { source: best.source, balanced: false, reason: `best-delta-${best.delta.toFixed(1)}pt`, delta: best.delta, pages: best.pages, compiles: state.compiles, breakAfter: best.k };
    }
    return { source: plain(), balanced: false, reason: 'no-valid-break', compiles: state.compiles };
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
}
