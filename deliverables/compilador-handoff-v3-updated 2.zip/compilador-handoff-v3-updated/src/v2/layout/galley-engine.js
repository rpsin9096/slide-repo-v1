/**
 * FocusGate / PDF Engine V2: Galley Engine & Layout Coordinator
 * Decoupled multi-column galley planning, anti-orphan heading lookahead, and the
 * two column-partition strategies: continuous fill (coluna corrida) and
 * two-pass Mittelbach balance.
 */

import { V2MulticolGalleyBalancer } from './multicol.js';
import { ColumnBand } from './column-band.js';
import { checkOrphan, checkWidow } from './atom.js';

export { ColumnBand };

export class AntiOrphanGuard {
  constructor(options = {}) {
    this.minLinesBelow = options.minLinesBelow || 2;
    this.defaultLineHeight = options.defaultLineHeight || 12;
    this.minHeadroom = options.minHeadroom || 24;
  }

  /**
   * Checks if an atom or item would create an orphan at the column bottom.
   * @param {object} item 
   * @param {number} remainingSlotsOrHeight 
   * @returns {boolean}
   */
  isOrphan(item, remainingSlotsOrHeight) {
    if (item?.group) {
      return checkOrphan(item, remainingSlotsOrHeight, this.minLinesBelow);
    }
    return false;
  }

  /**
   * Checks if an atom or item would leave a single trailing widow line on next page.
   * @param {object} item 
   * @param {number} remainingSlotsOrHeight 
   * @returns {boolean}
   */
  isWidow(item, remainingSlotsOrHeight) {
    if (item?.group) {
      return checkWidow(item, remainingSlotsOrHeight);
    }
    return false;
  }

  /**
   * Calculates the required vertical clearance for an element to prevent orphans.
   * Headings require their own height + space for at least minLinesBelow of subsequent content.
   * @param {object} item - Current layout item
   * @param {object[]} [subsequentItems=[]] - Following items in block
   * @returns {number} Minimum required vertical space
   */
  calculateRequiredClearance(item, subsequentItems = []) {
    const itemH = item.heightPt || item.height || 0;
    const isHeading = item.kind === 'heading' || (item.token && item.token.type === 'heading');

    if (!isHeading) {
      return itemH;
    }

    let trailingRequirement = this.minLinesBelow * this.defaultLineHeight;
    if (subsequentItems.length > 0) {
      const nextItem = subsequentItems[0];
      const nextH = nextItem.heightPt || nextItem.height || 0;
      // Caption-pair doctrine: a heading whose immediate follower is an
      // atomic block (table, image, math box) never separates from it at a
      // column seam. The atom cannot contribute "two lines below" the way
      // body text can — split by lines it is not, so its minimum company is
      // its WHOLE box. Requiring heading + atom height keeps the pair in
      // one column: measured 2026-10-03 on taskfiles/2 sampletext compact
      // mode, an H4 table lead-in placed at col1's foot by the two-line
      // approximation left its 180pt table opening col2 (and the doc-tail
      // balancer later split the same pair across both columns of a
      // nearly-empty last page).
      const followerIsAtom = nextItem
        && (nextItem.kind === 'table' || nextItem.kind === 'image' || nextItem.kind === 'math');
      if (followerIsAtom) {
        trailingRequirement = nextH;
      } else {
        trailingRequirement = Math.max(trailingRequirement, Math.min(nextH, this.minLinesBelow * this.defaultLineHeight * 2));
      }
    }

    return Math.max(itemH + trailingRequirement, this.minHeadroom);
  }
}

export class GalleyEngine {
  constructor(options = {}) {
    this.balancer = new V2MulticolGalleyBalancer(options);
    this.antiOrphan = new AntiOrphanGuard(options);
  }

  /**
   * Plans a region's two-column layout.
   * @param {object[]} items - Measured layout boxes
   * @param {object} constraints - Available height and partition strategy
   * @returns {{ col1: object[], col2: object[], unplaced: object[], continuous: boolean,
   *   keepWithNextDeferrals: number }} Column partition; `unplaced` is the tail
   *   neither column could hold (always empty for the balanced partition, which
   *   is sized to the region by the caller's shrink loop).
   */
  planColumns(items, constraints = {}) {
    const {
      availableHeight = 700,
      balance = true,
    } = constraints;

    if (!balance) {
      // Continuous fill: coluna corrida, the default flow.
      return this._continuousFill(items, availableHeight);
    }

    // Forward the real column height: the balancer's default search bound
    // (700) is smaller than most templates' column height, which collapses
    // every full page to a single column. Instance-scoped, no globals.
    this.balancer.maxAvailableHeight = availableHeight;

    // Two-pass Mittelbach balance
    const result = this.balancer.balance(items);

    return { ...result, continuous: false, keepWithNextDeferrals: 0 };
  }

  /**
   * Plans multi-column layout using discrete ColumnBands and integer partition balancing.
   * Locks lines cleanly across column gutters without floating-point drift.
   * Full-width atoms are grouped into panoramic runs (ref-11 placePanoramaRun):
   * preceding columns balance, the run spans full width, flow resumes below.
   * @param {object[]} atoms - Array of LayoutAtom objects
   * @param {object} [constraints={}]
   * @returns {{ band: ColumnBand, heightSlots: number, containerHeight: number, placements: object[], cursors: number[], unplaced: object[], pageBreak: boolean, diagnostics: object }}
   */
  planBand(atoms, constraints = {}) {
    const {
      colCount = 2,
      gridUnit = 12,
      availableHeight = 700,
      balance = true,
      startSlot = 0,
    } = constraints;

    const capacity = Math.max(1, Math.floor(availableHeight / gridUnit));
    const band = new ColumnBand({
      colCount,
      gridUnit,
      capacity,
      startSlot,
    });

    const isSpan = (a) => !!a && a.fullWidth === true;
    let i = 0;
    let pageBreak = false;
    let unplaced = [];
    while (i < atoms.length) {
      const atom = atoms[i];
      if (isSpan(atom)) {
        let j = i;
        while (j < atoms.length && isSpan(atoms[j])) j += 1;
        const res = band.placePanoramaRun(atoms.slice(i, j));
        if (res.pageBreak) {
          // Remainder (headers first) must open the next band/page.
          unplaced = [...res.pendingHeaders, ...res.rest, ...atoms.slice(j)];
          pageBreak = true;
          break;
        }
        i = j;
        continue;
      }
      if (this.antiOrphan.isOrphan(atom, band.remaining())) {
        if (!band.advanceColumn()) { unplaced = atoms.slice(i); pageBreak = true; break; }
      }
      if (band.remaining() < (atom.units || 1)) {
        if (!band.advanceColumn()) { unplaced = atoms.slice(i); pageBreak = true; break; }
      }
      band.place(atom);
      i += 1;
    }

    const heightSlots = band.closeBand(balance);
    return {
      band,
      heightSlots,
      containerHeight: heightSlots * gridUnit,
      placements: band.placements,
      cursors: band.cursors,
      unplaced,
      pageBreak,
      diagnostics: {
        panoramicTransitions: band.panoramicTransitions,
        tableSlices: band.tableSlices,
        overfullColumns: band.overfullColumns,
        balanceable: band.balanceable,
      },
    };
  }

  /**
   * Continuous fill ("coluna corrida"): col1 takes a doc-order prefix up to its
   * own capacity, col2 takes the next prefix up to the same capacity, and every
   * item neither column could hold returns as `unplaced` so the caller hands it
   * back to the stream. Nothing is skipped forward and nothing is dropped:
   * reading order stays a doc-order prefix across both columns, and a page full
   * of text puts both column feet on the region bottom without any padding
   * guesswork.
   * A heading which would close a column *alone* IS now deferred: the fit test
   * in `fill` applies to the item opening a column when that item is a heading
   * whose keep-with-next clearance does not fit AND whose next item cannot come
   * with it. Before that, a heading that happened to be the first item of a
   * column was placed unconditionally and its block continued in the next
   * column — a heading with nothing under it (sample2/bauhaus p4, gate G19).
   *
   * The deferral is reported through `unplaced`, which the caller already reads
   * (geometry-compiler.js:1952 and :1976), so it is observable and the caller
   * can act on it by shrinking the bite or starting a fresh page. The earlier
   * claim that this is "not a local fix" was true of a deferral that returned
   * an EMPTY plan: col1=[] and col2=[] passes the caller's fit test vacuously
   * and the same bite is re-planned forever (measured 2026-09-29: 2.2s ->
   * 3m13s at 97% CPU). The fix avoids that shape rather than the symptom — see
   * docs/notes/2026-09-28-continuous-fill-deferral-correction.md and
   * tests/lean/stranded-replan-bound.lean.js.
   */
  _continuousFill(items, availableHeight) {
    const col1 = [];
    const col2 = [];
    const state = { h1: 0, h2: 0, i: 0, deferrals: 0 };

    const fill = (list, key) => {
      while (state.i < items.length) {
        const item = items[state.i];
        const h = item.heightPt || item.height || 0;
        const required = this.antiOrphan.calculateRequiredClearance(item, items.slice(state.i + 1));
        // A heading that OPENS a column and cannot fit its keep-with-next
        // clearance must not be placed alone. `_continuousFill` starts col1
        // empty, so the progress guarantee (`list.length > 0`) does not apply
        // to the item opening it: the heading lands by itself, col2 then takes
        // the body, and the reader meets a bare section title at the column
        // foot. That is the strand — sample2/bauhaus p4, corpus gate G19, unit
        // gate tests/lean/continuous-fill.lean.js.
        //
        // So the item opening a column is exempt from the fit test ONLY when
        // it is not a stranded heading: a heading whose clearance cannot fit
        // here is DEFERRED, and the deferral is OBSERVABLE to the caller
        // through `unplaced` (already read at geometry-compiler.js:1952 and
        // :1976). The caller then shrinks the bite or page-breaks — the
        // contract required by
        // docs/notes/2026-09-28-continuous-fill-deferral-correction.md.
        //
        // Termination in the caller's uncapped replan loop
        // (geometry-compiler.js:1946) is certified, not assumed: see
        // tests/lean/stranded-replan-bound.lean.js, whose two probes
        // (sampletext2 x bauhaus and bauhaus_minimalist) hang under the naive
        // deferral this replaces (measured 2026-09-29: 2.2s -> 3m13s, 97% CPU)
        // because that one produced col1=[] AND col2=[] — a zero-height plan
        // that passes the caller's fit test vacuously, so the same bite is
        // re-planned forever. Here the deferral returns the heading in
        // `unplaced` while col1 stays empty, which the caller treats as a bite
        // it cannot place: it shrinks, and the heading opens the next page
        // with room for its body.
        //
        // The guarantee still holds everywhere else: a non-heading item opens a
        // column freely (an oversized one is split or page-broken by the
        // caller), a heading that FITS its clearance opens a column freely, and
        // a stream that is one lone heading keeps it.
        const isHeading = item.kind === 'heading' || (item.token && item.token.type === 'heading');
        const clearanceFits = state[key] + required <= availableHeight;
        if (isHeading && list.length === 0 && !clearanceFits && items.length > 1) {
          // `required` is the heading's own height plus `minHeadroom`/follower
          // clearance, so it can exceed the space the heading plus its FIRST
          // follower would actually need. Placing the heading is not the defect;
          // placing it ALONE is. So before deferring, check whether the heading
          // and the item that follows it both fit in this column — if they do,
          // place both and the strand cannot happen.
          const follower = items[state.i + 1];
          const pairH = h + (follower ? (follower.heightPt || follower.height || 0) : 0);
          if (!follower || pairH > availableHeight) {
            // The follower cannot come with it here. Placing the heading alone
            // is the strand; returning it unplaced is the caller's signal to
            // shrink the bite or start a fresh page, where it opens that page
            // with room for its body. Nothing is dropped.
            state.deferrals += 1;
            return;
          }
        }
        if (list.length > 0 && !clearanceFits) {
          if (isHeading) state.deferrals += 1;
          return;
        }
        list.push(item);
        state[key] += h;
        state.i += 1;
      }
    };

    fill(col1, 'h1');
    fill(col2, 'h2');

    return {
      col1,
      col2,
      height1: state.h1,
      height2: state.h2,
      col1Height: state.h1,
      col2Height: state.h2,
      containerHeight: Math.max(state.h1, state.h2),
      disparity: Math.abs(state.h1 - state.h2),
      unplaced: items.slice(state.i),
      continuous: true,
      keepWithNextDeferrals: state.deferrals,
    };
  }
}
