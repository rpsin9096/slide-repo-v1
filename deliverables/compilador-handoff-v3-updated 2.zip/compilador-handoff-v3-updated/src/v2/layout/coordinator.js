import { makeBox, KEEP_WITH_NEXT_LINES } from './box.js';
import { calibrateHeight, resolveCalOpts } from './measure-calibration.js';

// Measure: pure height budgeting, no state mutation. Segments each block
// into fine boxes (heading / para / list / table / quote / image / code /
// math / hr) so keep-with-next and terminal balancing can address them.
const isListLine = (l) => /^\s*([-*]|\d+[.)])\s+/.test(l);
const isQuoteLine = (l) => /^\s*>\s?/.test(l);
const isTableLine = (l) => /^\s*\|/.test(l);
const isHrLine = (l) => /^\s*(---|\*\*\*|___)\s*$/.test(l);
const isImageLine = (l) => /^\s*!\[[^\]]*\]\([^)]+\)\s*$/.test(l);
const isMathLine = (l) => /^\s*\$\$.+\$\$\s*$/.test(l);
const isFenceLine = (l) => /^\s*```/.test(l);
const isHeadingLine = (l) => /^#{1,6}\s/.test(l);

function segmentKind(lines, i) {
  const l = lines[i];
  if (isHeadingLine(l)) return 'heading';
  if (isFenceLine(l)) return 'code';
  if (isTableLine(l)) return 'table';
  if (isListLine(l)) return 'list';
  if (isQuoteLine(l)) return 'quote';
  if (isImageLine(l)) return 'image';
  if (isMathLine(l)) return 'math';
  if (isHrLine(l)) return 'hr';
  return 'para';
}

// Rates live in measure-calibration.js (estimateHeight); coordinator measures
// through calibrateHeight() so estimado stays byte-identical.

// Split a long prose line into clause fragments at top-level `→`, `;`
// and `,`+space (never inside code/math/link spans or brackets). Fragments
// rejoin with a single space, rendering identically, while giving the
// balancer sub-line granularity for pathological tails.
function splitClauses(line) {
  const frags = [];
  let depth = 0, inTick = false, inMath = false, start = 0;
  const cut = (end) => {
    const f = line.slice(start, end).trim();
    if (f) frags.push(f);
    start = end;
  };
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '`') inTick = !inTick;
    else if (c === '$' && !inTick) inMath = !inMath;
    else if (inTick || inMath) continue;
    else if (c === '[' || c === '(') depth++;
    else if (c === ']' || c === ')') depth = Math.max(0, depth - 1);
    else if (depth > 0) continue;
    else if (c === '→' || c === ';') cut(i + 1);
    else if (c === ',' && line[i + 1] === ' ') cut(i + 1);
  }
  const tail = line.slice(start).trim();
  if (tail) frags.push(tail);
  return frags.length > 0 ? frags : [line];
}
// Top-level list items (no leading indent) start a new unit; nested
// children become their own `cont` units (rejoined with single newlines so
// the list still renders continuously) — this gives the balancer sub-item
// granularity inside pathological lumps. Blank-line grouping is unchanged.
function splitListItems(group) {
  const units = [];
  for (const line of group) {
    const m = line.match(/^(\s*)([-*]|\d+[.)])\s+/);
    if (m && units.length > 0) units.push({ lines: [line], cont: true });
    else if (units.length === 0) units.push({ lines: [line], cont: false });
    else units[units.length - 1].lines.push(line);
  }
  return units;
}

// Expand a long unit line into clause fragments (see splitClauses).
// Continuations keep the structural marker (list indent or `>`) so the
// rejoin is seamless; para fragments need no marker (newline = space).
// Only lines >90 chars split; short lines stay atomic.
function expandClauses(unit, kind) {
  if (kind !== 'para' && kind !== 'quote' && kind !== 'list') return [unit];
  const [first, ...rest] = unit.lines;
  if (!first || first.length <= 90) return [unit];
  const marker = kind === 'list'
    ? (first.match(/^(\s*(?:[-*]|\d+[.)])\s+)/)?.[1] ?? '  ')
    : kind === 'quote' ? (first.match(/^(\s*>\s?)/)?.[1] ?? '') : '';
  const frags = splitClauses(first.slice(marker.length));
  if (frags.length <= 1) return [unit];
  // List continuations indent to content width (new bullets would lie);
  // quote continuations repeat `>` (else the quote ends); para needs none.
  const contPrefix = kind === 'list' ? ' '.repeat(marker.length) : kind === 'quote' ? marker : '';
  return frags.map((f, idx) => idx === 0
    ? { lines: [marker + f], cont: unit.cont }
    : idx === frags.length - 1
      ? { lines: [contPrefix + f, ...rest], cont: true }
      : { lines: [contPrefix + f], cont: true });
}

const plainText = (kind, mdLines) => mdLines.join(' ')
  .replace(/^#{1,6}\s*/, '').replace(/^\s*([-*]|\d+[.)]|>)\s?/, '').trim().slice(0, 80);

export function measure(blocks, opts = {}) {
  // Fase 3b: calibration behind flag; default estimado is byte-identical to
  // the former kindHeight() call (see measure-calibration.js).
  const calOpts = resolveCalOpts(opts);
  return blocks.flatMap((b) => {
    const md = String(b.markdown ?? '');
    const lines = md.split('\n');
    const out = [];
    let i = 0;
    const titled = (b.title ?? '') !== '';
    if (titled && !lines.some(isHeadingLine)) {
      out.push(makeBox('heading', {
        heightPt: 14, keepWithNextLines: KEEP_WITH_NEXT_LINES, lines: 1,
        text: b.title, md: `# ${b.title}`,
      }));
    }
    while (i < lines.length) {
      if (!lines[i].trim()) { i++; continue; }
      const kind = segmentKind(lines, i);
      const group = [lines[i++]];
      // Headings, images, hrs, math: single-line boxes. Fences run to close.
      if (kind === 'code') {
        while (i < lines.length && !isFenceLine(lines[i])) group.push(lines[i++]);
        if (i < lines.length) group.push(lines[i++]);
      } else if (kind === 'heading' || kind === 'image' || kind === 'hr' || kind === 'math') {
        // single line already taken
      } else {
        const same = kind === 'para'
          ? (l) => l.trim() && segmentKind([l], 0) === 'para'
          : (l) => l.trim() && segmentKind([l], 0) === kind;
        while (i < lines.length && same(lines[i])) group.push(lines[i++]);
      }
      // Line-level boxes for para/quote/list-items: the balancer needs
      // sub-paragraph granularity; `cont` boxes rejoin with a single
      // newline so they still render as one Typst paragraph/list.
      const units = (kind === 'para' || kind === 'quote')
        ? group.map((l, ui) => ({ lines: [l], cont: ui > 0 }))
        : kind === 'list' ? splitListItems(group)
        : [{ lines: group, cont: false }];
      units.flatMap((u) => expandClauses(u, kind)).forEach((unit) => {
        const clean = unit.lines.map((l) => l.trimEnd());
        out.push(makeBox(kind, {
          heightPt: calibrateHeight(kind, clean, calOpts),
          keepWithNextLines: kind === 'heading' ? KEEP_WITH_NEXT_LINES : 0,
          breakInside: (kind === 'image' || kind === 'table') && clean.length <= 8 ? 'avoid' : 'auto',
          lines: clean.length,
          cont: unit.cont,
          text: plainText(kind, clean),
          md: clean.join('\n'),
        }));
      });
    }
    if (out.length === 0) out.push(makeBox('para', { heightPt: 12, lines: 1, text: '' }));
    // Block masthead banner rides on the block's first box (rendered above it).
    const mh = b.masthead;
    if (mh && mh.enabled !== false && (mh.course || mh.topic)) {
      out[0].masthead = { enabled: true, course: mh.course || '', topic: mh.topic || '' };
    }
    return out;
  });
}

// Place: greedy column fill honoring keep-with-next (heading + next box stay together).
export function place(boxes, colHeightPt = 500) {
  const cols = [[], []];
  let ci = 0, used = 0;
  for (let i = 0; i < boxes.length; i++) {
    const b = boxes[i];
    const nxt = boxes[i + 1];
    const need = b.heightPt + (b.keepWithNextLines > 0 && nxt ? nxt.heightPt : 0);
    if (used + need > colHeightPt && cols[ci].length > 0) { ci = (ci + 1) % 2; used = cols[ci].reduce((s, x) => s + x.heightPt, 0); }
    cols[ci].push(b);
    used += b.heightPt;
  }
  return cols;
}

// balanceWithin: terminal column heights within pct%.
export function balanceWithin(cols, pct = 2) {
  const hs = cols.map((c) => c.reduce((s, b) => s + b.heightPt, 0));
  const [a, b] = hs;
  if (a === 0 && b === 0) return true;
  return (Math.abs(a - b) / Math.max(a, b)) * 100 <= pct;
}

// reclaimPass: drop trailing single-line page/column tail by merging back.
export function reclaimPass(cols) {
  const out = cols.map((c) => [...c]);
  const last = out[out.length - 1];
  if (last.length === 1 && (last[0].lines ?? 1) <= 1 && out.length > 1) {
    out.pop();
    out[out.length - 1].push(last[0]);
  }
  return out;
}

import { V2MulticolGalleyBalancer } from './multicol.js';
export { V2MulticolGalleyBalancer };

export function balanceColumnsLaTeX(boxes, options = {}) {
  const balancer = new V2MulticolGalleyBalancer(options);
  return balancer.balance(boxes);
}
