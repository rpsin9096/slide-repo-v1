import { getFontMetrics } from '../fonts/metrics.js';
/**
 * StretchSeam substrate (VGA M1) — Vertical Glue Allocation seam value object.
 *
 * A StretchSeam is an immutable placement-time record of one inter-item
 * boundary: where it sits, which scope it shifts, what class of gap it is,
 * and how much stretch it may absorb. It replaced a plain Y-list of gap
 * positions (ownership inferred by Y proximity) with explicit ownership tagging:
 * a seam in scope `col:0` shifts only col:0's content, so a column can flush
 * to the region foot independently of its neighbour.
 *
 * Pure module: no layout state, no PDFKit. Capacity comes from template
 * spacing tokens via rhythmForTemplate(), never literals — perceptibility
 * scales with line pitch, so the budget is a ratio property, not a point
 * total (spec F-3).
 *
 * Spec: FEATHERING-PADDING-SPEC.md §3.1–3.2. Roadmap M1.
 */

import { rhythmForTemplate } from '../templates/definitions.js';

export const SEAM_CLASS = {
  /** Inter-paragraph boundary: pitch-derived (0.35x body pitch). */
  PARA: 'para',
  /** Inter-list-item boundary: pitch-derived (0.35x body pitch). */
  LIST: 'list',
  /** Boundary above/below a full-width span: full stretch. */
  SPAN_EDGE: 'spanEdge',
  /** Heading↔body bond: capacity 0 — a heading never drifts off its body (F-6). */
  HEADING_BOND: 'headingBond',
  /** Table boundary: half a para gap (0.175x body pitch) — tabular rhythm is tighter than prose. */
  TABLE_EDGE: 'tableEdge',
  /** Block-final boundary: capacity 0 — trailing voids are semantic (F-9). */
  BLOCK_END: 'blockEnd',
};

/**
 * Classifies the boundary BELOW an item by the item's kind: stretching the
 * gap under a heading would separate it from its own body, so that boundary
 * carries the zero-capacity heading bond.
 * @param {object} [item={}] layout item with `kind`
 * @returns {string} seam class
 */
export function classForItemKind(item = {}) {
  const kind = item && item.kind;
  if (kind === 'heading') return SEAM_CLASS.HEADING_BOND;
  if (kind === 'list-item') return SEAM_CLASS.LIST;
  if (kind === 'table') return SEAM_CLASS.TABLE_EDGE;
  return SEAM_CLASS.PARA;
}

/**
 * The stretch budget for one seam, in points — how far this boundary may open
 * before the change becomes readable.
 *
 * WHY THIS IS NOT THE NOMINAL GAP. `capacityForClass()` used to return the
 * template's spacing token (paraGapPt 1.5, listGapPt 1.2) as the stretch
 * capacity, and `resolveSeams()` then bounds absorbable slack at MAX_RATIO
 * times the sum of those capacities. That conflates two different quantities:
 * the gap that ALREADY EXISTS at this boundary, and the STRETCH the boundary
 * may absorb. The consequence is a budget that shrinks as a page gets denser:
 *
 *     sampletext2/bauhaus p1  slack 82.53pt over 46 seams
 *                             budget 46 x 1.2pt = 55.20pt  -> refused
 *     sample1/base p4         slack 96.11pt over 33 seams
 *                             budget 33 x 1.2pt = 39.60pt  -> refused
 *
 * Both refusals are wrong. Closing sampletext2 p1 needs 1.79pt per seam, which
 * is 0.15x line pitch — far below anything a reader can see. The engine had 46
 * seams and would not spend 0.6pt of each, so the void went back to the
 * PARTITIONER, which leaves it as dead space at the foot of a column: the 5.02x
 * and 9.68x line-pitch holes measured in the reference-vs-current diff, both in
 * the document the user tested.
 *
 * Perceptibility is judged in LINE PITCH, not in points: a 1.5pt opening is
 * invisible at a 10.7pt pitch and obvious at a 12.4pt one for the same reader.
 * So the budget is a fraction of the page's own body pitch (spec F-3), and the
 * class weighting only scales it — it no longer replaces it. The reference
 * build e33b563 behaved as if it had ~0.25x pitch available per seam
 * (maxStretchPerLine 3.0pt on a ~11.8pt pitch); 0.35x leaves headroom over
 * what shipped and was accepted.
 */
const STRETCH_PITCH_FRACTION = 0.35;

/** Zero-capacity classes keep zero stretch regardless of the budget (F-6, F-9). */
const ZERO_CAPACITY = new Set([SEAM_CLASS.HEADING_BOND, SEAM_CLASS.BLOCK_END]);

/**
 * Stretch capacity for a seam class, as a fraction of the page's line pitch.
 * @param {string} klass seam class
 * @param {object} [tmpl={}] template definition
 * @returns {number} capacity in points (≥ 0)
 */
export function capacityForClass(klass, tmpl = {}) {
  const rhythm = rhythmForTemplate(tmpl);
  if (ZERO_CAPACITY.has(klass)) return 0;
  const budget = (rhythm.bodyPitchPt || 0) * STRETCH_PITCH_FRACTION;
  switch (klass) {
    case SEAM_CLASS.TABLE_EDGE:
      // Tabular rhythm is tighter than prose, but a table boundary is still a
      // real gap a reader can see widen. Half the prose budget, not half a
      // spacing token.
      return budget / 2;
    case SEAM_CLASS.SPAN_EDGE:
    case SEAM_CLASS.PARA:
    case SEAM_CLASS.LIST:
    default:
      return budget;
  }
}

/** The per-seam stretch budget this build grants, for probes and gates. */
export const seamStretchPitchFraction = () => STRETCH_PITCH_FRACTION;

/**
 * Builds one immutable seam record.
 * @param {object} fields { seq, page, region, scope, y, klass, capacity }
 * @returns {object} frozen seam
 */
export function makeSeam({ seq, page, region, scope, y, klass, capacity }) {
  return Object.freeze({
    seq, page, region, scope, y, klass, capacity,
  });
}

/**
 * Element content extent (VGA shared helper): the rendered bottom of one
 * display-list element. Single source of truth — it replaced per-call-site
 * extent guesswork duplicated between the compiler post-pass and the smoke
 * probe (spec F-5). Non-content types (destinations, tags, rotated pages) yield null.
 * @param {object} el display-list element
 * @returns {{ top: number, bottom: number }|null}
 */
export function elementExtent(el) {
  if (!el || typeof el !== 'object') return null;
  const t = el.type;
  if (t === 'destination' || t === 'tag_struct_start' || t === 'tag_struct_end') return null;
  if (t === 'rotated') return null; // dedicated page, box-constrained
  if (t === 'text') {
    if (typeof el.baseline === 'number') {
      const m = getFontMetrics(el.fontFamily || el.font || 'arimo', el.size || 9.5);
      return { top: el.baseline - m.capHeightPt, bottom: el.baseline + m.descenderDepth };
    }
    return { top: el.y || 0, bottom: (el.y || 0) + (el.size || 10) };
  }
  if (t === 'rect' || t === 'image') return { top: el.y || 0, bottom: (el.y || 0) + (el.h || 0) };
  if (t === 'rule') return { top: Math.min(el.y1 || 0, el.y2 || 0), bottom: Math.max(el.y1 || 0, el.y2 || 0) };
  if (t === 'bullet') return { top: (el.y || 0) - (el.r || 1.5), bottom: (el.y || 0) + (el.r || 1.5) };
  if (t === 'checkbox') return { top: el.y || 0, bottom: (el.y || 0) + 7.5 };
  return null;
}

/**
 * Derives the legacy Y-list view from seams: sorted boundary positions with
 * the 0.5pt dedupe epsilon (a boundary shared by both columns, or recorded
 * twice by a region hand-off, must not stack into one visible jump).
 * Retained as the seam module's own view for probes and diffing.
 * @param {object[]} [seams=[]] seam records
 * @param {number} [epsilon=0.5] dedupe epsilon in points
 * @returns {number[]} sorted deduped gap Y positions
 */
export function deriveGapYs(seams = [], epsilon = 0.5) {
  const ys = (Array.isArray(seams) ? seams : [])
    .map((s) => (s && typeof s.y === 'number' ? s.y : null))
    .filter((y) => typeof y === 'number');
  ys.sort((a, b) => a - b);
  return ys.filter((y, i, a) => i === 0 || Math.abs(y - a[i - 1]) > epsilon);
}
