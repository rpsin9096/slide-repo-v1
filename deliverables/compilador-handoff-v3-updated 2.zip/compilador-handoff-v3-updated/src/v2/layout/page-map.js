/**
 * FocusGate / PDF Engine V2: Lightweight Page Map Generator
 * Derives a geometric map from a DisplayList so clients can render fast page thumbnails
 * and baseline grid overlays without rasterising the PDF or running PDF.js.
 */

function round(val, decimals = 2) {
  const factor = 10 ** decimals;
  return Math.round(val * factor) / factor;
}

/**
 * Derives lightweight geometric thumbnail items from a compiled DisplayList.
 * @param {object} displayList - Compiled DisplayList
 * @returns {Array<object>} Array of PageMapPage objects
 */
export function buildPageMap(displayList) {
  if (!displayList || !Array.isArray(displayList.pages)) {
    return [];
  }

  const pageWidth = displayList.pageWidth || 595.28;
  const pageHeight = displayList.pageHeight || 841.89;

  return displayList.pages.map((page, pageIdx) => {
    const items = [];
    let currentRole = 'P';

    const processElement = (el) => {
      if (!el) return;

      if (el.type === 'tag_struct_start') {
        currentRole = el.role || 'P';
        return;
      }
      if (el.type === 'tag_struct_end') {
        currentRole = 'P';
        return;
      }

      if (el.type === 'text') {
        const x = el.x || 0;
        const y = el.y || 0;
        const w = el.width || (el.text ? el.text.length * (el.size || 10) * 0.5 : 50);
        const h = el.size || 10;
        items.push({
          x: round(x),
          y: round(y),
          w: round(w),
          h: round(h),
          kind: 'text',
          role: currentRole,
        });
      } else if (el.type === 'rect') {
        items.push({
          x: round(el.x || 0),
          y: round(el.y || 0),
          w: round(el.w || 0),
          h: round(el.h || 0),
          kind: 'rule',
          role: currentRole,
        });
      } else if (el.type === 'rule') {
        const x = Math.min(el.x1 || 0, el.x2 || 0);
        const y = Math.min(el.y1 || 0, el.y2 || 0);
        const w = Math.abs((el.x2 || 0) - (el.x1 || 0)) || 1;
        const h = Math.abs((el.y2 || 0) - (el.y1 || 0)) || 1;
        items.push({
          x: round(x),
          y: round(y),
          w: round(w),
          h: round(h),
          kind: 'rule',
          role: 'ARTIFACT',
        });
      } else if (el.type === 'image') {
        items.push({
          x: round(el.x || 0),
          y: round(el.y || 0),
          w: round(el.width || 100),
          h: round(el.height || 100),
          kind: 'image',
          role: 'FIGURE',
        });
      } else if (el.type === 'rotated') {
        for (const child of el.children || []) {
          processElement(child);
        }
      }
    };

    for (const el of page.elements || []) {
      processElement(el);
    }

    return {
      pageIndex: pageIdx,
      isRecto: pageIdx % 2 === 0,
      width: pageWidth,
      height: pageHeight,
      items,
    };
  });
}
