/**
 * FocusGate / PDF Engine V2: Isomorphic Hyphenation Engine
 * Calculates valid hyphenation break points for words across supported languages.
 */

import { getHyphenationPoints as getTableHyphenPoints } from '../modules/table-module.js';

const cache = new Map();
// Bounded isolate-level cache: sequential previews with distinct table
// vocab must not accumulate. Full clear() caused re-compute stampedes;
// trim oldest half instead. Very long tokens (e.g. base64) bypass the cache
// entirely so a single huge string can never be retained between requests.
const MAX_HYPHEN_CACHE = 2000;
const MAX_HYPHEN_WORD_LEN = 128;

/**
 * Returns array of character indices inside word where a hyphen can be placed.
 * Respects leftMin and rightMin.
 * @param {string} word 
 * @param {string} [lang='pt'] 
 * @param {number} [leftMin=2] 
 * @param {number} [rightMin=3] 
 * @returns {number[]} Array of hyphen point indices
 */
export function hyphenPoints(word, lang = 'pt', leftMin = 2, rightMin = 3) {
  if (!word || typeof word !== 'string' || word.length < leftMin + rightMin) {
    return [];
  }
  if (word.length > MAX_HYPHEN_WORD_LEN) {
    return [];
  }

  const key = `${word}|${lang}|${leftMin}|${rightMin}`;
  if (cache.has(key)) return cache.get(key);

  const rawPoints = getTableHyphenPoints(word);
  const points = rawPoints
    .map(p => (typeof p === 'number' ? p : p.index))
    .filter(idx => idx >= leftMin && word.length - idx >= rightMin);

  if (cache.size >= MAX_HYPHEN_CACHE) {
    const it = cache.keys();
    for (let i = 0; i < MAX_HYPHEN_CACHE / 2; i++) {
      const k = it.next().value;
      if (k === undefined) break;
      cache.delete(k);
    }
  }
  cache.set(key, points);
  return points;
}

/**
 * Inserts soft-hyphen characters into word at legal break points.
 * @param {string} word 
 * @param {string} [separator='\u00ad']
 * @returns {string} Hyphenated word
 */
export function hyphenateWord(word, separator = '\u00ad', lang = 'pt') {
  const points = hyphenPoints(word, lang);
  if (points.length === 0) return word;
  let out = '';
  let last = 0;
  for (const p of points) {
    out += word.slice(last, p) + separator;
    last = p;
  }
  return out + word.slice(last);
}
