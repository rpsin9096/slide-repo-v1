// Measure calibration (Fase 3): estimado reproduces coordinator.js rates
// verbatim; real mode wraps with a word measurer behind an explicit flag.
// Pure: no fonts, no PDFKit, no I/O. The measurer seam matches
// shaper.measure(word, fontId, fontSize, fontAssets) -> widthPt.

const RATES = { heading: 14, hr: 10, image: 130, math: 24 };
const PER_LINE = { list: 11, quote: 11 };

export function estimateHeight(kind, n) {
  if (RATES[kind] !== undefined) return RATES[kind];
  if (kind === 'table') return n * 14 + 10;
  if (kind === 'code') return n * 10;
  return n * (PER_LINE[kind] ?? 12);
}

const stripMarker = (line) => String(line ?? '')
  .replace(/^#{1,6}\s*/, '')
  .replace(/^\s*(?:[-*]|\d+[.)])\s+/, '')
  .replace(/^\s*>\s?/, '')
  .trim();

export function wrapLineCount(text, opts = {}) {
  const { measure, font = 'helvetica', size = 10, colWidthPt = 0 } = opts;
  const words = stripMarker(text).split(/\s+/).filter(Boolean);
  if (words.length === 0) return 1;
  if (typeof measure !== 'function' || !(colWidthPt > 0)) return 1;
  const spaceW = measure(' ', font, size);
  let lines = 1;
  let used = 0;
  for (const w of words) {
    const ww = measure(w, font, size);
    if (ww > colWidthPt) {
      if (used > 0) { lines += 1; used = 0; }
      lines += Math.ceil(ww / colWidthPt) - 1;
      used = ww % colWidthPt;
      if (used === 0) { used = colWidthPt; }
      continue;
    }
    const need = (used > 0 ? spaceW : 0) + ww;
    if (used + need <= colWidthPt) {
      used += need;
    } else {
      lines += 1;
      used = ww;
    }
  }
  return lines;
}

// Only prose kinds calibrate; structural kinds (table/code) and fixed kinds
// (heading/hr/image/math) always use the estimado rate: tables row-split
// downstream at placement and fixed boxes never wrap.
const CALIBRATED = new Set(['para', 'list', 'quote']);

// Maps loose option bags (compileOpts, driver options) to calibration opts.
//snake_case and camelCase aliases accepted; anything else -> estimado (identical).
export function resolveCalOpts(source = {}) {
  const mode = source.mode ?? source.measureMode ?? source.measure_mode;
  if (mode !== 'real') return { mode: 'estimado' };
  const colWidthPt = Number(source.colWidthPt ?? source.measureColWidthPt ?? source.measure_col_width_pt ?? 0);
  return {
    mode: 'real',
    measure: source.measure,
    colWidthPt: Number.isFinite(colWidthPt) ? colWidthPt : 0,
    font: source.font ?? source.measureFont ?? source.measure_font ?? 'helvetica',
    size: source.size ?? source.measureSize ?? source.measure_size ?? 10,
  };
}

export function calibrateHeight(kind, cleanLines, opts = {}) {
  const lines = Array.isArray(cleanLines) ? cleanLines : [cleanLines];
  const n = lines.length;
  if (opts.mode !== 'real' || !CALIBRATED.has(kind)) return estimateHeight(kind, n);
  if (typeof opts.measure !== 'function' || !(opts.colWidthPt > 0)) return estimateHeight(kind, n);
  const rate = PER_LINE[kind] ?? 12;
  let total = 0;
  for (const line of lines) {
    total += Math.max(1, wrapLineCount(line, opts)) * rate;
  }
  return total;
}
