/**
 * FocusGate / PDF Engine V2: PDFKit Vector Blaster
 * 
 * Thin, stateless visitor (~150 lines) that executes an immutable DisplayList into
 * direct PDFKit drawing commands. Makes zero layout decisions.
 */

import PDFDocument from 'pdfkit';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { renderChaptersTOC } from '../../modules/toc-module.js';
import { TEMPLATES } from '../../templates/definitions.js';
import { shaper, attachFkFontLayoutCache } from '../../fonts/shaping.js';
import { splitEmojiSegments, hasEmojiCandidate, EMOJI_FONT_FILE, EMOJI_FONT_ALIAS } from '../../fonts/emoji.js';
import { assertDriverPurity } from '../../core/display-list.js';

const FK_PARSED_CACHE = new Map();
const MAX_FK_CACHE_ENTRIES = 16;
let EmbeddedFontClass = null;

function fkCacheSet(key, value) {
  if (value) attachFkFontLayoutCache(value);
  // Isolate-level parsed-font reuse: bounded so rapid sequential compilations
  // with distinct faces cannot grow the isolate past Cloudflare memory limits.
  if (FK_PARSED_CACHE.size >= MAX_FK_CACHE_ENTRIES && !FK_PARSED_CACHE.has(key)) {
    const oldest = FK_PARSED_CACHE.keys().next().value;
    if (oldest !== undefined) FK_PARSED_CACHE.delete(oldest);
  }
  FK_PARSED_CACHE.set(key, value);
}

const origPdfDocRegisterFont = PDFDocument.prototype.registerFont;
const REGISTERED_FONT_ENTRY_CACHE = new Map();

if (typeof origPdfDocRegisterFont === 'function') {
  PDFDocument.prototype.registerFont = function(alias, src, family) {
    if (typeof src === 'string' && REGISTERED_FONT_ENTRY_CACHE.has(src) && this._registeredFonts) {
      this._registeredFonts[alias] = REGISTERED_FONT_ENTRY_CACHE.get(src);
      return this;
    }
    const res = origPdfDocRegisterFont.call(this, alias, src, family);
    if (this._registeredFonts && this._registeredFonts[alias]) {
      const entry = this._registeredFonts[alias];
      if (entry.fk) attachFkFontLayoutCache(entry.fk);
      if (typeof src === 'string' && !REGISTERED_FONT_ENTRY_CACHE.has(src)) {
        REGISTERED_FONT_ENTRY_CACHE.set(src, entry);
      }
    }
    return res;
  };
}

const origPdfDocFont = PDFDocument.prototype.font;
PDFDocument.prototype.font = function(src, family, size) {
  if (typeof src === 'string' && this._registeredFonts && this._registeredFonts[src]) {
    const reg = this._registeredFonts[src];
    if (reg.src && typeof reg.src === 'object' && reg.src._fontFile) {
      if (this._fontFamilies[src]) {
        this._font = this._fontFamilies[src];
        if (size != null) this.fontSize(size);
        return this;
      }
      if (EmbeddedFontClass && FK_PARSED_CACHE.has(reg.src._fontFile)) {
        const fkFont = FK_PARSED_CACHE.get(reg.src._fontFile);
        const id = `F${++this._fontCount}`;
        const embedded = new EmbeddedFontClass(this, fkFont, id);
        this._font = embedded;
        this._fontFamilies[src] = embedded;
        if (size != null) this.fontSize(size);
        return this;
      }
    }
  }
  const res = origPdfDocFont.call(this, src, family, size);
  if (this._font && this._font.font) {
    attachFkFontLayoutCache(this._font.font);
    if (typeof this._font.font.createSubset === 'function') {
      if (!EmbeddedFontClass) EmbeddedFontClass = this._font.constructor;
      const reg = typeof src === 'string' && this._registeredFonts && this._registeredFonts[src];
      if (reg && reg.src && reg.src._fontFile && !FK_PARSED_CACHE.has(reg.src._fontFile)) {
        fkCacheSet(reg.src._fontFile, this._font.font);
      }
    }
  }
  return res;
};

// Vendored body fonts (assets/fonts, Arimo family: Arial-metric clone with
// broad Latin/Greek/Cyrillic + symbol coverage incl. → — – “ ”).
// Resolved hermetically: repo checkout first, CWD second, no system dependency.
const RESOLVED_V2_FONT_PATHS = new Map();

// workerd leaves `import.meta.url` undefined; fileURLToPath(undefined) throws
// during module evaluation and Cloudflare rejects the script (error 10021).
// Workers use the embedded FontsPort adapter and never need a disk path.
function resolveBlasterModuleDir() {
  try {
    return import.meta.url ? path.dirname(fileURLToPath(import.meta.url)) : null;
  } catch {
    return null;
  }
}

const BLASTER_DIR = resolveBlasterModuleDir();

function resolveV2Font(file) {
  if (RESOLVED_V2_FONT_PATHS.has(file)) return RESOLVED_V2_FONT_PATHS.get(file);
  const candidates = [];
  if (BLASTER_DIR) candidates.push(path.join(BLASTER_DIR, '..', '..', '..', '..', 'assets', 'fonts', file));
  candidates.push(path.join(process.cwd(), 'assets', 'fonts', file));
  for (const p of candidates) {
    try {
      if (fs.existsSync(p)) {
        RESOLVED_V2_FONT_PATHS.set(file, p);
        return p;
      }
    } catch { /* next */ }
  }
  RESOLVED_V2_FONT_PATHS.set(file, null);
  return null;
}

const V2_FONT_FILES = {
  V2Sans: 'Arimo-Regular.ttf',
  V2SansBold: 'Arimo-Bold.ttf',
  V2SansOblique: 'Arimo-Italic.ttf',
  V2SansBoldOblique: 'Arimo-BoldItalic.ttf',
  AppSans: 'Arimo-Regular.ttf',
  AppSansBold: 'Arimo-Bold.ttf',
  AppSansOblique: 'Arimo-Italic.ttf',
  AppSansBoldOblique: 'Arimo-BoldItalic.ttf',
  V2Modern: 'Inter-Regular.ttf',
  V2ModernBold: 'Inter-Bold.ttf',
  V2ModernItalic: 'Inter-Italic.ttf',
  V2ModernBoldItalic: 'Inter-SemiBoldItalic.ttf',
  AppModern: 'Inter-Regular.ttf',
  AppModernMedium: 'Inter-Regular.ttf',
  AppModernSemiBold: 'Inter-Bold.ttf',
  AppModernItalic: 'Inter-Italic.ttf',
  AppModernSemiBoldItalic: 'Inter-SemiBoldItalic.ttf',
  V2Emoji: EMOJI_FONT_FILE,
  AppEmoji: EMOJI_FONT_FILE,
};

function registerV2Fonts(doc, fontAssets = null) {
  try {
    for (const [alias, file] of Object.entries(V2_FONT_FILES)) {
      let registered = false;
      if (fontAssets && typeof fontAssets.readBuffer === 'function') {
        try {
          const buf = fontAssets.readBuffer(file);
          if (buf) {
            doc.registerFont(alias, buf);
            registered = true;
          }
        } catch { /* fall through to disk path */ }
      }
      if (!registered) {
        const resolve = fontAssets && typeof fontAssets.resolvePath === 'function'
          ? (f) => fontAssets.resolvePath(f)
          : resolveV2Font;
        const p = resolve(file);
        if (p) doc.registerFont(alias, p);
      }
    }
    doc._v2Fonts = true;
    doc._modernFonts = true;
    return true;
  } catch {
    doc._v2Fonts = false;
    doc._modernFonts = false;
    return false;
  }
}

// Non-breaking spaces (U+00A0/U+2007/U+202F): the vendored Arimo build
// crashes fontkit's CBox parser on these glyphs (proven DataView throw).
// v1 parity keeps the glue (unbreakable during layout — see the wrapper's
// BREAKABLE_WS) but emits a regular space GLYPH (v1 output contains zero
// NBSP glyphs, proven by extraction). Same advance family, zero crash,
// byte-identical visuals.
function nbspToSpaces(text) {
  const s = String(text ?? '');
  if (
    s.indexOf('\u00A0') === -1 &&
    s.indexOf('\u2007') === -1 &&
    s.indexOf('\u202F') === -1
  ) {
    return s;
  }
  return s.replace(/[\u00A0\u2007\u202F]/g, ' ');
}

function mapV2Font(rawFont, runStyle, hasCustom, tmplId = null) {
  const lFont = (rawFont || 'helvetica').toLowerCase();
  const baseBold = lFont.includes('bold');
  const baseItalic = lFont.includes('oblique') || lFont.includes('italic');
  const style = runStyle || 'normal';
  const isScript = style === 'math-sub' || style === 'math-super';
  if (!hasCustom) {
    if (style === 'code' || lFont === 'courier') return 'Courier';
    if ((baseBold || style === 'bold' || style === 'bold_italic') && (baseItalic || style === 'italic' || style === 'bold_italic')) return 'Helvetica-BoldOblique';
    if (baseBold || style === 'bold') return 'Helvetica-Bold';
    if (baseItalic || style === 'italic' || style === 'math' || isScript) return 'Helvetica-Oblique';
    if (lFont.startsWith('times')) return 'Times-Roman';
    return 'Helvetica';
  }
  // NOTE: code/mono maps to V2Sans (no mono TTF vendored yet; Courier
  // builtin lacks →/symbol coverage, which breaks math parity).
  if (style === 'code' || lFont === 'courier') return 'V2Sans';
  if (lFont.startsWith('times')) return 'V2SansOblique';
  const wantBold = baseBold || style === 'bold' || style === 'bold_italic';
  const wantItalic = baseItalic || style === 'italic' || style === 'bold_italic' || style === 'math' || isScript;

  if (tmplId === 'bauhaus_minimalist') {
    if (wantBold && wantItalic) return 'V2ModernBoldItalic';
    if (wantBold) return 'V2ModernBold';
    if (wantItalic) return 'V2ModernItalic';
    return 'V2Modern';
  }

  if (wantBold && wantItalic) return 'V2SansBoldOblique';
  if (wantBold) return 'V2SansBold';
  if (wantItalic) return 'V2SansOblique';
  return 'V2Sans';
}

function baseStyleOf(rawFont) {
  const l = (rawFont || '').toLowerCase();
  if (l.includes('bold')) return 'bold';
  if (l.includes('oblique') || l.includes('italic')) return 'italic';
  if (l === 'courier') return 'code';
  return 'normal';
}

/**
 * Resolves the emoji fallback alias when it actually registered on this
 * document, else null (caller keeps the base font: today's behavior, no
 * crash when the TTF is absent).
 */
function emojiFontFor(doc) {
  try {
    if (doc && doc._registeredFonts && doc._registeredFonts[EMOJI_FONT_ALIAS]) {
      return EMOJI_FONT_ALIAS;
    }
  } catch { /* fall through to null */ }
  return null;
}

const WORD_MEASURE_CACHE = new Map();
// Fallback script nudges (× base font size, page space, down-positive).
const MATH_SUB_NUDGE = 0.10; // down — subs sit fully below like ₁
const MATH_SUPER_NUDGE = 0.50; // up — supers sit fully above like ²
// Bounded isolate-level LRU: expanded to 16,384 entries so multi-document
// and large 40KB documents never thrash mid-compile while staying < 500 KB.
const MAX_WORD_CACHE_ENTRIES = 16384;
const MAX_CACHED_WORD_LEN = 64;

let _singletonMeasureDoc = null;
let _singletonMeasureFontAssets = null;

function getSharedMeasureDoc(fontAssets) {
  if (!_singletonMeasureDoc || _singletonMeasureFontAssets !== fontAssets) {
    _singletonMeasureDoc = new PDFDocument({
      autoFirstPage: false,
      size: 'A4',
      margins: { top: 0, bottom: 0, left: 0, right: 0 },
    });
    registerV2Fonts(_singletonMeasureDoc, fontAssets);
    _singletonMeasureFontAssets = fontAssets;
  }
  return _singletonMeasureDoc;
}

/**
 * Live-font measure context for the compiler's word wrapper.
 * Reuses a single shared PDFKit instance per isolate with identical font resolution
 * and caches computed word widths in an isolate-level LRU map.
 * @param {string} [tmplId=null] - Template identifier for font mapping
 * @param {object} [fontAssets=null] - FontsPort asset provider
 * @returns {{ measure: (word: string, fontName: string, size: number) => number|null, dispose: () => void, measureImage: (buf: Buffer) => object|null, hasCustom: boolean }}
 */
const MEASURE_CTX_CACHE = new Map();

export function createMeasureContext(tmplId = null, fontAssets = null) {
  const doc = getSharedMeasureDoc(fontAssets);
  const ctxKey = `${tmplId || 'base'}`;
  if (_singletonMeasureFontAssets === fontAssets && MEASURE_CTX_CACHE.has(ctxKey)) {
    return MEASURE_CTX_CACHE.get(ctxKey);
  }
  const hasCustom = doc._v2Fonts === true;
  const emojiFont = emojiFontFor(doc);

  // Pre-compute mapped font names for standard compiler font keys
  const fontMap = {
    helvetica: mapV2Font('helvetica', 'normal', hasCustom, tmplId),
    'helvetica-bold': mapV2Font('helvetica-bold', 'normal', hasCustom, tmplId),
    'helvetica-oblique': mapV2Font('helvetica-oblique', 'normal', hasCustom, tmplId),
    courier: mapV2Font('courier', 'normal', hasCustom, tmplId),
  };

  const measure = (word, fontName, size) => {
    const cleanWord = nbspToSpaces(word || '');
    const mappedFont = fontMap[fontName] || mapV2Font(fontName, 'normal', hasCustom, tmplId);
    const cacheable = cleanWord.length <= MAX_CACHED_WORD_LEN;
    const cacheKey = cacheable ? `${mappedFont}\0${size}\0${cleanWord}` : null;
    if (cacheable) {
      const cached = WORD_MEASURE_CACHE.get(cacheKey);
      if (cached !== undefined) return cached;
    }

    // Emoji-aware width: emoji runs measure on the fallback face, body
    // runs on the mapped face; the sum keeps wrap breaks == render breaks.
    const widthOf = (text, font) => {
      doc.font(font).fontSize(size);
      return doc.widthOfString(text);
    };
    const measureWord = () => {
      const eFont = emojiFont && hasEmojiCandidate(cleanWord) ? emojiFont : null;
      if (!eFont) return widthOf(cleanWord, mappedFont);
      let w = 0;
      for (const part of splitEmojiSegments(cleanWord)) {
        w += widthOf(part.text, part.emoji ? eFont : mappedFont);
      }
      return w;
    };

    let measured;
    try {
      measured = measureWord();
    } catch {
      measured = shaper.measure(word, fontName, size, fontAssets);
    }

    if (cacheable) {
      if (WORD_MEASURE_CACHE.size >= MAX_WORD_CACHE_ENTRIES) {
        const it = WORD_MEASURE_CACHE.keys();
        for (let i = 0; i < 4096; i++) {
          const k = it.next().value;
          if (k === undefined) break;
          WORD_MEASURE_CACHE.delete(k);
        }
      }
      WORD_MEASURE_CACHE.set(cacheKey, measured);
    }
    return measured;
  };

  measure._isStandardLiveMeasure = true;
  measure._tmplId = tmplId || 'base';

  const measureImage = (buf) => {
    if (!buf) return null;
    try {
      const img = doc.openImage(buf);
      const dims = { width: img.width, height: img.height };
      try {
        if (doc._imageRegistry) {
          for (const k of Object.keys(doc._imageRegistry)) {
            if (doc._imageRegistry[k] === img) delete doc._imageRegistry[k];
          }
        }
      } catch { /* registry shape differs per pdfkit version */ }
      return dims;
    } catch {
      return null;
    }
  };

  const dispose = () => {
    // Shared document stays active across compilations in the isolate
  };

  const ctxObj = { measure, measureImage, dispose, hasCustom };
  if (_singletonMeasureFontAssets === fontAssets && MEASURE_CTX_CACHE.size < 16) {
    MEASURE_CTX_CACHE.set(ctxKey, ctxObj);
  }
  return ctxObj;
}

export class PDFKitVectorBlaster {
  /**
   * Blasts a DisplayList into a live PDFKit document and returns the binary Buffer.
   * @param {object} displayList - The compiled DisplayList
   * @param {object} [options={}]
   * @returns {Promise<Buffer>} Complete binary PDF buffer
   */
  static async blast(displayList, options = {}) {
    return new Promise((resolve, reject) => {
      try {
        assertDriverPurity(displayList, 'pdfkit');
        const isTagged = Boolean(options.tagged);
        const pinnedDate = options.timestamp ? new Date(options.timestamp) : (displayList.createdAt ? new Date(displayList.createdAt) : null);
        const needsBufferPages = Boolean(displayList.toc && displayList.toc.enabled);
        const pdfOpts = {
          autoFirstPage: false,
          bufferPages: needsBufferPages,
          size: 'A4',
          margins: { top: 0, bottom: 0, left: 0, right: 0 },
          // Disabling pure-JS flate compression reduces compile CPU time by ~75%
          // allowing execution well within Cloudflare Worker 10ms CPU limits.
          // Cloudflare edge CDN automatically applies HTTP gzip/brotli transfer compression.
          compress: options.compress !== undefined ? Boolean(options.compress) : false,
        };
        if (isTagged) {
          pdfOpts.tagged = true;
        }
        if (pinnedDate) {
          pdfOpts.info = {
            CreationDate: pinnedDate,
            ModDate: pinnedDate,
            Producer: 'Editorial Engine v2 (PDFKit)',
            Creator: 'Editorial Engine v2',
          };
        }

        const doc = new PDFDocument(pdfOpts);

        const chunks = [];
        doc.on('data', chunk => chunks.push(chunk));
        doc.on('end', () => {
          const buffer = Buffer.concat(chunks);
          chunks.length = 0;
          doc.removeAllListeners();
          if (typeof doc.destroy === 'function') {
            try { doc.destroy(); } catch {}
          }
          buffer.pagination = displayList.pagination || {
            totalPages: displayList.totalPages || displayList.pages.length,
            hasToC: Boolean(displayList.toc && displayList.toc.enabled),
            chaptersToc: Boolean(displayList.toc && displayList.toc.enabled),
            tocPage: (displayList.toc && displayList.toc.enabled) ? 1 : null,
            sections: displayList.toc ? displayList.toc.sections : [],
          };
          resolve(buffer);
        });
        doc.on('error', err => {
          chunks.length = 0;
          doc.removeAllListeners();
          if (typeof doc.destroy === 'function') {
            try { doc.destroy(); } catch {}
          }
          reject(err);
        });

        registerV2Fonts(doc, options.fontAssets || null);

        const tmplId = displayList.template || options.template || null;

        // Render each page
        for (const page of displayList.pages) {
          doc.addPage({
            size: 'A4',
            margins: { top: 0, bottom: 0, left: 0, right: 0 },
          });

          for (const el of page.elements) {
            PDFKitVectorBlaster._renderElement(doc, el, tmplId);
          }
        }

        // Render Table of Contents on page 0 if enabled
        if (displayList.toc && displayList.toc.enabled) {
          const tmpl = TEMPLATES[tmplId] || TEMPLATES.base;
          renderChaptersTOC(
            doc,
            tmpl,
            displayList.toc.sections,
            displayList.toc.runningHeader,
            displayList.toc.title,
            displayList.toc.includeHeadings,
            doc._v2Fonts === true,
            displayList.toc.docTitle,
            displayList.toc.docSubtitle,
            displayList.toc.headerOptions || {}
          );
        }

        doc.end();
      } catch (err) {
        reject(err);
      }
    });
  }

  static _renderElement(doc, el, tmplId = null) {
    if (el.type === 'tag_struct_start') {
      if (doc.options && doc.options.tagged) {
        const roleMap = {
          H1: 'H1', H2: 'H2', H3: 'H3', P: 'P',
          TABLE: 'Table', TR: 'TR', TH: 'TH', TD: 'TD',
          FIGURE: 'Figure', CAPTION: 'Caption', ARTIFACT: 'Artifact',
        };
        const roleKey = String(el.role || 'P').toUpperCase();
        const pdfRole = roleMap[roleKey] || 'P';
        if (pdfRole === 'Artifact') {
          doc.markContent('Artifact');
        } else {
          const content = doc.markStructureContent(pdfRole, el.alt ? { alt: el.alt } : {});
          doc._structStack = doc._structStack || [];
          doc._structStack.push({ role: pdfRole, content });
        }
      }
      return;
    }
    if (el.type === 'tag_struct_end') {
      if (doc.options && doc.options.tagged) {
        doc.endMarkedContent();
        if (doc._structStack && doc._structStack.length > 0) {
          const entry = doc._structStack.pop();
          if (entry && entry.content) {
            doc.addStructure(doc.struct(entry.role, [entry.content]));
          }
        }
      }
      return;
    }

    if (el.type === 'rotated') {
      doc.save();
      const boxW = el.boxW || el.w || 0;
      const boxH = el.boxH || el.w || 0;
      const tblW = el.w || 0;
      const tblH = el.h || 0;
      const angle = el.angle ?? 90;

      let tx, ty;
      if (angle === -90) {
        tx = (el.x || 0) + (boxW - tblH) / 2;
        ty = (el.y || 0) + (boxH + tblW) / 2;
      } else {
        tx = (el.x || 0) + (boxW + tblH) / 2;
        ty = (el.y || 0) + Math.max(0, (boxH - tblW) / 2);
      }

      doc.translate(tx, ty);
      doc.rotate(angle, { origin: [0, 0] });
      for (const child of el.children || []) {
        PDFKitVectorBlaster._renderElement(doc, child, tmplId);
      }
      doc.restore();
    } else if (el.type === 'rect') {
      doc.save();
      if (el.radius) {
        doc.roundedRect(el.x, el.y, el.w, el.h, el.radius);
      } else {
        doc.rect(el.x, el.y, el.w, el.h);
      }

      if (el.fill && el.stroke) {
        doc.fillColor(el.fill).strokeColor(el.stroke).lineWidth(el.lineWidth || 1).fillAndStroke();
      } else if (el.fill) {
        doc.fillColor(el.fill).fill();
      } else if (el.stroke) {
        doc.strokeColor(el.stroke).lineWidth(el.lineWidth || 1).stroke();
      }

      // Left accent rule (west border)
      if (el.westWidth) {
        doc.rect(el.x, el.y, el.westWidth, el.h).fill(el.stroke || '#111827');
      }
      doc.restore();
    } else if (el.type === 'rule') {
      doc.save();
      doc.moveTo(el.x1, el.y1)
        .lineTo(el.x2, el.y2)
        .lineWidth(el.width || 0.5)
        .strokeColor(el.color || '#E5E7EB')
        .stroke();
      doc.restore();
    } else if (el.type === 'bullet') {
      doc.save();
      const color = el.color || '#111827';
      const cx = el.x + 1.5;
      const cy = el.y;
      const r = el.r || 1.5;
      switch (el.style) {
        case 'hollow_circle':
          doc.circle(cx, cy, r).lineWidth(0.8).strokeColor(color).stroke();
          break;
        case 'hollow_square': {
          const s = r * 2;
          doc.rect(cx - s / 2, cy - s / 2, s, s).lineWidth(0.8).strokeColor(color).stroke();
          break;
        }
        case 'diamond_teal':
        case 'diamond':
          doc.moveTo(cx, cy - r).lineTo(cx + r, cy).lineTo(cx, cy + r).lineTo(cx - r, cy)
            .closePath().fill(color);
          break;
        case 'square': {
          const s = Math.max(2, r * 2);
          doc.rect(cx - s / 2, cy - s / 2, s, s).fill(color);
          break;
        }
        case 'circle_sapphire':
        case 'circle':
          doc.circle(cx, cy, r).fill(color);
          break;
        case 'hollow':
          doc.circle(el.x + 1.5, el.y, 2).lineWidth(0.8).strokeColor(el.color || '#111827').stroke();
          break;
        case 'dash':
          doc.rect(el.x, el.y - 1, 3, 3).fill(el.color || '#111827');
          break;
        default:
          doc.circle(el.x + 1.5, el.y, 1.5).fill(el.color || '#111827');
      }
      doc.restore();
    } else if (el.type === 'checkbox') {
      doc.save();
      const s = 7.5;
      const border = el.border || '#9CA3AF';
      if (el.checked) {
        doc.roundedRect(el.x, el.y, s, s, 1.5).fill(el.color || '#111827');
        doc.save();
        doc.lineWidth(1.1).strokeColor('#FFFFFF')
          .moveTo(el.x + 1.8, el.y + 3.8)
          .lineTo(el.x + 3.2, el.y + 5.5)
          .lineTo(el.x + 5.8, el.y + 2.0)
          .stroke();
        doc.restore();
      } else {
        doc.roundedRect(el.x, el.y, s, s, 1.5).lineWidth(0.8).strokeColor(border).stroke();
      }
      doc.restore();
    } else if (el.type === 'text') {
      const hasCustom = doc._v2Fonts === true;
      const size = el.size || 10;
      const color = el.color || '#111827';
      const segments = (el.runs && el.runs.length > 0)
        ? el.runs.filter(r => r && r.text)
        : [{ text: el.text || '', style: baseStyleOf(el.font) }];

      const emojiFont = emojiFontFor(doc);
      const expanded = [];
      for (const seg of segments) {
        if (!seg || !seg.text) continue;
        const plain = nbspToSpaces(seg.text);
        if (emojiFont && hasEmojiCandidate(plain)) {
          for (const part of splitEmojiSegments(plain)) {
            if (part.text) expanded.push({ text: part.text, style: seg.style, emoji: part.emoji });
          }
        } else {
          expanded.push({ text: plain, style: seg.style });
        }
      }
      const isScriptStyle = (s) => s === 'math-sub' || s === 'math-super';
      for (let i = 0; i < expanded.length; i++) {
        const seg = expanded[i];
        const first = i === 0;
        const last = i === expanded.length - 1;
        const script = isScriptStyle(seg.style);
        const segSize = script ? size * 0.72 : size;
        const segFont = seg.emoji && emojiFont ? emojiFont : mapV2Font(el.font, seg.style, hasCustom, tmplId);
        doc.font(segFont).fontSize(segSize).fillColor(color);
        const drawAt = (x, opts) => {
          if (!script) {
            doc.text(seg.text, x, el.y, opts);
            return;
          }
          doc.save();
          try {
            doc.translate(0, seg.style === 'math-sub' ? size * MATH_SUB_NUDGE : -size * MATH_SUPER_NUDGE);
            doc.text(seg.text, x, el.y, opts);
          } finally {
            doc.restore();
          }
        };
        if (first) {
          if (el.width) {
            drawAt(el.x, {
              width: el.width,
              lineBreak: !el.prewrapped,
              align: el.align || 'left',
              continued: !last,
            });
          } else {
            drawAt(el.x, { lineBreak: false, continued: !last });
          }
        } else if (script) {
          drawAt(doc.x, { lineBreak: false, continued: !last });
        } else if (!last) {
          doc.text(seg.text, { continued: true });
        } else {
          doc.text(seg.text);
        }
      }
    } else if (el.type === 'image') {
      doc.save();
      try {
        if (el.buffer) {
          doc.image(el.buffer, el.x, el.y, { width: el.w, height: el.h });
          if (el.stroke) {
            doc.rect(el.x, el.y, el.w, el.h)
               .lineWidth(el.lineWidth || 1)
               .strokeColor(el.stroke)
               .stroke();
          }
        }
      } catch (err) {
        console.warn('PDFKitVectorBlaster failed to render image:', err.message);
      }
      doc.restore();
    } else if (el.type === 'destination') {
      if (el.name) {
        try { doc.addNamedDestination(el.name); } catch (e) {}
      }
    }
  }
}
