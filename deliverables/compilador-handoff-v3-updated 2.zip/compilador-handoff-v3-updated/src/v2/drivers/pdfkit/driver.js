// V2 PDFKit Vector Driver (DisplayList Architecture)
// All metric access via FontMetrics adapter only. Zero per-glyph monkey patching.
import { GeometryCompiler } from '../../compiler/geometry-compiler.js';
import { PDFKitVectorBlaster, createMeasureContext } from './blaster.js';

import { shaper } from '../../fonts/shaping.js';

export const name = 'pdfkit';
export const FontMetrics = { source: 'fontkit', perGlyphTweaks: 'forbidden' };

const compiler = new GeometryCompiler();

/**
 * Emits either a test descriptor or a binary PDF buffer based on options.
 * @param {object[]|object} treeOrDocIR 
 * @param {object} [opts={}]
 * @returns {Promise<Buffer>|object}
 */
export function emit(treeOrDocIR, opts = {}) {
  if (opts.format === 'pdf' || opts.asBuffer === true) {
    const docIR = opts.docIR || treeOrDocIR;
    // Live word measurer (same fonts the blaster renders with) so wrap
    // breaks match rendered breaks. Per-call context (no shared state);
    // falls back to headless shaper / AFM tables when unavailable. Explicit opts.measure wins.
    const template = opts.template || (docIR && docIR.template) || 'base';
    let compileOpts = {
      // A1: production renders never consume diagnostics.fit (warn-gates
      // live in pipeline/QA). Default the audit off here; pass
      // { skip_fit_audit: false } explicitly to force it (e.g. QA).
      skip_fit_audit: true,
      measure: (w, f, s) => shaper.measure(w, f, s, opts.fontAssets || null),
      ...opts,
    };
    let dispose = null;
    if (typeof opts.measure !== 'function') {
      try {
        const ctx = createMeasureContext(template, opts.fontAssets || null);
        dispose = ctx.dispose;
        compileOpts = { ...opts, measure: ctx.measure, measureImage: ctx.measureImage };
      } catch { /* headless shaper fallback active */ }
    }
    try {
      const displayList = compiler.compile(docIR, compileOpts);
      return PDFKitVectorBlaster.blast(displayList, opts);
    } finally {
      if (dispose) {
        try { dispose(); } catch { /* already closed */ }
      }
    }
  }
  return { driver: name, boxes: (Array.isArray(treeOrDocIR) ? treeOrDocIR : []).length, via: FontMetrics.source };
}

/**
 * Clean entrypoint to directly generate binary PDF buffer via PDFKit Vector Blaster.
 * @param {object} payload 
 * @param {object} [options={}]
 * @returns {Promise<Buffer>}
 */
export async function emitPdf(payload, options = {}) {
  const template = options.template || (payload && payload.template) || 'base';
  let compileOpts = {
    // A1: see emit() above — audit off by default on render paths.
    skip_fit_audit: true,
    measure: (w, f, s) => shaper.measure(w, f, s, options.fontAssets || null),
    ...options,
  };
  let dispose = null;
  if (typeof options.measure !== 'function') {
    try {
      const ctx = createMeasureContext(template, options.fontAssets || null);
      dispose = ctx.dispose;
      compileOpts = { ...options, measure: ctx.measure, measureImage: ctx.measureImage };
    } catch { /* headless shaper fallback active */ }
  }
  try {
    const displayList = compiler.compile(payload, compileOpts);
    return await PDFKitVectorBlaster.blast(displayList, options);
  } finally {
    if (dispose) {
      try { dispose(); } catch { /* already closed */ }
    }
  }
}

export { PDFKitVectorBlaster, GeometryCompiler };
