/**
 * FocusGate / PDF Engine V2: Driver Interface Contract
 * Defines the formal abstract port for rendering drivers (Typst, PDFKit).
 */

export class DriverError extends Error {
  constructor(message, driverName, cause) {
    super(`[Driver:${driverName}] ${message}`);
    this.name = 'DriverError';
    this.driverName = driverName;
    this.cause = cause;
  }
}

/**
 * Validates if an object conforms to the Driver port.
 * @param {any} d 
 * @returns {boolean}
 */
export function isDriver(d) {
  return !!d && typeof d.emit === 'function' && typeof d.name === 'string';
}

// Re-export DisplayList seam so both adapters (pdfkit, typst) share one
// import surface: freeze/assert/count live in core/display-list.js.
export { IR_VERSION, isDisplayList, freezeIR, assertDriverPurity, countCommands } from '../core/display-list.js';

/**
 * Base Driver specification for documentation and typing.
 */
export class BaseDriver {
  constructor(name) {
    this.name = name;
  }

  /**
   * Emits PDF bytes, Typst source, or descriptor from a layout tree.
   * @param {object[]} layoutTree 
   * @param {object} [options={}] 
   * @returns {Promise<Buffer|string|object>|Buffer|string|object}
   */
  emit(layoutTree, options = {}) {
    throw new Error(`emit() not implemented on driver ${this.name}`);
  }
}
