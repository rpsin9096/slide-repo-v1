// V2 Typst emitter (primary). Deterministic source gen; metrics resolved
// natively by the Typst compiler — no per-glyph tweaks here by design.
// Markdown conversion lives in ./md.js; visual identity in themes.js.
import { convertInline, convertMarkdown, emitTable, V2_MICROTYPE_TOKENS, getOpticalProtrusion, suppressWidowWords } from './md.js';
import { preamble, masthead, THEMES } from '../../templates/themes.js';

export { V2_MICROTYPE_TOKENS, getOpticalProtrusion, suppressWidowWords };
export const name = 'typst';
export const baseline = 'native';


const tableStyle = (theme) => {
  const t = THEMES[theme] ?? THEMES.base;
  return { soft: t.accentSoft, rule: t.rule };
};

function emitBox(b, theme) {
  const head = masthead(b, theme);
  const prefix = head ? `${head}\n` : '';
  const md = (x) => convertMarkdown(x, tableStyle(theme));
  switch (b.kind) {
    case 'heading':
      if (b.md == null && b.text != null) return `${prefix}= ${convertInline(b.text)} // h=${b.heightPt} keep=${b.keepWithNextLines}`;
      return `${prefix}${md(b.md ?? b.text ?? '')} // keep=${b.keepWithNextLines}`;
    case 'table': {
      // Markdown pipe tables (b.md) render structured; hand-built boxes
      // keep the legacy cells path. No empty caption (it still numbers).
      const style = tableStyle(theme);
      if (b.md && /^\s*\|/m.test(b.md)) {
        try { return `${prefix}${emitTable(b.md.split('\n').filter((l) => /^\s*\|/.test(l)), style)}`; }
        catch { /* fall through to raw */ }
      }
      const cap = b.caption ? `, caption: [${convertInline(b.caption)}]` : '';
      return `${prefix}#figure(table(columns: ${b.cols ?? 2}${b.cells ? `, ${b.cells}` : ''})${cap}) // span=${b.span ?? 'column'}`;
    }
    case 'math': return `${prefix}$ ${b.tex ?? 'x'} $ // display=${b.display ?? false}`;
    case 'span': return `${prefix}#grid(columns: 1)[${convertInline(b.text ?? '')}] // panoramic full-width`;
    default: return `${prefix}${md(b.md ?? b.text ?? '')} // h=${b.heightPt}`;
  }
}

export function emit(tree, opts = {}) {
  const theme = opts.theme ?? 'base';
  const t = THEMES[theme] ?? THEMES.base;
  const head = preamble(theme, opts);
  const parts = [head];
  const boxes = tree ?? [];
  // Explicit block rhythm (legacy parity): Typst's par.spacing replaces
  // leading at breaks instead of adding, so breaks carry exact #v glue —
  // parskip between blocks, larger headGap above headings. `cont` boxes
  // rejoin with a single newline (space). v-space at column/page breaks
  // is trimmed, so this never strands trailing whitespace.
  const headLevel = (b) => {
    const m = /^#{1,6}\s/.test(b.md ?? '') && (b.md ?? '').match(/^(#{1,6})/);
    if (m) return Math.min(m[1].length, 3);
    return b.kind === 'heading' ? 1 : 0;
  };
  const gapFor = (b) => {
    const lv = headLevel(b);
    return lv > 0 ? (t.headGap[lv] ?? t.parskip) : t.parskip;
  };
  // Stretch window: scoped leading override on the short side's tail boxes
  // (LaTeX-glue equivalent). The window never starts mid-paragraph
  // (autobalance guarantees it); between list items the scope is invisible.
  const st = opts.stretch;
  let inStretch = false;
  let prev = 'head'; // head | box | break | scope | scopeEnd
  const openStretch = () => {
    parts.push(`\n\n#block[\n#set par(leading: ${st.leading})\n`);
    inStretch = true;
    prev = 'scope';
  };
  const closeStretch = () => {
    if (!inStretch) return;
    parts.push('\n]');
    inStretch = false;
    prev = 'scopeEnd';
  };
  boxes.forEach((b, idx) => {
    const wantStretch = !!(st && idx >= st.from && idx <= st.to);
    if (wantStretch && !inStretch) openStretch();
    if (!wantStretch) closeStretch();
    // Single newline continues a paragraph/list across boxes (even across a
    // colbreak); anything else starts a fresh block with exact #v glue.
    // Without this, all boxes merge into one wall-of-text paragraph.
    const continues = prev === 'scope' || (b.cont && (prev === 'box' || prev === 'break'));
    if (prev === 'head' || continues) parts.push('\n');
    else parts.push(`\n\n#v(${gapFor(b)})\n\n`);
    parts.push(emitBox(b, theme));
    prev = 'box';
    // Terminal-balance lever (docs: manual #colbreak(); V2 places it by
    // two-pass measurement in layout/autobalance.js, never by hand).
    if (opts.breakAfter === idx) {
      closeStretch();
      parts.push('\n\n#colbreak()');
      prev = 'break';
    }
  });
  closeStretch();
  return `${parts.join('')}\n`;
}
