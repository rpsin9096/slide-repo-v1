// V2 Markdown -> Typst converter with TeX Knuth-Plass, ragged2e, and microtype primitives.
// Emits VALID Typst markup:
// headings, bullets, enums, quotes, hr, tables-as-raw, bold, italic,
// links, images, inline code (untouched), strikethrough. Stray Typst
// sigils (#, $, lone *) outside code spans are escaped.

export const V2_MICROTYPE_TOKENS = {
  hangingHyphenProtrusion: 1.00,
  punctuationProtrusion: 0.65,
  openingQuoteHanging: 0.80,
  hyphens: ['-', '–', '—', '\u2010', '\u2013', '\u2014'],
  punctuation: ['.', ',', ';', ':', '!', '?'],
  openingQuotes: ['"', "'", '“', '‘', '«'],
};

export function getOpticalProtrusion(char) {
  if (V2_MICROTYPE_TOKENS.hyphens.includes(char)) {
    return V2_MICROTYPE_TOKENS.hangingHyphenProtrusion;
  }
  if (V2_MICROTYPE_TOKENS.punctuation.includes(char)) {
    return V2_MICROTYPE_TOKENS.punctuationProtrusion;
  }
  if (V2_MICROTYPE_TOKENS.openingQuotes.includes(char)) {
    return V2_MICROTYPE_TOKENS.openingQuoteHanging;
  }
  return 0.0;
}

export function suppressWidowWords(text) {
  if (typeof text !== 'string') return text;
  const words = text.trim().split(/\s+/);
  if (words.length >= 3) {
    const lastSpace = text.lastIndexOf(' ');
    if (lastSpace !== -1) {
      return text.slice(0, lastSpace) + '\u00A0' + text.slice(lastSpace + 1);
    }
  }
  return text;
}


function convertInlineInner(s) {
  let t = String(s ?? '');
  t = t.replace(/#/g, '\\#').replace(/\$/g, '\\$'); // escape sigils FIRST
  t = t.replace(/~~(.+?)~~/g, '#strike[$1]');
  // Images: `![alt](src "caption {width=0.6}")` or `![alt](src){#s width=0.6}`
  // → `#image("src", width: 60%)` (no width arg when scale is 1.0).
  // Caption suffix / attr block never leak into prose.
  t = t.replace(/!\[([^\]]*)\]\(([^)]+)\)(\s*\{[^}]*\})?/g, (_, alt, ref, tail) => {
    const { src, scale: titleScale } = splitImageRef(ref);
    const { scale: attrScale } = splitImageAttrs(tail || '');
    const scale = tail && tail.trim() ? attrScale : titleScale;
    void alt;
    return scale !== 1 ? `#image("${src}", width: ${Math.round(scale * 100)}%)` : `#image("${src}")`;
  });
  t = t.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '#link("$2")[$1]');
  const strong = []; // protect Typst strong spans before escaping lone *
  t = t.replace(/\*\*([^*]+?)\*\*/g, (_, b) => { strong.push(`*${b}*`); return `\x00${strong.length - 1}\x00`; });
  t = t.replace(/\*([^*\n]+?)\*/g, '_$1_'); // remaining singles are italic
  t = t.replace(/\*/g, '\\*');
  t = t.replace(/\x00(\d+)\x00/g, (_, i) => strong[Number(i)]);
  return t;
}

// Backtick spans are Typst raw already, `$...$` is Typst math already —
// never escape inside them. Split first, convert only prose parts.
const LITERAL_RE = /(`[^`]*`|\$[^$\n]+\$)/g;
export function convertInline(s) {
  return String(s ?? '').split(LITERAL_RE).map((part, i) =>
    i % 2 === 1 ? part : convertInlineInner(part)).join('');
}

// Per-image scale contract (handoff §2): trailing `{width=N}` in the
// image title. Shared semantics with ingest/from-markdown.js.
function clampScale(n) {
  const v = Number(n);
  if (!Number.isFinite(v)) return 1;
  return Math.min(1, Math.max(0.1, v));
}

function splitImageRef(ref = '') {
  const s = String(ref ?? '').trim();
  const m = s.match(/^(\S+)\s+["'](.*)["']$/);
  if (!m) return { src: s, caption: '', scale: 1, place: 'column' };
  const sm = m[2].match(/\{\s*width\s*=\s*([0-9]*\.?[0-9]+)\s*\}\s*$/);
  if (!sm) return { src: m[1], caption: m[2].trim(), scale: 1, place: 'column' };
  return { src: m[1], caption: m[2].slice(0, sm.index).trim(), scale: clampScale(sm[1]), place: 'column' };
}

// Trailing `{#slug width place ratio}` attr block (Phase 1 §3). Wins over
// the legacy title suffix when present.
function splitImageAttrs(tail = '') {
  const out = { scale: 1, place: 'column' };
  const m = String(tail ?? '').trim().match(/^\{([^}]*)\}\s*$/);
  if (!m) return out;
  for (const kv of m[1].matchAll(/(\w+)\s*=\s*"?([^"\s}]+)"?/g)) {
    const key = kv[1].toLowerCase();
    if (key === 'width') out.scale = clampScale(kv[2]);
    else if ((key === 'place' || key === 'placement') && (kv[2] === 'column' || kv[2] === 'full-width')) out.place = kv[2];
  }
  return out;
}

function convertLine(line) {
  const hm = line.match(/^(#{1,6})\s+(.*)$/);
  if (hm) return `${'='.repeat(hm[1].length)} ${convertInline(hm[2])}`;
  const img = line.match(/^\s*!\[([^\]]*)\]\(([^)]+)\)\s*(\{[^}]*\})?\s*$/);
  if (img) {
    const { src, caption, scale: titleScale } = splitImageRef(img[2]);
    const { scale: attrScale, place } = splitImageAttrs(img[3] || '');
    const scale = img[3] ? attrScale : titleScale;
    const cap = (caption || img[1] || '').trim();
    const width = scale !== 1 ? `, width: ${Math.round(scale * 100)}%` : '';
    // place=full-width spans both columns (Typst ≥0.11 figure scope).
    const scope = place === 'full-width' ? ', scope: "parent"' : '';
    return `#figure(image("${src}"${width}), caption: [${convertInline(cap)}]${scope})`;
  }
  const bm = line.match(/^(\s*)[-*]\s+(.*)$/);
  if (bm) return `${bm[1]}- ${convertInline(bm[2])}`;
  const em = line.match(/^(\s*)\d+[.)]\s+(.*)$/);
  if (em) return `${em[1]}+ ${convertInline(em[2])}`; // Typst enum marker
  const qm = line.match(/^>\s?(.*)$/);
  if (qm) return `#quote(block: true)[${convertInline(qm[1])}]`;
  if (/^\s*(---|\*\*\*|___)\s*$/.test(line)) return '#line(length: 100%)';
  return convertInline(line);
}

// Consecutive `|...` rows become a raw block so complex editorial tables
// never break compilation. Structured #table generation is P-next.
// Consecutive `|...` rows become a structured figure+table (header fill,
// per-column alignment from the `:---` delimiter row). Wide tables (>3 cols)
// shrink slightly to survive the narrow column; panoramic full-width spans
// are P-next. Anything unparseable falls back to a raw block (always valid).
function splitRow(line) {
  let t = line.trim();
  if (t.startsWith('|')) t = t.slice(1);
  if (t.endsWith('|')) t = t.slice(0, -1);
  return t.split('|').map((c) => c.trim());
}
const isDelimRow = (cells) => cells.length > 0 && cells.every((c) => /^:?-{1,}:?$/.test(c));
const alignOf = (c) => (/^:.*:$/.test(c) ? 'center' : /^:/.test(c) ? 'left' : /:$/.test(c) ? 'right' : 'left');

export function emitTable(rows, style = {}) {  const soft = style.soft ?? '#F9FAFB';
  const rule = style.rule ?? '#9CA3AF';
  const grid = rows.map(splitRow);
  const head = grid[0];
  const n = head.length;
  let aligns = Array(n).fill('left');
  let body = grid.slice(1);
  if (body.length > 0 && isDelimRow(body[0])) {
    aligns = body[0].slice(0, n).map(alignOf);
    while (aligns.length < n) aligns.push('left');
    body = body.slice(1);
  }
  const cell = (c) => `[${convertInline(c)}]`;
  // Equal fractional tracks (tabularx-style): cells can never exceed their
  // share, so long words must wrap/hyphenate instead of spilling into
  // neighbors. Auto tracks size to content and overflow narrow columns.
  const tracks = `(${Array(n).fill('1fr').join(', ')})`;
  const lines = [
    '#figure(',
    '  table(',
    `    columns: ${tracks},`,
    `    align: (${aligns.join(', ')}),`,
    `    stroke: 0.5pt + rgb("${rule}"),`,
    `    fill: (_, row) => if row == 0 { rgb("${soft}") },`,
    `    table.header(${head.map(cell).join(', ')}),`,
  ];
  for (const row of body) {
    const cells = row.slice(0, n);
    while (cells.length < n) cells.push('');
    lines.push(`    ${cells.map(cell).join(', ')},`);
  }
  lines.push('  ),');
  lines.push(')');
  const size = n > 3 ? '#text(size: 7.5pt)[\n' : '';
  const close = n > 3 ? '\n]' : '';
  return `${size}${lines.join('\n')}${close}`;
}

export function convertMarkdown(md, style = {}) {
  const lines = String(md ?? '').split('\n');
  const out = [];
  let table = [];
  let fence = null; // inside ``` fenced code: pass through literally
  const flush = () => {
    if (table.length > 0) {
      try { out.push(emitTable(table, style)); }
      catch { out.push('```', ...table, '```'); }
      table = [];
    }
  };
  for (const line of lines) {
    if (/^\s*```/.test(line)) { flush(); fence = fence ? null : line; out.push(fence ?? '```'); continue; }
    if (fence) { out.push(line); continue; }
    const dm = line.match(/^\s*\$\$(.+)\$\$\s*$/);
    if (dm) { flush(); out.push(`$ ${dm[1].trim()} $`); continue; } // display math
    if (/^\s*\|/.test(line)) table.push(line);
    else { flush(); out.push(convertLine(line)); }
  }
  flush();
  if (fence) out.push('```'); // unclosed fence: close it, stay valid
  return out.join('\n');
}
