/**
 * Typst source → PDF compilation seam (CC4).
 *
 * Single home for every `typst compile` child process: hermetic font env,
 * image-asset sandboxing, execution timeout, temp-dir cleanup. Replaces two
 * near-identical inline blocks in server.js (`/api/convert` engine=v2-typst
 * and `/api/convert-v2` format=pdf); the exported `sandboxTypstAssets`
 * doubles as the `resolveAssets(source, dir)` callback for
 * `layout/autobalance.js` balance probes.
 */
import { execFile } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import '../../layout/autobalance.js'; // side effect: sets TYPST_FONT_PATHS

/** Default `typst compile` ceiling; override with TYPST_TIMEOUT_MS (CC4). */
export const DEFAULT_TYPST_TIMEOUT_MS = 60000;

export function compileTimeoutMs() {
  const raw = Number(process.env.TYPST_TIMEOUT_MS);
  return Number.isFinite(raw) && raw > 0 ? raw : DEFAULT_TYPST_TIMEOUT_MS;
}

export function resolveTypstBin() {
  return process.env.TYPST_BIN
    || (fs.existsSync(path.join(os.homedir(), '.local', 'bin', 'typst'))
      ? path.join(os.homedir(), '.local', 'bin', 'typst') : 'typst');
}

/**
 * Copies local `image("ref")` assets into the sandbox dir and rewrites refs
 * to their basenames (Typst resolves relative to the source file). Remote
 * `http(s)` refs and missing files pass through untouched.
 * @param {string} source Typst source text
 * @param {string} dir sandbox directory (must exist)
 * @returns {string} source with local refs rewritten
 */
export function sandboxTypstAssets(source, dir) {
  let resolved = source;
  for (const m of resolved.matchAll(/image\("([^"]+)"\)/g)) {
    const ref = m[1];
    if (/^https?:/.test(ref)) continue;
    const rel = ref.replace(/^\//, '').replace(/^static\//, '');
    const cand = [path.join(process.cwd(), 'static', rel), path.join(process.cwd(), rel)];
    const hit = cand.find((p) => { try { return fs.existsSync(p) && fs.statSync(p).isFile(); } catch { return false; } });
    if (hit) {
      const base = path.basename(hit);
      fs.copyFileSync(hit, path.join(dir, base));
      resolved = resolved.split(`image("${ref}")`).join(`image("${base}")`);
    }
  }
  return resolved;
}

/**
 * Compiles Typst source to PDF bytes via the Typst binary.
 * @param {string} source Typst source text
 * @param {object} [opts] `{ timeoutMs, typstBin }`
 * @returns {Promise<Buffer>} PDF bytes
 * @throws on missing binary, non-zero exit, or timeout (temp dir always removed)
 */
export async function compileTypstSource(source, opts = {}) {
  const timeoutMs = opts.timeoutMs ?? compileTimeoutMs();
  const typstBin = opts.typstBin ?? resolveTypstBin();
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'typst-'));
  try {
    const src = path.join(dir, 'doc.typ');
    const pdf = path.join(dir, 'doc.pdf');
    fs.writeFileSync(src, sandboxTypstAssets(source, dir));
    await new Promise((resolve, reject) =>
      execFile(typstBin, ['compile', src, pdf], { timeout: timeoutMs }, (err) => {
        if (!err) return resolve();
        const timedOut = err.killed === true;
        const wrapped = new Error(
          timedOut
            ? `typst compile timed out after ${timeoutMs}ms`
            : `typst compile failed: ${err.message || err}`,
          { cause: err },
        );
        reject(wrapped);
      }));
    return fs.readFileSync(pdf);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
}
