// V2 compat shim (P3): legacy `generatePdf` import path resolves via V2.
// Legacy pdf-generator.js stays frozen; this maps DocIR -> V2 driver emit.
import { validateDocIR } from '../ingest/schema.js';
import { measure } from '../layout/coordinator.js';
import { emit as emitTypst } from '../drivers/typst/emitter.js';
import { emit as emitPdfkit } from '../drivers/pdfkit/driver.js';

export function generatePdf(docIR, { driver = 'typst' } = {}) {
  const v = validateDocIR(docIR);
  if (!v.ok) throw new Error(`Invalid DocIR: ${v.errors.join('; ')}`);
  const tree = measure(docIR.blocks);
  return driver === 'pdfkit' ? emitPdfkit(tree) : emitTypst(tree);
}
