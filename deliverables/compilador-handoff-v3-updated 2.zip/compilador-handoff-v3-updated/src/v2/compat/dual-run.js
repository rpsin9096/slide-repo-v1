// V2 dual-run: typst vs pdfkit parity behind flag (no legacy heavy path),
// plus runDualV2V3 (M0) for geometry: 'v2' vs 'v3' comparison.
import { render as renderBase } from '../templates/base.js';
import { emit as emitPdfkit } from '../drivers/pdfkit/driver.js';
import { runPipeline } from '../runtime/pipeline.js';
import { TEMPLATES } from '../templates/definitions.js';
import { PAGE_SIZES } from '../core/geometry.js';
import { elementExtent } from '../layout/stretch-seam.js';

export function runBoth(docIR, opts = {}) {
  const enabled = opts.dual ?? process.env.V2_DUAL_RUN === '1' ?? false;
  const base = renderBase(docIR, opts);
  const fb = emitPdfkit(base.tree);
  const parity = fb.boxes === base.tree.length;
  return { typst: base.source, pdfkit: fb, cols: base.cols, parity, dual: !!enabled };
}

function pageVoidPt(page, cbY) {
  let bottom = -Infinity;
  for (const el of (page.elements || [])) {
    if (el && el.type === 'rule' && (el.y1 || 0) !== (el.y2 || 0)) continue;
    const ext = elementExtent(el);
    if (!ext || ext.top >= cbY + 0.5) continue;
    if (ext.bottom > bottom) bottom = ext.bottom;
  }
  return Number.isFinite(bottom) ? Math.round((cbY - bottom) * 100) / 100 : null;
}

export async function runDualV2V3(payload, opts = {}) {
  const seed = opts.seed || 'dual-v2-v3';
  const timestamp = opts.timestamp ?? 1700000000000;
  const templateId = opts.template || payload?.template || 'base';
  const tmpl = TEMPLATES[templateId] || TEMPLATES.base;
  const cbY = PAGE_SIZES.A4.height - tmpl.margins.bottom - tmpl.footskip;

  const [v2Res, v3Res] = await Promise.all([
    runPipeline({
      payload,
      mode: 'paginate',
      seed,
      timestamp,
      options: { ...(opts.options || {}), geometry: 'v2' },
    }),
    runPipeline({
      payload,
      mode: 'paginate',
      seed,
      timestamp,
      options: { ...(opts.options || {}), geometry: 'v3' },
    }),
  ]);

  const v2Pages = v2Res.displayList.pages || [];
  const v3Pages = v3Res.displayList.pages || [];

  return {
    template: templateId,
    v2: {
      totalPages: v2Pages.length,
      voidsPt: v2Pages.map((p) => pageVoidPt(p, cbY)),
      displayList: v2Res.displayList,
    },
    v3: {
      totalPages: v3Pages.length,
      voidsPt: v3Pages.map((p) => pageVoidPt(p, cbY)),
      displayList: v3Res.displayList,
    },
    pageDelta: v3Pages.length - v2Pages.length,
  };
}
