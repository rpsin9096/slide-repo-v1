// Polyfill __dirname, __filename, and AFM font metrics in Cloudflare Worker (workerd) runtime
import fs from 'node:fs';
import { AFM_DATA } from './afm-data.js';

if (typeof globalThis.__dirname === 'undefined') {
  globalThis.__dirname = '/virtual';
}
if (typeof globalThis.__filename === 'undefined') {
  globalThis.__filename = '/virtual/_worker.js';
}

// Hook into fs.readFileSync and fs.existsSync with O(1) basename lookup and cached ICC buffers
const ICC_BUFFER_CACHE = new Map();
function extractVirtualBasename(filePath) {
  const str = String(filePath);
  const slash = Math.max(str.lastIndexOf('/'), str.lastIndexOf('\\'));
  return slash >= 0 ? str.slice(slash + 1) : str;
}

const origReadFileSync = fs.readFileSync;
fs.readFileSync = function(filePath, options) {
  const base = extractVirtualBasename(filePath);
  if (Object.prototype.hasOwnProperty.call(AFM_DATA, base)) {
    const content = AFM_DATA[base];
    if (base.endsWith('.icc')) {
      let buf = ICC_BUFFER_CACHE.get(base);
      if (!buf) {
        buf = Buffer.from(content, 'base64');
        ICC_BUFFER_CACHE.set(base, buf);
      }
      return buf;
    }
    return content;
  }
  if (typeof origReadFileSync === 'function') {
    try {
      return origReadFileSync(filePath, options);
    } catch (e) {}
  }
  throw new Error(`[virtual-fs] File not found in Cloudflare Worker runtime: ${filePath}`);
};

// Hook into fs.existsSync to report true for inlined AFM fonts in O(1)
const origExistsSync = fs.existsSync;
fs.existsSync = function(filePath) {
  const base = extractVirtualBasename(filePath);
  if (Object.prototype.hasOwnProperty.call(AFM_DATA, base)) return true;
  if (typeof origExistsSync === 'function') {
    try {
      return origExistsSync(filePath);
    } catch (e) {}
  }
  return false;
};

import { normalizeToDocIR, validateDocIR } from './v2/core/contracts.js';
// B: paginate estimator inlined (was: import { calculatePagination } from
// '../pdf-engine.js'). pdf-engine drags the typst emitter, template
// registry, galley balancer and event bus into the worker bundle — none
// used on this path. measure() itself is pure arithmetic (coordinator).
import { measure } from './v2/layout/coordinator.js';
import { emitPdf } from './v2/drivers/pdfkit/driver.js';
import { runPipeline } from './v2/runtime/pipeline.js';
// FontsPort embedded adapter: TTFs inlined at build time (no disk on
// workerd), so the worker renders the same Arimo/Inter faces as Node.
import { FONT_ASSETS } from './font-assets-data.js';
import { createEmbeddedFontAssets } from './v2/fonts/assets.js';

const workerFontAssets = createEmbeddedFontAssets(FONT_ASSETS);

// Fail fast before compiling: a single compile that blows the isolate's
// CPU/memory budget surfaces as Cloudflare Error 1102 (503). Reject
// oversized payloads with 413 while the request is still cheap.
// Calibrated against real documents (largest sample: ~40KB markdown):
// 150k chars ≈ 3.7x headroom, 30 sections ≈ 10x typical use.
const MAX_SECTIONS = 30;
const MAX_TOTAL_CHARS = 150000;
// Pasted/uploaded images arrive as data URIs (client downscales rasters to
// JPEG-1600px first, so typical payloads are small). The worker extracts
// decodable PNG/JPEG data URIs into an image map BEFORE stripping, so the
// compiler renders real pixels (not placeholders). Total decoded bytes are
// capped separately, and stripped bodies still flow through JSON parse,
// normalize, and layout as short tokens (a 273k-glyph "word" alone can
// exhaust the isolate via fontkit.layout).
// Cap total embedded image bytes separately and strip payloads before compile.
const MAX_IMAGE_BYTES = 15 * 1024 * 1024;
// Decompression-bomb guard (mirrors image-module.js MAX_IMAGE_PIXELS).
const MAX_IMAGE_PIXELS = 25 * 1000 * 1000;
// A2: wire-level pre-gate. JSON bodies above this are guaranteed to exceed
// the image+text budgets below, so reject before paying request.json() +
// regex scans on megabytes. 25MB covers 15MB of images + 150k text chars +
// JSON escaping overhead with headroom; chunked bodies without a
// content-length header skip this and fall through to the exact guards.
const MAX_WIRE_BYTES = 25 * 1024 * 1024;
const DATA_URI_RE = /data:image\/[a-zA-Z0-9+.-]+;base64,[A-Za-z0-9+/=]+/g;

function wireOverLimit(request) {
  try {
    const v = request.headers.get('content-length');
    if (v == null) return false;
    const n = Number(v);
    return Number.isFinite(n) && n > MAX_WIRE_BYTES;
  } catch {
    return false;
  }
}

// A2: single-pass input scan. Previously measureImages (regex scan #1) +
// stripBodyDataUris (regex scan #2 + string copies) + payloadSize (scan #3)
// each walked every markdown byte. This walks each text once: the replace
// callback accumulates image bytes while producing the stripped string,
// whose length feeds the text budget — identical semantics to the old
// measure-then-strip-then-size sequence (budgets apply post-strip).
function scanAndStripBody(body) {
  let imageBytes = 0;
  let chars = 0;
  try {
    const scrub = (t) => {
      const stripped = String(t || '').replace(DATA_URI_RE, (m) => {
        const comma = m.indexOf(',');
        imageBytes += Math.max(0, m.length - comma - 1);
        return m.slice(0, comma + 1);
      });
      chars += stripped.length;
      return stripped;
    };
    if (Array.isArray(body.sections)) {
      for (const s of body.sections) {
        if (s && typeof s.markdown === 'string') s.markdown = scrub(s.markdown);
        else if (s) chars += String(s.markdown || '').length;
      }
    }
    if (typeof body.markdown === 'string') body.markdown = scrub(body.markdown);
  } catch {
    /* keep original on unexpected shape; budgets read as accumulated */
  }
  return { imageBytes: Math.floor(imageBytes * 3 / 4), chars };
}

// Worker-first image decode: extract decodable data-URI images into a
// Map keyed by SHORT stable keys (`extracted:image-<n>`), and rewrite the
// body to reference those keys. Short keys are essential: scanAndStripBody
// truncates every data-URI body to `data:…,` before compile, so keying by
// full URI would always miss. Short keys never match DATA_URI_RE (no
// `data:` scheme), never consume text budget, and never reach the word
// wrapper as giant unbreakable tokens. Only PNG/JPEG are decoded — the
// renderer only supports those (gif/webp/svg stay placeholders). Every
// buffer passes magic-byte + dimension + pixel caps; failures decode to
// null (placeholder) instead of 413 so one corrupt figure never blocks
// the whole document. Total decoded bytes are capped at MAX_IMAGE_BYTES.
function decodeBase64ToBytes(b64) {
  if (typeof Buffer !== 'undefined' && typeof Buffer.from === 'function') {
    return Buffer.from(b64, 'base64');
  }
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

function detectWorkerImageType(buf) {
  if (!buf || buf.length < 12) return null;
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return 'png';
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpeg';
  return null;
}

function probeWorkerDims(buf, type) {
  try {
    if (type === 'png') {
      if (buf.length < 24) return null;
      const w = (buf[16] << 24) | (buf[17] << 16) | (buf[18] << 8) | buf[19];
      const h = (buf[20] << 24) | (buf[21] << 16) | (buf[22] << 8) | buf[23];
      if (!w || !h) return null;
      return { width: w >>> 0, height: h >>> 0 };
    }
    if (type === 'jpeg') {
      let i = 2;
      while (i + 8 < buf.length) {
        if (buf[i] !== 0xff) { i++; continue; }
        const marker = buf[i + 1];
        if (marker === 0x00 || marker === 0xd8 || marker === 0xd9
          || (marker >= 0xd0 && marker <= 0xd7)) { i += 2; continue; }
        if (i + 3 >= buf.length) return null;
        const len = (buf[i + 2] << 8) | buf[i + 3];
        if (len < 2) return null;
        if (marker >= 0xc0 && marker <= 0xcf && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc) {
          if (i + 8 >= buf.length) return null;
          const h = (buf[i + 5] << 8) | buf[i + 6];
          const w = (buf[i + 7] << 8) | buf[i + 8];
          if (!w || !h) return null;
          return { width: w, height: h };
        }
        i += 2 + len;
      }
      return null;
    }
  } catch { return null; }
  return null;
}

function extractDataUriImages(body) {
  const map = new Map(); // shortKey -> bytes
  const uriToKey = new Map(); // full data-URI -> shortKey (dedupe repeats)
  let totalBytes = 0;
  let counter = 0;
  const decodeOne = (uri) => {
    const known = uriToKey.get(uri);
    if (known) return known;
    const comma = uri.indexOf(',');
    const head = uri.slice(0, comma + 1).toLowerCase();
    // Leave non-decodable types in place: strip turns them into placeholders.
    if (!head.includes('image/png') && !head.includes('image/jpeg') && !head.includes('image/jpg')) return uri;
    let buf;
    try {
      buf = decodeBase64ToBytes(uri.slice(comma + 1));
    } catch { return uri; }
    if (!buf || buf.length === 0 || buf.length > MAX_IMAGE_BYTES) return uri;
    const type = detectWorkerImageType(buf);
    if (type !== 'png' && type !== 'jpeg') return uri;
    const dims = probeWorkerDims(buf, type);
    if (!dims || !dims.width || !dims.height) return uri;
    if (dims.width * dims.height > MAX_IMAGE_PIXELS) return uri;
    if (totalBytes + buf.length > MAX_IMAGE_BYTES) {
      throw new Error('IMAGE_BUDGET_EXCEEDED');
    }
    totalBytes += buf.length;
    const key = `extracted:image-${counter++}`;
    map.set(key, buf);
    uriToKey.set(uri, key);
    return key;
  };
  // Fresh regex per replace: DATA_URI_RE is global (lastIndex stateful).
  const rewriteText = (text) => String(text || '').replace(new RegExp(DATA_URI_RE.source, 'g'), (uri) => decodeOne(uri));
  try {
    if (Array.isArray(body.sections)) {
      for (const s of body.sections) {
        if (s && typeof s.markdown === 'string') s.markdown = rewriteText(s.markdown);
      }
    }
    if (typeof body.markdown === 'string') body.markdown = rewriteText(body.markdown);
  } catch (e) {
    if (e && e.message === 'IMAGE_BUDGET_EXCEEDED') throw e;
    /* keep original on unexpected shape; budgets read as accumulated */
  }
  return { map, totalBytes };
}

function oversizedResponse() {
  return new Response(JSON.stringify({ detail: 'Payload exceeds worker limits (413): reduza o tamanho ou o número de seções' }), {
    status: 413,
    headers: { 'Content-Type': 'application/json; charset=utf-8' },
  });
}

// B: local fast-path pagination estimator (identical math to the former
// pdf-engine.calculatePagination; kept here so the worker bundle never
// imports pdf-engine). Estimates from coarse box heights: 2 columns/page.
function calculatePagination(body, options = {}) {
  const startTime = Date.now();
  const docIR = normalizeToDocIR(body);
  const layoutTree = measure(docIR.blocks);

  const availableHeight = options.availableHeight || 700;
  let totalHeight = 0;
  for (const box of layoutTree) {
    totalHeight += box.heightPt || box.height || 0;
  }

  // 2 columns per page
  const pageCapacity = availableHeight * 2;
  const estimatedPages = Math.max(1, Math.ceil(totalHeight / pageCapacity));

  const sections = docIR.blocks.map((b, idx) => ({
    index: idx,
    title: b.title,
    estimatedHeight: (b.markdown || '').length * 0.4,
  }));

  return {
    totalPages: estimatedPages,
    sections,
    // Mirrors pdf-engine.calculatePagination (CC2): coarse estimate, not exact.
    estimated: true,
    metrics: {
      totalHeight,
      availableHeight,
      boxCount: layoutTree.length,
    },
    durationMs: Date.now() - startTime,
  };
}

// E: content-hash PDF cache. Repeat preview/compile of an unchanged
// document is the common case (preview → tweak → preview cycles hit the
// same bytes repeatedly); re-rendering burns full isolate CPU each time.
// Key = SHA-256 over the stripped body minus volatile flags, stored in
// caches.default (no binding needed; GET-only API so the hash travels in
// a synthetic URL). Headers that vary per request (Content-Disposition
// via `preview`) are re-applied on HIT, never keyed.
const CONVERT_CACHE_MAX_BYTES = 10 * 1024 * 1024;
const CONVERT_CACHE_TTL = 600;

// Cache keys MUST include the engine revision: the edge cache
// (caches.default) persists across deploys, so a key derived only from the
// payload keeps serving the PREVIOUS build's renders after a deploy —
// measured 2026-10-03: a user iterating edit→compile every few minutes
// across a layout-fix deploy kept receiving the old engine's broken page
// (col2 void before a panoramic table) from a cache entry their earlier
// compile had stored, while a fresh payload got the fixed render. Bumping
// this constant on every engine-affecting deploy invalidates every cached
// render at once.
const RENDER_ENGINE_REVISION = '2026-10-26-atomic-list-balance';
const PAGINATE_MEM_CACHE = new Map();
const MAX_PAGINATE_MEM_CACHE = 32;

function workerFastKey(value) {
  const str = stableStringify(value);
  let h1 = 0x811c9dc5;
  let h2 = 0xdeadbeef;
  for (let i = 0; i < str.length; i++) {
    const c = str.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 0x01000193) >>> 0;
    h2 = Math.imul(h2 ^ c, 0x9e3779b1) >>> 0;
  }
  return `${h1.toString(16)}-${h2.toString(16)}-${str.length}`;
}

function resolveWorkerCompileOptions(body = {}) {
  const b = body || {};
  return {
    chapters_toc: Boolean(b.chapters_toc ?? b.chaptersToc ?? false),
    toc_title: typeof (b.toc_title ?? b.tocTitle) === 'string' ? (b.toc_title ?? b.tocTitle) : undefined,
    toc_include_headings: b.toc_include_headings ?? b.tocIncludeHeadings ?? true,
    doc_title: typeof b.doc_title === 'string' ? b.doc_title : (typeof b.title === 'string' ? b.title : ''),
    doc_subtitle: typeof b.doc_subtitle === 'string' ? b.doc_subtitle : '',
    image_captions_enabled: b.image_captions_enabled ?? b.imageCaptionsEnabled ?? true,
    balance_columns: b.balance_columns ?? b.balanceColumns ?? null,
    clean_spans: b.clean_spans ?? b.cleanSpans ?? true,
    split_list_items: b.split_list_items ?? b.splitListItems ?? true,
    flush_columns: b.flush_columns ?? b.flushColumns ?? true,
    split_equations: b.split_equations ?? b.splitEquations ?? true,
    geometry: b.geometry === 'v3' ? 'v3' : 'v2',
  };
}

function stableStringify(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`;
  return `{${Object.keys(value).sort().map((k) => `${JSON.stringify(k)}:${stableStringify(value[k])}`).join(',')}}`;
}

function convertCacheBasis(body) {
  const { preview, preview_full, ...rest } = body || {};
  return { engineRevision: RENDER_ENGINE_REVISION, payload: rest };
}

async function convertCacheKey(body) {
  const bytes = new TextEncoder().encode(stableStringify(convertCacheBasis(body)));
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

function pdfResponseHeaders(body, pagination, cacheState) {
  const headers = new Headers();
  setCorsHeaders(headers);
  headers.set('Content-Type', 'application/pdf');
  headers.set('X-Engine-Used', body.engine || 'v2-modular');
  headers.set('X-Geometry-Version', body.geometry === 'v3' ? 'v3' : 'v2');
  headers.set('X-Cache', cacheState);
  if (body.preview) {
    headers.set('Content-Disposition', 'inline; filename="preview.pdf"');
  } else {
    headers.set('Content-Disposition', 'attachment; filename="document.pdf"');
  }
  if (pagination) {
    headers.set('X-Document-TOC', encodeURIComponent(JSON.stringify(pagination)));
    headers.set('X-Total-Pages', String(pagination.totalPages || 1));
  }
  return headers;
}

// Worker entry keeps ONLY `export default`: workerd rejects any other named
// export as an invalid entrypoint map entry (breaks `wrangler dev`). Pure
// helpers above stay module-private; live behavior is verified through
// HTTP (upload → convert → pixels), not unit imports.

function setCorsHeaders(headers) {
  headers.set('Access-Control-Allow-Origin', '*');
  headers.set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  headers.set('Access-Control-Expose-Headers', 'X-Document-TOC, X-Total-Pages, X-Engine-Used, X-Geometry-Version');
}

function backendUrl(env, pathname) {
  const base = (env && (env.PDF_BACKEND_URL || env.BACKEND_URL) || '').replace(/\/+$/, '');
  return base ? `${base}${pathname}` : null;
}

// Offloads CPU-heavy PDF work to a Node backend (Render/Fly/VPS) when
// PDF_BACKEND_URL is set. Keeps the isolate far below the Error 1102
// (surfaced as HTTP 503) CPU budget. Falls through to local emitPdf
// when unset so `wrangler dev` and single-Worker deploys keep working.
async function proxyToBackend(target, request, env) {
  const headers = new Headers();
  setCorsHeaders(headers);
  try {
    const raw = await request.text();
    const upstream = await fetch(target, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: raw,
    });
    const outHeaders = new Headers(upstream.headers);
    setCorsHeaders(outHeaders);
    return new Response(upstream.body, { status: upstream.status, headers: outHeaders });
  } catch (err) {
    return new Response(JSON.stringify({ detail: `Backend indisponível (${err.message || err}). Defina PDF_BACKEND_URL ou reduza o documento.` }), {
      status: 502,
      headers: { 'Content-Type': 'application/json; charset=utf-8', ...Object.fromEntries(headers) },
    });
  }
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    // 1. CORS Preflight
    if (request.method === 'OPTIONS') {
      const headers = new Headers();
      setCorsHeaders(headers);
      return new Response(null, { status: 204, headers });
    }

    // 2. Health Check Endpoint
    if (url.pathname === '/api/health') {
      const headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
      setCorsHeaders(headers);
      const backend = backendUrl(env, '/api/convert');
      return new Response(JSON.stringify({ status: 'ok', service: 'DOE Formatter Cloudflare', backend: backend ? 'proxy' : 'local' }), {
        status: 200,
        headers,
      });
    }

    // 3. Image Upload Endpoint (Converts payload to safe Data URI for serverless portability)
    if (url.pathname === '/api/upload-image' && request.method === 'POST') {
      try {
        const body = await request.json();
        const { data, filename } = body || {};
        if (!data || typeof data !== 'string') {
          return new Response(JSON.stringify({ error: 'Dados da imagem não fornecidos' }), {
            status: 400,
            headers: { 'Content-Type': 'application/json; charset=utf-8' },
          });
        }

        let dataUrl = data;
        if (!data.startsWith('data:image/')) {
          dataUrl = `data:image/png;base64,${data}`;
        }
        const safeName = filename || 'figura.png';

        const headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
        setCorsHeaders(headers);
        return new Response(JSON.stringify({
          success: true,
          url: dataUrl,
          filename: safeName,
        }), { status: 200, headers });
      } catch (err) {
        return new Response(JSON.stringify({ error: 'Falha no processamento da imagem: ' + err.message }), {
          status: 500,
          headers: { 'Content-Type': 'application/json; charset=utf-8' },
        });
      }
    }

    // 4. PDF Conversion Endpoint
    if (url.pathname === '/api/convert' && request.method === 'POST') {
      const target = backendUrl(env, '/api/convert');
      if (target) return proxyToBackend(target, request, env);
      try {
        // A2: wire pre-gate before request.json() pays parse + scans.
        if (wireOverLimit(request)) return oversizedResponse();
        const body = await request.json();
        const { sections, markdown, preview } = body || {};
        const hasSections = Array.isArray(sections) && sections.some(s => s.markdown && s.markdown.trim().length > 0);
        const hasMarkdown = typeof markdown === 'string' && markdown.trim().length > 0;

        if (!hasSections && !hasMarkdown) {
          return new Response(JSON.stringify({ detail: 'Markdown content is empty' }), {
            status: 400,
            headers: { 'Content-Type': 'application/json; charset=utf-8' },
          });
        }

        // Worker-first images: extract decodable data-URI bytes into an
        // image map BEFORE stripping (compiler looks up by exact `src`,
        // so keys are full data-URI strings). Corrupt/oversized figures
        // decode to null → placeholder; only a clean budget overrun 413s.
        let imageMap = null;
        try {
          imageMap = extractDataUriImages(body).map;
        } catch (e) {
          if (e && e.message === 'IMAGE_BUDGET_EXCEEDED') return oversizedResponse();
          imageMap = null;
        }

        // A2: single-pass scan — image budget + strip + text budget in
        // one walk (was: measureImages scan, strip scan+copies,
        // payloadSize scan). Text budget applies post-strip so photos
        // don't consume it. Strip output is layout-identical (short
        // tokens either way); real pixels come from imageMap above.
        const scan = scanAndStripBody(body);
        if (scan.imageBytes > MAX_IMAGE_BYTES) {
          return oversizedResponse();
        }

        if ((Array.isArray(sections) && sections.length > MAX_SECTIONS) || scan.chars > MAX_TOTAL_CHARS) {
          return oversizedResponse();
        }

        const docIR = normalizeToDocIR(body);
        const validation = validateDocIR(docIR);
        if (!validation.ok) {
          return new Response(JSON.stringify({ detail: `Invalid DocumentIR: ${validation.errors.join('; ')}` }), {
            status: 400,
            headers: { 'Content-Type': 'application/json; charset=utf-8' },
          });
        }
        // E: content-hash lookup — identical docs skip render entirely.
        // (Key excludes preview/preview_full: bytes are identical, only
        // Content-Disposition varies and is re-applied per request.)
        let convertCache = null;
        let convertCacheReq = null;
        try {
          if (typeof caches !== 'undefined' && caches.default) {
            convertCache = caches.default;
            const key = await convertCacheKey(body);
            convertCacheReq = new Request(`https://cache.internal/convert/${key}`, { method: 'GET' });
            const hit = await convertCache.match(convertCacheReq);
            if (hit) {
              const bytes = await hit.arrayBuffer();
              let pagination = null;
              try {
                const toc = hit.headers.get('X-Document-TOC');
                if (toc) pagination = JSON.parse(decodeURIComponent(toc));
              } catch { /* serve without TOC headers */ }
              const hitHeaders = pdfResponseHeaders(body, pagination, 'HIT');
              hitHeaders.set('Content-Length', String(bytes.byteLength));
              return new Response(bytes, { status: 200, headers: hitHeaders });
            }
          }
        } catch { /* cache unavailable — fall through to render */ }

        const compileOpts = resolveWorkerCompileOptions(body);
        const pdfBuffer = await emitPdf(docIR, { ...compileOpts, template: docIR.template, fontAssets: workerFontAssets, images: imageMap });
        const headers = pdfResponseHeaders(body, pdfBuffer.pagination || null, 'MISS');
        headers.set('Content-Length', String(pdfBuffer.length));

        // E: store render for repeats (bounded size, best-effort).
        try {
          if (convertCache && convertCacheReq && pdfBuffer.length <= CONVERT_CACHE_MAX_BYTES) {
            const storeHeaders = new Headers();
            setCorsHeaders(storeHeaders);
            storeHeaders.set('Content-Type', 'application/pdf');
            storeHeaders.set('X-Engine-Used', 'v2-modular');
            storeHeaders.set('Cache-Control', `public, max-age=${CONVERT_CACHE_TTL}`);
            if (pdfBuffer.pagination) {
              storeHeaders.set('X-Document-TOC', encodeURIComponent(JSON.stringify(pdfBuffer.pagination)));
              storeHeaders.set('X-Total-Pages', String(pdfBuffer.pagination.totalPages || 1));
            }
            const snapshot = new Response(pdfBuffer, { headers: storeHeaders });
            if (ctx && typeof ctx.waitUntil === 'function') ctx.waitUntil(convertCache.put(convertCacheReq, snapshot));
            else await convertCache.put(convertCacheReq, snapshot);
          }
        } catch { /* cache store best-effort */ }

        return new Response(pdfBuffer, { status: 200, headers });
      } catch (err) {
        console.error('Cloudflare Worker PDF conversion error:', err);
        return new Response(JSON.stringify({ detail: err.message || 'Erro ao gerar PDF' }), {
          status: 500,
          headers: { 'Content-Type': 'application/json; charset=utf-8' },
        });
      }
    }

    // 5. Document Pagination Inspection Endpoint (Zero-Divergence ToC Parity)
    if (url.pathname === '/api/paginate' && request.method === 'POST') {
      const target = backendUrl(env, '/api/paginate');
      if (target) return proxyToBackend(target, request, env);
      try {
        // A2: wire pre-gate (see /api/convert).
        if (wireOverLimit(request)) return oversizedResponse();
        const body = await request.json();
        const { sections, markdown } = body || {};
        const hasSections = Array.isArray(sections) && sections.some(s => s.markdown && s.markdown.trim().length > 0);
        const hasMarkdown = typeof markdown === 'string' && markdown.trim().length > 0;

        if (!hasSections && !hasMarkdown) {
          return new Response(JSON.stringify({ detail: 'Markdown content is empty' }), {
            status: 400,
            headers: { 'Content-Type': 'application/json; charset=utf-8' },
          });
        }

        // A2: single-pass scan (see /api/convert).
        const scanPaginate = scanAndStripBody(body);
        if (scanPaginate.imageBytes > MAX_IMAGE_BYTES) {
          return oversizedResponse();
        }

        if ((Array.isArray(sections) && sections.length > MAX_SECTIONS) || scanPaginate.chars > MAX_TOTAL_CHARS) {
          return oversizedResponse();
        }

        const pagCacheKey = workerFastKey(convertCacheBasis(body));
        let cacheState = 'MISS';
        let pagination = PAGINATE_MEM_CACHE.get(pagCacheKey);
        if (pagination !== undefined) {
          cacheState = 'HIT';
          PAGINATE_MEM_CACHE.delete(pagCacheKey);
          PAGINATE_MEM_CACHE.set(pagCacheKey, pagination);
        } else {
          if (body.geometry === 'v3') {
            const t0 = Date.now();
            const compileOpts = resolveWorkerCompileOptions(body);
            const out = await runPipeline({
              payload: body,
              mode: 'paginate',
              geometry: 'v3',
              fontAssets: workerFontAssets,
              options: { ...compileOpts, geometry: 'v3', skip_fit_audit: true },
            });
            pagination = { ...out.pagination, durationMs: Date.now() - t0 };
          } else {
            pagination = calculatePagination(body);
          }
          if (PAGINATE_MEM_CACHE.size >= MAX_PAGINATE_MEM_CACHE) {
            const oldest = PAGINATE_MEM_CACHE.keys().next().value;
            if (oldest !== undefined) PAGINATE_MEM_CACHE.delete(oldest);
          }
          PAGINATE_MEM_CACHE.set(pagCacheKey, pagination);
        }
        const headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8' });
        setCorsHeaders(headers);
        headers.set('X-Cache', cacheState);
        return new Response(JSON.stringify({ success: true, ...pagination }), {
          status: 200,
          headers,
        });
      } catch (err) {
        console.error('Cloudflare Worker pagination error:', err);
        return new Response(JSON.stringify({ detail: err.message || 'Erro ao calcular paginação' }), {
          status: 500,
          headers: { 'Content-Type': 'application/json; charset=utf-8' },
        });
      }
    }

    // 6. Static Assets Passthrough (Workers with Static Assets binding)
    if (env && env.ASSETS && typeof env.ASSETS.fetch === 'function') {
      return env.ASSETS.fetch(request);
    }

    return new Response('Not found', { status: 404 });
  }
};
