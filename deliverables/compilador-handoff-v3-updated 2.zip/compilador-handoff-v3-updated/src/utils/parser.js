/**
 * FocusGate Modular Compiler Utility - Scalable Character Normalizer & Escaper
 *
 * Provides a robust, future-proof escaping and unescaping mechanism for
 * all standard HTML/XML special characters (&, <, >, ", ') and an extensible
 * registry pattern for edge cases without architectural refactoring.
 */

// Standard HTML / XML entities
export const STANDARD_ESCAPE_RULES = {
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;',
};

// Standard reverse lookup (including &apos; alias for single quote)
export const STANDARD_UNESCAPE_RULES = {
  '&amp;': '&',
  '&lt;': '<',
  '&gt;': '>',
  '&quot;': '"',
  '&#39;': "'",
  '&apos;': "'",
  '&nbsp;': ' ',
};

/**
 * Scalable Character Escaping Registry
 * Allows dynamic extension of character transformations and profiles.
 */
export class CharacterEscapingRegistry {
  constructor(initialRules = STANDARD_ESCAPE_RULES, initialUnescape = STANDARD_UNESCAPE_RULES) {
    this._rules = new Map(Object.entries(initialRules));
    this._reverseRules = new Map(Object.entries(initialUnescape));
    this._buildRegex();
  }

  /**
   * Registers or overrides an escape rule.
   * @param {string} char - Special character to escape
   * @param {string} entity - Corresponding HTML/XML entity
   */
  register(char, entity) {
    if (!char || typeof char !== 'string') {
      throw new TypeError('Character to escape must be a non-empty string');
    }
    if (!entity || typeof entity !== 'string') {
      throw new TypeError('Entity must be a non-empty string');
    }
    this._rules.set(char, entity);
    this._reverseRules.set(entity, char);
    this._buildRegex();
    return this;
  }

  /**
   * Batch registers multiple rules.
   * @param {Record<string, string>} rulesMap
   */
  registerMany(rulesMap) {
    if (!rulesMap || typeof rulesMap !== 'object') {
      throw new TypeError('rulesMap must be an object');
    }
    for (const [char, entity] of Object.entries(rulesMap)) {
      this._rules.set(char, entity);
      this._reverseRules.set(entity, char);
    }
    this._buildRegex();
    return this;
  }

  /**
   * Removes a character escaping rule.
   * @param {string} char
   */
  unregister(char) {
    const entity = this._rules.get(char);
    if (entity) {
      this._rules.delete(char);
      this._reverseRules.delete(entity);
      this._buildRegex();
    }
    return this;
  }

  has(char) {
    return this._rules.has(char);
  }

  hasEntity(entity) {
    return this._reverseRules.has(entity);
  }

  get(char) {
    return this._rules.get(char);
  }

  getReverse(entity) {
    return this._reverseRules.get(entity);
  }

  getAllRules() {
    return Object.fromEntries(this._rules.entries());
  }

  getAllReverseRules() {
    return Object.fromEntries(this._reverseRules.entries());
  }

  _escapeRegex(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  _buildRegex() {
    // Escaping regex excludes '&' because '&' requires special lookahead logic
    // to prevent double-escaping existing entities (e.g. '&gt;' -> '&amp;gt;').
    const nonAmpChars = Array.from(this._rules.keys()).filter(c => c !== '&');
    if (nonAmpChars.length > 0) {
      const charPattern = nonAmpChars.map(c => this._escapeRegex(c)).join('|');
      this._nonAmpRegex = new RegExp(`(${charPattern})`, 'g');
    } else {
      this._nonAmpRegex = null;
    }

    // Unescaping regex for all entities
    const entities = Array.from(this._reverseRules.keys());
    if (entities.length > 0) {
      const entityPattern = entities.map(e => this._escapeRegex(e)).join('|');
      this._unescapeRegex = new RegExp(`(${entityPattern})`, 'g');
    } else {
      this._unescapeRegex = null;
    }
  }

  /**
   * Escapes a string using registered rules with idempotence against already escaped entities.
   * @param {string} text - Raw input string
   * @param {object} [opts={}] - Custom options
   * @returns {string} Escaped string
   */
  escape(text, opts = {}) {
    if (text === null || text === undefined) return '';
    let str = String(text);
    if (str.length === 0) return '';

    const ampEntity = this._rules.get('&') || '&amp;';

    // Step 1: Escape ampersands not already part of a valid HTML/XML entity or numeric reference.
    // Matches '&' unless followed by known alphanumeric entity name or numeric hex/dec code.
    if (this._rules.has('&')) {
      str = str.replace(/&(?!(?:[a-zA-Z0-9]+|#[0-9]{1,7}|#[xX][0-9a-fA-F]{1,6});)/g, ampEntity);
    }

    // Step 2: Escape other registered special characters (<, >, ", ', and any registered extensions)
    if (this._nonAmpRegex) {
      str = str.replace(this._nonAmpRegex, (match) => this._rules.get(match) || match);
    }

    return str;
  }

  /**
   * Unescapes a string using registered reverse rules.
   * @param {string} text - Escaped input string
   * @returns {string} Literal unescaped string
   */
  unescape(text) {
    if (text === null || text === undefined) return '';
    let str = String(text);
    if (str.length === 0) return '';

    if (this._unescapeRegex) {
      str = str.replace(this._unescapeRegex, (match) => this._reverseRules.get(match) || match);
    }

    return str;
  }
}

// Global default singleton normalizer instance
export const defaultNormalizer = new CharacterEscapingRegistry();

/**
 * Normalizes special characters by escaping dangerous or ambiguous HTML/XML characters
 * (&, <, >, ", ') into their standard entity representations.
 *
 * @param {string} text - Raw input string
 * @param {object} [options={}] - Optional configuration:
 * @param {CharacterEscapingRegistry} [options.registry] - Custom registry instance
 * @param {Record<string, string>} [options.customRules] - Ad-hoc rules for this execution
 * @returns {string} Normalized string
 */
export function normalizeSpecialCharacters(text, options = {}) {
  let registry = options.registry || defaultNormalizer;
  if (options.customRules) {
    registry = new CharacterEscapingRegistry(
      { ...registry.getAllRules(), ...options.customRules },
      { ...registry.getAllReverseRules() }
    );
  }
  return registry.escape(text, options);
}

/**
 * Direct alias for normalizeSpecialCharacters.
 * Specifically converts:
 *   >  ->  &gt;
 *   <  ->  &lt;
 *   &  ->  &amp;
 *   "  ->  &quot;
 *   '  ->  &#39;
 *
 * @param {string} text - Raw input string
 * @param {object} [options={}]
 * @returns {string} Escaped string
 */
export function escapeSpecialChars(text, options = {}) {
  return normalizeSpecialCharacters(text, options);
}

/**
 * Reversibly decodes HTML/XML entities back to literal characters.
 *
 * @param {string} text - Escaped string
 * @param {object} [options={}]
 * @returns {string} Unescaped string
 */
export function unescapeSpecialChars(text, options = {}) {
  const registry = options.registry || defaultNormalizer;
  return registry.unescape(text);
}

/**
 * Convenience helper to register a new escape rule globally for future extensions.
 * @param {string} char
 * @param {string} entity
 */
export function registerEscapeRule(char, entity) {
  defaultNormalizer.register(char, entity);
}

/**
 * Convenience helper to register multiple escape rules globally.
 * @param {Record<string, string>} rulesMap
 */
export function registerManyEscapeRules(rulesMap) {
  defaultNormalizer.registerMany(rulesMap);
}
