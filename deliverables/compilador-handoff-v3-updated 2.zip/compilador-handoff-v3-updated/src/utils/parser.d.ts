export interface EscapeOptions {
  registry?: CharacterEscapingRegistry;
  customRules?: Record<string, string>;
  idempotent?: boolean;
}

export declare class CharacterEscapingRegistry {
  constructor(initialRules?: Record<string, string>, initialUnescape?: Record<string, string>);
  register(char: string, entity: string): this;
  registerMany(rulesMap: Record<string, string>): this;
  unregister(char: string): this;
  has(char: string): boolean;
  hasEntity(entity: string): boolean;
  get(char: string): string | undefined;
  getReverse(entity: string): string | undefined;
  getAllRules(): Record<string, string>;
  getAllReverseRules(): Record<string, string>;
  escape(text: string, opts?: EscapeOptions): string;
  unescape(text: string): string;
}

export declare const defaultNormalizer: CharacterEscapingRegistry;
export declare function normalizeSpecialCharacters(text: string, options?: EscapeOptions): string;
export declare function escapeSpecialChars(text: string, options?: EscapeOptions): string;
export declare function unescapeSpecialChars(text: string, options?: EscapeOptions): string;
export declare function registerEscapeRule(char: string, entity: string): void;
export declare function registerManyEscapeRules(rulesMap: Record<string, string>): void;
