import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import crypto from 'node:crypto';
import { convertDocument, calculatePagination } from './pdf-engine.js';
import { runPipeline } from './src/v2/runtime/pipeline.js';
import { validateImageBuffer, detectImageType } from './src/v2/modules/image-module.js';
import { compileTypstSource, sandboxTypstAssets } from './src/v2/drivers/typst/compile.js';
import { createRateLimiter, envInt } from './src/v2/server/rate-limit.js';

const app = express();
const PORT = 3000;

// Ensure static/uploads exists for uploaded images
const uploadsDir = path.join(process.cwd(), 'static', 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Middleware
const corsOrigins = process.env.CORS_ORIGINS
  ? process.env.CORS_ORIGINS.split(',').map(s => s.trim()).filter(Boolean)
  : null;

if (corsOrigins && corsOrigins.length > 0) {
  app.use(cors({ origin: corsOrigins, credentials: true }));
} else {
  // Same-origin by deployment (express serves static + API; Cloudflare worker
  // likewise). Permissive fallback kept for split deploys — set CORS_ORIGINS
  // to lock down. This warning makes the open default visible (CC4).
  console.warn('[cors] CORS_ORIGINS unset — allowing all origins (open default)');
  app.use(cors());
}

// CC4: dependency-free fixed-window throttles on the expensive endpoints.
// Tunables: RATE_LIMIT_CONVERT / RATE_LIMIT_UPLOAD / RATE_LIMIT_PAGINATE
// (req/min/IP). Paginate is debounced client-side (~350ms) so its ceiling
// sits above pathological typing bursts; converts render full PDFs.
const convertLimiter = createRateLimiter({ max: envInt('RATE_LIMIT_CONVERT', 60) });
const uploadLimiter = createRateLimiter({ max: envInt('RATE_LIMIT_UPLOAD', 60) });
const paginateLimiter = createRateLimiter({ max: envInt('RATE_LIMIT_PAGINATE', 300) });

app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// Boundary validation for conversion endpoints (prod hardening):
// non-string section markdown is treated as empty (never throws on .trim),
// and total input text is capped so oversized payloads fail fast with 413
// instead of stalling the event loop in layout.
const MAX_CONVERT_CHARS = 2_000_000;
function sectionText(s) {
  return (s && typeof s.markdown === 'string') ? s.markdown : '';
}
function convertBodyStats(body = {}) {
  const sections = Array.isArray(body.sections) ? body.sections : [];
  let chars = 0;
  for (const s of sections) {
    chars += sectionText(s).length;
  }
  const single = typeof body.markdown === 'string' ? body.markdown : '';
  chars += single.length;
  return { chars };
}

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'DOE Formatter' });
});

// Image Upload Endpoint (Frontend-to-Backend clean storage)
app.post('/api/upload-image', uploadLimiter, (req, res) => {
  try {
    const { data, filename } = req.body || {};
    if (!data || typeof data !== 'string') {
      return res.status(400).json({ error: 'Dados da imagem não fornecidos' });
    }

    let ext = 'png';
    let base64Payload = data;

    const mimeMatch = data.match(/^data:image\/([a-zA-Z0-9+.-]+);base64,/i);
    if (mimeMatch) {
      const mimeSub = mimeMatch[1].toLowerCase();
      if (mimeSub === 'jpeg') ext = 'jpg';
      else if (mimeSub === 'svg+xml') ext = 'svg';
      else ext = mimeSub.replace(/[^a-z0-9]/g, '') || 'png';
      base64Payload = data.slice(mimeMatch[0].length);
    } else if (filename) {
      const extMatch = filename.match(/\.([a-zA-Z0-9]+)$/);
      if (extMatch) {
        ext = extMatch[1].toLowerCase();
      }
    }

    if (!['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg'].includes(ext)) {
      ext = 'png';
    }

    const safeBaseName = (filename ? path.basename(filename, path.extname(filename)) : 'figura')
      .replace(/[^a-zA-Z0-9_-]/g, '_')
      .slice(0, 30);
    const uniqueName = `img_${Date.now()}_${safeBaseName}.${ext}`;
    const targetPath = path.join(uploadsDir, uniqueName);

    const buffer = Buffer.from(base64Payload, 'base64');
    // Per-file cap aligned with the pipeline gate (MAX_IMAGE_BYTES = 15MB in
    // src/v2/modules/image-module.js): larger rasters are rejected downstream
    // anyway, so fail fast here instead of writing unbounded bytes to disk.
    const MAX_UPLOAD_BYTES = 15 * 1024 * 1024;
    if (buffer.length > MAX_UPLOAD_BYTES) {
      return res.status(413).json({ error: 'Imagem excede o limite de 15MB', code: 'IMAGE_TOO_LARGE' });
    }
    if (buffer.length === 0) {
      return res.status(400).json({ error: 'Imagem vazia ou base64 inválido', code: 'IMAGE_EMPTY' });
    }
    // Magic-byte gate (no silent png-coerce): only PDFKit-rasterizable bytes
    // are stored; anything else fails fast with 422 instead of rendering a
    // silent placeholder downstream. SVG stays allowed (vector, stored as-is).
    if (ext !== 'svg') {
      const probe = validateImageBuffer(buffer);
      if (!probe) {
        const detected = detectImageType(buffer);
        return res.status(422).json({
          error: detected
            ? `Formato '${detected}' não suportado no PDF (use PNG ou JPEG)`
            : 'Arquivo não é uma imagem PNG/JPEG válida',
          code: 'IMAGE_UNSUPPORTED_TYPE',
        });
      }
    }
    const sha256 = crypto.createHash('sha256').update(buffer).digest('hex').slice(0, 16);
    fs.writeFileSync(targetPath, buffer);
    console.log(`[upload-image] ${uniqueName} ${buffer.length}B sha=${sha256} ext=${ext}`);

    const publicUrl = `/uploads/${uniqueName}`;
    return res.json({
      success: true,
      url: publicUrl,
      filename: uniqueName,
      size: buffer.length,
      sha256,
    });
  } catch (err) {
    console.error('Erro no upload de imagem:', err);
    return res.status(500).json({ error: 'Falha ao salvar imagem no servidor' });
  }
});

// Compiles Typst source (as emitted by the pdf-engine typst driver) to PDF
// bytes via the Typst binary. Shared by /api/convert when engine=v2-typst,
// where generatePdf() resolves to a source string instead of a PDF buffer.
// (CC4: lives in src/v2/drivers/typst/compile.js — timeout + asset sandbox.)

// PDF Conversion Endpoint
app.post('/api/convert', convertLimiter, async (req, res) => {
  try {
    const { sections, markdown, preview } = req.body || {};

    const stats = convertBodyStats(req.body);
    if (stats.chars > MAX_CONVERT_CHARS) {
      return res.status(413).json({ detail: 'Conteúdo excede o limite de 2M caracteres' });
    }
    const hasSections = Array.isArray(sections) && sections.some(s => sectionText(s).trim().length > 0);
    const hasMarkdown = typeof markdown === 'string' && markdown.trim().length > 0;

    if (!hasSections && !hasMarkdown) {
      return res.status(400).json({ detail: 'Markdown content is empty' });
    }

    const requestedDriver = req.body?.driver || (req.body?.engine === 'v2-typst' ? 'typst' : 'pdfkit');
    let pdfBuffer = await convertDocument(req.body, {
      driver: requestedDriver,
      format: 'pdf',
    });
    const usedEngine = req.body?.engine || 'v1';

    // The v2-typst driver emits Typst source (string), not PDF bytes.
    // Compile it so the response is always an openable PDF.
    if (typeof pdfBuffer === 'string') {
      try {
        pdfBuffer = await compileTypstSource(pdfBuffer);
      } catch (err) {
        console.error('Typst compile error:', err);
        return res.status(500).json({ detail: `Falha ao compilar Typst (${usedEngine}): ${err.message || err}` });
      }
    }

    res.setHeader('Access-Control-Expose-Headers', 'X-Document-TOC, X-Total-Pages, X-Engine-Used, X-Geometry-Version');
    res.setHeader('X-Geometry-Version', pdfBuffer.pagination?.geometry || req.body?.geometry || 'v2');
    res.setHeader('X-Engine-Used', usedEngine);
    if (pdfBuffer.pagination) {
      res.setHeader('X-Document-TOC', encodeURIComponent(JSON.stringify(pdfBuffer.pagination)));
      res.setHeader('X-Total-Pages', String(pdfBuffer.pagination.totalPages || 1));
    }

    res.setHeader('Content-Type', 'application/pdf');
    if (preview) {
      res.setHeader('Content-Disposition', 'inline; filename="preview.pdf"');
    } else {
      res.setHeader('Content-Disposition', 'attachment; filename="document.pdf"');
    }
    res.setHeader('Content-Length', pdfBuffer.length);
    return res.send(pdfBuffer);
  } catch (err) {
    console.error('PDF generation error:', err);
    return res.status(500).json({ detail: err.message || 'Erro ao gerar PDF' });
  }
});

// V2 staging endpoint (opt-in only; legacy /api/convert untouched).
// Requires body.v2 === true. Returns deterministic Typst source as text/plain
// (no Typst binary in this env to compile PDFs). Template via body.template
// or V2_TEMPLATE env. Kill-switch: set V2_STAGING=0 to disable.
app.post('/api/convert-v2', convertLimiter, async (req, res) => {
  try {
    if (process.env.V2_STAGING === '0') {
      return res.status(409).json({ detail: 'V2 staging disabled' });
    }
    const { sections, markdown, template, v2, format } = req.body || {};
    if (v2 !== true) {
      return res.status(400).json({ detail: 'Opt-in required: { v2: true }' });
    }
    const statsV2 = convertBodyStats(req.body);
    if (statsV2.chars > MAX_CONVERT_CHARS) {
      return res.status(413).json({ detail: 'Conteúdo excede o limite de 2M caracteres' });
    }
    const hasSections = Array.isArray(sections) && sections.some(s => sectionText(s).trim().length > 0);
    const hasMarkdown = typeof markdown === 'string' && markdown.trim().length > 0;
    if (!hasSections && !hasMarkdown) {
      return res.status(400).json({ detail: 'Markdown content is empty' });
    }
    const { renderWithTemplate } = await import('./src/v2/templates/index.js');
    const blocks = hasSections
      ? sections.filter(s => sectionText(s).trim()).map(s => ({
        title: s.title || s.name || '',
        markdown: sectionText(s),
        masthead: {
          enabled: s.enable_masthead !== false && !!(s.masthead_course || s.masthead_topic),
          prefix: s.masthead_prefix || s.masthead?.prefix || '',
          header: s.masthead_header === true || s.masthead?.header === true,
          course: s.masthead_course || '',
          topic: s.masthead_topic || '',
        },
      }))
      : [{ title: '', markdown }];
    const doc = {
      title: 'V2 staging',
      template: template || process.env.V2_TEMPLATE || 'base',
      headerText: req.body.header_text || '',
      headerDate: req.body.header_date || null,
      headerOnTop: req.body.show_header_top !== false && req.body.header_position !== 'footer',
      footerText: req.body.doc_title || '',
      alignment: req.body.alignment || (req.body.raggedright ? 'left' : 'justify'),
      lang: ['pt', 'es', 'en'].includes(req.body.lang) ? req.body.lang : undefined,
      blocks,
    };
    const out = renderWithTemplate(doc, doc.template);
    if (format === 'pdf') {
      // Resolve editor-uploaded images (static/uploads/...) into a sandbox dir.
      // (CC4: shared helper — also the autobalance resolveAssets callback.)
      const resolveV2Assets = (text, dest) => sandboxTypstAssets(text, dest);
      // Two-pass terminal balancing (opt-out: V2_BALANCE=0).
      let balSource = out.source;
      let balanceNote = 'off';
      if (process.env.V2_BALANCE !== '0') {
        try {
          const { autobalance } = await import('./src/v2/layout/autobalance.js');
          const t0 = Date.now();
          const bal = autobalance(out.tree, out.emitOpts, { resolveAssets: resolveV2Assets });
          balSource = bal.source;
          balanceNote = bal.balanced ? `balanced ${bal.delta?.toFixed?.(1) ?? '?'}pt/${bal.compiles}c` : `unbalanced ${bal.reason}/${bal.compiles}c`;
          console.log(`V2 balance [${out.template}]: ${balanceNote} (${Date.now() - t0}ms)`);
        } catch (err) {
          balanceNote = `error ${err.message}`;
          console.error('V2 balance error (shipping unbalanced):', err.message);
        }
      }
      // Final compile owns its sandbox + timeout (CC4 seam); asset refs are
      // resolved inside compileTypstSource.
      const buf = await compileTypstSource(balSource);
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('X-V2-Template', out.template);
      res.setHeader('X-V2-Balance', balanceNote);
      res.setHeader('Content-Disposition', 'attachment; filename="document-v2.pdf"');
      res.setHeader('Content-Length', buf.length);
      return res.send(buf);
    }
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('X-V2-Template', out.template);
    return res.send(out.source);
  } catch (err) {
    console.error('V2 staging error:', err);
    return res.status(500).json({ detail: err.message || 'Erro ao gerar fonte Typst' });
  }
});

// Document Pagination Inspection Endpoint (Zero-Divergence ToC Parity)
app.post('/api/paginate', paginateLimiter, async (req, res) => {
  try {
    const { sections, markdown } = req.body || {};
    const statsP = convertBodyStats(req.body);
    if (statsP.chars > MAX_CONVERT_CHARS) {
      return res.status(413).json({ detail: 'Conteúdo excede o limite de 2M caracteres' });
    }
    const hasSections = Array.isArray(sections) && sections.some(s => sectionText(s).trim().length > 0);
    const hasMarkdown = typeof markdown === 'string' && markdown.trim().length > 0;

    if (!hasSections && !hasMarkdown) {
      return res.status(400).json({ detail: 'Markdown content is empty' });
    }

    if (req.body && req.body.geometry === 'v3') {
      const t0 = Date.now();
      const out = await runPipeline({ payload: req.body, mode: 'paginate', geometry: 'v3', options: { skip_fit_audit: true } });
      return res.json({ success: true, ...out.pagination, estimated: false, geometry: 'v3', durationMs: Date.now() - t0 });
    }
    const pagination = calculatePagination(req.body);
    return res.json({ success: true, ...pagination });
  } catch (err) {
    console.error('Pagination calculation error:', err);
    return res.status(500).json({ detail: err.message || 'Erro ao calcular paginação' });
  }
});

// Static assets
const staticDir = path.join(process.cwd(), 'static');
app.use(express.static(staticDir));

// SPA fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(staticDir, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`DOE Formatter server running at http://0.0.0.0:${PORT}`);
});
