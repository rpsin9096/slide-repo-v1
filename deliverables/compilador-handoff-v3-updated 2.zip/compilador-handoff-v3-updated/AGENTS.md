# AGENTS.md

Instructions for any agent or maintainer working in this repository. Read this before changing code, specs, tests, or deployment files.

## Read order

1. `README.md` for the quickstart and project map.
2. `specs/00-INDEX.md` for the spec set and ownership table.
3. The owning spec for the behavior you are changing.
4. `specs/07-TESTING.md` for the required evidence.
5. `ALTERATIONS.md` for recent decisions.

## Non-negotiable rules

### 1. Specs are normative

`specs/` describes the system this repository intends to be. Code describes current behavior. If they disagree, do not silently follow one. Resolve the disagreement in the same change: fix the code or the spec, and record the decision.

### 2. Every behavior change updates its owning spec

- Request fields/defaults/limits → `specs/03-INPUT.md`
- Page/layout behavior → `specs/04-LAYOUT.md`
- DisplayList/PDF/driver/response shapes → `specs/05-OUTPUT.md`
- Run/build/deploy/security → `specs/06-OPERATIONS.md`
- Test tiers/fixtures/corpus → `specs/07-TESTING.md`
- Component boundaries/data flow → `specs/02-ARCHITECTURE.md`
- Product scope/glossary → `specs/01-PRODUCT.md`

Do not duplicate a fact in two specs. Link to the owner.

### 3. Every change appends to the alterations log

Add an entry to `ALTERATIONS.md` with:

- Date (`YYYY-MM-DD`)
- What changed
- Why
- Verification performed
- Any intentional breaking change or unresolved risk

The log is append-only. Do not rewrite history.

### 4. Tests are evidence, not obstacles

- Run `npm test` before committing behavior changes.
- Run `npm run test:design` when touching editor markup, CSS, or design tokens.
- Run `npm run test:all` before a handoff or release.
- For a bug, add a test that fails before the fix when practical.
- If a test is red, classify it: regression, intentional behavior change, environment/flake, or obsolete. Fix the cause; do not delete/skip/weaken a test to get green.
- Golden/fixture changes require a reviewed diff, a checked-in regeneration command, and an alterations entry.
- Source/CSS design locks are tripwires, not proof of runtime appearance. If a visual behavior matters, add a browser/computed-style test rather than weakening the lock silently.

### 5. Preserve the sanitized boundary

Do not add to the repository:

- Secrets, API keys, tokens, `.env` files, shell profiles, or credentials.
- Personal data, names, emails, phone numbers, screenshots, scans, or uploaded images.
- `node_modules/`, `dist/`, `.wrangler/`, `coverage/`, or `static/uploads/` contents.
- Generated `src/font-assets-data.js` (rebuild it).
- AI/session debris, old plans, roadmaps, focus-gate state, or agent scratch directories.
- Large binaries without a clear runtime/test purpose.

If you discover a secret in the tree or history, do not echo it. Rotate it and remove it; record the remediation without the value.

### 6. Generated files

- `src/afm-data.js` is generated but committed. Rebuild with `npm run build`; do not hand-edit.
- `src/font-assets-data.js` is generated and gitignored. Do not commit it.
- `dist/` is generated and gitignored. Do not commit it.
- `tests/fixtures/*.json` are hand-reviewed goldens. Regenerate only with the documented command and review the diff.

### 7. Keep the product name and language stable

- The product is **Compilador do Raul**. Do not rebrand it.
- The editor UI is Portuguese. Preserve Portuguese labels and domain terms when editing UI text.
- The documentation is English. Keep it clear and factual.

## Change workflow

1. **Locate the owner.** Read the relevant spec and the code it describes.
2. **State the evidence.** What test or manual check proves the current behavior? What will prove the new behavior?
3. **Make the smallest coherent change.** Avoid unrelated refactors in the same commit.
4. **Update the spec.** If the behavior or intent changed, update the owning spec. If only implementation changed, say so in the alterations entry.
5. **Add/adjust tests.** Prefer behavior tests. Keep corpus/fixture changes deliberate.
6. **Verify.** Run the commands appropriate to the surface.
7. **Log.** Append to `ALTERATIONS.md`.
8. **Commit.** One logical change; do not mix formatting churn with behavior.

## Verification commands

```bash
npm run lint
npm test
npm run test:design   # UI/CSS changes
npm run test:all      # handoff/release
```

For server changes, also smoke-test:

```bash
npm run dev
curl -s http://localhost:3000/api/health
curl -sS -D - -o /tmp/smoke.pdf -X POST http://localhost:3000/api/convert \
  -H 'Content-Type: application/json' \
  -d '{"markdown":"# Smoke\n\nHello PDF","preview":true}'
```

For build/deploy changes, run `npm run build` and, if credentials/network are available, `npm run dev:cf`. Do not claim a deploy succeeded without the command output.

## Files and areas that need extra care

- `src/v2/compiler/geometry-compiler.js` — large, central layout engine. Change one behavior at a time; run the full layout suites.
- `src/v2/layout/` — seams, bands, multicol, calibration. Glue changes can silently move every page; review goldens.
- `src/v2/drivers/` — purity boundary. Drivers must consume only the frozen DisplayList and must not measure/re-layout.
- `static/v2-app.js` and `static/document-store.js` — duplicated editor/store state. Flush adapters before saving; preserve migration behavior.
- `static/design-system.css` and `static/shell.css` — split ownership and load order. `shell.css` must load after `design-system.css`.
- `server.js` and `src/_worker.js` — different limits, CORS, and error envelopes. Do not assume Node behavior applies to the Worker.
- `tests/corpus/` — fixed layout evidence. Do not move it back to the root or edit a document to make a test pass without a fixture review.

## When to ask

Ask the human partner before:

- Changing the product name, scope, or non-goals.
- Removing a feature or a test suite.
- Regenerating a golden that changes many pages without a clear explanation.
- Adding a dependency, network service, account, or secret.
- Weakening a documented security or layout invariant.
- Making a breaking API change.

## Definition of done

A change is done when:

- The owning spec and `ALTERATIONS.md` are updated.
- The relevant tests pass, with output observed.
- No sanitization invariant is violated.
- The change is small enough to review and has a clear reason.
- Any residual risk or unverified surface is stated in the alterations entry, not hidden.
