# FocusGate Production Ledger: compilador-handoff-v3-frontend-finetuning
Active: none

## 1. Domain Anchors
- **SystemArchetype**: Immutable 8-dimension configuration tuple (spacing_base: 4px, corner: soft, depth: hairline, type_lanes: 2, display_weight_ceiling: 600, content_cap: 1280px, breakpoints: [480, 768, 1024, 1280], mode: both).
- **ThreeLayerTokens**: Non-skipping CSS custom-property graph where --primitive-* holds raw literals, semantic tokens (--color-*, --surface, --ink, --line) reference primitives across light and dark modes, and components reference semantic/component tokens only.
- **StateMatrix**: Complete 5-state interactive matrix (default, @media (hover: hover) :hover, :focus-visible, :active, :disabled) with reserved geometry and non-opacity-only disabled surfaces.
- **HairlineDepth**: 0.5px/1px hairline separator and surface-flip elevation language with zero card hover shadow lift and closed 4px-aligned radii.
- **GateReceiptChain**: Append-only SHA-256 hash-chained evidence log in .focusgate/GATES.evidence.jsonl proving Red-Before-Green settlement.
- **WorkerIsolateBudget**: Sub-10ms warm pagination and incremental block-item + DisplayList memoization within Cloudflare Workers Free Plan CPU (10ms) and memory (128MB) isolate limits with zero geometric drift.
- **EditorialGeometryV2**: Template-aware 96-DPI multi-unit & paper-preset resolver (4-tier precedence), dynamic @page rule injector, transitive heading/list-intro glue calculator, rowspan-safe table & list continuation splitter, and framed-safe .is-page-bottom margin/padding suppressor verified across 6 falsifiable DOM gates.

## 2. Acceptance Gates
- [x] gate-1-token-integrity: Enforce 3-layer token discipline, zero untokenized literals in components, and semantic-only [data-theme="dark"] overrides
  DEPS: []
  CHECK: python3 scripts/design_guardrails.py --config design-guardrails.config.json --audit-tokens static
  EXPECT: AUDIT_TOKENS_PASS
  EVIDENCE: exit=0 | AUDIT_TOKENS_PASS (layers=3, dark_mode=semantic_only, untokenized_literals=0) | sha256:0141cc7c0b3f

- [x] gate-2-contrast: Verify WCAG 2.1 AA contrast (>= 4.5:1) across all 11 light and dark semantic text/surface pairs including --ink-mute on --page
  DEPS: [gate-1-token-integrity]
  CHECK: python3 scripts/design_guardrails.py --config design-guardrails.config.json --audit-contrast static
  EXPECT: CONTRAST_PASS_AA
  EVIDENCE: exit=0 | CONTRAST_PASS_AA (all 11 light/dark semantic pairs >= 4.5:1) | sha256:60dbd3c50e29

- [x] gate-3-layout: Enforce 4px structural spacing base across static/design-system.css and static/shell.css and 70% safe-zone compliance
  DEPS: [gate-2-contrast]
  CHECK: python3 scripts/design_guardrails.py --config design-guardrails.config.json --audit-layout static --base 4
  EXPECT: LAYOUT_PASS
  EVIDENCE: exit=0 | LAYOUT_PASS (SPACING_PASS base=4px, off_grid=0, SAFE_ZONE_PASS) | sha256:6e7fd4a3302b

- [x] gate-4-type: Enforce closed type scale, 2-family budget, tabular-nums, text-wrap balance on headings, and text-wrap pretty on paragraphs
  DEPS: [gate-3-layout]
  CHECK: python3 scripts/design_guardrails.py --config design-guardrails.config.json --audit-type static
  EXPECT: TYPE_PASS
  EVIDENCE: exit=0 | TYPE_PASS (families=2, scale=closed, text_wrap=balance+pretty, tabular_nums=true) | sha256:206b5d8c6e3c

- [x] gate-5-states: Enforce complete 5-state interactive matrix, @media (hover: hover) guard, surface-backed disabled state, and closed 4px-aligned radius set
  DEPS: [gate-4-type]
  CHECK: python3 scripts/design_guardrails.py --config design-guardrails.config.json --audit-states static
  EXPECT: STATES_PASS
  EVIDENCE: exit=0 | STATES_PASS (RADIUS_PASS, SHADOW_PASS, 5_state_matrix=complete, hover_media_guarded=true) | sha256:eded7985a39f

- [x] gate-6-responsive: Enforce 100dvh mobile viewport units, reduced-motion handling, and verified 10-section DESIGN.md specification
  DEPS: [gate-5-states]
  CHECK: python3 scripts/design_guardrails.py --config design-guardrails.config.json --audit-responsive static --document DESIGN.md
  EXPECT: RESPONSIVE_PASS
  EVIDENCE: exit=0 | RESPONSIVE_PASS (DOCUMENT_PASS, PROSE_AUDIT_PASS, DESIGN_AUDIT_PASS, dvh=true) | sha256:4261d8359e02

- [x] gate-7-consolidation: Verify aggregate design guardrails audit, AST code rigor, and all 33 visual design regression tests
  DEPS: [gate-6-responsive]
  CHECK: python3 scripts/design_guardrails.py --config design-guardrails.config.json --audit-all static --document DESIGN.md && npm run test:design
  EXPECT: AUDIT_ALL_PASS
  EVIDENCE: exit=0 | AUDIT_TOKENS_PASS (layers=3, dark_mode=semantic_only, untokenized_literals=0) | sha256:241cb60fb91d

- [x] gate-8-compiler-hotpaths: Optimize parseInlineRuns, TypographicAutofix, wrapRunsToLines single-pass token measurement, calculateStringWidth LUT, and fontkit layout caching
  DEPS: [gate-7-consolidation]
  CHECK: node scripts/probe-compiler-efficiency.mjs --gate hotpaths
  EXPECT: HOTPATHS_PASS
  EVIDENCE: exit=0 | {"gate":"gate-8-compiler-hotpaths","pass":true,"autofixMs":5.99,"parseRunsMs":8.86,"calcWidthMs":0.5 | sha256:f8851c26811b

- [x] gate-9-worker-isolate-budget: Enforce Cloudflare Free Plan (<10ms warm paginate) via bounded DisplayList & block-item LRU memoization, paginate-to-convert reuse, and zero-overhead telemetry
  DEPS: [gate-8-compiler-hotpaths]
  CHECK: node scripts/probe-compiler-efficiency.mjs --gate worker-budget
  EXPECT: WORKER_BUDGET_PASS
  EVIDENCE: exit=0 | {"gate":"gate-9-worker-isolate-budget","pass":true,"avgWarmPaginateMs":2.83,"maxSinglePaginateMs":3. | sha256:d23a65eb7068

- [x] gate-10-zero-drift-parity: Verify >=2.2x uncached full-corpus compile speedup, <15ms cached corpus compile, and 100% bit-identical V2/V3 geometric parity (157/157 rows, VG-0..VG-17)
  DEPS: [gate-9-worker-isolate-budget]
  CHECK: node scripts/probe-compiler-efficiency.mjs --gate parity && node scripts/probe-geometry-baseline.mjs --geometry v3 --gate all --verify-v2-fixture
  EXPECT: EFFICIENCY_PARITY_PASS
  EVIDENCE: exit=0 | {"gate":"gate-10-zero-drift-parity","pass":true,"allIdentical":true,"totalUncachedCompileMs":145.15, | sha256:d6923577fa83

- [x] gate-11-template-geometry-guardrails: Enforce Template-Aware Geometry & Fragmentation profiles in design-guardrails.config.json and @page / continuation / page-bottom rules in design-system.css
  DEPS: [gate-10-zero-drift-parity]
  CHECK: node scripts/probe-editorial-geometry-v2.mjs --gate config-css && python3 scripts/design_guardrails.py --config design-guardrails.config.json --audit-all static --document DESIGN.md && npm run test:design
  EXPECT: GATE_11_CONFIG_CSS_PASS
  EVIDENCE: exit=0 | GATE_11_CONFIG_CSS_PASS | sha256:23a4f75b2d63

- [x] gate-12-editorial-geometry-engine: Verify EditorialGeometryEngine 96-DPI multi-unit presets, 4-tier template resolution, transitive heading/list-intro glue, atomic push-down, rowspan-safe table/list continuation splitting, and framed-safe .is-page-bottom suppression
  DEPS: [gate-11-template-geometry-guardrails]
  CHECK: node scripts/probe-editorial-geometry-v2.mjs --gate engine && node --test tests/lean/editorial-geometry-v2.lean.js
  EXPECT: GATE_12_ENGINE_PASS
  EVIDENCE: exit=0 | GATE_12_ENGINE_PASS | sha256:18155e7297aa

- [x] gate-13-pipeline-integration-and-6-gate-audit: Verify pdf-engine.js, pdf-generator.js (generateEditorialPdf), editor-core.js (initializeEditorialPagination), V3 compiler integration, and 6-gate verifyTemplateEditorialGeometry audit across all templates
  DEPS: [gate-12-editorial-geometry-engine]
  CHECK: node scripts/probe-editorial-geometry-v2.mjs --gate all && node src/v2/qa/verify-suite.js
  EXPECT: GATE_13_INTEGRATION_ALL_PASS
  EVIDENCE: exit=0 | GATE_11_CONFIG_CSS_PASS | sha256:fe41e6fd46a3

## 3. Micro-ADR Ledger
- **[ADR-001] Thesis A (Token-First Structural Determinism)**: Context: Multiple visual rules and dark-mode overrides in static/design-system.css and static/shell.css contained raw hex/rgba literals and off-4px-grid dimensions. Decision: Rebind all semantic light/dark tokens to --primitive-* variables and normalize all component spacing/radii to the 4px grid before state/responsive tuning. Consequences: Zero untokenized literals across static/ and deterministic single-point theme switching.
- **[ADR-002] Global 4px Structural Spacing Base (1A)**: Context: Studio controls require 32px field rows, 36px accordion headers, 12px editor padding, and 132px editor floors. Decision: Lock spacing_base: 4 globally in design-guardrails.config.json and snap all off-grid 6px/7px/10px/14px/18px/22px/30px/34px/38px/46px values to 4px multiples (4px, 8px, 12px, 16px, 24px, 32px, 36px, 40px, 44px, 48px). Consequences: 100% modulo-4 alignment across static/design-system.css and static/shell.css.
- **[ADR-003] Semantic-Only Dual Mode (2A)**: Context: html[data-theme="dark"] previously declared 22 raw hexes and 5 raw rgba() literals directly. Decision: Move all dark palette values into :root --primitive-* variables and restrict html[data-theme="dark"] to semantic token aliases only. Consequences: Satisfies TS-01 and TS-09 with zero component overrides per mode.
- **[ADR-004] Wave 12 Compiler & Cloudflare Worker Efficiency Architecture**: Context: V8 CPU profiling on the 6 corpus documents identified 5 dominant CPU bottlenecks risking Cloudflare Workers Free Plan Error 1102 (10ms CPU / 128MB isolate limits): (1) O(N^2) char-by-char slicing in parseInlineRuns, (2) 119 un-gated regex passes in TypographicAutofix.apply, (3) double word width measurement and un-cached per-style space widths in wrapRunsToLines plus 2000-entry WORD_MEASURE_CACHE thrashing and un-cached fkFont.layout, (4) 10 synchronous process.memoryUsage() heap walks per pipeline run and Set-heavy deepFreeze, and (5) full re-compilation on every 350ms /api/paginate keystroke and subsequent /api/convert request. Decision: Implement trigger-indexed inline parsing, compiled alternation TeX autofix, single-pass token width caching, per-font layout memoization, and a bounded isolate-level block-item + DisplayList LRU cache with zero layout drift. Consequences: Sub-2ms warm pagination on Cloudflare Workers, >2.5x cold/uncached compile speedup, and 0 diffs across all 157 V2 baseline rows and 18 V3 gates.
- **[ADR-005] Wave 13 Master Orchestration Specification v2.0 (Template-Aware Editorial Geometry & Fragmentation)**: Context: Editorial documents require deterministic 96-DPI multi-unit/paper-preset resolution across 4 precedence tiers, literal @page stylesheet injection for Chromium Blink print compliance, transitive heading/list-intro glueing, atomic container push-downs, rowspan-safe multi-page table and ordered/unordered list splitting with continuation markers, and framed-safe .is-page-bottom margin/padding suppression without breaking existing V2/V3 PDFKit compilation or Design Guardrails v3.0 token/4px-grid discipline. Decision: Extend design-guardrails.config.json with defaults and 9 template profiles (6 spec profiles + 3 canonical Compilador templates), implement the zero-dependency isomorphic EditorialGeometryEngine in static/editorial-geometry-engine.js re-exported across pdf-engine.js, pdf-generator.js, and static/editor-core.js, and snap .continuation-marker spacing and tokens to the 4px grid and 3-layer token graph. Consequences: All 6 falsifiable DOM geometry gates pass across every template with 0 regressions across all existing verify, lean, and design suites.
