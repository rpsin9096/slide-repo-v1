#!/bin/bash
# Compilador do Raul — local server launcher.
# Double-click this file in Finder (macOS) to start the server at
# http://localhost:3000. Equivalent to: npm ci (first run) + npm run dev.
set -e
cd "$(dirname "$0")"

pause_close() {
  echo
  read -r -p "Press ENTER to close this window..." _
  exit 1
}

echo "Compilador do Raul — local server"
echo "================================="

if ! command -v node >/dev/null 2>&1; then
  echo "ERROR: Node.js is not installed."
  echo "Install Node.js 20 or newer from https://nodejs.org and try again."
  pause_close
fi

NODE_MAJOR="$(node -p 'Number(process.versions.node.split(".")[0])')"
if [ "$NODE_MAJOR" -lt 20 ]; then
  echo "ERROR: Node.js 20 or newer is required (found $(node -v))."
  pause_close
fi

if [ ! -d node_modules ]; then
  echo "First run: installing dependencies (npm ci)..."
  npm ci || npm install
fi

# Open the editor in the default browser as soon as the server answers.
(
  for _ in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 20 25 30; do
    if curl -s -o /dev/null http://localhost:3000/api/health; then
      open "http://localhost:3000"
      break
    fi
    sleep 1
  done
) &

echo "Starting server at http://localhost:3000 (close this window or press Ctrl+C to stop)"
echo
npm run dev

echo
echo "Server stopped."
read -r -p "Press ENTER to close this window..." _
