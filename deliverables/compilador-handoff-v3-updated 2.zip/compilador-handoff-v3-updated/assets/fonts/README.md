# Vendored V2 body fonts (hermetic Typst builds).
# DejaVu Sans 2.37 (tunstall/dejavu-fonts, OFL): matches the legacy
# pdf-generator.js fallback stack (Arial > DejaVu Sans > ...).
# Typst consumes them via --font-path (see TYPST_FONT_DIR / server.js).
# Mono (DejaVu Sans Mono) and math (New Computer Modern Math) ship with Typst.
# Arimo (Google Fonts, Apache 2.0): metric-compatible with Arial/Helvetica,
# i.e. the look the legacy engine had on macOS (Arial first in its stack).
# Preferred V2 body family; DejaVu Sans stays as coverage fallback.
# Inter 4.0 (Google Fonts, OFL): modern grotesque for the minimalist template
# (body Regular/Italic, headings Medium/SemiBold per the typographic audit).
# Noto Emoji Regular (Google Fonts, OFL, monochrome): emoji fallback face.
# Neither Arimo nor Inter ships emoji pictographs, so without this face
# PDFKit embeds `.notdef` and emoji silently vanish from compiled PDFs.
# Only emoji runs select it (see src/v2/fonts/emoji.js); body text never
# touches this face, so non-emoji documents embed zero extra bytes.
# Registered as V2Emoji/AppEmoji in the pdfkit blaster + shaping ttfMap,
# and inlined for Workers via V2_TTF_FACES in scripts/build-cloudflare.js.
