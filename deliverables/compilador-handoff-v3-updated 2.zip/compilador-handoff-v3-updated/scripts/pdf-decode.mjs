/**
 * Pure PDF positioned-text decoder (ToUnicode-aware).
 *
 * Extracted verbatim from scripts/verify-pdf-geometry.mjs so both the
 * geometry suite and the differential parity harness share one decoder.
 * Zero side effects, zero filesystem access. Returns runs: [{x, y, size, font, text}].
 */
import zlib from 'node:zlib';

export function getObjects(buf) {
  const raw = buf.toString('latin1');
  const objects = new Map();
  for (const m of raw.matchAll(/(\d+)\s+(\d+)\s+obj\b([\s\S]*?)endobj/g)) objects.set(m[1] + ' ' + m[2], m[3]);
  return objects;
}

export function getStreams(objects) {
  const streams = new Map();
  for (const [key, body] of objects) {
    const si = body.indexOf('stream'); if (si === -1) continue;
    let st = si + 6; while (body[st] === '\r' || body[st] === '\n') st++;
    let d = Buffer.from(body.slice(st, body.indexOf('endstream', st)), 'latin1');
    if (/\/FlateDecode/.test(body.slice(0, si))) { try { d = zlib.inflateSync(d); } catch { continue; } }
    streams.set(key, d);
  }
  return streams;
}

export function parseCmap(buf) {
  const s = buf.toString('latin1'); const mp = new Map();
  for (const m of s.matchAll(/<([0-9A-Fa-f]+)>\s+<([0-9A-Fa-f]+)>\s*\[([0-9A-Fa-f\s<>]+)\]/g)) {
    const lo = parseInt(m[1], 16);
    [...m[3].matchAll(/<([0-9A-Fa-f]+)>/g)].forEach((x, i) =>
      mp.set((lo + i).toString(16).toUpperCase().padStart(m[1].length, '0'), x[1].toUpperCase()));
  }
  for (const m of s.matchAll(/<([0-9A-Fa-f]+)>\s+<([0-9A-Fa-f]+)>/g)) {
    if (mp.has(m[1].toUpperCase())) continue;
    mp.set(m[1].toUpperCase(), m[2].toUpperCase());
  }
  return mp;
}

// returns runs: [{x, y, size, font, text, page}] (page is 0-based display order)
export function decodeRuns(buf) {
  const objects = getObjects(buf);
  const streams = getStreams(objects);
  const cmaps = new Map(); const fontNames = new Map();
  for (const [k, b] of objects) {
    const tu = b.match(/\/ToUnicode\s+(\d+)\s+(\d+)\s+R/);
    if (tu && /\/Type\s*\/Font/.test(b)) {
      const d = streams.get(tu[1] + ' ' + tu[2]);
      if (d) cmaps.set(k, parseCmap(d));
      const bf = b.match(/\/BaseFont\s*\/([A-Za-z0-9+]+)/);
      if (bf) fontNames.set(k, bf[1]);
    }
  }
  const resmap = new Map();
  // Page order from the /Pages /Kids array (object insertion order is NOT page order).
  const pageIndexByRef = new Map();
  for (const [, b] of objects) {
    if (!/\/Type\s*\/Pages/.test(b)) continue;
    const kids = b.match(/\/Kids\s*\[([^\]]*)\]/);
    if (!kids) continue;
    const refs = [...kids[1].matchAll(/(\d+)\s+(\d+)\s+R/g)];
    refs.forEach((m, idx) => pageIndexByRef.set(m[1] + ' ' + m[2], idx));
    break;
  }
  let autoPage = 0;
  const contentPage = new Map();
  for (const [k, b] of objects) {
    if (!/\/Type\s*\/Page[^s]/.test(b)) continue;
    const rr = b.match(/\/Resources\s+(\d+)\s+(\d+)\s+R/);
    const rb = rr ? objects.get(rr[1] + ' ' + rr[2]) : b;
    const fm = new Map();
    const fs2 = (rb || '').match(/\/Font\s*<<([^>]*)>>/);
    if (fs2) for (const m of fs2[1].matchAll(/\/(F\d+)\s+(\d+)\s+(\d+)\s+R/g)) fm.set(m[1], m[2] + ' ' + m[3]);
    const cr = b.match(/\/Contents\s+(\d+)\s+(\d+)\s+R/);
    if (cr) {
      resmap.set(cr[1] + ' ' + cr[2], fm);
      if (!contentPage.has(cr[1] + ' ' + cr[2])) {
        contentPage.set(cr[1] + ' ' + cr[2], pageIndexByRef.has(k) ? pageIndexByRef.get(k) : autoPage++);
      }
    }
  }
  const runs = [];
  for (const [ckey, data] of streams) {
    if (!resmap.has(ckey)) continue;
    const fonts = resmap.get(ckey);
    const s = data.toString('latin1');
    const ops = s.match(/1 0 0 1 [\d.]+ [\d.]+ Tm|\/F\d+ [\d.]+ Tf|<[0-9A-Fa-f]+>\s*Tj|\[[^\]]*\] TJ|\bET\b/sg) || [];
    let x = null, y = null, font = null, size = null;
    for (const op of ops) {
      let m;
      if ((m = op.match(/1 0 0 1 ([\d.]+) ([\d.]+) Tm/))) { x = +m[1]; y = +m[2]; }
      else if (op === 'ET') { x = null; y = null; }
      else if ((m = op.match(/\/(F\d+) ([\d.]+) Tf/))) { font = m[1]; size = +m[2]; }
      else {
        if (x === null || y === null) continue;
        const cm = cmaps.get(fonts.get(font));
        // Walk TJ arrays token by token: v1's manual justifier packs whole
        // lines as [<hex> <gap> <hex> ...] TJ with word gaps as large
        // positive advances. Reinserting spaces there (threshold ≈ 120
        // thousandths-em; kern pairs are small/negative) keeps word
        // tokenization faithful; single-hex Tj ops are unaffected.
        let text = '';
        const decodeHex = (hex) => {
          let out = '';
          for (let i = 0; i + 4 <= hex.length; i += 4) {
            const uni = cm?.get(hex.slice(i, i + 4).toUpperCase());
            out += uni ? String.fromCodePoint(parseInt(uni, 16)) : '�';
          }
          return out;
        };
        if (op.trimStart().startsWith('[')) {
          // Word gaps appear as LARGE advances in either sign convention:
          // v1's manual justifier separates words with big negative offsets
          // (≈ -500 thousandths-em, proven), other producers use large
          // positives. Kerning pairs stay small (|v| < ~100) either way.
          let pendingGap = false;
          for (const t of op.matchAll(/<([0-9A-Fa-f]+)>|(-?\d+\.?\d*)/g)) {
            if (t[1] !== undefined) {
              if (pendingGap) text += ' ';
              text += decodeHex(t[1]);
              pendingGap = false;
            } else {
              const adv = parseFloat(t[2]);
              if (adv >= 120 || adv <= -150) pendingGap = true;
            }
          }
        } else {
          for (const h of op.matchAll(/<([0-9A-Fa-f]+)>/g)) {
            text += decodeHex(h[1]);
          }
        }
        if (text) runs.push({ x, y, size, font: fontNames.get(fonts.get(font)) || font, text, page: contentPage.get(ckey) ?? 0 });
      }
    }
  }
  return runs;
}
