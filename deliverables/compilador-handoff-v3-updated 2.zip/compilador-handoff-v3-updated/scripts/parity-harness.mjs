/**
 * Phase-0 differential parity harness (skeleton).
 *
 * Renders a fixture × template matrix through LEGACY generatePdf and the NEW
 * V2 pdfkit driver, then compares: exact page counts, normalized text
 * similarity, same-baseline overprints, and basic 2-column presence.
 *
 * Gate contract: RED on today's gaps, GREEN on legacy self-compare.
 * Exit code is non-zero when any case FAILs.
 *
 * Usage: node scripts/parity-harness.mjs [--fixture sample1] [--template base]
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { decodeRuns } from './pdf-decode.mjs';
import { generatePdf } from '../pdf-generator.js';
import { convertDocument } from '../pdf-engine.js';
import { readCorpus } from '../tests/corpus/index.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const REPO = path.resolve(__dirname, '..');

const FIXTURES = ['sample1.md', 'sample2.md', 'sample3.md', 'text-test.md'];
const TEMPLATES = ['base', 'bauhaus', 'bauhaus_minimalist'];
const FIXED_DATE = '01/01/2026'; // deterministic header date on both paths

const args = process.argv.slice(2);
const flagValue = (name) => {
  const i = args.indexOf(name);
  return i !== -1 ? (args[i + 1] || null) : null;
};
const onlyFixture = flagValue('--fixture');
const onlyTemplate = flagValue('--template');

const normText = (s) => (s || '')
  .replace(/­/g, '')
  .replace(/\s+/g, ' ')
  .replace(/[“”]/g, '"')
  .replace(/[‘’]/g, "'")
  .trim();

// Punctuation-stripped words: kills decoder tokenization noise (colon
// attachment, run splits) so Jaccard measures content, not segmentation.
const normWord = (w) => w.toLowerCase().replace(/^[^a-z0-9à-ÿā-ž]+|[^a-z0-9à-ÿā-ž]+$/gi, '');

function pageTexts(buf) {
  // decodeRuns has no page index; callers compare whole-document normalized
  // word multisets + head/tail anchors (order-tolerant by design; the
  // geometry suite owns positional assertions). Fragments are merged into
  // visual lines first (see mergeRuns).
  return mergeRuns(decodeRuns(buf));
}

function wordSet(text) {
  const m = new Map();
  for (const raw of text.split(' ').filter(Boolean)) {
    const w = normWord(raw);
    if (!w) continue;
    m.set(w, (m.get(w) || 0) + 1);
  }
  return m;
}

function jaccard(a, b) {
  const keys = new Set([...a.keys(), ...b.keys()]);
  let inter = 0, union = 0;
  for (const k of keys) {
    inter += Math.min(a.get(k) || 0, b.get(k) || 0);
    union += Math.max(a.get(k) || 0, b.get(k) || 0);
  }
  return union === 0 ? 1 : inter / union;
}

function countPages(buf) {
  const raw = buf.toString('latin1');
  const matches = raw.match(/\/Type\s*\/Page[^s]/g);
  return matches ? matches.length : 0;
}

// Merge decoder fragments sharing one text position on one page into visual
// lines. (PDFKit emits continued-run chains as several Tj ops under a single
// Tm; without merging, every multi-run line looks like a same-position
// duplicate. Page is part of the key: y repeats across pages.)
function mergeRuns(runs) {
  const lines = new Map();
  for (const r of runs) {
    const key = (r.page ?? 0) + ',' + (Math.round(r.x * 2) / 2) + ',' + (Math.round(r.y * 2) / 2);
    if (!lines.has(key)) {
      lines.set(key, { x: r.x, y: r.y, page: r.page ?? 0, size: r.size, font: r.font, text: r.text || '' });
    } else {
      lines.get(key).text += r.text || '';
    }
  }
  return [...lines.values()];
}

// True-overprint signature on MERGED lines: two visual lines at the SAME
// position (proven bug shape: PDFKit re-wraps past box width, landing the
// fragment exactly on the next line's origin). Thresholds are sub-point on
// purpose: continued fragments without their own Tm inherit stale decoder
// positions up to ~1pt off (proven false-positive class: lone '→' at 0.89pt
// over its neighbor), while true re-wraps coincide to float noise.
// Consecutive justified words share baselines by design and never match
// both axes. Returns duplicates for diagnosis.
function findOverprints(runs) {
  // Operates on MERGED visual lines (callers merge first): two distinct
  // lines are duplicates only if same page AND same position.
  const dupes = [];
  for (let i = 0; i < runs.length; i++) {
    for (let j = i + 1; j < runs.length; j++) {
      const a = runs[i], b = runs[j];
      if ((a.page ?? 0) !== (b.page ?? 0)) continue;
      if (Math.abs(a.y - b.y) >= 0.5 || Math.abs(a.x - b.x) >= 1.0) continue;
      if (Math.abs((a.x + (a.text || '').length) - (b.x + (b.text || '').length)) < 2) continue; // same run twice decoded
      dupes.push([a, b]);
    }
  }
  return dupes;
}

function hasTwoColumns(runs) {
  if (runs.length === 0) return false;
  const xs = runs.map((r) => r.x);
  const mid = (Math.min(...xs) + Math.max(...xs)) / 2;
  const left = runs.filter((r) => r.x < mid).length;
  const right = runs.filter((r) => r.x >= mid).length;
  return left > 10 && right > 10;
}

const failures = [];
let cases = 0;

for (const fixture of FIXTURES) {
  if (onlyFixture && fixture !== onlyFixture && fixture !== onlyFixture + '.md') continue;
  const md = readCorpus(fixture);
  for (const template of TEMPLATES) {
    if (onlyTemplate && template !== onlyTemplate) continue;
    cases++;
    const label = `${fixture} × ${template}`;
    const payload = {
      sections: [{ name: 'Case', markdown: md }],
      template,
      header_text: 'Parity Probe',
      header_date: { enabled: true, format: 'dd_mm_yyyy', custom_value: FIXED_DATE },
      alignment: 'justify',
    };
    let legacy, modern;
    try {
      legacy = await generatePdf({ ...payload, engine: 'v1' });
    } catch (e) {
      console.log(`FAIL ${label} legacy render threw: ${e.message}`);
      failures.push(label + ' legacy-throw');
      continue;
    }
    try {
      modern = await convertDocument(payload, { driver: 'pdfkit', format: 'pdf' });
    } catch (e) {
      console.log(`FAIL ${label} v2 render threw: ${e.message}`);
      failures.push(label + ' v2-throw');
      continue;
    }
    const modernBuf = Buffer.isBuffer(modern) ? modern : Buffer.from(modern);
    const checks = [];
    const lp = countPages(legacy), mp = countPages(modernBuf);
    checks.push(['pages legacy=' + lp + ' v2=' + mp, lp === mp]);

    const lt = normText(pageTexts(legacy).map((r) => r.text).join(' '));
    const mt = normText(pageTexts(modernBuf).map((r) => r.text).join(' '));
    const sim = jaccard(wordSet(lt), wordSet(mt));
    checks.push(['text-jaccard=' + sim.toFixed(3), sim >= 0.97]);
    checks.push(['len-ratio=' + (mt.length / Math.max(1, lt.length)).toFixed(3),
      mt.length / Math.max(1, lt.length) > 0.9 && mt.length / Math.max(1, lt.length) < 1.1]);

    const modernRuns = pageTexts(modernBuf);
    const dupes = findOverprints(mergeRuns(modernRuns));
    checks.push(['v2-overprints=' + dupes.length, dupes.length === 0]);
    if (dupes.length > 0 && dupes.length <= 5) {
      for (const [a, b] of dupes) {
        console.log(`    overprint @(${a.x.toFixed(1)},${a.y.toFixed(1)}): ${JSON.stringify(a.text.slice(0, 25))} x ${JSON.stringify(b.text.slice(0, 25))}`);
      }
    }
    const lCol = hasTwoColumns(pageTexts(legacy));
    const mCol = hasTwoColumns(modernRuns);
    checks.push(['2col legacy=' + lCol + ' v2=' + mCol, !lCol || mCol]);

    // Fixed date appears on both (determinism proof for ClockPort wiring).
    checks.push(['fixed-date both', lt.includes(FIXED_DATE) && mt.includes(FIXED_DATE)]);

    const bad = checks.filter(([, ok]) => !ok);
    if (bad.length === 0) {
      console.log(`PASS ${label} pages=${lp} jaccard=${sim.toFixed(3)}`);
    } else {
      console.log(`FAIL ${label} :: ${bad.map(([m]) => m).join(' | ')}`);
      if (sim < 0.97) {
        // Diagnosability: top legacy words missing from v2 output.
        const lw = wordSet(lt), mw = wordSet(mt);
        const missing = [...lw.keys()].filter((k) => !mw.has(k)).slice(0, 12);
        console.log(`    legacy-only words: ${JSON.stringify(missing)}`);
      }
      failures.push(label);
    }
  }
}

console.log(`\n${cases - failures.length}/${cases} parity cases green`);
if (failures.length > 0) {
  console.log('RED cases:', failures.join(', '));
  process.exitCode = 1;
}
