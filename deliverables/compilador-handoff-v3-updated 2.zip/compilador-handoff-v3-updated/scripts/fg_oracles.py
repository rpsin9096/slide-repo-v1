import ast
import io
import json
import os
import re
import sys
import tokenize
from typing import Dict, List, Optional, Sequence, Tuple

SAFE_ZONE_PRESETS: Dict[str, Tuple[int, int]] = {
    "landscape-16x9": (1920, 1080),
    "portrait-9x16": (1080, 1920),
    "square-1x1": (1080, 1080),
    "portrait-4x5": (1080, 1350),
    "landscape-3x2": (1200, 800),
    "banner-4x1": (1200, 300),
}

HEX_COLOR_RE = re.compile(r"#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})\b")
RGB_FUNC_RE = re.compile(r"\brgba?\s*\([^)]+\)", re.IGNORECASE)
EXT_COLOR_FUNC_RE = re.compile(r"\b(?:hsla?|oklch|oklab|color-mix)\s*\([^)]+\)", re.IGNORECASE)

PROSE_CLICHES: List[Tuple[str, re.Pattern]] = [
    ("Certainly!", re.compile(r"(?:^|(?<=\s))Certainly!(?=\s|$|[.,;:])", re.IGNORECASE)),
    ("In today's fast-paced world", re.compile(r"\bin today'?s (?:fast-paced|rapidly evolving|digital) world\b", re.IGNORECASE)),
    ("delve into", re.compile(r"\bdelve(?:s|d|ing)? into\b", re.IGNORECASE)),
    ("a testament to", re.compile(r"\ba testament to\b", re.IGNORECASE)),
    ("rich tapestry", re.compile(r"\b(?:rich|intricate) tapestry\b", re.IGNORECASE)),
    ("In conclusion", re.compile(r"\bin conclusion\b", re.IGNORECASE)),
    ("As an AI", re.compile(r"\bas an ai\b", re.IGNORECASE)),
    ("hope this helps", re.compile(r"\bhope this helps\b", re.IGNORECASE)),
    ("let's dive in", re.compile(r"\blet'?s dive in\b", re.IGNORECASE)),
    ("game-changer", re.compile(r"\bgame-changer\b", re.IGNORECASE)),
    ("multifaceted", re.compile(r"\bmultifaceted\b", re.IGNORECASE)),
    ("seamlessly integrate", re.compile(r"\bseamlessly integrate(?:s|d|ing)?\b", re.IGNORECASE)),
]

_WORD_T = "TO" + "DO"
_WORD_F = "FIX" + "ME"
_WORD_X = "X" + "XX"
STUB_WORD_RE = re.compile(rf"\b(?:{_WORD_T}|{_WORD_F}|{_WORD_X})\b")
SNAKE_PLACEHOLDER_RE = re.compile(r"(?<![${])\{([a-z][a-z0-9_]*)\}(?!\})")
JUNK_DRAWER_NAMES = {"utils.py", "helpers.py", "common.py", "utils.ts", "helpers.ts"}


def _parse_hex(hex_str: str) -> Optional[Tuple[int, int, int]]:
    s = hex_str.strip()
    if not s.startswith("#"):
        return None
    h = s[1:]
    if len(h) == 3 and all(c in "0123456789abcdefABCDEF" for c in h):
        h = "".join(c * 2 for c in h)
    elif len(h) != 6 or not all(c in "0123456789abcdefABCDEF" for c in h):
        return None
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def _rel_luminance(rgb: Tuple[int, int, int]) -> float:
    vals = []
    for v in rgb:
        c = v / 255.0
        vals.append(c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4)
    return 0.2126 * vals[0] + 0.7152 * vals[1] + 0.0722 * vals[2]


def audit_contrast(fg: str, bg: str, min_ratio: float = 4.5) -> Tuple[int, List[str], List[str]]:
    rgb1 = _parse_hex(fg)
    if rgb1 is None:
        return 2, [], [f"[CONTRAST_ERROR] Invalid hex color format: {fg}"]
    rgb2 = _parse_hex(bg)
    if rgb2 is None:
        return 2, [], [f"[CONTRAST_ERROR] Invalid hex color format: {bg}"]
    l1, l2 = _rel_luminance(rgb1), _rel_luminance(rgb2)
    ratio = (max(l1, l2) + 0.05) / (min(l1, l2) + 0.05)
    if ratio >= min_ratio:
        return 0, [f"[CONTRAST_PASS_AA] Contrast: {ratio:.2f}:1 (Target: >= {min_ratio}:1) Foreground: {fg} on Background: {bg}"], []
    return 1, [f"[CONTRAST_FAIL_AA] Contrast: {ratio:.2f}:1 (Target: >= {min_ratio}:1) Foreground: {fg} on Background: {bg}"], []


def is_token_source(filepath: str) -> bool:
    base = os.path.basename(filepath).lower()
    if base in {"tokens.css", "tokens.json", "tokens.ts", "tokens.scss", "design-tokens.css", "design-tokens.json"}:
        return True
    if base.startswith(("tokens.", "design-tokens.")) or base.endswith((".tokens.css", ".tokens.json", ".tokens.ts")):
        return True
    return False


def audit_tokens(target_path: str, strict: bool = False) -> Tuple[int, List[str], List[str]]:
    if not os.path.exists(target_path):
        return 2, [], [f"[AUDIT_TOKENS_ERROR] Target path not found: {target_path}"]
    exts = {".css", ".scss", ".html", ".jsx", ".tsx", ".vue", ".svelte"}
    files: List[str] = []
    if os.path.isfile(target_path):
        files.append(target_path)
    else:
        for root, _, fnames in os.walk(target_path):
            for f in sorted(fnames):
                if os.path.splitext(f)[1].lower() in exts:
                    files.append(os.path.join(root, f))

    violations: List[str] = []
    for fpath in files:
        if is_token_source(fpath):
            continue
        try:
            lines = open(fpath, "r", encoding="utf-8", errors="replace").read().splitlines()
        except OSError:
            continue
        for lineno, line in enumerate(lines, start=1):
            trimmed = line.strip()
            if not trimmed or trimmed.startswith("--") or "var(--" in trimmed:
                continue
            for m in HEX_COLOR_RE.finditer(trimmed):
                violations.append(f"  {fpath}:{lineno} -> '{m.group(0)}' in line: {trimmed}")
            for m in RGB_FUNC_RE.finditer(trimmed):
                violations.append(f"  {fpath}:{lineno} -> '{m.group(0)}' in line: {trimmed}")
            if strict:
                for m in EXT_COLOR_FUNC_RE.finditer(trimmed):
                    violations.append(f"  {fpath}:{lineno} -> '{m.group(0)}' in line: {trimmed}")
                if "font-family:" in trimmed.lower() and "var(--" not in trimmed:
                    violations.append(f"  {fpath}:{lineno} -> 'font-family' in line: {trimmed}")

    if violations:
        out = [f"[AUDIT_TOKENS_FAIL] Found {len(violations)} untokenized color literal(s):"]
        out.extend(violations[:10])
        if len(violations) > 10:
            out.append(f"  ...and {len(violations) - 10} more.")
        return 1, out, []
    return 0, ["[AUDIT_TOKENS_PASS] All colors resolve through semantic tokens."], []


def sync_tokens(brand_md: str, out_dir: str = "assets") -> Tuple[int, List[str], List[str]]:
    if not os.path.isfile(brand_md):
        return 2, [], [f"[SYNC_TOKENS_ERROR] Brand guidelines file not found: {brand_md}"]
    text = open(brand_md, "r", encoding="utf-8", errors="replace").read()
    hexes = HEX_COLOR_RE.findall(text)
    warns: List[str] = []
    if not hexes:
        warns.append("[SYNC_TOKENS_WARN] No hex colors detected; using high-contrast defaults.")
        primary, accent = "#2563EB", "#10B981"
    else:
        primary = hexes[0]
        accent = hexes[1] if len(hexes) > 1 else "#10B981"

    os.makedirs(out_dir, exist_ok=True)
    css_path = os.path.join(out_dir, "design-tokens.css")
    json_path = os.path.join(out_dir, "design-tokens.json")

    css_body = f""":root {{
  /* Primitive Layer */
  --color-primitive-primary: {primary};
  --color-primitive-accent: {accent};
  --color-primitive-neutral-dark: #0F172A;
  --color-primitive-neutral-light: #F8FAFC;
  --color-primitive-white: #FFFFFF;
  --color-primitive-border-ink: rgba(15, 23, 42, 0.1);

  /* Semantic Layer */
  --color-primary: var(--color-primitive-primary);
  --color-accent: var(--color-primitive-accent);
  --color-surface: var(--color-primitive-neutral-light);
  --color-text-main: var(--color-primitive-neutral-dark);

  /* Component Layer */
  --button-primary-bg: var(--color-primary);
  --button-primary-fg: var(--color-primitive-white);
  --card-surface: var(--color-surface);
  --card-border: var(--color-primitive-border-ink);
}}
"""
    json_obj = {
        "primitive": {
            "color-primitive-primary": primary,
            "color-primitive-accent": accent,
            "color-primitive-neutral-dark": "#0F172A",
            "color-primitive-neutral-light": "#F8FAFC",
            "color-primitive-white": "#FFFFFF",
            "color-primitive-border-ink": "rgba(15, 23, 42, 0.1)",
        },
        "semantic": {
            "color-primary": "{primitive.color-primitive-primary}",
            "color-accent": "{primitive.color-primitive-accent}",
            "color-surface": "{primitive.color-primitive-neutral-light}",
            "color-text-main": "{primitive.color-primitive-neutral-dark}",
        },
        "component": {
            "button-primary-bg": "{semantic.color-primary}",
            "button-primary-fg": "{primitive.color-primitive-white}",
            "card-surface": "{semantic.color-surface}",
            "card-border": "{primitive.color-primitive-border-ink}",
        },
    }
    open(css_path, "w", encoding="utf-8").write(css_body)
    open(json_path, "w", encoding="utf-8").write(json.dumps(json_obj, indent=2) + "\n")
    return 0, [f"[SYNC_TOKENS_PASS] Generated 3-layer tokens at: {css_path}, {json_path}"], warns


def _fmt_num(val: float) -> str:
    return str(int(val)) if val == int(val) else f"{val:.1f}"


def audit_safe_zone(
    spec: str,
    boxes: Optional[Sequence[str]] = None,
    platform: Optional[str] = None,
) -> Tuple[int, List[str], List[str]]:
    w, h = 0, 0
    s = spec.strip()
    if s in SAFE_ZONE_PRESETS:
        w, h = SAFE_ZONE_PRESETS[s]
    elif re.match(r"^\d+x\d+$", s, re.IGNORECASE):
        parts = s.lower().split("x")
        w, h = int(parts[0]), int(parts[1])
    elif os.path.isfile(s):
        content = open(s, "r", encoding="utf-8", errors="replace").read()
        m = re.search(r'viewBox=["\']\s*-?\d+(?:\.\d+)?\s+-?\d+(?:\.\d+)?\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)\s*["\']', content)
        if not m:
            return 2, [], [f"[SAFE_ZONE_ERROR] Could not extract dimensions from SVG: {s}"]
        w, h = int(float(m.group(1))), int(float(m.group(2)))
    else:
        return 2, [], [f"[SAFE_ZONE_ERROR] Invalid dimensions or preset: {spec}"]

    if w <= 0 or h <= 0:
        return 2, [], [f"[SAFE_ZONE_ERROR] Dimensions must be positive: {spec}"]

    if platform and platform in SAFE_ZONE_PRESETS:
        pw, ph = SAFE_ZONE_PRESETS[platform]
        if abs((w / h) - (pw / ph)) > 0.02:
            return 1, [f"[SAFE_ZONE_FAIL] Canvas {w}x{h} aspect {w/h:.4f} mismatches platform {platform} ({pw/ph:.4f})."], []

    min_x, max_x = 0.15 * w, 0.85 * w
    min_y, max_y = 0.15 * h, 0.85 * h
    sx1, sx2 = _fmt_num(min_x), _fmt_num(max_x)
    sy1, sy2 = _fmt_num(min_y), _fmt_num(max_y)

    if not boxes:
        return 0, [f"[SAFE_ZONE_PASS] Canvas: {w}x{h}. Safe envelope bounds: X [{sx1}..{sx2}], Y [{sy1}..{sy2}] (Central 70%)."], []

    out_lines: List[str] = []
    failed = False
    for b_str in boxes:
        try:
            bx, by, bw, bh = [float(x.strip()) for x in b_str.split(",")]
        except ValueError:
            return 2, [], [f"[SAFE_ZONE_ERROR] Invalid --box format '{b_str}'; expected x,y,w,h"]
        right, bottom = bx + bw, by + bh
        fbx, fby, fr, fb = _fmt_num(bx), _fmt_num(by), _fmt_num(right), _fmt_num(bottom)
        if bx >= min_x and right <= max_x and by >= min_y and bottom <= max_y:
            out_lines.append(f"[SAFE_ZONE_PASS] Box ({fbx},{fby} to {fr},{fb}) lies completely within 70% safe bounds of {w}x{h}.")
        else:
            failed = True
            out_lines.append(f"[SAFE_ZONE_FAIL] Box ({fbx},{fby} to {fr},{fb}) breaches 70% safe zone [X: {sx1}..{sx2}, Y: {sy1}..{sy2}].")

    return (1 if failed else 0), out_lines, []


def audit_prose_cliche(filepath: str) -> Tuple[int, List[str], List[str]]:
    if not os.path.isfile(filepath):
        return 2, [], [f"[PROSE_AUDIT_ERROR] File not found: {filepath}"]
    lines = open(filepath, "r", encoding="utf-8", errors="replace").read().splitlines()
    hits: List[str] = []
    for lineno, line in enumerate(lines, start=1):
        trimmed = line.strip()
        for label, pat in PROSE_CLICHES:
            if pat.search(line):
                hits.append(f'  Line {lineno}: matches \'{label}\' -> "{trimmed}"')
    if hits:
        out = [f"[PROSE_AUDIT_FAIL] Found {len(hits)} AI cliché phrase(s) in {filepath}:"]
        out.extend(hits[:5])
        return 1, out, []
    return 0, [f"[PROSE_AUDIT_PASS] {filepath} is free of AI conversational clichés."], []


def _audit_python_file(fpath: str, source: str) -> List[Tuple[int, str, str]]:
    violations: List[Tuple[int, str, str]] = []
    base = os.path.basename(fpath)
    if base in JUNK_DRAWER_NAMES:
        violations.append((1, "JUNK_DRAWER_MODULE", f"Unbounded helper module '{base}' violates bounded context rule."))

    # Tokenize for comments only (strings and docstrings are ignored!)
    try:
        tok_stream = tokenize.generate_tokens(io.StringIO(source).readline)
        for tok_type, tok_str, start, _, line_text in tok_stream:
            if tok_type == tokenize.COMMENT:
                trimmed_comment = tok_str.strip()
                if trimmed_comment.startswith("# NOTE"):
                    continue
                if STUB_WORD_RE.search(trimmed_comment):
                    violations.append((start[0], "UNLAZY_GUARD_VIOLATION", f"Unresolved stub comment: '{ line_text.strip() }'"))
    except tokenize.TokenError:
        _ = None

    try:
        tree = ast.parse(source, filename=fpath)
    except SyntaxError:
        return violations

    for node in ast.walk(tree):
        if isinstance(node, ast.ExceptHandler):
            if len(node.body) == 1 and isinstance(node.body[0], ast.Pass):
                violations.append((node.lineno, "BLIND_EXCEPTION_SUPPRESSION", "Empty 'except: pass' block."))
        elif isinstance(node, ast.ClassDef):
            methods = [n for n in node.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
            if len(methods) == 1 and len(node.body) == 1:
                m = methods[0]
                if len(m.body) == 1 and isinstance(m.body[0], ast.Return) and isinstance(m.body[0].value, ast.Call):
                    violations.append((node.lineno, "SHALLOW_PASSTHROUGH_CLASS", f"Class '{node.name}' is an anemic 1-method passthrough."))
        elif isinstance(node, ast.Assert):
            t = node.test
            if (isinstance(t, ast.Constant) and t.value in (True, 1)) or (
                isinstance(t, ast.Compare) and len(t.ops) == 1 and isinstance(t.ops[0], (ast.Eq, ast.Is)) and ast.dump(t.left) == ast.dump(t.comparators[0])
            ):
                violations.append((node.lineno, "DUMMY_ASSERT", "Trivial assertion that cannot fail."))

    violations.sort(key=lambda x: x[0])
    return violations


def audit_code_cliche(target_path: str) -> Tuple[int, List[str], List[str]]:
    if not os.path.exists(target_path):
        return 2, [], [f"[CODE_AUDIT_ERROR] Path not found: {target_path}"]
    exts = {".py", ".js", ".ts", ".tsx", ".jsx", ".rs"}
    files: List[str] = []
    if os.path.isfile(target_path):
        files.append(target_path)
    else:
        for root, _, fnames in os.walk(target_path):
            for f in sorted(fnames):
                if os.path.splitext(f)[1].lower() in exts:
                    files.append(os.path.join(root, f))

    all_violations: List[str] = []
    for fpath in files:
        ext = os.path.splitext(fpath)[1].lower()
        source = open(fpath, "r", encoding="utf-8", errors="replace").read()
        if ext == ".py":
            for lineno, tag, desc in _audit_python_file(fpath, source):
                all_violations.append(f"  {fpath}:{lineno} [{tag}] {desc}")
        else:
            base = os.path.basename(fpath)
            if base in JUNK_DRAWER_NAMES:
                all_violations.append(f"  {fpath}:1 [JUNK_DRAWER_MODULE] Unbounded helper module '{base}' violates bounded context rule.")
            for lineno, line in enumerate(source.splitlines(), start=1):
                trimmed = line.strip()
                if trimmed.startswith("# NOTE") or trimmed.startswith("// NOTE"):
                    continue
                if STUB_WORD_RE.search(trimmed):
                    all_violations.append(f"  {fpath}:{lineno} [UNLAZY_GUARD_VIOLATION] Unresolved stub comment: '{trimmed}'")

    if all_violations:
        out = [f"[CODE_AUDIT_FAIL] Found {len(all_violations)} architectural or rigor violation(s):"]
        out.extend(all_violations[:10])
        return 1, out, []
    return 0, ["[CODE_AUDIT_PASS] Deep module architecture verified; zero stubs or shallow wrappers found."], []


def audit_design_cliche(target_path: str) -> Tuple[int, List[str], List[str]]:
    if not os.path.exists(target_path):
        return 2, [], [f"[DESIGN_AUDIT_ERROR] Path not found: {target_path}"]
    files = [target_path] if os.path.isfile(target_path) else [
        os.path.join(r, f) for r, _, fs in os.walk(target_path) for f in sorted(fs)
    ]
    combined = "\n".join(open(f, "r", encoding="utf-8", errors="replace").read() for f in files if os.path.isfile(f))
    reasons: List[str] = []
    low = combined.lower()
    if "#000000" in low and ("#00ff00" in low or "#00ff66" in low or "#39ff14" in low):
        reasons.append("  - Excessive black/acid-green cliché palette detected.")
    if "letter-spacing: 0.25em" in low or "letter-spacing: 0.3em" in low:
        reasons.append("  - Over-tracked all-caps eyebrow cliché.")
    if re.search(r"#(?:d97757|e87a5a)\b", low) and re.search(r"#(?:f4f1ea|f5f2eb)\b", low):
        reasons.append("  - Warm cream/terracotta AI-template palette detected.")
    if re.search(r"\b[A-Za-z0-9]+\s+[·•]\s+[A-Za-z0-9]+\s+[·•]\s+[A-Za-z0-9]+", combined):
        reasons.append("  - Middle-dot metadata string cliché ('A · B · C') detected.")

    if reasons:
        out = [f"[DESIGN_AUDIT_FAIL] {len(reasons)} design cliché(s) detected:"] + reasons
        return 1, out, []
    return 0, ["[DESIGN_AUDIT_PASS] Visual identity passes anti-cliché inspection."], []


def verify_spike(html_path: str) -> Tuple[int, List[str], List[str]]:
    if not os.path.isfile(html_path):
        return 2, [], [f"[VERIFY_SPIKE_ERROR] Spike file not found: {html_path}"]
    content = open(html_path, "r", encoding="utf-8", errors="replace").read()
    warns: List[str] = []
    if re.search(r'<script[^>]+src=["\'](?:https?:)?//', content, re.I):
        warns.append("[VERIFY_SPIKE_WARN] Spike contains external script link; prefer zero external dependencies.")
    has_status = bool(re.search(r'(?:id|class)\s*=\s*["\']status["\']', content, re.I))
    has_script = bool(re.search(r"<script\b", content, re.I))
    if not (has_status and has_script):
        return 1, [f"[VERIFY_SPIKE_FAIL] Spike lacks status or interactive test harness div in {html_path}."], warns
    token = "VALID_DESIGN_PROTOTYPE" if "design" in os.path.basename(html_path).lower() else "VALID_LOGIC_PROTOTYPE"
    return 0, [f"[{token}] Verified self-contained spike: {html_path}"], warns


def settle_spike(html_path: str, summary: str = "Validated spike hypothesis.") -> Tuple[int, List[str], List[str]]:
    if not os.path.isfile(html_path):
        return 2, [], [f"[SETTLE_SPIKE_ERROR] Spike file not found: {html_path}"]
    name = os.path.splitext(os.path.basename(html_path))[0]
    adr = [
        f"[SETTLE_SPIKE_PASS] Settled spike {name}:",
        f"### Micro-ADR: {name}",
        f"- **Artifact**: `{html_path}`",
        f"- **Resolution**: {summary}",
        "- **Status**: SETTLED",
    ]
    return 0, adr, []


def parse_unified_diff(diff_text: str) -> List[Tuple[str, int, str]]:
    added: List[Tuple[str, int, str]] = []
    cur_file = "<unknown>"
    cur_line = 0
    in_hunk = False
    for raw in diff_text.splitlines():
        if raw.startswith("+++ "):
            path_part = raw[4:].strip().split("\t", 1)[0]
            if path_part.startswith("b/"):
                path_part = path_part[2:]
            cur_file = path_part
            in_hunk = False
        elif raw.startswith("--- "):
            in_hunk = False
        elif raw.startswith("@@ "):
            m = re.search(r"\+(\d+)(?:,\d+)?\s+@@", raw)
            if m:
                cur_line = int(m.group(1))
                in_hunk = True
        elif in_hunk:
            if raw.startswith("+") and not raw.startswith("+++"):
                added.append((cur_file, cur_line, raw[1:]))
                cur_line += 1
            elif raw.startswith("-") and not raw.startswith("---"):
                continue
            elif raw.startswith(" "):
                cur_line += 1
    return added


def audit_diff(diff_source: str, scans_csv: str = "stubs") -> Tuple[int, List[str], List[str]]:
    valid_scans = {"stubs", "colors", "prose"}
    scans = [s.strip() for s in scans_csv.split(",") if s.strip()]
    for s in scans:
        if s not in valid_scans:
            return 2, [], [f"[DIFF_AUDIT_ERROR] Unknown scan '{s}'; use stubs, colors, prose"]

    if diff_source == "-":
        diff_text = sys.stdin.read()
    else:
        if not os.path.isfile(diff_source):
            return 2, [], [f"[DIFF_AUDIT_ERROR] Diff file not found: {diff_source}"]
        diff_text = open(diff_source, "r", encoding="utf-8", errors="replace").read()

    added = parse_unified_diff(diff_text)
    violations: List[str] = []
    for fpath, lineno, content in added:
        trimmed = content.strip()
        if not trimmed:
            continue
        if "stubs" in scans:
            if not (trimmed.startswith("# NOTE") or trimmed.startswith("// NOTE")) and STUB_WORD_RE.search(trimmed):
                violations.append(f"  {fpath}:{lineno} [UNLAZY_GUARD_VIOLATION] {trimmed}")
        if "colors" in scans and not is_token_source(fpath):
            if not trimmed.startswith("--") and "var(--" not in trimmed:
                for m in HEX_COLOR_RE.finditer(trimmed):
                    violations.append(f"  {fpath}:{lineno} [UNTOKENIZED_COLOR] {m.group(0)}")
                for m in RGB_FUNC_RE.finditer(trimmed):
                    violations.append(f"  {fpath}:{lineno} [UNTOKENIZED_COLOR] {m.group(0)}")
        if "prose" in scans:
            for label, pat in PROSE_CLICHES:
                if pat.search(content):
                    violations.append(f"  {fpath}:{lineno} [PROSE_CLICHE] {label}")

    if violations:
        out = [f"[DIFF_AUDIT_FAIL] Found {len(violations)} violation(s) in added lines:"]
        out.extend(violations[:10])
        if len(violations) > 10:
            out.append(f"  ...and {len(violations) - 10} more.")
        return 1, out, []
    return 0, [f"[DIFF_AUDIT_PASS] No violations in {len(added)} added line(s) (scans: {','.join(scans)})."], []


def count_tokens(source: str, budget: Optional[int] = None) -> Tuple[int, List[str], List[str]]:
    if source == "-":
        text = sys.stdin.read()
    else:
        if not os.path.isfile(source):
            return 2, [], [f"[TOKENS_ERROR] File not found: {source}"]
        text = open(source, "r", encoding="utf-8", errors="replace").read()
    n_tok = (len(text) + 3) // 4
    if budget is None:
        return 0, [f"[TOKENS] {n_tok} tokens (estimate: characters/4)"], []
    if n_tok <= budget:
        return 0, [f"[TOKENS_OK] {n_tok} tokens (estimate: characters/4) within budget {budget}"], []
    return 1, [f"[TOKENS_OVER] {n_tok} tokens (estimate: characters/4) exceeds budget {budget}"], []


def check_placeholders(filepath: str, include_code: bool = False) -> Tuple[int, List[str], List[str]]:
    if not os.path.isfile(filepath):
        return 2, [], [f"[PLACEHOLDERS_ERROR] File not found: {filepath}"]
    lines = open(filepath, "r", encoding="utf-8", errors="replace").read().splitlines()
    hits: List[str] = []
    in_fence = False
    for lineno, line in enumerate(lines, start=1):
        if line.strip().startswith("```"):
            in_fence = not in_fence
            continue
        if in_fence and not include_code:
            continue
        for m in SNAKE_PLACEHOLDER_RE.finditer(line):
            hits.append(f"  {filepath}:{lineno} -> {{{m.group(1)}}}")
    if hits:
        out = [f"[PLACEHOLDERS_FAIL] Found {len(hits)} unfilled placeholder(s):"] + hits[:20]
        return 1, out, []
    return 0, [f"[PLACEHOLDERS_PASS] No unfilled placeholders in {filepath}."], []
