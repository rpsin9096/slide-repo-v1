#!/usr/bin/env node
/**
 * FocusGate Probe & Deterministic Mock DOM Harness for Master Orchestration Specification v2.0
 * Verifies:
 *   --gate config-css : Deliverable A (design-guardrails.config.json) & Deliverable B (design-system.css / shell.css)
 *   --gate engine     : Deliverable C (EditorialGeometryEngine, normalizeEditorialGeometry)
 *   --gate all        : Deliverable D (pdf-generator.js, editor-core.js) + Section 3 (6-Gate Audit across all templates)
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');

/**
 * Lightweight deterministic DOM + CSSOM environment for testing EditorialGeometryEngine,
 * normalizeEditorialGeometry, verifyTemplateEditorialGeometry, generateEditorialPdf, and
 * initializeEditorialPagination in Node without requiring an external browser binary.
 */
export function createMockEditorialDom({ template = null, cssVars = {} } = {}) {
  class MockClassList {
    constructor(owner) {
      this.owner = owner;
      this._set = new Set();
    }
    _syncFromAttr(str) {
      this._set = new Set(String(str || '').split(/\s+/).filter(Boolean));
    }
    add(...names) {
      for (const n of names) if (n) this._set.add(n);
    }
    remove(...names) {
      for (const n of names) this._set.delete(n);
    }
    contains(name) {
      return this._set.has(name);
    }
    toggle(name, force) {
      const on = force !== undefined ? Boolean(force) : !this._set.has(name);
      if (on) this._set.add(name);
      else this._set.delete(name);
      return on;
    }
    toString() {
      return [...this._set].join(' ');
    }
  }

  class MockStyle {
    constructor() {
      this._props = new Map();
    }
    setProperty(k, v) {
      this._props.set(k, String(v));
    }
    getPropertyValue(k) {
      return this._props.get(k) || '';
    }
  }

  function matchesSingle(el, s) {
    if (!el || el.nodeType !== 1) return false;
    if (s === '*') return true;
    const attrM = s.match(/^([a-zA-Z0-9_-]+)?\[([a-zA-Z0-9_-]+)(?:=['"]?([^'"\]]+)['"]?)?\]$/);
    if (attrM) {
      const [, tagPart, attrName, attrVal] = attrM;
      if (tagPart && el.tagName !== tagPart.toUpperCase()) return false;
      if (!el.hasAttribute(attrName)) return false;
      if (attrVal !== undefined) return el.getAttribute(attrName) === attrVal;
      return true;
    }
    if (s.startsWith('.')) return el.classList.contains(s.slice(1));
    if (s.startsWith('#')) return el.id === s.slice(1);
    return el.tagName === s.toUpperCase();
  }

  function matchesSelector(el, sel) {
    if (!el || el.nodeType !== 1) return false;
    const s = sel.trim();
    if (!s) return false;
    if (s === ':scope > tr') return el.tagName === 'TR';
    if (s.includes(':not(')) {
      const parts = s.split(/:not\(([^)]+)\)/).filter(Boolean);
      const base = parts[0];
      if (!matchesSingle(el, base)) return false;
      const notMatches = [...s.matchAll(/:not\(([^)]+)\)/g)].map((m) => m[1]);
      return notMatches.every((nSel) => !matchesSingle(el, nSel));
    }
    if (s.includes('>')) {
      const [pSel, cSel] = s.split('>').map((x) => x.trim());
      if (pSel === ':scope') return matchesSingle(el, cSel);
      return matchesSingle(el, cSel) && el.parentElement && matchesSingle(el.parentElement, pSel);
    }
    return matchesSingle(el, s);
  }

  class MockElement {
    constructor(tagName, ownerDocument) {
      this.nodeType = 1;
      this.tagName = String(tagName || 'DIV').toUpperCase();
      this.ownerDocument = ownerDocument;
      this.children = [];
      this.parentElement = null;
      this.attributes = new Map();
      this.classList = new MockClassList(this);
      this.style = new MockStyle();
      this.textContent = '';
      this._id = '';
      this._box = {
        height: 24,
        marginTop: 0,
        marginBottom: 12,
        paddingTop: 0,
        paddingBottom: 0,
        borderTopWidth: 0,
        borderBottomWidth: 0,
        fontSize: 16,
        lineHeight: 22,
        backgroundColor: 'transparent',
        display: 'block',
        position: 'static',
        breakBefore: 'auto',
        pageBreakBefore: 'auto',
      };
    }
    get id() {
      return this._id || this.attributes.get('id') || '';
    }
    set id(v) {
      this._id = String(v);
      this.attributes.set('id', String(v));
    }
    get className() {
      return this.classList.toString();
    }
    set className(v) {
      this.classList._syncFromAttr(v);
    }
    get dataset() {
      const self = this;
      return new Proxy({}, {
        get(_, prop) {
          const kebab = 'data-' + String(prop).replace(/[A-Z]/g, (m) => `-${m.toLowerCase()}`);
          return self.getAttribute(kebab) ?? undefined;
        },
        set(_, prop, val) {
          const kebab = 'data-' + String(prop).replace(/[A-Z]/g, (m) => `-${m.toLowerCase()}`);
          self.setAttribute(kebab, String(val));
          return true;
        },
      });
    }
    setBoxMetrics(patch = {}) {
      Object.assign(this._box, patch);
      return this;
    }
    getBoundingClientRect() {
      let h = this._box.height;
      if (this.tagName === 'TABLE') {
        const thead = this.querySelector('thead');
        const tfoot = this.querySelector('tfoot');
        const rows = this.querySelectorAll('tr').filter((r) => !r.closest('thead') && !r.closest('tfoot'));
        if (thead || rows.length > 0) {
          h = (thead ? thead.getBoundingClientRect().height : 0)
            + rows.reduce((s, r) => s + r.getBoundingClientRect().height, 0)
            + (tfoot ? tfoot.getBoundingClientRect().height : 0);
        }
      } else if (this.tagName === 'UL' || this.tagName === 'OL') {
        const items = this.children.filter((c) => c.tagName === 'LI');
        if (items.length > 0) {
          let sum = 0;
          for (let i = 0; i < items.length; i++) {
            const b = items[i]._box;
            const prevMb = i > 0 ? items[i - 1]._box.marginBottom : 0;
            sum += b.height + (i > 0 ? Math.max(prevMb, b.marginTop) : 0);
          }
          h = sum;
        }
      }
      return { top: 0, left: 0, width: 600, height: h, bottom: h, right: 600 };
    }
    setAttribute(name, val) {
      const k = String(name);
      const v = String(val);
      this.attributes.set(k, v);
      if (k === 'id') this._id = v;
      if (k === 'class') this.classList._syncFromAttr(v);
    }
    getAttribute(name) {
      if (name === 'class') return this.className || null;
      if (name === 'id') return this._id || this.attributes.get('id') || null;
      return this.attributes.has(name) ? this.attributes.get(name) : null;
    }
    hasAttribute(name) {
      if (name === 'class') return this.classList._set.size > 0;
      if (name === 'id') return Boolean(this._id || this.attributes.has('id'));
      return this.attributes.has(name);
    }
    removeAttribute(name) {
      this.attributes.delete(name);
      if (name === 'id') this._id = '';
    }
    appendChild(child) {
      if (child.parentElement) {
        const idx = child.parentElement.children.indexOf(child);
        if (idx >= 0) child.parentElement.children.splice(idx, 1);
      }
      child.parentElement = this;
      this.children.push(child);
      return child;
    }
    remove() {
      if (!this.parentElement) return;
      const idx = this.parentElement.children.indexOf(this);
      if (idx >= 0) this.parentElement.children.splice(idx, 1);
      this.parentElement = null;
    }
    after(...nodes) {
      if (!this.parentElement) return;
      for (const n of nodes) {
        if (n.parentElement) {
          const oldIdx = n.parentElement.children.indexOf(n);
          if (oldIdx >= 0) n.parentElement.children.splice(oldIdx, 1);
        }
      }
      const idx = this.parentElement.children.indexOf(this);
      if (idx < 0) return;
      nodes.forEach((n) => { n.parentElement = this.parentElement; });
      this.parentElement.children.splice(idx + 1, 0, ...nodes);
    }
    before(...nodes) {
      if (!this.parentElement) return;
      for (const n of nodes) {
        if (n.parentElement) {
          const oldIdx = n.parentElement.children.indexOf(n);
          if (oldIdx >= 0) n.parentElement.children.splice(oldIdx, 1);
        }
      }
      const idx = this.parentElement.children.indexOf(this);
      if (idx < 0) return;
      nodes.forEach((n) => { n.parentElement = this.parentElement; });
      this.parentElement.children.splice(idx, 0, ...nodes);
    }
    cloneNode(deep = false) {
      const copy = new MockElement(this.tagName, this.ownerDocument);
      for (const [k, v] of this.attributes.entries()) copy.setAttribute(k, v);
      copy.className = this.className;
      copy.textContent = this.textContent;
      copy._box = { ...this._box };
      if (deep) {
        for (const ch of this.children) {
          copy.appendChild(ch.cloneNode(true));
        }
      }
      return copy;
    }
    get firstElementChild() {
      return this.children[0] || null;
    }
    get lastElementChild() {
      return this.children[this.children.length - 1] || null;
    }
    get nextElementSibling() {
      if (!this.parentElement) return null;
      const idx = this.parentElement.children.indexOf(this);
      return idx >= 0 && idx + 1 < this.parentElement.children.length
        ? this.parentElement.children[idx + 1]
        : null;
    }
    get previousElementSibling() {
      if (!this.parentElement) return null;
      const idx = this.parentElement.children.indexOf(this);
      return idx > 0 ? this.parentElement.children[idx - 1] : null;
    }
    matches(selectorList) {
      const sels = String(selectorList || '').split(',').map((s) => s.trim()).filter(Boolean);
      return sels.some((sel) => matchesSelector(this, sel));
    }
    closest(selectorList) {
      let cur = this;
      while (cur && cur.nodeType === 1) {
        if (cur.matches(selectorList)) return cur;
        cur = cur.parentElement;
      }
      return null;
    }
    querySelectorAll(selectorList) {
      const sels = String(selectorList || '').split(',').map((s) => s.trim()).filter(Boolean);
      const out = [];
      const walk = (node) => {
        for (const ch of node.children) {
          const matched = sels.some((sel) => {
            if (sel === ':scope > tr') return ch.parentElement === this && ch.tagName === 'TR';
            if (sel === 'tbody > tr') return ch.tagName === 'TR' && ch.parentElement?.tagName === 'TBODY';
            return matchesSelector(ch, sel);
          });
          if (matched) out.push(ch);
          walk(ch);
        }
      };
      walk(this);
      return out;
    }
    querySelector(selectorList) {
      return this.querySelectorAll(selectorList)[0] || null;
    }
  }

  const doc = {
    fonts: { ready: Promise.resolve() },
    createElement(tag) {
      return new MockElement(tag, doc);
    },
    getElementById(id) {
      const walk = (n) => {
        if (n.id === id) return n;
        for (const c of n.children) {
          const hit = walk(c);
          if (hit) return hit;
        }
        return null;
      };
      return walk(doc.documentElement);
    },
    querySelector(sel) {
      return doc.documentElement.querySelector(sel);
    },
    querySelectorAll(sel) {
      return doc.documentElement.querySelectorAll(sel);
    },
  };
  doc.documentElement = new MockElement('html', doc);
  doc.head = new MockElement('head', doc);
  doc.body = new MockElement('body', doc);
  doc.documentElement.appendChild(doc.head);
  doc.documentElement.appendChild(doc.body);

  const documentRoot = new MockElement('main', doc);
  documentRoot.className = 'document-root';
  documentRoot.setAttribute('data-document-root', 'true');
  if (template) documentRoot.setAttribute('data-template', template);
  for (const [k, v] of Object.entries(cssVars)) {
    documentRoot.style.setProperty(k, v);
  }
  doc.body.appendChild(documentRoot);

  const computeStyle = (el) => {
    const b = el?._box || {};
    const isBottom = el?.classList?.contains('is-page-bottom');
    const isFramed = el?.classList?.contains('is-framed-box');
    const isForcedBreak = el?.classList?.contains('js-forced-page-break');
    const isCont = el?.classList?.contains('continuation-marker');
    return {
      display: b.display || 'block',
      position: b.position || 'static',
      breakBefore: isForcedBreak ? 'page' : (b.breakBefore || 'auto'),
      pageBreakBefore: isForcedBreak ? 'always' : (b.pageBreakBefore || 'auto'),
      marginTop: `${isForcedBreak || isCont ? 0 : (b.marginTop ?? 0)}px`,
      marginBottom: `${isBottom ? 0 : (isCont ? 4 : (b.marginBottom ?? 12))}px`,
      paddingTop: `${b.paddingTop ?? 0}px`,
      paddingBottom: `${(isBottom && !isFramed) ? 0 : (b.paddingBottom ?? 0)}px`,
      borderTopWidth: `${b.borderTopWidth ?? 0}px`,
      borderBottomWidth: `${b.borderBottomWidth ?? 0}px`,
      fontSize: `${b.fontSize ?? 16}px`,
      lineHeight: `${b.lineHeight ?? 22}px`,
      backgroundColor: b.backgroundColor || 'transparent',
      getPropertyValue(prop) {
        return el?.style?.getPropertyValue(prop) || doc.documentElement.style.getPropertyValue(prop) || '';
      },
    };
  };

  const prevWindow = globalThis.window;
  const prevDocument = globalThis.document;
  const listeners = new Map();

  const mockWindow = {
    document: doc,
    getComputedStyle: computeStyle,
    addEventListener(evt, fn) {
      if (!listeners.has(evt)) listeners.set(evt, []);
      listeners.get(evt).push(fn);
    },
    dispatchEvent(evtName) {
      for (const fn of listeners.get(evtName) || []) fn();
    },
  };

  const installGlobals = () => {
    globalThis.window = mockWindow;
    globalThis.document = doc;
  };
  const restoreGlobals = () => {
    globalThis.window = prevWindow;
    globalThis.document = prevDocument;
  };

  return { doc, documentRoot, mockWindow, installGlobals, restoreGlobals };
}

async function checkConfigAndCss() {
  const cfgPath = path.join(ROOT, 'design-guardrails.config.json');
  const dsPath = path.join(ROOT, 'static/design-system.css');
  const shPath = path.join(ROOT, 'static/shell.css');

  const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
  const ds = fs.readFileSync(dsPath, 'utf8');
  const sh = fs.readFileSync(shPath, 'utf8');

  if (!cfg.defaults?.geometry || !cfg.defaults?.fragmentation || !cfg.templates) {
    console.error('[FAIL] design-guardrails.config.json missing defaults.geometry, defaults.fragmentation, or templates');
    process.exit(1);
  }
  const requiredTemplates = [
    'default',
    'executive-report',
    'legal-contract',
    'compact-technical',
    'landscape-dossier',
    'us-letter-brief',
    'base',
    'bauhaus',
    'bauhaus_minimalist',
  ];
  for (const t of requiredTemplates) {
    if (!(t in cfg.templates)) {
      console.error(`[FAIL] design-guardrails.config.json missing template: ${t}`);
      process.exit(1);
    }
  }
  for (const needle of [
    '--page-width: 210mm',
    '--first-page-footer-safe-zone: 12mm',
    '@page :first',
    '.virtual-page-preview',
    '.continuation-marker',
    '.allow-emergency-split',
    '.js-forced-page-break',
    '.is-page-bottom:not(.is-framed-box)',
  ]) {
    if (!ds.includes(needle)) {
      console.error(`[FAIL] static/design-system.css missing rule: ${needle}`);
      process.exit(1);
    }
  }
  if (sh.includes('@page') || sh.includes('.is-page-bottom')) {
    console.error('[FAIL] static/shell.css overrides @page or .is-page-bottom');
    process.exit(1);
  }
  console.log('GATE_11_CONFIG_CSS_PASS');
}

async function checkEngine() {
  const pdfEngineMod = await import('../pdf-engine.js');
  const { EditorialGeometryEngine, normalizeEditorialGeometry, verifyTemplateEditorialGeometry } = pdfEngineMod;
  if (typeof EditorialGeometryEngine !== 'function' || typeof normalizeEditorialGeometry !== 'function' || typeof verifyTemplateEditorialGeometry !== 'function') {
    console.error('[FAIL] pdf-engine.js does not export EditorialGeometryEngine, normalizeEditorialGeometry, or verifyTemplateEditorialGeometry');
    process.exit(1);
  }

  const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'design-guardrails.config.json'), 'utf8'));
  const eng = new EditorialGeometryEngine(cfg, { templateId: 'executive-report' });
  if (eng.getUsablePageHeightPx(0) === eng.getUsablePageHeightPx(1)) {
    console.error('[FAIL] executive-report first-page usable height must differ from body usable height');
    process.exit(1);
  }
  console.log('GATE_12_ENGINE_PASS');
}

async function checkIntegrationAndAudit() {
  await checkConfigAndCss();
  await checkEngine();

  const { normalizeEditorialGeometry, verifyTemplateEditorialGeometry } = await import('../pdf-engine.js');
  const { generateEditorialPdf } = await import('../pdf-generator.js');
  const { initializeEditorialPagination } = await import('../static/editor-core.js');

  if (typeof generateEditorialPdf !== 'function' || typeof initializeEditorialPagination !== 'function') {
    console.error('[FAIL] Missing generateEditorialPdf or initializeEditorialPagination');
    process.exit(1);
  }

  const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'design-guardrails.config.json'), 'utf8'));
  const templatesToVerify = [
    'default',
    'executive-report',
    'legal-contract',
    'compact-technical',
    'landscape-dossier',
    'us-letter-brief',
    'base',
    'bauhaus',
    'bauhaus_minimalist',
  ];

  for (const tplId of templatesToVerify) {
    const env = createMockEditorialDom({ template: tplId });
    env.installGlobals();
    try {
      const { doc, documentRoot } = env;
      const p1 = doc.createElement('p');
      p1.textContent = 'Parágrafo inicial.';
      p1.setBoxMetrics({ height: 420, marginBottom: 16 });
      documentRoot.appendChild(p1);

      const h2 = doc.createElement('h2');
      h2.textContent = 'Seção Principal';
      h2.setBoxMetrics({ height: 28, marginTop: 12, marginBottom: 8 });
      documentRoot.appendChild(h2);

      const ul = doc.createElement('ul');
      for (let i = 0; i < 6; i++) {
        const li = doc.createElement('li');
        li.textContent = `Ponto ${i + 1}`;
        li.setBoxMetrics({ height: 110, marginTop: 4, marginBottom: 8 });
        ul.appendChild(li);
      }
      documentRoot.appendChild(ul);

      await normalizeEditorialGeometry(documentRoot, cfg);
      const audit = verifyTemplateEditorialGeometry(documentRoot);
      if (!audit.passed) {
        console.error(`[FAIL] Template ${tplId} failed 6-gate audit:`, audit.errors);
        process.exit(1);
      }
    } finally {
      env.restoreGlobals();
    }
  }

  console.log('GATE_13_INTEGRATION_ALL_PASS');
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const args = process.argv.slice(2);
  const gateIdx = args.indexOf('--gate');
  const gateMode = gateIdx >= 0 ? args[gateIdx + 1] : 'all';
  if (gateMode === 'config-css') {
    await checkConfigAndCss();
  } else if (gateMode === 'engine') {
    await checkEngine();
  } else {
    await checkIntegrationAndAudit();
  }
}
