import contextlib
import datetime
import hashlib
import json
import os
import re
import shlex
import time
import uuid
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import fg_integrity
import fg_oracles
import fg_runner

GATE_HEADER_RE = re.compile(r"^-\s*\[([ ~x!])\]\s*([A-Za-z0-9_-]+):\s*(.+?)\s*$")
ACTIVE_HEADER_RE = re.compile(r"^Active:[ \t]*(.+?)[ \t]*$", re.MULTILINE)
ABANDON_RE = re.compile(r"^ABANDON:\s*([A-Za-z0-9_-]+)\s+(.+)$")

ORACLE_NAMES = {
    "contrast", "tokens", "sync-tokens", "safe-zone", "code-cliche",
    "unlazy-rigor", "prose-cliche", "design-cliche", "spike-verify",
    "spike-settle", "lint", "diff", "count-tokens", "check-placeholders",
}


@dataclass
class Gate:
    id: str
    title: str
    status: str  # ' ', '~', 'x', '!'
    line_no: int
    deps: List[str] = field(default_factory=list)
    check: Optional[str] = None
    expect: Optional[str] = None
    expect_exit: str = "0"
    expect_not: Optional[str] = None
    timeout: int = 60
    cwd: Optional[str] = None
    evidence: Optional[str] = None

    @property
    def is_spike(self) -> bool:
        return self.id.lower().startswith("spike")

    @property
    def is_settled(self) -> bool:
        return self.status == "x"

    @property
    def kind(self) -> str:
        if not self.check:
            return "none"
        c = self.check.strip()
        if c.startswith("oracle:"):
            return "oracle"
        if c.startswith("desk:"):
            return "desk"
        return "exec"

    @property
    def command_text(self) -> str:
        if not self.check:
            return ""
        c = self.check.strip()
        if c.startswith("exec:"):
            return c[5:].strip()
        if c.startswith("oracle:"):
            return c[7:].strip()
        if c.startswith("desk:"):
            return c[5:].strip()
        return c


@dataclass
class Ledger:
    active: Optional[str]
    gates: List[Gate]
    abandoned: Dict[str, str]
    raw_text: str

    def gate_map(self) -> Dict[str, Gate]:
        return {g.id: g for g in self.gates}

    def ready_gates(self) -> List[Gate]:
        gmap = self.gate_map()
        ready: List[Gate] = []
        for g in self.gates:
            if g.is_settled or g.id in self.abandoned:
                continue
            if all( d in gmap and gmap[d].is_settled for d in g.deps ):
                ready.append(g)
        return ready


def gate_fingerprint(gate: Gate) -> str:
    chk = (gate.check or "").strip()
    if chk.startswith("exec:"):
        chk = chk[5:].strip()
    raw = f"{gate.kind}\0{chk}\0{(gate.expect or '').strip()}\0{gate.expect_exit.strip()}\0{(gate.expect_not or '').strip()}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]


def _parse_deps(raw_deps: str) -> List[str]:
    s = raw_deps.strip()
    if s.startswith("[") and s.endswith("]"):
        s = s[1:-1]
    return [tok.strip().strip("\"'") for tok in s.split(",") if tok.strip()]


def parse_ledger(text: str) -> Ledger:
    m_act = ACTIVE_HEADER_RE.search(text)
    active = m_act.group(1).strip() if m_act else None
    gates: List[Gate] = []
    abandoned: Dict[str, str] = {}
    cur_gate: Optional[Gate] = None
    in_fence = False

    for lineno, line in enumerate(text.splitlines(), start=1):
        if line.strip().startswith("```"):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        m_ab = ABANDON_RE.match(line.strip())
        if m_ab:
            abandoned[m_ab.group(1)] = m_ab.group(2).strip()
            continue
        m_gh = GATE_HEADER_RE.match(line)
        if m_gh:
            cur_gate = Gate(
                id=m_gh.group(2),
                title=m_gh.group(3),
                status=m_gh.group(1),
                line_no=lineno,
            )
            gates.append(cur_gate)
            continue
        if line.startswith("#"):
            cur_gate = None
            continue
        if cur_gate is not None and (line.startswith("  ") or line.startswith("\t")):
            stripped = line.strip()
            if ":" in stripped:
                k, v = stripped.split(":", 1)
                ku = k.strip().upper()
                val = v.strip()
                if ku in {"DEPS", "AFTER"}:
                    cur_gate.deps = _parse_deps(val)
                elif ku == "CHECK":
                    cur_gate.check = val
                elif ku == "EXPECT":
                    cur_gate.expect = val
                elif ku == "EXPECT_EXIT":
                    cur_gate.expect_exit = val
                elif ku == "EXPECT_NOT":
                    cur_gate.expect_not = val
                elif ku == "TIMEOUT":
                    try:
                        cur_gate.timeout = max(1, min(int(val), 600))
                    except ValueError:
                        cur_gate.timeout = 60
                elif ku == "CWD":
                    cur_gate.cwd = val
                elif ku == "EVIDENCE":
                    cur_gate.evidence = val

    return Ledger(active=active, gates=gates, abandoned=abandoned, raw_text=text)


def _find_cycle_or_unknown(gates: List[Gate]) -> List[Tuple[str, str]]:
    gmap = {g.id: g for g in gates}
    issues: List[Tuple[str, str]] = []
    for g in gates:
        for dep in g.deps:
            if dep not in gmap:
                issues.append((g.id, dep))

    # Cycle detection via DFS coloring (0=unvisited, 1=visiting, 2=done)
    color: Dict[str, int] = {g.id: 0 for g in gates}
    recorded_cycle = False

    def dfs(u: str) -> None:
        nonlocal recorded_cycle
        color[u] = 1
        for dep in gmap[u].deps:
            if dep not in gmap:
                continue
            if color[dep] == 1 and not recorded_cycle:
                issues.append((u, dep))
                recorded_cycle = True
            elif color[dep] == 0:
                dfs(dep)
        color[u] = 2

    for g in gates:
        if color[g.id] == 0:
            dfs(g.id)
    return issues


def ledger_errors(text: str, strict: bool = False, check_integrity: bool = False, cwd: str = ".") -> List[str]:
    led = parse_ledger(text)
    errors: List[str] = []

    unsettled = [g for g in led.gates if not g.is_settled and g.id not in led.abandoned]
    unsettled_prod = [g for g in unsettled if not g.is_spike]

    # P1: > 3 unsettled production gates
    if len(unsettled_prod) > 3:
        errors.append(f"Queue congestion: {len(unsettled_prod)} active production gates found; enforce single active slot.")

    # P2: unsettled gate missing CHECK or EXPECT
    for g in unsettled:
        if not g.check:
            errors.append(f"Gate '{g.id}' is missing a 'CHECK:' execution command.")
        if g.expect is None:
            errors.append(f"Gate '{g.id}' is missing an 'EXPECT:' outcome pattern.")

    # E1 (strict only): Active slot validation
    if strict:
        gmap = led.gate_map()
        if led.active is None:
            errors.append("Active slot invalid: missing 'Active:' header line.")
        elif unsettled:
            if led.active.lower() == "none":
                errors.append("Active slot invalid: Active is 'none' while unsettled gates exist.")
            elif led.active not in gmap:
                errors.append(f"Active slot invalid: unknown gate '{led.active}'.")
            elif gmap[led.active].is_settled:
                errors.append(f"Active slot invalid: gate '{led.active}' is already settled.")
        else:
            if led.active.lower() != "none":
                errors.append(f"Active slot invalid: Active is '{led.active}' but all gates are settled (expected 'none').")

    # E2: trivial or empty-matching EXPECT on unsettled gate
    for g in unsettled:
        if g.expect is not None and str(g.expect_exit).strip() == "0":
            exp_s = g.expect.strip()
            if exp_s.lower() in {"", "true", "ok", "0", "pass", "works", "done"}:
                errors.append(f"Gate '{g.id}' has a trivial EXPECT '{exp_s}'.")
            else:
                try:
                    cre = re.compile(exp_s, re.MULTILINE)
                    if cre.search("") is not None:
                        errors.append(f"Gate '{g.id}' has a trivial EXPECT '{exp_s}'.")
                except re.error as exc:
                    errors.append(f"Gate '{g.id}' has invalid EXPECT regex '{exp_s}': {exc}")

    # E3: unknown dependency or cycle
    for u, v in _find_cycle_or_unknown(led.gates):
        errors.append(f"Gate '{u}' depends on unknown or cyclic gate '{v}'.")

    # E4 (strict only): settled gate without EVIDENCE
    if strict:
        for g in led.gates:
            if g.is_settled and not g.evidence:
                errors.append(f"Gate '{g.id}' is settled without an EVIDENCE: line.")

    # E6: unfilled {snake_case} placeholders outside fenced code
    in_fence = False
    for lineno, line in enumerate(text.splitlines(), start=1):
        if line.strip().startswith("```"):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        for m in fg_oracles.SNAKE_PLACEHOLDER_RE.finditer(line):
            errors.append(f"Unfilled placeholder '{{{m.group(1)}}}' at line {lineno}.")

    # E7: invalid EXPECT_EXIT
    for g in led.gates:
        ee = str(g.expect_exit).strip()
        if not fg_runner.VALID_EXPECT_EXIT_RE.match(ee):
            errors.append(f"Gate '{g.id}' has invalid EXPECT_EXIT '{ee}'.")

    # E8+: Command & Target Integrity (when check_integrity=True)
    if check_integrity:
        for g in unsettled:
            if g.check:
                findings = fg_integrity.analyze_gate_integrity(g.check, g.expect, g.expect_exit, cwd=cwd)
                for f in findings:
                    if f["severity"] == "error" and f["code"] not in {"VACUOUS_EXPECT", "UNFILLED_TEMPLATE", "INVALID_EXPECT"}:
                        errors.append(f"Gate '{g.id}' [{f['code']}]: {f['message']}")

    return errors


def lint_ledger_file(ledger_path: str, strict: bool = False, check_integrity: bool = False) -> Tuple[int, List[str], List[str]]:
    if not os.path.isfile(ledger_path):
        return 0, [], [f"[LINT_WARN] Ledger '{ledger_path}' does not exist yet. Run passes with clean slate."]
    text = open(ledger_path, "r", encoding="utf-8", errors="replace").read()
    cwd = os.path.dirname(os.path.abspath(ledger_path)) or "."
    errs = ledger_errors(text, strict=strict, check_integrity=check_integrity, cwd=cwd)
    if errs:
        out = [f"[LINT_FAIL] Ledger validation failed with {len(errs)} error(s):"]
        for e in errs[:12]:
            out.append(f"  - {e}")
        if len(errs) > 12:
            out.append(f"  ...and {len(errs) - 12} more.")
        return 1, out, []
    led = parse_ledger(text)
    settled_cnt = sum(1 for g in led.gates if g.is_settled)
    active_cnt = sum(1 for g in led.gates if not g.is_settled and g.id not in led.abandoned)
    return 0, [f"[LINT_PASS] Ledger '{ledger_path}' is structurally valid ({settled_cnt} settled, {active_cnt} active)."], []


@contextlib.contextmanager
def ledger_lock(ledger_path: str, timeout_s: float = 10.0, stale_after_s: float = 30.0):
    lock_path = f"{ledger_path}.lock"
    deadline = time.monotonic() + timeout_s
    acquired = False
    while time.monotonic() < deadline:
        try:
            fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
            os.write(fd, f"{os.getpid()}\n{time.time()}\n".encode("utf-8"))
            os.close(fd)
            acquired = True
            break
        except FileExistsError:
            try:
                st = os.stat(lock_path)
                age = time.time() - st.st_mtime
                stale = age > stale_after_s
                if not stale:
                    raw = open(lock_path, "r", encoding="utf-8").read().splitlines()
                    if raw and raw[0].isdigit():
                        pid = int(raw[0])
                        try:
                            os.kill(pid, 0)
                        except ProcessLookupError:
                            stale = True
                        except PermissionError:
                            _ = None
                if stale:
                    try:
                        os.unlink(lock_path)
                        continue
                    except OSError:
                        _ = None
            except OSError:
                _ = None
            time.sleep(0.02)
    if not acquired:
        raise TimeoutError(f"Timed out acquiring ledger lock: {lock_path}")
    try:
        yield
    finally:
        try:
            os.unlink(lock_path)
        except OSError:
            _ = None


def atomic_write(filepath: str, content: str) -> None:
    parent = os.path.dirname(os.path.abspath(filepath))
    os.makedirs(parent, exist_ok=True)
    tmp_path = f"{filepath}.tmp.{os.getpid()}.{uuid.uuid4().hex[:6]}"
    with open(tmp_path, "w", encoding="utf-8") as fh:
        fh.write(content)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp_path, filepath)


def apply_status(text: str, gate_id: str, new_status: str, evidence_line: Optional[str] = None) -> str:
    has_trailing_nl = text.endswith("\n")
    lines = text.splitlines()
    out_lines: List[str] = []
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        m = GATE_HEADER_RE.match(line)
        if m and m.group(2) == gate_id:
            # Rewrite status box
            prefix_end = line.find("[")
            rewritten = line[:prefix_end] + f"[{new_status}]" + line[prefix_end + 3 :]
            out_lines.append(rewritten)
            i += 1
            # Copy gate block lines, removing existing EVIDENCE: line
            last_field_idx = len(out_lines) - 1
            while i < n:
                nxt = lines[i]
                if GATE_HEADER_RE.match(nxt) or nxt.startswith("#"):
                    break
                if nxt.strip().upper().startswith("EVIDENCE:"):
                    i += 1
                    continue
                out_lines.append(nxt)
                if nxt.startswith("  ") or nxt.startswith("\t"):
                    last_field_idx = len(out_lines) - 1
                i += 1
            if evidence_line is not None and new_status == "x":
                out_lines.insert(last_field_idx + 1, f"  EVIDENCE: {evidence_line}")
            continue
        out_lines.append(line)
        i += 1

    updated = "\n".join(out_lines) + ("\n" if has_trailing_nl else "")
    # Recompute Active: line using [ \t]* so blank lines are never swallowed
    led_after = parse_ledger(updated)
    ready = led_after.ready_gates()
    next_active = ready[0].id if ready else "none"
    updated = re.sub(r"^Active:[ \t]*[^\r\n]*", f"Active: {next_active}", updated, count=1, flags=re.MULTILINE)
    return updated


# --- Hash-Chained Evidence Log & Receipts ---

def _evidence_log_path(ledger_path: str) -> str:
    base_dir = os.path.dirname(os.path.abspath(ledger_path))
    return os.path.join(base_dir, "GATES.evidence.jsonl")


def _anchor_path(ledger_path: str) -> str:
    return _evidence_log_path(ledger_path) + ".anchor"


def read_evidence_records(ledger_path: str) -> List[Dict[str, object]]:
    epath = _evidence_log_path(ledger_path)
    if not os.path.isfile(epath):
        return []
    records: List[Dict[str, object]] = []
    for line in open(epath, "r", encoding="utf-8").read().splitlines():
        if line.strip():
            records.append(json.loads(line))
    return records


def append_evidence_record(
    ledger_path: str,
    gate_id: str,
    fp: str,
    phase: str,
    result: str,
    exit_code: Optional[int],
    ev_hash: str,
    waived_red: Optional[str] = None,
    forced: bool = False,
) -> Dict[str, object]:
    epath = _evidence_log_path(ledger_path)
    os.makedirs(os.path.dirname(epath), exist_ok=True)
    records = read_evidence_records(ledger_path)

    # Deduplicate consecutive identical run records
    if phase == "run" and records:
        for r in reversed(records):
            if r.get("gate") == gate_id and r.get("fp") == fp:
                if r.get("result") == result and r.get("phase") == "run":
                    return r
                break

    prev_hash = str(records[-1]["entry_hash"]) if records else ("0" * 64)
    ts = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    rec: Dict[str, object] = {
        "ts": ts,
        "gate": gate_id,
        "fp": fp,
        "phase": phase,
        "result": result,
        "exit_code": exit_code,
        "evidence_hash": ev_hash,
        "prev_hash": prev_hash,
    }
    if waived_red:
        rec["waived_red"] = waived_red
    if forced:
        rec["forced"] = True

    canonical = json.dumps(rec, sort_keys=True, separators=(",", ":")).encode("utf-8")
    rec["entry_hash"] = hashlib.sha256(canonical).hexdigest()

    with open(epath, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(rec, separators=(",", ":")) + "\n")
    return rec


def verify_evidence_chain(ledger_path: str) -> Tuple[int, List[str], List[str]]:
    epath = _evidence_log_path(ledger_path)
    if not os.path.isfile(epath):
        return 0, [f"[EVIDENCE_PASS] Verified 0 hash-chained record(s) in {epath} (head: none)."], []
    try:
        records = read_evidence_records(ledger_path)
    except Exception as exc:
        return 1, [f"[EVIDENCE_FAIL] Malformed JSONL in {epath}: {exc}"], []

    expected_prev = "0" * 64
    for idx, rec in enumerate(records, start=1):
        if rec.get("prev_hash") != expected_prev:
            return 1, [f"[EVIDENCE_FAIL] Tamper or inconsistency at record {idx}: prev_hash mismatch"], []
        check_copy = {k: v for k, v in rec.items() if k != "entry_hash"}
        canonical = json.dumps(check_copy, sort_keys=True, separators=(",", ":")).encode("utf-8")
        calc_hash = hashlib.sha256(canonical).hexdigest()
        if rec.get("entry_hash") != calc_hash:
            return 1, [f"[EVIDENCE_FAIL] Tamper or inconsistency at record {idx}: entry_hash mismatch"], []
        expected_prev = calc_hash

    apath = _anchor_path(ledger_path)
    if os.path.isfile(apath):
        pinned = open(apath, "r", encoding="utf-8").read().strip()
        if pinned and not any(r.get("entry_hash") == pinned for r in records):
            return 1, [f"[EVIDENCE_FAIL] Tamper or inconsistency at anchor: pinned hash {pinned[:12]} missing (log truncated)"], []

    head_short = expected_prev[:12] if records else "none"
    return 0, [f"[EVIDENCE_PASS] Verified {len(records)} hash-chained record(s) in {epath} (head: {head_short})."], []


def anchor_evidence(ledger_path: str) -> Tuple[int, List[str], List[str]]:
    records = read_evidence_records(ledger_path)
    if not records:
        return 2, [], ["[ANCHOR_ERROR] Cannot anchor empty evidence log."]
    head = str(records[-1]["entry_hash"])
    apath = _anchor_path(ledger_path)
    atomic_write(apath, head + "\n")
    return 0, [f"[ANCHOR_PASS] Pinned head {head[:12]} ({len(records)} records) to {apath}."], []


def write_receipt_and_trajectory(
    ledger_path: str,
    gate_id: str,
    facet: str,
    verdict: str,
    command: str,
    res: fg_runner.RunResult,
    ev_hash: str,
    reasons: List[str],
) -> str:
    base_dir = os.path.dirname(os.path.abspath(ledger_path))
    rec_dir = os.path.join(base_dir, "receipts")
    os.makedirs(rec_dir, exist_ok=True)
    now_utc = datetime.datetime.now(datetime.timezone.utc)
    ts_compact = now_utc.strftime("%Y%m%dT%H%M%S%fZ")
    ts_iso = now_utc.strftime("%Y-%m-%dT%H:%M:%SZ")

    first_line = ""
    norm_out = fg_runner.normalize_output(res.stdout)
    for ln in norm_out.splitlines():
        if ln.strip():
            first_line = ln.strip()[:100]
            break
    findings = reasons[:3] if reasons else ([first_line] if first_line else [f"Exit {res.exit_code}"])

    receipt_obj = {
        "session_id": f"eph-{uuid.uuid4().hex[:8]}",
        "gate_id": gate_id,
        "facet": facet,
        "status": "PASS" if verdict == "PASS" else "FAIL",
        "key_findings": findings[:3],
        "evidence_hash": ev_hash,
        "elapsed_ms": res.duration_ms,
        "command": command,
        "exit_code": res.exit_code,
        "timed_out": res.timed_out,
        "truncated": res.truncated,
    }
    rec_path = os.path.join(rec_dir, f"{gate_id}-{ts_compact}.json")
    atomic_write(rec_path, json.dumps(receipt_obj, indent=2) + "\n")

    traj_path = os.path.join(base_dir, "trajectory.jsonl")
    step_obj = {
        "schema": "focusgate.trajectory-step/1",
        "ts": ts_iso,
        "gate_id": gate_id,
        "command": command,
        "verdict": verdict,
        "exit_code": res.exit_code,
        "duration_ms": res.duration_ms,
    }
    with open(traj_path, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(step_obj, separators=(",", ":")) + "\n")
    return rec_path


# --- Gate Execution Helpers ---

def _run_oracle_gate(gate: Gate, ledger_path: str) -> Tuple[fg_runner.RunResult, str]:
    t0 = time.monotonic()
    cmd_body = gate.command_text
    try:
        tokens = shlex.split(cmd_body)
    except ValueError as exc:
        res = fg_runner.RunResult(gate.check or "", 2, None, False, False, 0, "", str(exc))
        return res, f"BAD_ORACLE: {exc}"
    if not tokens or tokens[0] not in ORACLE_NAMES:
        name = tokens[0] if tokens else "<empty>"
        res = fg_runner.RunResult(gate.check or "", 2, None, False, False, 0, "", f"Unknown oracle '{name}'")
        return res, f"BAD_ORACLE: {gate.check}"

    oname = tokens[0]
    rest = tokens[1:]
    rc = 0
    out_lines: List[str] = []
    err_lines: List[str] = []

    if oname == "contrast" and len(rest) >= 2:
        min_r = 4.5
        if "--min" in rest:
            idx = rest.index("--min")
            if idx + 1 < len(rest):
                min_r = float(rest[idx + 1])
        rc, out_lines, err_lines = fg_oracles.audit_contrast(rest[0], rest[1], min_ratio=min_r)
    elif oname == "tokens" and rest:
        rc, out_lines, err_lines = fg_oracles.audit_tokens(rest[0], strict=("--strict" in rest))
    elif oname == "sync-tokens" and rest:
        out_d = "assets"
        if "--out" in rest:
            idx = rest.index("--out")
            if idx + 1 < len(rest):
                out_d = rest[idx + 1]
        rc, out_lines, err_lines = fg_oracles.sync_tokens(rest[0], out_dir=out_d)
    elif oname == "safe-zone" and rest:
        boxes: List[str] = []
        plat = None
        i = 1
        while i < len(rest):
            if rest[i] == "--box" and i + 1 < len(rest):
                boxes.append(rest[i + 1])
                i += 2
            elif rest[i] == "--platform" and i + 1 < len(rest):
                plat = rest[i + 1]
                i += 2
            else:
                i += 1
        rc, out_lines, err_lines = fg_oracles.audit_safe_zone(rest[0], boxes=boxes or None, platform=plat)
    elif oname in {"code-cliche", "unlazy-rigor"} and rest:
        rc, out_lines, err_lines = fg_oracles.audit_code_cliche(rest[0])
    elif oname == "prose-cliche" and rest:
        rc, out_lines, err_lines = fg_oracles.audit_prose_cliche(rest[0])
    elif oname == "design-cliche" and rest:
        rc, out_lines, err_lines = fg_oracles.audit_design_cliche(rest[0])
    elif oname == "spike-verify" and rest:
        rc, out_lines, err_lines = fg_oracles.verify_spike(rest[0])
    elif oname == "spike-settle" and rest:
        summ = "Validated spike."
        if "--summary" in rest:
            idx = rest.index("--summary")
            if idx + 1 < len(rest):
                summ = rest[idx + 1]
        rc, out_lines, err_lines = fg_oracles.settle_spike(rest[0], summary=summ)
    elif oname == "diff" and rest:
        sc = "stubs"
        if "--scan" in rest:
            idx = rest.index("--scan")
            if idx + 1 < len(rest):
                sc = rest[idx + 1]
        rc, out_lines, err_lines = fg_oracles.audit_diff(rest[0], scans_csv=sc)
    elif oname == "count-tokens" and rest:
        bud = None
        if "--budget" in rest:
            idx = rest.index("--budget")
            if idx + 1 < len(rest):
                bud = int(rest[idx + 1])
        rc, out_lines, err_lines = fg_oracles.count_tokens(rest[0], budget=bud)
    elif oname == "check-placeholders" and rest:
        rc, out_lines, err_lines = fg_oracles.check_placeholders(rest[0], include_code=("--include-code" in rest))
    elif oname == "lint":
        target_l = rest[0] if rest and not rest[0].startswith("-") else ledger_path
        rc, out_lines, err_lines = lint_ledger_file(target_l, strict=("--strict" in rest))
    else:
        res = fg_runner.RunResult(gate.check or "", 2, None, False, False, 0, "", f"Missing arguments for oracle:{oname}")
        return res, f"BAD_ORACLE: {gate.check}"

    elapsed = int((time.monotonic() - t0) * 1000)
    res = fg_runner.RunResult(
        command=gate.check or "",
        exit_code=rc,
        signal=None,
        timed_out=False,
        truncated=False,
        duration_ms=elapsed,
        stdout="\n".join(out_lines),
        stderr="\n".join(err_lines),
        timeout_s=gate.timeout,
    )
    return res, ""


def next_gate(ledger_path: str) -> Tuple[int, List[str], List[str], Optional[Gate]]:
    if not os.path.isfile(ledger_path):
        return 2, [], [f"[NEXT_GATE_ERROR] Ledger not found: {ledger_path}"], None
    text = open(ledger_path, "r", encoding="utf-8", errors="replace").read()
    led = parse_ledger(text)
    unsettled = [g for g in led.gates if not g.is_settled and g.id not in led.abandoned]
    if not unsettled:
        return 0, ["[NEXT_GATE] none (all gates settled)"], [], None
    ready = led.ready_gates()
    if not ready:
        return 1, ["[NEXT_GATE] none ready (all unsettled gates are blocked)"], [], None
    g = ready[0]
    lines = [
        f"[NEXT_GATE] {g.id}: {g.title}",
        f"  CHECK: {g.check}",
        f"  EXPECT: {g.expect}",
    ]
    if str(g.expect_exit) != "0":
        lines.append(f"  EXPECT_EXIT: {g.expect_exit}")
    if g.expect_not:
        lines.append(f"  EXPECT_NOT: {g.expect_not}")
    if g.timeout != 60:
        lines.append(f"  TIMEOUT: {g.timeout}")
    return 0, lines, [], g


def execute_gate(
    ledger_path: str,
    gate_id: str,
    settle: bool = False,
    allow_risky: bool = False,
    write_receipt: bool = False,
    facet: str = "unlazy",
    strict: bool = False,
    waive_red: Optional[str] = None,
    force: bool = False,
    cwd_override: Optional[str] = None,
    timeout_override: Optional[int] = None,
) -> Tuple[int, List[str], List[str], Dict[str, object]]:
    prefix = "SETTLE" if settle else "RUN_GATE"
    if not os.path.isfile(ledger_path):
        msg = f"[{prefix}_ERROR] Ledger not found: {ledger_path}"
        return 2, [], [msg], {"verdict": "ERROR", "token": f"{prefix}_ERROR", "reasons": [msg]}

    text = open(ledger_path, "r", encoding="utf-8", errors="replace").read()
    led = parse_ledger(text)
    gmap = led.gate_map()
    if gate_id not in gmap:
        msg = f"[{prefix}_ERROR] Unknown gate '{gate_id}'"
        return 2, [], [msg], {"verdict": "ERROR", "token": f"{prefix}_ERROR", "reasons": [msg]}

    gate = gmap[gate_id]
    if gate.is_settled:
        msg = f"[{prefix}_SKIP] Gate '{gate_id}' is already settled."
        return 0, [msg], [], {"verdict": "PASS", "token": f"{prefix}_SKIP", "gate_id": gate_id, "reasons": []}

    lint_errs = ledger_errors(text, strict=False)
    if lint_errs:
        msg = f"[{prefix}_ERROR] Ledger lint failed with {len(lint_errs)} error(s); first: {lint_errs[0]}"
        return 2, [], [msg], {"verdict": "ERROR", "token": f"{prefix}_ERROR", "reasons": lint_errs}

    unsettled_deps = [d for d in gate.deps if d in gmap and not gmap[d].is_settled]
    if unsettled_deps:
        msg = f"[{prefix}_BLOCKED] Gate '{gate_id}' blocked by unsettled deps: {', '.join(unsettled_deps)}"
        return 1, [msg], [], {"verdict": "FAIL", "token": f"{prefix}_BLOCKED", "gate_id": gate_id, "reasons": [msg]}

    if gate.kind == "desk":
        msg = f"[{prefix}_ERROR] {gate_id}: DESK_NOT_EXECUTABLE: {gate.check}"
        return 2, [], [msg], {"verdict": "ERROR", "token": f"{prefix}_ERROR", "gate_id": gate_id, "reasons": ["DESK_NOT_EXECUTABLE"]}

    eff_cwd = cwd_override or gate.cwd
    if eff_cwd and not os.path.isdir(eff_cwd):
        msg = f"[{prefix}_ERROR] cwd is not a directory: {eff_cwd}"
        return 2, [], [msg], {"verdict": "ERROR", "token": f"{prefix}_ERROR", "gate_id": gate_id, "reasons": [msg]}

    pol = {"allowed": True, "class": "OK", "tags": []}
    if gate.kind == "exec":
        pol = fg_integrity.classify_command(gate.command_text, allow_risky=allow_risky)
        if not pol["allowed"]:
            tags_str = ",".join(pol["tags"])  # type: ignore[arg-type]
            msg = f"[{prefix}_POLICY_DENIED] {gate_id}: {pol['class']}: {tags_str}"
            return 3, [msg], [], {
                "verdict": "POLICY",
                "token": f"{prefix}_POLICY_DENIED",
                "gate_id": gate_id,
                "command": gate.command_text,
                "policy": pol,
                "reasons": [f"{pol['class']}: {tags_str}"],
            }

    # Check strict command integrity before running
    if strict and gate.kind == "exec" and not force:
        int_findings = fg_integrity.analyze_gate_integrity(
            gate.command_text, gate.expect, gate.expect_exit, cwd=eff_cwd or "."
        )
        int_errors = [f for f in int_findings if f["severity"] == "error"]
        if int_errors:
            first_err = int_errors[0]
            msg = f"[{prefix}_FAIL] {gate_id}: INTEGRITY_ERROR [{first_err['code']}]: {first_err['message']}"
            return 1, [msg], [], {
                "verdict": "FAIL",
                "token": f"{prefix}_FAIL",
                "gate_id": gate_id,
                "command": gate.command_text,
                "policy": pol,
                "reasons": [f"{first_err['code']}: {first_err['message']}"],
            }

    if gate.kind == "oracle":
        res, oracle_err = _run_oracle_gate(gate, ledger_path)
        if oracle_err:
            msg = f"[{prefix}_ERROR] {gate_id}: {oracle_err}"
            return 2, [], [msg], {"verdict": "ERROR", "token": f"{prefix}_ERROR", "gate_id": gate_id, "reasons": [oracle_err]}
        ev = fg_runner.evaluate(res, expect=gate.expect, expect_exit=gate.expect_exit, expect_not=gate.expect_not, enforce_rigor=False)
    else:
        eff_timeout = timeout_override if timeout_override is not None else gate.timeout
        res = fg_runner.run_command(gate.command_text, timeout_s=eff_timeout, cwd=eff_cwd)
        ev = fg_runner.evaluate(
            res,
            expect=gate.expect,
            expect_exit=gate.expect_exit,
            expect_not=gate.expect_not,
            enforce_rigor=strict,
        )

    if ev.verdict == "ERROR":
        msg = f"[{prefix}_ERROR] {gate_id}: {ev.human_reasons[0]}"
        return 2, [], [msg], {"verdict": "ERROR", "token": f"{prefix}_ERROR", "gate_id": gate_id, "reasons": ev.reasons}

    fp = gate_fingerprint(gate)
    ev_hash = fg_runner.evidence_hash(gate_id, gate.command_text, res.exit_code, res.stdout, res.stderr)

    # Check Red-Before-Green history prior to appending current settle record
    existing_records = read_evidence_records(ledger_path)
    had_prior_red = any(
        r.get("gate") == gate_id and r.get("fp") == fp and r.get("result") == "red"
        for r in existing_records
    )
    has_prior_waiver = any(
        r.get("gate") == gate_id and r.get("fp") == fp and r.get("waived_red")
        for r in existing_records
    )

    if settle:
        append_evidence_record(
            ledger_path=ledger_path,
            gate_id=gate_id,
            fp=fp,
            phase="settle",
            result="green" if ev.verdict == "PASS" else "red",
            exit_code=res.exit_code,
            ev_hash=ev_hash,
            waived_red=waive_red if (waive_red and not had_prior_red) else None,
            forced=force,
        )

    # Enforce strict Red-Before-Green when baseline/evidence tracking is active on this ledger
    if (
        settle
        and strict
        and ev.verdict == "PASS"
        and gate.kind == "exec"
        and str(gate.expect_exit) == "0"
        and existing_records
        and not had_prior_red
        and not waive_red
        and not has_prior_waiver
    ):
        reason_msg = f"STRICT_NO_RED: Gate '{gate_id}' was never observed failing with current fingerprint {fp}; run --baseline first or pass --waive-red \"<reason>\"."
        out_l = [f"[SETTLE_FAIL] {gate_id}: {reason_msg}"]
        return 1, out_l, [], {
            "verdict": "FAIL",
            "token": "SETTLE_FAIL",
            "gate_id": gate_id,
            "command": gate.command_text,
            "policy": pol,
            "reasons": [reason_msg],
            "duration_ms": res.duration_ms,
        }

    receipt_path: Optional[str] = None
    if write_receipt:
        receipt_path = write_receipt_and_trajectory(
            ledger_path, gate_id, facet, ev.verdict, gate.command_text, res, ev_hash, ev.human_reasons
        )

    ledger_status: Optional[str] = None
    if settle:
        norm_out = fg_runner.normalize_output(res.stdout)
        first_line = ""
        for ln in norm_out.splitlines():
            if ln.strip():
                first_line = ln.strip()[:100]
                break
        if not first_line:
            first_line = "(no stdout)"
        ev_line = f"exit={res.exit_code} | {first_line} | sha256:{ev_hash[:12]}"
        new_box = "x" if ev.verdict == "PASS" else "!"
        ledger_status = new_box
        with ledger_lock(ledger_path):
            fresh_text = open(ledger_path, "r", encoding="utf-8", errors="replace").read()
            updated_text = apply_status(fresh_text, gate_id, new_box, evidence_line=ev_line if new_box == "x" else None)
            atomic_write(ledger_path, updated_text)

    stdout_tail = fg_runner.normalize_output(res.stdout).splitlines()[-40:]
    stderr_tail = fg_runner.normalize_output(res.stderr).splitlines()[-40:]

    extra: Dict[str, object] = {
        "verdict": ev.verdict,
        "token": f"{prefix}_{ev.verdict}",
        "gate_id": gate_id,
        "command": gate.command_text,
        "reasons": ev.reasons,
        "policy": pol,
        "duration_ms": res.duration_ms,
        "child": {
            "exit_code": res.exit_code,
            "signal": res.signal,
            "timed_out": res.timed_out,
            "truncated": res.truncated,
            "duration_ms": res.duration_ms,
        },
        "stdout_tail": stdout_tail,
        "stderr_tail": stderr_tail,
    }
    if ledger_status is not None:
        extra["ledger_status"] = ledger_status
    if receipt_path is not None:
        extra["receipt"] = receipt_path

    if ev.verdict == "PASS":
        return 0, [f"[{prefix}_PASS] {gate.id}: {gate.title} (exit {res.exit_code}, {res.duration_ms} ms)"], [], extra

    out_lines = [f"[{prefix}_FAIL] {gate.id}: {'; '.join(ev.human_reasons)}"]
    if stderr_tail:
        out_lines.append("STDERR:")
        out_lines.extend(f"  {ln}" for ln in stderr_tail)
    if stdout_tail:
        out_lines.append("STDOUT:")
        out_lines.extend(f"  {ln}" for ln in stdout_tail)
    if res.truncated:
        out_lines.append(f"[output truncated: kept head and tail of {res.max_output} bytes]")
    return 1, out_lines, [], extra


def run_baseline(ledger_path: str) -> Tuple[int, List[str], List[str]]:
    if not os.path.isfile(ledger_path):
        return 2, [], [f"[BASELINE_ERROR] Ledger not found: {ledger_path}"]
    text = open(ledger_path, "r", encoding="utf-8", errors="replace").read()
    led = parse_ledger(text)
    open_exec = [g for g in led.gates if not g.is_settled and g.id not in led.abandoned and g.kind == "exec"]
    red_c, green_c, err_c = 0, 0, 0
    details: List[str] = []
    for g in open_exec:
        pol = fg_integrity.classify_command(g.command_text, allow_risky=False)
        if not pol["allowed"]:
            err_c += 1
            details.append(f"  {g.id}: ERROR (policy denied: {pol['class']})")
            continue
        res = fg_runner.run_command(g.command_text, timeout_s=g.timeout, cwd=g.cwd)
        ev = fg_runner.evaluate(res, expect=g.expect, expect_exit=g.expect_exit, expect_not=g.expect_not, enforce_rigor=True)
        fp = gate_fingerprint(g)
        eh = fg_runner.evidence_hash(g.id, g.command_text, res.exit_code, res.stdout, res.stderr)
        if res.timed_out or res.exit_code in {126, 127}:
            err_c += 1
            append_evidence_record(ledger_path, g.id, fp, "baseline", "error", res.exit_code, eh)
            details.append(f"  {g.id}: ERROR (exit={res.exit_code})")
        elif ev.verdict == "PASS":
            green_c += 1
            append_evidence_record(ledger_path, g.id, fp, "baseline", "green", res.exit_code, eh)
            details.append(f"  {g.id}: ALREADY_GREEN (passes before work; tighten CHECK or plan --waive-red)")
        else:
            red_c += 1
            append_evidence_record(ledger_path, g.id, fp, "baseline", "red", res.exit_code, eh)
            details.append(f"  {g.id}: RED (exit={res.exit_code})")

    header = f"[BASELINE_DONE] {len(open_exec)} gate(s) run: {red_c} RED, {green_c} ALREADY_GREEN, {err_c} ERROR"
    rc = 2 if err_c > 0 else (1 if green_c > 0 else 0)
    return rc, [header] + details, []


def run_all_gates(ledger_path: str, reopen: bool = False) -> Tuple[int, List[str], List[str]]:
    if not os.path.isfile(ledger_path):
        return 2, [], [f"[RUN_ALL_ERROR] Ledger not found: {ledger_path}"]
    text = open(ledger_path, "r", encoding="utf-8", errors="replace").read()
    led = parse_ledger(text)
    runnable = [g for g in led.gates if g.id not in led.abandoned and g.kind in {"exec", "oracle"}]
    failed_ids: List[str] = []
    drifted_ids: List[str] = []
    lines: List[str] = []

    for g in runnable:
        if g.kind == "oracle":
            res, _ = _run_oracle_gate(g, ledger_path)
            ev = fg_runner.evaluate(res, expect=g.expect, expect_exit=g.expect_exit, expect_not=g.expect_not)
        else:
            res = fg_runner.run_command(g.command_text, timeout_s=g.timeout, cwd=g.cwd)
            ev = fg_runner.evaluate(res, expect=g.expect, expect_exit=g.expect_exit, expect_not=g.expect_not, enforce_rigor=True)
        fp = gate_fingerprint(g)
        eh = fg_runner.evidence_hash(g.id, g.command_text, res.exit_code, res.stdout, res.stderr)
        if ev.verdict == "PASS":
            append_evidence_record(ledger_path, g.id, fp, "run", "green", res.exit_code, eh)
            lines.append(f"  {g.id}: PASSED")
        else:
            failed_ids.append(g.id)
            if g.is_settled:
                drifted_ids.append(g.id)
                append_evidence_record(ledger_path, g.id, fp, "drift", "red", res.exit_code, eh)
                lines.append(f"  {g.id}: DRIFT (settled gate failed)")
            else:
                append_evidence_record(ledger_path, g.id, fp, "run", "red", res.exit_code, eh)
                lines.append(f"  {g.id}: FAILED")

    if reopen and drifted_ids:
        with ledger_lock(ledger_path):
            cur_text = open(ledger_path, "r", encoding="utf-8", errors="replace").read()
            for gid in drifted_ids:
                cur_text = apply_status(cur_text, gid, " ", evidence_line=None)
            atomic_write(ledger_path, cur_text)

    if not failed_ids:
        return 0, [f"[RUN_ALL_PASS] All {len(runnable)} runnable gate(s) passed; 0 drifted."] + lines, []
    drift_str = ", ".join(drifted_ids) if drifted_ids else "none"
    return 1, [f"[RUN_ALL_FAIL] {len(failed_ids)} gate(s) failed, {len(drifted_ids)} settled gate(s) DRIFTED: {drift_str}"] + lines, []


def _drifted_gates(led: Ledger, records: List[Dict[str, object]]) -> List[str]:
    drifted: List[str] = []
    for g in led.gates:
        if not g.is_settled:
            continue
        fp = gate_fingerprint(g)
        rel = [r for r in records if r.get("gate") == g.id and r.get("fp") == fp and r.get("phase") in {"settle", "run", "drift"}]
        if rel and rel[-1].get("result") in {"red", "error"}:
            drifted.append(g.id)
    return drifted


def status_line(ledger_path: str) -> Tuple[int, List[str], List[str]]:
    if not os.path.isfile(ledger_path):
        return 2, [], [f"[STATUS_ERROR] Ledger not found: {ledger_path}"]
    text = open(ledger_path, "r", encoding="utf-8", errors="replace").read()
    led = parse_ledger(text)
    records = read_evidence_records(ledger_path)
    prod = [g for g in led.gates if not g.is_spike and g.id not in led.abandoned]
    settled = [g for g in prod if g.is_settled]
    open_ids = [g.id for g in prod if not g.is_settled]
    drifted = _drifted_gates(led, records)
    act = led.active or "none"
    open_s = ", ".join(open_ids) if open_ids else "none"
    drift_s = ", ".join(drifted) if drifted else "none"
    return 0, [f"[STATUS] {len(settled)}/{len(prod)} production gates settled. Active: {act}. Open: {open_s}. Drift: {drift_s}."], []


def delivery_report(ledger_path: str, fresh: bool = False) -> Tuple[int, List[str], List[str]]:
    if not os.path.isfile(ledger_path):
        return 2, [], [f"[REPORT_ERROR] Ledger not found: {ledger_path}"]
    if fresh:
        run_all_gates(ledger_path, reopen=False)

    text = open(ledger_path, "r", encoding="utf-8", errors="replace").read()
    led = parse_ledger(text)
    ev_rc, _, _ = verify_evidence_chain(ledger_path)
    records = read_evidence_records(ledger_path)

    prod = [g for g in led.gates if not g.is_spike and g.id not in led.abandoned]
    settled = [g for g in prod if g.is_settled]
    unsettled = [g.id for g in prod if not g.is_settled]
    drifted = _drifted_gates(led, records)

    forced_ids: List[str] = []
    waived_notes: List[str] = []
    never_red_ids: List[str] = []

    for g in settled:
        fp = gate_fingerprint(g)
        g_recs = [r for r in records if r.get("gate") == g.id and r.get("fp") == fp]
        if any(r.get("forced") for r in g_recs):
            forced_ids.append(g.id)
        waivers = [str(r.get("waived_red")) for r in g_recs if r.get("waived_red")]
        if waivers:
            waived_notes.append(f"{g.id} ({waivers[-1]})")
        elif g.kind == "exec" and str(g.expect_exit) == "0":
            if not any(r.get("result") == "red" for r in g_recs):
                never_red_ids.append(g.id)

    blockers: List[str] = []
    if not prod:
        blockers.append("no production gates in ledger")
    if ev_rc != 0:
        blockers.append("evidence log hash chain broken or truncated")
    if unsettled:
        blockers.append(f"{len(unsettled)} production gate(s) not settled: {', '.join(unsettled)}")
    if drifted:
        blockers.append(f"drift (settled but failing): {', '.join(drifted)}")
    if forced_ids:
        blockers.append(f"settled with --force: {', '.join(forced_ids)}")

    caveats: List[str] = []
    if not os.path.isfile(_anchor_path(ledger_path)):
        caveats.append("no .evidence.anchor file pinned")
    if waived_notes:
        caveats.append(f"red-before-green waived: {', '.join(waived_notes)}")
    if never_red_ids:
        caveats.append(f"never observed failing: {', '.join(never_red_ids)}")

    if not blockers:
        out = [f"[REPORT_PASS] DELIVERABLE ({len(settled)}/{len(prod)} settled, {len(records)} evidence records, 0 blockers)"]
        for c in caveats:
            out.append(f"  caveat: {c}")
        return 0, out, []
    out = [f"[REPORT_FAIL] NOT_DELIVERABLE ({len(blockers)} blocker(s): {'; '.join(blockers)})"]
    for c in caveats:
        out.append(f"  caveat: {c}")
    return 1, out, []


def retro_report(ledger_path: str) -> Tuple[int, List[str], List[str]]:
    if not os.path.isfile(ledger_path):
        return 2, [], [f"[RETRO_ERROR] Ledger not found: {ledger_path}"]
    text = open(ledger_path, "r", encoding="utf-8", errors="replace").read()
    led = parse_ledger(text)
    records = read_evidence_records(ledger_path)
    prod = [g for g in led.gates if not g.is_spike and g.id not in led.abandoned]
    settled = [g for g in prod if g.is_settled]

    drifts = sum(1 for r in records if r.get("phase") == "drift")
    waivers = sum(1 for r in records if r.get("waived_red"))
    forced = sum(1 for r in records if r.get("forced"))
    never_red = 0
    for g in settled:
        fp = gate_fingerprint(g)
        g_recs = [r for r in records if r.get("gate") == g.id and r.get("fp") == fp]
        if g.kind == "exec" and str(g.expect_exit) == "0" and not any(r.get("result") == "red" or r.get("waived_red") for r in g_recs):
            never_red += 1

    return 0, [f"[RETRO_PASS] {len(settled)}/{len(prod)} settled | drifts={drifts} | waivers={waivers} | forced={forced} | never_red={never_red}"], []
