/**
 * Corpus distribution probe for vertical justification (VGA M5).
 *
 * Per-page void and ratio distribution over the whole corpus × 3 templates ×
 * balance on/off, with a pinned seed/timestamp so the output is a stable
 * fixture. Prints a table; `--json` writes the machine-readable form used by
 * `tests/lean/justify-corpus.lean.js` (G12 distribution) and G18 (absence of
 * the dead slack model).
 *
 * Usage:
 *   node scripts/probe-vertical-justification.mjs
 *   node scripts/probe-vertical-justification.mjs --json > tests/fixtures/vertical-justify.json
 */
import { runPipeline } from '../src/v2/runtime/pipeline.js';
import { TEMPLATES } from '../src/v2/templates/definitions.js';
import { PAGE_SIZES } from '../src/v2/core/geometry.js';
import { elementExtent } from '../src/v2/layout/stretch-seam.js';
import { readCorpus } from '../tests/corpus/index.js';

const FIX = { seed: 'vertical-justify', timestamp: 1700000000000 };

const DOCS = ['sample1.md', 'sample2.md', 'sample3.md', 'sample4.md', 'text-test.md', 'taskfiles/sampletext2.md'];
const TEMPLATE_IDS = ['base', 'bauhaus', 'bauhaus_minimalist'];
const BALANCE = [false, true];

const contentBottomY = (template) => {
  const t = TEMPLATES[template];
  return PAGE_SIZES.A4.height - t.margins.bottom - t.footskip;
};

const docOf = (markdown, template, balance) => ({
  title: 'Probe',
  template,
  blocks: [{
    title: 'A', markdown, masthead: { enabled: false },
    flags: { autofix: true, optimize_tables: true, split_equations: true, ...(balance ? { balance_columns: true } : {}) },
    columns: null,
  }],
});

/**
 * Bottom void of one page, in points. Chrome (header/footer) is excluded by
 * the same contentBottomY test the compiler's own audit uses, and vertical
 * rules are excluded — a column separator stretches to the foot by design
 * and must not define it.
 */
const pageVoidPt = (page, cbY) => {
  let bottom = -Infinity;
  for (const el of (page.elements || [])) {
    if (el && el.type === 'rule' && (el.y1 || 0) !== (el.y2 || 0)) continue;
    const ext = elementExtent(el);
    if (!ext || ext.top >= cbY + 0.5) continue;
    if (ext.bottom > bottom) bottom = ext.bottom;
  }
  return Number.isFinite(bottom) ? Math.round((cbY - bottom) * 100) / 100 : null;
};

const rows = [];
for (const file of DOCS) {
  const markdown = readCorpus(file);
  for (const template of TEMPLATE_IDS) {
    for (const balance of BALANCE) {
      const { displayList: dl } = await runPipeline({
        payload: docOf(markdown, template, balance), mode: 'paginate', ...FIX,
      });
      const cbY = contentBottomY(template);
      const j = dl.diagnostics.justify || {};
      const applied = new Set(j.pages || []);
      for (const page of (dl.pages || [])) {
        const n = page.pageNumber;
        rows.push({
          doc: file,
          template,
          balance,
          page: n,
          applied: applied.has(n),
          voidPt: pageVoidPt(page, cbY),
          reason: (j.skipped || []).find((s) => s.page === n)?.reason ?? null,
          lifted: (j.lifted || []).includes(n),
        });
      }
    }
  }
}

const summary = {
  generated: 'scripts/probe-vertical-justification.mjs',
  seed: FIX.seed,
  timestamp: FIX.timestamp,
  docs: DOCS,
  templates: TEMPLATE_IDS,
  balance: BALANCE,
  rows,
};

if (process.argv.includes('--json')) {
  process.stdout.write(`${JSON.stringify(summary, null, 1)}\n`);
} else {
  const pad = (s, n) => String(s).padEnd(n);
  console.log(`${pad('doc', 24)} ${pad('template', 20)} ${pad('bal', 5)} ${pad('pg', 4)} ${pad('void', 9)} ${pad('state', 14)} reason`);
  for (const r of rows) {
    const state = r.applied ? 'applied' : (r.lifted ? 'lifted' : 'ragged');
    console.log(`${pad(r.doc, 24)} ${pad(r.template, 20)} ${pad(r.balance ? 'on' : 'off', 5)} ${pad(r.page, 4)} ${pad(`${r.voidPt}pt`, 9)} ${pad(state, 14)} ${r.reason || ''}`);
  }
  const applied = rows.filter((r) => r.applied).length;
  const voids = rows.filter((r) => r.applied && r.voidPt !== null).map((r) => r.voidPt);
  const over = voids.filter((v) => v > 1.0);
  console.log(`\npages=${rows.length} applied=${applied} lifted=${rows.filter((r) => r.lifted).length} ragged=${rows.filter((r) => !r.applied && !r.lifted).length}`);
  console.log(`applied void: max=${Math.max(...voids).toFixed(2)}pt mean=${(voids.reduce((a, b) => a + b, 0) / voids.length).toFixed(2)}pt  G12 violations (>1pt)=${over.length}`);
}
