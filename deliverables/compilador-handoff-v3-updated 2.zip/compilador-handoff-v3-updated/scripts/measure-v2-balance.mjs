// V2 column-balance probe: measures per-page column bottom alignment
// from compiled PDF text matrices (no Typst toolchain needed to READ,
// only to produce the PDF).
// Gate semantics (LaTeX parity): mid-document page breaks may end ragged —
// only the TERMINAL page must balance. A non-terminal page fails only when
// BOTH columns end >200pt above the foot (half-empty page = pathology).
// Usage: node scripts/measure-v2-balance.mjs <pdf> [tolerancePt] [--json]
import { decodePdfRuns } from './pdf-text-runs.mjs';

const [pdfPath, tolArg] = process.argv.slice(2);
if (!pdfPath) { console.error('usage: node scripts/measure-v2-balance.mjs <pdf> [tolPt] [--json]'); process.exit(2); }
const TOL = Number(tolArg ?? 12);
const JSON_OUT = process.argv.includes('--json');

import fs from 'node:fs';
const pages = decodePdfRuns(fs.readFileSync(pdfPath));

let worst = 0, failures = 0;
const pagesOut = [];
pages.forEach(({ W, H, runs }, i) => {
  const body = runs.filter((p) => p.y > 60 && p.y < H - 27);
  const pageText = body.map((r) => r.text).join(' ').slice(0, 30000);
  const runSample = body.map((r) => ({ x: Math.round(r.x * 10) / 10, y: Math.round(r.y * 10) / 10, t: r.text.slice(0, 60) }));
  if (body.length === 0) {
    // Blank last page = the trailing-whitespace bug. Mid-doc blank (e.g. a
    // bare image page with no text runs) only warns.
    const bad = i === pages.length - 1;
    pagesOut.push({ page: i + 1, skipped: 'no-body-text', text: '', unbalanced: bad, runs: [] });
    if (bad) failures++;
    if (!JSON_OUT) console.log(`page ${i + 1}: no body text (${bad ? 'FAIL' : 'warn'})`);
    return;
  }
  const left = body.filter((p) => p.x < W / 2).map((p) => p.y);
  const right = body.filter((p) => p.x >= W / 2).map((p) => p.y);
  if (left.length === 0 || right.length === 0) {
    const n = left.length + right.length;
    const isLast = i === pages.length - 1;
    // Terminal single-column tail fails unless tiny; mid-doc single column
    // means a half-empty page and always fails.
    const bad = isLast ? n > 4 : true;
    pagesOut.push({ page: i + 1, skipped: 'single-column', left: left.length, right: right.length,
      bottom: left.length ? Math.min(...left) : Math.min(...right), text: pageText, unbalanced: bad,
      runs: runSample });
    if (bad) failures++;
    if (!JSON_OUT) console.log(`page ${i + 1}: single column (${bad ? 'UNBALANCED' : 'tiny tail, ok'})`);
    return;
  }
  const delta = Math.abs(Math.min(...left) - Math.min(...right));
  const isLast = i === pages.length - 1;
  const slackL = Math.min(...left) - 60, slackR = Math.min(...right) - 60;
  // Terminal page: must balance. Mid-document: fail only on half-empty page.
  const ok = isLast ? delta <= TOL : !(slackL > 200 && slackR > 200);
  if (!ok) failures++;
  worst = Math.max(worst, delta);
  pagesOut.push({ page: i + 1, left: left.length, right: right.length, delta,
    leftBottom: Math.min(...left), rightBottom: Math.min(...right), terminal: isLast, text: pageText, runs: runSample });
  if (!JSON_OUT) console.log(`page ${i + 1}: bottom L=${Math.min(...left).toFixed(1)} R=${Math.min(...right).toFixed(1)} delta=${delta.toFixed(1)}pt ${isLast ? (ok ? 'BALANCED' : 'UNBALANCED') : '(mid-doc)'} `);
});
if (JSON_OUT) {
  console.log(JSON.stringify({ pages: pages.length, worst, failures, tol: TOL, detail: pagesOut }));
} else {
  console.log(`worst delta=${worst.toFixed(1)}pt tol=${TOL}pt ${failures === 0 ? 'PASS' : `FAIL (${failures} pages)`}`);
}
process.exitCode = failures === 0 ? 0 : 1;
