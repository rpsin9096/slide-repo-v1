import json
import os
import re
from typing import Dict, List, Tuple

SUFFIX_OPT = r"(?:s|es|ed|ing|ally|ly)?"

ARCHETYPE_CASCADE = [
    ("FRONTEND_BESPOKE", "Bespoke Frontend Design & Implementation", ["frontend-design", "design-tokens", "prototype", "codebase-design", "unlazy", "code-review"], 30),
    ("DESIGN_AUDIT", "Design Audit & Accessibility Polish", ["diagnosing-bugs", "focus-design", "unlazy", "code-review"], 20),
    ("UI_COMPONENT", "UI Component & Design System Slicing", ["writing-fragments", "focus-design", "prototype", "codebase-design", "unlazy"], 35),
    ("VISUAL_ASSET", "Visual Design & Creative Asset Production", ["triage", "focus-design", "prototype", "code-review"], 20),
    ("POSTMORTEM", "Narrative Guide & Post-Mortem", ["diagnosing-bugs", "writing-beats", "code-review"], 25),
    ("AUTOMATION", "Loop Synthesis", ["loop-me", "grilling", "unlazy"], 25),
    ("SPECIFICATION", "Architectural RFC Spec", ["writing-fragments", "codebase-design", "writing-shape", "prototype"], 45),
    ("IDEATION", "Ideation to Implementation", ["writing-fragments", "writing-shape", "writing-for-agents", "unlazy"], 30),
    ("ATOMIC_EXPLICIT", "Atomic Sprint", ["unlazy", "unlazy", "code-review"], 10),
    ("DEFECT", "Rapid Defect Resolution", ["triage", "diagnosing-bugs", "unlazy", "code-review"], 15),
    ("STRATEGY", "Strategic Wayfinding", ["grilling", "wayfinder", "prototype", "unlazy"], 45),
    ("ARCHITECTURE", "Deep Module Redesign", ["codebase-design", "prototype", "unlazy", "code-review"], 40),
    ("ATOMIC", "Atomic Sprint", ["unlazy", "unlazy", "code-review"], 10),
]


def _phrase_hits(text_low: str, phrase: str) -> bool:
    p = re.escape(phrase.lower().strip())
    pat = rf"(?<![a-z0-9]){p}{SUFFIX_OPT}(?![a-z0-9])"
    return re.search(pat, text_low) is not None


def score_facets(task_text: str, index_path: str) -> List[Tuple[str, float]]:
    text_low = task_text.lower()
    if not os.path.isfile(index_path):
        return []
    data = json.load(open(index_path, "r", encoding="utf-8"))
    facets = data.get("facets", [])
    scored: List[Tuple[str, float]] = []
    for f in facets:
        fid = f["id"]
        pri = float(f.get("priority", 5))
        never = f.get("never_when", [])
        if any(_phrase_hits(text_low, nw) for nw in never):
            continue
        triggers = f.get("applies_when", [])
        matched = [t for t in triggers if _phrase_hits(text_low, t)]
        if not matched:
            continue
        hits = len(matched)
        longest_words = max(len(t.split()) for t in matched)
        score = pri + 1.5 * min(hits - 1, 3) + 0.5 * (longest_words - 1)
        scored.append((fid, score))
    scored.sort(key=lambda x: (-x[1], x[0]))
    return scored


def route_task(task_text: str, index_path: str) -> Dict[str, object]:
    text_low = task_text.lower()
    scored = score_facets(task_text, index_path)
    top6 = [f[0] for f in scored[:6]]
    top4 = [f[0] for f in scored[:4]]

    ui_kw = ("ui component", "design system", "design tokens", "button component", "card layout", "card component", "modal dialog", "table ui", "navigation bar", "styling", "css variables", "shadcn", "tailwind", "alert banner")
    pm_kw = ("post-mortem", "postmortem", "incident", "tutorial", "migration guide", "release notes", "changelog")
    at_kw = ("typo", "bump version", "badge link", "single comment", "change default timeout", "quick 2-minute", "atomic")
    st_kw = ("fog", "maybe", "concept")

    chosen = ARCHETYPE_CASCADE[-1]
    if "frontend-design" in top6 or "frontend-design" in text_low:
        chosen = ARCHETYPE_CASCADE[0]
    elif "focus-design" in top6:
        chosen = ARCHETYPE_CASCADE[1]
    elif any(k in text_low for k in ui_kw):
        chosen = ARCHETYPE_CASCADE[2]
    elif "banner-safe-zone" in top6 or "logo" in text_low:
        chosen = ARCHETYPE_CASCADE[3]
    elif any(k in text_low for k in pm_kw):
        chosen = ARCHETYPE_CASCADE[4]
    elif "loop-me" in top6:
        chosen = ARCHETYPE_CASCADE[5]
    elif "writing-shape" in top6:
        chosen = ARCHETYPE_CASCADE[6]
    elif "writing-fragments" in top6 or "spark" in text_low:
        chosen = ARCHETYPE_CASCADE[7]
    elif any(k in text_low for k in at_kw):
        chosen = ARCHETYPE_CASCADE[8]
    elif "diagnosing-bugs" in top6:
        chosen = ARCHETYPE_CASCADE[9]
    elif "wayfinder" in top6 or any(k in text_low for k in st_kw):
        chosen = ARCHETYPE_CASCADE[10]
    elif "codebase-design" in top6:
        chosen = ARCHETYPE_CASCADE[11]

    arch_name = "ATOMIC" if chosen[0] == "ATOMIC_EXPLICIT" else chosen[0]
    return {
        "archetype": arch_name,
        "pipeline_title": chosen[1],
        "stages": chosen[2],
        "est_minutes": chosen[3],
        "facets": top4,
    }
