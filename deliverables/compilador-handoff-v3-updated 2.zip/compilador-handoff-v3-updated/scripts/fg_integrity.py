import ast
import os
import re
import shlex
from typing import Dict, List, Optional, Tuple

DENY_RULES: List[Tuple[str, re.Pattern]] = [
    ("SUDO", re.compile(r"(?:^|[;&|()\s])sudo(?:\s|$)")),
    ("PIPE_TO_SHELL", re.compile(
        r"\b(?:curl|wget|fetch)\b[^|;&\n]*\|\s*(?:sudo\s+(?:-\S+\s+)*)?(?:ba|z|da|k|fi)?sh\b"
        r"|\b(?:sh|bash|zsh)\s+<\(\s*(?:curl|wget)\b"
        r"|\beval\s+[\"']?\$\(\s*(?:curl|wget)\b"
        r"|\b(?:ba|z|da|k)?sh\s+-c\s+[\"']?\$\(?\s*(?:curl|wget)\b"
        r"|\bbase64\s+(?:-d|--decode)\b[^|;&\n]*\|\s*(?:sudo\s+)?(?:ba|z|da)?sh\b"
    )),
    ("EVAL_INDIRECTION", re.compile(
        r"\b(?:eval|source|\.)\s+[\"']?\$\{?\w+\}?[\"']?\s*(?:;|&&|\||$)"
        r"|\b(?:ba|z|da)?sh\b\s*<<<?\s*[\"']?\$"
    )),
    ("MKFS", re.compile(r"\b(?:mkfs(?:\.\w+)?|fdisk|parted|shred|wipefs)\b")),
    ("DD_DEVICE", re.compile(r"\bdd\s+if=|\bof=/dev/")),
    ("WRITE_DEVICE", re.compile(r">\s*/dev/(?:sd|nvme|hd|vd|mmcblk|disk)\w*")),
    ("FORK_BOMB", re.compile(r":\(\)\s*\{\s*:\|:&\s*\};:")),
    ("POWER", re.compile(r"\b(?:shutdown|reboot|poweroff|halt|init\s+0)\b")),
    ("CHMOD_ROOT", re.compile(r"\bchmod\s+(?:-\S+\s+)*0?777\s+(?:-\S+\s+)*[\"']?(?:/|~|\$HOME)[\"']?(?:\s|$)")),
    ("FIND_DELETE_ROOT", re.compile(r"\bfind\s+[\"']?(?:/|~|\$HOME)[\"']?(?:\s|$)[^|;&\n]*-delete\b")),
    ("INTERPRETER_WIPE", re.compile(
        r"\b(?:rmtree|os\.(?:remove|unlink|rmdir)|shutil\.move)\(\s*[rbuf]*[\"'](?:/|~|/home|/etc|/usr|/var|/root)[\"']"
        r"|\b(?:python3?|perl|ruby|node)\s+-[ec]\s+[\"'][^\"']*\b(?:rmtree|unlink|rmdir|remove)\b[^\"']*(?:expanduser|HOME|getenv)"
    )),
    ("GIT_FORCE_PUSH", re.compile(r"\bgit\s+push\b[^\n;&|]*(?:--force(?:-with-lease)?|-f\b)")),
]

CONFIRM_RULES: List[Tuple[str, re.Pattern]] = [
    ("GIT_DESTRUCTIVE", re.compile(r"\bgit\s+(?:push\b|reset\s+--hard\b|clean\s+-[a-zA-Z]*f|checkout\s+--\s+\.)")),
    ("PACKAGE_INSTALL", re.compile(r"\b(?:pip3?\s+install|npm\s+(?:i|install)|pnpm\s+add|yarn\s+add|cargo\s+install|apt(?:-get)?\s+install|brew\s+install)\b")),
    ("ENV_DUMP", re.compile(r"(?:^|[;&|()\s])(?:printenv|env)(?:\s*[;&|)]|\s*$)|\bcat\s+[^\n;&|]*\.env\b")),
    ("CHMOD_WIDE", re.compile(r"\bchmod\s+(?:-\S+\s+)*(?:0?777|a\+[rwx]*w)")),
]

BROAD_RM_TARGETS = {"/", "/*", "~", "~/*", "$HOME", "${HOME}", ".", "..", "*"}


def _has_broad_rm(cmd: str) -> bool:
    # Check both direct rm and xargs rm across quoted or unquoted tokens
    if re.search(r"\bxargs\b[^|;&\n]*\brm\s+(?:-[a-zA-Z]*[rf][a-zA-Z]*|--recursive|--force)\b[^|;&\n]*(?:\s+[\"']?(?:/|~|\$HOME|\.\.)[\"']?(?:\s|$))", cmd):
        return True
    try:
        lex = shlex.shlex(cmd, posix=False, punctuation_chars=";&|()")
        lex.whitespace_split = True
        tokens = list(lex)
    except ValueError:
        tokens = cmd.split()

    i = 0
    while i < len(tokens):
        tok = tokens[i].strip("\"'")
        if os.path.basename(tok) == "rm":
            has_rf = False
            targets: List[str] = []
            j = i + 1
            while j < len(tokens):
                t = tokens[j]
                if t in {";", "&&", "||", "|", "|&", "&", ")"}:
                    break
                unq = t.strip("\"'")
                if unq.startswith("-"):
                    if "r" in unq or "f" in unq or unq in {"--recursive", "--force"}:
                        has_rf = True
                else:
                    targets.append(unq)
                j += 1
            if has_rf:
                for tgt in targets:
                    if tgt in BROAD_RM_TARGETS or tgt.startswith("../") or tgt == "/..":
                        return True
            i = j
        else:
            i += 1
    return False


def classify_command(command: str, allow_risky: bool = False) -> Dict[str, object]:
    deny_tags: List[str] = []
    if _has_broad_rm(command):
        deny_tags.append("RM_BROAD")
    for tag, pat in DENY_RULES:
        if pat.search(command) and tag not in deny_tags:
            deny_tags.append(tag)
    if deny_tags:
        return {"allowed": False, "class": "DENY", "tags": deny_tags}

    confirm_tags: List[str] = []
    for tag, pat in CONFIRM_RULES:
        if pat.search(command) and tag not in confirm_tags:
            confirm_tags.append(tag)
    if confirm_tags:
        return {"allowed": bool(allow_risky), "class": "CONFIRM", "tags": confirm_tags}

    return {"allowed": True, "class": "OK", "tags": []}


# --- GateIntegrity Analyzer (v5.1 + FG65 unified) ---

_ALWAYS_OK = {":", "echo", "printf", "true"}
_SELF_WORDS = {":", "echo", "exit", "printf", "return", "sleep", "true", "yes"}
_WRAPPERS = {"command", "env", "exec", "nice", "nohup", "sudo", "time"}
_RUNNERS = {
    "bun", "cargo", "ctest", "deno", "dotnet", "flutter", "go", "gradle",
    "gradlew", "jest", "make", "mix", "mocha", "mvn", "nox", "npm", "npx",
    "phpunit", "pnpm", "py.test", "pytest", "python", "python3", "rspec",
    "ruby", "swift", "tox", "vitest", "yarn",
}
_FORMATTERS = {"cat", "cut", "head", "less", "more", "sed", "sort", "tail", "tee", "uniq"}
_PROBES = {"date", "env", "hostname", "id", "printenv", "pwd", "uname", "uptime", "whoami"}
_GIT_PROBES = {"branch", "config", "log", "remote", "rev-parse", "status", "version"}
_SHELLS = {"bash", "dash", "ksh", "sh", "zsh"}
_OPERATORS = {"&", "&&", ";", "|", "|&", "||"}
_EXPECT_PROBES = ("", "zzz9 probe\nline two", "FAIL: boom (exit 1)")
_TRIVIAL_EXPECT_WORDS = {"", "true", "ok", "0", "pass", "works", "done"}

_MARKER_T = "TO" + "DO"
_MARKER_F = "FIX" + "ME"
_PLACEHOLDER_RE = re.compile(
    rf"\b(?:{_MARKER_T}|{_MARKER_F}|REPLACE_ME)\b|<replace|<command|\{{\{{|\}}\}}",
    re.IGNORECASE,
)
_SNAKE_PH_RE = re.compile(r"(?<![${])\{([a-z][a-z0-9_]*)\}(?!\})")


def _cmd_word_and_rest(words: List[str]) -> Tuple[str, List[str]]:
    idx = 0
    while idx < len(words):
        w = words[idx]
        if "=" in w and not w.startswith("-") and w.split("=", 1)[0].isidentifier():
            idx += 1
            continue
        base = os.path.basename(w).lower()
        if base in _WRAPPERS:
            idx += 1
            continue
        return base, words[idx + 1 :]
    return "", []


def _split_segments(cmd: str) -> Optional[Tuple[List[Dict[str, object]], Optional[str]]]:
    try:
        lex = shlex.shlex(cmd, posix=True, punctuation_chars=";&|()")
        lex.whitespace_split = False
        tokens = list(lex)
    except ValueError:
        return None
    segments: List[Dict[str, object]] = []
    cur_words: List[str] = []
    prev_op: Optional[str] = None
    depth = 0
    has_group = False
    last_op: Optional[str] = None

    for tok in tokens:
        if tok == "(":
            depth += 1
            has_group = True
            cur_words.append(tok)
        elif tok == ")":
            depth = max(0, depth - 1)
            cur_words.append(tok)
        elif depth == 0 and tok in _OPERATORS:
            if cur_words:
                segments.append({"words": cur_words, "prev_op": prev_op, "group": has_group})
            cur_words = []
            has_group = False
            prev_op = tok
            last_op = tok
        else:
            cur_words.append(tok)
            last_op = None

    if cur_words:
        segments.append({"words": cur_words, "prev_op": prev_op, "group": has_group})
    return segments, last_op


def _analyze_shell_command(cmd: str, expect_exit: str, pipefail: bool = False, depth: int = 0) -> List[Dict[str, str]]:
    if depth > 3:
        return []
    findings: List[Dict[str, str]] = []
    parsed = _split_segments(cmd)
    if parsed is None:
        return [{"code": "UNPARSEABLE_CHECK", "severity": "warn", "message": "cannot parse this CHECK (unbalanced quotes?); integrity not verified"}]
    segments, trailing_op = parsed
    if not segments:
        return [{"code": "SELF_SATISFYING", "severity": "error", "message": "empty CHECK command"}]

    # Check if pipefail is enabled inside segments
    local_pipefail = pipefail
    for seg in segments:
        w, rest = _cmd_word_and_rest(seg["words"])  # type: ignore[arg-type]
        if w == "set" and any("pipefail" in r for r in rest):
            local_pipefail = True

    # SELF_SATISFYING (only when expecting exit 0)
    if expect_exit == "0":
        all_self = True
        for seg in segments:
            if seg["group"]:
                all_self = False
                break
            w, rest = _cmd_word_and_rest(seg["words"])  # type: ignore[arg-type]
            if w not in _SELF_WORDS:
                all_self = False
                break
            if w == "exit" and (not rest or rest[0] != "0"):
                all_self = False
                break
        if all_self:
            findings.append({
                "code": "SELF_SATISFYING",
                "severity": "error",
                "message": "every command here succeeds regardless of the project (echo/true/exit 0); it cannot fail, so it proves nothing",
            })

    # MASKED_EXIT
    for seg in segments:
        if seg["group"]:
            continue
        w, rest = _cmd_word_and_rest(seg["words"])  # type: ignore[arg-type]
        if w == "set" and ("+e" in rest or ("+o" in rest and "errexit" in rest)):
            findings.append({"code": "MASKED_EXIT", "severity": "error", "message": "'set +e' disables failure detection"})
        if seg["prev_op"] == "||" and (w in _ALWAYS_OK or (w == "exit" and rest and rest[0] == "0")):
            findings.append({"code": "MASKED_EXIT", "severity": "error", "message": f"'|| {w}' turns a failing command into exit 0"})

    last_seg = segments[-1]
    if not last_seg["group"] and last_seg["prev_op"] == ";":
        lw, lrest = _cmd_word_and_rest(last_seg["words"])  # type: ignore[arg-type]
        if lw in _ALWAYS_OK or (lw == "exit" and lrest and lrest[0] == "0"):
            findings.append({"code": "MASKED_EXIT", "severity": "error", "message": f"the last command ({lw}) decides the exit status and always succeeds"})

    if trailing_op == "&":
        findings.append({"code": "MASKED_EXIT", "severity": "error", "message": "a backgrounded command returns exit 0 immediately"})

    # PIPE_MASKS_EXIT
    if not local_pipefail:
        for idx in range(len(segments) - 1):
            s1, s2 = segments[idx], segments[idx + 1]
            if s2["prev_op"] in {"|", "|&"}:
                w1, _ = _cmd_word_and_rest(s1["words"])  # type: ignore[arg-type]
                w2, _ = _cmd_word_and_rest(s2["words"])  # type: ignore[arg-type]
                if w1 in _RUNNERS and w2 in _FORMATTERS:
                    findings.append({
                        "code": "PIPE_MASKS_EXIT",
                        "severity": "warn",
                        "message": f"piping '{w1}' into '{w2}' discards the runner's exit status; use bash -o pipefail -c '...'",
                    })
                    break

    # TAUTOLOGY_CHECK
    all_probes = True
    for seg in segments:
        if seg["group"]:
            all_probes = False
            break
        w, rest = _cmd_word_and_rest(seg["words"])  # type: ignore[arg-type]
        non_flag = [r for r in rest if not r.startswith("-")]
        if w in _PROBES:
            continue
        if w == "git" and non_flag and non_flag[0] in _GIT_PROBES:
            continue
        if w == "ls" and not non_flag:
            continue
        all_probes = False
        break
    if all_probes:
        findings.append({"code": "TAUTOLOGY_CHECK", "severity": "warn", "message": "this probe passes in any repository, whatever you changed"})

    # LITERAL_OUTPUT & shell recursion
    for seg in segments:
        if seg["group"]:
            continue
        w, rest = _cmd_word_and_rest(seg["words"])  # type: ignore[arg-type]
        if w.startswith("python") and "-c" in rest:
            c_idx = rest.index("-c")
            if c_idx + 1 < len(rest):
                code_str = rest[c_idx + 1]
                if "print" in code_str and not re.search(r"import|open\(|assert|subprocess|exit\(|raise|os\.", code_str):
                    findings.append({"code": "LITERAL_OUTPUT", "severity": "warn", "message": "python -c only prints a literal; the output is not evidence"})
        if w in _SHELLS:
            # Find -c script
            sub_pf = local_pipefail or any("pipefail" in r for r in rest)
            for r_idx, r_tok in enumerate(rest):
                if r_tok.startswith("-") and not r_tok.startswith("--") and "c" in r_tok[1:]:
                    if r_idx + 1 < len(rest):
                        findings.extend(_analyze_shell_command(rest[r_idx + 1], expect_exit, pipefail=sub_pf, depth=depth + 1))
                    break

    return findings


def _func_has_real_assertion(fn_node: ast.AST) -> bool:
    for node in ast.walk(fn_node):
        if isinstance(node, ast.Raise):
            return True
        if isinstance(node, ast.Assert):
            t = node.test
            if isinstance(t, ast.Constant) and t.value in (True, 1):
                continue
            if isinstance(t, ast.Compare) and len(t.ops) == 1 and isinstance(t.ops[0], (ast.Eq, ast.Is, ast.GtE, ast.LtE)):
                if ast.dump(t.left) == ast.dump(t.comparators[0]):
                    continue
            return True
        if isinstance(node, ast.Call):
            name = ""
            if isinstance(node.func, ast.Name):
                name = node.func.id
            elif isinstance(node.func, ast.Attribute):
                name = node.func.attr
            low = name.lower()
            if low in {"fail", "raises", "approx", "warns"} or low.startswith(("assert", "expect", "verify", "check", "ensure", "must")):
                if low in {"asserttrue", "assertisnone"} and len(node.args) == 1 and isinstance(node.args[0], ast.Constant) and node.args[0].value in (True, None):
                    continue
                if low == "assertfalse" and len(node.args) == 1 and isinstance(node.args[0], ast.Constant) and node.args[0].value is False:
                    continue
                if low.startswith("assertequal") and len(node.args) >= 2 and ast.dump(node.args[0]) == ast.dump(node.args[1]):
                    continue
                return True
    return False


def _inspect_test_targets(cmd: str, cwd: str) -> List[Dict[str, str]]:
    findings: List[Dict[str, str]] = []
    try:
        tokens = shlex.split(cmd)
    except ValueError:
        return findings
    if not any(os.path.basename(t) in {"pytest", "py.test", "unittest"} for t in tokens):
        return findings
    for tok in tokens:
        if tok.startswith("-"):
            continue
        file_part = tok.split("::", 1)[0]
        if file_part.endswith(".py"):
            cand = os.path.join(cwd, file_part)
            if os.path.isfile(cand):
                try:
                    tree = ast.parse(open(cand, "r", encoding="utf-8").read(), filename=file_part)
                except SyntaxError:
                    continue
                test_fns = [
                    n for n in ast.walk(tree)
                    if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name.startswith("test")
                ]
                if not test_fns:
                    findings.append({
                        "code": "EMPTY_TEST_TARGET",
                        "severity": "error",
                        "message": f"{file_part} selects 0 tests; an empty run is not evidence",
                    })
                else:
                    bare = [fn.name for fn in test_fns if not _func_has_real_assertion(fn)]
                    if len(bare) == len(test_fns):
                        findings.append({
                            "code": "TEST_WITHOUT_ASSERTIONS",
                            "severity": "error",
                            "message": f"none of the {len(test_fns)} test(s) in {file_part} asserts anything; they can only fail by crashing",
                        })
                    elif bare:
                        findings.append({
                            "code": "SOME_TESTS_WITHOUT_ASSERTIONS",
                            "severity": "warn",
                            "message": f"{len(bare)} of {len(test_fns)} test(s) in {file_part} assert nothing: {', '.join(bare[:3])}",
                        })
    return findings


def analyze_gate_integrity(
    check_cmd: str,
    expect_re: Optional[str],
    expect_exit: str = "0",
    cwd: str = ".",
) -> List[Dict[str, str]]:
    findings: List[Dict[str, str]] = []
    chk_clean = (check_cmd or "").replace("{{focusgate}}", "focus_gate.py")
    exp_clean = (expect_re or "").replace("{{focusgate}}", "focus_gate.py")

    if _PLACEHOLDER_RE.search(chk_clean) or _PLACEHOLDER_RE.search(exp_clean) or _SNAKE_PH_RE.search(chk_clean) or _SNAKE_PH_RE.search(exp_clean):
        findings.append({"code": "UNFILLED_TEMPLATE", "severity": "error", "message": "CHECK/EXPECT still contains a template placeholder"})

    raw_cmd = check_cmd.strip()
    is_exec = True
    if raw_cmd.startswith("oracle:") or raw_cmd.startswith("desk:"):
        is_exec = False
    elif raw_cmd.startswith("exec:"):
        raw_cmd = raw_cmd[5:].strip()

    if is_exec:
        pol = classify_command(raw_cmd, allow_risky=False)
        if pol["class"] == "DENY":
            findings.append({
                "code": "DESTRUCTIVE_COMMAND",
                "severity": "error",
                "message": f"{','.join(pol['tags'])}; a gate CHECK may not run this",  # type: ignore[arg-type]
            })
        findings.extend(_analyze_shell_command(raw_cmd, expect_exit=str(expect_exit)))
        findings.extend(_inspect_test_targets(raw_cmd, cwd=cwd))

    if expect_re is not None:
        exp_s = expect_re.strip()
        if str(expect_exit) == "0" and exp_s.lower() in _TRIVIAL_EXPECT_WORDS:
            findings.append({"code": "VACUOUS_EXPECT", "severity": "error", "message": f"EXPECT '{exp_s}' is trivial and constrains nothing"})
        else:
            try:
                cre = re.compile(exp_s, re.MULTILINE)
                if str(expect_exit) == "0":
                    if cre.search("") is not None or all(cre.search(p) is not None for p in _EXPECT_PROBES):
                        findings.append({"code": "VACUOUS_EXPECT", "severity": "error", "message": "EXPECT matches any output, so it constrains nothing"})
            except re.error as exc:
                findings.append({"code": "INVALID_EXPECT", "severity": "error", "message": f"EXPECT is not a valid regex: {exc}"})

    # Deduplicate and sort errors first
    dedup: List[Dict[str, str]] = []
    seen = set()
    for f in findings:
        key = (f["code"], f["message"])
        if key not in seen:
            seen.add(key)
            dedup.append(f)
    dedup.sort(key=lambda x: 0 if x["severity"] == "error" else 1)
    return dedup
