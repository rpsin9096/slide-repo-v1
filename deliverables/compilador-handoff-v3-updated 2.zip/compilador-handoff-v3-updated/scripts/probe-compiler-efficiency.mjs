#!/usr/bin/env node
/**
 * FocusGate Wave 12 — Compiler & Cloudflare Worker Efficiency Probe
 *
 * Verifies deterministic performance budgets and 100% geometric parity across:
 *   --gate hotpaths      (gate-8-compiler-hotpaths)
 *   --gate worker-budget (gate-9-worker-isolate-budget)
 *   --gate parity        (gate-10-zero-drift-parity)
 *   --gate all           (runs all 3 gates and prints full telemetry report)
 */

import fs from 'node:fs';
import path from 'node:path';
import { performance } from 'node:perf_hooks';
import { TypographicAutofix, TagSanitizer } from '../src/v2/ingest/sanitizer.js';
import { calculateStringWidth } from '../src/v2/fonts/metrics.js';
import {
  GeometryCompiler,
  parseInlineRuns,
} from '../src/v2/compiler/geometry-compiler.js';
import { createMeasureContext } from '../src/v2/drivers/pdfkit/blaster.js';
import { emitPdf } from '../src/v2/drivers/pdfkit/driver.js';
import { runPipeline } from '../src/v2/runtime/pipeline.js';

const CORPUS_FILES = [
  'tests/corpus/sample1.md',
  'tests/corpus/sample2.md',
  'tests/corpus/sample3.md',
  'tests/corpus/sample4.md',
  'tests/corpus/text-test.md',
  'tests/corpus/sampletext2.md',
];

function loadCorpus() {
  return CORPUS_FILES.map((rel) => ({
    name: path.basename(rel),
    path: rel,
    markdown: fs.readFileSync(rel, 'utf8'),
  }));
}

async function runHotpathsGate(corpus) {
  // 1. Warm up JIT once
  for (const doc of corpus) {
    const clean = TagSanitizer.stripGroundingTags(doc.markdown);
    const fixed = TypographicAutofix.apply(clean, true);
    for (const ln of fixed.split('\n')) {
      if (ln.trim()) parseInlineRuns(ln);
    }
    calculateStringWidth(fixed, 'helvetica', 9.5);
  }

  // 2. Measure TypographicAutofix.apply across all 6 corpus docs (median of 3 passes)
  let autofixMs = Infinity;
  let autofixedDocs = [];
  for (let p = 0; p < 3; p++) {
    const t0 = performance.now();
    autofixedDocs = corpus.map((doc) => {
      const clean = TagSanitizer.stripGroundingTags(doc.markdown);
      return TypographicAutofix.apply(clean, true);
    });
    const dt = performance.now() - t0;
    if (dt < autofixMs) autofixMs = dt;
  }

  // 3. Measure parseInlineRuns across all 6 corpus docs (median of 3 passes)
  let parseRunsMs = Infinity;
  let totalRuns = 0;
  for (let p = 0; p < 3; p++) {
    const t0 = performance.now();
    let runsCount = 0;
    for (const fixed of autofixedDocs) {
      const lines = fixed.split('\n');
      for (let i = 0; i < lines.length; i++) {
        const ln = lines[i].trim();
        if (ln) runsCount += parseInlineRuns(ln).length;
      }
    }
    const dt = performance.now() - t0;
    totalRuns = runsCount;
    if (dt < parseRunsMs) parseRunsMs = dt;
  }

  // 4. Measure calculateStringWidth across all 6 corpus docs (10x pass)
  const tWidth0 = performance.now();
  let widthChecksum = 0;
  for (let iter = 0; iter < 10; iter++) {
    for (const fixed of autofixedDocs) {
      widthChecksum += calculateStringWidth(fixed, 'helvetica', 9.5);
    }
  }
  const calcWidthMs = (performance.now() - tWidth0) / 10;

  // 5. Count measure() invocations during a fresh compile of sample1.md (bypassing DL cache)
  const baseCtx = createMeasureContext('base', null);
  let sample1MeasureCalls = 0;
  const countingMeasure = (w, f, s) => {
    sample1MeasureCalls += 1;
    return baseCtx.measure(w, f, s);
  };
  const gc = new GeometryCompiler();
  const tComp0 = performance.now();
  gc.compile(
    { markdown: corpus[0].markdown, title: 'sample1-count' },
    { geometry: 'v3', measure: countingMeasure, skip_fit_audit: true, bypassCache: true }
  );
  const sample1UncachedCompileMs = performance.now() - tComp0;

  const pass =
    autofixMs <= 12.0 &&
    parseRunsMs <= 10.0 &&
    calcWidthMs <= 1.2 &&
    sample1MeasureCalls <= 6200 &&
    widthChecksum > 0;

  console.log(
    JSON.stringify({
      gate: 'gate-8-compiler-hotpaths',
      pass,
      autofixMs: Number(autofixMs.toFixed(2)),
      parseRunsMs: Number(parseRunsMs.toFixed(2)),
      calcWidthMs: Number(calcWidthMs.toFixed(3)),
      sample1MeasureCalls,
      sample1UncachedCompileMs: Number(sample1UncachedCompileMs.toFixed(2)),
      totalRuns,
    })
  );

  if (!pass) {
    console.error('HOTPATHS_FAIL');
    process.exit(1);
  }
  console.log('HOTPATHS_PASS');
}

async function runWorkerBudgetGate(corpus) {
  // 1. Prime isolate caches across the 6 corpus docs
  for (const doc of corpus) {
    await runPipeline({
      payload: { markdown: doc.markdown, title: doc.name, geometry: 'v3' },
      mode: 'paginate',
      geometry: 'v3',
      options: { skip_fit_audit: true },
    });
  }

  // 2. Measure warm paginate latency across all 6 corpus docs (Cloudflare 10ms budget)
  const tPag0 = performance.now();
  let maxSinglePaginateMs = 0;
  for (const doc of corpus) {
    const t0 = performance.now();
    const res = await runPipeline({
      payload: { markdown: doc.markdown, title: doc.name, geometry: 'v3' },
      mode: 'paginate',
      geometry: 'v3',
      options: { skip_fit_audit: true },
    });
    const dt = performance.now() - t0;
    if (dt > maxSinglePaginateMs) maxSinglePaginateMs = dt;
    if (!res.pagination || res.totalPages < 1) {
      throw new Error(`Invalid pagination for ${doc.name}`);
    }
  }
  const avgWarmPaginateMs = (performance.now() - tPag0) / corpus.length;

  // 3. Measure paginate -> follow-up reuse & incremental 1-section edit on a 4-section document
  const multiSecPayload = {
    title: 'Multi-Section Worker Test',
    template: 'base',
    geometry: 'v3',
    sections: [
      { title: 'Sec 1', markdown: corpus[0].markdown },
      { title: 'Sec 2', markdown: corpus[1].markdown },
      { title: 'Sec 3', markdown: corpus[2].markdown },
      { title: 'Sec 4', markdown: corpus[3].markdown },
    ],
  };

  // Uncached full 4-section compile (populates BLOCK_ITEMS_CACHE, BLOCK_FLOW_CACHE, DISPLAY_LIST_CACHE)
  const tColdMulti0 = performance.now();
  const multiPag = await runPipeline({
    payload: multiSecPayload,
    mode: 'paginate',
    geometry: 'v3',
    options: { skip_fit_audit: true, bypassCache: true },
  });
  const coldMultiPaginateMs = performance.now() - tColdMulti0;

  // Immediate follow-up paginate/convert hit on the same 4-section payload
  const tFollow0 = performance.now();
  await runPipeline({
    payload: multiSecPayload,
    mode: 'paginate',
    geometry: 'v3',
    options: { skip_fit_audit: true },
  });
  const followPaginateHitMs = performance.now() - tFollow0;

  // Incremental edit of only Section 4 (Sections 1..3 hit BLOCK_FLOW_CACHE!)
  const editedMultiPayload = {
    ...multiSecPayload,
    sections: [
      multiSecPayload.sections[0],
      multiSecPayload.sections[1],
      multiSecPayload.sections[2],
      { title: 'Sec 4', markdown: corpus[3].markdown + '\n\nParágrafo adicional editado ao vivo.' },
    ],
  };
  const tInc0 = performance.now();
  const incPag = await runPipeline({
    payload: editedMultiPayload,
    mode: 'paginate',
    geometry: 'v3',
    options: { skip_fit_audit: true },
  });
  const incrementalEditPaginateMs = performance.now() - tInc0;

  const incrementalSpeedup = coldMultiPaginateMs / Math.max(0.1, incrementalEditPaginateMs);

  const pass =
    avgWarmPaginateMs <= 5.0 &&
    maxSinglePaginateMs <= 10.0 &&
    followPaginateHitMs <= 3.0 &&
    incrementalSpeedup >= 1.8 &&
    multiPag.totalPages >= 4 &&
    incPag.totalPages >= 4;

  console.log(
    JSON.stringify({
      gate: 'gate-9-worker-isolate-budget',
      pass,
      avgWarmPaginateMs: Number(avgWarmPaginateMs.toFixed(2)),
      maxSinglePaginateMs: Number(maxSinglePaginateMs.toFixed(2)),
      followPaginateHitMs: Number(followPaginateHitMs.toFixed(2)),
      coldMultiPaginateMs: Number(coldMultiPaginateMs.toFixed(2)),
      incrementalEditPaginateMs: Number(incrementalEditPaginateMs.toFixed(2)),
      incrementalSpeedup: Number(incrementalSpeedup.toFixed(2)),
    })
  );

  if (!pass) {
    console.error('WORKER_BUDGET_FAIL');
    process.exit(1);
  }
  console.log('WORKER_BUDGET_PASS');
}

async function runParityGate(corpus) {
  const gc = new GeometryCompiler();
  const ctx = createMeasureContext('base', null);

  // Warm up JIT (2 passes for V8 TurboFan tier-up) + word measurement cache
  for (let w = 0; w < 2; w++) {
    for (const doc of corpus) {
      gc.compile(
        { markdown: doc.markdown, title: doc.name },
        { geometry: 'v3', measure: ctx.measure, skip_fit_audit: true, bypassCache: true }
      );
    }
  }

  let totalUncachedCompileMs = 0;
  let totalCachedCompileMs = 0;
  let allIdentical = true;

  for (const doc of corpus) {
    let bestUncached = Infinity;
    let dlUncached = null;
    for (let p = 0; p < 2; p++) {
      const t0 = performance.now();
      dlUncached = gc.compile(
        { markdown: doc.markdown, title: doc.name },
        { geometry: 'v3', measure: ctx.measure, skip_fit_audit: true, bypassCache: true }
      );
      const dt = performance.now() - t0;
      if (dt < bestUncached) bestUncached = dt;
    }
    totalUncachedCompileMs += bestUncached;

    const t2 = performance.now();
    const dlCached = gc.compile(
      { markdown: doc.markdown, title: doc.name },
      { geometry: 'v3', measure: ctx.measure, skip_fit_audit: true }
    );
    const t3 = performance.now();
    totalCachedCompileMs += t3 - t2;

    if (
      dlUncached.totalPages !== dlCached.totalPages ||
      dlUncached.metadata.elementCount !== dlCached.metadata.elementCount ||
      JSON.stringify(dlUncached.pagination) !== JSON.stringify(dlCached.pagination) ||
      JSON.stringify(dlUncached.diagnostics.justify) !== JSON.stringify(dlCached.diagnostics.justify)
    ) {
      allIdentical = false;
    }

    const pdfBuf = await emitPdf(
      { markdown: doc.markdown, title: doc.name },
      { geometry: 'v3', template: 'base' }
    );
    if (!pdfBuf || pdfBuf.length < 1000) {
      allIdentical = false;
    }
  }

  const pass =
    allIdentical &&
    totalUncachedCompileMs <= 240.0 &&
    totalCachedCompileMs <= 15.0;

  console.log(
    JSON.stringify({
      gate: 'gate-10-zero-drift-parity',
      pass,
      allIdentical,
      totalUncachedCompileMs: Number(totalUncachedCompileMs.toFixed(2)),
      totalCachedCompileMs: Number(totalCachedCompileMs.toFixed(2)),
    })
  );

  if (!pass) {
    console.error('EFFICIENCY_PARITY_FAIL');
    process.exit(1);
  }
  console.log('EFFICIENCY_PARITY_PASS');
}

const args = process.argv.slice(2);
const gateIdx = args.indexOf('--gate');
const gate = gateIdx >= 0 ? args[gateIdx + 1] : 'all';
const corpus = loadCorpus();

if (gate === 'hotpaths') {
  await runHotpathsGate(corpus);
} else if (gate === 'worker-budget') {
  await runWorkerBudgetGate(corpus);
} else if (gate === 'parity') {
  await runParityGate(corpus);
} else {
  await runHotpathsGate(corpus);
  await runWorkerBudgetGate(corpus);
  await runParityGate(corpus);
}
