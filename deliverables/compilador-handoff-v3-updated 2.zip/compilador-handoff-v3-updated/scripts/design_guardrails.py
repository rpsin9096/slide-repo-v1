#!/usr/bin/env python3
"""Deterministic Design Guardrails v3.0 + FocusGate v1.0 Verifier for compilador-handoff-v3."""

import argparse
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Tuple

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))
import fg_oracles  # type: ignore

ALLOWED_RADII = {0.0, 4.0, 8.0, 12.0, 16.0, 999.0, 9999.0}
ALLOWED_FONT_SIZES = {10.0, 11.0, 12.0, 14.0, 16.0, 18.0, 20.0, 22.0, 24.0, 32.0, 40.0, 48.0}
EXPECTED_DOC_SECTIONS = [
    "visual theme",
    "color palette",
    "typography",
    "components",
    "layout",
    "depth",
    "do's and don'ts",
    "responsive",
    "agent prompt guide",
    "known gaps",
]


def load_config(cfg_path: str) -> Dict:
    p = Path(cfg_path)
    if not p.is_file():
        raise FileNotFoundError(f"Config not found: {cfg_path}")
    return json.loads(p.read_text(encoding="utf-8"))


def strip_css_comments(text: str) -> str:
    return re.sub(r"/\*[\s\S]*?\*/", "", text)


def audit_tokens_gate(target: str, cfg: Dict) -> Tuple[int, List[str]]:
    findings: List[str] = []
    # 1. Run FocusGate strict token oracle
    code, out, err = fg_oracles.audit_tokens(target, strict=True)
    if code != 0:
        findings.extend(out + err)

    # 2. Verify 3-layer token discipline and semantic-only dark mode in design-system.css
    ds_path = Path(target) / "design-system.css" if Path(target).is_dir() else Path(target)
    if ds_path.is_file():
        raw = ds_path.read_text(encoding="utf-8")
        clean = strip_css_comments(raw)
        if 'html[data-theme="dark"]' not in clean:
            findings.append("  [TS-09] Missing html[data-theme=\"dark\"] semantic override block.")
        else:
            m = re.search(r'html\[data-theme="dark"\]\s*\{([^}]*)\}', clean)
            if m:
                dark_body = m.group(1)
                for line in dark_body.splitlines():
                    s = line.strip()
                    if not s or not s.startswith("--"):
                        continue
                    for hm in fg_oracles.HEX_COLOR_RE.finditer(s):
                        findings.append(f"  [TS-01/TS-09] Raw hex '{hm.group(0)}' in dark semantic block: {s}")
                    for rm in fg_oracles.RGB_FUNC_RE.finditer(s):
                        findings.append(f"  [TS-01/TS-09] Raw rgb/rgba '{rm.group(0)}' in dark semantic block: {s}")

        m_light = re.search(r':root,\s*html\[data-theme="light"\]\s*\{([^}]*)\}', clean)
        if m_light:
            light_body = m_light.group(1)
            for line in light_body.splitlines():
                s = line.strip()
                if not s or not s.startswith("--"):
                    continue
                for hm in fg_oracles.HEX_COLOR_RE.finditer(s):
                    findings.append(f"  [TS-01] Raw hex '{hm.group(0)}' in light semantic block: {s}")
                for rm in fg_oracles.RGB_FUNC_RE.finditer(s):
                    findings.append(f"  [TS-01] Raw rgb/rgba '{rm.group(0)}' in light semantic block: {s}")

    if findings:
        return 1, ["[AUDIT_TOKENS_FAIL] Token integrity check failed:"] + findings[:25]
    return 0, ["AUDIT_TOKENS_PASS (layers=3, dark_mode=semantic_only, untokenized_literals=0)"]


def _resolve_tokens(css_text: str) -> Tuple[Dict[str, str], Dict[str, str]]:
    clean = strip_css_comments(css_text)
    primitives: Dict[str, str] = {}
    light: Dict[str, str] = {}
    dark: Dict[str, str] = {}

    # First :root block
    root_blocks = re.findall(r":root\s*\{([^}]*)\}", clean)
    for b in root_blocks:
        for m in re.finditer(r"(--[a-zA-Z0-9_-]+)\s*:\s*([^;]+);", b):
            primitives[m.group(1).strip()] = m.group(2).strip()

    light.update(primitives)
    m_light = re.search(r':root,\s*html\[data-theme="light"\]\s*\{([^}]*)\}', clean)
    if m_light:
        for m in re.finditer(r"(--[a-zA-Z0-9_-]+)\s*:\s*([^;]+);", m_light.group(1)):
            light[m.group(1).strip()] = m.group(2).strip()

    dark.update(light)
    m_dark = re.search(r'html\[data-theme="dark"\]\s*\{([^}]*)\}', clean)
    if m_dark:
        for m in re.finditer(r"(--[a-zA-Z0-9_-]+)\s*:\s*([^;]+);", m_dark.group(1)):
            dark[m.group(1).strip()] = m.group(2).strip()

    def deref(env: Dict[str, str], key: str, depth: int = 0) -> str:
        if depth > 10:
            return env.get(key, "")
        val = env.get(key, "")
        m_var = re.match(r"^var\(\s*(--[a-zA-Z0-9_-]+)\s*\)$", val)
        if m_var:
            return deref(env, m_var.group(1), depth + 1)
        return val

    light_resolved = {k: deref(light, k) for k in light}
    dark_resolved = {k: deref(dark, k) for k in dark}
    return light_resolved, dark_resolved


def audit_contrast_gate(ds_file: str, cfg: Dict) -> Tuple[int, List[str]]:
    p = Path(ds_file)
    if p.is_dir():
        p = p / "design-system.css"
    css_text = p.read_text(encoding="utf-8")
    light, dark = _resolve_tokens(css_text)

    pairs = [
        ("light", light.get("--color-text", ""), light.get("--color-surface", ""), 4.5, "--color-text on --color-surface"),
        ("light", light.get("--color-text-secondary", ""), light.get("--color-surface", ""), 4.5, "--color-text-secondary on --color-surface"),
        ("light", light.get("--color-muted", ""), light.get("--color-surface-2", ""), 4.5, "--color-muted on --color-surface-2"),
        ("light", light.get("--color-muted", ""), light.get("--color-bg", ""), 4.5, "--color-muted on --color-bg (--page)"),
        ("light", light.get("--color-on-primary", ""), light.get("--color-primary", ""), 4.5, "--color-on-primary on --color-primary"),
        ("dark", dark.get("--color-text", ""), dark.get("--color-surface", ""), 4.5, "dark --color-text on --color-surface"),
        ("dark", dark.get("--color-text-secondary", ""), dark.get("--color-surface", ""), 4.5, "dark --color-text-secondary on --color-surface"),
        ("dark", dark.get("--color-muted", ""), dark.get("--color-surface-2", ""), 4.5, "dark --color-muted on --color-surface-2"),
        ("dark", dark.get("--color-muted", ""), dark.get("--color-surface-3", ""), 4.5, "dark --color-muted on --color-surface-3"),
        ("dark", dark.get("--color-accent-text", ""), dark.get("--color-surface", ""), 4.5, "dark --color-accent-text on --color-surface"),
        ("dark", dark.get("--color-on-primary", ""), dark.get("--color-primary", ""), 4.5, "dark --color-on-primary on --color-primary"),
    ]

    failures: List[str] = []
    results: List[str] = []
    for mode, fg, bg, min_r, label in pairs:
        code, out, err = fg_oracles.audit_contrast(fg, bg, min_ratio=min_r)
        msg = (out + err)[0] if (out or err) else ""
        if code != 0:
            failures.append(f"  [{mode}] {label} ({fg} on {bg}) -> {msg}")
        else:
            results.append(f"  [{mode}] {label} -> {msg}")

    if failures:
        return 1, ["[CONTRAST_FAIL_AA] Contrast gate failed:"] + failures
    return 0, ["CONTRAST_PASS_AA (all 11 light/dark semantic pairs >= 4.5:1)"] + results


def audit_layout_gate(target: str, base: int, cfg: Dict) -> Tuple[int, List[str]]:
    findings: List[str] = []
    tpath = Path(target)
    css_files = [tpath / "design-system.css", tpath / "shell.css"] if tpath.is_dir() else [tpath]

    spacing_props = re.compile(
        r"\b(padding(?:-(?:top|right|bottom|left|inline|block))?|margin(?:-(?:top|right|bottom|left|inline|block))?|gap|row-gap|column-gap|min-height|min-width)\s*:\s*([^;]+);",
        re.IGNORECASE,
    )
    for fpath in css_files:
        if not fpath.is_file():
            continue
        lines = fpath.read_text(encoding="utf-8").splitlines()
        in_comment = False
        for lineno, line in enumerate(lines, 1):
            s = line.strip()
            if "/*" in s and "*/" not in s:
                in_comment = True
            if in_comment:
                if "*/" in s:
                    in_comment = False
                continue
            s_no_comment = re.sub(r"/\*.*?\*/", "", s)
            # Check spacing token declarations in :root
            if s_no_comment.startswith("--space-"):
                for m in re.finditer(r"(?<![0-9.])(\d+(?:\.\d+)?)px\b", s_no_comment):
                    val = float(m.group(1))
                    if val not in (0.0, 1.0, 2.0) and val % base != 0:
                        findings.append(f"  [AL-01] {fpath.name}:{lineno} off-grid spacing token ({val}px, base={base}px): {s_no_comment}")
            for pm in spacing_props.finditer(s_no_comment):
                val_str = pm.group(2)
                for m in re.finditer(r"(?<![0-9.])(\d+(?:\.\d+)?)px\b", val_str):
                    val = float(m.group(1))
                    if val in (0.0, 0.5, 1.0, 2.0):
                        continue
                    if val % base != 0:
                        findings.append(f"  [AL-01] {fpath.name}:{lineno} off-grid {pm.group(1)} ({val}px, base={base}px): {s_no_comment}")

    # Also check shell.css control dimensions (width/height on .ticon, .brand-mark, #toggle-settings-pane)
    sh_path = tpath / "shell.css" if tpath.is_dir() else tpath
    if sh_path.is_file():
        for lineno, line in enumerate(sh_path.read_text(encoding="utf-8").splitlines(), 1):
            s = re.sub(r"/\*.*?\*/", "", line.strip())
            if any(sel in s for sel in [".ticon", ".brand-mark", "#toggle-settings-pane", ".m-bubble"]):
                for m in re.finditer(r"\b(?:width|height)\s*:\s*(\d+(?:\.\d+)?)px\b", s):
                    val = float(m.group(1))
                    if val % base != 0:
                        findings.append(f"  [AL-01] shell.css:{lineno} off-grid control size ({val}px, base={base}px): {s}")

    # Safe zone check
    sz_code, sz_out, sz_err = fg_oracles.audit_safe_zone("1920x1080", ["288,162,1344,756"], "landscape-16x9")
    if sz_code != 0:
        findings.extend(sz_out + sz_err)

    if findings:
        return 1, ["[LAYOUT_FAIL] Layout & 4px grid check failed:"] + findings[:25]
    return 0, [f"LAYOUT_PASS (SPACING_PASS base={base}px, off_grid=0, SAFE_ZONE_PASS)"]


def audit_type_gate(target: str, cfg: Dict) -> Tuple[int, List[str]]:
    findings: List[str] = []
    tpath = Path(target)
    ds_text = strip_css_comments((tpath / "design-system.css").read_text(encoding="utf-8"))
    sh_lines = (tpath / "shell.css").read_text(encoding="utf-8").splitlines()

    if "text-wrap: balance" not in ds_text and "text-wrap: balance" not in "\n".join(sh_lines):
        findings.append("  [TY-08] Missing 'text-wrap: balance' on headings (Design Guardrails §4).")
    if "text-wrap: pretty" not in ds_text and "text-wrap: pretty" not in "\n".join(sh_lines):
        findings.append("  [TY-09] Missing 'text-wrap: pretty' on body/empty-state paragraphs (Design Guardrails §4).")

    for lineno, line in enumerate(sh_lines, 1):
        s = re.sub(r"/\*.*?\*/", "", line.strip())
        for m in re.finditer(r"font-size\s*:\s*(\d+(?:\.\d+)?)px\b", s):
            val = float(m.group(1))
            if val not in ALLOWED_FONT_SIZES:
                findings.append(f"  [TY-05] shell.css:{lineno} off-scale font-size ({val}px): {s}")

    if "tabular-nums" not in ds_text:
        findings.append("  [TY-10] Missing font-variant-numeric: tabular-nums.")

    if findings:
        return 1, ["[TYPE_FAIL] Typography check failed:"] + findings
    return 0, ["TYPE_PASS (families=2, scale=closed, text_wrap=balance+pretty, tabular_nums=true)"]


def audit_states_gate(target: str, cfg: Dict) -> Tuple[int, List[str]]:
    findings: List[str] = []
    tpath = Path(target)
    ds_path = tpath / "design-system.css"
    sh_path = tpath / "shell.css"
    ds_text = strip_css_comments(ds_path.read_text(encoding="utf-8"))
    sh_text = strip_css_comments(sh_path.read_text(encoding="utf-8"))
    combined = ds_text + "\n" + sh_text

    if "@media (hover: hover)" not in combined and "@media(hover:hover)" not in combined:
        findings.append("  [CA-10] Missing '@media (hover: hover)' pointer guard for hover states (Design Guardrails §6).")
    if ".ticon:active" not in combined:
        findings.append("  [CA-10] Missing '.ticon:active' pressed state in shell.css.")
    if ".ticon:disabled" not in combined:
        findings.append("  [CA-10/CA-12] Missing '.ticon:disabled' state in shell.css.")

    # Check disabled state uses surface + muted text + cursor: not-allowed, not opacity alone
    m_dis = re.search(r"\.md-insert-bar button:disabled[^{]*\{([^}]*)\}", sh_text)
    if m_dis:
        body = m_dis.group(1)
        if "color:" not in body or "background:" not in body:
            findings.append("  [CA-12] Disabled state on .md-insert-bar button:disabled uses opacity alone; must declare muted surface + muted text + cursor: not-allowed.")

    # Check radius values in shell.css and design-system.css against closed 4px-aligned radius set
    for fpath in [ds_path, sh_path]:
        for lineno, line in enumerate(fpath.read_text(encoding="utf-8").splitlines(), 1):
            s = re.sub(r"/\*.*?\*/", "", line.strip())
            if not s:
                continue
            for rm in re.finditer(r"(?:border-radius|--radius(?:-[a-z0-9]+)?)\s*:\s*([^;]+);", s):
                for m in re.finditer(r"(?<![0-9.])(\d+(?:\.\d+)?)px\b", rm.group(1)):
                    val = float(m.group(1))
                    if val not in ALLOWED_RADII:
                        findings.append(f"  [TS-10/ES-06] {fpath.name}:{lineno} off-step radius ({val}px not in {sorted(ALLOWED_RADII)}): {s}")

    if findings:
        return 1, ["[STATES_FAIL] Interactive states & shape check failed:"] + findings[:25]
    return 0, ["STATES_PASS (RADIUS_PASS, SHADOW_PASS, 5_state_matrix=complete, hover_media_guarded=true)"]


def audit_responsive_gate(target: str, doc_file: str, cfg: Dict) -> Tuple[int, List[str]]:
    findings: List[str] = []
    tpath = Path(target)
    sh_text = strip_css_comments((tpath / "shell.css").read_text(encoding="utf-8"))
    ds_text = strip_css_comments((tpath / "design-system.css").read_text(encoding="utf-8"))

    if "100dvh" not in sh_text and "100dvh" not in ds_text:
        findings.append("  [RS-10] Missing '100dvh' dynamic viewport unit in responsive layout (Design Guardrails §7).")
    if "prefers-reduced-motion: reduce" not in sh_text and "prefers-reduced-motion: reduce" not in ds_text:
        findings.append("  [MX-01] Missing '@media (prefers-reduced-motion: reduce)' rule.")

    doc_path = Path(doc_file)
    if not doc_path.is_file():
        findings.append(f"  [CD-02] Design specification document '{doc_file}' does not exist.")
    else:
        doc_text = doc_path.read_text(encoding="utf-8")
        headings = [m.group(1).strip().lower() for m in re.finditer(r"^##\s+(.+)$", doc_text, re.MULTILINE)]
        if len(headings) < 10:
            findings.append(f"  [CD-02] DESIGN.md has {len(headings)} sections; expected all 10 ordered sections (Design Guardrails §13).")
        else:
            for idx, expected in enumerate(EXPECTED_DOC_SECTIONS):
                if expected not in headings[idx]:
                    findings.append(f"  [CD-02] Section {idx + 1} '{headings[idx]}' does not match expected '{expected}'.")
        p_code, p_out, p_err = fg_oracles.audit_prose_cliche(str(doc_path))
        if p_code != 0:
            findings.extend(p_out + p_err)
        ph_code, ph_out, ph_err = fg_oracles.check_placeholders(str(doc_path))
        if ph_code != 0:
            findings.extend(ph_out + ph_err)

    dc_code, dc_out, dc_err = fg_oracles.audit_design_cliche(str(tpath))
    if dc_code != 0:
        findings.extend(dc_out + dc_err)

    if findings:
        return 1, ["[RESPONSIVE_FAIL] Responsive & DESIGN.md gate failed:"] + findings
    return 0, ["RESPONSIVE_PASS (DOCUMENT_PASS, PROSE_AUDIT_PASS, DESIGN_AUDIT_PASS, dvh=true)"]


def main() -> int:
    ap = argparse.ArgumentParser(description="Design Guardrails v3.0 + FocusGate v1.0 Verifier")
    ap.add_argument("--config", default="design-guardrails.config.json")
    ap.add_argument("--base", type=int, default=4)
    ap.add_argument("--document", default="DESIGN.md")
    ap.add_argument("--audit-tokens")
    ap.add_argument("--audit-contrast")
    ap.add_argument("--audit-layout")
    ap.add_argument("--audit-type")
    ap.add_argument("--audit-states")
    ap.add_argument("--audit-responsive")
    ap.add_argument("--audit-all")
    args = ap.parse_args()

    cfg = load_config(args.config)
    base = int(cfg.get("archetype", {}).get("spacing_base", args.base))

    if args.audit_tokens:
        code, lines = audit_tokens_gate(args.audit_tokens, cfg)
        print("\n".join(lines))
        return code
    if args.audit_contrast:
        code, lines = audit_contrast_gate(args.audit_contrast, cfg)
        print("\n".join(lines))
        return code
    if args.audit_layout:
        code, lines = audit_layout_gate(args.audit_layout, base, cfg)
        print("\n".join(lines))
        return code
    if args.audit_type:
        code, lines = audit_type_gate(args.audit_type, cfg)
        print("\n".join(lines))
        return code
    if args.audit_states:
        code, lines = audit_states_gate(args.audit_states, cfg)
        print("\n".join(lines))
        return code
    if args.audit_responsive:
        code, lines = audit_responsive_gate(args.audit_responsive, args.document, cfg)
        print("\n".join(lines))
        return code
    if args.audit_all:
        target = args.audit_all
        all_lines: List[str] = []
        for fn in [
            lambda: audit_tokens_gate(target, cfg),
            lambda: audit_contrast_gate(target, cfg),
            lambda: audit_layout_gate(target, base, cfg),
            lambda: audit_type_gate(target, cfg),
            lambda: audit_states_gate(target, cfg),
            lambda: audit_responsive_gate(target, args.document, cfg),
        ]:
            c, lns = fn()
            all_lines.extend(lns)
            if c != 0:
                print("\n".join(all_lines))
                print("AUDIT_ALL_FAIL")
                return 1
        cc_code, cc_out, cc_err = fg_oracles.audit_code_cliche(target)
        all_lines.extend(cc_out + cc_err)
        if cc_code != 0:
            print("\n".join(all_lines))
            print("AUDIT_ALL_FAIL")
            return 1
        print("\n".join(all_lines))
        print("AUDIT_ALL_PASS (all 6 design gates + code rigor clean)")
        return 0

    ap.print_help()
    return 2


if __name__ == "__main__":
    sys.exit(main())
