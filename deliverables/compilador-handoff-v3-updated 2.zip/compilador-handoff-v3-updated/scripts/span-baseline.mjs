import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { runPipeline } from '../src/v2/runtime/pipeline.js';
import { readCorpus } from '../tests/corpus/index.js';

const here = dirname(fileURLToPath(import.meta.url));
const repo = join(here, '..');
const SEED = 'span-baseline';
const TIMESTAMP = 1700000000000;
const NAMES = ['sample1.md', 'sample2.md', 'sample3.md', 'text-test.md'];

const docOf = (markdown) => ({
  title: 'Baseline',
  template: 'base',
  blocks: [{ title: 'A', markdown, masthead: { enabled: false }, flags: { autofix: true, optimize_tables: true, split_equations: true }, columns: null }],
});

const pick = (d) => ({
  totalPages: d.totalPages,
  diagnostics: {
    tableSlices: d.diagnostics.tableSlices ?? null,
    panoramicTransitions: d.diagnostics.panoramicTransitions ?? null,
    overfullColumns: d.diagnostics.overfullColumns ?? null,
    keepWithNextBreaks: d.diagnostics.keepWithNextBreaks ?? null,
    orphanSuppressions: d.diagnostics.orphanSuppressions ?? null,
    widowSuppressions: d.diagnostics.widowSuppressions ?? null,
  },
});

const out = { generatedAt: new Date(TIMESTAMP).toISOString(), seed: SEED, timestamp: TIMESTAMP, template: 'base', fixtures: {} };
for (const name of NAMES) {
  const markdown = readCorpus(name);
  const { displayList } = await runPipeline({ payload: docOf(markdown), mode: 'paginate', seed: SEED, timestamp: TIMESTAMP });
  out.fixtures[name] = pick(displayList);
}
mkdirSync(join(repo, 'tests', 'fixtures'), { recursive: true });
writeFileSync(join(repo, 'tests', 'fixtures', 'span-baseline.json'), JSON.stringify(out, null, 2) + '\n');
console.log(JSON.stringify(out, null, 2));
