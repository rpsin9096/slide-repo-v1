// Shared positioned-text decoder for PDFs (PDFKit + Typst output).
// Importable with zero side effects: decodePdfRuns(buf) -> [{ W, H, runs }].
// Handles FlateDecode streams, CTM (cm) tracking, q/Q graphics-state font
// restore, ToUnicode CMaps (hex + octal-escape literal strings, 1/2-byte
// CIDs, surrogate guards). Ported from the battle-tested measure script.
import zlib from 'node:zlib';

function getObjects(raw) {
  const objects = new Map();
  for (const m of raw.matchAll(/(\d+)\s+(\d+)\s+obj\b([\s\S]*?)endobj/g)) objects.set(`${m[1]} ${m[2]}`, m[3]);
  return objects;
}

function inflate(body) {
  const si = body.indexOf('stream');
  if (si === -1) return null;
  let st = si + 6;
  while (body[st] === '\r' || body[st] === '\n') st++;
  let d = Buffer.from(body.slice(st, body.indexOf('endstream', st)), 'latin1');
  if (/\/FlateDecode/.test(body.slice(0, si))) { try { d = zlib.inflateSync(d); } catch { return null; } }
  return d;
}

function parseCmap(buf) {
  const s = buf.toString('latin1');
  const mp = new Map();
  for (const m of s.matchAll(/<([0-9A-Fa-f]+)>\s+<([0-9A-Fa-f]+)>\s*\[([0-9A-Fa-f\s<>]+)\]/g)) {
    const lo = parseInt(m[1], 16);
    [...m[3].matchAll(/<([0-9A-Fa-f]+)>/g)].forEach((x, i) =>
      mp.set((lo + i).toString(16).toUpperCase().padStart(m[1].length, '0'), x[1].toUpperCase()));
  }
  for (const m of s.matchAll(/<([0-9A-Fa-f]+)>\s+<([0-9A-Fa-f]+)>/g)) {
    if (mp.has(m[1].toUpperCase())) continue;
    mp.set(m[1].toUpperCase(), m[2].toUpperCase());
  }
  return mp;
}

function decodeStr(raw2, cm) {
  const wide = !cm || [...cm.keys()].some((k) => k.length >= 4);
  const unit = wide ? 4 : 2;
  const bytes = [];
  if (raw2.startsWith('<')) {
    const hex = raw2.slice(1, raw2.indexOf('>')).replace(/\s/g, '');
    for (let i = 0; i + unit <= hex.length; i += unit) bytes.push(hex.slice(i, i + unit).toUpperCase());
  } else {
    const inner = raw2.slice(1, -1)
      .replace(/\\([0-7]{1,3})/g, (_, o) => String.fromCharCode(parseInt(o, 8)))
      .replace(/\\n/g, '\n').replace(/\\r/g, '\r').replace(/\\t/g, '\t')
      .replace(/\\b/g, '\b').replace(/\\f/g, '\f')
      .replace(/\\([()\\])/g, '$1');
    const buf = Buffer.from(inner, 'latin1');
    const step = wide ? 2 : 1;
    for (let i = 0; i + step <= buf.length; i += step) {
      bytes.push((wide ? buf.readUInt16BE(i).toString(16) : buf[i].toString(16)).toUpperCase().padStart(unit, '0'));
    }
  }
  return bytes.map((h) => {
    const uni = cm?.get(h) ?? cm?.get(h.padStart(4, '0'));
    const cp = uni ? parseInt(uni, 16) : NaN;
    if (!Number.isSafeInteger(cp) || cp < 0 || cp > 0x10FFFF) return '';
    if (cp >= 0xD800 && cp <= 0xDFFF) return '';
    return String.fromCodePoint(cp);
  }).join('');
}

export function decodePdfRuns(buf) {
  const raw = buf.toString('latin1');
  const objects = getObjects(raw);
  const streamBufs = new Map();
  for (const [key, body] of objects) {
    const d = inflate(body);
    if (d) streamBufs.set(key, d);
  }
  const cmaps = new Map();
  for (const [k, b] of objects) {
    const tu = b.match(/\/ToUnicode\s+(\d+)\s+(\d+)\s+R/);
    if (tu && /\/Type\s*\/Font/.test(b)) {
      const d = streamBufs.get(`${tu[1]} ${tu[2]}`);
      if (d) cmaps.set(k, parseCmap(d));
    }
  }
  const pagesBody = [...objects.values()].find((b) => /\/Type\s*\/Pages/.test(b)) ?? '';
  const kids = [...pagesBody.matchAll(/(\d+)\s+(\d+)\s+R/g)].map((m) => `${m[1]} ${m[2]}`);
  const pageKeys = kids.filter((k) => /\/Type\s*\/Page[^s]/.test(objects.get(k) ?? ''));
  const NUM = '-?[\\d.]+(?:[eE][-+]?\\d+)?';
  return pageKeys.map((pk) => {
    const pb = objects.get(pk) ?? '';
    const mb = pb.match(/\/MediaBox\s*\[\s*([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s*\]/);
    const W = mb ? +mb[3] - +mb[1] : 595;
    const H = mb ? +mb[4] - +mb[2] : 842;
    const refs = [...pb.matchAll(/\/Contents\s*(?:\[\s*([^\]]*?)\s*\]|(\d+)\s+(\d+)\s+R)/g)];
    const streamKeys = [];
    for (const r of refs) {
      if (r[1]) for (const m of r[1].matchAll(/(\d+)\s+(\d+)\s+R/g)) streamKeys.push(`${m[1]} ${m[2]}`);
      else if (r[2]) streamKeys.push(`${r[2]} ${r[3]}`);
    }
    const rr = pb.match(/\/Resources\s+(\d+)\s+(\d+)\s+R/);
    let rb = rr ? objects.get(`${rr[1]} ${rr[2]}`) : pb;
    if (rb && rb.includes('stream')) {
      const inflated = inflate(rb);
      if (inflated) rb = inflated.toString('latin1');
    }
    const pageFonts = new Map();
    const fs2 = (rb || '').match(/\/Font\s*<<([^>]*)>>/);
    if (fs2) for (const m of fs2[1].matchAll(/\/(F\d+)\s+(\d+)\s+(\d+)\s+R/g)) pageFonts.set(m[1], `${m[2]} ${m[3]}`);
    const runs = [];
    for (const sk of streamKeys) {
      const d = streamBufs.get(sk);
      if (!d) continue;
      const s = d.toString('latin1');
      let ctm = [1, 0, 0, 1, 0, 0];
      const stack = [];
      const mul = (m1, m2) => [
        m1[0] * m2[0] + m1[2] * m2[1], m1[1] * m2[0] + m1[3] * m2[1],
        m1[0] * m2[2] + m1[2] * m2[3], m1[1] * m2[2] + m1[3] * m2[3],
        m1[0] * m2[4] + m1[2] * m2[5] + m1[4], m1[1] * m2[4] + m1[3] * m2[5] + m1[5],
      ];
      let cx = null, cy = null, cfont = null;
      const tok = new RegExp(
        `(${NUM})\\s+(${NUM})\\s+(${NUM})\\s+(${NUM})\\s+(${NUM})\\s+(${NUM})\\s+Tm` +
        `|(${NUM})\\s+(${NUM})\\s+(${NUM})\\s+(${NUM})\\s+(${NUM})\\s+(${NUM})\\s+cm` +
        `|\\bq\\b|\\bQ\\b|\\bET\\b|\\/(F\\d+)\\s+${NUM}\\s+Tf` +
        `|<[0-9A-Fa-f\\s]+>\\s*Tj|\\[[^\\]]*\\]\\s*TJ|\\((?:[^()\\\\]|\\\\.)*\\)\\s*Tj`,
        'g');
      for (const m of s.matchAll(tok)) {
        const op = m[0];
        if (op === 'q') { stack.push({ ctm, cfont }); continue; }
        if (op === 'Q') {
          const st8 = stack.pop();
          ctm = st8?.ctm ?? [1, 0, 0, 1, 0, 0];
          cfont = st8?.cfont ?? cfont;
          continue;
        }
        if (op === 'ET') { cx = null; cy = null; continue; }
        const fnt = op.match(/^\/(F\d+)/);
        if (fnt) { cfont = fnt[1]; continue; }
        const v = (m[7] !== undefined ? m.slice(7, 13) : m.slice(1, 7)).map(Number);
        if (op.endsWith('cm')) { ctm = mul(ctm, v); continue; }
        if (/Tm$/.test(op)) {
          const [a, b, c, dd, e, f] = ctm;
          cx = a * v[4] + c * v[5] + e;
          cy = b * v[4] + dd * v[5] + f;
          continue;
        }
        if (cx === null || cy === null) continue;
        const cm = cmaps.get(pageFonts.get(cfont));
        let text = '';
        if (op.endsWith('Tj')) {
          const sm = op.match(/^(<[^>]*>|\((?:[^()\\]|\\.)*\))/)?.[1] ?? '';
          if (sm) text = decodeStr(sm, cm);
        } else {
          for (const hm of op.matchAll(/<([0-9A-Fa-f\s]+)>|\((?:[^()\\]|\\.)*\)/g)) {
            text += decodeStr(hm[0].startsWith('<') ? `<${hm[1]}>` : hm[0], cm);
          }
        }
        if (text) runs.push({ x: cx, y: cy, text });
      }
    }
    return { W, H, runs };
  });
}
