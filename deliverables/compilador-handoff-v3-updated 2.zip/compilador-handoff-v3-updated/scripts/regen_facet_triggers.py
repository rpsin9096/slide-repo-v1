import argparse
import json
import os
import re
import sys
from typing import Dict, List


def _parse_list(val: str) -> List[str]:
    val = val.strip()
    if not (val.startswith("[") and val.endswith("]")):
        return []
    try:
        return json.loads(val)
    except json.JSONDecodeError:
        return [x.strip().strip("\"'") for x in val[1:-1].split(",") if x.strip()]


def extract_facets(root_dir: str) -> List[Dict[str, object]]:
    facets_dir = os.path.join(root_dir, "facets")
    entries: List[Dict[str, object]] = []
    for sub in sorted(os.listdir(facets_dir)):
        sub_path = os.path.join(facets_dir, sub)
        if not os.path.isdir(sub_path):
            continue
        for fname in sorted(os.listdir(sub_path)):
            if not fname.endswith(".md"):
                continue
            fpath = os.path.join(sub_path, fname)
            text = open(fpath, "r", encoding="utf-8").read()
            m = re.search(r"```facet-meta\n(.*?)\n```", text, re.S)
            if not m:
                continue
            meta_block = m.group(1)
            meta: Dict[str, object] = {"context": sub, "file": f"facets/{sub}/{fname}"}
            for line in meta_block.splitlines():
                if ":" not in line or line.startswith(" "):
                    continue
                k, v = line.split(":", 1)
                k, v = k.strip(), v.strip()
                if k in {"applies_when", "never_when", "oracle"}:
                    meta[k] = _parse_list(v)
                elif k in {"priority", "schema"}:
                    meta[k] = int(v)
                else:
                    meta[k] = v.strip("\"'")
            entries.append(meta)
    entries.sort(key=lambda x: (-int(x.get("priority", 0)), str(x.get("id", ""))))  # type: ignore[arg-type]
    return entries


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    ap.add_argument("--check", action="store_true")
    args = ap.parse_args()

    entries = extract_facets(args.root)
    total_triggers = sum(len(e.get("applies_when", [])) for e in entries)  # type: ignore[arg-type]
    index_path = os.path.join(args.root, "facets", "facet_index.json")
    payload = {"schema": 1, "version": "1.0.0", "total_triggers": total_triggers, "facets": entries}

    if args.check:
        if not os.path.isfile(index_path):
            print("[FACET_INDEX_FAIL] facet_index.json is missing", file=sys.stderr)
            return 1
        cur = json.load(open(index_path, "r", encoding="utf-8"))
        if cur.get("facets") != entries:
            print("[FACET_INDEX_FAIL] facet_index.json is out of sync with facets/*/*.md", file=sys.stderr)
            return 1
        print(f"[FACET_INDEX_PASS] 0 trigger(s) missing from the index (total {total_triggers})")
        return 0

    open(index_path, "w", encoding="utf-8").write(json.dumps(payload, indent=2) + "\n")
    print(f"[FACET_INDEX] compiled {len(entries)} facet(s); total {total_triggers} trigger(s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
