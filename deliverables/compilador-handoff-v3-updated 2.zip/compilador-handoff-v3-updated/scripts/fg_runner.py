import hashlib
import os
import re
import signal
import subprocess
import threading
import time
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

SAFE_ENV = {
    "CI": "1",
    "NO_COLOR": "1",
    "TERM": "dumb",
    "PAGER": "cat",
    "GIT_PAGER": "cat",
    "GIT_TERMINAL_PROMPT": "0",
    "PYTHONUNBUFFERED": "1",
}

ANSI_RE = re.compile(r"\x1b(?:\[[0-9;?]*[A-Za-z]|\][^\x07]*(?:\x07|\x1b\\)|[@-Z\\-_])")
VALID_EXPECT_EXIT_RE = re.compile(r"^(?:0|-?[1-9]\d*|nonzero|any)$")


@dataclass
class RunResult:
    command: str
    exit_code: int
    signal: Optional[int]
    timed_out: bool
    truncated: bool
    duration_ms: int
    stdout: str
    stderr: str
    timeout_s: int = 60
    max_output: int = 262144


@dataclass
class EvalResult:
    verdict: str  # PASS, FAIL, ERROR
    reasons: List[str] = field(default_factory=list)
    human_reasons: List[str] = field(default_factory=list)


def normalize_output(raw_text: str) -> str:
    if not raw_text:
        return ""
    cleaned = ANSI_RE.sub("", raw_text)
    cleaned = cleaned.replace("\r\n", "\n")
    out_lines: List[str] = []
    for line in cleaned.split("\n"):
        if "\r" in line:
            parts = line.split("\r")
            buf = ""
            for part in parts:
                if part == "":
                    continue
                buf = part
            line = buf
        out_lines.append(line.rstrip(" \t"))
    return "\n".join(out_lines)


def _read_stream_capped(stream, max_bytes: int, sink: List):
    head_budget = max_bytes // 2
    tail_budget = max_bytes - head_budget
    head_chunks: List[bytes] = []
    head_len = 0
    tail_buf = bytearray()
    total_len = 0
    try:
        while True:
            chunk = stream.read(16384)
            if not chunk:
                break
            total_len += len(chunk)
            if head_len < head_budget:
                take = min(len(chunk), head_budget - head_len)
                head_chunks.append(chunk[:take])
                head_len += take
                rem = chunk[take:]
            else:
                rem = chunk
            if rem:
                tail_buf.extend(rem)
                if len(tail_buf) > tail_budget:
                    del tail_buf[: len(tail_buf) - tail_budget]
    finally:
        try:
            stream.close()
        except OSError:
            return
    head_bytes = b"".join(head_chunks)
    if total_len <= max_bytes:
        full_bytes = head_bytes + bytes(tail_buf)
        sink.append((full_bytes.decode("utf-8", errors="replace"), False))
    else:
        marker = f"\n...[truncated: total {total_len} bytes, kept {max_bytes}]...\n".encode("utf-8")
        combined = head_bytes + marker + bytes(tail_buf)
        sink.append((combined.decode("utf-8", errors="replace"), True))


def _kill_process_group(pgid: int) -> None:
    try:
        os.killpg(pgid, signal.SIGTERM)
    except ProcessLookupError:
        return
    except PermissionError:
        return
    for _ in range(20):
        time.sleep(0.01)
        try:
            os.killpg(pgid, 0)
        except ProcessLookupError:
            return
        except PermissionError:
            break
    try:
        os.killpg(pgid, signal.SIGKILL)
    except (ProcessLookupError, PermissionError):
        return


def run_command(
    command: str,
    timeout_s: int = 60,
    cwd: Optional[str] = None,
    max_output: int = 262144,
) -> RunResult:
    if os.name != "posix":
        raise RuntimeError("run_command requires a POSIX platform")
    timeout_clamped = max(1, min(int(timeout_s), 600))
    max_bytes = max(1024, int(max_output))
    env = os.environ.copy()
    env.update(SAFE_ENV)

    t0 = time.monotonic()
    proc = subprocess.Popen(
        ["/bin/sh", "-c", command],
        cwd=cwd,
        env=env,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        start_new_session=True,
    )
    out_sink: List[Tuple[str, bool]] = []
    err_sink: List[Tuple[str, bool]] = []
    t_out = threading.Thread(target=_read_stream_capped, args=(proc.stdout, max_bytes, out_sink), daemon=True)
    t_err = threading.Thread(target=_read_stream_capped, args=(proc.stderr, max_bytes, err_sink), daemon=True)
    t_out.start()
    t_err.start()

    timed_out = False
    try:
        proc.wait(timeout=timeout_clamped)
    except subprocess.TimeoutExpired:
        timed_out = True
        _kill_process_group(proc.pid)
        try:
            proc.wait(timeout=1.0)
        except subprocess.TimeoutExpired:
            _ = None

    t_out.join(timeout=2.0)
    t_err.join(timeout=2.0)
    elapsed_ms = int((time.monotonic() - t0) * 1000)

    stdout_text, out_trunc = out_sink[0] if out_sink else ("", False)
    stderr_text, err_trunc = err_sink[0] if err_sink else ("", False)
    truncated = out_trunc or err_trunc

    if timed_out:
        exit_code = 124
        sig_num = None
    else:
        rc = proc.returncode if proc.returncode is not None else 1
        if rc < 0:
            sig_num = -rc
            exit_code = 128 + sig_num
        else:
            sig_num = None
            exit_code = rc

    return RunResult(
        command=command,
        exit_code=exit_code,
        signal=sig_num,
        timed_out=timed_out,
        truncated=truncated,
        duration_ms=elapsed_ms,
        stdout=stdout_text,
        stderr=stderr_text,
        timeout_s=timeout_clamped,
        max_output=max_bytes,
    )


def evaluate(
    res: RunResult,
    expect: Optional[str] = None,
    expect_exit: str = "0",
    expect_not: Optional[str] = None,
    enforce_rigor: bool = False,
) -> EvalResult:
    ee = str(expect_exit).strip()
    if not VALID_EXPECT_EXIT_RE.match(ee):
        msg = f"Invalid expect_exit '{ee}'; use 0, an integer, nonzero, or any"
        return EvalResult(verdict="ERROR", reasons=[f"BAD_EXPECT_EXIT: {msg}"], human_reasons=[msg])

    re_expect = None
    if expect is not None:
        try:
            re_expect = re.compile(expect, re.MULTILINE)
        except re.error as exc:
            msg = f"BAD_REGEX: {exc}"
            return EvalResult(verdict="ERROR", reasons=[msg], human_reasons=[msg])

    re_expect_not = None
    if expect_not is not None:
        try:
            re_expect_not = re.compile(expect_not, re.MULTILINE)
        except re.error as exc:
            msg = f"BAD_REGEX: {exc}"
            return EvalResult(verdict="ERROR", reasons=[msg], human_reasons=[msg])

    if res.timed_out:
        return EvalResult(
            verdict="FAIL",
            reasons=["TIMEOUT"],
            human_reasons=[f"Command timed out after {res.timeout_s}s"],
        )

    reasons: List[str] = []
    human_reasons: List[str] = []

    if ee == "0":
        if res.exit_code != 0:
            reasons.append(f"EXIT_MISMATCH: expected 0, got {res.exit_code}")
            human_reasons.append(f"Command exited with code {res.exit_code}")
    elif ee == "nonzero":
        if res.exit_code == 0:
            reasons.append("EXIT_MISMATCH: expected nonzero, got 0")
            human_reasons.append("Exit code 0, expected nonzero")
    elif ee == "any":
        pass
    else:
        target_code = int(ee)
        if res.exit_code != target_code:
            reasons.append(f"EXIT_MISMATCH: expected {target_code}, got {res.exit_code}")
            human_reasons.append(f"Exit code {res.exit_code}, expected {target_code}")

    norm_out = normalize_output(res.stdout)
    norm_err = normalize_output(res.stderr)
    combined = norm_out + ("\n" + norm_err if norm_err else "")

    if re_expect is not None and not re_expect.search(combined):
        reasons.append(f"EXPECT_NOT_FOUND: {expect}")
        human_reasons.append(f"Output did not match EXPECT pattern: '{expect}'")

    if re_expect_not is not None and re_expect_not.search(combined):
        reasons.append(f"EXPECT_NOT_VIOLATED: {expect_not}")
        human_reasons.append(f"Output matched forbidden EXPECT_NOT pattern: '{expect_not}'")

    if enforce_rigor and not reasons and ee == "0":
        if re.search(r"\b0+\s+passed\b", combined, re.I) and not re.search(r"\b[1-9]\d*\s+passed\b", combined, re.I):
            reasons.append("EMPTY_TEST_SUITE: 0 passed")
            human_reasons.append("Output triggered EMPTY_TEST_SUITE rigor rule (0 passed)")
        elif re.search(r"\ball\s+tests\s+skipped\b|\bno\s+tests\s+ran\b", combined, re.I):
            reasons.append("SKIPPED_SUITE: no tests ran")
            human_reasons.append("Output triggered SKIPPED_SUITE rigor rule (no tests ran)")

    return EvalResult(
        verdict="PASS" if not reasons else "FAIL",
        reasons=reasons,
        human_reasons=human_reasons,
    )


def evidence_hash(gate_id: str, command: str, exit_code: int, stdout_text: str, stderr_text: str) -> str:
    norm_out = normalize_output(stdout_text)
    norm_err = normalize_output(stderr_text)
    combined = (norm_out + "\n" + norm_err).splitlines()
    norm_combined = "\n".join(line.rstrip(" \t") for line in combined).rstrip("\n")
    payload = f"{gate_id}\n{command}\n{exit_code}\n{norm_combined}".encode("utf-8")
    return hashlib.sha256(payload).hexdigest()