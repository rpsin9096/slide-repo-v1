#!/usr/bin/env python3
"""FocusGate 1.0.0 (Unified Epoch) — Command, Tool-Call & Epistemic Verification Engine."""

import argparse
import json
import os
import signal
import sys
from typing import Dict, List, Optional

VERSION = "1.0.0"
VERSION_TAG = "v1.0.0-UNIFIED"

EXIT_PASS = 0
EXIT_FAIL = 1
EXIT_ERROR = 2
EXIT_POLICY = 3

if hasattr(signal, "SIGPIPE"):
    signal.signal(signal.SIGPIPE, signal.SIG_DFL)

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)


def _first_token(lines: List[str], default: str) -> str:
    for ln in lines:
        if ln.startswith("[") and "]" in ln:
            return ln[1 : ln.index("]")]
    return default


def _emit(
    rc: int,
    mode: str,
    out_lines: List[str],
    err_lines: List[str],
    as_json: bool = False,
    extra_json: Optional[Dict[str, object]] = None,
) -> int:
    verdict_map = {0: "PASS", 1: "FAIL", 2: "ERROR", 3: "POLICY"}
    verdict = verdict_map.get(rc, "ERROR")
    all_lines = [ln for ln in (out_lines + err_lines) if ln.strip()]
    token = _first_token(all_lines, f"{mode.upper()}_{verdict}")

    if as_json:
        payload: Dict[str, object] = {
            "schema": "focusgate.verdict/1",
            "tool": "focus_gate",
            "version": VERSION,
            "mode": mode,
            "verdict": verdict,
            "token": token,
            "exit_code": rc,
        }
        if extra_json:
            payload.update(extra_json)
        else:
            payload["lines"] = all_lines
        print(json.dumps(payload, separators=(",", ":")))
        return rc

    for ln in err_lines:
        print(ln, file=sys.stderr)
    for ln in out_lines:
        print(ln)
    return rc


def _handle_run(args: argparse.Namespace) -> int:
    import fg_integrity
    import fg_runner

    cmd = args.run
    if args.cwd and not os.path.isdir(args.cwd):
        msg = f"[CHECK_ERROR] cwd is not a directory: {args.cwd}"
        return _emit(
            EXIT_ERROR, "run", [], [msg], as_json=args.json,
            extra_json={
                "command": cmd, "child": None, "reasons": [f"BAD_CWD: {args.cwd}"],
                "policy": {"allowed": True, "class": "OK", "tags": []},
                "stdout_tail": [], "stderr_tail": [],
            },
        )

    pol = fg_integrity.classify_command(cmd, allow_risky=args.allow_risky)
    if args.dry_run:
        cwd_label = args.cwd or os.getcwd()
        t_clamped = max(1, min(int(args.timeout), 600))
        msg = f"[CHECK_DRY_RUN] Would run in {cwd_label}: {cmd} (timeout {t_clamped}s, policy {pol['class']})"
        return _emit(EXIT_PASS, "run", [msg], [], as_json=args.json)

    if not pol["allowed"]:
        tags_str = ",".join(pol["tags"])  # type: ignore[arg-type]
        msg = f"[CHECK_POLICY_DENIED] {pol['class']}: {tags_str}"
        return _emit(
            EXIT_POLICY, "run", [msg], [], as_json=args.json,
            extra_json={
                "command": cmd, "child": None, "reasons": [f"{pol['class']}: {tags_str}"],
                "policy": pol, "stdout_tail": [], "stderr_tail": [],
            },
        )

    dummy_res = fg_runner.RunResult(cmd, 0, None, False, False, 0, "", "", timeout_s=args.timeout, max_output=args.max_output)
    pre_ev = fg_runner.evaluate(dummy_res, expect=args.expect, expect_exit=args.expect_exit, expect_not=args.expect_not)
    if pre_ev.verdict == "ERROR":
        err_msg = f"[CHECK_ERROR] {pre_ev.human_reasons[0]}"
        return _emit(
            EXIT_ERROR, "run", [], [err_msg], as_json=args.json,
            extra_json={
                "command": cmd, "child": None, "reasons": pre_ev.reasons,
                "policy": pol, "stdout_tail": [], "stderr_tail": [],
            },
        )

    res = fg_runner.run_command(cmd, timeout_s=args.timeout, cwd=args.cwd, max_output=args.max_output)
    ev = fg_runner.evaluate(
        res, expect=args.expect, expect_exit=args.expect_exit,
        expect_not=args.expect_not, enforce_rigor=args.strict,
    )

    stdout_tail = fg_runner.normalize_output(res.stdout).splitlines()[-40:]
    stderr_tail = fg_runner.normalize_output(res.stderr).splitlines()[-40:]
    extra_run: Dict[str, object] = {
        "command": cmd,
        "child": {
            "exit_code": res.exit_code, "signal": res.signal,
            "timed_out": res.timed_out, "truncated": res.truncated,
            "duration_ms": res.duration_ms,
        },
        "reasons": ev.reasons, "policy": pol,
        "stdout_tail": stdout_tail, "stderr_tail": stderr_tail,
    }

    if ev.verdict == "PASS":
        msg = f"[CHECK_PASS] Exit {res.exit_code}"
        if args.expect is not None:
            msg += f" and output matched EXPECT pattern: '{args.expect}'"
        if args.expect_not is not None:
            msg += f" and output avoided EXPECT_NOT pattern: '{args.expect_not}'"
        out_l = [f"▶ RUNNING CHECK: {cmd}", msg]
        if args.expect is None and args.expect_not is None and stdout_tail:
            out_l.extend(stdout_tail)
        extra_run["token"] = "CHECK_PASS"
        return _emit(EXIT_PASS, "run", out_l, [], as_json=args.json, extra_json=extra_run)

    out_l = [f"▶ RUNNING CHECK: {cmd}", f"[CHECK_FAIL] {'; '.join(ev.human_reasons)}"]
    if stderr_tail:
        out_l.append("STDERR:")
        out_l.extend(f"  {ln}" for ln in stderr_tail)
    if stdout_tail:
        out_l.append("STDOUT:")
        out_l.extend(f"  {ln}" for ln in stdout_tail)
    if res.truncated:
        out_l.append(f"[output truncated: kept head and tail of {res.max_output} bytes]")
    extra_run["token"] = "CHECK_FAIL"
    return _emit(EXIT_FAIL, "run", out_l, [], as_json=args.json, extra_json=extra_run)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="focus_gate.py", description=f"FocusGate {VERSION_TAG}")
    p.add_argument("--version", action="version", version=f"FocusGate {VERSION} ({VERSION_TAG})")

    modes = p.add_mutually_exclusive_group(required=True)
    modes.add_argument("--audit-contrast", nargs=2, metavar=("FG", "BG"))
    modes.add_argument("--audit-tokens", metavar="PATH")
    modes.add_argument("--sync-tokens", metavar="BRAND_MD")
    modes.add_argument("--audit-safe-zone", metavar="SPEC")
    modes.add_argument("--audit-prose-cliche", metavar="FILE")
    modes.add_argument("--audit-code-cliche", "--unlazy-rigor", dest="audit_code_cliche", metavar="PATH")
    modes.add_argument("--audit-design-cliche", metavar="PATH")
    modes.add_argument("--verify-spike", metavar="HTML_PATH")
    modes.add_argument("--settle-spike", metavar="HTML_PATH")
    modes.add_argument("--diff", metavar="FILE_OR_DASH")
    modes.add_argument("--count-tokens", metavar="FILE_OR_DASH")
    modes.add_argument("--check-placeholders", metavar="FILE")
    modes.add_argument("--lint", nargs="?", const=".focusgate/GATES.md", metavar="LEDGER_PATH")
    modes.add_argument("--run", metavar="CMD")
    modes.add_argument("--next", action="store_true")
    modes.add_argument("--baseline", action="store_true")
    modes.add_argument("--run-gate", metavar="GATE_ID")
    modes.add_argument("--settle", "--check", dest="settle", metavar="GATE_ID")
    modes.add_argument("--run-all", action="store_true")
    modes.add_argument("--evidence", action="store_true")
    modes.add_argument("--anchor-evidence", action="store_true")
    modes.add_argument("--status", action="store_true")
    modes.add_argument("--report", action="store_true")
    modes.add_argument("--retro", action="store_true")
    modes.add_argument("--route", "-p", "--synthesize-pipeline", dest="route", metavar="TASK")
    modes.add_argument("--selftest", action="store_true")

    p.add_argument("--expect", default=None)
    p.add_argument("--expect-exit", default="0")
    p.add_argument("--expect-not", default=None)
    p.add_argument("--timeout", type=int, default=60)
    p.add_argument("--cwd", default=None)
    p.add_argument("--max-output", type=int, default=262144)
    p.add_argument("--json", action="store_true")
    p.add_argument("--allow-risky", action="store_true")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--ledger", default=".focusgate/GATES.md")
    p.add_argument("--strict", action="store_true")
    p.add_argument("--force", action="store_true")
    p.add_argument("--waive-red", default=None)
    p.add_argument("--check-integrity", action="store_true")
    p.add_argument("--receipt", action="store_true")
    p.add_argument("--facet", default="unlazy")
    p.add_argument("--reopen", action="store_true")
    p.add_argument("--fresh", action="store_true")
    p.add_argument("--scan", default="stubs")
    p.add_argument("--budget", type=int, default=None)
    p.add_argument("--include-code", action="store_true")
    p.add_argument("--box", action="append", default=None)
    p.add_argument("--platform", default=None)
    p.add_argument("--min", dest="min_ratio", type=float, default=4.5)
    p.add_argument("--out", default="assets")
    p.add_argument("--summary", default="Validated spike hypothesis.")
    return p


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:
        return EXIT_ERROR if exc.code != 0 else EXIT_PASS

    if args.run is not None:
        return _handle_run(args)

    if args.audit_contrast:
        import fg_oracles
        rc, o, e = fg_oracles.audit_contrast(args.audit_contrast[0], args.audit_contrast[1], min_ratio=args.min_ratio)
        return _emit(rc, "audit-contrast", o, e, as_json=args.json)

    if args.audit_tokens:
        import fg_oracles
        rc, o, e = fg_oracles.audit_tokens(args.audit_tokens, strict=args.strict)
        return _emit(rc, "audit-tokens", o, e, as_json=args.json)

    if args.sync_tokens:
        import fg_oracles
        rc, o, e = fg_oracles.sync_tokens(args.sync_tokens, out_dir=args.out)
        return _emit(rc, "sync-tokens", o, e, as_json=args.json)

    if args.audit_safe_zone:
        import fg_oracles
        rc, o, e = fg_oracles.audit_safe_zone(args.audit_safe_zone, boxes=args.box, platform=args.platform)
        return _emit(rc, "audit-safe-zone", o, e, as_json=args.json)

    if args.audit_prose_cliche:
        import fg_oracles
        rc, o, e = fg_oracles.audit_prose_cliche(args.audit_prose_cliche)
        return _emit(rc, "audit-prose-cliche", o, e, as_json=args.json)

    if args.audit_code_cliche:
        import fg_oracles
        rc, o, e = fg_oracles.audit_code_cliche(args.audit_code_cliche)
        return _emit(rc, "audit-code-cliche", o, e, as_json=args.json)

    if args.audit_design_cliche:
        import fg_oracles
        rc, o, e = fg_oracles.audit_design_cliche(args.audit_design_cliche)
        return _emit(rc, "audit-design-cliche", o, e, as_json=args.json)

    if args.verify_spike:
        import fg_oracles
        rc, o, e = fg_oracles.verify_spike(args.verify_spike)
        return _emit(rc, "verify-spike", o, e, as_json=args.json)

    if args.settle_spike:
        import fg_oracles
        rc, o, e = fg_oracles.settle_spike(args.settle_spike, summary=args.summary)
        return _emit(rc, "settle-spike", o, e, as_json=args.json)

    if args.diff:
        import fg_oracles
        rc, o, e = fg_oracles.audit_diff(args.diff, scans_csv=args.scan)
        return _emit(rc, "diff", o, e, as_json=args.json)

    if args.count_tokens:
        import fg_oracles
        rc, o, e = fg_oracles.count_tokens(args.count_tokens, budget=args.budget)
        return _emit(rc, "count-tokens", o, e, as_json=args.json)

    if args.check_placeholders:
        import fg_oracles
        rc, o, e = fg_oracles.check_placeholders(args.check_placeholders, include_code=args.include_code)
        return _emit(rc, "check-placeholders", o, e, as_json=args.json)

    if args.lint is not None:
        import fg_ledger
        rc, o, e = fg_ledger.lint_ledger_file(args.lint, strict=args.strict, check_integrity=args.check_integrity)
        return _emit(rc, "lint", o, e, as_json=args.json)

    if args.next:
        import fg_ledger
        rc, o, e, g = fg_ledger.next_gate(args.ledger)
        g_dict = None
        if g is not None:
            g_dict = {
                "id": g.id, "title": g.title, "status": g.status, "deps": g.deps,
                "check": g.check, "expect": g.expect, "expect_exit": g.expect_exit,
                "expect_not": g.expect_not, "timeout": g.timeout, "kind": g.kind,
            }
        return _emit(rc, "next", o, e, as_json=args.json, extra_json={"gate": g_dict, "token": "NEXT_GATE"})

    if args.baseline:
        import fg_ledger
        rc, o, e = fg_ledger.run_baseline(args.ledger)
        return _emit(rc, "baseline", o, e, as_json=args.json)

    if args.run_gate or args.settle:
        import fg_ledger
        is_settle = bool(args.settle)
        gid = args.settle if is_settle else args.run_gate
        t_ov = args.timeout if "--timeout" in (argv or sys.argv[1:]) else None
        rc, o, e, extra = fg_ledger.execute_gate(
            ledger_path=args.ledger, gate_id=gid, settle=is_settle,
            allow_risky=args.allow_risky, write_receipt=args.receipt,
            facet=args.facet, strict=args.strict, waive_red=args.waive_red,
            force=args.force, cwd_override=args.cwd, timeout_override=t_ov,
        )
        return _emit(rc, "settle" if is_settle else "run-gate", o, e, as_json=args.json, extra_json=extra)

    if args.run_all:
        import fg_ledger
        rc, o, e = fg_ledger.run_all_gates(args.ledger, reopen=args.reopen)
        return _emit(rc, "run-all", o, e, as_json=args.json)

    if args.evidence:
        import fg_ledger
        rc, o, e = fg_ledger.verify_evidence_chain(args.ledger)
        return _emit(rc, "evidence", o, e, as_json=args.json)

    if args.anchor_evidence:
        import fg_ledger
        rc, o, e = fg_ledger.anchor_evidence(args.ledger)
        return _emit(rc, "anchor-evidence", o, e, as_json=args.json)

    if args.status:
        import fg_ledger
        rc, o, e = fg_ledger.status_line(args.ledger)
        return _emit(rc, "status", o, e, as_json=args.json)

    if args.report:
        import fg_ledger
        rc, o, e = fg_ledger.delivery_report(args.ledger, fresh=args.fresh)
        return _emit(rc, "report", o, e, as_json=args.json)

    if args.retro:
        import fg_ledger
        rc, o, e = fg_ledger.retro_report(args.ledger)
        return _emit(rc, "retro", o, e, as_json=args.json)

    if args.route:
        import fg_router
        idx_path = os.path.join(os.path.dirname(SCRIPT_DIR), "facets", "facet_index.json")
        res_r = fg_router.route_task(args.route, idx_path)
        facets_csv = ", ".join(res_r["facets"]) if res_r["facets"] else "(none)"  # type: ignore[arg-type]
        stages_s = " -> ".join(res_r["stages"])  # type: ignore[arg-type]
        line = f"[ROUTE_PASS] Archetype: {res_r['archetype']} | Facets: {facets_csv} | Pipeline: {stages_s}"
        return _emit(0, "route", [line], [], as_json=args.json, extra_json={**res_r, "token": "ROUTE_PASS"})

    if args.selftest:
        import unittest
        tests_dir = os.path.join(os.path.dirname(SCRIPT_DIR), "tests")
        suite = unittest.defaultTestLoader.discover(start_dir=tests_dir, pattern="test_*.py")
        stream = open(os.devnull, "w", encoding="utf-8")
        runner = unittest.TextTestRunner(stream=stream, verbosity=0)
        res_u = runner.run(suite)
        stream.close()
        n_run = res_u.testsRun
        n_fail = len(res_u.failures)
        n_err = len(res_u.errors)
        rc = EXIT_PASS if (n_fail == 0 and n_err == 0) else EXIT_FAIL
        tok = "SELFTEST_PASS" if rc == 0 else "SELFTEST_FAIL"
        return _emit(rc, "selftest", [f"[{tok}] {n_run} tests, {n_fail} failures, {n_err} errors"], [], as_json=args.json)

    return EXIT_ERROR


if __name__ == "__main__":
    sys.exit(main())
