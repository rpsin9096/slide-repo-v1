# Handoff — Atomic List-Item Fix Inspection Guide

**Date:** 2026-10-26
**Audience:** another agent asked to inspect, review, or extend the atomic-list-balance fix.
**Scope:** `split_list_items: false` now makes list items atomic in the v3 geometry engine; the fix is implemented, tested, spec'd, and **deployed live** (revision `2026-10-26-atomic-list-balance`).

Read `AGENTS.md` first, then `specs/00-INDEX.md`. The owning specs are `specs/03-INPUT.md` (flag contract) and `specs/08-LAYOUT-GEOMETRY-V3.md` §5.9.3 (mechanics). The two `ALTERATIONS.md` entries dated 2026-10-26 ("Atomic list items were split despite…", "Atomic-list-balance build deployed…") are the change log for this work.

## 1. What the bug was

The editor exposes a Portuguese checkbox **"Dividir itens longos"** and both `pdf-engine.js` and the Worker forwarded `split_list_items`, but the v3 compiler (`src/v2/compiler/geometry-compiler.js`) never read the flag. With the control off, the user's `bauhaus` export still cut list items mid-text, and the nested-list `parentListKeep` keep peeled whole parent chains to the next page, leaving a 112 pt void on page 2 (`805.8 / 693.9`). Page 3 opened mid-item (`intraperitoneal…`) with no bullet marker.

The fix is the user-selected **atomic + rebalance** design: never cut a list item; move whole items between columns; let glue close residual space. The default stays `true` (splitting allowed) — changing the default is a separate product decision that was deliberately not made.

## 2. Change map (line numbers verified 2026-10-26; grep anchors included because lines drift)

All in `src/v2/compiler/geometry-compiler.js` unless noted:

| What | Where | Grep anchor |
| --- | --- | --- |
| Read the flag once per compile (both aliases) | lines 955–956 | `split_list_items !== false` |
| Flag in display-list cache key | line 1053 | `splitListItems ? '1' : '0'` |
| Flag in block-flow cache key | line 1157 | same anchor (first of two long hashes) |
| Flag in parsed-item cache key | line 1300 | same anchor (second long hash) |
| Stamp every parsed list item `splitAllowed` | line 2058 | `it.splitAllowed = splitListItems` |
| The repair switch: `atomicListBalance = !splitListItems` | line 2076 | `const atomicListBalance` |
| Atomic exception to the region-tail parent keep | line 2643 | `const tailIsParentList = splitListItems` |
| `_splitParagraph` returns atomic items whole | line 4430 | `item.splitAllowed === false) return [item, null]` |
| Revision bump | `src/_worker.js` line 313 | `RENDER_ENGINE_REVISION = '2026-10-26-atomic-list-balance'` |
| Regression gate | `tests/lean/atomic-list-balance.lean.js` | — (2 tests) |

Supporting (unchanged by this fix, relevant to understand the flow): `pdf-engine.js` (forwards the flag into compile options), `static/export-payload.js` (sends `split_list_items: !!g.splitListItems`), `static/document-store.js` (store default `splitListItems: true`), `src/v2/layout/glue-allocator.js` (glue/lift behind the residual short-column limits).

## 3. How the mechanism works

1. When `split_list_items` is `false`, every parsed list item carries `splitAllowed === false`, so `_splitParagraph` returns it whole no matter which call site asks (continuous fill, boundary refinement, tail parity, single-column path).
2. Regions still try **continuous fill first**. Only when the continuous plan leaves a material column disparity — more than two body pitches (`2 * bodyLineH`) — does the region switch to the existing multicol whole-item balancer. A continuous page that is already flush is left alone, so the repair never shortens full pages.
3. At an atomic-list region tail, the `parentListKeep` shrink is skipped: a whole parent item may end one column and its child may open the next, in document order. The `stacked-sliver-order` guard still applies.
4. The flag is part of the display-list, block-flow, and parsed-item cache keys, so a cached `true` request can never satisfy a `false` request. The Worker's edge cache key also includes `RENDER_ENGINE_REVISION` (`convertCacheBasis`, `src/_worker.js` ~line 355), which is why the revision bump flushes stale live output.

## 4. How to verify (fresh commands, expected outputs)

Gate (fast, ~1 s):

```bash
node --test tests/lean/atomic-list-balance.lean.js   # 2/2 pass
```

The gate compiles a sanitized synthetic nested-list document (30 preamble paragraphs, 20 list groups), records every list-item split call, and measures body column feet. Before the fix it observed `6` cuts and a page-3 right column at `y = 488.1` vs left `805.8`; after the fix it requires `0` cuts and every interior column within `14 pt` of the region foot.

Full suites (all observed passing 2026-10-26):

```bash
npm run lint          # pass
npm test              # VERIFY: PASS; 327 tests in 81 suites, 327 pass, 0 fail
npm run test:design   # 38 tests in 9 suites, all pass
npm run build         # pass; dist/_worker.js 6106.4 KB
```

User-document metrics through the **production path** (via `convertDocument`, no instrumentation shims):

- `bauhaus`, `split_list_items: false`: 194,985 B, 4 pages, **0 actual cuts**. Display-list body feet: p1 `805.8/805.8`, p2 `805.8/805.8`, p3 `727.4/751.0` (the next whole table cannot fit — intentional granularity, not a split), p4 opens with the table.
- `base`: 186,703 B, 4 pages, **0 cuts**, pages 1–3 flush at `801.0/801.0`.

### Coordinate-frame warning (we hit this during verification)

`scripts/pdf-text-runs.mjs` → `decodePdfRuns` reports raw **bottom-up** PDF content-stream coordinates: the *highest* y is the top header band, so "max y" is the top of the page, not the column foot. Display-list elements (`elementExtent` from `src/v2/layout/stretch-seam.js`) are **top-down** and are the correct way to measure column feet; they are what produced the numbers above. Filter footer/page-number elements by `scope` (`col:N` / `span` are body; `scope`-less text near the frame bottom is chrome).

### Live parity protocol (deployed state, re-verified 2026-10-26)

```bash
curl -sS https://doe-formatter.rpsin9096.workers.dev/api/health
# {"status":"ok","service":"DOE Formatter Cloudflare","backend":"local"}
```

POST the reproduction payload to `/api/convert` and diff text runs against a local `convertDocument` render of the identical body. Observed for both `base` and `bauhaus` with `split_list_items: false`: same page count (4), same byte size, `X-Cache: MISS` (fresh compute under the new revision), max text-run drift `0.000`, `0` text diffs, `0` run-count mismatches. A working harness for this exists at `/private/var/folders/kr/c3g4pjkn4lz624xxd9wvz6cw0000gn/T/opencode/render87.mjs` (base) and `.../live-parity-bauhaus.mjs` (bauhaus).

## 5. Known residuals and non-goals

- **Short pre-table columns are intentional.** When the next whole item/group/table cannot fit, an atomic region ends short (bauhaus p3 above). This is the honest price of "never cut an item"; `split_list_items: true` is the opt-out.
- **Default remains `true`** in the API, Worker (`resolveWorkerCompileOptions`), store, and the UI checkbox. Atomic behavior requires unchecking **"Dividir itens longos"** or sending `split_list_items: false`. Do not flip the default without a product decision.
- **Code blocks are not list items.** A pre-existing, out-of-scope limit remains: one code block taller than a page is emitted whole and crosses the content foot. It is not the split/glue class and was not touched.
- **Already-exported PDFs are frozen.** Only re-exports after the deploy carry the new layout.
- **Deploy credential hygiene.** The Cloudflare token used for the deploy was passed inline from the conversation, never written to the repository (verified: `grep -r "cfut_\|CLOUDFLARE_API_TOKEN" .` → no matches). Rotate it if the transcript may be shared.

## 6. Reproduction artifacts (machine-local, not in the repository)

- `/private/var/folders/kr/c3g4pjkn4lz624xxd9wvz6cw0000gn/T/opencode/doc87.md` — the user's exact markdown.
- `.../doc87.json` — reproduction payload (base/v3, `split_list_items: false`); switch `template` to `bauhaus` for the bauhaus run.
- `.../doc87-atomic-hybrid.pdf` — local bauhaus render, layout-identical to the deployed output.
- `.../local-verify-doc87.mjs` — production-path cut counter + feet probe.
- `.../render87.mjs`, `.../live-parity-bauhaus.mjs` — live-vs-local parity harnesses.

If those temp paths are gone, rebuild the check from the gate: the synthetic fixture in `tests/lean/atomic-list-balance.lean.js` is self-contained and sanitized, and it is the durable regression evidence.

## 7. What a reviewer should poke at

1. **Cache-key completeness** — confirm the split flag appears in all three cache keys (grep anchors in §2) and reason about whether any fourth cache exists that should also key on it.
2. **The rebalance trigger** — find the `2 * bodyLineH` disparity threshold in the region planner and check both directions: does an already-flush page ever get rebalanced (it must not)? Does a genuinely disparate page ever stay continuous (>2 pitches must rebalance)?
3. **The parent-keep exception** — verify the skip applies only at atomic-list region tails and that `stacked-sliver-order` still holds (its lean test passes).
4. **Terminating behavior** — the region planner's progress guarantee is pinned by `tests/lean/table-region-zero-placement.lean.js`; atomic items make bites coarser, so a reviewer should confirm the zero-placement guard (keyed on `bite.length`, not the cursor) still covers atomic-item bites.
5. **Cross-template coverage** — the earlier 87/87 cross-template audit predates this change; current coverage is the new gate plus the full 327-test suite. If you extend the behavior, re-run a template × geometry matrix.
