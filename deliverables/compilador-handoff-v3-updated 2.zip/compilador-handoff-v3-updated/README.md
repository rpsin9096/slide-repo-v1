# Compilador do Raul

A local-first Markdown-to-PDF compiler for long-form study material. It combines a browser editor, a Node/Express API, a deterministic PDF layout engine, and an optional Cloudflare Worker deployment.

This repository is a **sanitized handoff snapshot**. It contains the runtime, tests, build scripts, and the documentation needed to run the project now and rebuild it later. It is not the historical development repository: the old git history, session notes, screenshots, experiments, and personal artifacts are intentionally absent.

## Quick start

Requirements:

- Node.js 20 or newer (`.nvmrc` pins 20; the runtime declares `>=20`)
- npm
- Optional: Typst, only if you use the legacy `v2-typst` driver or `/api/convert-v2`
- Optional: a Cloudflare account and network access, only for deployment

```bash
cd compilador-handoff-v3
npm ci
npm run dev
```

Open <http://localhost:3000>. The server creates `static/uploads/` on first start. Edit a block, choose a template and document options, then use **Gerar PDF** or **Pré-visualizar**.

The Node server does not load `.env` automatically. Export variables in your shell, or start it with `node --env-file=.env server.js`.

## Verification

```bash
npm run lint           # syntax check of entry points
npm test               # 9 verify suites + 60 lean test files (311 tests across 79 suites)
npm run test:design    # 9 exact-CSS/design locks (38 tests across 9 suites)
npm run test:all       # npm test + design tier
python3 scripts/design_guardrails.py --config design-guardrails.config.json --audit-all static --document DESIGN.md
```

Baseline on 2026-10-25: `npm test` passed 9/9 verify suites and 311 tests in 79 suites; `npm run test:design` passed 38 tests in 9 suites; `design_guardrails.py` passed with `0` errors and `0` warnings. Counts are evidence, not contracts. The testing policy and fixture regeneration rules are in [specs/07-TESTING.md](specs/07-TESTING.md).

Useful manual checks:

```bash
curl -s http://localhost:3000/api/health
curl -sS -D - -o /tmp/smoke.pdf -X POST http://localhost:3000/api/convert \
  -H 'Content-Type: application/json' \
  -d '{"markdown":"# Smoke\n\nHello PDF","preview":true}'
```

## Build and deploy

```bash
npm run build          # regenerates src/afm-data.js and src/font-assets-data.js, builds dist/
npm run dev:cf         # build, then wrangler dev on :8787
npm run deploy         # build, then wrangler deploy
```

`npm run build` uses `npx wrangler` for the final dry-run bundle. Wrangler is intentionally not pinned in `package.json`, so the first build needs network access. Deployment details, required secrets, and Worker limits are in [specs/06-OPERATIONS.md](specs/06-OPERATIONS.md).

## Project map

| Path | Responsibility |
| --- | --- |
| `static/` | Browser editor, document store, export payload builder, 3-layer CSS token system |
| `DESIGN.md` | Normative frontend design system specification (9 sections, tokens, WCAG AA contrast, 4px grid) |
| `design-guardrails.config.json` | Machine-readable Design Guardrails v3.0 contract (`spacing_base: 4`, `mode: "both"`) |
| `server.js` | Local Express API and static file server |
| `src/_worker.js` | Cloudflare Worker API, embedded assets, edge cache |
| `pdf-engine.js` | Public conversion/pagination facade and driver selection |
| `pdf-generator.js` | Deprecated compatibility facade; keep for tests and old callers |
| `src/v2/` | Canonical ingest → layout → compiler (V2 + V3 integer-mpt engine) → driver pipeline |
| `scripts/` | Build, fixture regeneration, PDF probes, parity tooling, `design_guardrails.py` |
| `tests/corpus/` | Markdown corpus used by layout and regression tests |
| `tests/lean/` | Fast behavioral/unit tests (`npm run test:lean`) |
| `tests/design/` | Exact-CSS/design tripwires (`npm run test:design`) |
| `tests/fixtures/` | Frozen diagnostic/layout goldens |
| `specs/` | Numbered system specification; start at `specs/00-INDEX.md` |

## Documentation

- [Specification index](specs/00-INDEX.md)
- [Product and glossary](specs/01-PRODUCT.md)
- [Architecture](specs/02-ARCHITECTURE.md)
- [Input contract](specs/03-INPUT.md)
- [Layout engine](specs/04-LAYOUT.md)
- [Output and PDF](specs/05-OUTPUT.md)
- [Operations and deployment](specs/06-OPERATIONS.md)
- [Testing](specs/07-TESTING.md)
- [Layout Geometry V3](specs/08-LAYOUT-GEOMETRY-V3.md)
- [Frontend Design System](DESIGN.md)
- [Agent rules](AGENTS.md)
- [Alterations log](ALTERATIONS.md)

## Security and scope

The application has **no authentication**. Treat it as a local or trusted-network tool. Do not expose the Node server or Worker publicly without adding authentication, request controls, and a CSP/upload policy. The default CORS behavior is open when `CORS_ORIGINS` is unset; the Worker always uses `*`. See [specs/06-OPERATIONS.md](specs/06-OPERATIONS.md) for the full security posture.

## Known limits

- When `geometry: 'v3'` is passed (the browser default), `/api/paginate` and `/api/convert` return exact compiler pagination; legacy callers omitting `geometry` on `/api/paginate` receive the fast coarse estimate.
- `/api/convert-v2` is a staging endpoint. It requires Typst and the `v2-typst` path; the default `/api/convert` uses PDFKit.
- The Worker has no Typst driver and no `/api/convert-v2`; it uses PDFKit and has stricter payload limits.
- `npm run build` needs `npx wrangler` from the network; it is not part of `npm test`.
