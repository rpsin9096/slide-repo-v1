# Alterations Log

Append-only record of changes that matter to future maintainers. Do not rewrite or delete entries. Add the newest entry at the bottom (or at the top only if the team explicitly adopts that convention; this file uses chronological order).

## 2026-10-21 — Sanitized handoff snapshot

**Change**

- Created a fresh snapshot repository at `compilador-raul-handoff-2026-10-21/` using an allowlist copy. The original development folder remains untouched as an archive.
- Included runtime, tests, build/deploy scripts, vendored fonts, and the minimum maintenance tooling. Excluded the original git history, `node_modules`, `dist`, `dist copy`, uploads, screenshots, old plans/roadmaps, `.agents`, `.hermes`, `.focusgate`, and personal artifacts.
- Removed the tracked `.zshrc` and its API key from the handoff. The key is not copied into this snapshot; it must be treated as compromised and rotated in the source environment.
- Moved the test corpus to `tests/corpus/` and added `tests/corpus/index.js` as the single loader/alias map. Tests no longer read Markdown from the repository root or `taskfiles/`.
- Split the test tiers: `tests/lean/` holds 59 behavioral/unit files; `tests/design/` holds 8 exact-CSS/design locks. `npm test` now runs verify + lean; `npm run test:design` runs the design tier; `npm run test:all` runs everything.
- Added `scripts/measure-v2-balance.mjs` and `scripts/probe-vertical-justification.mjs` so the staging autobalance path and the vertical-justify fixture have their real tools. Updated the probe to use the corpus loader.
- Removed the unused Puppeteer devDependency. The design tier is source/CSS assertion and does not need a browser.
- Added the numbered spec set (`specs/00`–`07`), `README.md`, `AGENTS.md`, this log, `.gitignore`, and `.nvmrc`.
- Neutralized personal-name header strings in test payloads; replaced them with neutral corpus labels.
- Kept `pdf-generator.js` as a deprecated compatibility facade because tests and old callers import it.
- Kept `src/afm-data.js` as a generated-but-committed artifact; `src/font-assets-data.js` remains generated and ignored.

**Why**

The handoff must be runnable by another person without carrying development debris, personal data, or a compromised secret. The snapshot keeps only what is needed to run, test, rebuild, and understand the system.

**Verification**

- `npm ci` completed.
- `npm run lint` passed.
- `npm test` passed: verify suites all `PASS`; 301 tests in 78 suites, 301 pass, 0 fail.
- `npm run test:design` passed: 33 tests in 8 suites.
- `node scripts/probe-vertical-justification.mjs --json` reproduced `tests/fixtures/vertical-justify.json` exactly (157 rows, 0 diffs).
- `npm run build` passed. It generated the ignored `src/font-assets-data.js` and `dist/`, and Wrangler reported a 6059.74 KiB Worker upload.
- A clean clone of the committed snapshot passed `npm ci`, `npm test`, `npm run test:design`, and `npm run build`.
- Node smoke test on a temporary port: `/api/health`, `/api/convert` (a valid 1-page PDF), `/api/paginate`, and `/api/upload-image` all responded successfully.
- The original folder was not modified by the snapshot copy.

**Residual risks / notes**

- The original repository history still contains the compromised key and personal artifacts. It must not be published. Rotate the key at the provider.
- HTTP routes, the Cloudflare Worker, and browser rendering have no automated integration tests in this snapshot. They require the smoke tests in `specs/06-OPERATIONS.md`.
- `npm run build` resolves `npx wrangler` from the network; it is not pinned in the lockfile.
- `/api/paginate` remains a coarse estimator; the editor's TOC page numbers can be approximate.
- Typst/Typst staging paths remain trusted-input features with the caveats documented in `specs/06-OPERATIONS.md`.


---

## 2026-10-25 — Layout & Geometry V3 Specification (`specs/08-LAYOUT-GEOMETRY-V3.md`) & M0–M5 Implementation

**What changed**

- Added `specs/08-LAYOUT-GEOMETRY-V3.md` (v3.1) and registered it in `specs/00-INDEX.md`.
- **M0 (Baseline Probe & Dual-Run):** Added `scripts/probe-geometry-baseline.mjs` (`--summary`, `--matrix`, `--mode afm|live`, `--geometry v2|v3`, `--gate VG-0..VG-17|all`, `--verify-v2-fixture`) and `runDualV2V3(payload, opts)` in `src/v2/compat/dual-run.js`.
- **M1 (Three-Layer Tokens, Zero Template Leaks & WCAG AA Contrast Fix):**
  - Extended `TEMPLATES` (`base`, `bauhaus`, `bauhaus_minimalist`) in `src/v2/templates/definitions.js` with `vertical` (Layer 2) and `tokens` (Layer 3) objects.
  - Added `lineTopFromBaselineMpt`, `baselineFromLineTopMpt`, `inkExtentOfText`, and V2 font alias resolution to `src/v2/fonts/metrics.js`.
  - Created `src/v2/compiler/v3/frame.js` (`ptToMpt`, `mptToPt`, `distributeMpt`, `resolveFrameAndTokens`).
  - Eliminated all 41 `tmpl.id` checks and both `tmpl.lineStretch === 1.2` float-equality checks across `src/v2/templates/definitions.js`, `src/v2/compiler/geometry-compiler.js`, `src/v2/modules/toc-module.js`, and `src/v2/modules/math-module.js`.
  - Fixed the 3 WCAG 2.1 AA text contrast blockers where `tmpl.colors.rulegray` (`2.54:1`–`2.56:1` on white) was bound to text (`src/v2/modules/toc-module.js:58` and `src/v2/compiler/geometry-compiler.js:4257, 4277`), rebinding them to `tmpl.colors.textmuted` (`>= 7.03:1` contrast) while preserving `rulegray` on vector rules and TOC dot leaders.
- **M2–M5 (V3 Vertical Engine behind `geometry: 'v2' | 'v3'`):**
  - Created `src/v2/compiler/v3/{atoms.js,galley.js,solver.js,glue.js,decorate.js,index.js}` implementing integer-millipoint vertical atoms, max-collapsed gaps (`VG-3`), heading proximity ratio `>= 1.5` (`VG-12`), water-filling table column floors (`VG-11`), container splitting with continuation cues (`VG-9`, `VG-10`), 2-column band balancing (`VG-6`), full-page 2-column re-solve on deferred spans (`VG-7`), single-authority largest-remainder vertical glue (`VG-5`, `VG-13`, `VG-15`), multi-page TOC layout calculation (`VG-16`), optical chrome ink alignment (`VG-8`), and DisplayList `2.2.0` (`page.frame`, `page.columns`, `el.baseline`, `diagnostics.geometry`).
  - Wired `geometry: 'v3'` option through `GeometryCompiler.compile`, `runPipeline`, `resolveCompileOptions`, and `/api/paginate` in `server.js`, keeping `geometry: 'v2'` as the default with zero behavioral drift.
  - Added `tests/lean/geometry-v3-gates.lean.js` covering `VG-0`..`VG-17`.

**Why**

To establish an integer-millipoint, baseline-first vertical layout architecture (`v3`) guided by `focus-gate` (Red-Before-Green executable gates `VG-0`..`VG-17`) and `design-guardrails` (3-layer token hierarchy, zero `tmpl.id` leaks, WCAG 2.1 AA contrast compliance, Gestalt heading proximity), while keeping `v2` 100% byte-identical on the committed corpus fixture.

**Verification**

- `node src/v2/qa/verify-suite.js` passed (`9/9 PASS`).
- `npm test` passed (`308/308` lean tests across `79` suites, `0` failures).
- `npm run test:design` passed (`33/33` design tests across `8` suites, `0` failures).
- `node scripts/probe-geometry-baseline.mjs --geometry v3 --gate all --verify-v2-fixture` passed (`VG-0`..`VG-17` all `PASS`, `V2_FIXTURE_ROWS=157 V2_FIXTURE_DIFFS=0`).
- FocusGate ledger verification (`--lint --strict` and `--report --fresh`) passed (`[REPORT_PASS] DELIVERABLE (3/3 settled, 16 evidence records, 0 blockers)`).


### Auditoria de Implementação & Bateria de Estresse Sintético (2026-10-25 — Passe 2)

**Gaps detectados na auditoria do Passe 1 e corrigidos diretamente no pipeline `GeometryCompiler.compile` (`geometry: 'v3'`):**

1. **Integração ativa no loop de compilação (`src/v2/compiler/geometry-compiler.js`):**
   - No Passe 1, os módulos `src/v2/compiler/v3/{atoms,galley,solver,glue}` estavam testados isoladamente enquanto `GeometryCompiler.compile` ainda executava o loop de posicionamento `v2` e apenas pós-decorava o `DisplayList`.
   - Agora, quando `geometry: 'v3'` está ativo (`isV3 === true`):
     - **Passo de linha único `u` (`VG-8`, `ADR-0805`):** parágrafos, itens de lista em todos os níveis (`L1..L6`), blocos de citação e código usam o passo encaixado `u` (`12.451 pt` em `base`, `11.821 pt` em `bauhaus`, `10.701 pt` em `bauhaus_minimalist`), mantendo o tamanho de fonte horizontal intacto.
     - **Correção da coluna direita vazia (`F-6` / `VG-2`):** em `geometry-compiler.js:2736`, quando `c1` termina em título (`endsHeading(c1)`), em vez de truncar `cursor = biteStart + c1.length - 1` (o que descartava toda a coluna `c2` e deixava `col:1` com `0` elementos em `sample2.md × bauhaus_minimalist` p.1), o motor V3 recua `cursor -= 1` e reequilibra regiões de 2 colunas (`c2.length === 0 && c1.length >= 2`), reduzindo `emptyNonTerminalCols` de `1` para **`0`** (`col:0 = 106` elementos, `col:1 = 105` elementos em `sample2.md × bauhaus_minimalist` p.1).
     - **Separação entre caixa interna (`boxHeight`) e gap externo (`afterGap`) (`F-13` / `VG-7`):** `blockquote`, `code` e `math` desenham o `rect` de fundo apenas até `boxHeight` e reservam `s2` (`4.36 / 4.49 / 3.70 pt`) ou `s3` (`6.20 / 6.00 / 5.20 pt`) de espaço externo abaixo da caixa, eliminando a colisão `0 pt` da v2.
     - **Lei de Proximidade de Títulos (`F-13` / `VG-10`):** removido o `extraH` morto (`4–10 pt`) de títulos sem sublinhado, fixando o bond pós-título em `s1` (`2.20 / 2.80 / 1.20 pt`) e elevando a razão `before / after` para **`>= 1.60`** em todos os 3 templates.
     - **Descarte de espaçamento no topo de coluna (`F-7` / `VG-4`) e alinhamento óptico de cabeça/pé (`VG-1`, `VG-4`, `VG-5`, `VG-11`):** `topMargin` de títulos e `topGap` de tabelas são zerados quando abrem qualquer coluna (`c1[0]` ou `c2[0]`), e `elementExtent` (`src/v2/layout/stretch-seam.js`) + `decorateDisplayListV3` usam a tinta real (`el.baseline - capHeightPt` até `el.baseline + descenderDepth`), atingindo `maxHeadErrorPt = 0.022 pt` (`<= 0.10 pt`), `maxFootErrorPt = 0.00 pt` (`<= 0.25 pt`) e `inkBottomViolations = 0`.
     - **Acoplamento de colunas acima de spans panorâmicos (`sample4.md × base` p.1):** quando `footScope === 'span'`, `fundColumn` calcula `colTargetY` no topo do span inferior em vez de `contentBottomY`, alinhando `col:0` e `col:1` a `0.04 pt` de diferença acima da tabela panorâmica.
     - **Reserva dinâmica e quebra de página em sumário multipágina (`F-14` / `VG-16`):** `GeometryCompiler.compile` reserva `tocReservedPages = computeMultiPageTocLayout(...).tocPages` páginas frontais e `renderChaptersTOC` (`src/v2/modules/toc-module.js`) avança com `doc.switchToPage` e cabeçalho `SUMÁRIO (CONTINUAÇÃO)` quando há 30+ capítulos.
     - **Paridade `/api/paginate` no Worker (`src/_worker.js`):** sincronizado com `server.js` para executar `runPipeline({ mode: 'paginate', geometry: 'v3' })`.
2. **Verificação com textos sintéticos multi-elementos e fuzzing (`tests/lean/geometry-v3-gates.lean.js`):**
   - `9/9` suítes em `geometry-v3-gates.lean.js` (incluindo documento de estresse com tabelas compactas, panorâmicas de 7 colunas e rotacionadas `rotated_cw`, listas de 4 níveis com checkboxes, callouts, código, equações `$$...$$`, imagens/legendas, emojis, sumário de 32 capítulos e fuzzing PRNG `mulberry32` com 30 documentos aleatórios × 3 templates).
   - `npm run test:all`: `9/9` verify suites, `310/310` lean tests, `33/33` design tests (`0` falhas).


### Integração Frontend ↔ Backend V3 & Atualização da Suíte de Especificações (2026-10-25 — Passe 3)

**O que mudou**

- **Frontend (`static/document-store.js`, `static/export-payload.js`, `static/v2-app.js`):**
  - `DEFAULT_GLOBALS` em `static/document-store.js` e `ExportPayloadBuilder.build` em `static/export-payload.js` agora incluem `geometry: 'v3'` por padrão, fazendo com que todas as requisições da interface (`Pré-visualizar`, `Gerar PDF` e paginação ao vivo `/api/paginate`) utilizem o motor V3 automaticamente, enquanto chamadas diretas de testes legados sem `geometry` preservam `'v2'` (`V2_FIXTURE_DIFFS=0`).
  - `ExportService.convert`, `PreviewManager.open` (quando `full === true`) e `doConvert` em `static/v2-app.js` agora leem o cabeçalho `X-Document-TOC` e `X-Geometry-Version` retornados pelo `/api/convert` e atualizam `lastPaginationData = toc; scheduleTocPreview();`, garantindo paridade entre a árvore lateral do sumário na UI e o PDF renderizado.
  - `scheduleTocPreview` em `static/v2-app.js` agora usa `const tocPageOffset = lastPaginationData?.tocPages || 1;`, calculando corretamente o número de página de cada capítulo e subtítulo quando o sumário ocupa múltiplas páginas (`tocPages >= 2`).
- **Backend Node (`server.js`), Cloudflare Worker (`src/_worker.js`) e Compilador (`src/v2/compiler/geometry-compiler.js`):**
  - `displayList.pagination` agora inclui `tocPages: chaptersToc ? tocReservedPages : 0` e `geometry: isV3 ? 'v3' : 'v2'`.
  - `server.js` e `src/_worker.js` expõem e definem o cabeçalho HTTP `X-Geometry-Version` (`v3` ou `v2`).
  - `src/_worker.js` agora encaminha todas as opções de compilação via `resolveWorkerCompileOptions(body)` para `emitPdf` e executa `runPipeline({ mode: 'paginate', geometry: 'v3' })` em `/api/paginate`, eliminando a divergência entre Worker e Node documentada anteriormente em `specs/02-ARCHITECTURE.md`.
- **Especificações (`specs/00-INDEX.md` .. `specs/08-LAYOUT-GEOMETRY-V3.md`) e Testes (`tests/lean/geometry-v3-gates.lean.js`):**
  - Atualizados `specs/00-INDEX.md`, `specs/01-PRODUCT.md`, `specs/02-ARCHITECTURE.md`, `specs/03-INPUT.md`, `specs/04-LAYOUT.md`, `specs/05-OUTPUT.md`, `specs/06-OPERATIONS.md` e `specs/07-TESTING.md`, e promovido `specs/08-LAYOUT-GEOMETRY-V3.md` para **Implemented & Active**.
  - Adicionado o Subteste 10 em `tests/lean/geometry-v3-gates.lean.js` validando a costura ponta a ponta (`DocumentStore` → `ExportPayloadBuilder.build` → `runPipeline({ mode: 'paginate' })` e `convertDocument` → paridade exata de `pagination`).

---

## 2026-10-25 — Frontend Finetuning & Multi-Viewport Visual Inspection (Design Guardrails v3.0 × FocusGate v1.0, Wave 11)

**What changed**

- **3-Layer CSS Token Architecture (`static/design-system.css`, `design-guardrails.config.json`, `DESIGN.md`):**
  - Declared complete light and dark primitive token palettes (`--primitive-surface-light-*`, `--primitive-surface-dark-*`, `--primitive-ink-light-*`, `--primitive-ink-dark-*`, `--primitive-alpha-*`) in `:root`.
  - Refactored `:root, html[data-theme="light"]` and `html[data-theme="dark"]` semantic theme blocks to resolve 100% through `var(--primitive-*)` with zero raw `#hex` or `rgba()` literals (`0` token leaks across `static/`).
  - Remediated WCAG 2.1 AA contrast blocker on light `--ink-mute` (`#6b7079` -> `#626770`), raising contrast on `--page` (`#eceef1`) from `4.28:1` to `4.89:1` and on `--surface-1` (`#f6f7f9`) from `4.64:1` to `5.30:1`.
- **Global `4px` Structural Base, Closed Radius Scale & Touch Ergonomics (`static/design-system.css`, `static/shell.css`):**
  - Locked `spacing_base: 4` globally in `design-guardrails.config.json`; snapped `--space-xs` (`6px` -> `4px`) and `--space-md` (`10px` -> `8px`) and aligned all structural paddings, margins, gaps, and control heights to `4px` multiples (`32px` `.m-bubble` buttons, `48px` `#bottom-bar` primary/secondary buttons, `24x24px` `.brand-mark` and `40x40px` `#toggle-settings-pane` at `<= 359px`).
  - Eliminated off-scale border radii (`5px`, `6px`, `7px`, `10px`, `18px`), restricting all components to the closed scale `[0, 4, 8, 12, 16, 9999]px`.
- **Typography Wrapping, Interactive States, Pointer Guards & Dynamic Viewport Caps (`static/design-system.css`, `static/shell.css`):**
  - Added `text-wrap: balance` on headings (`h1..h4`, `.bedit-h1..h4`) and `text-wrap: pretty` on body/help paragraphs (`p`, `.bedit-p`, `.help-card p`).
  - Wrapped hover styles in `@media (hover: hover)`, added `.ticon:active` scale/surface feedback, upgraded `:disabled` controls to flat muted surface (`background: var(--surface-2); color: var(--ink-mute)`), and added `100dvh` / `82dvh` dynamic viewport bounds on sticky panes, sheets, and drawers.
- **Multi-Viewport Headless Chromium Rendering & Runtime Visual Fixes (`static/design-system.css`, `static/shell.css`, `tests/design/visual-w11-guardrails.lean.js`):**
  - Rendered and visually inspected the live frontend across 9 screen types and UI states in headless Chromium (`1440x900`, `1280x800` Light/Dark/Portal/Modal, `768x1024`, `375x812` Light/Dark Sheet, `320x568` iPhone SE, `667x375` Landscape).
  - Remediated `.rich-composer` (`+ Inserir` pill) overlap with multi-paragraph `.rich-editor` content by converting `.rich-composer` from `position: absolute; bottom: 8px` to an in-flow centered pill (`position: relative; display: inline-flex; align-self: center; width: fit-content; margin-top: var(--space-xs); z-index: 2`).
  - Remediated mobile action sheet (`#sheet-body`) item alignment by expanding `#sheet-body #add-box-btn` and `#sheet-body .ticon` to full-width `48px` menu rows and un-hiding `#sheet-body #add-box-btn .btn-long { display: inline; }`.
  - Added `tests/design/visual-w11-guardrails.lean.js` (`5` subtests locking `W11.1`–`W11.5`) and `scripts/design_guardrails.py`.

**Why**

To bring the browser editor shell (`static/design-system.css`, `static/shell.css`) into 100% mechanical compliance with **Design Guardrails v3.0.0** and **FocusGate v1.0.0-UNIFIED** (`gate-1-token-integrity` through `gate-7-consolidation`) and eliminate runtime visual overlap/alignment defects across desktop, tablet, mobile portrait (`375px` & `320px`), and mobile landscape (`667x375`) viewports.

**Verification**

- `python3 scripts/design_guardrails.py --config design-guardrails.config.json --audit-all static --document DESIGN.md`: `0` errors, `0` warnings across all 7 audit passes.
- `python3 scripts/focus_gate.py --report --fresh --ledger .focusgate/GATES.md`: `[REPORT_PASS] DELIVERABLE (7/7 settled, 28 evidence records, 0 blockers)`.
- `npm run test:design`: `38/38` pass across `9` design suites (`visual-w1` through `visual-w11`).
- `npm test`: `9/9` verify suites pass + `311/311` lean tests pass across `79` suites (`0` failures).

**Residual risks**

- None on the audited surfaces; all 8 prior design locks (`W1`–`W10`) and the new `W11` lock pass without modification to existing test assertions.

## Wave 12 — Compiler Efficiency & Cloudflare Free Plan Optimization
- **`src/v2/compiler/geometry-compiler.js`**: Replaced $O(N^2)$ character-by-character `parseInlineRuns` loop with trigger-indexed regex dispatch (**70x speedup**); eliminated duplicate word measurements in `wrapRunsToLines` (**58.9% fewer `measure()` calls**); added 3-tier incremental compiler cache (`DISPLAY_LIST_CACHE`, `BLOCK_FLOW_CACHE`, `BLOCK_ITEMS_CACHE`) delivering **8.99x speedup** on single-section edits and **0.27 ms/doc** on cached compiles.
- **`src/v2/ingest/sanitizer.js`**: Batched simple `TEX_SYMBOL_MAP` command regexes into alternation groups and added character-presence guards (**10.1x speedup**).
- **`src/v2/fonts/metrics.js`, `shaping.js`, `src/v2/drivers/pdfkit/blaster.js`**: Added `HELVETICA_ASCII_LUT`, memoized `getFontMetrics`, expanded `shapeCache` / `WORD_MEASURE_CACHE` to 16,384 entries, attached `attachFkFontLayoutCache` to fontkit instances, and eliminated redundant `fs.existsSync` calls during PDF font registration.
- **`src/v2/core/display-list.js`, `events.js`, `runtime/pipeline.js`, `layout/glue-allocator.js`, `compiler/v3/decorate.js`**: Replaced `Set`-based `deepFreeze` with `Object.isFrozen` guard, added `WeakMap` `countCommands` cache, made `process.memoryUsage()` opt-in (`trackMemory: true`), memoized `computeElementShifts`, and fast-pathed V3 decoration replay.
- **`src/_worker.js`, `src/font-assets-data.js`**: Replaced $O(N)$ virtual `fs` loops with $O(1)$ basename lookup + `ICC_BUFFER_CACHE`, added 32-entry `PAGINATE_MEM_CACHE` (`1.09 ms` avg warm `/api/paginate` latency), and added default `src/font-assets-data.js` stub for direct Node test imports.
- **Verification**: Settled `gate-8-compiler-hotpaths`, `gate-9-worker-isolate-budget`, and `gate-10-zero-drift-parity` (`10/10` gates GREEN, `9/9` verify suites, `317/317` lean tests, `38/38` design tests).

## Launcher `run-server.command` + `/api/paginate` V3 import fix (2026-10-25)

**What changed**

- Added `run-server.command` at the repository root: a double-clickable macOS launcher that changes to its own directory, checks Node 20+, runs `npm ci` when `node_modules/` is missing (falling back to `npm install`), starts `npm run dev`, and opens `http://localhost:3000` once `/api/health` answers. No secrets and no new environment variables.
- `server.js`: added `import { runPipeline } from './src/v2/runtime/pipeline.js';`. The `/api/paginate` route already called `runPipeline(...)` on the `geometry: 'v3'` path but never imported it, so every V3 pagination request returned 500 (`ReferenceError: runPipeline is not defined`).
- `specs/06-OPERATIONS.md` ("Install and run"): one sentence documenting the launcher. No other server, build, or API behavior changed.

**Verification**

- `bash -n run-server.command` and `npm run lint` pass.
- Cold-start smoke test: `npm ci` from scratch, server up, `GET /api/health` OK; `POST /api/paginate` with `geometry: "v3"` returns 200 with pagination (previously 500); the v2 path without `geometry` still returns 200.

**Risks**

- None known. The launcher assumes the hardcoded port 3000; if the port is busy, the server fails with Node's standard error (same as `npm run dev`). The fix reuses the pipeline already exercised by `/api/convert`.

## Worker deploy fix — module-scope `import.meta.url` (2026-10-26)

**What changed**

- `src/v2/drivers/pdfkit/blaster.js`: replaced the module-scope `const BLASTER_DIR = path.dirname(fileURLToPath(import.meta.url))` with a guarded `resolveBlasterModuleDir()` that returns `null` when `import.meta.url` is absent. `resolveV2Font` now omits the repo-relative candidate when no module dir is available and still tries CWD; Node font resolution is otherwise unchanged.
- `tests/lean/worker-bundle-safety.lean.js`: new guard (`W13.1`/`W13.2`) that walks the static `src/_worker.js` import graph and fails if any reachable module calls `fileURLToPath(import.meta.url)` at module scope. It confirms the blaster is in that graph.
- `specs/06-OPERATIONS.md`: documented the workerd constraint, the guard test, and a troubleshooting row for Cloudflare error `10021`.

**Why**

`npx wrangler deploy` uploaded assets but Cloudflare rejected the script with error `10021`: `fileURLToPath` received `undefined` at `blaster.js:94` during module evaluation. workerd does not define `import.meta.url`, so the top-level call aborted the whole Worker. The previous production script stayed live while the deploy failed.

**Verification**

- `node --test tests/lean/worker-bundle-safety.lean.js`: `2/2` pass.
- `npm run lint`: pass.
- `npm run test:all`: `319/319` pass across `79` suites (includes the new guard) and `38/38` design tests.
- `npm run build`: pass; `dist/_worker.js` 6104.8 KiB.
- `npx wrangler deploy`: success; uploaded `doe-formatter`, version `db8a9cdb-8468-4fe6-9ab2-b88f448147f5`, startup 88 ms.
- Live Worker smoke tests: `GET /api/health` → `{"status":"ok","backend":"local"}`; `POST /api/convert` (preview) → HTTP 200, `application/pdf`, 1-page PDF; `POST /api/paginate` with `geometry: "v3"` → HTTP 200, `totalPages: 1`; `/` and `/shell.css` → HTTP 200.

**Risks**

- None known for Node or Worker behavior. The Worker path already preferred embedded font buffers, so it never needed `BLASTER_DIR`; the change only makes that fallback safe to evaluate.
- Deploy remains exposed to the documented Free-plan CPU budget during heavy `/api/convert` requests; this change does not address that.

## Worker text-spacing corruption — shared fontkit layout cache (2026-10-26)

**What changed**

- `src/v2/fonts/shaping.js`: `attachFkFontLayoutCache` now returns a per-call copy of the cached run (`Object.create(prototype)` + copied `positions`). The prototype is preserved so fontkit getters (`advanceWidth`, `advanceHeight`, `bbox`) still work; a spread-only copy produced `NaN` line widths and was discarded during verification.
- `tests/lean/shaping-layout-cache.lean.js`: new guard (`W14.1`/`W14.2`) proving a reused run is isolated from caller mutation and keeps a finite `advanceWidth`.
- `src/_worker.js`: bumped `RENDER_ENGINE_REVISION` to `2026-10-26-font-layout-cache-fix` so the persistent edge cache cannot keep serving pre-fix renders.
- `specs/05-OUTPUT.md`: documented the per-call isolation invariant. `specs/06-OPERATIONS.md`: troubleshooting row for stale cache after a deploy.

**Why**

Live Worker PDFs showed compressed text on every justified line, with the last run of a line displaced by up to ~101 pt versus Node. Raw content streams showed PDFKit emitting TJ adjustments of ~142–455 thousandths per glyph (Node emits only real kerning, e.g. 74). `EmbeddedFont.layoutRun` normalizes `positions` in place (`position[key] *= scale`, `advanceWidth = glyph.advanceWidth * scale`). The Wave 12 cache returned the same mutable run object from a fontkit font shared across documents in a Worker isolate, so every later document rescaled `xAdvance` again while `advanceWidth` was reset. With Arimo's 2048 upem (scale 0.488), the second pass yields `advanceWidth - xAdvance ≈ 0.25 × advance ≈ +282`, matching the observed numbers. Node opens a fresh font per document, so only the Worker corrupted; the first request in an isolate was clean, later ones were not. The user's export was hit through a cached render, so the cache revision had to change too.

**Verification**

- Pre-fix reproduction in a throwaway copy: cache returned the same object (`same object: true`) and caller mutation survived into the next call.
- `node --test tests/lean/shaping-layout-cache.lean.js`: `2/2` pass.
- `npm run test:all`: `321/321` across `79` suites (`VERIFY: PASS`) and `38/38` design tests.
- `npm run lint`, `npm run build`: pass; `dist/_worker.js` 6104.9 KB.
- `npx wrangler deploy`: version `30dfc129-28d6-4ebe-aa6c-82332c6ff625` (the preceding fix-only deploy `a1dc78e2…` still returned the cached pre-fix PDF, which is why the revision bump was required).
- Live Worker vs current-source Node, two distinct cache-busted payloads: page 1 `191/191` runs, page 2 `183/183` runs, identical text, `max|dx| = 0.00`, `max|dy| = 0.00`; output 120,426 / 120,434 bytes, the same sizes as Node.

**Risks**

- Cache-hit responses rendered before this version remain under the old revision key and are no longer addressable; no user data is lost.
- The clone adds one positions-array allocation per cached shape call. It was not benchmarked separately; correctness is required and PDFKit already caches per document.
- The user's already-downloaded `document-v2-modular-86.pdf` cannot be repaired retroactively; it must be re-exported.

## Flush lift overshoot collapsed multi-line atoms (2026-10-26)

**What changed**

- `src/v2/layout/glue-allocator.js`: `boundedLift(seams, ceilingPt, budgetPt)` takes an optional total budget; when the ramp's sum exceeds it, offsets are scaled down proportionally. Added `capShiftsToFoot(elements, shifts, contentBottomY, extentOf)`, which applies the foot guard by ownership group `(scope, seamSeq)` instead of per element.
- `src/v2/compiler/geometry-compiler.js`: `fundColumn` passes its own column void as the lift budget; the v3 sibling-sync branch does the same for the column it re-lifts. The application pass now uses `capShiftsToFoot`, so a multi-line atom receives one capped shift instead of a different cap per line.
- `tests/lean/percol-funding.lean.js`: unit guards for the lift budget (uncapped overshoots 9.66 pt, capped spends it) and for group-uniform foot clamping (three lines keep 11.82 pt spacing and land at the foot).
- `specs/04-LAYOUT.md`: documented the void-bound lift and ownership-group application.
- `src/_worker.js`: bumped `RENDER_ENGINE_REVISION` to `2026-10-26-flush-lift-budget-fix`.

**Why**

The user's bauhaus export (`document-v2-modular-87.pdf`) printed the three lines of “Hipertonia e dor muscular à compressão…” on one baseline at PDF `y = 37.89` (page 2, left column foot). The content streams matched the local render byte for byte, so this was an engine defect, not a Worker drift. On page 2, col:1 was over-cap (`partial-lift`) and the v3 sibling-sync branch replaced col:0's already-applied offsets with a per-seam `boundedLift`. Sixteen seams × the 3.55 pt ceiling summed to 38.54 pt against a 9.66 pt void, so every line was clamped independently to its own headroom (33.30 / 21.48 / 9.66 pt) and all three landed on the last line's baseline. The lift now spends at most the column's void, and the guard moves the atom as a unit if a cap ever applies.

**Verification**

- Reproduction with the user's exact markdown, template `bauhaus`, geometry `v3`: before the fix, 3 same-baseline collisions at page 2 `x = 58.35, y = 37.89`; after, 0 collisions on all 4 pages, and the item sits at `y = 772.63 / 784.47 / 796.30` (top-down) with 11.82 pt line spacing, 1.0 pt below the content foot.
- `npm test`: `323/323` pass across `79` suites (includes the two new guards).
- `npm run test:design`: `38/38` pass.
- `npm run test:all`: `VERIFY: PASS`, `323/323` + `38/38`.
- `npm run lint`, `npm run build`: pass; `dist/_worker.js` 6105.8 KiB.
- No corpus/`vertical-justify.json` golden changed: the corpus does not reach the v3 sibling-sync branch (scanned `sample1`, `sample2`, `sampletext2` × 3 templates, no hits), so the new unit guards are the branch's only coverage.
- Deployment: `npx wrangler deploy` with the user-supplied token (not written to the repository) succeeded; version `91ba5be3-aa4f-4103-a20a-863397b22ab4`, startup 81 ms.
- Live verification against `https://doe-formatter.rpsin9096.workers.dev`: `GET /api/health` → `ok`; `POST /api/convert` with the user's payload (template `bauhaus`, geometry `v3`) → HTTP 200, 194,975 bytes, 4 pages, 499 runs. Worker vs current-source Node: `499/499` runs, identical text, `max|dx| = 0.000`, `max|dy| = 0.000`; 0 same-baseline collisions. The three “Hipertonia” lines now sit at PDF `y = 61.56 / 49.73 / 37.89` (11.83 pt apart).

**Risks**

- The corpus does not exercise the sibling-sync branch, so an end-to-end golden for this exact class of page is still missing; the unit guards pin the arithmetic and grouping instead.
- Any already-downloaded export containing the overlap cannot be repaired retroactively; it must be re-exported after the deploy.

## Zero-placement table tail spun the region planner (2026-10-26)

**What changed**

- `src/v2/compiler/geometry-compiler.js`: the zero-placement guard now keys on `bite.length` (the items the planner failed to place) instead of `cursor < items.length`. Mid-page it defers the bite to a fresh page. At page top it row-splits an atomic table taller than the page, or places the first item alone, so the region cannot re-enter with the same state.
- `tests/lean/table-region-zero-placement.lean.js`: two child-process termination probes — three tables followed by a 16-row table on a 298.7 pt region, and a 220-row table on a fresh page.
- `specs/04-LAYOUT.md`: pagination rule 9 states the progress guarantee.
- `src/_worker.js`: bumped `RENDER_ENGINE_REVISION` to `2026-10-26-zero-placement-guard`.

**Why**

A cross-template audit (3 templates × 2 geometries × 9 documents, plus flag variants) found that a tall table placed after two other tables could hang the compiler. With 15 rows the document finished in 45 ms; 16 rows never finished. `GalleyEngine.planColumns` returned `col1=[]`, `col2=[]` and all four items in `unplaced` because the table no longer fit the 298.7 pt region. The bite had consumed the whole remaining stream, so `cursor === items.length` — the old guard's “content still queued” test was false. The continuous branch then set `cursor = biteStart` and re-entered the identical region. A trace run produced 490,870 lines in 3 seconds at 100% CPU. The post-bite cursor is not the queue; the unplaced bite is.

**Verification**

- `node --test tests/lean/table-region-zero-placement.lean.js`: `2/2` pass, the 16-row probe finishes in ~0.36 s and the 220-row page-split probe in ~0.36 s.
- `npm test`: `325/325` pass across `80` suites, no golden change.
- Cross-template audit after the fix: `87/87` cases ran to completion (3 templates × 2 geometries × 9 documents; flag variants for the five stress documents and the user document). No same-baseline collisions, intra-atom line overlaps, content-past-foot, divider escapes, bullet/line mismatches, or PDF-run collisions were found. The only scanner hits were a `bauhaus_minimalist`/v2 PDF foot heuristic reading a baseline 0.25 pt above the content foot as overflow; the display-list extent check and the baseline position agree that it is inside the frame, so this is a scanner tolerance issue, not a layout defect.

**Risks**

- The page-top fallback places the first item alone when the planner still returns an empty plan and no table can be split. That is a progress guarantee for a pathological all-unplaced state; it can produce a short column, but never a hang.
- The audit matrix is synthetic plus the three corpus documents. It does not replace a future golden for every template, and it does not cover the v3 decorator's defensive per-element foot clamp.
- A separate probe found a pre-existing atomic-item limit: one code block taller than a page (120 lines) is emitted whole and crosses the content foot. It is not the overlap class and was not changed here; code blocks are not line-split like paragraphs.

## Atomic list items were split despite `split_list_items: false` (2026-10-26)

**What changed**

- `src/v2/compiler/geometry-compiler.js`:
  - Reads `split_list_items` / `splitListItems` once per compile and marks every parsed list item with `splitAllowed`. `_splitParagraph` returns an atomic list item whole, so every call site (continuous fill, boundary refinement, tail parity, single-column path) honors the control.
  - When atomic list items leave a continuous plan with a material column disparity (more than two body pitches), the region switches to the existing multicol whole-item balancer instead of being cut line-by-line. A flush continuous page is left alone, so the repair does not shorten pages that were already full. The default `split_list_items: true` path is unchanged and still uses continuous fill.
  - The region-tail `parentListKeep` shrink is skipped for atomic list items, so a whole parent may end one column and its child may open the next in document order. The `stacked-sliver-order` guard remains active.
  - Display-list, block-flow, and parsed-item cache keys include the split flag; a cached `true` request can no longer satisfy a `false` request.
- `src/_worker.js`: bumped `RENDER_ENGINE_REVISION` to `2026-10-26-atomic-list-balance`.
- `tests/lean/atomic-list-balance.lean.js`: new two-assertion gate. It compiles a sanitized synthetic nested-list document with 30 preamble paragraphs and 20 list groups, records every list-item split call, and measures body column feet.
- `specs/03-INPUT.md`, `specs/08-LAYOUT-GEOMETRY-V3.md`: document the flag contract, the whole-item balanced partition, and the atomic-list exception to `parentListKeep`.

**Why**

The editor exposes “Dividir itens longos”, and both `pdf-engine.js` and the Worker forwarded `split_list_items`, but the v3 compiler never read it. With the control off, the user's `bauhaus` export still cut list items: page 2's right column ended at `y = 693.9` while the left ended at `805.8` (112 pt void), and page 3 opened mid-item at `intraperitoneal…` with no marker. The gap was produced by two interacting policies: the flag was ignored, and the nested-list `tailIsParentList` keep peeled whole parent chains to the next page. The user chose **atomic list items plus whole-item rebalancing**.

**Verification**

- New gate before the fix: `6` list-item splits and page 3 right column at `y = 488.1` vs left `y = 805.8` (317 pt void). After: `0` splits; every interior column in the fixture is at the region foot within `14 pt`.
- User document, `bauhaus`, `v3`, `split_list_items: false`: `0` list-item splits, `4` pages. Pages 1 and 2 are now `805.8 / 805.8`; page 2 was `805.8 / 693.9`. Page 3 opens with a whole `Critério de decisão…` bullet (no `intraperitoneal…` continuation). Page 3 ends at `727.4 / 751.0` before the page-4 table: the next atomic table cannot fit, so this residual is the granularity limit, not a split.
- User document, `base`, same flags: `0` splits, `4` pages, pages 1–3 flush at `801.0 / 801.0`.
- `npm test`: `327/327` pass across `81` suites (`VERIFY: PASS`).
- `npm run test:design`: `38/38` pass.
- `npm run lint`: pass. `npm run build`: pass; `dist/_worker.js` 6106.4 KB.
- No corpus golden changed. The corpus does not request `split_list_items: false`; the new behavior is covered by the synthetic gate and the user-document probe.

**Risks**

- Atomic list items can still leave a short column when the next whole item, group, or span does not fit, and glue may be at its capacity (the pre-table page above). This is the honest price of “never cut an item”; `split_list_items: true` remains the opt-out.
- The default remains `true` (spec contract and UI checked state). Atomic behavior requires the editor toggle to be off (or `split_list_items: false` in the API). Changing the default is a product decision and was not made here.
- The fix is local only. The Worker revision is bumped but has **not** been deployed; the live URL still serves the previous build until a deploy is requested and verified.
- Already-downloaded PDFs keep the old layout and must be re-exported.

## Atomic-list-balance build deployed to the live Worker (2026-10-26)

**What changed**

- No source change. Deployed the already-verified build (`RENDER_ENGINE_REVISION` `2026-10-26-atomic-list-balance`) to the Cloudflare Worker with `npx wrangler deploy`.

**Why**

- The atomic-list fix was local only; the live URL still served the previous build (see the entry above).

**Verification**

- `npx wrangler deploy`: upload `6386.76 KiB` (gzip `2815.63 KiB`), worker startup `99 ms`. The only warning is a pre-existing duplicate-key `axisIndex` diagnostic in the bundled chart library, unrelated to this change.
- `GET /api/health` on the live URL returns `{"status":"ok","service":"DOE Formatter Cloudflare","backend":"local"}`.
- Live-vs-local parity, user document, `base`, `split_list_items: false`: `4` pages each, `186703 B` each, `X-Cache: MISS` (fresh compute under the new revision), max text-run drift `0.000`, `0` text diffs.
- Live-vs-local parity, user document, `bauhaus`, `split_list_items: false`: `4` pages each, `194985 B` each, `X-Cache: MISS`, max drift `0.000`, `0` text diffs, `0` run-count mismatches. The live output is identical to the verified local render (`0` list-item cuts, pages 1–2 flush).

**Risks**

- The deploy credential was supplied in the conversation and used inline for the deploy only; it was not written to the repository. If the transcript may be shared, rotate the token.
- PDFs exported before this deploy keep the old layout; re-export from the editor to get the fixed layout.

## Spec sync and inspection handoff for the atomic-list fix (2026-10-26)

**What changed**

- `specs/03-INPUT.md`: the `split_list_items` row now documents the editor checkbox **Dividir itens longos** (checked by default) and where the store/export defaults live.
- `specs/04-LAYOUT.md`: pagination rule 4 states the list-item exception — items split only when `split_list_items` is `true`; when `false` they move whole and a disparate v3 region re-partitions by whole items — linking to the flag owner (03) and the mechanics owner (08 §5.9.3).
- `specs/07-TESTING.md`: baseline re-dated 2026-10-26 with fresh evidence (327/327 lean in 81 suites, 38/38 design, `AUDIT_ALL_PASS`, `ALL_VG_GATES=PASS` + `V2_FIXTURE_ROWS=157 V2_FIXTURE_DIFFS=0`, lint, build, live parity). Lean catalog count corrected 60 → 65 and given rows for `atomic-list-balance`, `table-region-zero-placement`, `shaping-layout-cache`, `worker-bundle-safety`, and `compiler-efficiency` (previously described only in the Wave 12 section).
- `specs/00-INDEX.md`: last-verified date and status numbers refreshed; the dangling spec-11 table row (it sat after the change-protocol section) was moved into the ownership table with a proper "does not own" cell.
- `HANDOFF-ATOMIC-LIST-FIX.md`: new agent handoff covering the change map with grep anchors, the rebalance mechanism, the verification protocol with expected outputs, the PDF/display-list coordinate-frame trap, deployment state, residuals, and review directions.

**Why**

The atomic-list fix updated its two owning specs during implementation, but the cross-referencing specs still described the 2026-10-25 snapshot: `07-TESTING` baseline numbers and the lean catalog were five files behind, `04-LAYOUT`'s pagination rules did not mention the list-item exception, `00-INDEX` carried stale verification numbers and a broken table row, and no spec recorded where the editor toggle maps to the flag. AGENTS.md requires the spec set and the index to describe the current system.

**Verification**

- Every number written into the specs was measured fresh on 2026-10-26 in this session: `npm test` (`VERIFY: PASS`; 327/327, 81 suites), `npm run test:design` (38/38), guardrails CLI (`AUDIT_ALL_PASS`), V3 gates (`ALL_VG_GATES=PASS`; `V2_FIXTURE_ROWS=157 V2_FIXTURE_DIFFS=0`), `npm run lint`, `npm run build` (6106.4 KB), live Worker parity (`X-Cache: MISS`, drift `0.000`, equal bytes/pages for base and bauhaus), production-path cut counts (`0` both templates), and display-list feet (bauhaus p1/p2 `805.8/805.8`, p3 `727.4/751.0`; base p1–p3 `801.0/801.0`).
- Catalog audit: every `tests/lean/*.lean.js` file (65) is now listed in `specs/07-TESTING.md`; the count was verified by scripted diff (previously 4 files were unlisted).
- Documentation only: no code, behavior, fixtures, or goldens changed, so no new test run was required beyond the fresh evidence above.

**Risks**

- Line numbers cited in the handoff for `geometry-compiler.js` will drift with future edits; grep anchors are provided next to each.
- The handoff references machine-local temp paths for the reproduction payload; those artifacts are outside the repository and may not survive cleanup. The durable regression evidence is the self-contained gate `tests/lean/atomic-list-balance.lean.js`.



---

## 2026-10-27 — Master Orchestration Specification v2.0 (Template-Aware Editorial Geometry, Fragmentation & Bottom-Padding Overhaul — Wave 13)

**What changed**

- **Deliverable A (`design-guardrails.config.json`):** Extended the Design Guardrails v3.0 configuration (preserving `schema`, `archetype`, `tokens`, `thresholds`, `typography`, `shape`, `states`, and `responsive` intact) with `defaults.geometry`, `defaults.fragmentation`, and 9 template profiles in `templates` (`default`, `base`, `bauhaus`, `bauhaus_minimalist`, `executive-report`, `legal-contract`, `compact-technical`, `landscape-dossier`, and `us-letter-brief`).
- **Deliverable B (`static/design-system.css` & `static/shell.css`):** Added `:root` template geometry custom properties (`--page-width`..`--first-page-footer-safe-zone`), `@page` / `@page :first` / `@page :left` / `@page :right` rules, `.virtual-page-preview` synchronization, orphan/widow (`orphans: 3; widows: 3`) and heading/list-intro glue rules, atomic container rules (`.callout-box`, `.advisory-box`, `.metric-card`, `.stat-card`, `.signature-zone`, `.metadata-panel`, `.stamp-row`, `.atomic-block`, `blockquote`, `figure`, `pre`, `.allow-emergency-split`), `.continuation-marker` / `.table-continuation-caption` / `.list-continuation-caption` rules (snapped to `--space-xs` `4px` grid and semantic `--color-text-muted` / `--font-sans` tokens), and `.js-forced-page-break` / `.is-page-bottom` / `.is-framed-box` / `@media print` rules.
- **Deliverable C (`static/editorial-geometry-engine.js`, `pdf-engine.js`, `src/v2/core/geometry.js`):** Implemented `EditorialGeometryEngine`, `normalizeEditorialGeometry`, and `verifyTemplateEditorialGeometry` in `static/editorial-geometry-engine.js` and re-exported them from `pdf-engine.js`, `pdf-generator.js`, and `static/editor-core.js`. Extended `PAGE_SIZES` in `src/v2/core/geometry.js` with `A3`, `A5`, and `TABLOID`.
- **Deliverable D (`pdf-generator.js`, `static/editor-core.js`, `static/v2-app.js`, `scripts/build-cloudflare.js`):** Added `generateEditorialPdf(page, outputPath, options)` in `pdf-generator.js`, `initializeEditorialPagination(editorRootElement, initialTemplateId)` in `static/editor-core.js`, wired workspace template synchronization in `static/v2-app.js`, and registered `editorial-geometry-engine.js` in `scripts/build-cloudflare.js`.
- **Specs & Tests (`specs/12-EDITORIAL-GEOMETRY-OVERHAUL-V2.md`, `specs/00-INDEX.md`, `scripts/probe-editorial-geometry-v2.mjs`, `tests/lean/editorial-geometry-v2.lean.js`, `tests/design/visual-w13-editorial-geometry.lean.js`):** Added Spec 12, the FocusGate probe (`gate-11`..`gate-13`), 5 behavioral test suites in `editorial-geometry-v2.lean.js`, and 3 CSS/config lock tests in `visual-w13-editorial-geometry.lean.js`.

**Why**

To adapt and implement the Master Orchestration Specification v2.0 (Template-Aware Edition) into Compilador do Raul using the FocusGate v1.0.0-UNIFIED Red-Before-Green workflow without breaking any existing V2/V3 PDFKit compilation paths, Cloudflare Worker bundles, or Design Guardrails v3.0 token and 4px-grid constraints.

**Verification**

- FocusGate (`scripts/focus_gate.py`): `gate-11-template-geometry-guardrails`, `gate-12-editorial-geometry-engine`, and `gate-13-pipeline-integration-and-6-gate-audit` baselined `RED` (`3 RED, 0 ALREADY_GREEN, 0 ERROR`) and settled `GREEN` with cryptographic receipts (`13/13 settled, 0 blockers`).
- `python3 scripts/design_guardrails.py --config design-guardrails.config.json --audit-all static --document DESIGN.md`: `AUDIT_ALL_PASS` (`0` errors, `0` warnings).
- `npm run lint`: pass.
- `npm test`: `9/9` verify suites pass; `332/332` lean tests pass across `82` suites (`0` failures).
- `npm run test:design`: `41/41` design tests pass across `10` suites (`0` failures).
