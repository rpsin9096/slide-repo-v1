# Compilador Studio Design System

**System Archetype:** `spacing_base: 4px` | `corners: soft (0, 4, 8, 12, 16, 9999px)` | `depth: hairline (0.5px/1px + surface flips)` | `type_lanes: 2 (sans + mono)` | `weight_ceiling: 600` | `content_cap: 1280px` | `breakpoints: [480, 768, 860, 1024, 1280]` | `mode: both (light + dark semantic overrides)`

## 1. Visual Theme & Atmosphere

Compilador Studio is a high-density editorial and document-compilation workspace engineered for long-form clinical, legal, and technical publishing. Its visual stance pairs crisp hairline geometry (`0.5px` and `1px` borders), neutral slate surfaces, and high-luminance typographic hierarchy so authors focus on block structure, live PDF pagination, and inline formatting without decorative noise.

## 2. Color Palette & Roles

All colors resolve through a strict three-layer custom-property graph (`primitive -> semantic -> component`) declared in `static/design-system.css`:

- **Primary Canvas & Surfaces**: Light mode pairs `{color.bg}` (`#eceef1`, cool editorial page gutter) with `{color.surface}` (`#ffffff`, primary card canvas) and `{color.surface-2}` (`#f6f7f9`, subtle control well). Dark mode (`html[data-theme="dark"]`) rebinds semantic tokens only to `{primitive.dark-page}` (`#17181b`), `{primitive.dark-surface}` (`#1c1d22`), and `{primitive.dark-surface-1}` (`#232429`).
- **Ink & Contrast Hierarchy**:
  - Light primary ink `{color.text}` (`#14151a`) on `{color.surface}` (`#ffffff`) measures **18.06:1** (WCAG AAA).
  - Light secondary ink `{color.text-secondary}` (`#52565f`) on `{color.surface}` (`#ffffff`) measures **7.32:1** (WCAG AAA).
  - Light muted ink `{color.muted}` (`#626770`) measures **5.30:1** on `{color.surface-2}` (`#f6f7f9`) and **4.89:1** on `{color.bg}` (`#eceef1`), clearing WCAG AA (`>= 4.5:1`) across every surface it lands on.
  - Dark primary ink `{primitive.dark-ink}` (`#f0f1f3`) on `{primitive.dark-surface}` (`#1c1d22`) measures **14.37:1**; dark muted ink `{primitive.dark-ink-mute}` (`#93969e`) measures **5.23:1** on `{primitive.dark-surface-1}` (`#232429`) and **4.58:1** on `{primitive.dark-surface-3}` (`#2c2e35`).
- **Single Accent Discipline**: Brand cobalt `{color.primary}` (`#2563eb`, hover `#1d4ed8`, foreground `{color.on-primary}` `#ffffff` at **5.17:1**) is confined to the primary `Gerar PDF` action, active state markers, `:focus-visible` rings (`{focus.glow}`), and inline links. In dark mode, small accent labels bind to `{color.accent-text}` (`#549af9`, **5.90:1** on dark surface).
- **Status & Scrims**: Semantic status roles `{color.danger}` (`#dc2626`), `{color.warn}` (`#b45309`), and `{color.ok}` (`#059669`) remain separate from the brand accent. Sheet and drawer overlays resolve exclusively through `{color.backdrop}`.

## 3. Typography

- **Two-Family Budget**: UI and editorial prose use `{font.body}` (`system-ui, -apple-system, "Segoe UI", Inter, Roboto, sans-serif`); raw Markdown syntax, code blocks, and counters use `{font.mono}` (`ui-monospace, "JetBrains Mono", Menlo, Consolas, monospace`).
- **Closed Scale & Line-Height Registers**:
  - Type scale steps: `10px` (`--font-size-3xs`), `11px` (`--font-size-2xs`), `12px` (`--font-size-xs`), `14px` (`--font-size-base` / `--editor-size`), `16px` (`--font-size-lg`), `18px` (`--font-size-xl`), `22px` (`--font-size-2xl`).
  - Both Markdown (`.box-md`) and Rich (`.rich-container`, `.bedit-ce`, `.bedit-preview`) editing surfaces lock to `14px` (`--editor-size`) with `line-height: 1.6`.
  - Headings apply `text-wrap: balance`; body and onboarding paragraphs apply `text-wrap: pretty`.
  - TOC page numbers (`.toc-preview-page`) and card character counters (`.char-count`) enforce `font-variant-numeric: tabular-nums`.

## 4. Components

- **Action Hierarchy**: Exactly one filled primary button (`.btn-primary`) appears per action cluster (desktop topbar or mobile bottom action bar). Companion controls use `.btn-ghost` or `.ticon`.
- **Block Cards (`.box-card`)**: Declare `{color.surface}` background, `{radius.card}` (`12px`), and `0.5px solid var(--line)` border. Card hover is hairline-only (`border-color: var(--line-strong)` with zero shadow lift). Card `:focus-within` renders the single token ring `var(--focus-glow)`.
- **Card Chrome & Editors**: Block toolbars (`.box-card > .toolbar-groups`) remain fully visible at rest (`opacity: 1`). Card footers (`.box-footer`) render as a `12px` muted bar with a top hairline (`var(--line)`), a pill-group mode switcher (`var(--radius-pill)`), and right-aligned `tabular-nums` character counts. Both `.box-md` and `.rich-container` share `12px` padding, `8px` radius, a `132px` floor, a `42vh` cap, and an inset top scroll cue.
- **Rich-Composer In-Flow Pill (`.rich-composer`)**: Renders as an in-flow centered pill (`position: relative; display: inline-flex; align-self: center; width: fit-content; margin-top: var(--space-xs); z-index: 2`) below the active `.rich-editor` block flow so `+ Inserir` never overlaps multi-paragraph rich blocks at any viewport width.
- **Full Five-State Matrix**: Every interactive control (`.btn`, `.ticon`, `.field-row`, `.segment`, `.acc-head`, `.bedit-ft-btn`) declares `default`, `@media (hover: hover)` `:hover`, `:focus-visible`, `:active`, and `:disabled` (flat muted surface `var(--surface-1)` + `var(--ink-mute)` + `cursor: not-allowed`).

## 5. Layout & Spacing

- **Global 4px Structural Base**: All spacing tokens and component dimensions snap to multiples of `4px` (`--space-2xs: 4px`, `--space-xs: 4px`, `--space-sm: 8px`, `--space-md: 8px`, `--space-lg: 12px`, `--space-xl: 16px`, `--space-2xl: 20px`, `--space-3xl: 24px`, `--space-4xl: 32px`, `--space-5xl: 40px`), reserving `0.5px–2px` strictly for hairlines and optical micro-gaps.
- **Pane & Control Rhythm**: Settings pane `button.field-row` sits on the `4pt` grid (`min-height: 32px`, `4px/8px` padding rhythm), and `.acc-head` carries a `4pt`-multiple `min-height`.
- **Workspace Grid**: Desktop pairs a fluid editor column (`max-width: 108ch`, left-aligned above `1280px`) with a docked `320px` sticky settings rail (`max-height: calc(100dvh - var(--topbar-h) - var(--space-2xl))`).

## 6. Depth & Elevation

- **Hairline & Surface-Flip Archetype**: In-flow cards, settings panes, and toolbars separate via `0.5px`/`1px` solid `var(--line)` hairlines and surface steps (`--page` -> `--surface-1` -> `--surface`).
- **Floating Portal & Bubble Elevation**: Only out-of-flow overlays (`.m-bubble`, `#ui-portal .bedit-quick-menu.portal-open`, modal sheets) use `var(--shadow-pop)`, clamping height to `calc(100vh - 16px)` with `overflow-y: auto`.

## 7. Do's and Don'ts

- **Do** resolve every color, border, background, and scrim through semantic and component tokens in `static/design-system.css`.
- **Don't** place raw `#hex` or `rgba()` literals inside `html[data-theme="dark"]`, `.m-bubble`, `.brand-mark`, or `.btn-primary`.
- **Do** keep all structural paddings, gaps, and control heights on multiples of the `4px` base unit (`32px` desktop icon controls, `44px–48px` mobile touch targets).
- **Don't** introduce off-step border radii (`5px`, `6px`, `7px`, `10px`, `18px`); use only the closed set `[0, 4, 8, 12, 16, 9999]px`.
- **Do** drive config accordion (`.config-body`) and card collapse (`.box-body`) through the cancellable two-phase `.is-closing` -> `.hidden` transition.
- **Don't** snap collapsible containers closed with immediate `display: none` or stack a `2px` browser outline on top of `var(--focus-glow)`.

## 8. Responsive Behavior

- **Single-Row Header & Bottom Bar**: Desktop `.topbar-center` and `.box-header-actions` stay single-row (`flex-wrap: nowrap`). Below `860px`, the settings rail converts into a bottom sheet (`max-height: 82dvh`, `border-radius: 16px 16px 0 0`) backed by `var(--color-backdrop)`, and `.mobile-action-bar .btn` stays single-line (`white-space: nowrap`, `min-height: 48px`).
- **Unified Mobile Action Sheet (`#sheet-body`)**: When mobile controls migrate into `#sheet-body`, all action buttons (`.btn`, `.file-btn`, `#add-box-btn`, `.ticon`) expand to full-width `48px` rows (`justify-content: flex-start; gap: 12px`), and `#sheet-body #add-box-btn .btn-long` un-hides (`display: inline`) so the `+ Novo bloco` label reads alongside `Importar .md`, `Exportar .md`, `Atalhos (?)`, and `Alternar tema`.
- **320px Floor & Multi-Viewport Inspection Matrix**: At `<= 359px` (`320x568` iPhone SE), `.brand-mark` (`24x24px`), `#add-box-btn` (`padding: 8px`), and `#toggle-settings-pane` (`40x40px`) fit on one row with zero horizontal page scroll (`scrollWidth <= clientWidth`). Verified across 9 headless Chromium viewports (`1440x900`, `1280x800` Light/Dark/Portal/Modal, `768x1024`, `375x812` Light/Dark Sheet, `320x568`, `667x375` Landscape).

## 9. Agent Prompt Guide

- **Token & Grid Contract**: Before editing `static/design-system.css` or `static/shell.css`, resolve all colors to `--primitive-*` -> `--color-*` tokens, snap all dimensions to `4px` multiples, and keep radii within `[0, 4, 8, 12, 16, 9999]px`.
- **Verification Command**: Run `python3 scripts/design_guardrails.py --config design-guardrails.config.json --audit-all static --document DESIGN.md && npm run test:design` before settling any gate in `.focusgate/GATES.md`.

## 10. Known Gaps

- **Motion Timings (`--duration-*`, `--ease-*`)**: Corpus brand sources do not export `prefers-reduced-motion` tokens; all transition timings (`75ms`, `120ms`, `200ms`, `280ms`) are documented practitioner recommendations governed by `@media (prefers-reduced-motion: reduce)`.
- **Font Metric Substitutions**: When local system faces (`system-ui`, `-apple-system`, `Segoe UI`) substitute for `Inter` or `JetBrains Mono`, line-height (`1.5` UI / `1.6` editor) and `font-display: swap` preserve vertical rhythm without external webfont blocking.
