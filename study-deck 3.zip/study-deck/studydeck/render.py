# -*- coding: utf-8 -*-
"""RENDER: monta o .pptx e devolve os pares que violaram WCAG.

O chamador decide se o arquivo sobrevive: com violacao de contraste o deck NAO
e entregue (o arquivo e apagado). Nao ha entrega parcial silenciosa.
"""

import os
import tempfile

from pptx import Presentation
from pptx.util import Inches

from . import primitives
from .contrast import ContrastGate
from .geometry import CANVAS_H, CANVAS_W
from .i18n import set_ui
from .registry import MODULES
from .contracts import _NO_HEADER_MODULES
from .primitives import footer, header, set_fallback_palette, set_gate
from .version import VERSION


def render(deck, out):
    """(n_slides, falhas_de_contraste) para um Deck carregado."""
    pal = deck.palette
    set_ui(deck.lang)
    gate = set_gate(ContrastGate())
    set_fallback_palette(pal)

    prs = Presentation()
    prs.slide_width = Inches(CANVAS_W)
    prs.slide_height = Inches(CANVAS_H)
    blank = prs.slide_layouts[6]

    for idx, data in enumerate(deck.slides, 1):
        module = str(data.get('module', ''))
        if module not in MODULES:
            raise KeyError(f'slide {idx}: modulo desconhecido {module!r}')
        gate.begin_slide(idx, module)
        slide = prs.slides.add_slide(blank)
        if module not in _NO_HEADER_MODULES:
            header(slide, pal, data)
            footer(slide, pal, idx, deck.course, deck.config)
        MODULES[module]['render'](slide, data, pal, deck.course_info)

    fails = gate.failures()
    if fails:
        try:
            os.remove(out)
        except OSError:
            pass
        return idx, fails
    prs.save(out)
    return idx, fails


def _render_once(slides, course='StudyDeck'):
    """(n, falhas) de UM render de uma lista de slides; o .pptx nunca sobra."""
    from .manifest import Deck
    deck = Deck('<fixture>', slides, {'course': course}, {'LANG': 'pt-BR'})
    tmp = tempfile.NamedTemporaryFile(suffix='.pptx', delete=False)
    tmp.close()
    try:
        return render(deck, tmp.name)
    finally:
        try:
            os.remove(tmp.name)
        except OSError:
            pass


def _self_test_isolated(slides):
    """Um render por slide: o caminho de EXCEPCAO, para dizer qual modulo quebrou."""
    out = []
    for slide in slides:
        name = str(slide.get('module'))
        try:
            _n, fails = _render_once([slide])
            ok = not fails
            detail = fails[0] if fails else None
        except Exception as exc:                       # noqa: BLE001 - self-test reporta
            ok, detail = False, f'{type(exc).__name__}: {exc}'
        out.append((name, ok, detail))
    return out


def self_test(verbose=False):
    """[(module, ok, detalhe)] dos 35 modulos, com UM render do fixture.

    Caminho feliz: o fixture inteiro renderiza uma vez e o veredicto por modulo
    sai do log de contraste, que ja carrega slide e modulo de cada entrada. O
    isolating por modulo continua existindo, mas so quando um modulo levanta —
    e um modulo que levanta aborta o render do deck, entao ali ele e a unica
    forma de saber *qual* foi.
    """
    from .fixtures import fixture_slides
    slides = fixture_slides()
    try:
        _n, fails = _render_once(slides)
    except Exception:                                  # noqa: BLE001 - cai no isolating
        return _self_test_isolated(slides)
    by_module = {}
    for entry in fails:
        by_module.setdefault(entry.get('module'), []).append(entry)
    out = []
    for slide in slides:
        name = str(slide.get('module'))
        bad = by_module.get(name) or []
        out.append((name, not bad, bad[0] if bad else None))
    return out


def failure_lines(fails, limit=8):
    """[str] das violacoes de contraste, no formato que a CLI imprime.

    `check`, `build` e `contrast` imprimem o mesmo par texto/superficie. Um
    formato em um lugar e o que impede os tres de divergirem em silencio.
    """
    out = []
    for cf in fails[:limit]:
        out.append(f"  X slide {cf.get('slide')} [{cf.get('module')}]: "
                   f"#{cf.get('fg')} sobre #{cf.get('bg')} = {cf.get('ratio')} "
                   f"(requer {cf.get('required')})")
    return out


def scan_contrast(deck):
    """Violacoes de contraste de um deck, sem gravar arquivo e sem lintar.

    O lint e a validacao do CONTRATO; quem pediu contraste nao pediu contrato.
    Rodar os dois e a validacao excessiva que este comando nao deveria pagar.
    """
    return _render_once(deck.slides, deck.course)[1]


__all__ = ['render', 'self_test', 'scan_contrast', 'failure_lines',
           'primitives', 'VERSION', 'MODULES']