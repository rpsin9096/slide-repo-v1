# -*- coding: utf-8 -*-
"""ESTILO DE PROSA UCP — guard das duas camadas lexicas do deck.

Adaptado do Thematic Consolidation Compiler v1.0 para o texto dos slides:

- **Layer A (dominio, travada)**: nosologia, anatomia, farmacologia e taxonomia
  ficam EXATAMENTE como na fonte — o guard nao toca nelas (isso e trabalho do
  autor, guiado pelo SYSTEM_PROMPT).
- **Layer B (conectiva, guardada aqui)**: verbos operativos no indicativo, sem
  muleta introdutoria, metafora dramatica, quantificador vago nem rabo de
  participio.

So entra na lista de bloqueio o termo que NUNCA e linguagem clinica literal.
Palavras de dupla vida ('colapso', 'fulminante', 'catastrófico') vivem em
CONTEXTUAL: passam com o qualificador literal na mesma frase, caem sem ele.
"""

import re
import unicodedata

_FAMILIES = {
    'pt-BR': {
        'STYLE_CRUTCH': {
            'hint': 'corte a muleta; comece pelo fato',
            'terms': ('vale destacar que', 'cabe ressaltar que', 'cabe destacar que',
                      'e imperioso notar', 'como e sabido', 'em suma',
                      'diante do exposto', 'e importante lembrar',
                      'e importante destacar', 'neste cenario', 'sob essa otica',
                      'podemos dizer que', 'convem notar que'),
        },
        'STYLE_METAPHOR': {
            'hint': 'metafora banida; use o verbo operacional',
            'terms': ('arsenal', 'trincheira', 'blindar', 'detonar', 'devastar',
                      'vertiginoso', 'colossal', 'revolucionario',
                      'dramatico', 'dramaticamente', 'desatar', 'deflagrar', 'orquestrar',
                      'harmonizar', 'trampolim', 'armas terapeuticas',
                      'arma terapeutica', 'ferramenta terapeutica'),
        },
        'STYLE_VAGUE': {
            'hint': 'quantifique; reproduza o numero da fonte',
            'terms': ('diversos', 'diversas', 'inumeros', 'inumeras',
                      'entre outros', 'relativamente', 'comumente',
                      'em geral', 'varios', 'varias', 'etc'),
        },
        'STYLE_TAIL': {
            'hint': 'rabo de participio: o fato derivado ganha campo proprio',
            'patterns': (r',\s*gerando\b', r',\s*cursando com\b', r',\s*trazendo\b',
                         r',\s*resultando em\b', r',\s*levando a\b',
                         r',\s*provocando\b', r',\s*causando\b'),
        },
    },
    'es-ES': {
        'STYLE_CRUTCH': {
            'hint': 'corte la muleta; comience por el hecho',
            'terms': ('cabe resaltar que', 'cabe destacar que',
                      'vale la pena destacar', 'vale la pena señalar',
                      'es imperioso notar', 'como es sabido', 'en resumen',
                      'en sintesis', 'frente a lo expuesto',
                      'es importante recordar', 'es importante destacar',
                      'en este escenario', 'podemos decir que', 'conviene notar que'),
        },
        'STYLE_METAPHOR': {
            'hint': 'metafora banida; use el verbo operacional',
            'terms': ('arsenal', 'trinchera', 'blindar', 'detonar', 'devastar',
                      'vertiginoso', 'colosal', 'revolucionario',
                      'dramatico', 'dramaticamente', 'desatar', 'deflagrar', 'orquestar',
                      'armonizar', 'trampolin', 'armas terapeuticas',
                      'arma terapeutica', 'herramienta terapeutica'),
        },
        'STYLE_VAGUE': {
            'hint': 'cuantifique; reproduzca el numero de la fuente',
            'terms': ('diversos', 'diversas', 'innumerables', 'entre otros',
                      'relativamente', 'comunmente', 'en general',
                      'varios', 'varias', 'etc'),
        },
        'STYLE_TAIL': {
            'hint': 'participio suelto: el hecho derivado gana campo propio',
            'patterns': (r',\s*generando\b', r',\s*cursando con\b', r',\s*trayendo\b',
                         r',\s*dando lugar a\b', r',\s*provocando\b', r',\s*causando\b'),
        },
    },
    'en-US': {
        'STYLE_CRUTCH': {
            'hint': 'cut the crutch; start with the fact',
            'terms': ('it is worth noting', 'it is important to note',
                      'it is important to remember', 'as is well known',
                      'needless to say', 'in summary', 'in this scenario',
                      'we can say that', 'it should be noted'),
        },
        'STYLE_METAPHOR': {
            'hint': 'banned metaphor; use the operational verb',
            'terms': ('arsenal', 'battleground', 'battlefield', 'shield',
                      'detonate', 'devastate', 'dizzying', 'colossal',
                      'revolutionary', 'dramatic', 'dramatically', 'unleash', 'orchestrate',
                      'harmonize', 'springboard', 'therapeutic weapons',
                      'therapeutic tool'),
        },
        'STYLE_VAGUE': {
            'hint': 'quantify; reproduce the number from the source',
            'terms': ('several', 'numerous', 'various', 'among others',
                      'relatively', 'commonly', 'in general', 'etc'),
        },
        'STYLE_TAIL': {
            'hint': 'loose participle: the derived fact earns its own field',
            'patterns': (r',\s*generating\b', r',\s*causing\b', r',\s*bringing\b',
                         r',\s*leading to\b', r',\s*resulting in\b'),
        },
    },
}

# Palavras de dupla vida: uso literal clinico passa com o qualificador na
# mesma frase; sem qualificador, e figura de retorica e o lint bloqueia.
_CONTEXTUAL = {
    'pt-BR': {
        'colapso': ('hemodinamico', 'cardiogenico', 'cardiocirculatorio',
                    'cardiovascular'),
        'fulminante': ('hepatite', 'miocardite', 'edema', 'malaria'),
        'catastrofico': ('antifosfolipide', 'antifosfolipidea'),
    },
    'es-ES': {
        'colapso': ('hemodinamico', 'cardiogenico', 'cardiocirculatorio'),
        'fulminante': ('hepatitis', 'miocarditis', 'edema', 'malaria'),
        'catastrofico': ('antifosfolipido', 'antifosfolipidea'),
    },
    'en-US': {
        'collapse': ('hemodynamic', 'cardiogenic', 'cardiovascular'),
        'fulminant': ('hepatitis', 'myocarditis', 'edema', 'malaria'),
        'catastrophic': ('antiphospholipid',),
    },
}

_SENTENCE = re.compile(r'[^.!?;]+')
_SUFFIX = r'(?:s|es|ed|ing)?'


def _plain(text):
    """minusculas sem acento: 'Inúmeros' -> 'inumeros' (comparacao estavel).

    NFKD decompoe o acento em base + marca combinante; a marca se REMOVE
    (nao se mapeia: a chave precomposta nunca aparece pos-NFKD).
    """
    low = unicodedata.normalize('NFKD', str(text).lower())
    return ''.join(ch for ch in low if not unicodedata.combining(ch))


def _word_pattern(term):
    """Borda de palavra + inflexao verbal comum: 'orchestrate' pega 'orchestrates'."""
    return re.compile(r'(?<!\w)' + re.escape(term) + _SUFFIX + r'(?!\w)')


def style_hits(text, lang='pt-BR', allow=()):
    """[(termo, codigo, hint)] das violacoes de Layer B no texto.

    `allow` exime termos pontuais (mesma lista de ALLOW_TERMS do drift: um
    nome proprio, um termo estrangeiro deliberado) — e por termo, nao por
    texto inteiro.
    """
    if not isinstance(text, str) or not text.strip():
        return []
    families = _FAMILIES.get(lang) or _FAMILIES['pt-BR']
    contextual = _CONTEXTUAL.get(lang) or _CONTEXTUAL['pt-BR']
    allow = {_plain(t) for t in allow}
    out = []
    for sentence in _SENTENCE.findall(text):
        plain = _plain(sentence)
        for code, spec in families.items():
            for term in spec.get('terms', ()):
                if _plain(term) in allow:
                    continue
                if _word_pattern(_plain(term)).search(plain):
                    out.append((term, code, spec['hint']))
            for pattern in spec.get('patterns', ()):
                if re.search(pattern, plain):
                    out.append((pattern, code, spec['hint']))
        for word, qualifiers in contextual.items():
            if _word_pattern(word).search(plain) and _plain(word) not in allow:
                if not any(_plain(q) in plain for q in qualifiers):
                    out.append((word, 'STYLE_LITERAL',
                                'uso figurado de termo clinico; so o sentido '
                                'literal qualificado passa'))
    return out