# -*- coding: utf-8 -*-
"""Lienzo, zona segura, reparto de tarjetas y densidad de contenido.

La asimetria 0.650 / 0.683 (borde derecho de facto 12.65) es historica y
CANONICA: no se "corrige" en silencio porque cambiaria la composicion de los
35 modulos calibrados contra ella.

La banda de contenido tiene un solo dono: aqui. `CONTENT_BAND_H` (4.95) y
`CONTENT_BOTTOM` (6.60) son los numeros que los renderers ya escribian a mao.

La densidad se DECIDE, no se declara: `tier_for` mide el contenido en el tier
STANDARD una unica vez y devuelve COMPACT cuando no cabe. No remede, no escala
para un tercer tier, no vuelve a renderizar. Si aun asi no cabe, el gate de
ajuste lo reporta — el motor no disimula un desborde afinando la caja.
"""

from collections import namedtuple

from .typography import est_height

CANVAS_W, CANVAS_H = 13.333, 7.500
SAFE_X0, SAFE_Y0 = 0.650, 1.550
CONTENT_W = 12.0                  # de facto: 0.650 + 12.0 = borde 12.65
CONTENT_H = 5.05                  # banda de contenido SAFE_Y0 -> 6.60
FOOTER_Y = 6.98

FOOTNOTE_GUTTER = 0.10            # el pie analitico vive en esta franja
CONTENT_BOTTOM = SAFE_Y0 + CONTENT_H      # 6.60
CONTENT_BAND_H = CONTENT_H - FOOTNOTE_GUTTER   # 4.95, la banda de facto

# Cajas medidas: nombres proprios donde antes havia una COORDENada fazendo el
# papel de una MEDIDA. El valor no estaba mal — el nombre sim, y nadie sabia
# por que era aquele.
HEADER_TITLE_H = 0.65             # titular de cabecera: y=0.58 ate as pills de 1.28
                                # (o titulo de 75 car. sao 2 linhas = 0.73 in: cabe
                                #  dentro da tolerancia do oraculo, mas a caixa nao
                                #  promete mais que isso. Medido, nao estimado.)
ELABORATION_H = 0.65              # faixa de `elaboration` dentro do cartao de 0.85
ROOT_CARD_TEXT_H = 1.55           # texto do cartao de raiz da etimologia (cartao 1.85)

# Pisos que el oraculo visual exige: 9.0 pt en etiqueta, 10.5 pt en cuerpo
# con mas de 40 caracteres. El COMPACT puede bajar el tamano, nunca abaixo de
# estos numeros.
TYPE_FLOOR_PT = 9.0
BODY_FLOOR_PT = 10.5

# Un tier es metro, no comportamiento: gap entre filas, pad por fila, tope
# estetico de altura y el factor del unico paso de tipo. `cap=None` significa
# "sin tope": la caja crece hasta conter el texto.
Tier = namedtuple('Tier', 'gap pad cap scale')

STANDARD = Tier(gap=0.16, pad=0.25, cap=1.20, scale=1.00)
COMPACT = Tier(gap=0.10, pad=0.18, cap=None, scale=0.94)

CARD_INSET = 0.15             # recuo que o motor ja deixa de cada lado do texto


def stack_layout(y0, zone_h, n, gap, cap=None):
    """Alto de fila con tope + desplazamiento vertical para centrar el grupo."""
    n = max(n, 1)
    row_h = (zone_h - gap * (n - 1)) / n
    if cap:
        row_h = min(row_h, cap)
    return row_h, y0 + (zone_h - (row_h * n + gap * (n - 1))) / 2.0


def row_layout(x0, total_w, n, gap, center=False):
    """Hermano horizontal de stack_layout: ancho de item + x de inicio."""
    n = max(n, 1)
    item_w = min((total_w - gap * (n - 1)) / n, total_w)
    if center:
        item_w = min(1.35, item_w)
        x0 = x0 + (total_w - (item_w * n + gap * (n - 1))) / 2.0
    return item_w, x0


def type_pt(size, tier, long=False):
    """Tamano del cuerpo en este tier, con piso: un paso abajo, nunca abaixo do piso."""
    if tier.scale >= 1.0:
        return float(size)
    floor = BODY_FLOOR_PT if long else TYPE_FLOOR_PT
    return max(float(size) * tier.scale, floor)


def _row_height(texts, box_w, size, tier):
    """Alto que necesita UNA fila para conter el texto mas largo de la lista."""
    pt = type_pt(size, tier, long=True)
    return max((est_height(t, box_w, pt) for t in texts), default=0.0)


def tier_for(texts, box_w, size, zone_h):
    """STANDARD si el contenido cabe en la zona; COMPACT si no cabe. Una sola medida."""
    items = [str(t) for t in (texts or []) if str(t)]
    n = max(len(items), 1)
    needed = (n * _row_height(items, box_w, size, STANDARD)
              + n * STANDARD.pad + max(n - 1, 0) * STANDARD.gap)
    return STANDARD if needed <= zone_h else COMPACT


def _stack_metrics(y0, zone_h, items, box_w, size, cap, gap):
    """(row_h, y_first, tier) — la unica medida de una columna de tarjetas."""
    n = max(len(items), 1)
    tier = tier_for(items, box_w, size, zone_h)
    metric = tier.gap if gap is None else gap * tier.gap / STANDARD.gap
    ceiling = (tier.cap if cap is None else cap) if tier is STANDARD \
        else _row_height(items, box_w, size, tier)
    row_h, y_first = stack_layout(y0, zone_h, n, metric, ceiling)
    return row_h, y_first, tier


def stack(y0, zone_h, texts, size, cap=None, gap=None, box_w=CONTENT_W):
    """Alto de fila + y de inicio no tier que o conteudo merece.

    `gap` e o metro do modulo: cada renderer tem o seu ritmo. No STANDARD ele
    manda; no COMPACT ele encolhe na proporcao do tier, para o cartao nao
    perder a identidade visual que o modulo construiu.

    Em STANDARD devolve exatamente lo que devolvia `stack_layout` com los
    metros do modulo. En COMPACT la fila toma su altura del texto: el tope
    estetico se apaga para no esconder un desborde dentro del carton.
    """
    items = [str(t) for t in (texts or []) if str(t)]
    row_h, y_first, _tier = _stack_metrics(y0, zone_h, items, box_w, size, cap, gap)
    return row_h, y_first


def stack_typed(y0, zone_h, texts, size, cap=None, gap=None, box_w=CONTENT_W):
    """(row_h, y_first, size_pt) — los metros y el tipo de la MISMA decision.

    Sin esto un modulo mide con `tier_for` y despues dimensiona el tipo con
    `type_pt`: dos llamadas que hoy coinciden y manana pueden divergir.
    """
    items = [str(t) for t in (texts or []) if str(t)]
    row_h, y_first, tier = _stack_metrics(y0, zone_h, items, box_w, size, cap, gap)
    return row_h, y_first, type_pt(size, tier, long=True)


def fit_pt(text, box_w, box_h, start_pt=12.0, long=False):
    """El mayor cuerpo que cabe en la caja, sin bajar del piso editorial.

    El inverso de `block_height`: mientras aquel responde "que altura pide el
    texto", este responde "que cuerpo cabe en la altura que tengo". Un bloque
    estrecho de la piramide lo necesita — y cuando NADA cabe, gana el piso: la
    legibilidad no se negocia con la geometria.
    """
    floor = BODY_FLOOR_PT if long else TYPE_FLOOR_PT
    size = float(start_pt)
    while size > floor and est_height(str(text), box_w, size) > box_h:
        size -= 0.5
    return max(size, floor)


def tier_for_block(text, box_w, size, slot_h):
    """STANDARD se un bloque suelto cabe en la vaga; COMPACT si no cabe."""
    needed = est_height(str(text), box_w, type_pt(size, STANDARD, long=True)) \
        + 2 * CARD_INSET
    return STANDARD if needed <= slot_h else COMPACT


def block_height(text, box_w, size, slot_h, tier):
    """Altura del CARTON que contiene el bloque: lo que el texto pide, mas el
    recuo de los dos lados, nunca mas que la vaga."""
    needed = est_height(str(text), box_w, type_pt(size, tier, long=True)) \
        + 2 * CARD_INSET
    return min(needed, slot_h)