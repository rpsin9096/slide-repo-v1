# -*- coding: utf-8 -*-
"""ESTILO DE PROSA UCP: duas camadas lexicas para o texto dos slides.

Adaptado do Thematic Consolidation Compiler para autoria de decks:
- Layer A (dominio): termos clinicos/anatomicos/farmacologicos intactos.
- Layer B (conectiva): verbos operativos no indicativo, sem metafora, sem
  muleta introdutoria, sem quantificador vago, sem participo solto.

O guard bloqueia so o que e provavel por maquina (listas curadas com
excecao literal: 'colapso hemodinamico' passa, 'colapso' figurado nao);
as regras de julgamento vivem no SYSTEM_PROMPT para o autor.
"""

import unittest

from studydeck import manifest as MF
from studydeck import lint as L
from studydeck.style import style_hits


def hits(text, lang='pt-BR', **kw):
    return style_hits(text, lang, **kw)


class TestCrutches(unittest.TestCase):
    """Muletas introdutorias: o slide comeca pelo fato, nao pelo preambulo."""

    def test_portuguese_crutch_is_blocked(self):
        self.assertTrue(any(code == 'STYLE_CRUTCH'
                            for _t, code, _h in hits('E importante destacar que a inflamação é vascular.')))

    def test_spanish_crutch_is_blocked(self):
        self.assertTrue(any(code == 'STYLE_CRUTCH'
                            for _t, code, _h in hits('Cabe resaltar que la inflamación es vascular.', 'es-ES')))

    def test_english_crutch_is_blocked(self):
        self.assertTrue(any(code == 'STYLE_CRUTCH'
                            for _t, code, _h in hits('It is important to note that inflammation is vascular.', 'en-US')))


class TestMetaphorFamilies(unittest.TestCase):
    """Metaforas dramaticas: o verbo operacional substitui a figura."""

    def test_arsenal_is_blocked(self):
        self.assertTrue(any(code == 'STYLE_METAPHOR'
                            for _t, code, _h in hits('O arsenal terapêutico reduz a mortalidade.')))

    def test_english_orchestrate_is_blocked(self):
        self.assertTrue(any(code == 'STYLE_METAPHOR'
                            for _t, code, _h in hits('The pathway orchestrates the immune response.', 'en-US')))

    def test_literal_clinical_word_with_qualifier_passes(self):
        self.assertEqual(hits('O colapso hemodinâmico reduz o débito urinário.'), [])

    def test_figurative_collapse_is_blocked(self):
        self.assertTrue(any(code == 'STYLE_LITERAL' and 'colapso' in t
                            for t, code, _h in hits('O colapso do sistema de saúde eleva a mortalidade.')))

    def test_hepatite_fulminante_literal_passes(self):
        self.assertEqual(hits('A hepatite fulminante leva a insuficiência hepática em dias.'), [])

    def test_figurative_fulminante_is_blocked(self):
        self.assertTrue(any(code == 'STYLE_LITERAL' and 'fulminante' in t
                            for t, code, _h in hits('A resposta fulminante do sistema imune devasta o tecido.')))

    def test_catastrophic_antiphospholipid_literal_passes(self):
        self.assertEqual(hits('A síndrome catastrófica de antifosfolípide oclui a microcirculação.'), [])


class TestVagueQuantifiers(unittest.TestCase):
    """Quantificador vago: reproduza o numero da fonte ou nao afirme."""

    def test_portuguese_vague_is_blocked(self):
        self.assertTrue(any(code == 'STYLE_VAGUE'
                            for _t, code, _h in hits('Diversos fatores elevam a pressão arterial.')))

    def test_english_various_is_blocked(self):
        self.assertTrue(any(code == 'STYLE_VAGUE'
                            for _t, code, _h in hits('Various mechanisms elevate blood pressure.', 'en-US')))

    def test_explicit_number_passes(self):
        self.assertEqual(hits('Três fatores elevam a pressão arterial.'), [])


class TestLooseTails(unittest.TestCase):
    """Rabo de participio: fato derivado ganha o proprio campo, nao o rabo."""

    def test_portuguese_generating_tail_is_blocked(self):
        self.assertTrue(any(code == 'STYLE_TAIL'
                            for _t, code, _h in hits('A lesão endotelial aumenta a permeabilidade, gerando edema.')))

    def test_english_resulting_in_tail_is_blocked(self):
        self.assertTrue(any(code == 'STYLE_TAIL'
                            for _t, code, _h in hits('Endothelial injury raises permeability, resulting in edema.', 'en-US')))

    def test_coordinated_clause_is_not_a_tail(self):
        self.assertEqual(hits('A lesão aumenta a permeabilidade e provoca edema.'), [])


class TestHonestyOfTheGuard(unittest.TestCase):
    def test_substring_inside_a_word_does_not_trip(self):
        self.assertEqual(hits('A conversa sobre diversão não é slide.'), [])

    def test_empty_text_is_clean(self):
        self.assertEqual(hits(''), [])

    def test_real_clinical_prose_is_clean(self):
        clean = ('A histamina liga-se ao receptor H1 e provoca vasodilatação '
                 'arteriolar; o aumento da permeabilidade capilar acumula exsudato '
                 'proteico no interstício.')
        self.assertEqual(hits(clean), [])

    def test_allow_terms_exempt_a_specific_word(self):
        text = 'O arsenal hospitalar é restrito.'
        self.assertTrue(hits(text))
        self.assertEqual(hits(text, allow=('arsenal',)), [])

    def test_hit_carries_a_hint(self):
        for _term, _code, hint in hits('Vale destacar que a resposta é vascular.'):
            self.assertTrue(hint.strip())


class TestLintIntegration(unittest.TestCase):
    def _check(self, slides, lang='pt-BR'):
        return L.check(slides, lang)

    def test_slide_with_crutch_fails_lint_with_the_style_code(self):
        slide = {'module': 'definition', 'kicker': 'Conceito', 'title': 'Inflamação',
                 'main_statement': 'É importante destacar que a resposta é vascular.',
                 'key_points': [{'title': 'Vascular', 'desc': 'Vasodilatação direta.'},
                                {'title': 'Celular', 'desc': 'Neutrófilos chegam primeiro.'}]}
        errs = self._check([slide])
        self.assertTrue(any('STYLE_CRUTCH' in e for e in errs))

    def test_clean_slide_has_no_style_errors(self):
        slide = {'module': 'definition', 'kicker': 'Conceito', 'title': 'Inflamação',
                 'main_statement': 'A histamina provoca vasodilatação arteriolar imediata.',
                 'key_points': [{'title': 'Vascular', 'desc': 'Vasodilatação direta.'},
                                {'title': 'Celular', 'desc': 'Neutrófilos chegam primeiro.'}]}
        errs = self._check([slide])
        self.assertEqual([e for e in errs if 'estilo' in e], [])

    def test_spanish_slide_is_checked_in_spanish(self):
        slide = {'module': 'definition', 'kicker': 'Concepto', 'title': 'Inflamación',
                 'main_statement': 'Cabe resaltar que la respuesta es vascular.',
                 'key_points': [{'title': 'Vascular', 'desc': 'Vasodilatación directa.'},
                                {'title': 'Celular', 'desc': 'Los neutrófilos llegan primero.'}]}
        errs = self._check([slide], 'es-ES')
        self.assertTrue(any('STYLE_CRUTCH' in e for e in errs))

    def test_example_deck_passes_the_style_guard(self):
        deck = MF.load('examples/ejemplo_inflamacao.py')
        errs = L.check(deck.slides, deck.lang, deck.images, deck.allow_terms)
        self.assertEqual([e for e in errs if 'estilo' in e], [])


if __name__ == "__main__":
    unittest.main()