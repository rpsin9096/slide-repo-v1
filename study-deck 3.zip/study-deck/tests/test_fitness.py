# -*- coding: utf-8 -*-
"""FITNESS RATCHETS: regras estructurales que solo pueden endurecerse.

Cada test falla hoy si alguien reintroduce la deuda que este rebuild elimino:
el doble bloque de presupuestos, el cajon `utils`, los modulos gordos y las
dependencias que apuntan hacia afuera.
"""

import ast
import pathlib
import unittest

PKG = pathlib.Path(__file__).resolve().parent.parent / 'studydeck'
MODULES = PKG / 'modules'
SOURCE_DIRS = ('contracts.py', 'authoring.py', 'registry.py', 'lint.py',
               'render.py', 'cli.py', 'manifest.py', 'images.py', 'imagedata.py',
               'primitives.py', 'palette.py', 'geometry.py', 'i18n.py',
               'typography.py', 'contrast.py', 'fixtures.py', 'ingest.py',
               'version.py', '__init__.py', '__main__.py', 'scaffold.py', 'style.py')

# Dois tetos subiram nesta refatoracao, e o motivo e' o mesmo: M2c e M2d
# trocaram logica por motivo, nao por prosa. Recusar encolher a explicacao do
# redesenho para caber num contador produz codigo pior. Continuam sendo tetos.
SIZE_CAPS = {
    'core.py': 410, 'diagram.py': 235, 'scholarly.py': 315, 'pedagogy.py': 210,
    'contracts.py': 405, 'primitives.py': 295, 'cli.py': 300, 'lint.py': 135,
    'registry.py': 135, 'images.py': 185, 'render.py': 140, 'style.py': 181,
}

JUNK_DRAWERS = ('utils.py', 'helpers.py', 'common.py', 'misc.py', 'tools.py')

INWARD_OK = {'contrast', 'geometry', 'i18n', 'images', 'primitives', 'typography',
             'contracts', 'version'}

OUTWARD = {'lint', 'render', 'cli', 'registry', 'manifest', 'fixtures'}


def py_files():
    yield PKG / '__init__.py'
    for name in SOURCE_DIRS:
        yield PKG / name
    for path in sorted(MODULES.glob('*.py')):
        yield path


def lines(path):
    return len(path.read_text(encoding='utf-8').splitlines())


def imports_of(path):
    tree = ast.parse(path.read_text(encoding='utf-8'))
    out = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            if node.level and node.module:
                out.add(node.module.split('.')[0])
            elif node.level == 0 and node.module:
                out.add(node.module.split('.')[0])
        elif isinstance(node, ast.Import):
            for alias in node.names:
                out.add(alias.name.split('.')[0])
    return out


class TestNoJunkDrawer(unittest.TestCase):
    def test_no_junk_drawer_modules(self):
        found = [p.name for p in PKG.rglob('*.py') if p.name in JUNK_DRAWERS]
        self.assertEqual(found, [], f'cajon de utilidades rejeitado: {found}')

    def test_package_has_the_expected_files_only(self):
        actual = {p.name for p in PKG.rglob('*.py')}
        allowed = set(SOURCE_DIRS) | {p.name for p in MODULES.glob('*.py')}
        self.assertEqual(actual - allowed, set())


LEGACY_PALETTE_WORDS = ('oxford', 'harvard', 'yale', 'cambridge')
LEGACY_PALETTE_HEX = ('002147', 'B08D57', 'A51C30', 'B88B4A',
                      '0F4D92', 'C5A059', '1B365D', '007788')


class TestNoLegacyPalette(unittest.TestCase):
    """UCP-only: ninguna palabra ni hex de las paletas retirementadas sobrevive.
    `oxford_union` es el nombre de un modulo de debate, no una paleta."""

    def _sources(self):
        yield from py_files()
        for name in ('README.md', 'prompt.md', 'SYSTEM_PROMPT.md'):
            path = pathlib.Path(__file__).resolve().parent.parent / name
            if path.exists():
                yield path

    def test_no_legacy_palette_word_outside_the_debate_module(self):
        offenders = []
        for path in self._sources():
            body = path.read_text(encoding='utf-8').lower().replace('oxford_union', '')
            for word in LEGACY_PALETTE_WORDS:
                if word in body:
                    offenders.append(f'{path.name}:{word}')
        self.assertEqual(offenders, [], f'paleta legada ainda citada: {offenders}')

    def test_no_legacy_palette_hex_anywhere(self):
        offenders = [p.name for p in self._sources()
                     if any(hx in p.read_text(encoding='utf-8').upper()
                            for hx in LEGACY_PALETTE_HEX)]
        self.assertEqual(offenders, [])


class TestSingleWriter(unittest.TestCase):
    def _toplevel_assigns(self, path):
        tree = ast.parse(path.read_text(encoding='utf-8'))
        return {t.id for n in tree.body if isinstance(n, ast.Assign)
                for t in n.targets if isinstance(t, ast.Name)}

    def test_character_budgets_are_written_once(self):
        owners = [p.name for p in py_files() if 'B' in self._toplevel_assigns(p)
                  and p.name != 'contracts.py'
                  and 'B' in self._toplevel_assigns(p)]
        self.assertEqual(owners, [], 'presupuestos duplicados fora de contracts.py')

    def test_required_fields_are_written_once(self):
        owners = [p.name for p in py_files()
                  if 'REQUIRED_NONEMPTY' in self._toplevel_assigns(p)
                  and p.name != 'contracts.py']
        self.assertEqual(owners, [])

    def test_no_module_table_is_built_outside_the_registry(self):
        owners = [p.name for p in py_files()
                  if 'MODULES' in self._toplevel_assigns(p) and p.name != 'registry.py']
        self.assertEqual(owners, [])

    def test_contracts_exposes_the_single_budget_object(self):
        import studydeck.contracts as c
        import studydeck.registry as r
        self.assertIs(c.B, r.B)


class TestSizeRatchet(unittest.TestCase):
    def test_every_source_file_is_inside_its_cap(self):
        for path in py_files():
            with self.subTest(file=path.name):
                cap = SIZE_CAPS.get(path.name)
                if cap is not None:
                    self.assertLessEqual(lines(path), cap,
                                         f'{path.name} passo do teto de {cap} linhas')

    def test_no_file_exceeds_the_global_cap(self):
        for path in py_files():
            with self.subTest(file=path.name):
                self.assertLessEqual(lines(path), 460)

    def test_legacy_reference_is_not_inside_the_package(self):
        self.assertFalse((PKG / 'legacy_studydeck_reference.py').exists())


class TestImportDirection(unittest.TestCase):
    def test_renderers_only_import_inward(self):
        for path in sorted(MODULES.glob('*.py')):
            with self.subTest(file=path.name):
                bad = {m for m in imports_of(path)
                       if m.startswith('studydeck') or m in OUTWARD}
                self.assertEqual(bad - INWARD_OK, set(),
                                 f'{path.name} importa hacia afuera: {bad}')

    def test_registry_does_not_import_lint_or_render(self):
        bad = {'lint', 'render', 'cli'} & imports_of(PKG / 'registry.py')
        self.assertEqual(bad, set())

    def test_contracts_does_not_import_registry(self):
        self.assertNotIn('registry', imports_of(PKG / 'contracts.py'))

    def test_primitives_does_not_import_registry(self):
        self.assertNotIn('registry', imports_of(PKG / 'primitives.py'))


class TestDocumentation(unittest.TestCase):
    def test_every_module_has_a_docstring(self):
        for path in py_files():
            with self.subTest(file=path.name):
                tree = ast.parse(path.read_text(encoding='utf-8'))
                self.assertTrue(ast.get_docstring(tree), f'{path.name} sem docstring')

    def test_every_renderer_has_a_docstring(self):
        import studydeck.registry as registry
        for name, spec in registry.MODULES.items():
            with self.subTest(module=name):
                self.assertTrue(spec['render'].__doc__, f'{name} sem docstring')

    def test_public_functions_are_documented(self):
        for path in py_files():
            tree = ast.parse(path.read_text(encoding='utf-8'))
            for node in tree.body:
                if isinstance(node, ast.FunctionDef) and not node.name.startswith('_'):
                    with self.subTest(file=path.name, function=node.name):
                        self.assertTrue(ast.get_docstring(node),
                                        f'{path.name}:{node.name} sem docstring')


class TestGeometryIsTheSingleSource(unittest.TestCase):
    """A banda de conteudo tem UM dono: geometry.py. Nos renderers, zero literal."""

    BAND_LITERALS = (4.95, 6.60)

    def _renderer_literals(self):
        found = []
        for path in sorted(MODULES.glob('*.py')):
            tree = ast.parse(path.read_text(encoding='utf-8'))
            for node in ast.walk(tree):
                if isinstance(node, ast.Constant) and isinstance(node.value, float):
                    if any(abs(node.value - b) < 1e-6 for b in self.BAND_LITERALS):
                        found.append(f'{path.name}:{node.lineno}:{node.value}')
        return found

    def test_no_renderer_hardcodes_the_content_band(self):
        found = self._renderer_literals()
        self.assertEqual(found, [],
                         f'banda de conteudo escrita a mao (use CONTENT_BAND_H / '
                         f'CONTENT_BOTTOM): {found}')

    def test_renderers_import_the_named_band(self):
        """O antídoto do teste acima: os renderers CONSOMEM a banda nomeada."""
        import studydeck.geometry as g
        self.assertAlmostEqual(g.CONTENT_BAND_H, 4.95, places=6)
        self.assertAlmostEqual(g.CONTENT_BOTTOM, 6.60, places=6)


class TestDensityHasOneHome(unittest.TestCase):
    """Densidade e decidida por `geometry.tier_for`, nao dentro do renderer.

    Um renderer sob o tier nao decide geometria por CONTAGEM de itens
    (`n <= 4`, `len(xs) > 3`): e a forma exata do ternario que o tier
    substitui. Branch sobre modo (tem imagem? tem nota?) continua legitimo —
    sao duas composicoes, nao duas densidades.

    `TIER_OWNED` cresce a cada milestone; `DEFERRED` esta vazio. `m_cycle_diagram`
    entrou em M5: o que nao cabia era o ORCAMENTO de desc (90 -> 80 car. por
    `_desc_by_count`, em M2c), nao a geometria — e o raio e o centro sao
    derivados da banda, nao da contagem.
    """

    TIER_OWNED = (('diagram.py', 'm_timeline'), ('diagram.py', 'm_cycle_diagram'))
    DEFERRED = set()

    def _count_branches(self):
        found = []
        for fname, func in self.TIER_OWNED:
            path = MODULES / fname
            tree = ast.parse(path.read_text(encoding='utf-8'))
            target = next((n for n in tree.body
                           if isinstance(n, ast.FunctionDef) and n.name == func), None)
            self.assertIsNotNone(target, f'{fname}:{func} nao existe')
            for node in ast.walk(target):
                if isinstance(node, ast.IfExp) and any(
                        isinstance(s, ast.Compare) for s in ast.walk(node.test)):
                    found.append(f'{fname}:{func}:{node.lineno}: '
                                 f'{ast.unparse(node)[:48]}')
        return found

    def test_no_tier_owned_renderer_branches_geometry_on_item_count(self):
        found = self._count_branches()
        self.assertEqual(found, [],
                         f'ternario de densidade dentro do renderer (use tier_for): {found}')

    def test_the_dormant_branch_is_a_tier_decision(self):
        """Antidoto: `tier_for` decide, e ele nao faz `n <= 4` na mao."""
        import inspect
        from studydeck import geometry
        src = inspect.getsource(geometry.tier_for)
        self.assertNotIn('n <= 4', src)
        self.assertIn('STANDARD', src)

    def test_deferred_renderers_are_declared_not_forgotten(self):
        """O que ficou para M2b tem que estar escrito aqui, nao no Precisamos."""
        present = {m for _f, m in self.TIER_OWNED} | self.DEFERRED
        self.assertTrue(self.DEFERRED <= present)


class TestNoDeadNames(unittest.TestCase):
    """`geometry.py` nao guarda simbolo que ninguem le.

    Tres nomes sobraram de refactors anteriores e pareciam invariantes: `SAFE_X1`
    (documental, nunca importado), `CAPTION_MIN` (o escritor real e' `images.py`)
    e `content_top()` (so o teste o chamava).
    """

    DEAD = ('SAFE_X1', 'CAPTION_MIN', 'content_top')

    def test_geometry_has_no_dead_symbol(self):
        import studydeck.geometry as g
        alive = [n for n in self.DEAD if hasattr(g, n)]
        self.assertEqual(alive, [], f'simbolo morto em geometry.py: {alive}')

    def test_the_real_caption_floor_lives_in_one_place(self):
        from studydeck import geometry as g
        self.assertFalse(hasattr(g, 'CAPTION_MIN'),
                         'o piso de pie analitico e um so: images.CAPTION_MIN')

    def test_no_test_pins_a_symbol_the_package_dropped(self):
        """Um teste que so chama um simbolo nao e cobertura: e dependencia."""
        import studydeck.geometry as g
        dead = [n for n in self.DEAD if hasattr(g, n)]
        callers = []
        for path in sorted(pathlib.Path(__file__).resolve().parent.glob('*.py')):
            body = path.read_text(encoding='utf-8')
            for name in dead:
                if f'G.{name}' in body or f'geometry.{name}' in body:
                    callers.append(f'{path.name}: {name}')
        self.assertEqual(callers, [], f'teste ainda usa simbolo morto: {callers}')


class TestNoUnusedImports(unittest.TestCase):
    """Cabecalho de import copiado e colado nos 4 renderers deixau 60+ mortos."""

    def _unused(self, path):
        tree = ast.parse(path.read_text(encoding='utf-8'))
        imported = {}
        for node in tree.body:
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                for alias in node.names:
                    if alias.name == '*':
                        continue
                    imported[alias.asname or alias.name.split('.')[0]] = node.lineno
        used = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Name):
                used.add(node.id)
            elif isinstance(node, ast.Attribute):
                base = node
                while isinstance(base, ast.Attribute):
                    base = base.value
                if isinstance(base, ast.Name):
                    used.add(base.id)
        for node in tree.body:          # `__all__` é uso: re-export deliberado
            if isinstance(node, ast.Assign) and any(
                    isinstance(t, ast.Name) and t.id == '__all__' for t in node.targets):
                used.update(el.value for el in getattr(node.value, 'elts', [])
                            if isinstance(el, ast.Constant))
        return sorted((line, name) for name, line in imported.items()
                      if name not in used)

    def test_no_unused_import_in_the_package(self):
        offenders = []
        for path in py_files():
            for line, name in self._unused(path):
                offenders.append(f'{path.name}:{line}:{name}')
        self.assertEqual(offenders, [],
                         f'imports mortos no pacote: {offenders}')


class TestNoSuppression(unittest.TestCase):
    def test_no_bare_except_pass(self):
        for path in py_files():
            body = path.read_text(encoding='utf-8')
            with self.subTest(file=path.name):
                self.assertNotIn('except: pass', body)
                self.assertNotIn('except Exception: pass', body)

    def test_broad_exceptions_are_annotated(self):
        for path in py_files():
            body = path.read_text(encoding='utf-8').splitlines()
            for i, line in enumerate(body, 1):
                if 'except Exception' in line and 'noqa' not in line and '#' not in line:
                    with self.subTest(file=path.name, line=i):
                        self.fail(f'{path.name}:{i} except Exception sem justificativa')


if __name__ == "__main__":
    unittest.main()