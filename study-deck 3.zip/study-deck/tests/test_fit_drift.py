# -*- coding: utf-8 -*-
"""O gate de ajuste mede a caixa que o renderer PINTOU?

`FIT_RULES` e uma copia escrita a mao das caixas de 12 dos 35 modulos. Se ela
divergir do renderer, o lint diz que o texto cabe numa caixa onde ele nao cabe:
o autor passa o lint, o build grava o .pptx, e o transbordo so aparece quando
alguem abre o arquivo. Esse e exatamente o custo de iteracao que a refatoracao
tenta pagar.

Este arquivo mede a divergencia, nao a descreve: para cada modulo com regra de
ajuste, acha o MAIOR texto que o lint aceita, renderiza esse texto, e confere se
ele cabe na caixa de verdade. Se cabe, o gate mede a caixa real. Se nao cabe, o
gate mede uma caixa imaginaria — e o teste diz qual modulo e por quantos centesimos.
"""

import ast
import pathlib
import unittest

from studydeck import contracts
from studydeck import lint as L
from studydeck.images import ImagePolicy

import test_density as TD

PKG = pathlib.Path(__file__).resolve().parent.parent / 'studydeck'


def _accepts(module, slide):
    """True quando o contrato aceita este slide (sem contar marcadores)."""
    errs = [e for e in L.check([slide], 'pt-BR', ImagePolicy(), ())
            if 'transbordo' in e]
    return not errs


def _budget(module, field):
    """Orçamento de caracteres do campo, ou None se nao for campo simples."""
    spec = contracts.B.get(module, {})
    val = spec.get(field)
    return val if isinstance(val, int) else None


def _fields(module):
    """Todos os campos com regra de ajuste — nao so o primeiro."""
    seen = []
    for field, _w, _h, _pt in contracts.FIT_RULES[module]({}):
        if field not in seen:
            seen.append(field)
    return seen


def _with(module, field, text):
    """Um slide do modulo com `field` posto em `text` e o resto plausivel."""
    slide = CASES[module](60)
    slide[field] = text
    return slide


def _largest_accepted(module, field, limit):
    """Maior n de caracteres que o lint aceita em `field` (bissecção)."""
    best = None
    for n in range(20, limit + 1, 5):
        if not _accepts(module, _with(module, field, 'x' * n)):
            break
        best = n
    return best


class TestFitRulesMeasureTheRenderedBox(unittest.TestCase):
    """Para o maior texto que o lint aceita, o texto tem que caber de verdade."""


    def test_no_coordinate_stands_in_for_a_size(self):
        """O acidente do `SAFE_X0`/`SAFE_Y0` como altura de caixa.

        O valor estava certo; o que estava errado era uma COORDENada fazendo o
        papel de uma MEDIDA. O sintoma e silencioso: o lint e o renderer
        concordam porque copiam o mesmo acidente, e ninguem sabe porque o
        numero e aquele.
        """
        signatures = {'tx': (3, 4), 'textframe': (3, 4), 'rect': (3, 4),
                      'pill': (3, 4), 'place_image': (4, 5)}
        coords = ('SAFE_X0', 'SAFE_Y0')
        offenders = []
        for path in sorted(PKG.rglob('*.py')):
            tree = ast.parse(path.read_text(encoding='utf-8'))
            for node in ast.walk(tree):
                if not isinstance(node, ast.Call):
                    continue
                name = getattr(node.func, 'id', getattr(node.func, 'attr', ''))
                if name not in signatures:
                    continue
                for pos in signatures[name]:
                    if pos >= len(node.args):
                        continue
                    arg = node.args[pos]
                    if isinstance(arg, ast.Name) and arg.id in coords:
                        offenders.append(f'{path.name}:{node.lineno} '
                                         f'{name}() {arg.id} em w/h')
        self.assertEqual(offenders, [],
                         f'coordenada no lugar de medida: {offenders}')

    def test_the_fit_rules_name_the_boxes_they_measure(self):
        """Toda medida de `FIT_RULES` tem nome proprio em geometry.py."""
        import studydeck.geometry as g
        named = {name for name in dir(g) if name.endswith('_H') or name.endswith('_W')}
        used = set()
        for module, rule in contracts.FIT_RULES.items():
            if not rule:
                continue
            for _f, _w, _h, _pt in rule({}):
                used.add(module)
        self.assertTrue(named, 'geometry.py precisa expor as caixas nomeadas')
        self.assertEqual(used - set(contracts.FIT_RULES), set())

    def test_the_text_the_lint_accepts_fits_the_box_the_engine_paints(self):
        drifted, unchecked = [], []
        for module in sorted(CASES):
            for field in _fields(module):
                with self.subTest(module=module, field=field):
                    limit = _budget(module, field) or 400
                    n = _largest_accepted(module, field, limit)
                    if n is None:
                        unchecked.append(f'{module}.{field}')
                        continue
                    over = _overflows(_with(module, field, 'x' * n))
                    if over:
                        worst = max(o[0] - o[1] for o in over)
                        drifted.append(f'{module}.{field} @ {n} car.: estoura {worst:+.2f} in')
        self.assertEqual(drifted, [],
                         f'o gate de ajuste mede uma caixa que o renderer nao pinta: {drifted}')
        self.assertEqual(unchecked, [],
                         f'campo com regra de ajuste que o lint nunca exercita: {unchecked}')


def _overflows(slide):
    """[(need, box_h)] das caixas que o texto nao preenche."""
    path, _fails = TD._render([slide])
    import pathlib
    from pptx import Presentation
    out = []
    try:
        for shape, box, _runs in TD._boxes_and_runs(Presentation(path).slides[0]):
            if box is None or not getattr(shape, 'has_text_frame', False):
                continue
            if getattr(shape, 'has_chart', False) or getattr(shape, 'has_table', False):
                continue
            need = TD._text_frame_height(shape)
            if need > box[3] + TD.OVERFLOW_MARGIN_IN:
                out.append((round(need, 3), round(box[3], 3)))
    finally:
        pathlib.Path(path).unlink(missing_ok=True)
    return out


# Cada entrada monta um slide valido do modulo e devolve o campo com regra de ajuste.
CASES = {
    'definition': lambda n: {
        'module': 'definition', 'kicker': 'C', 'title': 'D',
        'main_statement': 'x' * n,
        'key_points': [{'title': 'V', 'desc': 'd'}]},
    'stat_card': lambda n: {
        'module': 'stat_card', 'kicker': 'C', 'title': 'D',
        'stat_num': '42%', 'stat_title': 'x' * n},
    'case_block': lambda n: {
        'module': 'case_block', 'kicker': 'C', 'title': 'D',
        'case_stem': 'x' * n, 'findings': ['f'],
        'reasoning': 'r' * 20, 'diagnosis': 'D', 'clinical_pearl': 'p' * 20},
    'quote_block': lambda n: {
        'module': 'quote_block', 'kicker': 'C', 'title': 'D',
        'quote': 'x' * n, 'author': 'A'},
    'socratic_question': lambda n: {
        'module': 'socratic_question', 'kicker': 'C', 'title': 'D',
        'question': 'x' * n},
    'oxford_union': lambda n: {
        'module': 'oxford_union', 'kicker': 'C', 'title': 'D',
        'motion': 'x' * n, 'verdict': 'v' * 20,
        'pro_card': {'title': 'p', 'points': ['a']},
        'con_card': {'title': 'c', 'points': ['a']}},
    'viva_question': lambda n: {
        'module': 'viva_question', 'kicker': 'C', 'title': 'D',
        'prompt': 'x' * n, 'model_answer': 'm' * 20, 'examiner_note': 'e' * 20},
    'evidence_card': lambda n: {
        'module': 'evidence_card', 'kicker': 'C', 'title': 'D',
        'study_name': 'S', 'design': 'rct',
        'population': 'x' * n, 'intervention': 'i' * 20,
        'comparison': 'c' * 20, 'outcome': 'o' * 20,
        'effect': 'HR 0.75', 'credit': 'R'},
    'annotated_passage': lambda n: {
        'module': 'annotated_passage', 'kicker': 'C', 'title': 'D',
        'passage': 'x' * n, 'annotations': [{'ref': '1', 'note': 'n' * 20}]},
    'authority_card': lambda n: {
        'module': 'authority_card', 'kicker': 'C', 'title': 'D',
        'image': TD._deck_image(), 'name': 'N' * 20, 'bio': 'x' * n},
    'title': lambda n: {
        'module': 'title', 'title': 'x' * n},
    'section_divider': lambda n: {
        'module': 'section_divider', 'section_title': 'x' * n},
}


if __name__ == "__main__":
    unittest.main()