# -*- coding: utf-8 -*-
"""Densidade de conteudo: o motor mede uma vez e escolhe a geometria.

Uma regra so: o conteudo que cabe na banda fica no tier STANDARD (a geometria
de hoje, sem mudanca); o conteudo que estoura vira COMPACT, que encolhe gap e
pad e da UM passo de tipo com piso. Se ainda assim nao couber, o motor NAO
remede: devolve COMPACT e deixa o ajuste reportar. Sem retry, sem re-render.
"""

import tempfile
import unittest

from pptx import Presentation

from studydeck import geometry as G
from studydeck import manifest as MF
from studydeck import render as RD
from dense_deck import dense_deck
from studydeck.fixtures import fixture_slides
from studydeck.typography import est_height

# 190 caracteres numa caixa de 3.0 in a 11 pt: estoura a banda no tier
# STANDARD e cabe no COMPACT (6 linhas a 10.5 pt + gap + pad).
DENSE = 'x' * 190
SPARSE = ['Leituras iniciais', 'Estudo de caso', 'Revisao final']


class TestBand(unittest.TestCase):
    def test_content_bottom_is_the_documented_band_edge(self):
        self.assertAlmostEqual(G.CONTENT_BOTTOM, 6.60, places=6)

    def test_band_height_reserves_the_footnote_gutter(self):
        expected = G.CONTENT_BOTTOM - G.SAFE_Y0 - G.FOOTNOTE_GUTTER
        self.assertAlmostEqual(G.CONTENT_BAND_H, expected, places=6)

    def test_band_height_is_the_number_renderers_used_to_hardcode(self):
        self.assertAlmostEqual(G.CONTENT_BAND_H, 4.95, places=6)

    def test_band_bottom_leaves_room_above_the_footer(self):
        self.assertLessEqual(G.CONTENT_BOTTOM, G.FOOTER_Y)


class TestTierDecision(unittest.TestCase):
    def test_content_that_fits_stays_on_the_standard_tier(self):
        self.assertIs(G.tier_for(SPARSE, 5.88, 11.0, 4.95), G.STANDARD)

    def test_content_over_the_zone_falls_back_to_compact(self):
        self.assertIs(G.tier_for([DENSE] * 3, 3.0, 11.0, 4.95), G.COMPACT)

    def test_the_tier_is_one_of_the_two_named_tiers(self):
        for texts, w in (([DENSE] * 8, 2.0), (SPARSE, 5.88)):
            self.assertIn(G.tier_for(texts, w, 11.0, 4.95),
                          (G.STANDARD, G.COMPACT))

    def test_decision_is_taken_once_and_never_escalated(self):
        """Conteudo que nao cabe nem no compact NAO vira um terceiro tier."""
        absurd = [DENSE * 6] * 5
        self.assertIs(G.tier_for(absurd, 2.0, 11.0, 4.95), G.COMPACT)

    def test_more_content_never_chooses_the_roomier_tier(self):
        sparse = G.tier_for(SPARSE, 5.88, 11.0, 4.95)
        dense = G.tier_for(SPARSE * 4, 5.88, 11.0, 4.95)
        self.assertNotEqual(dense.gap, sparse.gap)


class TestTypeScale(unittest.TestCase):
    def test_standard_type_is_not_rescaled(self):
        self.assertAlmostEqual(G.type_pt(11.0, G.STANDARD), 11.0, places=6)
        self.assertAlmostEqual(G.type_pt(9.5, G.STANDARD, long=True), 9.5, places=6)

    def test_compact_steps_the_body_down_once(self):
        stepped = G.type_pt(12.0, G.COMPACT)
        self.assertLess(stepped, 12.0)
        self.assertGreaterEqual(stepped, G.TYPE_FLOOR_PT)

    def test_compact_never_breaks_the_label_floor(self):
        self.assertGreaterEqual(G.type_pt(9.2, G.COMPACT), G.TYPE_FLOOR_PT)

    def test_compact_never_breaks_the_long_body_floor(self):
        self.assertGreaterEqual(G.type_pt(10.8, G.COMPACT, long=True),
                                G.BODY_FLOOR_PT)

    def test_long_body_floor_binds_before_the_scale_does(self):
        """10.5 pt e o piso do corpo longo: a escala nao pode descer abaixo."""
        self.assertAlmostEqual(G.type_pt(11.0, G.COMPACT, long=True),
                               G.BODY_FLOOR_PT, places=6)


class TestStack(unittest.TestCase):
    def test_standard_content_reproduces_the_current_meters(self):
        """Neutralidade: no tier STANDARD a aritmetica e a de hoje, byte a byte."""
        got = G.stack(1.55, 4.95, SPARSE, 11.0, cap=1.2)
        want = G.stack_layout(1.55, 4.95, len(SPARSE), G.STANDARD.gap, cap=1.2)
        self.assertEqual(got, want)

    def test_standard_content_honours_the_module_cap(self):
        row_h, _y = G.stack(1.55, 4.95, SPARSE, 11.0, cap=1.0)
        self.assertAlmostEqual(row_h, 1.0, places=6)

    def test_dense_stack_fits_the_zone_that_standard_overflows(self):
        n = 3
        row_h, _y = G.stack(1.55, 4.95, [DENSE] * n, 11.0, box_w=3.0)
        consumed = n * row_h + (n - 1) * G.COMPACT.gap
        self.assertLessEqual(consumed, 4.95)

    def test_compact_rows_take_their_height_from_the_content(self):
        """Sem tecto no compact: a caixa cresce ate conter o texto."""
        row_h, _y = G.stack(1.55, 4.95, [DENSE] * 3, 11.0, box_w=3.0)
        needed = est_height(DENSE, 3.0, G.type_pt(11.0, G.COMPACT, long=True))
        self.assertAlmostEqual(row_h, needed, places=3)

    def test_each_compact_row_holds_its_own_text(self):
        row_h, _y = G.stack(1.55, 4.95, [DENSE] * 3, 11.0, box_w=3.0)
        for text in (DENSE,):
            needed = est_height(text, 3.0, G.type_pt(11.0, G.COMPACT, long=True))
            self.assertGreaterEqual(row_h, needed - 1e-6)

    def test_group_stays_vertically_centred(self):
        n = 3
        row_h, y_first = G.stack(1.55, 4.95, [DENSE] * n, 11.0, box_w=3.0)
        centre = y_first + (row_h * n + G.COMPACT.gap * (n - 1)) / 2.0
        self.assertAlmostEqual(centre, 1.55 + 4.95 / 2.0, places=3)

    def test_empty_content_does_not_divide_by_zero(self):
        row_h, y = G.stack(1.55, 4.95, [], 11.0)
        self.assertGreater(row_h, 0)
        self.assertIsInstance(y, float)


# ---------------------------------------------------------------- M2: oraculos

IN = 914400
CANVAS_W, CANVAS_H = 13.333, 7.5
BAND_X0, BAND_X1 = 0.63, 12.703
BAND_TOP, BAND_BOTTOM = 1.45, 6.65
EPS = 0.011
MIN_FONT_PT = 9.0
BODY_FONT_PT = 10.5
OVERLAP_AREA_IN2 = 0.02
OVERFLOW_MARGIN_IN = 0.12      # folga do oraculo de transbordo (erro do estimador)


def _first_text(shape):
    for p in shape.text_frame.paragraphs:
        for r in p.runs:
            if r.text and r.text.strip():
                return r.text
    return ''


def _text_frame_height(shape):
    """Alto estimado de um TextFrame, usando o espacamento que o motor fixou.

    `est_height` e a régua do proprio motor; o que difere aqui e o
    `line_spacing`/`space_after` reais do parágrafo, para o oráculo não acusar
    o texto que cabe.
    """
    total = 0.0
    for p in shape.text_frame.paragraphs:
        text = ''.join(r.text for r in p.runs)
        if not text.strip():
            continue
        sizes = [r.font.size.pt for r in p.runs if r.font.size is not None]
        if not sizes:
            continue
        line_sp = p.line_spacing if isinstance(p.line_spacing, (int, float)) else 1.08
        sp_after = p.space_after.pt if p.space_after is not None else 0.0
        total += est_height(text, _frame_width(shape), max(sizes),
                            line_sp=line_sp, sp_after=sp_after)
    return total


def _frame_width(shape):
    try:
        return shape.width / IN
    except (TypeError, ValueError):
        return 0.0


def _render(slides):
    """(caminho, falhas_de_contraste) de um deck sintetico."""
    deck = MF.Deck('<compact>', slides, {'course': 'DENSIDADE'},
                   {'LANG': 'pt-BR'})
    tmp = tempfile.NamedTemporaryFile(suffix='.pptx', delete=False)
    tmp.close()
    _n, fails = RD.render(deck, tmp.name)
    return tmp.name, fails


def _boxes_and_runs(slide):
    """(shape, box, runs) por shape; `runs` e None quando nao ha texto medivel."""
    for shape in slide.shapes:
        box = None
        try:
            box = (shape.left / IN, shape.top / IN, shape.width / IN, shape.height / IN)
        except (TypeError, ValueError):
            pass
        runs = None
        if getattr(shape, 'has_text_frame', False):
            runs = [r for p in shape.text_frame.paragraphs for r in p.runs
                    if r.text and r.text.strip()]
        yield shape, box, runs


def _engine_text(shape, runs):
    """Texto pintado pelo motor: tabela e grafico nativos ficam de fora.

    Sao eles que o PowerPoint desenha; o oraculo de colisao deles e outro.
    """
    if not runs:
        return False
    return not (getattr(shape, 'has_chart', False) or getattr(shape, 'has_table', False))


class TestDenseDeckMeetsTheOracles(unittest.TestCase):
    """Deck na cardinalidade maxima tem que caber na banda e ler.

    `dense_deck.py` traz os 35 modulos no limite do contrato; `test_dense_deck_is_legal`
    prova que e um manifesto que um autor pode escrever. Sem essa prova, um oraculo
    aqui so mediria algo que ninguem escreveria.
    """

    @classmethod
    def setUpClass(cls):
        cls.path, cls.fails = _render(dense_deck())
        cls.slides = Presentation(cls.path).slides
        cls.names = [s['module'] for s in dense_deck()]

    @classmethod
    def tearDownClass(cls):
        import pathlib
        pathlib.Path(cls.path).unlink(missing_ok=True)

    def test_no_contrast_violation_in_a_dense_deck(self):
        self.assertEqual(self.fails, [], f'contraste: {self.fails[:3]}')

    def test_no_shape_escapes_the_canvas(self):
        escapes = []
        for name, slide in zip(self.names, self.slides):
            for _shape, box, _runs in _boxes_and_runs(slide):
                if box is None:
                    continue
                x, y, w, h = box
                if x < -EPS or y < -EPS or x + w > CANVAS_W + EPS or y + h > CANVAS_H + EPS:
                    escapes.append((name, round(x, 2), round(y, 2),
                                    round(x + w, 2), round(y + h, 2)))
        self.assertEqual(escapes, [], f'formas fora do lienzo: {escapes}')

    def test_dense_content_stays_inside_the_band(self):
        stray = []
        for name, slide in zip(self.names, self.slides):
            for _shape, box, _runs in _boxes_and_runs(slide):
                if box is None:
                    continue
                x, y, w, h = box
                if not (y >= BAND_TOP - EPS and y + h <= BAND_BOTTOM + EPS):
                    continue
                if x < BAND_X0 - EPS or x + w > BAND_X1 + EPS:
                    stray.append((name, round(x, 2), round(x + w, 2)))
        self.assertEqual(stray, [], f'conteudo fora da banda: {stray}')

    def test_no_text_box_collides_in_a_dense_deck(self):
        clashes = []
        for name, slide in zip(self.names, self.slides):
            boxes = []
            for shape, box, runs in _boxes_and_runs(slide):
                if box and _engine_text(shape, runs):
                    boxes.append((box, runs[0].text[:16]))
            for i in range(len(boxes)):
                for j in range(i + 1, len(boxes)):
                    hit, area = _intersect(boxes[i][0], boxes[j][0])
                    if hit and area > OVERLAP_AREA_IN2:
                        clashes.append((name, boxes[i][1], boxes[j][1], round(area, 3)))
        self.assertEqual(clashes, [], f'colisoes de texto: {clashes}')

    def test_dense_text_never_drops_below_the_editorial_floor(self):
        thin = []
        for name, slide in zip(self.names, self.slides):
            for _shape, _box, runs in _boxes_and_runs(slide):
                for run in runs or []:
                    size = run.font.size
                    if size is not None and size.pt < MIN_FONT_PT:
                        thin.append((name, run.text[:20], round(size.pt, 1)))
        self.assertEqual(thin, [], f'abaixo de {MIN_FONT_PT}pt: {thin}')

    def test_dense_body_text_stays_at_reading_size(self):
        """Corpo com mais de 40 caracteres nao pode descer de 10.5 pt.

        O que conta como corpo e' o que o motor escreve como prosa. Tres coisas
        nao sao corpo, e a versao anterior deste teste tratava as tres como se
        fossem, producing 13 "violacoes" das quais 7 eram rotulo ou chrome:

        - **rotulo**: tudo em caixa alta (instituicao, eixos, `design`, badges).
          Caixa alta e gritado editorial; 10 pt ali e escolha, nao defeito.
        - **chrome**: o rodape (curso + numeracao), abaixo de 6.65 in. O proprio
          `tests/test_visual.py` documenta a banda de conteudo e o rodape como
          excecoes, e o piso de 9.0 pt continua valendo la.
        - **piso absoluto**: abaixo de 9.0 pt continua sendo violacao, em corpo
          ou em rotulo — esse e o outro teste, `..._never_drops_below_the_
          editorial_floor`.
        """
        thin = []
        for name, slide in zip(self.names, self.slides):
            for _shape, box, runs in _boxes_and_runs(slide):
                if box is not None and box[1] > BAND_BOTTOM - 0.12:
                    continue                      # chrome: rodape
                for run in runs or []:
                    if not self._is_body(run):
                        continue
                    size = run.font.size
                    if size is not None and size.pt < BODY_FONT_PT:
                        thin.append((name, run.text[:20], round(size.pt, 1)))
        self.assertEqual(thin, [], f'corpo longo abaixo de {BODY_FONT_PT}pt: {thin}')

    @staticmethod
    def _is_body(run):
        """Prosa do modulo: nao e' caixa alta (rotulo) e tem mais de 40 caracteres."""
        text = ''.join(run.text.split())
        return len(text) > 40 and text.upper() != text

    def test_dense_text_fits_inside_its_own_card(self):
        """O vazio real: texto que transborda a propria caixa nao gera colisao.

        Nenhum oraculo ate aqui media isso — colisao e caixa contra caixa, e o
        texto que cresce dentro do carton continua "dentro" do carton. Aqui o
        texto e medido contra a caixa que o motor pintou.

        `DECLARED_FORMAT_LIMITS` nomeia os formatos que NAO cabem na
        cardinalidade maxima com texto no limite. Eles nao passam por silencio:
        `test_the_declared_format_limits_are_still_limits` falha se um deles
        deixar de transbordar, o que obriga a atualizar a lista junto com o fix.
        """
        over = self._overflows()
        unexpected = sorted({row[0] for row in over} - set(self.DECLARED_FORMAT_LIMITS))
        self.assertEqual(unexpected, [],
                         f'transbordo novo (nao declarado): {over}')

    DECLARED_FORMAT_LIMITS = {}
    # A lista esta VAZIA de proposito: os 5 formatos que M2b declarou foram fechados
    # (fit_pt, _desc_by_count, largura do quadrante, redesenho do venn). Ela continua
    # aqui como contrato do teste: se um formato voltar a estourar, o oraculo acusa
    # como "transbordo novo" e alguem tem que declarar o motivo de novo aqui.
    # Saíram daqui em M2c, com numero medido e nao estimado:
    #   cycle_diagram -> 90 -> 80 car. por `_desc_by_count` (o cartao radial nao cresce)
    #   concept_map   -> 80 -> 60 car. por `_desc_by_count` (idem)
    #   pyramid       -> o corpo do titulo acompanha a largura do bloco (`fit_pt`); a
    #                    razao do limite era o titulo da BASE, nao a anotacao lateral
    #   quadrant_matrix -> os quadrantes comecavam em x=2.30 com 1.22 in de vao morto
    #                      depois da caixa do rotulo de eixo; resgatar essa largura
    #                      (x=1.20, 4.90 -> 5.64) e o ponto a 10.5 pt fez 5 pontos de
    #                      110 car. caberem: need 2.03 in numa caixa de 2.05
    #   venn_diagram    -> a lente dos 3 circulos tinha 0.98 in de altura para 1-3
    #                      itens de 45 car.: impossivel em qualquer geometria legivel
    #                      (medido por busca). `shared` virou faixa rotulada abaixo,
    #                      os circulos ganharam area util, e o orcamento de item
    #                      foi para 30 car. — o teto que o desenho novo mede.

    def test_the_declared_format_limits_are_still_limits(self):
        """Um limite declarado que deixou de existir vira lista obsoleta."""
        actual = {row[0] for row in self._overflows()}
        fixed = sorted(set(self.DECLARED_FORMAT_LIMITS) - actual)
        self.assertEqual(fixed, [],
                         f'estes formatos ja cabem na cardinalidade maxima — '
                         f'remova da lista e feche o numero: {fixed}')

    def test_the_declared_limits_all_exist_as_modules(self):
        from studydeck.registry import MODULES
        missing = sorted(set(self.DECLARED_FORMAT_LIMITS) - set(MODULES))
        self.assertEqual(missing, [], f'limite declarado para modulo inexistente: {missing}')

    def _overflows(self):
        out = []
        for name, slide in zip(self.names, self.slides):
            for _shape, box, _runs in _boxes_and_runs(slide):
                if box is None or not getattr(_shape, 'has_text_frame', False):
                    continue
                if getattr(_shape, 'has_chart', False) or getattr(_shape, 'has_table', False):
                    continue
                need = _text_frame_height(_shape)
                if need > box[3] + OVERFLOW_MARGIN_IN:
                    out.append((name, round(need, 2), round(box[3], 2),
                                _first_text(_shape)[:20]))
        return out


def _intersect(a, b):
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    w = min(ax + aw, bx + bw) - max(ax, bx)
    h = min(ay + ah, by + bh) - max(ay, by)
    return (w > EPS and h > EPS), max(w, 0) * max(h, 0)


class TestBlockTier(unittest.TestCase):
    """Cartao solto (timeline, ciclo): o bloco decide a propria altura.

    `stack` reparte uma COLUNA de linhas; um cartao solto ao longo de um eixo
    nao tem coluna. Aqui a vaga e `slot_h` e a altura segue o texto ate ela.
    """

    LONG = 'x' * 200

    def test_short_block_stays_standard(self):
        self.assertIs(G.tier_for_block('curto', 2.0, 12.0, 2.05), G.STANDARD)

    def test_block_over_the_slot_falls_back_to_compact(self):
        self.assertIs(G.tier_for_block(self.LONG, 2.0, 12.0, 1.0), G.COMPACT)

    def test_block_that_fits_anywhere_stays_standard(self):
        """So existem dois desfechos: cabe -> STANDARD, nao cabe -> COMPACT.

        Nao existe um terceiro tier para quando o COMPACT tambem nao resolve: o
        bloco transborda a vista e o ajuste reporta.
        """
        self.assertIs(G.tier_for_block(self.LONG, 3.0, 12.0, 40.0), G.STANDARD)
        self.assertIs(G.tier_for_block(self.LONG, 3.0, 12.0, 0.01), G.COMPACT)

    def test_block_height_is_the_text_plus_the_two_insets(self):
        want = est_height('curto', 2.0, 12.0) + 2 * G.CARD_INSET
        self.assertAlmostEqual(G.block_height('curto', 2.0, 12.0, 9.0, G.STANDARD),
                               want, places=3)

    def test_block_height_never_exceeds_the_slot(self):
        self.assertLessEqual(G.block_height(self.LONG, 2.0, 12.0, 1.0, G.COMPACT), 1.0)

    def test_compact_block_height_keeps_the_reading_floor(self):
        """O passo de tipo no compact nunca produz corpo abaixo do piso."""
        for size in (9.0, 9.5, 10.0, 10.5, 11.0, 12.0):
            with self.subTest(size=size):
                self.assertGreaterEqual(G.type_pt(size, G.COMPACT, long=True),
                                        G.BODY_FLOOR_PT)

    def test_the_tier_switch_is_what_makes_the_block_fit(self):
        """O piso do COMPACT e o que fecha a conta, nao um ajuste de espaco.

        Medido a 12 pt o bloco estoura a vaga; medido no piso de 10.5 pt ele
        cabe. E para isso que a decisao de tier existe.
        """
        slot = 2.9
        self.assertIs(G.tier_for_block(self.LONG, 2.0, 12.0, slot), G.COMPACT)
        height = G.block_height(self.LONG, 2.0, 12.0, slot, G.COMPACT)
        self.assertLessEqual(height, slot)
        stepped = G.type_pt(12.0, G.COMPACT, long=True)
        self.assertAlmostEqual(height,
                               est_height(self.LONG, 2.0, stepped) + 2 * G.CARD_INSET,
                               places=3)


class TestStandardNeutrality(unittest.TestCase):
    """Ratchet: os slides do fixture que M2 nao toca nao podem mudar.

    O fixture e o unico deck que os gates de hoje conhecem como bom. Se o tier
    resolver para COMPACT num slide que hoje e STANDARD, ou se um refactor
    atravessar um renderer vizinho, este teste acusa — por modulo.

    Fora de proposito, com motivo declarado:

    - `timeline`: os cartoes passam a ter a altura do texto (hoje sao 2.05 in
      fixos guardando um desc de 4 caracteres). Prova: TestBlockTier + oraculo.
    - `authority_card`: o marco do nome passa a ter a altura do texto (60
      caracteres a 24 pt sao duas linhas, e o marco fixo empurrava a bio para
      dentro do retrato). Prova: o oraculo de transbordo.
    - `cycle_diagram`: raio e centro sao derivados da banda em vez da contagem.
      `R = 2.35 if n <= 4 else 2.20` media quantos nos tem, nao o espaco
      disponivel. Prova: o ratchet de ternario de contagem.
    """

    CHANGES_BY_DESIGN = ('timeline', 'authority_card', 'quadrant_matrix',
                          'venn_diagram', 'cycle_diagram')

    DIGEST = {
        'title': 'bd9401233a688e7c', 'section_divider': 'a4e36098ed8b0b2f',
        'definition': 'aa30f15ecdbb7fda', 'flow_diagram': 'c2bb30f2fd242881',
        'comparison_table': '63494084d0f2d0bd', 'synthesis_grid': '63494084d0f2d0bd',
        'stat_card': '9b8957f4c6a288df', 'checklist': 'a473040388711f75',
        'fixed_schema_card': '51651e945c8693be', 'side_by_side': '46530a817a7e0dfc',
        'taxonomy_tree': '9cb2ad7b31dfe8c5', 'algorithm': 'cf97c378881c1f95',
        'case_block': '3190dd78c8cad9b6', 'cycle_diagram': '4e566cade7698e8e',
        'quadrant_matrix': '5677e93ddddd8cda',
        'pyramid': 'c49e2ad1994c0e23', 'quote_block': 'dcac65f6eb564e9b',
        'socratic_question': 'd7e072d31937a4f1', 'oxford_union': '065efa4a46ce6ee3',
        'evidence_card': '4a37f973c6cf87dd', 'viva_question': '4a190727bf3c735b',
        'mnemonic_card': '0e222c5ef6ea3e84', 'etymology': 'ca7cada4ce5df4e0',
        'venn_diagram': 'd48fb6d349f93d25', 'chart_data': '7d9ca54935b7b99e',
        'references': 'c30f179caf290ad7', 'learning_objectives': '86c8b8f12bdfdc89',
        'colloquy': '192350a57981765d', 'annotated_passage': 'fd9dcce5ceea948f',
        'concept_map': 'e05022fa53e88a67', 'glossary': 'e5289a0428b423b4',
        'further_reading': '277939a28c040a1f', 'figure': '36bfebd51c61eab4',
        'authority_card': '05718f53ea0808ed',
    }

    def test_the_fixture_geometry_is_unchanged(self):
        import hashlib
        slides = [s for s in fixture_slides() if s['module'] not in self.CHANGES_BY_DESIGN]
        path, fails = _render(slides)
        try:
            self.assertEqual(fails, [], f'contraste: {fails[:3]}')
            out = Presentation(path).slides
            self.assertEqual(len(out), len(slides))
            drifted = []
            for src, slide in zip(slides, out):
                rows = []
                for shape, _box, _runs in _boxes_and_runs(slide):
                    rows.append((str(getattr(shape, 'shape_type', '?')),) + tuple(
                        round(v, 3) for v in (shape.left / IN, shape.top / IN,
                                              shape.width / IN, shape.height / IN)))
                rows.sort()
                got = hashlib.sha256(repr(rows).encode()).hexdigest()[:16]
                if got != self.DIGEST.get(src['module']):
                    drifted.append((src['module'], self.DIGEST.get(src['module']), got))
            self.assertEqual(drifted, [],
                             f'geometria mudou (o fixture e STANDARD): {drifted}')
        finally:
            import pathlib
            pathlib.Path(path).unlink(missing_ok=True)

    def test_every_fixture_module_is_accounted_for(self):
        """Nenhum modulo sai da conta: ou tem digest, ou esta listado como mudado."""
        names = {s['module'] for s in fixture_slides()}
        missing = names - set(self.DIGEST) - set(self.CHANGES_BY_DESIGN)
        self.assertEqual(missing, set(),
                         f'modulo sem digest e sem justificativa: {sorted(missing)}')

    def test_the_exclusion_is_declared_not_forgotten(self):
        for module in self.CHANGES_BY_DESIGN:
            with self.subTest(module=module):
                self.assertIn(module, {s['module'] for s in fixture_slides()})


def _deck_image():
    """A figura do fixture, para os modulos que exigem retrato."""
    from studydeck.fixtures import _fixture_image
    return _fixture_image()


class TestDenseDeckIsLegal(unittest.TestCase):
    """O deck de densidade tem que ser um manifesto que um AUTOR pode escrever.

    Sem isso o oraculo visual mede uma carga invalida e a gente conserta
    geometria para um cenario que nao existe.
    """

    def test_the_dense_deck_passes_the_contract(self):
        from studydeck import lint as L
        from studydeck.images import ImagePolicy
        errs = L.check(dense_deck(), 'pt-BR', ImagePolicy(), ())
        self.assertEqual(errs, [], f'deck denso fora do contrato: {errs[:6]}')

    def test_the_dense_deck_covers_every_module(self):
        from studydeck.registry import MODULES
        names = [s['module'] for s in dense_deck()]
        self.assertEqual(sorted(set(names)), sorted(MODULES),
                         'o deck denso tem que cobrir os 35 modulos')
        self.assertEqual(len(names), len(MODULES), 'um slide por modulo')


class TestStackTyped(unittest.TestCase):
    """Metros e tipo saem da MESMA decisao de tier, num so lugar.

    Sem isto, um modulo mede com `tier_for` e depois dimensiona o tipo com
    `type_pt` — duas chamadas que concordam hoje e podem divergir amanha.
    """

    def test_it_returns_meters_and_size_from_one_decision(self):
        got = G.stack_typed(1.55, 4.95, [DENSE] * 3, 12.0, box_w=3.0)
        self.assertEqual(len(got), 3)
        row_h, y_first, size = got
        self.assertIsInstance(size, float)
        self.assertAlmostEqual(size, G.type_pt(12.0, G.COMPACT, long=True), places=6)

    def test_standard_content_is_typed_at_its_own_size(self):
        _row_h, _y, size = G.stack_typed(1.55, 4.95, SPARSE, 11.0, cap=1.2)
        self.assertAlmostEqual(size, 11.0, places=6)

    def test_the_meters_match_the_plain_stack(self):
        typed = G.stack_typed(1.55, 4.95, SPARSE, 11.0, cap=1.2)
        plain = G.stack(1.55, 4.95, SPARSE, 11.0, cap=1.2)
        self.assertEqual(typed[:2], plain)

    def test_dense_meters_match_the_plain_stack(self):
        typed = G.stack_typed(1.55, 4.95, [DENSE] * 3, 12.0, box_w=3.0)
        plain = G.stack(1.55, 4.95, [DENSE] * 3, 12.0, box_w=3.0)
        self.assertEqual(typed[:2], plain)

    def test_the_size_never_breaks_the_reading_floor(self):
        _r, _y, size = G.stack_typed(1.55, 4.95, [DENSE] * 5, 10.5, box_w=2.0)
        self.assertGreaterEqual(size, G.BODY_FLOOR_PT)


class TestFitPt(unittest.TestCase):
    """O maior corpo que cabe na caixa, com piso editorial.

    `block_height` e o inverso deste: enquanto aquele responde "que altura o
    texto pede", este responde "que corpo cabe na altura que eu tenho". E o que
    a piramide precisa, porque o bloco mais estreito e o da base.
    """

    WIDE_TITLE = 'Fase vascular da resposta inicial'
    NARROW = 'Apendicite'

    def test_short_text_keeps_the_full_size(self):
        self.assertAlmostEqual(G.fit_pt('curto', 1.2, 0.9, 12.0), 12.0, places=6)

    def test_narrow_box_steps_the_size_down(self):
        """O caso real da piramide: 55 caracteres no bloco de 1.64 in de base."""
        got = G.fit_pt(self.WIDE_TITLE, 1.14, 0.92, 12.0)
        self.assertLess(got, 12.0)
        self.assertGreaterEqual(got, G.TYPE_FLOOR_PT)

    def test_the_chosen_size_actually_fits(self):
        """Cabe, OU o piso editorial venceu. Nunca as duas coisas erradas."""
        for w, h in ((1.14, 0.92), (2.16, 0.95), (4.5, 2.05), (1.64, 0.92)):
            with self.subTest(w=w, h=h):
                text = self.WIDE_TITLE * 2
                pt = G.fit_pt(text, w, h, 12.0)
                if pt > G.TYPE_FLOOR_PT:
                    self.assertLessEqual(est_height(text, w, pt), h + 1e-9,
                                         f'{pt}pt ainda estoura {h}in em {w}in')
                else:
                    self.assertAlmostEqual(pt, G.TYPE_FLOOR_PT, places=6)

    def test_it_never_goes_below_the_editorial_floor(self):
        """Nao ha tamanho que caiba: o piso editorial vale mais que o encaixe."""
        self.assertAlmostEqual(G.fit_pt('x' * 400, 0.6, 0.2, 12.0),
                               G.TYPE_FLOOR_PT, places=6)

    def test_the_long_body_floor_wins_for_prose(self):
        self.assertAlmostEqual(G.fit_pt('x' * 60, 0.9, 0.5, 12.0, long=True),
                               G.BODY_FLOOR_PT, places=6)

    def test_a_wide_box_never_shrinks_the_text(self):
        self.assertAlmostEqual(G.fit_pt(self.WIDE_TITLE, 8.0, 2.0, 12.0), 12.0, places=6)

    def test_empty_text_keeps_the_full_size(self):
        self.assertAlmostEqual(G.fit_pt('', 1.0, 0.5, 12.0), 12.0, places=6)


if __name__ == "__main__":
    unittest.main()