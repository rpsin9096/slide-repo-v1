# -*- coding: utf-8 -*-
"""PIPELINE: quantas vezes o motor repete o trabalho antes de entregar.

O deck e o mesmo em todas as respostas; o que muda e quantas vezes o motor
recarrega o manifest, reexecuta o lint e re-renderiza os 35 modulos. Um lint
que roda duas vezes nao e "mais seguro": e o dobro do custo de I/O e de
verificacao de imagem para a mesma resposta.

Estes testes contam invocacoes na costura real (o mock envolve a funcao de
producao, que continua rodando de verdade).
"""

import contextlib
import io
import textwrap
import unittest
from unittest import mock

from studydeck import cli
from studydeck import lint as L
from studydeck import manifest as MF
from studydeck import render as RD

MANIFEST = textwrap.dedent('''
    COURSE_INFO = {'course': 'Fisiopatologia', 'institution': 'UCP'}
    CONFIG = {'LANG': 'pt-BR', 'PROFILE': 'short'}
    SLIDES = [
        {'module': 'title', 'title': 'Inflamacao aguda',
         'subtitle': 'Do estimulo a resolucao', 'course': 'Fisiopatologia',
         'institution': 'UCP'},
        {'module': 'definition', 'kicker': 'Conceito', 'title': 'Definicao',
         'main_statement': 'Resposta vascular estereotipada do tecido vivo diante da lesao.',
         'key_points': [{'title': 'Vascular', 'desc': 'Vasodilatacao.'},
                        {'title': 'Celular', 'desc': 'Neutrofilos.'}]},
    ]
''')


def _manifest(tmp, body=MANIFEST):
    import pathlib
    path = pathlib.Path(tmp) / 'm.py'
    path.write_text(body, encoding='utf-8')
    return str(path)


def run(*argv):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = cli.main(list(argv))
    return rc, buf.getvalue()


class TestAllLoadsOnce(unittest.TestCase):
    """`all` e a entrada que o autor usa; ela nao pode reler o manifest."""

    def test_all_loads_the_manifest_exactly_once(self):
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            path = _manifest(tmp)
            with mock.patch.object(MF, 'load', wraps=MF.load) as load:
                rc, _out = run('all', path, f'{tmp}/d.pptx')
            self.assertEqual(rc, 0)
            self.assertEqual(load.call_count, 1)

    def test_build_loads_the_manifest_exactly_once(self):
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            path = _manifest(tmp)
            with mock.patch.object(MF, 'load', wraps=MF.load) as load:
                rc, _out = run('build', path, f'{tmp}/d.pptx')
            self.assertEqual(rc, 0)
            self.assertEqual(load.call_count, 1)


class TestAllLintsOnce(unittest.TestCase):
    """Duas respostas de lint identicas na mesma invocacao: uma e desperdicio."""

    def test_all_lints_exactly_once(self):
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            path = _manifest(tmp)
            with mock.patch.object(L, 'check', wraps=L.check) as lint:
                rc, _out = run('all', path, f'{tmp}/d.pptx')
            self.assertEqual(rc, 0)
            self.assertEqual(lint.call_count, 1)

    def test_build_lints_exactly_once(self):
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            path = _manifest(tmp)
            with mock.patch.object(L, 'check', wraps=L.check) as lint:
                rc, _out = run('build', path, f'{tmp}/d.pptx')
            self.assertEqual(rc, 0)
            self.assertEqual(lint.call_count, 1)

    def test_lint_still_lints_when_asked(self):
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            path = _manifest(tmp)
            with mock.patch.object(L, 'check', wraps=L.check) as lint:
                rc, _out = run('lint', path)
            self.assertEqual(rc, 0)
            self.assertEqual(lint.call_count, 1)


class TestContrastDoesNotLint(unittest.TestCase):
    """`contrast` promete contraste. Rodar o contrato inteiro e jogar fora nao
    e caution: e a validacao que o comando nao pediu."""

    def test_contrast_of_a_manifest_never_calls_lint(self):
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            path = _manifest(tmp)
            with mock.patch.object(L, 'check', wraps=L.check) as lint:
                rc, out = run('contrast', path)
            self.assertEqual(rc, 0)
            self.assertIn('0 violaciones', out)
            self.assertEqual(lint.call_count, 0)

    def test_the_contrast_matrix_never_calls_lint(self):
        with mock.patch.object(L, 'check', wraps=L.check) as lint:
            rc, out = run('contrast')
        self.assertEqual(rc, 0)
        self.assertIn('ucp', out)
        self.assertEqual(lint.call_count, 0)

    def test_scan_contrast_is_render_only(self):
        from studydeck.fixtures import fixture_slides
        deck = MF.Deck('<fixture>', fixture_slides(), {'course': 'STUDYDECK CHECK'},
                       {'LANG': 'pt-BR'})
        with mock.patch.object(L, 'check', wraps=L.check) as lint:
            fails = RD.scan_contrast(deck)
        self.assertEqual(fails, [])
        self.assertEqual(lint.call_count, 0)


class TestCheckRendersOnce(unittest.TestCase):
    """`check` renderiza os 35 modulos. Fez isso duas vezes."""

    def test_check_renders_the_fixture_exactly_once(self):
        with mock.patch.object(RD, 'render', wraps=RD.render) as render:
            rc, out = run('check')
        self.assertEqual(rc, 0)
        self.assertEqual(render.call_count, 1)

    def test_check_still_reports_every_module(self):
        rc, out = run('check')
        self.assertEqual(rc, 0)
        self.assertIn('35/35', out)
        self.assertIn('0 violaciones', out)

    def test_check_still_attributes_a_broken_module(self):
        """O render unico e o caminho feliz; o isolating fica so na excecao."""
        from studydeck.fixtures import fixture_slides
        original = RD.MODULES['definition']['render']

        def saboteur(slide, d, pal, info):
            raise RuntimeError('modulo quebrado de proposito')

        with mock.patch.dict(RD.MODULES['definition'], {'render': saboteur}):
            rows = RD.self_test()
        broken = dict((name, ok) for name, ok, _detail in rows)
        self.assertFalse(broken['definition'])
        self.assertEqual(broken['title'], True)
        del original


class TestNoAliasForTheSameWork(unittest.TestCase):
    """`scan_contrast` era um apelido de uma linha para `contrast_scan`. Dois
    nomes para um comportamento e dividao de manutencao."""

    def test_the_contrast_entry_point_is_unique(self):
        import inspect
        from studydeck import render as module
        public = [n for n, f in vars(module).items()
                  if not n.startswith('_') and inspect.isfunction(f)]
        contrast = [n for n in public if 'contrast' in n]
        self.assertEqual(sorted(contrast), ['scan_contrast'],
                         f'uma so porta de entrada para contraste, achou {contrast}')


if __name__ == "__main__":
    unittest.main()