# -*- coding: utf-8 -*-
"""Deck de densidade alta: os 35 modulos na cardinalidade maxima, no limite.

Este e o pior caso que um AUTOR pode escrever dentro do contrato — nao um
payload invalido. Todo campo respeita `contracts.B`: cardinalidade maxima e
texto no limite de caracteres. `test_dense_deck_is_legal` prova isso passando o
deck pelo lint; sem essa prova, um oraculo visual aqui so mediria um manifesto
que ninguem escreveria.

O orcamento e em CARACTERES, nao em palavras: `_chars(n)` devolve exatamente n.
A primeira versao deste deck media "palavras" e produzia descs de 193 caracteres
onde o contrato permite 150 — por isso previa transbordos que nao existem.
"""

BASIS = ('lesao endotelial capilar aumenta permeabilidade e forma exsudato '
         'intersticial no tecido vizinho ')


def _chars(n):
    """Exatamente `n` caracteres de corpo clinico, sem sentido e sem piese."""
    return (BASIS * (n // len(BASIS) + 2))[:n]


def _tag(n):
    """Rotulo curto: badges e pills vivem de poucas palavras."""
    return _chars(n).split(' ')[0][:n].upper()


def _image():
    """A figura do proprio fixture: existe, respeita 20 KB-4 MB e lado >= 300 px."""
    from studydeck.fixtures import _fixture_image
    return _fixture_image()


def _img_slides():
    img = _image()
    return [
        {'module': 'figure', 'kicker': 'Evidencia', 'title': 'Figura densa',
         'image': img, 'caption': _chars(110), 'credit': _chars(130)},
        {'module': 'authority_card', 'kicker': 'Autor', 'title': 'Autor denso',
         'image': img, 'name': _chars(60), 'dates': _chars(30),
         'epithet': _chars(80), 'bio': _chars(300), 'legacy': _chars(120),
         'caption': _chars(110), 'credit': _chars(130)},
    ]


def dense_deck():
    """[slide] dos 35 modulos, cada um na maior cardinalidade que o contrato permite."""
    rows = [
        {'module': 'title', 'course': _chars(70), 'title': _chars(80),
         'subtitle': _chars(100), 'institution': _chars(70), 'author': _chars(70)},
        {'module': 'section_divider', 'section_title': _chars(70),
         'section_subtitle': _chars(180), 'divider_style': _tag(40),
         'author': _chars(70)},
        {'module': 'definition', 'kicker': _tag(55), 'title': _chars(75),
         'main_statement': _chars(240), 'elaboration': _chars(230),
         'footnote': _chars(120),
         'key_points': [{'title': _chars(45), 'desc': _chars(150)} for _ in range(3)]},
        {'module': 'flow_diagram', 'kicker': _tag(55), 'title': _chars(75),
         'explanation': _chars(340),
         'steps': [dict({'label': _chars(12)[:3], 'title': _chars(35),
                         'desc': _chars(170)}, highlight=(i == 1))
                   for i in range(4)]},
        {'module': 'comparison_table', 'kicker': _tag(55), 'title': _chars(75),
         'headers': [_chars(24) for _ in range(3)], 'col_widths': [2.0, 1.0, 1.0],
         'takeaway': _chars(140),
         'rows': [[_chars(160) for _ in range(3)] for _ in range(3)]},
        {'module': 'synthesis_grid', 'kicker': _tag(55), 'title': _chars(75),
         'headers': [_chars(30) for _ in range(3)],
         'matrix_data': [[_chars(220) for _ in range(3)] for _ in range(3)],
         'takeaway': _chars(140)},
        {'module': 'stat_card', 'kicker': _tag(55), 'title': _chars(75),
         'stat_num': '42%', 'stat_title': _chars(120),
         'narrative_blocks': [{'title': _chars(45), 'desc': _chars(180)}
                              for _ in range(3)]},
        {'module': 'checklist', 'kicker': _tag(55), 'title': _chars(75),
         'items': [{'label': _chars(65), 'desc': _chars(150)} for _ in range(5)]},
        {'module': 'fixed_schema_card', 'kicker': _tag(55), 'title': _chars(75),
         'fields': [{'label': _chars(30), 'value': _chars(170)} for _ in range(5)]},
        {'module': 'side_by_side', 'kicker': _tag(55), 'title': _chars(75),
         'left_card': {'header': _chars(35), 'title': _chars(50),
                       'points': [_chars(125) for _ in range(4)]},
         'right_card': {'header': _chars(35), 'title': _chars(50),
                        'points': [_chars(125) for _ in range(4)]}},
        {'module': 'taxonomy_tree', 'kicker': _tag(55), 'title': _chars(75),
         'root': _chars(50),
         'categories': [{'name': _chars(30), 'property': _chars(65),
                         'examples': [_chars(90) for _ in range(3)]}
                        for _ in range(3)]},
        {'module': 'algorithm', 'kicker': _tag(55), 'title': _chars(75),
         'steps': [{'title': _chars(70), 'desc': _chars(200)} for _ in range(4)]},
        {'module': 'case_block', 'kicker': _tag(55), 'title': _chars(75),
         'case_stem': _chars(240), 'findings': [_chars(80) for _ in range(5)],
         'reasoning': _chars(250), 'diagnosis': _chars(50),
         'clinical_pearl': _chars(160)},
        {'module': 'timeline', 'kicker': _tag(55), 'title': _chars(75),
         'milestones': [{'label': str(i + 1), 'title': _chars(40), 'desc': _chars(70)}
                        for i in range(5)]},
        {'module': 'cycle_diagram', 'kicker': _tag(55), 'title': _chars(75),
         'center_label': _chars(40),
         'nodes': [{'title': _chars(40), 'desc': _chars(80)} for _ in range(6)]},
        {'module': 'quadrant_matrix', 'kicker': _tag(55), 'title': _chars(75),
         'x_label': _chars(45), 'y_label': _chars(45),
         'quadrants': [{'title': _chars(40), 'points': [_chars(110) for _ in range(5)]}
                       for _ in range(4)]},
        {'module': 'pyramid', 'kicker': _tag(55), 'title': _chars(75),
         'levels': [{'title': _chars(55), 'desc': _chars(90)} for _ in range(5)]},
        {'module': 'quote_block', 'kicker': _tag(55), 'title': _chars(75),
         'quote': _chars(260), 'author': _chars(60), 'source': _chars(90),
         'year': '1900', 'context': _chars(160)},
        {'module': 'socratic_question', 'kicker': _tag(55), 'title': _chars(75),
         'question': _chars(220), 'context': _chars(160), 'reading': _chars(130),
         'scaffold': [_chars(90) for _ in range(4)]},
        {'module': 'oxford_union', 'kicker': _tag(55), 'title': _chars(75),
         'motion': _chars(140), 'verdict': _chars(160),
         'pro_card': {'title': _chars(30), 'points': [_chars(110) for _ in range(4)]},
         'con_card': {'title': _chars(30), 'points': [_chars(110) for _ in range(4)]}},
        {'module': 'evidence_card', 'kicker': _tag(55), 'title': _chars(75),
         'study_name': _chars(60), 'design': _chars(60),
         'population': _chars(140), 'intervention': _chars(140),
         'comparison': _chars(140), 'outcome': _chars(140),
         'effect': 'HR 0.75', 'effect_desc': _chars(120),
         'limitation': _chars(160), 'year': '2024', 'credit': _chars(130)},
        {'module': 'viva_question', 'kicker': _tag(55), 'title': _chars(75),
         'prompt': _chars(220), 'model_answer': _chars(260),
         'examiner_note': _chars(180), 'difficulty': _tag(12)},
        {'module': 'mnemonic_card', 'kicker': _tag(55), 'title': _chars(75),
         'acronym': 'SAMPLA', 'expansion': [_chars(30) for _ in range(6)],
         'usage': _chars(200), 'domain': _tag(30)},
        {'module': 'etymology', 'kicker': _tag(55), 'title': _chars(75),
         'term': 'Apendicite', 'fragments': ['Apendic', 'ite'],
         'roots': [{'part': 'Apendic', 'origin': 'latim', 'meaning': _chars(70)},
                   {'part': 'ite', 'origin': 'grego', 'meaning': _chars(70)}],
         'modern': _chars(160)},
        {'module': 'venn_diagram', 'kicker': _tag(55), 'title': _chars(75),
         'sets': [{'label': _chars(30), 'items': [_chars(30) for _ in range(4)]}
                  for _ in range(3)],
         'shared': [_chars(45) for _ in range(3)]},
        {'module': 'chart_data', 'kicker': _tag(55), 'title': _chars(75),
         'chart_type': 'bar', 'categories': [_chars(25) for _ in range(8)],
         'series': [{'name': _chars(30),
                     'values': [float(i + 1) for i in range(8)]},
                    {'name': _chars(30),
                     'values': [float(8 - i) for i in range(8)]}],
         'insights': [_chars(120) for _ in range(3)], 'credit': _chars(130)},
        {'module': 'references', 'kicker': _tag(55), 'title': _chars(75),
         'refs': [_chars(160) for _ in range(10)]},
        {'module': 'learning_objectives', 'kicker': _tag(55), 'title': _chars(75),
         'objectives': [{'verb': _tag(25), 'text': _chars(130),
                         'bloom': 'apply'} for _ in range(6)]},
        {'module': 'colloquy', 'kicker': _tag(55), 'title': _chars(75),
         'turns': [{'speaker': 'tutor' if i % 2 == 0 else 'student',
                    'text': _chars(160)} for i in range(8)]},
        {'module': 'annotated_passage', 'kicker': _tag(55), 'title': _chars(75),
         'passage': _chars(520), 'source': _chars(90),
         'annotations': [{'ref': str(i + 1), 'note': _chars(110)} for i in range(5)]},
        {'module': 'concept_map', 'kicker': _tag(55), 'title': _chars(75),
         'hub': _chars(40),
         'nodes': [{'title': _chars(35), 'desc': _chars(60)} for _ in range(6)]},
        {'module': 'glossary', 'kicker': _tag(55), 'title': _chars(75),
         'terms': [{'term': _chars(30), 'def': _chars(130)} for _ in range(10)]},
        {'module': 'further_reading', 'kicker': _tag(55), 'title': _chars(75),
         'entries': [{'tag': 'avanzado', 'title': _chars(90), 'note': _chars(100)}
                     for _ in range(6)]},
    ]
    return rows + _img_slides()